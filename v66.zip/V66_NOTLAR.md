# V66 NOTLAR — Yayın profilleri: kim ne görür

Taban: v65 (224). Sonuç: 225 dosya (1 yeni, 8 değişen). Silinecek yok. Firestore kuralı değişmedi (kullanıcı belgesine profile / places alanlarını yalnız yönetici yazar; mevcut kural yöneticiye serbest).

## Dosyalar (SHA-256)
a481aa91b43564d63676f3743df820fb3a8326b480429fbe4bf03484e7676e1a  src/config/publishProfiles.ts
a51d9b08c63459d7c04d2d5f68ce2f50a0fffa4382e5e2173e2b8bd43f6f7430  src/types/auth.ts
bb9d15028529585112bc9c39c86e0d188590fa4d44fa63ec545bad9e5f5b9244  src/utils/authService.ts
043986280f98f49b918179528bc6f258cff62e3145af9969f11579576ade91d0  src/components/auth/AdminUserManagementModal.tsx
380e22b86542e87baf3133227a81e79c8930361f065f056aa6e4c99f02608a1f  src/components/portal/HomeMenu.tsx
0d8818dbea9d4e36b8d185eacff2c45e3022c0d92901d5e54d1656f9660b9884  src/components/common/MobileBottomBar.tsx
0b44781a628c98b9620505e7f664b279c47a9229819e191a0d24ca1a4dab2a2b  src/components/dashboard/HomeDashboard.tsx
4ca81e69ace7775460870e6a90832c8a232d6bb43946816878c1dffa30fe549a  src/App.tsx
772b9200382ba80a1e031fe54aa6603ddde08c8ecd1145119823539accf93c54  src/components/views/OrchardCardsView.tsx

Yeni: src/config/publishProfiles.ts

## Ne değişti
- 7 profil: Saha (bahçe) · Sera (muz) · Depo · Lojistik · Ofis / kalite · Yönetim · Dış / müşteri. Yönetici her şeyi görür.
- Kullanıcılar ve onaylar › kişiyi düzenle › "Yayın profili" (Otomatik = bölümünden tahmin) ve "Kendi yerleri" (bahçe / sera / depo düğmeleri).
- Menü: yalnız profilin ekranları; boş gruplar kalkar; başlık altında "Profil: … · yerler".
- Alt çubuk: Saha / Sera'da Depolar yok; Depo / Lojistik'te Bahçeler yok; Dış'ta yalnız Ana ve Menü. + düğmesi profilin kayıtlarını bir liste olarak açar (Saha: hasat, saha testi, badem, akt; Depo: depo kabul, ön soğutma, sortlama, akt; …).
- Ana sayfa: profile göre bölümler; "Bugün bakılacaklar" profile göre (Saha bahçe işleri, Sera muz, Depo / Lojistik depo + uyarı, Ofis / Yönetim hepsi).
- Aktlar: herkes kendi yerlerinin (ve kendi yazdığı) aktları; Yönetim ve Ofis / kalite hepsini; yer seçilmemişse hepsi.
- Kendi yerleri: Bahçeler listesinde önde ve ● işaretli; Saha / Sera / Depo / Lojistik başka yeri açabilir ama orada kayıt giremez ("bakabilirsiniz, kayıt giremezsiniz").
- Dış / müşteri: ana sayfada yalnız "Parti bilgisi" açıklaması; arama ve Partiler yok; QR linkiyle gelince herkese açık parti kartı (iç kayıt açılmaz); başka ekrana geçemez.
