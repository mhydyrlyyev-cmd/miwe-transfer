export type UserStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'DEACTIVATED' | 'PASIF_READER';
export type UserRole = 'ADMIN' | 'OPERATOR' | 'QUALITY_INSPECTOR' | 'MANAGER' | 'VIEWER';

export interface UserPermissions {
  canEdit: boolean;       // Düzenleme Yetkisi (Admin onaylı)
  canDelete: boolean;     // Silme Yetkisi (Admin onaylı)
  canClearDemo: boolean;   // Örnekleri Temizleme Yetkisi (Admin onaylı)
  canExport: boolean;     // PDF / CSV Dışa Aktarma Yetkisi
  canViewAll?: boolean;   // Tüm Verileri Görüntüleme İzni
}

export interface AppUser {
  id: string;
  fullName: string;       // İsim Soyisim
  phone: string;          // Telefon No
  email: string;          // E-posta
  company: string;        // Görev Yaptığı Firma
  jobTitle: string;       // Görevi / Pozisyon
  role: UserRole;
  status: UserStatus;
  allowedModules: string[]; // Görebileceği modüller ('ALL' veya modül anahtarları)
  permissions: UserPermissions;
  requiresPasswordChange?: boolean; // İlk girişte şifre değiştirme zorunluluğu
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
  approvedBy?: string;
  approvedAt?: string;
  /** v66 yayın profili (config/publishProfiles) */
  profile?: 'SAHA' | 'SERA' | 'DEPO' | 'LOJISTIK' | 'OFIS' | 'YONETIM' | 'DIS';
  /** v66 kendi yerleri: bahçe / sera / depo adları */
  places?: string[];
}

export interface PasswordResetRequest {
  id: string;
  email: string;
  userId: string;
  verificationCode: string;
  createdAt: string;
  expiresAt: string;
  isUsed: boolean;
}

export type ActivityActionType =
  | 'LOGIN'
  | 'LOGOUT'
  | 'REGISTER'
  | 'CREATE_RECORD'
  | 'UPDATE_RECORD'
  | 'DELETE_RECORD'
  | 'CLEAR_DEMO_DATA'
  | 'USER_APPROVED'
  | 'USER_REJECTED'
  | 'USER_APPROVAL_REVOKED'
  | 'USER_PERMISSIONS_UPDATED'
  | 'DISPATCH_SHIPMENT'
  | 'EXPORT_REPORT'
  | 'SYSTEM_SYNC';

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userEmail: string;
  company: string;
  jobTitle: string;
  action: ActivityActionType;
  module?: string;
  refId?: string;
  details: string;
}

/** v49c: iş bölümleri (bahçe / depo adı bölüm değildir; kişinin yeri ayrıca yazılır) */
export const KNOWN_COMPANIES = [
  'Saha / bahçeler',
  'Seralar (muz)',
  'Muz kalite ve paketleme',
  'Depo',
  'Lojistik / sevk',
  'Satış',
  'Freeze-dry (Erem)',
  'Kalite merkezi',
  'Yönetim'
] as const;

export const KNOWN_JOB_TITLES = [
  'Sistem & Kalite Yöneticisi',
  'Ziraat Yüksek Mühendisi',
  'Kalite Kontrol ve Standartlaşma Uzmanı',
  'Hasat & Saha Operatörü',
  'Depo & Soğuk Hava Şefi',
  'Frigorifik Sevkiyat Sorumlusu',
  'Kantar ve Muhasebe Memuru',
  'İhracat / Satış Koordinatörü'
] as const;

export const ALL_APP_MODULES = [
  { key: 'HARVEST', name: 'Günlük Hasat & Bahçe', desc: 'Hasat, kantar ve saha kabulleri' },
  { key: 'FIELD', name: 'Meyve Kalite Testi', desc: 'Penetrometre, Brix, nitrat ve kalite sapması' },
  { key: 'MUZ', name: 'Muz Kalite Kontrol & MAP', desc: '1-7 renk skalası, şerit, kalibrasyon ve gazlama' },
  { key: 'BADEM', name: 'Badem Testi & Randıman', desc: 'Randıman %, nem ve çatlama parametreleri' },
  { key: 'LOJISTIK', name: 'Lojistik & Delilnama', desc: 'Resmi delilnama, frigorifik tır ve sevkiyat' },
  { key: 'AMBAR', name: 'Ambar & Soğuk Depo', desc: 'Kabul, 1-MCP, ozonlama, fire takibi' },
  { key: 'FREEZE_DRY', name: 'Freeze & Dry Kurutma', desc: 'Liyofilizasyon ve standart dışı değerlendirme' },
  { key: 'EXPORT_SAMPLE', name: 'İhracat Numune Testi', desc: 'Transit dayanım ve raf ömrü testleri' },
  { key: 'SALES', name: 'Satış & Sevkiyat Çıkışı', desc: 'Müşteri faturası, ticari çıkış' },
  { key: 'INCIDENT', name: 'Barlag Akty & Uygunsuzluk', desc: 'Kalite sapma tutanağı, 5-Why analizi' },
  { key: 'GALLERY', name: 'Saha Fotoğraf Galerisi', desc: 'Hasat, kalite ve yükleme fotoğrafları' },
  { key: 'ANALYTICS', name: 'Kalite Raporları & Analitik', desc: 'İstatistikler, grafikler ve trendler' },
  { key: 'MONTHLY_REPORT', name: 'Aylık Kalite Raporu', desc: 'Resmi aylık ihracat ve kalite bülteni' },
  { key: 'REFERENCES', name: 'Parti & Kütük Defteri', desc: 'Tüm partilerin genel izlenebilirlik kütüğü' }
] as const;
