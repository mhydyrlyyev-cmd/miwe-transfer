/**
 * v66 — Yayın profilleri: kim ne görür.
 * Her kullanıcıya yönetici bir profil atar (Kullanıcılar ve onaylar › düzenle). Atanmamışsa bölümünden (company) tahmin edilir.
 * ADMIN rolü her zaman her şeyi görür. Düzenleme / silme izinleri (permissions) ayrıdır, bu dosya yalnız GÖRÜNÜRLÜĞÜ belirler.
 * Yer sınırı (places): kendi bahçe / sera / depoları önde; diğerleri açılabilir ama orada kayıt (test, hasat) girilmez.
 * Aktlar: herkes kendi yerlerinin aktlarını görür; Yönetim ve Ofis / kalite hepsini.
 */
import type { AppUser } from '../types/auth';

export type PublishProfile = 'SAHA' | 'SERA' | 'DEPO' | 'LOJISTIK' | 'OFIS' | 'YONETIM' | 'DIS';
export type HomeSection = 'TODAY' | 'WEATHER' | 'FLOW' | 'DEPOTS' | 'WEEK' | 'ORCHARDS' | 'REFS';

export interface ProfileDef {
  key: PublishProfile; label: string; who: string;
  /** menüde görünen ekranlar (view anahtarları); '*' = hepsi */
  menu: string[] | '*';
  /** + düğmesinde çıkan kayıtlar (view anahtarları) */
  plus: string[];
  /** ana sayfa bölümleri, sırasıyla */
  home: HomeSection[];
  /** alt çubuk: Bahçeler / Depolar / + görünür mü */
  nav: { orchards: boolean; depots: boolean; plus: boolean };
  /** bütün aktları görür mü (değilse yalnız kendi yerleri) */
  allIncidents: boolean;
  /** kayıt girebilir mi (Dış hiç giremez) */
  canRecord: boolean;
}

const COMMON_TAIL = ['MANAGER_BRIEF', 'GUIDE_PORTAL', 'FEEDBACK', '__SYNC', 'PENDING'];

export const PROFILES: Record<PublishProfile, ProfileDef> = {
  SAHA: { key: 'SAHA', label: 'Saha (bahçe)', who: 'saha çalışanı · agronom',
    menu: ['HARVEST', 'PRECOOLING', 'INCIDENT', 'TEST_HUB', 'FIELD', 'BADEM', '__FLOW_BADEM', 'ORCHARD_CARDS', 'CLIMATE', '__STANDARDS', '__VISUAL_STANDARDS', ...COMMON_TAIL],
    plus: ['HARVEST', 'FIELD', 'BADEM', 'INCIDENT'], home: ['TODAY', 'WEATHER', 'ORCHARDS', 'WEEK'],
    nav: { orchards: true, depots: false, plus: true }, allIncidents: false, canRecord: true },
  SERA: { key: 'SERA', label: 'Sera (muz)', who: 'sera sorumlusu · muz kalite',
    menu: ['HARVEST', 'INCIDENT', 'TEST_HUB', 'MUZ', '__FLOW_MUZ', 'ORCHARD_CARDS', '__STANDARDS', '__VISUAL_STANDARDS', ...COMMON_TAIL],
    plus: ['HARVEST', 'MUZ', 'INCIDENT'], home: ['TODAY', 'FLOW', 'WEEK'],
    nav: { orchards: true, depots: false, plus: true }, allIncidents: false, canRecord: true },
  DEPO: { key: 'DEPO', label: 'Depo', who: 'depo ve soğuk hava',
    menu: ['PRECOOLING', 'SORTING_STATUS', 'AMBAR', 'INCIDENT', '__BATCH_SCAN', 'TEST_HUB', '__LABELS', '__STANDARDS', ...COMMON_TAIL],
    plus: ['AMBAR', 'PRECOOLING', 'SORTING_STATUS', 'INCIDENT'], home: ['TODAY', 'DEPOTS', 'FLOW', 'WEEK'],
    nav: { orchards: false, depots: true, plus: true }, allIncidents: false, canRecord: true },
  LOJISTIK: { key: 'LOJISTIK', label: 'Lojistik', who: 'PM merkez · sevk · satış',
    menu: ['AMBAR', 'LOJISTIK', 'SALES', 'INCIDENT', '__BATCH_SCAN', 'EXPORT_SAMPLE', 'MUZ', '__FLOW_MUZ', 'TEST_HUB', 'REPORTS', '__LABELS', ...COMMON_TAIL],
    plus: ['LOJISTIK', 'AMBAR', 'SALES', 'INCIDENT'], home: ['TODAY', 'DEPOTS', 'FLOW', 'WEEK'],
    nav: { orchards: false, depots: true, plus: true }, allIncidents: false, canRecord: true },
  OFIS: { key: 'OFIS', label: 'Ofis / kalite', who: 'ofis · kalite uzmanı',
    menu: '*', plus: ['FIELD', 'EXPORT_SAMPLE', 'FREEZE_DRY', 'INCIDENT'], home: ['TODAY', 'WEATHER', 'FLOW', 'DEPOTS', 'WEEK', 'ORCHARDS', 'REFS'],
    nav: { orchards: true, depots: true, plus: true }, allIncidents: true, canRecord: true },
  YONETIM: { key: 'YONETIM', label: 'Yönetim', who: 'müdürler',
    menu: ['MANAGER_BRIEF', 'REPORTS', 'ALERTS', 'TEST_HUB', 'ORCHARD_CARDS', 'CLIMATE', 'INCIDENT', 'MGMT_ANALYSIS', '__STANDARDS', 'GUIDE_PORTAL', 'FEEDBACK', '__SYNC'],
    plus: ['INCIDENT'], home: ['TODAY', 'WEEK', 'ORCHARDS', 'WEATHER', 'DEPOTS', 'FLOW'],
    nav: { orchards: true, depots: true, plus: true }, allIncidents: true, canRecord: true },
  DIS: { key: 'DIS', label: 'Dış / müşteri', who: 'alıcı · misafir · denetçi',
    menu: ['GUIDE_PORTAL'], plus: [], home: [],
    nav: { orchards: false, depots: false, plus: false }, allIncidents: false, canRecord: false },
};
export const PROFILE_ORDER: PublishProfile[] = ['SAHA', 'SERA', 'DEPO', 'LOJISTIK', 'OFIS', 'YONETIM', 'DIS'];

/** Atanmış profil; yoksa bölümden tahmin. ADMIN → null (her şey). */
export function profileOf(u?: AppUser | null): ProfileDef | null {
  if (!u || u.role === 'ADMIN') return null;
  const k = (u as AppUser & { profile?: PublishProfile }).profile;
  if (k && PROFILES[k]) return PROFILES[k];
  const c = (u.company || '').toLocaleLowerCase('tr');
  if (/yönetim/.test(c) || u.role === 'MANAGER') return PROFILES.YONETIM;
  if (/kalite merkezi|freeze|erem/.test(c) || u.role === 'QUALITY_INSPECTOR') return PROFILES.OFIS;
  if (/sera|muz/.test(c)) return PROFILES.SERA;
  if (/depo/.test(c)) return PROFILES.DEPO;
  if (/lojistik|sevk|satış/.test(c)) return PROFILES.LOJISTIK;
  if (/saha|bahçe/.test(c)) return PROFILES.SAHA;
  return u.role === 'VIEWER' ? PROFILES.DIS : PROFILES.OFIS;
}
export const placesOf = (u?: AppUser | null): string[] => ((u as (AppUser & { places?: string[] }) | null | undefined)?.places || []).filter(Boolean);
/** + düğmesindeki kayıtların adları */
export const PLUS_LABEL: Record<string, string> = {
  HARVEST: 'Günlük hasat', FIELD: 'Saha testi', BADEM: 'Badem testi', MUZ: 'Muz testi', INCIDENT: 'Akt / olay', AMBAR: 'Depo kabul',
  PRECOOLING: 'Ön soğutma fişi', SORTING_STATUS: 'Sortlama', LOJISTIK: 'Sevk kaydı', SALES: 'Satış', EXPORT_SAMPLE: 'İhracat numunesi', FREEZE_DRY: 'Freeze-dry',
};
export const ADMIN_PLUS = ['HARVEST', 'FIELD', 'MUZ', 'BADEM', 'AMBAR', 'LOJISTIK', 'SALES', 'INCIDENT'];
export const canSeeView = (p: ProfileDef | null, view: string) => !p || p.menu === '*' || p.menu.includes(view);
