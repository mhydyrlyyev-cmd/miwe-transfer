import React from 'react';
import { Home, Plus, TreeDeciduous, Warehouse, Menu } from 'lucide-react';

/**
 * v52 — Mobil alt menü: Ana · Bahçeler · [+ Yeni kayıt] · Depolar · Menü. Partiler: Ana sayfa üstü ve Menü.
 * Uyarılar Ana sayfadaki zilde, senkron Menü'de (çevrimdışı / bekleyen kayıt Menü simgesinde nokta).
 */
interface MobileBottomBarProps {
  activeView: string;
  onNavigateToDashboard: () => void;
  onOpenQuickNew: () => void;
  onOpenSyncModal: () => void;
  onOpenGallery: () => void;
  onOpenSearch: () => void;
  onOpenReferences?: () => void;
  onOpenAlerts?: () => void;
  alertCount?: number;
  onOpenGantt?: () => void;
  onOpenAiVision?: () => void;
  onOpenDepots?: () => void;
  onOpenMenu?: () => void;
  onOpenOrchards?: () => void;
  offlineQueueCount: number;
  isOnline: boolean;
  /** v66 yayın profili: alt çubukta görünenler ve + listesi */
  show?: { orchards: boolean; depots: boolean; plus: boolean };
  plusItems?: { label: string; view: string }[];
  onPlus?: (view: string) => void;
}

export const MobileBottomBar: React.FC<MobileBottomBarProps> = ({
  activeView,
  onNavigateToDashboard,
  onOpenQuickNew,
  onOpenSyncModal,
  onOpenSearch,
  onOpenReferences,
  onOpenDepots,
  onOpenMenu,
  onOpenOrchards,
  offlineQueueCount,
  isOnline,
  show = { orchards: true, depots: true, plus: true },
  plusItems,
  onPlus,
}) => {
  const [sheet, setSheet] = React.useState(false);
  const plus = () => { if (plusItems && plusItems.length > 1 && onPlus) setSheet(s => !s); else if (plusItems?.length === 1 && onPlus) onPlus(plusItems[0].view); else onOpenQuickNew(); };
  const tab = (on: boolean) =>
    `flex-1 flex flex-col items-center justify-center gap-0.5 min-h-[52px] rounded-xl text-[11px] cursor-pointer transition active:scale-95 ${
      on ? 'text-teal-700 font-bold dark:text-teal-300' : 'text-slate-500 font-semibold dark:text-slate-400'
    }`;

  return (
    <nav
      aria-label="Alt menü"
      style={{
        paddingBottom: 'calc(0.4rem + env(safe-area-inset-bottom, 0px))',
        paddingLeft: 'calc(0.5rem + env(safe-area-inset-left, 0px))',
        paddingRight: 'calc(0.5rem + env(safe-area-inset-right, 0px))',
      }}
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pt-1 sm:hidden flex items-end select-none print:hidden"
    >
      <button type="button" onClick={onNavigateToDashboard} className={tab(activeView === 'DASHBOARD')} aria-current={activeView === 'DASHBOARD' ? 'page' : undefined}>
        <Home className="w-6 h-6" />Ana
      </button>

      {show.orchards && <button type="button" onClick={onOpenOrchards || onOpenReferences || onOpenSearch} className={tab(['ORCHARD_CARDS', 'HARVEST_CALENDAR', 'CLIMATE'].includes(activeView))} aria-current={['ORCHARD_CARDS', 'HARVEST_CALENDAR', 'CLIMATE'].includes(activeView) ? 'page' : undefined}>
        <TreeDeciduous className="w-6 h-6" />Bahçeler
      </button>}

      {show.plus && <div className="flex-1 flex justify-center relative">
        {sheet && plusItems && (
          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 w-56 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xl p-1.5 z-50">
            <div className="text-[11px] font-semibold text-slate-500 px-2 py-1">Yeni kayıt</div>
            {plusItems.map(it => <button key={it.view} type="button" onClick={() => { setSheet(false); onPlus?.(it.view); }} className="w-full text-left min-h-[44px] px-3 rounded-xl text-sm text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">{it.label}</button>)}
          </div>
        )}
        <button
          type="button"
          onClick={plus}
          aria-label="Yeni kayıt"
          className="-mt-6 w-14 h-14 rounded-2xl bg-teal-700 hover:bg-teal-800 text-white flex items-center justify-center shadow-lg shadow-teal-700/30 ring-4 ring-white dark:ring-slate-900 active:scale-95 transition cursor-pointer"
        >
          <Plus className="w-7 h-7" strokeWidth={2.75} />
        </button>
      </div>}

      {show.depots && <button type="button" onClick={onOpenDepots} className={tab(activeView === 'COLD_STORAGE')} aria-current={activeView === 'COLD_STORAGE' ? 'page' : undefined}>
        <Warehouse className="w-6 h-6" />Depolar
      </button>}

      <button type="button" onClick={onOpenMenu || onOpenSyncModal} className={tab(activeView === 'PORTAL_LAUNCHER')} aria-current={activeView === 'PORTAL_LAUNCHER' ? 'page' : undefined}>
        <span className="relative">
          <Menu className="w-6 h-6" />
          {(!isOnline || offlineQueueCount > 0) && (
            <span className="absolute -top-1 -right-1.5 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-900" aria-label={!isOnline ? 'Çevrimdışı' : `${offlineQueueCount} kayıt bekliyor`} />
          )}
        </span>
        Menü
      </button>
    </nav>
  );
};
