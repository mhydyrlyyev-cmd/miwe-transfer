import React, { useMemo } from 'react';
import { profileOf, type HomeSection } from '../../config/publishProfiles';
import { Search, Bell, Thermometer, ClipboardCheck, AlertTriangle, Wrench, ChevronRight, Wifi, WifiOff, FlaskConical, Snowflake, Apple, Scissors, Flower2, Banana, Layers } from 'lucide-react';
import type { FieldRecord, AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord, IncidentRecord, ExportSampleRecord } from '../../types';
import type { AppUser } from '../../types/auth';
import { analyzeColdChain } from '../../utils/coldChainEngine';
import { ALERT_STAGE, STAGE_BY_KEY } from '../../config/processStages';
import { lifecycleCounts } from '../../utils/refLifecycle';
import OrchardsPanel from './OrchardsPanel';
import AgroWeatherCard from './AgroWeatherCard';
import { useOrchardTasks } from '../../services/orchardTasks';
import { useMuzDocs, useMuzCfg, muzVerdict, isPal, palWaitH } from '../../services/muzDaily';
import { useFieldStatuses } from '../../services/fieldDaily';
import { FIELD_UNIT } from '../../config/fieldCrops';
import { muzTodaySummary } from '../views/MuzPanel';
import { groupByRef, witnessPlan, WITNESS_MAX_DAY } from '../../services/sahit';
import { useLocationProfiles } from '../../services/locationProfiles';
import { calibrationStatus } from '../../config/calibrationRules';
import { storedLots, summarizeDepots, useRoomChecks, roomCode, setLabel, fmtC, tons } from '../../services/depots';

/**
 * v49c — Ana sayfa: 1) bugün bakılacaklar (eylem düğmeli) 2) akış (5 aşama) 3) depo doluluğu 4) bu hafta.
 * Uzun açıklama ve grafik yok; her satır bir işe götürür. Ayrıntı Rapor merkezinde.
 */
interface Props {
  currentUser?: AppUser | null;
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  incidentRecords: IncidentRecord[];
  testCountThisWeek: number;
  isOnline: boolean;
  pendingCount: number;
  alertCount: number;
  onNavigate: (view: string) => void;
  onOpenDepot: (target: { depotId?: string; roomId?: string; tour?: boolean }) => void;
  onOpenSearch: () => void;
  onOpenAlerts: () => void;
  onOpenProfiles: () => void;
  /** v49c2: uyarı satırı partinin sayfasını açar */
  onOpenLot?: (refId: string) => void;
  /** v49c3: şahit numune 7. ve 14. gün hatırlatması */
  exportSampleRecords?: ExportSampleRecord[];
  /** v49c6: Ana sayfa › Bahçeler kartı */
  onOpenOrchard?: (name: string) => void;
  /** v49c10: hasat öncesi test hatırlatması için */
  fieldRecords?: FieldRecord[];
}

/** v49c10: iş alanı — Depo (oda, tur, şahit numune), Bahçe (bahce-*), Uyarı (diğer) */
export type TodoArea = 'DEPO' | 'BAHCE' | 'UYARI';
export const todoArea = (id: string): TodoArea => (id.startsWith('bahce-') ? 'BAHCE' : /^(room-|tour-|sahit-)/.test(id) ? 'DEPO' : 'UYARI');
export const bahceIcon = (id: string) => id.startsWith('bahce-muzpal') ? <Snowflake className="w-4 h-4" /> : id.startsWith('bahce-muz') ? <Banana className="w-4 h-4" /> : id.startsWith('bahce-test') ? <FlaskConical className="w-4 h-4" /> : id.startsWith('bahce-frost') ? <Snowflake className="w-4 h-4" /> : id.startsWith('bahce-count') ? <Apple className="w-4 h-4" /> : id.startsWith('bahce-thin') ? <Scissors className="w-4 h-4" /> : <Flower2 className="w-4 h-4" />;
export type Todo = { id: string; level: 'bad' | 'warn' | 'info'; title: string; detail: string; action: string; run: () => void };

const STAGES = [
  { key: 'HASAT', label: 'Hasat', view: 'HARVEST_STATUS', cls: 'border-slate-200 bg-slate-50 text-slate-900 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-100' },
  { key: 'ON_SOGUTMA', label: 'Ön soğ.', view: 'PRECOOLING', cls: 'border-slate-200 bg-slate-50 text-slate-900 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-100' },
  { key: 'SORTING', label: 'Sortlama', view: 'SORTING_STATUS', cls: 'border-slate-200 bg-slate-50 text-slate-900 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-100' },
  { key: 'SOGUK_DEPO', label: 'Depo', view: 'COLD_STORAGE', cls: 'border-slate-200 bg-slate-50 text-slate-900 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-100' },
  { key: 'SEVK', label: 'Sevk', view: 'TRANSIT', cls: 'border-slate-200 bg-slate-50 text-slate-900 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-100' },
] as const;

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return 'İyi geceler';
  if (h < 12) return 'Günaydın';
  if (h < 18) return 'İyi günler';
  return 'İyi akşamlar';
}
const weekStart = () => { const d = new Date(); const day = (d.getDay() + 6) % 7; d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - day); return d.toISOString().slice(0, 10); };

type TodoInput = Pick<Props, 'references' | 'harvestRecords' | 'ambarRecords' | 'lojistikRecords' | 'salesRecords' | 'incidentRecords' | 'onNavigate' | 'onOpenDepot' | 'onOpenProfiles' | 'onOpenLot' | 'exportSampleRecords' | 'fieldRecords' | 'onOpenOrchard'>;

/** v49c2: ana sayfa ve "Bugün yapılacaklar" aynı listeyi kullanır */
export function useHomeData(p: TodoInput) {
  useLocationProfiles();
  const devices = useLocationProfiles('DEVICE');
  const checks = useRoomChecks();
  const summary = useMemo(() => analyzeColdChain({ references: p.references, harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords, lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords }),
    [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);
  const lots = useMemo(() => storedLots(p), [p.ambarRecords, p.references, p.lojistikRecords, p.salesRecords, checks]);
  const depots = useMemo(() => summarizeDepots(lots, checks), [lots, checks]);
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);

  // ── Akış: aşama başına parti ve kg ──
  const flow = useMemo(() => {
    const live = p.references.filter(r => !r.archived);
    const pre = live.filter(r => r.status === 'CREATED' && (r.precoolingSlips || []).length > 0);
    const sorting = live.filter((r: any) => {
      const slips = (r.precoolingSlips || []) as any[];
      if (!slips.some(s => s.inspectionMode === 'SORTING' || s.packedKg || s.culledKg)) return false;
      const net = slips.reduce((a, s) => a + (Number(s.netKg) || 0), 0);
      const done = slips.reduce((a, s) => a + (Number(s.packedKg) || 0) + (Number(s.culledKg) || 0), 0);
      return net === 0 || done < net * 0.98;
    });
    const kgOf = (list: ReferenceItem[]) => list.reduce((s, r) => s + (Number(r.quantity) || 0), 0);
    return {
      HASAT: { n: Math.max(0, life.SAHADA - pre.length), kg: Math.max(0, life.kg.SAHADA - kgOf(pre)) },
      ON_SOGUTMA: { n: pre.length, kg: kgOf(pre) },
      SORTING: { n: sorting.length, kg: kgOf(sorting) },
      SOGUK_DEPO: { n: life.DEPODA, kg: depots.reduce((s, d) => s + d.kg, 0) || life.kg.DEPODA },
      SEVK: { n: life.YOLDA, kg: life.kg.YOLDA },
    } as Record<string, { n: number; kg: number }>;
  }, [p.references, life, depots]);

  // ── Bugün bakılacaklar ──
  const orchardTasks = useOrchardTasks(p.harvestRecords, p.fieldRecords || []);
  const muzDocs = useMuzDocs(); const muzCfg = useMuzCfg();
  const fieldSt = useFieldStatuses();
  const todos = useMemo(() => {
    const t: Todo[] = [];
    for (const d of depots) {
      for (const r of d.rooms) {
        if (r.status !== 'bad' && r.status !== 'warn') continue;
        t.push({ id: `room-${r.room.id}`, level: r.status === 'bad' ? 'bad' : 'warn', title: `${String(d.depot.fields?.shortName || d.depot.name)} · ${roomCode(r.room)}`,
          detail: `Son ölçüm ${fmtC(r.reading?.monitorC)} °C · set ${setLabel(r.room)}`, action: 'Odaya git', run: () => p.onOpenDepot({ depotId: d.depot.id, roomId: r.room.id }) });
      }
    }
    for (const d of depots) {
      if (d.rooms.length < 3 && d.lots === 0) continue; // küçük ve boş depoya her gün tur önerilmez
      if (d.checkedToday >= d.rooms.length) continue;
      t.push({ id: `tour-${d.depot.id}`, level: 'info', title: `Oda kontrol turu · ${String(d.depot.fields?.shortName || d.depot.name)}`,
        detail: `${d.checkedToday} / ${d.rooms.length} oda girildi`, action: d.checkedToday ? 'Devam' : 'Başla', run: () => p.onOpenDepot({ depotId: d.depot.id, tour: true }) });
    }
    const testRefs = new Set(lots.filter(l => !l.depot && !l.exited).map(l => l.a.refId)); // profili olmayan depo = deneme
    for (const a of summary.alerts.filter(x => !testRefs.has(x.refId)).slice(0, 6)) {
      const sk = ALERT_STAGE[a.kind];
      const def = STAGE_BY_KEY[sk];
      t.push({ id: a.id, level: a.level === 'critical' ? 'bad' : a.level === 'warning' ? 'warn' : 'info', title: `${a.refId} · ${a.title}`, detail: a.detail,
        action: p.onOpenLot ? 'Partiyi aç' : def.short, run: () => (p.onOpenLot ? p.onOpenLot(a.refId) : p.onNavigate(def.monitorView || def.entryView)) });
    }
    // v49c4: şahit numune — yola çıkıştan 3, 5, 7, 14, 21 … gün ölçümü
    for (const [refId, rs] of groupByRef(p.exportSampleRecords)) {
      const w = witnessPlan(rs);
      if (!w || w.today > WITNESS_MAX_DAY) continue;
      const need = w.dueToday ?? w.missed;
      if (need === undefined) continue;
      const late = w.dueToday === undefined;
      t.push({ id: `sahit-${refId}`, level: late ? 'warn' : 'info', title: `Şahit numune · ${need}. gün ölçümü${late ? ' gecikti' : ''}`,
        detail: `${refId} · yolda ${w.today}. gün · ${w.count} ölçüm kaydı`,
        action: p.onOpenLot ? 'Partiyi aç' : 'Testler', run: () => (p.onOpenLot ? p.onOpenLot(refId) : p.onNavigate('LOTS')) });
    }
    const late = devices.filter(dv => { const st = calibrationStatus(dv.fields); return st.overdue || st.failed; });
    if (late.length) t.push({ id: 'cal', level: 'warn', title: `Kalibrasyon: ${late.length} cihaz`, detail: late.slice(0, 2).map(x => x.name).join(', '), action: 'Profiller', run: p.onOpenProfiles });
    const ord = { bad: 0, warn: 1, info: 2 };
    // v49c10: bahçe yapılacakları (BBCH rasadı, hasat öncesi test, seyreltme, meyve sayımı, çiçek donu)
    for (const o of orchardTasks) t.push({ id: o.id, level: o.level, title: o.title, detail: o.detail, action: o.kind === 'test' ? 'Test' : o.kind === 'frost' ? 'Bak' : 'Gir',
      run: () => (p.onOpenOrchard ? p.onOpenOrchard(o.variety ? `${o.orchard}|${o.variety}` : o.orchard) : p.onNavigate('HARVEST_CALENDAR')) });
    // v50: muz — akşam kg (17:00'den sonra) ve paketleme kalitesi girilmeyen partiler, sera başına bir satır
    const evening = new Date().getHours() >= 17;
    const bySera = new Map<string, { noKg: number; noQ: number; redo: number }>();
    for (const d of muzTodaySummary(muzDocs).days) {
      const x = bySera.get(d.sera) || { noKg: 0, noQ: 0, redo: 0 };
      if (d.kg === undefined && d.counts.length) x.noKg++;
      if (d.kg !== undefined && !d.grades) x.noQ++;
      if (muzVerdict(d.grades, muzCfg)?.decision === 'Gaýtadan işlenen') x.redo++;
      bySera.set(d.sera, x);
    }
    for (const [sera, x] of bySera) {
      const parts = [evening && x.noKg ? `${x.noKg} partide akşam kg yok` : '', x.noQ ? `${x.noQ} partide kalite yok` : '', x.redo ? `${x.redo} parti gaýtadan işlenen` : ''].filter(Boolean);
      if (!parts.length) continue;
      t.push({ id: `bahce-muz-${sera}`, level: evening && x.noKg ? 'warn' : 'info', title: `${sera} · bugün`, detail: parts.join(' · '), action: 'Gir',
        run: () => (p.onOpenOrchard ? p.onOpenOrchard(sera) : p.onNavigate('HARVEST_CALENDAR')) });
    }
    // v51: ön soğutmada bekleme sınırını aşan muz paletleri (sera başına)
    const palBy = new Map<string, { n: number; maxH: number }>();
    for (const pl of muzDocs.filter(isPal).filter(x => !x.shippedAt)) {
      const h = palWaitH(pl);
      if (h < muzCfg.waitWarnH) continue;
      const x = palBy.get(pl.sera) || { n: 0, maxH: 0 }; x.n++; x.maxH = Math.max(x.maxH, h); palBy.set(pl.sera, x);
    }
    for (const [sera, x] of palBy) t.push({ id: `bahce-muzpal-${sera}`, level: x.maxH >= muzCfg.waitCritH ? 'bad' : 'warn', title: `${sera} · ${x.n} palet ön soğutmada bekliyor`,
      detail: `en uzun ${Math.floor(x.maxH)} saat · sınır ${muzCfg.waitWarnH} / ${muzCfg.waitCritH} sa`, action: 'Sevk', run: () => (p.onOpenOrchard ? p.onOpenOrchard(sera) : p.onNavigate('HARVEST_CALENDAR')) });
    // v51: açık tarla — hasadı yaklaşan / süren ekinler
    for (const f of fieldSt.filter(x => x.state === 'hasat yakın' || x.state === 'hasatta')) t.push({ id: `bahce-tarla-${f.crop.id}`, level: 'info',
      title: `${f.crop.name} · ${f.state === 'hasatta' ? 'hasatta' : `hasada ${f.daysTo} gün`}`, detail: f.state === 'hasatta' ? `toplanan ${Math.round(f.harvKg / 1000)} / ${Math.round(f.planKg / 1000)} t` : `${f.ha} ha · plan ${Math.round(f.planKg / 1000)} t`,
      action: 'Gir', run: () => (p.onOpenOrchard ? p.onOpenOrchard(FIELD_UNIT) : p.onNavigate('HARVEST_CALENDAR')) });
    return t.sort((a, b) => ord[a.level] - ord[b.level]);
  }, [depots, summary, devices, lots, p, orchardTasks, muzDocs, muzCfg, fieldSt]);

  // ── Bu hafta ──
  const ws = weekStart();
  const week = useMemo(() => ({
    harvest: p.harvestRecords.filter(h => (h.recordDate || h.timestamp || '').slice(0, 10) >= ws).reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0),
    ship: p.lojistikRecords.filter(l => (l.shipmentDate || '').slice(0, 10) >= ws).reduce((s, l) => s + (Number(l.weightKg) || 0), 0),
    incidents: p.incidentRecords.filter(i => !/RESOLVED|CLOSED|KAPAN|ÇÖZ/i.test(String(i.status || ''))).length,
  }), [p.harvestRecords, p.lojistikRecords, p.incidentRecords, ws]);

  return { todos, flow, depots, week };
}

export default function HomeDashboard(p: Props) {
  const { todos, flow, depots, week } = useHomeData(p);
  const prof = profileOf(p.currentUser);
  const on = (k: HomeSection) => !prof || prof.home.includes(k);
  const first = (p.currentUser?.fullName || '').split(' ')[0];
  const today = new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  const [area, setArea] = React.useState<TodoArea | 'ALL'>('ALL');
  // v66: profile göre işler — Saha: bahçe (muz hariç) · Sera: muz · Depo / Lojistik: depo + uyarı · Ofis / Yönetim: hepsi
  const mine = todos.filter(t => !prof || prof.key === 'OFIS' || prof.key === 'YONETIM' ? true
    : prof.key === 'SAHA' ? todoArea(t.id) === 'BAHCE' && !t.id.startsWith('bahce-muz')
    : prof.key === 'SERA' ? t.id.startsWith('bahce-muz')
    : prof.key === 'DEPO' || prof.key === 'LOJISTIK' ? todoArea(t.id) !== 'BAHCE' : false);
  const areaList = mine.filter(t => area === 'ALL' || todoArea(t.id) === area);
  const shown = areaList.slice(0, 7);
  const dot = { bad: 'bg-rose-600', warn: 'bg-amber-500', info: 'bg-sky-500' };
  const icon = (id: string) => id.startsWith('bahce-') ? bahceIcon(id) : id.startsWith('room-') ? <Thermometer className="w-4 h-4" /> : id.startsWith('tour-') ? <ClipboardCheck className="w-4 h-4" /> : id === 'cal' ? <Wrench className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />;

  return (
    <div className="max-w-5xl mx-auto space-y-3 sm:space-y-4 min-w-0">
      <header className="flex items-end justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">{today}</div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">{greeting()}{first ? `, ${first}` : ''}</h1>
        </div>
        <div className="flex gap-2 shrink-0">
          {(!p.isOnline || p.pendingCount > 0) && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900">{p.isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}{p.pendingCount ? `${p.pendingCount} bekliyor` : 'Çevrimdışı'}</span>
          )}
{/* v52: Partiler alt menüden çıktı (yerine Bahçeler) → burada */}
          {prof?.key !== 'DIS' && <button type="button" onClick={p.onOpenSearch} className="min-h-[36px] px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-800 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer"><Layers className="w-4 h-4 text-teal-700" />Partiler</button>}
        </div>
      </header>

      {prof?.key === 'DIS' && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">Parti bilgisi</h2>
          <p className="text-sm text-slate-700 dark:text-slate-300">Kasa veya palet etiketindeki QR kodu telefonun kamerasıyla okutun: ürün, çeşit, hasat tarihi, sınıf ve o partinin kalite özeti açılır.</p>
          <p className="text-[11px] text-slate-500">Bu hesapta iç kayıtlar, tonajlar, aktlar ve kişi adları görünmez.</p>
        </section>
      )}
      {(!prof || prof.home.length > 0) && <div className="grid gap-3 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        {/* 1) Bugün bakılacaklar */}
        {on('TODAY') && <section className="min-w-0 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Bugün bakılacaklar</h2>
            <span className="text-xs text-slate-500 tabular-nums">{mine.length}</span>
          </div>
          <div className="flex gap-1 mb-1">{([['ALL', 'Tümü'], ['DEPO', 'Depo'], ['BAHCE', 'Bahçe'], ['UYARI', 'Uyarı']] as const).map(([k, l]) => {
            const n = k === 'ALL' ? mine.length : mine.filter(t => todoArea(t.id) === k).length;
            if (k !== 'ALL' && !n && prof && prof.key !== 'OFIS' && prof.key !== 'YONETIM') return null;
            return <button key={k} type="button" onClick={() => setArea(k)} className={`px-2.5 min-h-[30px] rounded-full text-[11px] border cursor-pointer ${area === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{l}{n ? ` ${n}` : ''}</button>;
          })}</div>
          {shown.length === 0 && <p className="py-5 text-center text-sm text-slate-500">Şu an bakılacak bir şey yok.</p>}
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {shown.map(t => (
              <li key={t.id}>
                <button type="button" onClick={t.run} className="w-full flex items-center justify-between gap-3 py-2.5 text-left cursor-pointer">
                  <span className="flex items-center gap-3 min-w-0">
                    <span className="relative w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0">{icon(t.id)}<span className={`absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${dot[t.level]}`} /></span>
                    <span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white truncate">{t.title}</span><span className="block text-xs text-slate-500 truncate">{t.detail}</span></span>
                  </span>
                  <span className="text-xs font-semibold text-teal-700 dark:text-teal-300 whitespace-nowrap">{t.action} ›</span>
                </button>
              </li>
            ))}
          </ul>
          {areaList.length > shown.length && <button type="button" onClick={p.onOpenAlerts} className="mt-1 text-xs font-semibold text-teal-700 cursor-pointer">+{areaList.length - shown.length} daha</button>}
        </section>}

        <div className="space-y-3 min-w-0">
          {/* v63: zirai hava */}
          {on('WEATHER') && <AgroWeatherCard onOpen={() => p.onNavigate('CLIMATE')} />}
          {/* 2) Akış */}
          {on('FLOW') && <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Akış · şu an</h2>
            <div className="grid grid-cols-5 gap-1 text-center">
              {STAGES.map(s => (
                <button key={s.key} type="button" onClick={() => p.onNavigate(s.view)} className={`rounded-xl border py-2 cursor-pointer active:scale-95 transition ${s.cls}`}>
                  <div className="text-lg font-bold tabular-nums">{flow[s.key].n}</div>
                  <div className="text-[10px] text-slate-600 dark:text-slate-300">{s.label}</div>
                  <div className="text-[10px] text-slate-500 tabular-nums">{flow[s.key].kg ? tons(flow[s.key].kg) : '—'}</div>
                </button>
              ))}
            </div>
          </section>}

          {/* 3) Depolar */}
          {on('DEPOTS') && <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Depolar</h2>
              <button type="button" onClick={() => p.onOpenDepot({})} className="text-xs font-semibold text-teal-700 dark:text-teal-300 cursor-pointer">Tümü ›</button>
            </div>
            {depots.length === 0 && <p className="text-sm text-slate-500">Depo profili yok.</p>}
            <ul className="space-y-2.5">
              {depots.map(d => {
                const w = d.pct ?? (d.kg > 0 ? 100 : 0);
                const barCls = d.pct === undefined ? 'bg-indigo-200 dark:bg-indigo-900' : w >= 90 ? 'bg-rose-600' : 'bg-indigo-600';
                return (
                  <li key={d.depot.id}>
                    <button type="button" onClick={() => p.onOpenDepot({ depotId: d.depot.id })} className="w-full text-left cursor-pointer">
                      <div className="flex justify-between text-xs mb-1 gap-2">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">{d.depot.name} <span className="font-normal text-slate-500">· {d.rooms.length} oda</span>{d.bad > 0 && <span className="ml-1 text-rose-700 font-semibold">· {d.bad} set dışı</span>}</span>
                        <span className="tabular-nums text-slate-600 dark:text-slate-300 shrink-0">{d.kg ? tons(d.kg) : 'boş'}{d.pct !== undefined ? ` · %${d.pct}` : ''}</span>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className={`h-full rounded-full ${barCls}`} style={{ width: `${w}%` }} /></div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>}

          {/* 4) Bu hafta */}
          {on('WEEK') && <section className="grid grid-cols-2 gap-2">
            {[['Bu hafta hasat', tons(week.harvest), 'HARVEST_STATUS'], ['Bu hafta sevk', tons(week.ship), 'TRANSIT'], ['Kalite testi', String(p.testCountThisWeek), 'LOTS'], ['Açık akt', String(week.incidents), 'ALERTS']].map(([a, b, v]) => (
              <button key={a} type="button" onClick={() => p.onNavigate(v)} className="text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 cursor-pointer">
                <div className="text-xs text-slate-500 flex items-center justify-between">{a}<ChevronRight className="w-3.5 h-3.5 text-slate-300" /></div>
                <div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div>
              </button>
            ))}
          </section>}
        </div>
      </div>}

      {/* v49c6: Bahçeler */}
      {on('ORCHARDS') && <OrchardsPanel harvestRecords={p.harvestRecords} onOpenOrchard={(n) => (p.onOpenOrchard ? p.onOpenOrchard(n) : p.onNavigate('HARVEST_CALENDAR'))} onOpenCalendar={() => p.onNavigate('HARVEST_CALENDAR')} />}
    </div>
  );
}
