# V63 NOTLAR — menü sadeleştirme · Test merkezi · ana sayfa (zirai hava, yaklaşan hasat) · renk sadeliği (v62 dahil)

Taban: v61 (218). v62 uygulandıysa da uygulanmadıysa da bu paket yeter (v62'nin 4 dosyası içinde, aynı içerik). Sonuç: 220 dosya (2 yeni, 8 değişen). Silinecek yok. Firestore kuralı değişmedi.

## Dosyalar (SHA-256)
d413a21b7c497bb5955b3e534bd2bff0fbc64b0b6212091fd6238888de7c9fa3  src/App.tsx
60df46f022acea1f33330bf3844b9287143b1ffc7ab8b19e2e87c9ae0918a07d  src/components/portal/HomeMenu.tsx
557c5e20e92f29f287fab29607ae41274e5a26fe2f7dc8a958e675ddf7d5a65e  src/components/views/TestHubView.tsx
897003703c4af14820ad988bed74cf4984540ee99372051d7b8db061dbafd333  src/components/dashboard/AgroWeatherCard.tsx
93bd22635c2957044d5236303c690bb4abb7fdaa7d36c9f65398e4e9b8181f47  src/components/dashboard/HomeDashboard.tsx
ca5bcb6e31acd82ef3cf1a2cf8bc689a178a00eaedad127f1ec68da696fa0e77  src/components/dashboard/OrchardsPanel.tsx
3c4b8179a89bbbd2de0f48d42059b67af2eed2ca8c8dffd4567f4866ed26dd0c  src/components/views/ManagementViews.tsx
47194bb648c8d027e2e477f52c4a4bcc59c9ee0c4ae382bdab0e782c4dd93b01  src/components/views/OrchardCardsView.tsx
5e13afbc4b16b118f6894d82b555d374482c75ea1a4bd73f007a4a2ebc58d5de  src/services/locationProfiles.ts
7bff9b9a3e9952d03acf79f2b19d8f47dac45a83cb1caecf1578c6ea8bf36569  src/components/views/Archive2026View.tsx

Yeni: src/components/views/TestHubView.tsx, src/components/dashboard/AgroWeatherCard.tsx

## Ne değişti
- Menü 43 → 26 satır. Tekrarlar kaldırıldı: "Soğan, patates ve diğer" saha testine katıldı; Muz / Badem akışı satırın yanında "akış" düğmesi; Kalite raporu, Aylık PDF, İzlenebilirlik defteri, Partiler ve testler Rapor merkezinde; Bekleyen işlemler Senkron'un yanında; Görsel standartlar Standartlar'ın yanında; Yönetim analizi ve Denetim izi Yönetici masasının yanında; Bugün yapılacaklar, Depolar ve Bahçeler ana sayfada / alt çubukta. Hiçbir ekran silinmedi, yalnız menü satırları birleşti.
- Test merkezi (yeni): yeni test düğmeleri; dönem (hafta / 30 gün / yıl / tümü), Bahçeler / Seralar / İhracat / Freeze-dry, yer ve ürün süzgeci; test, ölçülen meyve, dikkat, 2026 arşivi sayıları; bütün modüllerin son testleri; meyve testine dokununca ayrıntı ve çeşit geçmişi, diğerleri kendi formunda; bahçe seçilince bahçe sayfasına geçiş; arşiv, kalite raporu, partiler, standartlar.
- Yönetici özeti herkese açık (giriş yapan herkes). Yönetici masası yalnız yönetici.
- Ana sayfa: "Zirai hava · 3 gün" kartı (bahçe konumlarından; uyarı yoksa 3 günün sıcaklığı; kışın don uyarısı yok); bahçe kartları ana sayfadan kalktı (Bahçeler sekmesinde), yerine "Yaklaşan hasat · 30 gün" ve "Bahçeler" düğmesi; sezon gidişatı kaldı.
- Renk: menü simgeleri gri, yalnız ana girişler yeşil, akt kırmızı; ana sayfa akış kutuları tek renk (gri).
- Rapor merkezine "İzlenebilirlik defteri" satırı.
- (v62) testlerde meyve ağırlığı/sayısı; seralar Yönetici masasında ve arşivde; Garahan 1200, Kaka birleşmesi.
