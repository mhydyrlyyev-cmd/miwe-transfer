import React, { useMemo, useState } from 'react';
import { ArrowLeft, ChevronDown } from 'lucide-react';
import { ARCHIVE_TESTS_2026, ARCHIVE_SOURCE, type ArchiveTest } from '../../config/archive2026';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { vkey, matchCardVariety, actual2026 } from '../../services/orchardOverview';
import { aktsFor } from '../../services/archive2026';
import { findProfile } from '../../services/locationProfiles';

/**
 * v59 — 2026 arşivi · analiz: bahçe → çeşit: kaç test, kaç hasat testi, ortalama meyve ağırlığı (g), çap, sertlik, Brix,
 * 2026 hasat tonu, ilk–son test. Ağırlık ve ölçüler hasat testlerinden (Ýygym-1, 2…); hasat testi yoksa bütün testlerden.
 */
const isHarvest = (t: ArchiveTest) => /^ýygym-?\d/i.test(t.type.replace(/\s/g, ''));
const avg = (xs: (number | undefined)[]) => { const v = xs.filter((x): x is number => typeof x === 'number' && x > 0); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : undefined; };
const f = (x?: number, d = 1) => (x === undefined ? '—' : x.toLocaleString('tr-TR', { maximumFractionDigits: d }));
const dm = (iso?: string) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}` : '—');
const title = (s: string) => s.trim().replace(/\s+/g, ' ').replace(/(^|\s)\S/g, c => c.toLocaleUpperCase('tr'));

interface Row { place: string; fruit: string; key: string; name: string; tests: ArchiveTest[]; harvest: number; w?: number; dia?: number; hard?: number; brix?: number; first: string; last: string; ton?: number }

export default function Archive2026View({ onBack, onOpenOrchard }: { onBack: () => void; onOpenOrchard?: (name: string) => void }) {
  const [place, setPlace] = useState<string>('ALL');
  const [fruit, setFruit] = useState<string>('ALL');
  const [open, setOpen] = useState<string | null>(null);
  const rows = useMemo(() => {
    const m = new Map<string, Row>();
    for (const t of ARCHIVE_TESTS_2026) {
      const key = matchCardVariety(t.place, t.variety) || vkey(t.variety);
      const id = `${t.place}|${t.fruit}|${key}`;
      const card = ORCHARD_CARDS[t.place]?.varieties.find(v => vkey(v.cesit) === key);
      const r = m.get(id) || { place: t.place, fruit: t.fruit, key, name: card?.cesit || title(t.variety) || '(çeşit yazılmamış)', tests: [], harvest: 0, first: t.d, last: t.d };
      r.tests.push(t); if (isHarvest(t)) r.harvest++;
      if (t.d < r.first) r.first = t.d; if (t.d > r.last) r.last = t.d;
      m.set(id, r);
    }
    for (const r of m.values()) {
      const base = r.harvest ? r.tests.filter(isHarvest) : r.tests;
      r.w = avg(base.map(t => (t.w && t.w >= 2 ? t.w : undefined) as any)); r.dia = avg(base.map(t => t.dia)); r.hard = avg(base.map(t => t.hard)); r.brix = avg(base.map(t => t.brix));
      const a = actual2026(r.place, r.name); r.ton = a.kg ? a.kg / 1000 : undefined;
    }
    return [...m.values()].sort((a, b) => a.place.localeCompare(b.place, 'tr') || a.fruit.localeCompare(b.fruit, 'tr') || b.tests.length - a.tests.length);
  }, []);
  const places = [...new Set(rows.map(r => r.place))];
  const fruits = [...new Set(rows.map(r => r.fruit))];
  const shown = rows.filter(r => (place === 'ALL' || r.place === place) && (fruit === 'ALL' || r.fruit === fruit));
  const byPlace = places.filter(p => shown.some(r => r.place === p)).sort((a, b) => Number(!!findProfile('GREENHOUSE', a)) - Number(!!findProfile('GREENHOUSE', b)));
  const nT = shown.reduce((a, r) => a + r.tests.length, 0), nH = shown.reduce((a, r) => a + r.harvest, 0);
  const chip = (on: boolean) => `shrink-0 px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${on ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`;

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">2026 arşivi · analiz</h1><p className="text-xs text-slate-500">Bahçe → çeşit: test, ağırlık, ölçüler, hasat</p></div>
      </div>
      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5"><button type="button" onClick={() => setPlace('ALL')} className={chip(place === 'ALL')}>Tüm bahçe ve seralar</button>{places.map(p => <button key={p} type="button" onClick={() => setPlace(p)} className={chip(place === p)}>{p}</button>)}</div>
      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5"><button type="button" onClick={() => setFruit('ALL')} className={chip(fruit === 'ALL')}>Tüm ürünler</button>{fruits.map(x => <button key={x} type="button" onClick={() => setFruit(x)} className={chip(fruit === x)}>{x}</button>)}</div>
      <div className="grid grid-cols-3 gap-2">
        {[['Test', String(nT)], ['Hasat testi', String(nH)], ['Çeşit', String(shown.length)]].map(([l, v]) => <div key={l} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-lg font-bold tabular-nums">{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>)}
      </div>
      {byPlace.map((p, i) => {
        const rs = shown.filter(r => r.place === p); const akt = aktsFor(p).length;
        const gh = !!findProfile('GREENHOUSE', p); const prevGh = i > 0 && !!findProfile('GREENHOUSE', byPlace[i - 1]);
        return (<React.Fragment key={p}>
          {(i === 0 || gh !== prevGh) && <h2 className="text-[11px] font-bold text-slate-500 uppercase tracking-wide px-1 pt-1">{gh ? 'Seralar' : 'Bahçeler'}</h2>}
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2.5">
            <div className="flex items-center justify-between gap-2"><button type="button" onClick={() => onOpenOrchard?.(p)} className="text-sm font-bold text-left truncate cursor-pointer">{p}</button>
              <span className="text-[10px] text-slate-500 shrink-0">{rs.reduce((a, r) => a + r.tests.length, 0)} test{akt ? ` · ${akt} akt` : ''}</span></div>
            <div className="grid grid-cols-[34px_44px_36px_36px_36px_minmax(0,1fr)] gap-1 text-[9px] font-semibold text-slate-500 border-b border-slate-100 py-1 mt-1"><span className="text-right">test</span><span className="text-right">g/meyve</span><span className="text-right">çap</span><span className="text-right">sert.</span><span className="text-right">Brix</span><span className="text-right">2026 t</span></div>
            {rs.map(r => { const id = `${r.place}|${r.fruit}|${r.key}`; return (
              <div key={id} className="border-b border-slate-100 dark:border-slate-800 last:border-0">
                <button type="button" onClick={() => setOpen(open === id ? null : id)} className="w-full py-1.5 text-left cursor-pointer">
                  <div className="text-xs break-words"><b>{r.name}</b> <span className="text-slate-500">· {r.fruit} · {r.tests.reduce((a, t) => a + (t.n || 0), 0)} meyve</span></div>
                  <div className="grid grid-cols-[34px_44px_36px_36px_36px_minmax(0,1fr)] gap-1 text-xs tabular-nums items-center">
                  <span className="text-right">{r.tests.length}{r.harvest ? <span className="text-teal-700">/{r.harvest}</span> : ''}</span>
                  <b className="text-right">{f(r.w, r.w && r.w < 20 ? 1 : 0)}</b><span className="text-right">{f(r.dia, 0)}</span><span className="text-right">{f(r.hard)}</span><span className="text-right">{f(r.brix)}</span><span className="text-right">{f(r.ton)}</span>
                  </div>
                </button>
                {open === id && (
                  <div className="pb-2 space-y-0.5">
                    <div className="text-[10px] text-slate-500">İlk test {dm(r.first)} · son test {dm(r.last)} · ölçüler {r.harvest ? 'hasat testlerinden' : 'bütün testlerden'}</div>
                    {[...r.tests].sort((a, b) => a.d.localeCompare(b.d)).map((t, i) => (
                      <div key={i} className={`grid grid-cols-[40px_minmax(0,1fr)_40px_34px_34px_34px] gap-1 text-[11px] tabular-nums ${isHarvest(t) ? 'font-semibold' : 'text-slate-600'}`}>
                        <span>{dm(t.d)}</span><span className="truncate">{t.type}{t.by ? ` · ${t.by}` : ''}</span><span className="text-right">{f(t.w, t.w && t.w < 20 ? 1 : 0)}</span><span className="text-right">{f(t.dia, 0)}</span><span className="text-right">{f(t.hard)}</span><span className="text-right">{f(t.brix)}</span>
                      </div>))}
                  </div>)}
              </div>); })}
          </section></React.Fragment>);
      })}
      {(place === 'ALL' || findProfile('GREENHOUSE', place)) && <p className="text-[11px] text-slate-600 bg-amber-50 dark:bg-amber-950/30 rounded-xl px-3 py-2">Muz seralarının 2026 kalite ölçümleri bu arşivde yok (Google Sheet'te tutuldu); seraların 2026 aktları Yönetim'de. İsterseniz o sayfayı arşive ekleriz.</p>}
      <p className="text-[10px] text-slate-500 px-1">Kaynak: {ARCHIVE_SOURCE}. 2026 ton: hasat fişleri, yoksa Gantt "satylan". "test/hasat" sütunu: toplam test / hasat (Ýygym) testi. <ChevronDown className="inline w-3 h-3" /> çeşide dokunun: tek tek testler.</p>
    </div>
  );
}
