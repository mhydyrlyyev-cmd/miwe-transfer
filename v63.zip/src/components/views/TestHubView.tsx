import React, { useMemo, useState } from 'react';
import { ArrowLeft, FlaskConical, Banana, Nut, Globe2, Wind, ChevronRight } from 'lucide-react';
import type { BademRecord, ExportSampleRecord, FieldRecord, FreezeDryRecord, HarvestRecord, MuzRecord } from '../../types';
import { canonicalOrchard, canonicalName, findProfile } from '../../services/locationProfiles';
import { vkey, matchCardVariety } from '../../services/orchardOverview';
import { archiveTestsFor } from '../../services/archive2026';
import { ARCHIVE_TESTS_2026 } from '../../config/archive2026';
import TestDetailSheet from './TestDetailSheet';

/**
 * v63 — Test merkezi: bütün testler tek yerde.
 * Yeni test düğmeleri · dönem / yer / ürün süzgeci · son testler (meyve, muz, badem, ihracat, freeze-dry) · 2026 arşivi sayısı.
 * Meyve testine dokununca ayrıntı ve çeşit geçmişi (TestDetailSheet); diğerleri kendi formunda açılır.
 */
type Kind = 'FIELD' | 'MUZ' | 'BADEM' | 'EXPORT_SAMPLE' | 'FREEZE_DRY';
type Scope = 'ALL' | 'ORCHARD' | 'GREENHOUSE' | 'EXPORT' | 'FD';
interface Row { id: string; at: number; kind: Kind; place: string; scope: Exclude<Scope, 'ALL'>; product: string; variety: string; type: string; m: string; n: number; bad: boolean; by?: string; rec: unknown }

const ms = (t?: string | number) => { const x = typeof t === 'number' ? t : Date.parse(String(t || '')); return Number.isFinite(x) ? x : 0; };
const f1 = (x?: number, d = 1) => (typeof x === 'number' && Number.isFinite(x) && x > 0 ? x.toLocaleString('tr-TR', { maximumFractionDigits: d }) : '');
const join = (xs: (string | false | undefined)[]) => xs.filter(Boolean).join(' · ');
const isBad = (...xs: (string | undefined)[]) => xs.some(x => !!x && /red|ret|uygun değil|uygunsuz|reject|fail|dikkat|ıskarta/i.test(x));
const KIND_LABEL: Record<Kind, string> = { FIELD: 'Saha', MUZ: 'Muz', BADEM: 'Badem', EXPORT_SAMPLE: 'İhracat', FREEZE_DRY: 'Freeze-dry' };

export default function TestHubView(p: {
  fieldRecords: FieldRecord[]; muzRecords: MuzRecord[]; bademRecords: BademRecord[]; exportSampleRecords: ExportSampleRecord[]; freezeDryRecords: FreezeDryRecord[]; harvestRecords: HarvestRecord[];
  onBack: () => void; onStart: (view: string) => void; onEdit: (kind: Kind, rec: unknown) => void; onOpenOrchard: (name: string) => void; onOpen: (view: string, tab?: string) => void; onOpenStandards: () => void;
}) {
  const [period, setPeriod] = useState<'W' | 'M' | 'Y' | 'ALL'>('Y');
  const [scope, setScope] = useState<Scope>('ALL');
  const [place, setPlace] = useState('ALL');
  const [product, setProduct] = useState('ALL');
  const [limit, setLimit] = useState(30);
  const [openT, setOpenT] = useState<FieldRecord | null>(null);

  const rows = useMemo<Row[]>(() => {
    const out: Row[] = [];
    for (const r of p.fieldRecords) {
      const place0 = canonicalOrchard(r.orchard || r.location || '') || '—';
      const gh = !!findProfile('GREENHOUSE', place0);
      out.push({ id: `F${r.id}`, at: ms(r.timestamp), kind: 'FIELD', place: place0, scope: gh ? 'GREENHOUSE' : 'ORCHARD', product: r.product || 'Ürün yazılmamış', variety: r.sortVariety || '', type: r.testType || 'Saha testi',
        m: join([f1(r.avgHardness) && `sertlik ${f1(r.avgHardness)}`, f1(r.avgBrix) && `Brix ${f1(r.avgBrix)}`, f1(r.avgFruitWeightG, 0) && `${f1(r.avgFruitWeightG, 0)} g`, f1(r.avgDiameter, 0) && `çap ${f1(r.avgDiameter, 0)}`]),
        n: Number(r.sampleCount) || 0, bad: isBad(r.decision, r.testStatus, r.qualityStandardVerdict), by: r.operator, rec: r });
    }
    for (const r of p.muzRecords) {
      out.push({ id: `M${r.id}`, at: ms(r.timestamp), kind: 'MUZ', place: canonicalName('GREENHOUSE', r.greenhouseNo || '') || r.greenhouseNo || 'Muz', scope: 'GREENHOUSE', product: 'Muz', variety: r.ribbonColor ? `kurdele ${r.ribbonColor}` : '', type: 'Muz kalite',
        m: join([f1(r.harvestAgeWeeks, 0) && `${f1(r.harvestAgeWeeks, 0)} hafta`, f1(r.calibrationMm, 0) && `kalibre ${f1(r.calibrationMm, 0)}`, f1(r.fingerLengthCm) && `parmak ${f1(r.fingerLengthCm)} cm`, f1(r.avgBrix) && `Brix ${f1(r.avgBrix)}`]),
        n: 0, bad: isBad(r.decision, r.testStatus, r.qualityStatus), by: r.operator, rec: r });
    }
    for (const r of p.bademRecords) {
      out.push({ id: `B${r.id}`, at: ms(r.timestamp), kind: 'BADEM', place: canonicalOrchard(r.location || '') || '—', scope: 'ORCHARD', product: 'Badem', variety: r.variety || '', type: r.testStage || 'Badem testi',
        m: join([f1(r.hullSplitPercent, 0) && `kabuk %${f1(r.hullSplitPercent, 0)}`, f1(r.kernelMoisturePercent ?? r.moisturePercent) && `nem %${f1(r.kernelMoisturePercent ?? r.moisturePercent)}`, f1(r.kernelYieldPercent) && `iç %${f1(r.kernelYieldPercent)}`]),
        n: Number(r.sampleFruitCount) || 0, bad: isBad(r.testStatus, r.classification), by: r.operator, rec: r });
    }
    for (const r of p.exportSampleRecords) {
      out.push({ id: `E${r.id}`, at: ms(r.testDate || r.timestamp), kind: 'EXPORT_SAMPLE', place: `İhracat${r.destinationCountry ? ` · ${r.destinationCountry}` : ''}`, scope: 'EXPORT', product: r.product || 'Numune', variety: r.variety || '', type: 'Şahit numune',
        m: join([f1(r.transitDays, 0) && `${f1(r.transitDays, 0)}. gün`, f1(r.weightLossPercent) && `fire %${f1(r.weightLossPercent)}`, f1(r.avgHardness) && `sertlik ${f1(r.avgHardness)}`, f1(r.avgBrix) && `Brix ${f1(r.avgBrix)}`]),
        n: Number(r.sampleCount) || 0, bad: isBad(r.shelfLifeDecision), by: r.operator, rec: r });
    }
    for (const r of p.freezeDryRecords) {
      out.push({ id: `D${r.id}`, at: ms(r.processDate || r.timestamp), kind: 'FREEZE_DRY', place: 'Freeze-dry', scope: 'FD', product: r.product || 'Freeze-dry ürünü', variety: r.variety || '', type: r.processStatus || 'Proses',
        m: join([f1(r.rawWeightKg, 0) && `ham ${f1(r.rawWeightKg, 0)} kg`, f1(r.yieldRatioPercent) && `verim %${f1(r.yieldRatioPercent)}`, f1(r.finalMoisturePercent) && `nem %${f1(r.finalMoisturePercent)}`]),
        n: 0, bad: isBad(r.processStatus), by: r.operator, rec: r });
    }
    return out.sort((a, b) => b.at - a.at);
  }, [p.fieldRecords, p.muzRecords, p.bademRecords, p.exportSampleRecords, p.freezeDryRecords]);

  const now = Date.now();
  const from = period === 'W' ? now - 7 * 864e5 : period === 'M' ? now - 30 * 864e5 : period === 'Y' ? new Date(new Date().getFullYear(), 0, 1).getTime() : 0;
  const inPeriod = rows.filter(r => r.at >= from);
  const inScope = inPeriod.filter(r => scope === 'ALL' || r.scope === scope);
  const places = [...new Set(inScope.map(r => r.place))].sort((a, b) => a.localeCompare(b, 'tr'));
  const inPlace = inScope.filter(r => place === 'ALL' || r.place === place);
  const products = [...new Set(inPlace.map(r => r.product))].filter(x => x !== '—').sort((a, b) => a.localeCompare(b, 'tr'));
  const shown = inPlace.filter(r => product === 'ALL' || r.product === product);
  const fruits = shown.reduce((s, r) => s + r.n, 0), bad = shown.filter(r => r.bad).length;
  const arch = ARCHIVE_TESTS_2026.filter(t => (place === 'ALL' || t.place === place) && (product === 'ALL' || (t.fruit || '').toLowerCase() === product.toLowerCase()) && (scope === 'ALL' || scope === 'ORCHARD' || (scope === 'GREENHOUSE' && !!findProfile('GREENHOUSE', t.place))));
  const isPlaceOrchard = place !== 'ALL' && (!!findProfile('ORCHARD', place) || !!findProfile('GREENHOUSE', place));

  const chip = (on: boolean) => `shrink-0 px-2.5 min-h-[32px] rounded-full border text-[11px] cursor-pointer ${on ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'border-slate-300 dark:border-slate-700'}`;
  const dm = (t: number) => (t ? new Date(t).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit' }) : '—');
  const open = (r: Row) => { if (r.kind === 'FIELD') setOpenT(r.rec as FieldRecord); else p.onEdit(r.kind, r.rec); };

  const starts: [string, string, React.ReactNode][] = [
    ['Meyve · sebze', 'FIELD', <FlaskConical className="w-4 h-4" />], ['Muz', 'MUZ', <Banana className="w-4 h-4" />], ['Badem', 'BADEM', <Nut className="w-4 h-4" />],
    ['İhracat numunesi', 'EXPORT_SAMPLE', <Globe2 className="w-4 h-4" />], ['Freeze-dry', 'FREEZE_DRY', <Wind className="w-4 h-4" />],
  ];

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Test merkezi</h1><p className="text-xs text-slate-500">Yeni test · geçmiş · bahçe ve sera · standartlar</p></div>
      </div>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
        <h2 className="text-xs font-semibold text-slate-500 mb-2">Yeni test</h2>
        <div className="grid grid-cols-2 gap-2">{starts.map(([l, v, ic]) => (
          <button key={v} type="button" onClick={() => p.onStart(v)} className="flex items-center gap-2 min-h-[44px] px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-left cursor-pointer hover:border-teal-400"><span className="text-teal-700">{ic}</span>{l}</button>))}
        </div>
      </section>

      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1">{([['W', 'Bu hafta'], ['M', '30 gün'], ['Y', 'Bu yıl'], ['ALL', 'Tümü']] as const).map(([k, l]) => <button key={k} type="button" onClick={() => setPeriod(k)} className={chip(period === k)}>{l}</button>)}</div>
      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1">{([['ALL', 'Hepsi'], ['ORCHARD', 'Bahçeler'], ['GREENHOUSE', 'Seralar'], ['EXPORT', 'İhracat'], ['FD', 'Freeze-dry']] as const).map(([k, l]) => <button key={k} type="button" onClick={() => { setScope(k); setPlace('ALL'); setProduct('ALL'); }} className={chip(scope === k)}>{l}</button>)}</div>
      {places.length > 1 && <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1"><button type="button" onClick={() => { setPlace('ALL'); setProduct('ALL'); }} className={chip(place === 'ALL')}>Tüm yerler</button>{places.map(x => <button key={x} type="button" onClick={() => { setPlace(x); setProduct('ALL'); }} className={chip(place === x)}>{x}</button>)}</div>}
      {products.length > 1 && <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1"><button type="button" onClick={() => setProduct('ALL')} className={chip(product === 'ALL')}>Tüm ürünler</button>{products.map(x => <button key={x} type="button" onClick={() => setProduct(x)} className={chip(product === x)}>{x}</button>)}</div>}

      <div className="grid grid-cols-2 gap-2">
        {([['Test', String(shown.length)], ['Ölçülen meyve', fruits ? fruits.toLocaleString('tr-TR') : '—'], ['Dikkat / uygun değil', String(bad)], ['2026 arşivi', `${arch.length} test`]] as const).map(([l, v]) => (
          <div key={l} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2"><div className={`text-lg font-bold tabular-nums ${l.startsWith('Dikkat') && bad ? 'text-rose-700' : 'text-slate-900 dark:text-white'}`}>{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>))}
      </div>
      {isPlaceOrchard && <button type="button" onClick={() => p.onOpenOrchard(place)} className="w-full flex items-center justify-between min-h-[44px] px-3 rounded-xl border border-teal-300 text-sm font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">{place} · çeşit çeşit testler, takvim, profil<ChevronRight className="w-4 h-4" /></button>}

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
        <h2 className="text-xs font-semibold text-slate-500 py-1">Son testler · teste dokunun</h2>
        {shown.length === 0 ? <p className="text-sm text-slate-500 py-3">Bu süzgeçte test yok. Dönemi "Tümü" yapın veya 2026 arşivine bakın.</p> : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{shown.slice(0, limit).map(r => (
            <li key={r.id}><button type="button" onClick={() => open(r)} className="w-full text-left py-2 cursor-pointer">
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-sm min-w-0 truncate"><b>{r.product}</b>{r.variety ? ` · ${r.variety}` : ''}</span>
                <span className="text-[11px] text-slate-500 tabular-nums shrink-0">{dm(r.at)}</span>
              </div>
              <div className="text-[11px] text-slate-600 dark:text-slate-400 flex flex-wrap gap-x-1.5">
                <span className="font-semibold">{KIND_LABEL[r.kind]}</span><span>· {r.place}</span><span>· {r.type}</span>{r.n ? <span>· {r.n} meyve</span> : null}{r.bad && <span className="text-rose-700 font-semibold">· dikkat</span>}
              </div>
              {r.m && <div className="text-[11px] tabular-nums text-slate-800 dark:text-slate-200">{r.m}</div>}
            </button></li>))}</ul>)}
        {shown.length > limit && <button type="button" onClick={() => setLimit(l => l + 30)} className="w-full min-h-[40px] text-xs font-semibold text-teal-700 cursor-pointer">Daha fazla ({shown.length - limit})</button>}
      </section>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1">
        {([['2026 arşivi · çeşit çeşit analiz', () => p.onOpen('ARCHIVE_2026')], ['Kalite raporu', () => p.onOpen('REPORT_CENTER', 'quality')], ['Partiler ve testler (RefID)', () => p.onOpen('LOTS')], ['Standartlar (OECD · UNECE · iç hedef)', p.onOpenStandards]] as [string, () => void][]).map(([l, fn]) => (
          <button key={l} type="button" onClick={fn} className="w-full flex items-center justify-between min-h-[44px] text-sm border-b last:border-0 border-slate-100 dark:border-slate-800 cursor-pointer">{l}<ChevronRight className="w-4 h-4 text-slate-400" /></button>))}
      </section>

      {openT && (() => {
        const o = canonicalOrchard(openT.orchard || openT.location || '');
        const key = matchCardVariety(o, openT.sortVariety || '') || vkey(openT.sortVariety);
        const same = p.fieldRecords.filter(r => canonicalOrchard(r.orchard || r.location || '') === o && (vkey(r.sortVariety) === key || matchCardVariety(o, r.sortVariety || '') === key));
        const harv = p.harvestRecords.filter(h => canonicalOrchard(h.orchard) === o && (vkey(h.variety) === key || matchCardVariety(o, h.variety || '') === key));
        return <TestDetailSheet r={openT} sameVariety={same} arch={archiveTestsFor(o, key)} harvests={harv} onClose={() => setOpenT(null)} onEdit={() => { const x = openT; setOpenT(null); p.onEdit('FIELD', x); }} />;
      })()}
    </div>
  );
}
