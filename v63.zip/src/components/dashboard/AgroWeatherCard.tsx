import React from 'react';
import { CloudSun, ChevronRight } from 'lucide-react';
import { useLocationProfiles } from '../../services/locationProfiles';
import { useOrchardWeather, agroAlerts } from '../../services/weather';

/**
 * v63 — Ana sayfa › Zirai hava (3 gün): bahçe ve seraların konumundan Open-Meteo tahmini, services/weather eşikleri.
 * Aynı gün + aynı uyarı tek satır. Kış dinlenmesinde (Kas–Şub) don uyarısı gösterilmez (İklim sayfasıyla aynı kural).
 * Uyarı yoksa üç günün en düşük / en yüksek sıcaklığı.
 */
export default function AgroWeatherCard({ onOpen }: { onOpen: () => void }) {
  const orchards = useLocationProfiles('ORCHARD');
  const points = orchards.map(o => ({ name: o.name, lat: Number(o.fields?.lat) || undefined, lon: Number(o.fields?.lon) || undefined })).filter(p => p.lat !== undefined && p.lon !== undefined);
  const { data } = useOrchardWeather(points);
  const have = points.filter(p => data[p.name]?.length);
  if (!points.length) return null;
  const mon = new Date().getMonth() + 1;
  const dormant = mon >= 11 || mon <= 2;
  const raw = have.flatMap(p => agroAlerts(p.name, data[p.name], 3)).filter(a => !(dormant && a.kind === 'FROST'));
  const g = new Map<string, { a: typeof raw[number]; names: string[] }>();
  for (const a of raw) { const k = `${a.date}|${a.kind}`; const x = g.get(k) || { a, names: [] }; x.names.push(a.orchard); g.set(k, x); }
  const alerts = [...g.values()].sort((x, y) => x.a.date.localeCompare(y.a.date));
  const days = [0, 1, 2].map(i => {
    const ds = have.map(p => data[p.name][i]).filter(Boolean);
    if (!ds.length) return null;
    return { date: ds[0].date, lo: Math.min(...ds.map(d => d.tMin)), hi: Math.max(...ds.map(d => d.tMax)), rain: Math.max(...ds.map(d => d.rain)) };
  }).filter((x): x is { date: string; lo: number; hi: number; rain: number } => !!x);
  const wd = (iso: string) => new Date(`${iso}T00:00:00`).toLocaleDateString('tr-TR', { weekday: 'short' });
  const worst = alerts.some(x => x.a.level === 'critical') ? 'bad' : alerts.length ? 'warn' : 'ok';
  const cls = worst === 'bad' ? 'border-rose-200 bg-rose-50 dark:bg-rose-950/30' : worst === 'warn' ? 'border-amber-200 bg-amber-50 dark:bg-amber-950/30' : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900';
  return (
    <button type="button" onClick={onOpen} className={`w-full text-left rounded-2xl border px-4 py-3 cursor-pointer ${cls}`}>
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><CloudSun className="w-4 h-4 text-teal-700" />Zirai hava · 3 gün</h2>
        <span className="text-xs font-semibold text-teal-700 inline-flex items-center">İklim<ChevronRight className="w-3.5 h-3.5" /></span>
      </div>
      {!have.length ? <p className="text-[11px] text-slate-500 mt-1">Hava bilgisi yükleniyor…</p> : (<>
        <div className="grid grid-cols-3 gap-1.5 mt-2">{days.map(d => (
          <div key={d.date} className="rounded-lg bg-white/70 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800 px-2 py-1 text-center">
            <div className="text-[10px] text-slate-500 capitalize">{wd(d.date)}</div>
            <div className="text-xs font-semibold tabular-nums text-slate-900 dark:text-white">{Math.round(d.lo)}…{Math.round(d.hi)} °C</div>
            {d.rain >= 1 && <div className="text-[10px] text-slate-600 tabular-nums">{Math.round(d.rain)} mm</div>}
          </div>))}
        </div>
        {alerts.length === 0
          ? <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1.5">3 gün içinde bahçelerde zirai risk yok.</p>
          : <ul className="mt-1.5 space-y-0.5">{alerts.slice(0, 4).map((x, i) => (
              <li key={i} className={`text-[11px] ${x.a.level === 'critical' ? 'text-rose-800 dark:text-rose-300' : 'text-amber-900 dark:text-amber-300'}`}><b>{x.names.length === have.length && have.length > 2 ? 'Tüm bahçeler' : x.names.join(', ')}</b> · {x.a.text}</li>))}</ul>}
        {dormant && <p className="text-[10px] text-slate-500 mt-1">Kış dinlenmesi: don uyarısı gösterilmez.</p>}
      </>)}
    </button>
  );
}
