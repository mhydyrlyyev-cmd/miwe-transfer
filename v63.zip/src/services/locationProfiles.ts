/**
 * v3.4 — Yer Profilleri (Madde 5, 9, 11)
 *
 * Bahçe, depo, oda, ön soğutma yeri ve varış noktası için TEK kayıt defteri.
 * - Adı kullanıcı yazar ("Merkez / Bahçe" sabit değil); aynı yerin farklı yazımları alias ile birleşir.
 * - Alanlar isteğe bağlıdır (zorunlu değil) ve yönetici yeni alan ekleyebilir.
 * - Sistem kayıtlarda geçen ama profili olmayan yeni adları algılar → "profil oluştur" önerir.
 *   Operasyon (hasat, kabul, sevk formu) sırasında form AÇILMAZ; profil ayrı ekranda doldurulur.
 * Kalıcılık: localStorage önbelleği + Firestore 'locationProfiles' koleksiyonu (en iyi çaba).
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import { PROFILE_SEED } from '../config/profileSeed';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../types';

export type LocationKind = 'ORCHARD' | 'GREENHOUSE' | 'FIELD' | 'PRECOOL' | 'WAREHOUSE' | 'ROOM' | 'DESTINATION' | 'DEVICE';

export const LOCATION_KIND_LABEL: Record<LocationKind, string> = {
  ORCHARD: 'Bahçe',
  GREENHOUSE: 'Sera',
  FIELD: 'Tarla',
  DEVICE: 'Cihaz',
  PRECOOL: 'Ön soğutma yeri',
  WAREHOUSE: 'Depo',
  ROOM: 'Oda',
  DESTINATION: 'Varış / alıcı',
};

export interface ProfileFieldDef {
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'boolean';
  unit?: string;
  options?: string[];
}

/** Varsayılan (isteğe bağlı) alanlar — yönetici ekleyebilir */
export const DEFAULT_FIELDS: Record<LocationKind, ProfileFieldDef[]> = {
  ORCHARD: [
    { key: 'areaHa', label: 'Alan', type: 'number', unit: 'ha' },
    { key: 'treeCount', label: 'Ağaç sayısı', type: 'number' },
    { key: 'products', label: 'Ürünler / çeşitler', type: 'text' },
    { key: 'region', label: 'Bölge / etrap', type: 'text' },
    { key: 'company', label: 'Firma', type: 'text' },
    { key: 'sections', label: 'Bölümler / parseller', type: 'text' },
    { key: 'lat', label: 'Enlem', type: 'number' },
    { key: 'lon', label: 'Boylam', type: 'number' },
    { key: 'plan2027Ton', label: '2027 plan', type: 'number', unit: 't' },
    { key: 'actual2026Ton', label: '2026 gerçekleşen', type: 'number', unit: 't' },
    { key: 'rootstock', label: 'Anaç', type: 'text' },
    { key: 'plantYears', label: 'Dikim yılı', type: 'text' },
    { key: 'agronomist', label: 'Sorumlu agronom', type: 'text' },
    { key: 'ownPrecool', label: 'Kendi ön soğutması var', type: 'boolean' },
    { key: 'distanceKm', label: 'Merkeze uzaklık', type: 'number', unit: 'km' },
    { key: 'bloomDate', label: 'Çiçeklenme tarihi (GG.AA, ör. 25.03)', type: 'text' },
    { key: 'gddBaseC', label: 'Gün-derece taban sıcaklığı (boşsa 10)', type: 'number', unit: '°C' },
    { key: 'harvestGdd', label: 'Hasat için gün-derece hedefi', type: 'number' },
    { key: 'ownership', label: 'Sahiplik', type: 'select', options: ['Kendi', 'C proje (dış bahçe)'] },
    { key: 'contact', label: 'Sorumlu / iletişim', type: 'text' },
  ],
  DEVICE: [
    { key: 'deviceType', label: 'Cihaz türü', type: 'select', options: ['Termometre (problu)', 'Refraktometre (Brix)', 'Penetrometre (sertlik)', 'Terazi / kantar', 'Datalogger', 'Gaz ölçer (O₂ / CO₂)', 'Nem ölçer (RH)'] },
    { key: 'serial', label: 'Seri no', type: 'text' },
    { key: 'location', label: 'Bulunduğu yer', type: 'text' },
    { key: 'lastCheck', label: 'Son kontrol (YYYY-AA-GG)', type: 'text' },
    { key: 'lastResult', label: 'Sonuç (Geçti / Kaldı + okunan değer)', type: 'text' },
    { key: 'intervalDays', label: 'Kontrol aralığı (boşsa kural)', type: 'number', unit: 'gün' },
    { key: 'certificateUntil', label: 'Sertifika geçerlilik (YYYY-AA-GG)', type: 'text' },
    { key: 'responsible', label: 'Sorumlu', type: 'text' },
  ],
  GREENHOUSE: [
    { key: 'crop', label: 'Ürün', type: 'text' },
    { key: 'areaHa', label: 'Alan', type: 'number', unit: 'ha' },
    { key: 'company', label: 'Firma / bölüm', type: 'text' },
    { key: 'plan2027Ton', label: '2027 plan', type: 'number', unit: 't' },
    { key: 'lat', label: 'Enlem', type: 'number' },
    { key: 'lon', label: 'Boylam', type: 'number' },
  ],
  FIELD: [
    { key: 'region', label: 'Bölge', type: 'text' },
    { key: 'areaHa', label: 'Toplam alan', type: 'number', unit: 'ha' },
    { key: 'crops', label: 'Ekinler ve alanları', type: 'text' },
    { key: 'lat', label: 'Enlem', type: 'number' },
    { key: 'lon', label: 'Boylam', type: 'number' },
    { key: 'ownership', label: 'Sahiplik', type: 'select', options: ['Kendi', 'C proje (dış bahçe)'] },
    { key: 'contact', label: 'Sorumlu / iletişim', type: 'text' },
  ],
  PRECOOL: [
    { key: 'kind', label: 'Tip', type: 'select', options: ['Tünel (hava basınçlı)', 'Hidro-cooling', 'Oda içi', 'Diğer'] },
    { key: 'capacityKg', label: 'Kapasite', type: 'number', unit: 'kg/parti' },
    { key: 'parent', label: 'Bağlı olduğu yer (bahçe / depo)', type: 'text' },
  ],
  WAREHOUSE: [
    { key: 'shortName', label: 'Kısa ad (oda adlarının başında)', type: 'text' },
    { key: 'address', label: 'Konum', type: 'text' },
    { key: 'roomCount', label: 'Oda sayısı', type: 'number' },
    { key: 'responsible', label: 'Sorumlu', type: 'text' },
    { key: 'lat', label: 'Enlem', type: 'number' },
    { key: 'lon', label: 'Boylam', type: 'number' },
  ],
  ROOM: [
    { key: 'warehouse', label: 'Depo (depo profilinin adı)', type: 'text' },
    { key: 'building', label: 'Bina', type: 'text' },
    { key: 'code', label: 'Oda kodu (kayıtta yazılan)', type: 'text' },
    { key: 'roomType', label: 'Oda tipi', type: 'select', options: ['Soğuk depo', 'Ön soğutma', 'Kontrollü atmosfer', 'Sarartma', 'Donuk depo', 'Satışa hazır', 'İşleme alanı'] },
    { key: 'setMinC', label: 'Set alt sınır', type: 'number', unit: '°C' },
    { key: 'setMaxC', label: 'Set üst sınır', type: 'number', unit: '°C' },
    { key: 'volumeM3', label: 'Hacim', type: 'number', unit: 'm³' },
    { key: 'capacityPallets', label: 'Kapasite', type: 'number', unit: 'palet' },
    { key: 'capacityKg', label: 'Kapasite', type: 'number', unit: 'kg' },
    { key: 'use', label: 'Kullanım', type: 'select', options: ['Meyve', 'Sebze', 'Karışık'] },
    { key: 'atmosphere', label: 'Atmosfer', type: 'select', options: ['Normal', 'CA (kontrollü)', 'ULO'] },
    { key: 'ventilation', label: 'Havalandırma var', type: 'boolean' },
    { key: 'setpointC', label: 'Varsayılan set', type: 'number', unit: '°C' },
    { key: 'rhPercent', label: 'Hedef nem', type: 'number', unit: 'RH%' },
  ],
  DESTINATION: [
    { key: 'market', label: 'Pazar', type: 'select', options: ['İç pazar', 'İhracat', 'Numune', 'Sanayi'] },
    { key: 'country', label: 'Ülke / şehir', type: 'text' },
    { key: 'transitDays', label: 'Ortalama yol süresi', type: 'number', unit: 'gün' },
  ],
};

export interface LocationProfile {
  id: string;
  kind: LocationKind;
  name: string;
  aliases?: string[];
  fields: Record<string, string | number | boolean>;
  /** Yönetici notu / dikkat edilecekler */
  note?: string;
  createdAt: string;
  updatedAt?: string;
  updatedBy?: string;
}

interface Store { profiles: LocationProfile[]; extraFields: Partial<Record<LocationKind, ProfileFieldDef[]>> }

const LS_KEY = 'miwe_location_profiles_v1';
const norm = (s: string) => s.trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');

let store: Store = (() => {
  try { const raw = localStorage.getItem(LS_KEY); if (raw) return JSON.parse(raw) as Store; } catch { /* yoksay */ }
  return { profiles: [], extraFields: {} };
})();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS_KEY, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };

let remoteLoaded = false;
/** v49a: tohum profilleri — yalnız aynı ad/diğer ad ile profil YOKSA eklenir (sabit id: aynı belge, çift kayıt olmaz) */
let seeded = false;
async function seedMissing(writeRemote: boolean) {
  if (seeded) return; seeded = true;
  try {
    const { PROFILE_SEED } = await import('../config/profileSeed');
    const now = new Date().toISOString();
    const add: LocationProfile[] = [];
    const patched: LocationProfile[] = [];
    for (const sp of PROFILE_SEED) {
      if (store.profiles.some(p => p.id === sp.id)) continue;
      const existing = [sp.name, ...sp.aliases].map(n => findProfile(sp.kind, n)).find(Boolean) as LocationProfile | undefined;
      if (existing) {
        // v49b: var olan profile yalnız BOŞ alanları ve eksik diğer adları ekle (kullanıcının girdiği değer değişmez)
        const fields = { ...existing.fields };
        let changed = false;
        for (const [k, v] of Object.entries(sp.fields)) { if (fields[k] === undefined || fields[k] === '') { fields[k] = v; changed = true; } }
        const aliases = [...(existing.aliases || [])];
        for (const n of [sp.name, ...sp.aliases]) { if (n !== existing.name && !aliases.includes(n)) { aliases.push(n); changed = true; } }
        if (changed) patched.push({ ...existing, fields, aliases, updatedAt: now, updatedBy: 'Tohum verisi (v49b)' });
        continue;
      }
      add.push({ ...sp, createdAt: now, updatedAt: now, updatedBy: 'Tohum verisi (v49a)' } as LocationProfile);
    }
    if (!add.length && !patched.length) return;
    const pm = new Map(patched.map(p => [p.id, p]));
    store = { ...store, profiles: [...store.profiles.map(p => pm.get(p.id) || p), ...add] };
    emit();
    if (writeRemote) for (const p of [...add, ...patched]) { try { await saveRecordToFirestore('LOCATION_PROFILE', p); } catch { /* yerel kalır */ } }
  } catch { /* yoksay */ }
}

async function loadRemoteOnce() {
  if (remoteLoaded) return; remoteLoaded = true;
  try {
    const snap = await getDocs(collection(db, 'locationProfiles'));
    const remote: LocationProfile[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v && v.kind && v.name) remote.push({ ...v, id: d.id }); });
    if (remote.length) {
      const map = new Map(store.profiles.map(p => [p.id, p]));
      for (const r of remote) {
        const l = map.get(r.id);
        if (!l || (r.updatedAt || r.createdAt) > (l.updatedAt || l.createdAt)) map.set(r.id, r);
      }
      store = { ...store, profiles: [...map.values()] };
      emit();
    }
    await seedMissing(true);
  } catch { await seedMissing(false); /* çevrimdışı veya izin yok: yerel önbellek kullanılır */ }
}

/** v49a: bahçe adını profil adına çevirir (diğer adlar dahil; yoksa yazıldığı gibi) */
export function canonicalOrchard(raw?: string): string {
  const name = (raw || '').trim();
  if (!name) return '';
  const par = parentProfile('ORCHARD', name); if (par) return par.name;
  for (const k of ['ORCHARD', 'GREENHOUSE', 'FIELD'] as LocationKind[]) { const f = findProfile(k, name); if (f) return f.name; }
  return name;
}

/**
 * v60 — "Garahan 1200, Kaka" / "Garahan 1200 ha (Hurma)" gibi yazımlar ayrı bahçe değil: adı başka bir bahçenin adı/diğer adıyla
 * başlayıp ardından virgül, parantez, • · / ; geliyorsa o bahçedir. (Boşlukla devam eden ad birleşmez: "Saýwan Gursak" ≠ "Saýwan".)
 */
export function parentProfile(kind: LocationKind, rawName?: string): LocationProfile | undefined {
  const n = norm(rawName || '');
  if (!n) return undefined;
  let best: LocationProfile | undefined, bestLen = 0;
  // tohum profilleri de aday (canlı veride tohum profili yeniden adlandırılmış / diğer adları eksik olabilir)
  const cands = [...store.profiles, ...(PROFILE_SEED as unknown as LocationProfile[]).filter(sp => !store.profiles.some(x => x.id === sp.id))];
  for (const p of cands) {
    if (p.kind !== kind || norm(p.name) === n) continue;
    const names = [p.name, ...(p.aliases || [])].map(norm);
    // "Garahan 1200 ha" → "garahan 1200" de sayılır (kayıtlarda "ha" çoğu zaman yazılmaz)
    for (const an of [...new Set([...names, ...names.map(x => x.replace(/\s+ha$/, ''))])]) {
      if (an.length > bestLen && n.length > an.length && n.startsWith(an) && /^\s*[,•·(/;|]/.test(n.slice(an.length))) { best = p; bestLen = an.length; }
    }
  }
  return best;
}

export function getProfiles(kind?: LocationKind): LocationProfile[] {
  return store.profiles
    .filter(p => !kind || p.kind === kind)
    .filter(p => !(p.kind === 'ORCHARD' || p.kind === 'GREENHOUSE' || p.kind === 'FIELD') || !parentProfile(p.kind, p.name))
    .sort((a, b) => a.name.localeCompare(b.name, 'tr'));
}
export function fieldsFor(kind: LocationKind): ProfileFieldDef[] {
  return [...DEFAULT_FIELDS[kind], ...(store.extraFields[kind] || [])];
}
export function addCustomField(kind: LocationKind, def: ProfileFieldDef) {
  const cur = store.extraFields[kind] || [];
  if (cur.some(f => f.key === def.key) || DEFAULT_FIELDS[kind].some(f => f.key === def.key)) return;
  store = { ...store, extraFields: { ...store.extraFields, [kind]: [...cur, def] } };
  emit();
}

/** Aynı yerin farklı yazımlarını tek profile bağlar ("G-1 depo" = "g-1  Depo") */
export function findProfile(kind: LocationKind, rawName?: string): LocationProfile | undefined {
  if (!rawName) return undefined;
  const n = norm(rawName);
  return store.profiles.find(p => p.kind === kind && (norm(p.name) === n || (p.aliases || []).some(a => norm(a) === n)));
}
export function canonicalName(kind: LocationKind, rawName?: string): string {
  return findProfile(kind, rawName)?.name || (rawName || '').trim();
}

export async function upsertProfile(p: Omit<LocationProfile, 'id' | 'createdAt'> & { id?: string; createdAt?: string }): Promise<LocationProfile> {
  const now = new Date().toISOString();
  const id = p.id || `${p.kind.toLowerCase()}-${norm(p.name).replace(/[^a-z0-9çğıöşü]+/gi, '-').slice(0, 40)}-${Date.now().toString(36)}`;
  const full: LocationProfile = { ...p, id, createdAt: p.createdAt || now, updatedAt: now } as LocationProfile;
  const exists = store.profiles.some(x => x.id === id);
  store = { ...store, profiles: exists ? store.profiles.map(x => (x.id === id ? full : x)) : [...store.profiles, full] };
  emit();
  try { await saveRecordToFirestore('LOCATION_PROFILE', full); } catch { /* yerel kalır */ }
  return full;
}

export function useLocationProfiles(kind?: LocationKind): LocationProfile[] {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force(x => x + 1);
    listeners.add(l);
    loadRemoteOnce();
    return () => { listeners.delete(l); };
  }, []);
  return getProfiles(kind);
}

/** Form seçenekleri (datalist): profil adları önce, sonra kayıtlarda geçen adlar */
export function useLocationOptions(): { orchards: string[]; warehouses: string[]; rooms: string[]; precool: string[]; destinations: string[] } {
  const all = useLocationProfiles();
  const by = (k: LocationKind) => all.filter(p => p.kind === k).map(p => p.name);
  return { orchards: by('ORCHARD'), warehouses: by('WAREHOUSE'), rooms: by('ROOM'), precool: by('PRECOOL'), destinations: by('DESTINATION') };
}

export interface DetectedLocation { kind: LocationKind; name: string; uses: number }

/** Kayıtlarda geçen ama profili olmayan yerler (en çok kullanılan önce) */
export function detectNewLocations(src: {
  references: ReferenceItem[]; harvestRecords: HarvestRecord[]; ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[]; salesRecords: SalesRecord[];
}): DetectedLocation[] {
  const counts = new Map<string, DetectedLocation>();
  const add = (kind: LocationKind, raw?: string) => {
    const name = (raw || '').trim();
    if (!name || name === '—' || findProfile(kind, name) || parentProfile(kind, name)) return;
    const k = `${kind}|${norm(name)}`;
    const cur = counts.get(k) || { kind, name, uses: 0 };
    cur.uses++; counts.set(k, cur);
  };
  src.harvestRecords.forEach(h => add('ORCHARD', h.orchard));
  src.references.forEach(r => add('ORCHARD', r.orchard));
  src.references.forEach(r => (r.precoolingSlips || []).forEach(s => { add('PRECOOL', s.tunnel); add('WAREHOUSE', s.targetWarehouse); add('ROOM', s.targetRoom); }));
  src.ambarRecords.forEach(a => { add('WAREHOUSE', a.warehouse); add('ROOM', a.roomNo); (a.roomMovements || []).forEach(m => { add('WAREHOUSE', m.toWarehouse); add('ROOM', m.toRoom); }); });
  src.lojistikRecords.forEach(l => add('DESTINATION', l.destination));
  src.salesRecords.forEach(s => add('DESTINATION', s.destination || s.customer));
  return [...counts.values()].sort((a, b) => b.uses - a.uses);
}
