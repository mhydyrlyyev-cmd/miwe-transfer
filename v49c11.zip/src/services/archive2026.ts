/**
 * v49c11 — 2026 arşivi yardımcıları: çeşide göre testler, akt konuları (tekrarlanan durumlar).
 */
import { ARCHIVE_AKTS_2026, ARCHIVE_TESTS_2026, type ArchiveAkt, type ArchiveTest } from '../config/archive2026';
import { matchCardVariety, vkey } from './orchardOverview';

/** Bu bahçe + çeşidin 2026 test olayları (firma ekli adlar da bağlanır: "MAKAKO" → Makako) */
export function archiveTestsFor(orchard: string, key: string): ArchiveTest[] {
  return ARCHIVE_TESTS_2026.filter(t => t.place === orchard && (vkey(t.variety) === key || matchCardVariety(orchard, t.variety) === key));
}
/** 2026'da bu çeşidin ilk hasat öncesi testi */
export function firstTest2026(orchard: string, key: string): string | undefined {
  return archiveTestsFor(orchard, key).filter(t => !/^ýygym-\d/i.test(t.type.replace(/\s/g, ''))).map(t => t.d).sort()[0];
}

/** Akt konusu: kısa açıklama + akt adı anahtar kelimelerinden (Türkmençe) */
const THEMES: [string, RegExp][] = [
  ['Kemirgen zararı', /gemiri|gemırı/i],
  ['Zamanında sevk edilmeyen / dışarıda kalan meyve', /ugradylmadyk|daşda galan|salynman|sygman|soklamadan/i],
  ['Sıcaklık, enerji, ekipman', /temperat|gradus|tok öç|gazy kes|guratma|fan\)|ýiti|yiti|mcp|kemçilik/i],
  ['Taşıma ve ambalaj', /tentli|ulag|ýaşşik|yaşşik|döwük|gapysy/i],
  ['Sınıflama ve olgunluk', /sort|mix|hil ýagdaý|tayar önüm|taýýar önüm|standart|eksport|exportl|sary gelen|ýetişmedik|bişip|saraltma|saral|garalma|çapyk|sorty üýt/i],
  ['Bozulma, küf, nem', /heňleme|zaýa|zaya|çüýre|çyglylyk|suw akar|zaýalanma|uzak saklama/i],
  ['Zararlı (kurt)', /gurçyk|gurcuk/i],
  ['Hijyen ve hasat uygulaması', /sanitar|arassa|örtgü|düşürmek|ýerleşdirmek/i],
  ['Belge, bilgi ve iş disiplini', /delilnama|ýazylmady|habarsyz|gijä|ýetişmezlik|barlag/i],
  ['Ön soğutma', /precool|howuz/i],
];
export function aktTheme(a: ArchiveAkt): string {
  const s = `${a.summary} ${a.name}`.normalize('NFC');
  for (const [t, re] of THEMES) if (re.test(s)) return t;
  return 'Konu yazılmamış (genel akt adı)';
}
export interface AktThemeRow { theme: string; count: number; places: [string, number][]; akts: ArchiveAkt[] }
export function aktThemes(list: ArchiveAkt[] = ARCHIVE_AKTS_2026): AktThemeRow[] {
  const by = new Map<string, ArchiveAkt[]>();
  for (const a of list) { const t = aktTheme(a); by.set(t, [...(by.get(t) || []), a]); }
  return [...by.entries()].map(([theme, akts]) => {
    const pc = new Map<string, number>();
    for (const a of akts) pc.set(a.place, (pc.get(a.place) || 0) + 1);
    return { theme, count: akts.length, places: [...pc.entries()].sort((x, y) => y[1] - x[1]), akts: akts.sort((x, y) => String(y.d).localeCompare(String(x.d))) };
  }).sort((a, b) => b.count - a.count);
}
export const aktsFor = (place: string) => ARCHIVE_AKTS_2026.filter(a => a.place === place);

/** Akt listesi kutusu için kısa tarih */
export const aktDate = (a: ArchiveAkt) => (a.d ? a.d.slice(8, 10) + '.' + a.d.slice(5, 7) : '—');
