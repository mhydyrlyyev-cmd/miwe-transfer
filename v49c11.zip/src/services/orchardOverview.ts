/**
 * v49c6 — Bahçeler özeti (Ana sayfa) ve çeşit eşleştirme.
 *  · Sezon: Kasım'dan itibaren (son 10 günde hasat kaydı yoksa) ya da tüm çeşitler bittiyse bir sonraki yıl (Kasım 2026 → 2027).
 *  · 2026 gerçekleşen: Bahçe kartı olan bahçede hasat fişleri (URETIM 2026); fişi olmayan çeşitte Gantt "satylan" tonu.
 *    Diğer bahçelerde Gantt "satylan" tonu.
 *  · Plan: sezon 2027 → tonaj Excel'i (v2_1911); 2026 → rewiz / plan.
 */
import { useMemo } from 'react';
import type { HarvestRecord } from '../types';
import { buildCalendar, useCalOverrides, type CalItem } from './harvestCalendar';
import { CAL_SEED_ROWS } from '../config/harvestCalendarSeed';
import { ORCHARD_CARDS } from '../config/orchardCards';

const ALIAS: Record<string, string> = { laurenne: 'lauranne', gartairo: 'gartario', gallaval: 'galavall', galavall: 'galavall', goldenrainders: 'goldenreinders' };
/** çeşit anahtarı: harf/rakam dışı atılır, bilinen yazım farkları birleştirilir; parantez içi atılır */
export const vkey = (s?: string) => {
  const k = String(s || '').split('(')[0].toLocaleLowerCase('tr').replace(/ý/g, 'y').replace(/ı/g, 'i').replace(/[^a-z0-9]/g, '');
  return ALIAS[k] || k;
};
const DONE_RE = /tamam/i;

/** Takvim (Gantt) çeşit adını Bahçe profili çeşidine bağlar: "Makako E.D.", "Makako M.U" → Makako; "Vairo TAE" → Vairo.
 *  Önce tam eşleşme, sonra en uzun ön ek (en az 4 harf). Eşleşmezse null. */
export function matchCardVariety(orchard: string, variety: string): string | null {
  const card = ORCHARD_CARDS[orchard];
  if (!card) return null;
  const k = vkey(variety);
  let best: string | null = null;
  for (const v of card.varieties) {
    const ck = vkey(v.cesit);
    if (ck === k) return ck;
    if (ck.length >= 4 && k.startsWith(ck) && (!best || ck.length > best.length)) best = ck;
  }
  return best;
}

/** 2026 gerçekleşen kg ve kaynağı */
export function actual2026(orchard: string, variety: string): { kg: number; src: 'fiş' | 'Gantt' | null; first?: string | null; last?: string | null } {
  const card = ORCHARD_CARDS[orchard];
  const k = vkey(variety);
  const v = card?.varieties.find(x => vkey(x.cesit) === k);
  if (v && v.actual2026Kg > 0) return { kg: v.actual2026Kg, src: 'fiş', first: v.first2026, last: v.last2026 };
  // Gantt: aynı çeşidin firmalara bölünmüş satırları ("Makako E.D." + "Makako M.U") toplanır
  const gs = CAL_SEED_ROWS.filter(r => r.orchard === orchard && DONE_RE.test(r.status || '') && (r.soldTon || 0) > 0 && (vkey(r.variety) === k || (card && matchCardVariety(orchard, r.variety) === k)));
  if (gs.length) {
    const st = gs.map(r => r.start2026).filter(Boolean).sort() as string[], en = gs.map(r => r.end2026).filter(Boolean).sort() as string[];
    return { kg: Math.round(gs.reduce((a, r) => a + (r.soldTon || 0), 0) * 1000), src: 'Gantt', first: st[0] || null, last: en[en.length - 1] || null };
  }
  return { kg: 0, src: null };
}

/** takvim satırı (2026 Gantt) — çiçeklenme / hasat tarihleri için */
export const calSeedFor = (orchard: string, variety: string) => CAL_SEED_ROWS.find(r => r.orchard === orchard && vkey(r.variety) === vkey(variety));

const FRUIT_ORDER = ['Kiraz', 'Erik', 'Şeftali', 'Nektarin', 'Elma', 'Armut', 'Nashi', 'Hurma', 'Badem'];

export interface OrchardSummary {
  orchard: string; plan: number; done: number; ref2026: number;
  varieties: number; bloomEntered: number; bloomNeeded: number;
  next?: { variety: string; at: number }; hasCard: boolean;
}
export interface FruitSummary { fruit: string; plan: number; done: number; ref2026: number }

export function useOrchardOverview(harvestRecords: HarvestRecord[]) {
  const ovs = useCalOverrides();
  return useMemo(() => {
    const now = Date.now();
    const y = new Date().getFullYear();
    const cur = buildCalendar(y, ovs, harvestRecords, now);
    // Kasım'dan itibaren hasadı süren çeşit yoksa (ya da hepsi bittiyse) bir sonraki sezon gösterilir
    const recent = harvestRecords.some(h => { const t = Date.parse(String(h.recordDate || h.timestamp || '')); return Number.isFinite(t) && now - t < 10 * 86400000 && String(h.recordDate || h.timestamp).startsWith(String(y)); });
    // v49c11: 15 Kasım'dan sonra her durumda yeni sezon (deneme / geç kayıtlar sezonu geri çekmesin)
    const nd = new Date(); const lateNov = nd.getMonth() === 11 || (nd.getMonth() === 10 && nd.getDate() >= 15);
    const season = cur.length && (lateNov || (!recent && (nd.getMonth() >= 10 || cur.every(i => i.status === 'DONE')))) ? y + 1 : y;
    const items: CalItem[] = season === y ? cur : buildCalendar(season, ovs, harvestRecords, now);
    const orchards = new Map<string, OrchardSummary>();
    const fruits = new Map<string, FruitSummary>();
    const seen = new Set<string>();
    const fr = (f: string) => (/alma|elma/i.test(f) ? 'Elma' : /şet|seft|şeft/i.test(f) ? 'Şeftali' : /çer|cer|kiraz/i.test(f) ? 'Kiraz' : f);
    const getO = (n: string) => { const o = orchards.get(n) || { orchard: n, plan: 0, done: 0, ref2026: 0, varieties: 0, bloomEntered: 0, bloomNeeded: 0, hasCard: !!ORCHARD_CARDS[n] }; orchards.set(n, o); return o; };
    const getF = (n: string) => { const f = fruits.get(fr(n)) || { fruit: fr(n), plan: 0, done: 0, ref2026: 0 }; fruits.set(fr(n), f); return f; };
    for (const it of items) {
      if (!it.orchard || /ýyladyş|yyladys/i.test(it.orchard)) continue;
      const card = ORCHARD_CARDS[it.orchard];
      const k = `${it.orchard}|${vkey(it.variety)}`;
      const dup = seen.has(k); seen.add(k);
      const done = (it.doneTon || 0) * 1000;
      const o = getO(it.orchard); const f = getF(it.fruit);
      o.done += done; f.done += done;
      if (!dup) o.varieties++;
      if (season > 2026 && !dup) { o.bloomNeeded++; if (it.bbch65) o.bloomEntered++; }
      if (it.status !== 'DONE' && it.windowStart && it.windowStart >= now - 86400000 && (!o.next || it.windowStart < o.next.at)) o.next = { variety: it.variety.split('(')[0].trim(), at: it.windowStart };
      // Bahçe profili verisi (kart) olan bahçede plan ve 2026 kart üzerinden toplanır (aşağıda); diğerlerinde takvim satırından
      if (card && season > 2026) {
        if (!dup && !matchCardVariety(it.orchard, it.variety)) { const r = actual2026(it.orchard, it.variety).kg; o.ref2026 += r; f.ref2026 += r; }
        continue;
      }
      const plan = (it.targetTon || 0) * 1000;
      const ref = season <= 2026 ? 0 : actual2026(it.orchard, it.variety).kg;
      o.plan += plan; o.ref2026 += ref; f.plan += plan; f.ref2026 += ref;
    }
    if (season > 2026) for (const [name, card] of Object.entries(ORCHARD_CARDS)) {
      const o = getO(name);
      for (const v of card.varieties) { const f = getF(v.tur); const r = actual2026(name, v.cesit).kg; o.plan += v.plan2027Kg; o.ref2026 += r; f.plan += v.plan2027Kg; f.ref2026 += r; }
    }
    const orchList = [...orchards.values()].filter(o => o.plan > 0 || o.ref2026 > 0).sort((a, b) => b.plan - a.plan);
    const fruitList = [...fruits.values()].filter(f => f.plan > 0 || f.ref2026 > 0).sort((a, b) => FRUIT_ORDER.indexOf(a.fruit) - FRUIT_ORDER.indexOf(b.fruit));
    return { season, orchards: orchList, fruits: fruitList };
  }, [ovs, harvestRecords]);
}
