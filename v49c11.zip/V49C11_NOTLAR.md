# v49c11 — 2026 testleri ve aktları (arşiv) · tekrarlanan durumlar · masaüstü tekrarları temizlendi (v49c10 dahil)

v49c10 (bahçe yapılacakları, Depo/Bahçe ayrımı, seyreltme, meyve sayımı) bu pakette; ayrıca uygulanmaz.
Yeni:
1. 2026 arşivi (YENİ config/archive2026.ts, services/archive2026.ts) — Aktlar_List tablosundan, salt okunur, platform kayıtlarına karışmaz:
   - 1.927 meyve ölçümü → 300 test olayı (tarih + yer + çeşit + test türü; ortalama sertlik, brix, nişasta, çap, ağırlık; bademde kabuk açma % ve iç nem %).
     Bahçe profili › çeşit › Hasat rasatları altında "2026 arşivi · n test · ilk test hasattan x gün önce".
     Yılı 2027/2028 yazılmış 25 satır 2026'ya düzeltildi.
   - 83 akt. Yönetim analizi › Kritik noktalar › "2026 aktları · konuya göre": tekrarlanan konular (sınıflama/olgunluk 17, sıcaklık/enerji/ekipman 11,
     zamanında sevk edilmeyen 10, taşıma/ambalaj 10, bozulma/küf 8, kemirgen 5 …), dokununca o konunun aktları. Bahçe ve sera profillerinde o yerin 2026 aktları.
2. Hasat öncesi test hatırlatması: çiçeklenme girilmediyse 2026'daki ilk testin tarihi (bu yıla taşınmış) ya da pencere −14 gün, hangisi önceyse.
3. Sezon: 15 Kasım'dan sonra Ana sayfa › Bahçeler ve bahçe işleri 2027 sezonunu gösterir (deneme / geç kayıtlar 2026'ya geri çekmez).
4. Masaüstü tekrarları:
   - Üst çubuk "Bugün Yapılacaklar" (eski açılır liste) → doğrudan Bugün yapılacaklar sayfası; mobil menüdeki de.
   - "Yönetim" düğmesi → Yönetici masası; mor "Yönetici Paneli" → "Kullanıcılar" (aynı pencereyi iki düğme açmıyor).
   - Yan menü: Ana panel · Bugün yapılacaklar · Partiler · Bahçe profili · Uyarılar … Rapor merkezi (yeni) · Tüm menü; yönetici: Yönetici masası, Denetim izi, Kullanıcılar.
     "Bekleyen işlemler" ve "Referanslar" yan menüden çıktı (Bugün yapılacaklar ve Partiler içinde).
5. Yönetici masası › Veri sağlığı: "Aynı e-postayla birden çok kullanıcı" (ör. Oraz Berdiýew 2) — fazlası Kullanıcılar ekranından silinir.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (12 dosya)
c14e90a029fde3126923ba1f7f498b82edcd5410bcdc79287aa94de350f96350  src/App.tsx
bf155bb97b3b26c3e7e76aee425ce7b7a25074375a2dc8040913c3e818046c26  src/config/archive2026.ts
1e56366f96884aca975dcce61a4b29784ca83d1fcb36dd1e90a5e7a41cc88118  src/services/archive2026.ts
88a9f6f8c4fe701590d2e794c4476a092629a3c6c24c7ad8cf1da928dbf1b86d  src/services/orchardTasks.ts
1b13229f710968895cf59baae7edc6af5cef09f8ad1331b777c18466ed3f235e  src/services/orchardOverview.ts
c3e3221f6867d2ed41586c6014a3ff428d55218a40148754d9aa7913b3d10705  src/services/harvestCalendar.ts
6fa9be95208c9fb92bc6ba887a508bd7b476573fe784a0b80a7311bba8daac0d  src/components/Header.tsx
200f91101e1c0aeaef88653325e393dac8115831fb961a705e58a8bf8cdc6996  src/components/common/AppSidebar.tsx
0d7e18170480d838d3795653d389c3881b12a3eb7d7b4748a2f02b90ed8547f8  src/components/dashboard/HomeDashboard.tsx
6960e45329eb1e4a444abc2a1b96a8d298b61784e9946c33839df107597a67dc  src/components/views/TodayView.tsx
23d79b09b648b1ca8227c2887f536a8e173c03fe2d189f31ea8a730ce7fe380c  src/components/views/OrchardCardsView.tsx
c0096e4efb57eb1c76bcb44a7f0950a43142417be8db35c68c47b65423f544eb  src/components/views/ManagementViews.tsx
