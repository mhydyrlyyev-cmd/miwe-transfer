/**
 * v49c2 — Bir partinin (RefID) bütün testleri ve hareketleri tek listede.
 * Testler PDF değil, düzenlenebilir satırlar: her satır kaydın kendisine (modül + kayıt) bağlı.
 * Hasat öncesi testler: hasat kaydının linkedTestRefId'si ve referansın linkedTestRefIds'i.
 */
import type {
  AmbarRecord, BademRecord, ExportSampleRecord, FieldRecord, FreezeDryRecord, HarvestRecord,
  LojistikRecord, MuzRecord, ReferenceItem, SalesRecord,
} from '../types';

export type Verdict = 'ok' | 'warn' | 'bad' | 'none';
export type TestStage = 'PRE' | 'HARVEST' | 'PRECOOL' | 'SORT' | 'INTAKE' | 'STORAGE' | 'SHIP' | 'LAB';

export const STAGE_LABEL: Record<TestStage, string> = {
  PRE: 'Hasat öncesi', HARVEST: 'Hasat günü', PRECOOL: 'Ön soğutma', SORT: 'Sortlama / paketleme',
  INTAKE: 'Depo kabul', STORAGE: 'Depo kontrol', SHIP: 'Sevk / numune', LAB: 'İşleme',
};
export const STAGE_ORDER: TestStage[] = ['PRE', 'HARVEST', 'PRECOOL', 'SORT', 'INTAKE', 'STORAGE', 'SHIP', 'LAB'];

export interface LotTest {
  key: string;
  stage: TestStage;
  date: string;
  title: string;
  summary: string;
  verdict: Verdict;
  verdictLabel: string;
  by?: string;
  /** düzenleme için: modül ve kayıt (yoksa yalnız görüntülenir) */
  moduleKey?: string;
  record?: unknown;
}

export interface LotEvent { date: string; title: string; detail: string }

export interface LotData {
  ref: ReferenceItem;
  tests: LotTest[];
  events: LotEvent[];
  currentKg: number;
  place: string;
  daysInStage?: number;
}

export interface LotSources {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  fieldRecords: FieldRecord[];
  muzRecords: MuzRecord[];
  bademRecords: BademRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  exportSampleRecords: ExportSampleRecord[];
  freezeDryRecords: FreezeDryRecord[];
}

const n = (v: unknown) => (v === undefined || v === null || v === '' ? undefined : Number(v));
const f1 = (v?: number) => (v === undefined || Number.isNaN(v) ? '—' : v.toLocaleString('tr-TR', { maximumFractionDigits: 1 }));
const kg = (v?: number) => (v === undefined ? '—' : `${Math.round(v).toLocaleString('tr-TR')} kg`);
const day = (iso?: string) => (iso || '').slice(0, 10);
const join = (...xs: (string | false | undefined)[]) => xs.filter(Boolean).join(' · ');

function fieldVerdict(r: FieldRecord): [Verdict, string] {
  if (r.qualityStandardVerdict === 'FAIL' || r.nitratePass === false) return ['bad', 'Uygun değil'];
  if (r.qualityStandardVerdict === 'CONDITIONAL' || r.hueAngleVerdict === 'WARNING') return ['warn', 'Dikkat'];
  if (r.qualityStandardVerdict === 'PASS' || r.testStatus === 'COMPLETED') return ['ok', 'Uygun'];
  return ['none', 'Sürüyor'];
}

export function buildLot(refId: string, s: LotSources): LotData | null {
  const ref = s.references.find(r => r.refId === refId);
  if (!ref) return null;
  const tests: LotTest[] = [];
  const harvests = s.harvestRecords.filter(h => h.refId === refId);

  // Hasat öncesi testler (bağlı olanlar + aynı RefID'li saha testi)
  const linked = new Set<string>([...(ref.linkedTestRefIds || []), ...harvests.flatMap(h => [h.linkedTestRefId, ...(h.linkedTestRefIds || [])]).filter(Boolean) as string[]]);
  for (const r of s.fieldRecords.filter(x => x.refId === refId || linked.has(x.refId))) {
    const [v, l] = fieldVerdict(r);
    const pre = /önce|hasat öncesi|olgunluk/i.test(r.testType || '') || r.refId !== refId;
    tests.push({
      key: `field-${r.id}`, stage: pre ? 'PRE' : 'HARVEST', date: r.timestamp, by: r.operator,
      title: `${r.testType || 'Saha testi'}${r.refId !== refId ? ` · ${r.refId}` : ''}`,
      summary: join(r.avgHardness ? `sertlik ${f1(r.avgHardness)}` : '', r.avgBrix ? `Brix ${f1(r.avgBrix)}` : '', r.starchIndex ? `nişasta ${r.starchIndex}` : '',
        r.streifIndex ? `Streif ${r.streifIndex.toLocaleString('tr-TR', { maximumFractionDigits: 3 })}` : '', r.avgDiameter ? `çap ${f1(r.avgDiameter)} mm` : '',
        r.hasNitrateTest ? `nitrat ${r.nitratePass ? 'uygun' : 'aşım'}` : ''),
      verdict: v, verdictLabel: l, moduleKey: 'FIELD', record: r,
    });
  }
  for (const r of s.muzRecords.filter(x => x.refId === refId || linked.has(x.refId))) {
    const has = Number(r.calibrationMm) > 0 && Number(r.fingerLengthCm) > 0;
    const bad = r.qualityStatus === 'Sanayi / Fire';
    tests.push({
      key: `muz-${r.id}`, stage: r.refId !== refId ? 'PRE' : 'HARVEST', date: r.timestamp, by: r.operator,
      title: `Muz testi${r.ribbonColor ? ` · ${r.ribbonColor}` : ''}`,
      summary: join(has ? `kalibre ${f1(r.calibrationMm)} mm` : 'kalibre girilmedi', has ? `parmak ${f1(r.fingerLengthCm)} cm` : '',
        r.avgBrix ? `Brix ${f1(r.avgBrix)}` : '', r.ripenessScale ? `renk ${r.ripenessScale}` : '', r.pulpTemperatureC ? `iç ${f1(r.pulpTemperatureC)} °C` : ''),
      verdict: !has ? 'none' : bad ? 'bad' : 'ok', verdictLabel: !has ? 'Veri eksik' : r.kaliteSinifi || r.qualityStatus || 'Uygun', moduleKey: 'MUZ', record: r,
    });
  }
  for (const r of s.bademRecords.filter(x => x.refId === refId || linked.has(x.refId))) {
    const base = Number(r.sampleGram) > 0;
    const bad = r.aflatoxinTest === 'Pozitif (>4 ppb)';
    tests.push({
      key: `badem-${r.id}`, stage: /hasat|açılma/i.test(r.testStage || '') ? 'PRE' : 'LAB', date: r.timestamp, by: r.operator,
      title: `Badem · ${r.testStage || 'kalite testi'}`,
      summary: join(r.kernelYieldPercent ? `randıman %${f1(r.kernelYieldPercent)}` : '', base ? `kusur %${f1(r.totalDefectPercent)}` : '',
        r.kernelMoisturePercent ? `nem %${f1(r.kernelMoisturePercent)}` : r.moisturePercent ? `nem %${f1(r.moisturePercent)}` : '',
        r.hullSplitPercent ? `açılma %${f1(r.hullSplitPercent)}` : '', r.aflatoxinTest ? `aflatoksin ${r.aflatoxinTest.split(' ')[0].toLocaleLowerCase('tr')}` : ''),
      verdict: bad ? 'bad' : r.aflatoxinTest === 'İnceleniyor' ? 'warn' : 'ok', verdictLabel: bad ? 'Uygun değil' : r.classification || 'Uygun', moduleKey: 'BADEM', record: r,
    });
  }
  // Hasat günü
  for (const h of harvests) {
    tests.push({
      key: `harv-${h.id}`, stage: 'HARVEST', date: h.recordDate || h.timestamp, by: h.operator,
      title: 'Hasat kaydı', summary: join(kg(n(h.dailyTotalKg)), h.workerCount ? `${h.workerCount} işçi` : '', h.orchard, h.parcel || h.sector),
      verdict: 'ok', verdictLabel: 'Kayıtlı', moduleKey: 'HARVEST', record: h,
    });
  }
  // Ön soğutma ve sortlama fişleri
  (ref.precoolingSlips || []).forEach((p: any, i: number) => {
    const sorting = p.inspectionMode === 'SORTING' || p.packedKg || p.culledKg;
    const cull = n(p.culledKg), packed = n(p.packedKg), net = n(p.netKg);
    const cullPct = cull !== undefined && net ? (cull / net) * 100 : undefined;
    tests.push({
      key: `slip-${i}`, stage: sorting ? 'SORT' : 'PRECOOL', date: p.date || p.startAt || '',
      title: sorting ? 'Sortlama fişi' : 'Ön soğutma fişi',
      summary: join(net !== undefined ? `net ${kg(net)}` : '', packed !== undefined ? `paketlenen ${kg(packed)}` : '', cull !== undefined ? `ıskarta ${kg(cull)}${cullPct !== undefined ? ` (%${f1(cullPct)})` : ''}` : '',
        n(p.pulpAfterC) !== undefined ? `çıkış ${f1(n(p.pulpAfterC))} °C` : ''),
      verdict: cullPct !== undefined && cullPct > 10 ? 'warn' : 'ok', verdictLabel: cullPct !== undefined && cullPct > 10 ? 'Iskarta yüksek' : 'Kayıtlı',
    });
  });
  // Depo kabul + depo kontrolleri
  for (const a of s.ambarRecords.filter(x => x.refId === refId)) {
    const diff = n(a.weightDiffPercent);
    const t = n(a.productTemperature);
    const v: Verdict = a.acceptanceStatus === 'REJECTED' ? 'bad' : (diff !== undefined && Math.abs(diff) > 2) || a.coldChainStatus !== 'Uygun' ? 'warn' : 'ok';
    tests.push({
      key: `ambar-${a.id}`, stage: 'INTAKE', date: a.acceptanceDate || a.timestamp, by: a.operator,
      title: 'Depo kabul', summary: join(`${a.warehouse || '—'} · ${a.roomNo || '—'}`, kg(n(a.acceptedWeightKg)), t !== undefined ? `ürün ${f1(t)} °C` : '', diff !== undefined ? `fark %${f1(diff)}` : ''),
      verdict: v, verdictLabel: v === 'bad' ? 'Red' : v === 'warn' ? 'Dikkat' : 'Kabul', moduleKey: 'AMBAR', record: a,
    });
    for (const c of a.storageChecks || []) {
      const rot = n(c.rotPercent);
      tests.push({
        key: `chk-${c.id}`, stage: 'STORAGE', date: c.at, by: c.inspector, title: 'Depo kontrolü',
        summary: join(c.roomTemperatureC !== undefined ? `oda ${f1(c.roomTemperatureC)} °C` : '', c.pulpTemperatureC !== undefined ? `meyve ${f1(c.pulpTemperatureC)} °C` : '',
          c.firmness !== undefined ? `sertlik ${f1(c.firmness)}` : '', c.brix !== undefined ? `Brix ${f1(c.brix)}` : '', rot !== undefined ? `çürük %${f1(rot)}` : ''),
        verdict: rot !== undefined && rot > 2 ? 'warn' : 'ok', verdictLabel: rot !== undefined && rot > 2 ? 'Çürük var' : 'Kayıtlı',
      });
    }
  }
  // İhracat / şahit numune
  for (const e of s.exportSampleRecords.filter(x => x.refId === refId || (x as any).sourceRefId === refId)) {
    const bad = e.shelfLifeDecision === 'HIGH_RISK', warn = e.shelfLifeDecision === 'CONDITIONAL';
    tests.push({
      key: `exp-${e.id}`, stage: 'SHIP', date: e.testDate || e.timestamp, by: e.operator, title: 'İhracat / şahit numune',
      summary: join(e.destinationCountry, e.weightLossPercent ? `kayıp %${f1(e.weightLossPercent)}` : '', e.avgHardness ? `sertlik ${f1(e.avgHardness)}` : '', e.avgBrix ? `Brix ${f1(e.avgBrix)}` : ''),
      verdict: bad ? 'bad' : warn ? 'warn' : 'ok', verdictLabel: bad ? 'Yüksek risk' : warn ? 'Şartlı' : 'Uygun', moduleKey: 'EXPORT_SAMPLE', record: e,
    });
  }
  for (const d of s.freezeDryRecords.filter(x => x.refId === refId)) {
    tests.push({
      key: `fd-${d.id}`, stage: 'LAB', date: d.processDate || d.timestamp, by: d.operator, title: 'Freeze-dry',
      summary: join(d.rawWeightKg ? `giriş ${kg(d.rawWeightKg)}` : '', d.finalDryWeightKg ? `çıkış ${f1(d.finalDryWeightKg)} kg` : '', d.yieldRatioPercent ? `randıman %${f1(d.yieldRatioPercent)}` : '', d.finalMoisturePercent ? `nem %${f1(d.finalMoisturePercent)}` : ''),
      verdict: d.finalMoisturePercent > 3 ? 'warn' : 'ok', verdictLabel: d.finalMoisturePercent > 3 ? 'Nem yüksek' : 'Uygun', moduleKey: 'FREEZE_DRY', record: d,
    });
  }
  tests.sort((a, b) => STAGE_ORDER.indexOf(a.stage) - STAGE_ORDER.indexOf(b.stage) || day(a.date).localeCompare(day(b.date)));

  // Zaman çizelgesi
  const events: LotEvent[] = [];
  for (const h of harvests) events.push({ date: h.recordDate || h.timestamp, title: 'Hasat', detail: join(h.orchard, kg(n(h.dailyTotalKg)), h.operator) });
  (ref.precoolingSlips || []).forEach((p: any) => events.push({ date: p.date || p.startAt || '', title: p.packedKg || p.culledKg ? 'Sortlama' : 'Ön soğutma', detail: join(p.tunnel, p.netKg ? kg(n(p.netKg)) : '') }));
  for (const a of s.ambarRecords.filter(x => x.refId === refId)) {
    events.push({ date: a.acceptanceDate || a.timestamp, title: 'Depoya girdi', detail: join(a.warehouse, a.roomNo, kg(n(a.acceptedWeightKg)), a.operator) });
    for (const m of a.roomMovements || []) events.push({ date: m.at, title: 'Oda değişti', detail: join(`${m.fromRoom || '—'} → ${m.toRoom}`, m.by) });
  }
  for (const l of s.lojistikRecords.filter(x => x.refId === refId)) events.push({ date: l.shipmentDate, title: 'Sevk', detail: join((l as any).destination, kg(n(l.weightKg)), (l as any).vehiclePlate) });
  for (const x of s.salesRecords.filter(r => r.refId === refId)) events.push({ date: x.salesDate, title: 'Satış', detail: join((x as any).customer, kg(n(x.totalQuantityKg))) });
  if (!events.length && ref.createdAt) events.push({ date: ref.createdAt, title: 'Kayıt açıldı', detail: join(ref.orchard || ref.location, ref.quantity ? kg(Number(ref.quantity)) : '') });
  events.sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  const lastAmbar = s.ambarRecords.filter(x => x.refId === refId).sort((a, b) => (b.acceptanceDate || '').localeCompare(a.acceptanceDate || ''))[0];
  const out = s.lojistikRecords.filter(x => x.refId === refId).reduce((t, l) => t + (Number(l.weightKg) || 0), 0)
    + s.salesRecords.filter(x => x.refId === refId).reduce((t, l) => t + (Number(l.totalQuantityKg) || 0), 0);
  const inKg = lastAmbar ? Number(lastAmbar.acceptedWeightKg) || 0 : Number(ref.quantity) || 0;
  const place = lastAmbar ? `${lastAmbar.warehouse || '—'} · ${lastAmbar.roomNo || '—'}` : ref.orchard || ref.location || '—';
  const since = lastAmbar?.acceptanceDate || harvests[0]?.recordDate || ref.createdAt;
  const daysInStage = since ? Math.max(0, Math.round((Date.now() - new Date(since).getTime()) / 86400000)) : undefined;
  return { ref, tests, events, currentKg: Math.max(0, inKg - out), place, daysInStage };
}

/** Test ekle: partinin ürününe ve aşamasına uygun test türleri (önerilen önce) */
export interface TestKind { moduleKey: string; label: string; hint: string; stages: string[]; products?: RegExp }
export const TEST_KINDS: TestKind[] = [
  { moduleKey: 'FIELD', label: 'Saha / olgunluk testi', hint: 'Sertlik, Brix, nişasta, çap, renk, nitrat', stages: ['SAHADA'] },
  { moduleKey: 'MUZ', label: 'Muz testi', hint: 'Kalibre, parmak boyu, Brix, renk', stages: ['SAHADA'], products: /muz|banan/i },
  { moduleKey: 'BADEM', label: 'Badem testi', hint: 'Açılma, nem, randıman, kusur gramajı', stages: ['SAHADA', 'DEPODA'], products: /badem|almond/i },
  { moduleKey: 'AMBAR', label: 'Depo kabul', hint: 'Kantar, ürün sıcaklığı, numune kutuları', stages: ['SAHADA', 'YOLDA'] },
  { moduleKey: 'EXPORT_SAMPLE', label: 'İhracat / şahit numune', hint: 'Çıkış ve dönüş ölçümleri, raf ömrü', stages: ['DEPODA', 'YOLDA'] },
  { moduleKey: 'FREEZE_DRY', label: 'Freeze-dry', hint: 'Şoklama, kurutma, randıman', stages: ['DEPODA', 'SAHADA'] },
  { moduleKey: 'INCIDENT', label: 'Akt / olay', hint: 'Uygunsuzluk, fire, şikâyet', stages: ['SAHADA', 'DEPODA', 'YOLDA'] },
];
