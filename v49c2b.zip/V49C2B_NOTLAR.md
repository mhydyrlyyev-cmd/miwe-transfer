# v49c2b — küçük düzeltmeler (25.11 ekranlarından)

1. Günlük hasat › bağlı test: tek seçim yerine liste; birden çok test işaretlenir (linkedTestRefIds). Ürün / bahçe değişince
   uymayan test düşer (muz partisine elma testi kalmaz). İlk seçilen test yalnız boş alanları doldurur.
2. Parti sayfası: bağlı testlerin hepsi listede; hareketi olmayan partide "Kayıt açıldı" satırı; "()" gibi boş parantezler gizlendi.
3. Partiler: ⋯ menüsü ekranın dışına taşmıyor.
4. Parti sayfası ve Bugün yapılacaklar: yukarı ok düğmesi alt düğmelerin üstüne binmiyor.
5. Oda kontrol turu: set aralığı kısaltıldı (0…1°); −40/40 °C dışı sıcaklık ve %0–100 dışı nem kaydedilmez
   (ör. 7,9 yerine 79 yazılması yakalanır).

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (6 dosya)
26a900bbdda78485cdfe8f4865c67aa57786cd9fff325c8a21ce663e91136e8d  src/App.tsx
021afe40b3d6c9d7de08f2d56c907fc8bcd5471e9a88198926ee30148d3fc5f0  src/components/forms/DailyHarvestForm.tsx
f61bb770f25232b9e871804fff1ed76cfe74f2af3a764e7190475eaf6d57778e  src/components/views/LotsView.tsx
a4627c3d25eef292a996579ed7eb44e8f97cc4af9115619ca54da72a506c6fb3  src/components/views/RoomCheckTour.tsx
3c8614e4eb6fda22fcfc3ea090a05a7127c427839c829e3e7e8f46424357f0a9  src/services/lotTests.ts
cc42ac441b2a3ab926040b842aa69963eef2d9d5f534d9a9818b36d6f2fccde7  src/types.ts
