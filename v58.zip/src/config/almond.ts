/**
 * v56 — Badem sezon kuralları. Kaynak: kullanıcı defteri 25.11.26 (No. 58) ve 27.11.26 açıklaması.
 *  Hasat öncesi: ağaçta kabuk açılma %70–75 → uyarı (su kesme / hasat günü planla), %75–85 → doğru hasat, %85 üstü → geç (ağaçta fire).
 *  Hasat: meyve nemi (RH) en az %10.
 *  İşleme (MZ = Mindal zawody, Borell makinesi: hull → in-shell, serme): nem %8–9.
 *  Kurutma → depo: nem ≈ %6, en az %4.
 *  Sonra: kabuklu depo; sipariş varsa iç (kernel) haline getirme.
 */
export const ALMOND = {
  hullWarn: 70, hullStart: 75, hullMax: 85,
  harvestMoistMin: 10,
  processMin: 8, processMax: 9,
  dryTarget: 6, dryMin: 4,
};

/** MZ = Mindal zawody (badem işleme tesisi): Borell makinesiyle yeşil kabuktan (hull) kabuklu (in-shell) hale getirme ve geçici stok.
 *  Alanlar: defter 25.11.26 + 27.11.26 açıklaması. */
export const ALMOND_SITES = [
  { name: 'MZ · Borell ile kabuktan ayırma / serme', m2: 238 },
  { name: 'MZ · geçici kabuklu stok (in-shell)', m2: 354 },
  { name: 'Soğuk depo', m2: 452 },
];

/** Sezon adımları (defterdeki sıra) */
export const ALMOND_STEPS = [
  { k: 'tree', l: 'Ağaç durumu', d: 'kabuk açılma %, çanak durumu' },
  { k: 'water', l: 'Su kesme günü', d: 'açılma %70–75 olunca planla' },
  { k: 'harvest', l: 'Hasat günü', d: 'açılma %75–85 · meyve nemi ≥ %10' },
  { k: 'combine', l: 'Hasat · kombayn', d: 'parsel parsel, MZ\'ye teslim' },
  { k: 'process', l: 'MZ · Borell · kabuktan ayırma / serme', d: 'nem %8–9' },
  { k: 'dry', l: 'Kurutma', d: 'nem ≈ %6, en az %4' },
  { k: 'store', l: 'Kabuklu depo', d: 'MZ depo / soğuk depo' },
  { k: 'kernel', l: 'İç (kernel)', d: 'sipariş varsa kırma' },
] as const;

export type HullVerdict = 'erken' | 'yaklaşıyor' | 'hasat' | 'geç';
export function hullVerdict(h?: number): HullVerdict | undefined {
  if (h === undefined || h === null || Number.isNaN(h)) return undefined;
  if (h < ALMOND.hullWarn) return 'erken';
  if (h < ALMOND.hullStart) return 'yaklaşıyor';
  if (h <= ALMOND.hullMax) return 'hasat';
  return 'geç';
}
export const HULL_TEXT: Record<HullVerdict, string> = {
  erken: 'Erken · bekle',
  yaklaşıyor: 'Yaklaşıyor · su kesme ve hasat gününü planla',
  hasat: 'Hasat zamanı',
  geç: 'Geç · ağaçta fire artıyor',
};

export type MoistVerdict = 'yaş' | 'işleme' | 'kurutmada' | 'depo' | 'aşırı kuru';
export function moistVerdict(m?: number): MoistVerdict | undefined {
  if (m === undefined || m === null || Number.isNaN(m)) return undefined;
  if (m > ALMOND.processMax) return 'yaş';
  if (m >= ALMOND.processMin) return 'işleme';
  if (m > ALMOND.dryTarget) return 'kurutmada';
  if (m >= ALMOND.dryMin) return 'depo';
  return 'aşırı kuru';
}
export const MOIST_TEXT: Record<MoistVerdict, string> = {
  yaş: 'Yaş · kurumakta',
  işleme: 'MZ işlemeye uygun (%8–9)',
  kurutmada: 'Kurutmada · hedef ≈ %6',
  depo: 'Depoya hazır (%4–6)',
  'aşırı kuru': 'Aşırı kuru (< %4)',
};
