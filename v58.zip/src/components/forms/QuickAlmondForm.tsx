import React, { useState } from 'react';
import type { ActiveFieldContext, BademRecord, ReferenceItem } from '../../types';
import { generateRefId, calculateAlmondYield, evaluateAlmondGrade } from '../../utils/calculations';
import { getCurrentUser } from '../../utils/authService';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { ALMOND, hullVerdict, HULL_TEXT, moistVerdict, MOIST_TEXT } from '../../config/almond';
import { QHeader, Chips, NumTile, CalcRow, ResultBar, SEC, INP, num, fmt } from './QuickParts';

/**
 * v54 — Badem testi (görsel 32): Hasat öncesi · Kurutma · Laboratuvar.
 * v56 sınırlar config/almond.ts (defter 25.11.26): açılma %70–75 uyarı, %75–85 hasat, %85+ geç · meyve nemi ≥ %10 ·
 * MZ işleme %8–9 · kurutma ≈ %6 (en az %4). Laboratuvar sınıfı: calculations.evaluateAlmondGrade.
 * Kayıt eski formla aynı BademRecord.
 */
type Stage = 'PRE' | 'DRY' | 'LAB';
const STAGES: { k: Stage; l: string; t: BademRecord['testStage'] }[] = [
  { k: 'PRE', l: 'Hasat öncesi', t: 'Hasat Öncesi / Hasat Testi' },
  { k: 'DRY', l: 'İşleme · kurutma', t: 'Yerde Kurutma Aşaması' },
  { k: 'LAB', l: 'Laboratuvar', t: 'Laboratuvar Randıman & Kalite' },
];
const DEFS = [
  ['whole', 'Sağlam'], ['double', 'Çift'], ['broken', 'Kırık'], ['gum', 'Gam'], ['insect', 'Kurt'], ['serious', 'Küf / çürük'], ['undersize', 'Büzüşük'], ['foreign', 'Yabancı'], ['dust', 'Toz'],
] as const;
type DefK = typeof DEFS[number][0];

interface Props {
  onSave: (record: BademRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  ctx?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

export default function QuickAlmondForm(p: Props) {
  const [stage, setStage] = useState<Stage>('PRE');
  const [loc, setLoc] = useState(p.ctx?.orchard || '');
  const [variety, setVariety] = useState(p.ctx?.variety || '');
  const [hull, setHull] = useState(''); const [fruitM, setFruitM] = useState(''); const [cut, setCut] = useState('');
  const [hDate, setHDate] = useState(''); const [cond, setCond] = useState(''); const [treeLoss, setTreeLoss] = useState('');
  const [dryDay, setDryDay] = useState(''); const [kernM, setKernM] = useState('');
  const [sample, setSample] = useState(''); const [kernel, setKernel] = useState(''); const [moist, setMoist] = useState(''); const [calib, setCalib] = useState(''); const [load, setLoad] = useState('');
  const [def, setDef] = useState<Record<DefK, string>>({ whole: '', double: '', broken: '', gum: '', insect: '', serious: '', undersize: '', foreign: '', dust: '' });
  const [afla, setAfla] = useState<'' | BademRecord['aflatoxinTest']>('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const almondOrchards = Object.entries(ORCHARD_CARDS).filter(([, c]) => c.varieties.some(v => /badem/i.test(v.tur))).map(([n]) => n);
  const vars = ORCHARD_CARDS[loc]?.varieties.filter(v => /badem/i.test(v.tur)).map(v => v.cesit) || [];

  const H = num(hull), FM = num(fruitM), KM = num(kernM), S = num(sample), K = num(kernel), M = num(moist);
  const hv = hullVerdict(H);
  const fmOk = FM === undefined ? undefined : FM >= ALMOND.harvestMoistMin;
  const ready = hv ? (hv === 'hasat' && fmOk !== false ? 'Hasata Uygun' : hv === 'geç' ? 'Geç' : 'Erken / Beklemeli') : undefined;
  const mv = moistVerdict(KM);
  const dryOk = mv === undefined ? undefined : mv === 'depo';
  const g = (k: DefK) => num(def[k]) || 0;
  const defSum = g('double') + g('broken') + g('gum') + g('insect') + g('serious') + g('undersize') + g('foreign') + g('dust');
  const base = S && S > 0 ? S : g('whole') + defSum;
  const seriousPct = base ? ((g('serious') + g('insect')) / base) * 100 : 0;
  const totalPct = base ? (defSum / base) * 100 : 0;
  const yieldPct = S && K ? calculateAlmondYield(S, K) : undefined;
  const grade = M !== undefined && base ? evaluateAlmondGrade({ seriousDefectPercent: seriousPct, totalDefectPercent: totalPct, moisturePercent: M }) : undefined;

  const result = stage === 'PRE' ? (hv ? { t: `${HULL_TEXT[hv]}${fmOk === false ? ` · meyve nemi < %${ALMOND.harvestMoistMin}` : ''}`, tone: hv === 'hasat' && fmOk !== false ? 'ok' : hv === 'geç' ? 'bad' : 'warn' } : { t: cut || hDate ? 'Plan kaydı' : 'Kabuk açılma % girin', tone: cut || hDate ? 'ok' : 'none' })
    : stage === 'DRY' ? (mv ? { t: MOIST_TEXT[mv], tone: mv === 'depo' || mv === 'işleme' ? 'ok' : 'warn' } : { t: 'Nem girin', tone: 'none' })
    : grade ? { t: `${grade.grade}${grade.safeToStore ? '' : ' · nem yüksek'}`, tone: grade.grade === 'Sanayi / Yağlık' ? 'bad' : grade.safeToStore ? 'ok' : 'warn' } : { t: 'Numune g, iç g, nem ve kusurları girin', tone: 'none' };
  const canSave = !!loc.trim() && !p.isReadOnly && (stage === 'PRE' ? H !== undefined || FM !== undefined || !!cut || !!hDate : stage === 'DRY' ? KM !== undefined : !!S && !!K && M !== undefined);

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const isNew = !p.initialRefId;
    const refId = p.initialRefId || generateRefId('BADEM', p.existingRefs.map(r => r.refId));
    const st = STAGES.find(s => s.k === stage)!;
    const by = getCurrentUser()?.fullName || 'Belirtilmedi';
    const v = variety.trim() || 'Belirtilmedi';
    const rec: BademRecord = {
      id: `b-${Date.now()}`, refId, timestamp: new Date().toISOString(), operator: by, product: `Badem (${v})`, variety: v, location: loc.trim(),
      waterCutOffDate: cut || undefined, plannedHarvestDate: hDate || undefined, hullCondition: cond || undefined, treeLossPercent: num(treeLoss), hullSplitPercent: H, fruitMoisturePercent: FM, harvestReadinessStatus: ready as BademRecord['harvestReadinessStatus'],
      dryingStage: dryDay ? `Yerde Kurutma ${dryDay}. Gün` : undefined, kernelMoisturePercent: KM, dryingNextStep: mv === 'depo' ? 'Depolama (Kuru Depo Stok Kaydı)' : mv === 'işleme' ? 'Badem İşleme / Kırma Alanı' : undefined,
      calibre: calib, totalLoadKg: num(load) || 0, sampleGram: S || 0, kernelGram: K || 0, kernelYieldPercent: yieldPct || 0,
      moisturePercent: (M ?? KM ?? undefined) as number, aflatoxinTest: afla || undefined, phenologicalStage: '', testStage: st.t,
      defWholeGram: g('whole'), defDoubleGram: g('double'), defMechanicalGram: 0, defForeignGram: g('foreign'), defDustGram: g('dust'), defBrokenGram: g('broken'),
      defSeriousGram: g('serious') + g('insect'), defUndersizeGram: g('undersize'), defGumGram: g('gum'), defInsectGram: g('insect'),
      seriousDefectPercent: Number(seriousPct.toFixed(2)), totalDefectPercent: Number(totalPct.toFixed(2)), classification: grade?.grade || 'Sınıf 1',
      kaliteSinifi: grade?.grade, testStatus: 'COMPLETED', nextStep: stage === 'LAB' ? 'Depolama' : '', notes: note,
    };
    const refData: Partial<ReferenceItem> | undefined = isNew ? {
      refId, moduleKey: 'BADEM', product: rec.product, location: rec.location, source: rec.location, destination: 'Kuru depo', quantity: rec.totalLoadKg, unit: 'kg',
      status: 'CREATED', createdAt: new Date().toISOString(), operator: by, notes: `Badem [${st.t}]`,
    } : undefined;
    try { await p.onSave(rec, isNew, refData); } finally { setSaving(false); }
  };

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <QHeader title="Badem testi" sub={`${p.initialRefId || 'yeni RefID'}${loc ? ` · ${loc}` : ''}${variety ? ` · ${variety}` : ''}`} onBack={p.onCancel} />
      <Chips items={STAGES.map(s => ({ k: s.k, l: s.l }))} value={stage} onChange={k => setStage(k as Stage)} />

      <section className={SEC}>
        {almondOrchards.length > 0 && <Chips items={almondOrchards.map(n => ({ k: n, l: n }))} value={loc} onChange={x => { setLoc(x); setVariety(''); }} />}
        {vars.length > 0 && <Chips items={vars.map(n => ({ k: n, l: n }))} value={variety} onChange={setVariety} />}
        <div className="grid grid-cols-2 gap-2">
          <label className="text-[11px] text-slate-500">Bahçe / parsel<input value={loc} onChange={e => setLoc(e.target.value)} className={INP} /></label>
          <label className="text-[11px] text-slate-500">Çeşit<input value={variety} onChange={e => setVariety(e.target.value)} className={INP} placeholder="Makako, Lauranne…" /></label>
        </div>
      </section>

      {stage === 'PRE' && (<>
        <div className="grid grid-cols-2 gap-2">
          <NumTile label="Ağaçta kabuk açılma" value={hull} onChange={setHull} unit="%" hint={hv ? HULL_TEXT[hv] : `%${ALMOND.hullWarn}–${ALMOND.hullStart} uyarı · %${ALMOND.hullStart}–${ALMOND.hullMax} hasat`} tone={!hv ? undefined : hv === 'hasat' ? 'ok' : 'warn'} />
          <NumTile label="Meyve nemi (RH)" value={fruitM} onChange={setFruitM} unit="%" hint={`hasat için ≥ ${ALMOND.harvestMoistMin}`} tone={fmOk === undefined ? undefined : fmOk ? 'ok' : 'warn'} />
        </div>
        <section className={SEC}>
          <div className="text-[11px] text-slate-500">Çanak (kabuk) durumu</div>
          <Chips items={['Yeşil · kapalı', 'Çatlıyor', 'Açık · kuruyor', 'Açık · kuru'].map(x => ({ k: x, l: x }))} value={cond} onChange={k => setCond(cond === k ? '' : k)} />
          <div className="grid grid-cols-2 gap-2">
            <label className="text-[11px] text-slate-500">Su kesme günü<input type="date" value={cut} onChange={e => setCut(e.target.value)} className={INP} /></label>
            <label className="text-[11px] text-slate-500">Hasat günü<input type="date" value={hDate} onChange={e => setHDate(e.target.value)} className={INP} /></label>
          </div>
          {hv === 'yaklaşıyor' && !cut && <p className="text-[11px] text-amber-800">Açılma %{ALMOND.hullWarn}–{ALMOND.hullStart}: su kesme gününü belirleyin.</p>}
          {hv === 'hasat' && !hDate && <p className="text-[11px] text-amber-800">Hasat zamanı: hasat gününü ve ekibi belirleyin.</p>}
        </section>
        <NumTile label="Ağaçta kalan · fire payı (isteğe bağlı)" value={treeLoss} onChange={setTreeLoss} unit="%" hint={hv === 'geç' ? `%${ALMOND.hullMax} üstü: ağaçta kalan fireyi yazın` : 'hasat sonrası ağaçta kalan'} />
      </>)}
      {stage === 'DRY' && (
        <div className="grid grid-cols-2 gap-2">
          <NumTile label="Yerde kaçıncı gün" value={dryDay} onChange={setDryDay} unit="gün" />
          <NumTile label="Nem" value={kernM} onChange={setKernM} unit="%" hint={mv ? MOIST_TEXT[mv] : `MZ işleme %${ALMOND.processMin}–${ALMOND.processMax} · depo ≈ %${ALMOND.dryTarget} (en az ${ALMOND.dryMin})`} tone={!mv ? undefined : mv === 'depo' || mv === 'işleme' ? 'ok' : 'warn'} />
        </div>
      )}
      {stage === 'LAB' && (<>
        <div className="grid grid-cols-2 gap-2">
          <NumTile label="Brüt numune" value={sample} onChange={setSample} unit="g" hint="kabuklu" />
          <NumTile label="Net iç badem" value={kernel} onChange={setKernel} unit="g" hint="kırma sonrası" />
          <NumTile label="İç nemi" value={moist} onChange={setMoist} unit="%" hint="≤ 6,0 depolanabilir" tone={M === undefined ? undefined : M <= 6 ? 'ok' : 'warn'} />
          <label className="rounded-xl border border-slate-200 dark:border-slate-700 px-3 py-2 block"><div className="text-[10px] font-semibold text-slate-500">Kalibre</div><input value={calib} onChange={e => setCalib(e.target.value)} placeholder="28/30" className="w-full bg-transparent text-xl font-bold outline-none placeholder:text-slate-300" /><div className="text-[10px] text-slate-400">adet / oz</div></label>
        </div>
        <section className={SEC}>
          <h2 className="text-sm font-bold">Kusur dağılımı · gram</h2>
          <div className="grid grid-cols-3 gap-1.5">{DEFS.map(([k, l]) => (
            <label key={k} className={`rounded-lg border px-2 py-1 ${(k === 'serious' || k === 'insect') && g(k) > 0 ? 'border-rose-300 bg-rose-50 dark:bg-rose-950/30' : 'border-slate-200 dark:border-slate-700'}`}>
              <div className="text-[10px] text-slate-500">{l}</div>
              <input inputMode="decimal" value={def[k]} onChange={e => setDef(d => ({ ...d, [k]: e.target.value.replace(/[^\d.,]/g, '') }))} placeholder="0" className="w-full bg-transparent text-sm font-semibold tabular-nums outline-none" />
            </label>))}</div>
          <div className="flex gap-1.5 flex-wrap items-center"><span className="text-[11px] text-slate-500">Aflatoksin:</span>
            {(['Negatif (<2 ppb)', 'İnceleniyor', 'Pozitif (>4 ppb)'] as const).map(a => <button key={a} type="button" onClick={() => setAfla(afla === a ? '' : a)} className={`px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${afla === a ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{a}</button>)}</div>
        </section>
        {(yieldPct || base > 0) && (
          <section className={SEC}>
            {yieldPct ? <CalcRow label="Randıman (iç / brüt)" value={`% ${fmt(yieldPct)}`} /> : null}
            {base > 0 && <CalcRow label="Toplam kusur (sağlam dışı / numune)" value={`% ${fmt(totalPct)}`} badge="Ekstra ≤ 5 · Sınıf 1 ≤ 10" ok={totalPct <= 10} />}
            {base > 0 && <CalcRow label="Ciddi kusur (kurt + küf / çürük)" value={`% ${fmt(seriousPct)}`} badge="Ekstra ≤ 0,5 · Sınıf 1 ≤ 1" ok={seriousPct <= 1} />}
            {grade?.warnings.map((w, i) => <p key={i} className="text-[11px] text-amber-800">{w}</p>)}
          </section>
        )}
        <NumTile label="Toplam yük (isteğe bağlı)" value={load} onChange={setLoad} unit="kg" />
      </>)}

      <section className={SEC}>
        <textarea rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="Not" className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-sm" />
        <button type="button" onClick={p.onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 cursor-pointer">Fotoğraf, depolama önerisi, parçalı yük → ayrıntılı form</button>
      </section>
      <ResultBar text={result.t} tone={result.tone as any} canSave={canSave} saving={saving} onSave={save} />
    </div>
  );
}
