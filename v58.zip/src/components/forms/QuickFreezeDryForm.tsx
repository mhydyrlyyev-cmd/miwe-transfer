import React, { useMemo, useState } from 'react';
import type { FreezeDryRecord, ReferenceItem } from '../../types';
import { getCurrentUser } from '../../utils/authService';
import { nextSequence } from '../../utils/docNumbers';
import { QHeader, Chips, NumTile, CalcRow, ResultBar, RefPicker, SEC, INP, num, fmt } from './QuickParts';

/**
 * v54 — Freeze-dry (görsel 35): Giriş · Şoklama · Kurutma · Paket. Aynı partide aşama aşama ilerler (tek kayıt güncellenir).
 * Sınırlar platformda tanımlı olanlar: şoklama ≤ −40 °C ve vakum 0,1–0,5 mBar (FreezeDryRecord tanımı), nihai nem ≤ %3 (parti testleri).
 */
type St = 'IN' | 'SHOCK' | 'DRY' | 'PACK';
const STAGES: { k: St; l: string; status: FreezeDryRecord['processStatus'] }[] = [
  { k: 'IN', l: 'Giriş', status: 'RAW_ACCEPTED' }, { k: 'SHOCK', l: 'Şoklama', status: 'SHOCKED_40C' },
  { k: 'DRY', l: 'Kurutma', status: 'DRYING' }, { k: 'PACK', l: 'Paket', status: 'COMPLETED' },
];
const s = (v?: number) => (v === undefined || v === null || Number.isNaN(v) ? '' : String(v).replace('.', ','));

interface Props {
  onSave: (record: FreezeDryRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  fdRecords: FreezeDryRecord[];
  initialRefId?: string;
  isReadOnly?: boolean;
}

export default function QuickFreezeDryForm(p: Props) {
  const open = useMemo(() => p.fdRecords.filter(r => r.processStatus !== 'COMPLETED'), [p.fdRecords]);
  const [refId, setRefId] = useState(p.initialRefId || '');
  const cur = p.fdRecords.find(r => r.refId === refId);
  const stageOf = (r?: FreezeDryRecord): St => !r ? 'IN' : r.processStatus === 'RAW_ACCEPTED' ? 'SHOCK' : r.processStatus === 'SHOCKED_40C' || r.processStatus === 'STORED_25C' ? 'DRY' : 'PACK';
  const [stage, setStage] = useState<St>(stageOf(cur));
  const [v, setV] = useState<Record<string, string>>({});
  const pick = (r: string) => { setRefId(r); const c = p.fdRecords.find(x => x.refId === r); setStage(stageOf(c)); setV({}); };
  const val = (k: keyof FreezeDryRecord) => v[k as string] ?? s(cur?.[k] as number);
  const set = (k: keyof FreezeDryRecord) => (x: string) => setV(o => ({ ...o, [k]: x }));
  const N = (k: keyof FreezeDryRecord) => num(val(k));
  const [note, setNote] = useState('');
  const [n2, setN2] = useState<boolean>(cur?.nitrogenFlushed ?? true);
  const [saving, setSaving] = useState(false);

  const ref = p.existingRefs.find(r => r.refId === refId);
  const product = cur?.product || (ref?.product || '').replace(/\s*\(.*\)$/, '');
  const raw = N('rawWeightKg'), dry = N('finalDryWeightKg'), gram = N('packageGram');
  const yieldPct = raw && dry ? (dry / raw) * 100 : undefined;
  const packs = dry && gram ? Math.floor((dry * 1000) / gram) : undefined;
  const shock = N('shockFreezerTempC'), vac = N('vacuumPressureMbar'), moist = N('finalMoisturePercent');

  const need: Record<St, boolean> = { IN: !!raw, SHOCK: shock !== undefined, DRY: !!dry && moist !== undefined, PACK: !!gram };
  const canSave = !p.isReadOnly && !!refId && need[stage];
  const res = stage === 'IN' ? { t: raw ? `Giriş ${fmt(raw)} kg · şoklamaya hazır` : 'Giriş yaş ağırlığını girin', tone: raw ? 'ok' : 'none' }
    : stage === 'SHOCK' ? { t: shock === undefined ? 'Şok sıcaklığını girin' : shock <= -40 ? 'Şok tamam · kurutmaya hazır' : 'Şok yetersiz (> −40 °C)', tone: shock === undefined ? 'none' : shock <= -40 ? 'ok' : 'warn' }
    : stage === 'DRY' ? { t: moist === undefined ? 'Nihai nemi girin' : moist <= 3 ? 'Kuru · paketlemeye hazır' : 'Nem yüksek · kurutmaya devam', tone: moist === undefined ? 'none' : moist <= 3 ? 'ok' : 'warn' }
    : { t: packs ? `${packs} paket · tamamlandı` : 'Paket gramajını girin', tone: packs ? 'ok' : 'none' };

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const g = (k: keyof FreezeDryRecord, d = 0) => N(k) ?? (cur?.[k] as number) ?? d;
    const today = new Date().toISOString().slice(0, 10);
    const lotNo = cur?.lotNo || nextSequence(p.fdRecords.map(r => r.lotNo).filter(Boolean), `FD-${today.replace(/-/g, '')}-`);
    const rec: FreezeDryRecord = {
      ...(cur || {} as FreezeDryRecord),
      id: cur?.id || `fd-${Date.now()}`, refId, timestamp: new Date().toISOString(), operator: getCurrentUser()?.fullName || 'Belirtilmedi',
      processDate: cur?.processDate || today, product: product || 'Belirtilmedi', variety: cur?.variety || (ref?.product || '').match(/\((.*)\)/)?.[1] || '',
      rawMaterialSource: cur?.rawMaterialSource || 'Depo / sortlama ayrımı', rawWeightKg: g('rawWeightKg'), rawBrix: g('rawBrix'), rawMoisturePercent: g('rawMoisturePercent'),
      sortingWasteKg: g('sortingWasteKg'), usableRawWeightKg: Math.max(0, g('rawWeightKg') - g('sortingWasteKg')), sliceThicknessMm: g('sliceThicknessMm'),
      shockFreezerRoom: cur?.shockFreezerRoom || '', shockFreezerTempC: g('shockFreezerTempC'), coreTemperatureC: g('coreTemperatureC'), shockDurationHours: g('shockDurationHours'),
      shockStatus: shock !== undefined || cur?.shockFreezerTempC ? 'COMPLETED' : 'PENDING',
      frozenStorageRoom: cur?.frozenStorageRoom || '', frozenStorageTempC: cur?.frozenStorageTempC ?? 0,
      dryerChamberNo: v.dryerChamberNo ?? cur?.dryerChamberNo ?? '', trayCount: g('trayCount'), vacuumPressureMbar: g('vacuumPressureMbar'), sublimationTimeHours: g('sublimationTimeHours'),
      finalDryWeightKg: g('finalDryWeightKg'), finalMoisturePercent: g('finalMoisturePercent'), yieldRatioPercent: yieldPct ? Number(yieldPct.toFixed(2)) : cur?.yieldRatioPercent ?? 0,
      crunchinessTexture: cur?.crunchinessTexture || 'Gevrek / Çıtır', packagingType: cur?.packagingType || 'Azotlu doypack', packageGram: g('packageGram'),
      totalPackagesProduced: packs ?? cur?.totalPackagesProduced ?? 0, nitrogenFlushed: n2, lotNo, expiryDate: cur?.expiryDate || '',
      processStatus: STAGES.find(x => x.k === stage)!.status, notes: [cur?.notes, note].filter(Boolean).join(' · '),
    };
    try { await p.onSave(rec, false); } finally { setSaving(false); }
  };

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <QHeader title="Freeze-dry" sub={`${refId || 'parti seçin'}${product ? ` · ${product}` : ''}${val('dryerChamberNo') ? ` · kabin ${val('dryerChamberNo')}` : ''}`} onBack={p.onCancel} />
      <Chips items={STAGES.map(x => ({ k: x.k, l: x.l }))} value={stage} onChange={k => setStage(k as St)} />
      <section className={SEC}>
        {open.length > 0 && (<>
          <div className="text-[11px] font-semibold text-slate-500">Süren işlemler</div>
          <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{open.map(r => (
            <button key={r.id} type="button" onClick={() => pick(r.refId)} className={`shrink-0 px-3 min-h-[34px] rounded-full border text-xs cursor-pointer ${refId === r.refId ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{r.refId} · {STAGES.find(x => x.status === r.processStatus)?.l || 'Şoklama'}</button>))}</div>
        </>)}
        {!cur && <RefPicker refs={p.existingRefs.filter(r => !p.fdRecords.some(f => f.refId === r.refId))} value={refId} onChange={pick} empty="Parti yok." />}
      </section>

      {stage === 'IN' && <div className="grid grid-cols-2 gap-2">
        <NumTile label="Giriş yaş ağırlık" value={val('rawWeightKg')} onChange={set('rawWeightKg')} unit="kg" />
        <NumTile label="Giriş Brix" value={val('rawBrix')} onChange={set('rawBrix')} unit="°Bx" />
        <NumTile label="Ayıklama firesi" value={val('sortingWasteKg')} onChange={set('sortingWasteKg')} unit="kg" hint="çekirdek, kabuk" />
        <NumTile label="Dilim kalınlığı" value={val('sliceThicknessMm')} onChange={set('sliceThicknessMm')} unit="mm" />
      </div>}
      {stage === 'SHOCK' && <div className="grid grid-cols-2 gap-2">
        <NumTile label="Şoklama" value={val('shockFreezerTempC')} onChange={set('shockFreezerTempC')} unit="°C" hint="≤ −40 uygun" tone={shock === undefined ? undefined : shock <= -40 ? 'ok' : 'warn'} />
        <NumTile label="Çekirdek donma" value={val('coreTemperatureC')} onChange={set('coreTemperatureC')} unit="°C" />
        <NumTile label="Şok süresi" value={val('shockDurationHours')} onChange={set('shockDurationHours')} unit="saat" />
      </div>}
      {stage === 'DRY' && <div className="grid grid-cols-2 gap-2">
        <label className="rounded-xl border border-slate-200 dark:border-slate-700 px-3 py-2 block"><div className="text-[10px] font-semibold text-slate-500">Kabin</div><input value={val('dryerChamberNo')} onChange={e => set('dryerChamberNo')(e.target.value)} placeholder="L-2" className="w-full bg-transparent text-xl font-bold outline-none placeholder:text-slate-300" /></label>
        <NumTile label="Vakum" value={val('vacuumPressureMbar')} onChange={set('vacuumPressureMbar')} unit="mBar" hint="0,1–0,5" tone={vac === undefined ? undefined : vac >= 0.1 && vac <= 0.5 ? 'ok' : 'warn'} />
        <NumTile label="Süblimasyon" value={val('sublimationTimeHours')} onChange={set('sublimationTimeHours')} unit="saat" />
        <NumTile label="Çıkış kuru ağırlık" value={val('finalDryWeightKg')} onChange={set('finalDryWeightKg')} unit="kg" />
        <NumTile label="Nihai nem" value={val('finalMoisturePercent')} onChange={set('finalMoisturePercent')} unit="%" hint="≤ 3 uygun" tone={moist === undefined ? undefined : moist <= 3 ? 'ok' : 'warn'} />
      </div>}
      {stage === 'PACK' && <div className="grid grid-cols-2 gap-2">
        <NumTile label="Paket gramajı" value={val('packageGram')} onChange={set('packageGram')} unit="g" />
        <NumTile label="Paket sayısı" value={packs ? String(packs) : ''} unit="adet" hint="otomatik" readOnly />
        <button type="button" onClick={() => setN2(x => !x)} className={`col-span-2 min-h-[40px] rounded-xl border text-xs font-semibold cursor-pointer ${n2 ? 'border-teal-500 bg-teal-50 text-teal-800' : 'border-slate-300'}`}>Azot basıldı: {n2 ? 'evet' : 'hayır'}</button>
      </div>}

      {(yieldPct || packs) && (
        <section className={SEC}>
          {yieldPct ? <CalcRow label="Randıman (kuru / yaş)" value={`% ${fmt(yieldPct)}`} /> : null}
          {yieldPct ? <CalcRow label="Su uçurma" value={`% ${fmt(100 - yieldPct)}`} /> : null}
          {packs ? <CalcRow label={`Paket sayısı (${fmt(gram!, 0)} g)`} value={`${packs} paket`} /> : null}
        </section>
      )}
      <section className={SEC}>
        <input value={note} onChange={e => setNote(e.target.value)} placeholder="Not" className={INP} />
        <button type="button" onClick={p.onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 cursor-pointer">Donuk depo, tepsi, doku, son tüketim tarihi, fotoğraf → ayrıntılı form</button>
      </section>
      <ResultBar text={res.t} tone={res.tone as any} canSave={canSave} saving={saving} onSave={save} />
    </div>
  );
}
