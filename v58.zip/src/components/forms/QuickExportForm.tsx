import React, { useMemo, useState } from 'react';
import type { ExportSampleRecord, ReferenceItem } from '../../types';
import { generateRefId } from '../../utils/calculations';
import { getCurrentUser } from '../../utils/authService';
import { QHeader, Chips, NumTile, CalcRow, ResultBar, RefPicker, SEC, INP, num, fmt } from './QuickParts';

/**
 * v54 — İhracat / şahit numune (görsel 34): Çıkış ölçümü (gün 0) · Dönüş / ara ölçüm (gün 3, 5, 7, 14 …).
 * Dönüşte çıkış kaydıyla karşılaştırır: ağırlık kaybı, sertlik ve Brix değişimi. Platformda bu ölçüler için onaylı sınır yok,
 * bu yüzden karar (Mükemmel / Uygun / Şartlı / Yüksek risk) ölçen kişi tarafından seçilir — eski formdaki gibi.
 * Kayıt aynı ExportSampleRecord; şahit numune hatırlatmaları (Bugün bakılacaklar) aynen çalışır.
 */
type Mode = 'OUT' | 'BACK';
type Dec = ExportSampleRecord['shelfLifeDecision'];
const DECS: { k: Dec; l: string; tone: string }[] = [
  { k: 'EXCELLENT', l: 'Mükemmel', tone: 'emerald' }, { k: 'COMPLIANT', l: 'Uygun', tone: 'emerald' },
  { k: 'CONDITIONAL', l: 'Şartlı · hızlı sat', tone: 'amber' }, { k: 'HIGH_RISK', l: 'Yüksek risk', tone: 'rose' },
];
const day = (a: string, b: string) => Math.round((Date.parse(`${a}T00:00:00`) - Date.parse(`${b}T00:00:00`)) / 864e5);
const today = () => new Date().toISOString().slice(0, 10);

interface Props {
  onSave: (record: ExportSampleRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  exportRecords: ExportSampleRecord[];
  initialRefId?: string;
  isReadOnly?: boolean;
}

export default function QuickExportForm(p: Props) {
  const hasOut = (r: string) => p.exportRecords.some(e => e.refId === r);
  const [refId, setRefId] = useState(p.initialRefId || '');
  const [mode, setMode] = useState<Mode>(p.initialRefId && hasOut(p.initialRefId) ? 'BACK' : 'OUT');
  const ref = p.existingRefs.find(r => r.refId === refId);
  const prev = useMemo(() => p.exportRecords.filter(e => e.refId === refId).sort((a, b) => String(a.testDate || a.timestamp).localeCompare(String(b.testDate || b.timestamp))), [p.exportRecords, refId]);
  const base = prev[0];
  const [country, setCountry] = useState(base?.destinationCountry || '');
  const [dispatch, setDispatch] = useState(base?.dispatchDate?.slice(0, 10) || today());
  const [vehicle, setVehicle] = useState('');
  const [w, setW] = useState(''); const [h, setH] = useState(''); const [b, setB] = useState(''); const [cal, setCal] = useState(''); const [road, setRoad] = useState('');
  const [dec, setDec] = useState<Dec | ''>('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const W = num(w), Hh = num(h), B = num(b);
  const startDate = base?.dispatchDate?.slice(0, 10) || dispatch;
  const dayN = mode === 'BACK' ? Math.max(0, day(today(), startDate)) : 0;
  const w0 = base?.initialWeightGr, h0 = base?.avgHardness, b0 = base?.avgBrix;
  const loss = mode === 'BACK' && W && w0 ? ((w0 - W) / w0) * 100 : undefined;
  const hDrop = mode === 'BACK' && Hh && h0 ? ((h0 - Hh) / h0) * 100 : undefined;
  const product = (ref?.product || base?.product || '').replace(/\s*\(.*\)$/, '');
  const variety = (ref?.product || '').match(/\((.*)\)/)?.[1] || base?.variety || '';

  const canSave = !p.isReadOnly && !!W && (mode === 'OUT' ? !!country.trim() && (!!refId || !!product) : !!base && !!dec);
  const res = mode === 'OUT'
    ? { t: W ? `Çıkış ölçümü · ${country || 'ülke girin'}` : 'Çıkış ağırlığını girin', tone: W && country ? 'ok' : 'none' }
    : !base ? { t: 'Bu partinin çıkış ölçümü yok', tone: 'warn' }
    : dec ? { t: `${DECS.find(d => d.k === dec)!.l} · ${dayN}. gün`, tone: dec === 'HIGH_RISK' ? 'bad' : dec === 'CONDITIONAL' ? 'warn' : 'ok' }
    : { t: `${dayN}. gün ölçümü · karar seçin`, tone: 'none' };

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const isNew = !refId;
    const id = refId || generateRefId('EXPORT_SAMPLE', p.existingRefs.map(r => r.refId));
    const by = getCurrentUser()?.fullName || 'Belirtilmedi';
    const rec: ExportSampleRecord = {
      id: `exp-${Date.now()}`, refId: id, timestamp: new Date().toISOString(), testDate: today(), dispatchDate: startDate, operator: by,
      product: product || 'Belirtilmedi', variety, destinationCountry: (base?.destinationCountry || country).trim(), transitDays: dayN,
      transitCondition: vehicle || base?.transitCondition || 'Frigorifik', initialWeightGr: mode === 'OUT' ? W! : (w0 as number), finalWeightGr: W!,
      weightLossGr: mode === 'BACK' && w0 ? Number((w0 - W!).toFixed(1)) : 0, weightLossPercent: loss !== undefined ? Number(loss.toFixed(2)) : 0, waterLossPercent: loss !== undefined ? Number(loss.toFixed(2)) : 0,
      sampleCount: 0, samples: [], avgHardness: Hh as number, avgBrix: B as number, caliberActual: cal || undefined, actualTemperature: road || undefined,
      visualAssessment: '', shelfLifeDecision: (mode === 'OUT' ? 'COMPLIANT' : dec) as Dec, decisionNotes: mode === 'OUT' ? 'Çıkış ölçümü (gün 0)' : note, kaliteSinifi: undefined,
    };
    const refData: Partial<ReferenceItem> | undefined = isNew ? { product: product || 'Belirtilmedi', location: `İhracat numunesi (${rec.destinationCountry})`, destination: rec.destinationCountry, quantity: 0, unit: 'kg', notes: 'Şahit numune · çıkış ölçümü' } : undefined;
    try { await p.onSave(rec, isNew, refData); } finally { setSaving(false); }
  };

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <QHeader title="İhracat numunesi" sub={`${refId || 'parti seçin'}${product ? ` · ${product}${variety ? ` ${variety}` : ''}` : ''}${base?.destinationCountry ? ` → ${base.destinationCountry}` : ''}`} onBack={p.onCancel} />
      <Chips items={[{ k: 'OUT' as Mode, l: 'Çıkış (gün 0)' }, { k: 'BACK' as Mode, l: 'Dönüş / ara ölçüm' }]} value={mode} onChange={k => setMode(k as Mode)} />

      <section className={SEC}>
        <RefPicker refs={mode === 'BACK' ? p.existingRefs.filter(r => hasOut(r.refId)) : p.existingRefs} value={refId} onChange={setRefId} empty={mode === 'BACK' ? 'Çıkış ölçümü girilmiş parti yok.' : 'Parti yok.'} />
        {mode === 'OUT' ? (
          <div className="grid grid-cols-3 gap-2">
            <label className="text-[11px] text-slate-500">Ülke<input value={country} onChange={e => setCountry(e.target.value)} className={INP} placeholder="Rusya" /></label>
            <label className="text-[11px] text-slate-500">Yola çıkış<input type="date" value={dispatch} onChange={e => setDispatch(e.target.value)} className={INP} /></label>
            <label className="text-[11px] text-slate-500">Araç / logger<input value={vehicle} onChange={e => setVehicle(e.target.value)} className={INP} placeholder="AG 4512 · D-07" /></label>
          </div>
        ) : base ? (
          <p className="text-[11px] text-slate-600 dark:text-slate-400">Çıkış {startDate.slice(8, 10)}.{startDate.slice(5, 7)} · bugün <b>{dayN}. gün</b> · önceki ölçüm {prev.length} · çıkışta {w0 ? `${fmt(w0, 0)} g` : '—'}, sertlik {h0 ? fmt(h0) : '—'}, Brix {b0 ? fmt(b0) : '—'}</p>
        ) : null}
      </section>

      <div className="grid grid-cols-2 gap-2">
        <NumTile label={mode === 'OUT' ? 'Çıkış ağırlığı' : 'Bugünkü ağırlık'} value={w} onChange={setW} unit="g" hint={mode === 'BACK' && w0 ? `çıkışta ${fmt(w0, 0)}` : 'numunenin toplamı'} />
        <NumTile label="Sertlik" value={h} onChange={setH} unit="kg/cm²" hint={mode === 'BACK' && h0 ? `çıkışta ${fmt(h0)}` : 'ortalama'} />
        <NumTile label="Brix" value={b} onChange={setB} unit="°Bx" hint={mode === 'BACK' && b0 ? `çıkışta ${fmt(b0)}` : 'ortalama'} />
        {mode === 'OUT' ? <NumTile label="Kalibre uygunluk" value={cal} onChange={setCal} unit="%" /> : <NumTile label="Yol sıcaklığı" value={road} onChange={setRoad} unit="°C" hint="datalogger" />}
      </div>

      {mode === 'BACK' && (loss !== undefined || hDrop !== undefined) && (
        <section className={SEC}>
          {loss !== undefined && <CalcRow label="Ağırlık kaybı" value={`% ${fmt(loss)}`} />}
          {hDrop !== undefined && <CalcRow label="Sertlik düşüşü" value={`${fmt(h0! - Hh!)} kg/cm² · % ${fmt(hDrop)}`} />}
          {B && b0 ? <CalcRow label="Brix değişimi" value={`${B - b0 >= 0 ? '+' : ''}${fmt(B - b0)} °Bx`} /> : null}
          <p className="text-[10px] text-slate-500">Bu ölçüler için platformda onaylı sınır yok; kararı siz seçin. Sınırları verirseniz renklendiririm.</p>
        </section>
      )}
      {mode === 'BACK' && (
        <section className={SEC}>
          <h2 className="text-sm font-bold">Karar</h2>
          <div className="grid grid-cols-2 gap-1.5">{DECS.map(d => (
            <button key={d.k} type="button" onClick={() => setDec(d.k)} className={`min-h-[38px] rounded-xl border text-xs font-semibold cursor-pointer ${dec === d.k ? (d.tone === 'rose' ? 'bg-rose-600 text-white border-rose-600' : d.tone === 'amber' ? 'bg-amber-500 text-white border-amber-500' : 'bg-emerald-600 text-white border-emerald-600') : 'border-slate-300'}`}>{d.l}</button>))}</div>
          <textarea rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="Görünüş: buruşma, kararma, çürük…" className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-sm" />
        </section>
      )}
      <button type="button" onClick={p.onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 px-1 cursor-pointer">Meyve meyve ölçüm, GOST kusur, fotoğraf → ayrıntılı form</button>
      <ResultBar text={res.t} tone={res.tone as any} canSave={canSave} saving={saving} onSave={save} />
    </div>
  );
}
