import React from 'react';
import { ArrowLeft } from 'lucide-react';

/** v54 — Yeni formların ortak parçaları: başlık, aşama düğmeleri, sayı kutusu, hesap satırı, sonuç çubuğu. */
export const num = (s: string) => { if (s === '' || s == null) return undefined; const v = Number(String(s).replace(/\s/g, '').replace(',', '.')); return Number.isFinite(v) ? v : undefined; };
export const fmt = (x: number, d = 1) => x.toLocaleString('tr-TR', { maximumFractionDigits: d });
export const SEC = 'rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-2';
export const INP = 'w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 text-sm';

export function QHeader({ title, sub, onBack }: { title: string; sub: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-2">
      <button type="button" onClick={onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
      <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">{title}</h1><p className="text-xs text-slate-500 truncate">{sub}</p></div>
    </div>
  );
}

export function Chips<T extends string>({ items, value, onChange }: { items: { k: T; l: string }[]; value: T; onChange: (k: T) => void }) {
  return (
    <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{items.map(x => (
      <button key={x.k} type="button" onClick={() => onChange(x.k)} className={`shrink-0 px-3 min-h-[34px] rounded-full border text-xs cursor-pointer ${value === x.k ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'border-slate-300 text-slate-700 dark:text-slate-300'}`}>{x.l}</button>))}</div>
  );
}

/** Sayı kutusu. tone: ok = yeşil kenar, warn = sarı. hint: altta küçük yazı (sınır, kaynak). */
export function NumTile({ label, value, onChange, unit, hint, tone, readOnly }: { label: string; value: string; onChange?: (s: string) => void; unit?: string; hint?: React.ReactNode; tone?: 'ok' | 'warn'; readOnly?: boolean }) {
  const cls = tone === 'warn' ? 'border-amber-300 bg-amber-50 dark:bg-amber-950/30' : tone === 'ok' ? 'border-emerald-300' : value ? 'border-teal-300' : 'border-slate-200 dark:border-slate-700';
  return (
    <label className={`rounded-xl border bg-white dark:bg-slate-900 px-3 py-2 min-w-0 block ${cls}`}>
      <div className="text-[10px] font-semibold text-slate-500 truncate">{label}</div>
      <div className="flex items-baseline gap-1">
        <input inputMode="decimal" readOnly={readOnly} value={value} onChange={e => onChange?.(e.target.value.replace(/[^\d.,-]/g, ''))} placeholder="—" className="w-full min-w-0 bg-transparent text-xl font-bold tabular-nums outline-none placeholder:text-slate-300" />
        {unit && <span className="text-[10px] text-slate-400 shrink-0">{unit}</span>}
      </div>
      {hint && <div className={`text-[10px] truncate ${tone === 'warn' ? 'text-amber-800 font-semibold' : 'text-slate-400'}`}>{hint}</div>}
    </label>
  );
}

export function CalcRow({ label, value, badge, ok }: { label: string; value: string; badge?: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2 py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0">
      <div className="min-w-0"><div className="text-[11px] text-slate-500">{label}</div><div className="text-sm font-bold tabular-nums">{value}</div></div>
      {badge && <span className={`text-[10px] px-2 py-0.5 rounded-full border shrink-0 ${ok === undefined ? 'border-slate-200 text-slate-600' : ok ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-amber-300 bg-amber-50 text-amber-800'}`}>{badge}</span>}
    </div>
  );
}

export function ResultBar({ text, tone, canSave, saving, onSave }: { text: string; tone: 'ok' | 'warn' | 'bad' | 'none'; canSave: boolean; saving: boolean; onSave: () => void }) {
  const c = { ok: 'text-emerald-700', warn: 'text-amber-700', bad: 'text-rose-700', none: 'text-slate-500' }[tone];
  return (
    <div className="fixed left-0 right-0 bottom-[68px] sm:bottom-4 z-30 px-3">
      <div className="max-w-xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-lg px-4 py-2.5 flex items-center gap-3">
        <div className="min-w-0 flex-1"><div className="text-[10px] text-slate-500">Sonuç</div><div className={`text-sm font-bold truncate ${c}`}>{text}</div></div>
        <button type="button" disabled={!canSave || saving} onClick={onSave} className="min-h-[44px] px-6 rounded-xl bg-teal-700 text-white font-semibold disabled:opacity-40 cursor-pointer">{saving ? '…' : 'Kaydet'}</button>
      </div>
    </div>
  );
}

/** Parti seçici: üstte arama, altta son partiler. */
export function RefPicker({ refs, value, onChange, empty }: { refs: { refId: string; product?: string; orchard?: string; location?: string }[]; value: string; onChange: (r: string) => void; empty: string }) {
  const [q, setQ] = React.useState('');
  const list = refs.filter(r => !q || `${r.refId} ${r.product || ''} ${r.orchard || ''}`.toLocaleLowerCase('tr').includes(q.toLocaleLowerCase('tr'))).slice(0, 8);
  return (
    <div className="space-y-1">
      <input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, ürün, bahçe ara" className={INP} />
      {list.length === 0 ? <p className="text-[11px] text-slate-500">{empty}</p> : list.map(r => (
        <button key={r.refId} type="button" onClick={() => onChange(value === r.refId ? '' : r.refId)} className={`w-full text-left rounded-xl border px-3 py-1.5 text-xs cursor-pointer ${value === r.refId ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/30' : 'border-slate-200 dark:border-slate-700'}`}>
          <b className="font-mono">{r.refId}</b>{r.product ? ` · ${r.product}` : ''}{r.orchard || r.location ? ` · ${r.orchard || r.location}` : ''}</button>))}
    </div>
  );
}
