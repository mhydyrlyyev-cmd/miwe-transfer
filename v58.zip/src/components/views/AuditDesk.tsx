import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Download, Search } from 'lucide-react';
import type { ActivityLogItem } from '../../types/auth';
import { fetchActivityLogs, getActivityLogs } from '../../utils/authService';

/**
 * v55 — Denetim masası (görsel 15): kim, neyi, ne zaman değiştirdi. Arama, tür düğmeleri, hafta sayıları, dışa aktar.
 * Eski ayrıntılı ekran (filtreler, kullanıcıya göre) "Ayrıntılı görünüm" ile açılır.
 */
type Kind = 'ALL' | 'EDIT' | 'DELETE' | 'CREATE' | 'USER' | 'AUTH';
const KINDS: { k: Kind; l: string }[] = [{ k: 'ALL', l: 'Tümü' }, { k: 'EDIT', l: 'Düzeltme' }, { k: 'DELETE', l: 'Silme' }, { k: 'CREATE', l: 'Yeni' }, { k: 'USER', l: 'Kullanıcı' }, { k: 'AUTH', l: 'Giriş' }];
const kindOf = (a: string): Kind => /DELETE|CLEAR/.test(a) ? 'DELETE' : /UPDATE|EDIT|PERMISSION/.test(a) ? 'EDIT' : /CREATE|DISPATCH|REGISTER/.test(a) ? 'CREATE' : /USER_/.test(a) ? 'USER' : /LOGIN|LOGOUT/.test(a) ? 'AUTH' : 'EDIT';
const LABEL: Record<Kind, string> = { ALL: '', EDIT: 'düzeltme', DELETE: 'silme', CREATE: 'yeni', USER: 'kullanıcı', AUTH: 'giriş' };
const TONE: Record<Kind, string> = { ALL: '', EDIT: 'border-amber-200 bg-amber-50 text-amber-800', DELETE: 'border-rose-200 bg-rose-50 text-rose-800', CREATE: 'border-emerald-200 bg-emerald-50 text-emerald-800', USER: 'border-violet-200 bg-violet-50 text-violet-800', AUTH: 'border-slate-200 bg-slate-50 text-slate-600' };
const dt = (iso: string) => new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export default function AuditDesk({ onBack, onOpenRef, onOpenDetailed }: { onBack: () => void; onOpenRef: (refId: string) => void; onOpenDetailed: () => void }) {
  const [logs, setLogs] = useState<ActivityLogItem[]>(() => getActivityLogs());
  const [kind, setKind] = useState<Kind>('ALL');
  const [q, setQ] = useState('');
  const [n, setN] = useState(40);
  useEffect(() => { fetchActivityLogs().then(r => { if (r?.length) setLogs(r); }).catch(() => {}); }, []);
  const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString();
  const week = logs.filter(l => l.timestamp >= weekAgo);
  const list = useMemo(() => logs
    .filter(l => (kind === 'ALL' ? kindOf(l.action) !== 'AUTH' : kindOf(l.action) === kind))
    .filter(l => !q || `${l.userName} ${l.refId || ''} ${l.module || ''} ${l.details}`.toLocaleLowerCase('tr').includes(q.toLocaleLowerCase('tr')))
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp)), [logs, kind, q]);

  const csv = () => {
    const rows = [['Tarih', 'Kişi', 'Bölüm', 'İşlem', 'Modül', 'RefID', 'Ayrıntı'], ...list.map(l => [l.timestamp, l.userName, l.company, l.action, l.module || '', l.refId || '', l.details])];
    const txt = '﻿' + rows.map(r => r.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv;charset=utf-8' })); a.download = `denetim_${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Denetim masası</h1><p className="text-xs text-slate-500">Kim, neyi, ne zaman değiştirdi</p></div>
      </div>
      <label className="flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 min-h-[42px]"><Search className="w-4 h-4 text-slate-400" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, kişi, alan" className="flex-1 bg-transparent text-sm outline-none" /></label>
      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1">{KINDS.map(x => <button key={x.k} type="button" onClick={() => setKind(x.k)} className={`shrink-0 px-3 min-h-[32px] rounded-full border text-xs cursor-pointer ${kind === x.k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{x.l}</button>)}</div>
      <div className="grid grid-cols-3 gap-2">
        {[['bu hafta kayıt', week.filter(l => kindOf(l.action) !== 'AUTH').length], ['düzeltme', week.filter(l => kindOf(l.action) === 'EDIT').length], ['silme', week.filter(l => kindOf(l.action) === 'DELETE').length]].map(([l, v]) => (
          <div key={String(l)} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className={`text-xl font-bold tabular-nums ${l === 'silme' && Number(v) > 0 ? 'text-rose-700' : ''}`}>{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>))}
      </div>
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-2">
        {list.length === 0 ? <p className="text-sm text-slate-500 py-2">Kayıt yok.</p> : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{list.slice(0, n).map(l => { const k = kindOf(l.action); return (
            <li key={l.id} className="py-2">
              <div className="flex items-center justify-between gap-2"><span className="text-[11px] text-slate-500">{dt(l.timestamp)} · {l.userName || '—'}</span><span className={`text-[10px] px-2 py-0.5 rounded-full border shrink-0 ${TONE[k]}`}>{LABEL[k]}</span></div>
              {l.refId ? <button type="button" onClick={() => onOpenRef(l.refId!)} className="text-sm font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">{l.refId}{l.module ? ` · ${l.module}` : ''}</button> : <div className="text-sm font-semibold">{l.module || l.action}</div>}
              <div className="text-xs text-slate-600 dark:text-slate-400 break-words">{l.details}</div>
            </li>); })}</ul>
        )}
        {list.length > n && <button type="button" onClick={() => setN(x => x + 60)} className="w-full py-2 text-xs font-semibold text-teal-800 cursor-pointer">Daha fazla ({list.length - n})</button>}
      </section>
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={csv} className="min-h-[42px] rounded-xl border border-slate-300 text-sm font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"><Download className="w-4 h-4" />Dışa aktar (Excel)</button>
        <button type="button" onClick={onOpenDetailed} className="min-h-[42px] rounded-xl border border-slate-300 text-sm font-semibold cursor-pointer">Ayrıntılı görünüm</button>
      </div>
    </div>
  );
}
