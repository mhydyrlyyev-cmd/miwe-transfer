import React, { useMemo, useState } from 'react';
import { ArrowLeft, Camera, ChevronRight, FlaskConical, Users, FileText, AlertTriangle } from 'lucide-react';
import type { FieldRecord } from '../../types';
import type { MgmtData } from './ManagementViews';
import { canonicalOrchard, getProfiles, useLocationProfiles } from '../../services/locationProfiles';
import { useAllAkts } from '../../services/aktStatus';
import { useMuzDocs, isPal, palWaitH, useMuzCfg } from '../../services/muzDaily';

/**
 * v58 — Yönetici özeti: tek sayfa, kaybolmayan rapor girişi. Hafta / ay / sezon.
 * Ne oldu (hasat, depo, satış) · testler geniş analiz (ürün × aşama, bahçe, kişi, C proje) · testi eksik partiler ·
 * hasat fotoğrafları · kim ne yaptı · tüm raporlara kısayol. Yalnız okur, kayıt değiştirmez.
 */
type Period = 'WEEK' | 'MONTH' | 'SEASON';
const fromOf = (p: Period) => {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  if (p === 'WEEK') d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  else if (p === 'MONTH') d.setDate(1);
  else { d.setMonth(0, 1); }
  return d.toISOString();
};
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const f1 = (x?: number) => (x ? x.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—');
const stage = (t?: string) => (/önce|ön hasat/i.test(t || '') ? 'Hasat öncesi' : /hasat/i.test(t || '') ? 'Hasat' : /depo/i.test(t || '') ? 'Depo' : /sevk|çıkış/i.test(t || '') ? 'Sevk' : 'Diğer');
const verdict = (r: FieldRecord): 'ok' | 'warn' | 'bad' | 'none' =>
  r.qualityStandardVerdict === 'FAIL' || r.nitratePass === false ? 'bad' : r.qualityStandardVerdict === 'CONDITIONAL' || r.hueAngleVerdict === 'WARNING' ? 'warn' : r.qualityStandardVerdict === 'PASS' ? 'ok' : 'none';
const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : undefined);

interface Props extends MgmtData { onBack: () => void; onOpen: (view: string, tab?: string) => void; onOpenRef: (refId: string) => void; onOpenGallery: (module: string) => void }

export default function ManagerBrief(p: Props) {
  useLocationProfiles();
  const [period, setPeriod] = useState<Period>('WEEK');
  const [tab, setTab] = useState<'URUN' | 'BAHCE' | 'KISI'>('URUN');
  const from = fromOf(period);
  const inP = (iso?: string) => !!iso && iso >= from;
  const akts = useAllAkts(p.incidentRecords);
  const muz = useMuzDocs(); const muzCfg = useMuzCfg();
  const cProje = useMemo(() => new Set(getProfiles('ORCHARD').filter(o => /C proje/i.test(String(o.fields?.ownership || ''))).map(o => canonicalOrchard(o.name))), [p.references]);

  const d = useMemo(() => {
    const harv = p.harvestRecords.filter(h => inP(h.recordDate || h.timestamp));
    const amb = p.ambarRecords.filter(a => inP(a.acceptanceDate || a.timestamp));
    const sales = p.salesRecords.filter(s => inP((s as any).saleDate || s.timestamp));
    const tests = p.fieldRecords.filter(r => inP(r.timestamp));
    const judged = tests.filter(r => verdict(r) !== 'none');
    const okN = judged.filter(r => verdict(r) === 'ok').length;
    // ürün × aşama
    const byPS = new Map<string, FieldRecord[]>();
    for (const r of tests) { const k = `${(r.product || '—').split(' ')[0]}|${stage(r.testType)}`; byPS.set(k, [...(byPS.get(k) || []), r]); }
    const prod = [...byPS.entries()].map(([k, rs]) => {
      const [pr, st] = k.split('|'); const j = rs.filter(r => verdict(r) !== 'none');
      return { pr, st, n: rs.length, ok: j.length ? Math.round((j.filter(r => verdict(r) === 'ok').length / j.length) * 100) : undefined,
        h: mean(rs.map(r => r.avgHardness).filter(Boolean) as number[]), b: mean(rs.map(r => r.avgBrix).filter(Boolean) as number[]), last: rs.map(r => r.timestamp).sort().pop() };
    }).sort((a, b) => b.n - a.n);
    // bahçe: uygunluk en düşük önce
    const byO = new Map<string, FieldRecord[]>();
    for (const r of tests) { const o = canonicalOrchard(r.orchard || r.location || '—'); byO.set(o, [...(byO.get(o) || []), r]); }
    const orch = [...byO.entries()].map(([o, rs]) => { const j = rs.filter(r => verdict(r) !== 'none'); const bad = j.filter(r => verdict(r) !== 'ok').length;
      return { o, n: rs.length, bad, ok: j.length ? Math.round(((j.length - bad) / j.length) * 100) : undefined, c: cProje.has(o) }; }).sort((a, b) => (a.ok ?? 101) - (b.ok ?? 101) || b.n - a.n);
    // kişi: kim kaç kayıt (test + hasat + depo)
    const byP = new Map<string, { t: number; h: number; a: number }>();
    const add = (n: string | undefined, k: 't' | 'h' | 'a') => { const x = byP.get(n || '—') || { t: 0, h: 0, a: 0 }; x[k]++; byP.set(n || '—', x); };
    tests.forEach(r => add(r.operator, 't')); harv.forEach(r => add(r.operator, 'h')); amb.forEach(r => add(r.operator, 'a'));
    const people = [...byP.entries()].map(([n, x]) => ({ n, ...x, all: x.t + x.h + x.a })).sort((a, b) => b.all - a.all);
    // testi eksik partiler: dönemde hasadı olan, hiç saha testi bağlanmamış
    const tested = new Set([...p.fieldRecords.map(r => r.refId), ...p.harvestRecords.flatMap(h => [h.linkedTestRefId, ...(h.linkedTestRefIds || [])].filter(Boolean) as string[])]);
    const noTest = harv.filter(h => !tested.has(h.refId) && !(h.linkedTestRefIds?.length) && !h.linkedTestRefId).map(h => h.refId);
    const harvPhotos = harv.reduce((s, h) => s + (h.photos?.length || 0), 0);
    return { harvKg: harv.reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0), ambKg: amb.reduce((s, a) => s + (Number(a.acceptedWeightKg) || 0), 0), saleKg: sales.reduce((s, x) => s + (Number(x.totalQuantityKg) || 0), 0),
      tests: tests.length, okPct: judged.length ? Math.round((okN / judged.length) * 100) : undefined, cTests: tests.filter(r => cProje.has(canonicalOrchard(r.orchard || ''))).length,
      prod, orch, people, noTest: [...new Set(noTest)], harvPhotos };
  }, [p, from, cProje]);
  const openAkts = akts.filter(a => !a.done).length;
  const palLate = muz.filter(isPal).filter(x => !x.shippedAt && palWaitH(x) >= muzCfg.waitWarnH).length;

  const tile = (v: string, l: string, tone = '') => <div className={`rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 ${tone}`}><div className="text-lg font-bold tabular-nums">{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>;
  const sec = 'rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3';
  const link = (icon: React.ReactNode, t: string, sub: string, on: () => void) => (
    <li><button type="button" onClick={on} className="w-full flex items-center gap-2.5 py-2 text-left cursor-pointer"><span className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-700 flex items-center justify-center shrink-0">{icon}</span><span className="min-w-0 flex-1"><b className="text-sm block">{t}</b><span className="text-[11px] text-slate-500 block truncate">{sub}</span></span><ChevronRight className="w-4 h-4 text-slate-400" /></button></li>);

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0 flex-1"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Yönetici özeti</h1><p className="text-xs text-slate-500">Tek sayfa · bütün raporlar buradan</p></div>
      </div>
      <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">{([['WEEK', 'Bu hafta'], ['MONTH', 'Bu ay'], ['SEASON', 'Bu yıl']] as const).map(([k, l]) => (
        <button key={k} type="button" onClick={() => setPeriod(k)} className={`min-h-[34px] rounded-lg text-xs font-semibold cursor-pointer ${period === k ? 'bg-white dark:bg-slate-900 shadow-sm' : 'text-slate-600'}`}>{l}</button>))}</div>

      <div className="grid grid-cols-3 gap-2">
        {tile(d.harvKg ? `${t1(d.harvKg)} t` : '—', 'Hasat')}
        {tile(d.ambKg ? `${t1(d.ambKg)} t` : '—', 'Depoya giriş')}
        {tile(d.saleKg ? `${t1(d.saleKg)} t` : '—', 'Satış / sevk')}
        {tile(String(d.tests), `Test${d.okPct !== undefined ? ` · %${d.okPct} uygun` : ''}`, d.okPct !== undefined && d.okPct < 70 ? 'border-amber-300' : '')}
        {tile(String(openAkts), 'Açık akt', openAkts ? 'border-rose-200' : '')}
        {tile(String(palLate), 'Bekleyen palet', palLate ? 'border-amber-300' : '')}
      </div>

      {d.noTest.length > 0 && (
        <section className="rounded-2xl border border-amber-200 bg-amber-50 dark:bg-amber-950/30 px-4 py-2.5">
          <div className="text-xs font-bold text-amber-900 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" />Testi bağlanmamış hasat partisi · {d.noTest.length}</div>
          <div className="flex flex-wrap gap-1 mt-1">{d.noTest.slice(0, 12).map(r => <button key={r} type="button" onClick={() => p.onOpenRef(r)} className="px-2 py-0.5 rounded-full border border-amber-300 bg-white text-[10px] font-mono cursor-pointer">{r}</button>)}</div>
        </section>
      )}

      <section className={sec}>
        <div className="flex items-center justify-between"><h2 className="text-sm font-bold flex items-center gap-1.5"><FlaskConical className="w-4 h-4 text-teal-700" />Testler · geniş analiz</h2>
          <span className="text-[11px] text-slate-500">{d.cTests ? `C proje ${d.cTests}` : ''}</span></div>
        <div className="flex gap-1 mt-1.5">{([['URUN', 'Ürün × aşama'], ['BAHCE', 'Bahçe'], ['KISI', 'Kişi']] as const).map(([k, l]) => (
          <button key={k} type="button" onClick={() => setTab(k)} className={`px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${tab === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{l}</button>))}</div>
        {d.tests === 0 && <p className="text-[11px] text-slate-500 mt-2">Bu dönemde test yok.</p>}
        {tab === 'URUN' && d.prod.length > 0 && (
          <div className="mt-1.5">
            <div className="grid grid-cols-[minmax(0,1fr)_30px_40px_44px_40px] gap-1 text-[9px] font-semibold text-slate-500 py-1 border-b border-slate-100"><span>Ürün · aşama</span><span className="text-right">n</span><span className="text-right">uygun</span><span className="text-right">sertlik</span><span className="text-right">Brix</span></div>
            {d.prod.map(r => (
              <div key={r.pr + r.st} className="grid grid-cols-[minmax(0,1fr)_30px_40px_44px_40px] gap-1 py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0 text-xs tabular-nums items-center">
                <span className="min-w-0 truncate"><b>{r.pr}</b> · {r.st}</span><span className="text-right">{r.n}</span>
                <span className={`text-right font-semibold ${r.ok === undefined ? 'text-slate-400' : r.ok >= 85 ? 'text-emerald-700' : r.ok >= 65 ? 'text-amber-700' : 'text-rose-700'}`}>{r.ok === undefined ? '—' : `%${r.ok}`}</span>
                <span className="text-right">{f1(r.h)}</span><span className="text-right">{f1(r.b)}</span>
              </div>))}
          </div>
        )}
        {tab === 'BAHCE' && d.orch.length > 0 && (
          <ul className="mt-1.5 divide-y divide-slate-100 dark:divide-slate-800">{d.orch.map(r => (
            <li key={r.o} className="flex items-center justify-between gap-2 py-1.5 text-xs"><span className="min-w-0 truncate"><b>{r.o}</b>{r.c ? <span className="ml-1 text-[9px] px-1 rounded border border-violet-200 bg-violet-50 text-violet-800">C proje</span> : null}</span>
              <span className="tabular-nums shrink-0">{r.n} test · <b className={r.ok === undefined ? 'text-slate-400' : r.ok >= 85 ? 'text-emerald-700' : r.ok >= 65 ? 'text-amber-700' : 'text-rose-700'}>{r.ok === undefined ? '—' : `%${r.ok}`}</b>{r.bad ? <span className="text-rose-700"> · {r.bad} sorun</span> : null}</span></li>))}</ul>
        )}
        {tab === 'KISI' && d.people.length > 0 && (
          <div className="mt-1.5">
            <div className="grid grid-cols-[minmax(0,1fr)_36px_36px_36px] gap-1 text-[9px] font-semibold text-slate-500 py-1 border-b border-slate-100"><span>Kişi</span><span className="text-right">test</span><span className="text-right">hasat</span><span className="text-right">depo</span></div>
            {d.people.slice(0, 20).map(r => (
              <div key={r.n} className="grid grid-cols-[minmax(0,1fr)_36px_36px_36px] gap-1 py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0 text-xs tabular-nums"><span className="truncate">{r.n}</span><span className="text-right">{r.t || '·'}</span><span className="text-right">{r.h || '·'}</span><span className="text-right">{r.a || '·'}</span></div>))}
          </div>
        )}
      </section>

      <section className={sec}>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
          {link(<Camera className="w-4 h-4" />, 'Hasat fotoğrafları', `${d.harvPhotos} fotoğraf bu dönemde · galeri`, () => p.onOpenGallery('HARVEST'))}
          {link(<Camera className="w-4 h-4" />, 'Test fotoğrafları', 'saha testleri · galeri', () => p.onOpenGallery('FIELD'))}
          {link(<Users className="w-4 h-4" />, 'Yönetim analizi', 'bahçe ve depo puanı · kişiler · kritik noktalar', () => p.onOpen('MGMT_ANALYSIS'))}
          {link(<FileText className="w-4 h-4" />, 'Rapor merkezi', 'kalite · soğuk zincir · muz · badem · aylık PDF · Excel', () => p.onOpen('REPORTS'))}
          {link(<FileText className="w-4 h-4" />, 'Denetim masası', 'kim, neyi, ne zaman değiştirdi', () => p.onOpen('AUDIT_TRAIL'))}
        </ul>
      </section>
    </div>
  );
}
