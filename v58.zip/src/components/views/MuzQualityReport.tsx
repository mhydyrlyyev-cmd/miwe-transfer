import React, { useMemo, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useMuzDocs, useMuzCfg, muzVerdict, isPal, dayBunches, MUZ_GRADES, type MuzDay } from '../../services/muzDaily';

/**
 * v55 — Muz paketleme kalitesi raporu (rapor merkezi). Sera başına: parti, salkım, kg, sınıf dağılımı,
 * Gaýtadan işlenen oranı (Kadaly sınırları muz ayarlarından), palet ve lojistikte kabul farkı.
 */
const GC: Record<string, string> = { Extra: '#0f766e', Exclusive: '#14b8a6', Premium: '#5eead4', Classic: '#a7f3d0', Mix: '#fcd34d', Iskarta: '#f87171' };
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 });

export default function MuzQualityReport({ onBack }: { onBack: () => void }) {
  const docs = useMuzDocs();
  const cfg = useMuzCfg();
  const [days, setDays] = useState(30);
  const from = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
  const rows = useMemo(() => {
    const ds = docs.filter((d): d is MuzDay => d.kind === 'day' && (d as MuzDay).date >= from);
    const pals = docs.filter(isPal).filter(x => x.coolAt.slice(0, 10) >= from);
    const m = new Map<string, { sera: string; parties: number; bunches: number; kg: number; graded: number; redo: number; g: Record<string, number>; pals: number; boxes: number; recvDiff: number }>();
    for (const d of ds) {
      const r = m.get(d.sera) || { sera: d.sera, parties: 0, bunches: 0, kg: 0, graded: 0, redo: 0, g: {}, pals: 0, boxes: 0, recvDiff: 0 };
      r.parties++; r.bunches += dayBunches(d); r.kg += d.kg || 0;
      const v = muzVerdict(d.grades, cfg);
      if (v) { r.graded++; if (v.decision === 'Gaýtadan işlenen') r.redo++; for (const k of MUZ_GRADES) r.g[k] = (r.g[k] || 0) + (Number(d.grades?.[k]) || 0); }
      m.set(d.sera, r);
    }
    for (const p of pals) {
      const r = m.get(p.sera) || { sera: p.sera, parties: 0, bunches: 0, kg: 0, graded: 0, redo: 0, g: {}, pals: 0, boxes: 0, recvDiff: 0 };
      r.pals++; r.boxes += p.boxes; if (p.receivedAt && p.recvBoxes !== undefined) r.recvDiff += p.boxes - p.recvBoxes; m.set(p.sera, r);
    }
    return [...m.values()].sort((a, b) => b.kg - a.kg);
  }, [docs, cfg, from]);
  const tot = rows.reduce((a, r) => ({ kg: a.kg + r.kg, parties: a.parties + r.parties, graded: a.graded + r.graded, redo: a.redo + r.redo }), { kg: 0, parties: 0, graded: 0, redo: 0 });

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0 flex-1"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Muz paketleme kalitesi</h1><p className="text-xs text-slate-500">Sınıf, Gaýtadan işlenen, palet · son {days} gün</p></div>
        <div className="flex gap-1">{[7, 30, 90].map(d => <button key={d} type="button" onClick={() => setDays(d)} className={`px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${days === d ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{d} g</button>)}</div>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[['Paketlenen', tot.kg ? `${t1(tot.kg)} t` : '—', `${tot.parties} parti`], ['Kalitesi girilen', `${tot.graded} / ${tot.parties}`, 'parti'], ['Gaýtadan işlenen', tot.graded ? `%${Math.round((tot.redo / tot.graded) * 100)}` : '—', `${tot.redo} parti`]].map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-[11px] text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums">{b}</div><div className="text-[10px] text-slate-500">{c}</div></div>))}
      </div>
      {rows.length === 0 && <p className="text-sm text-slate-500">Bu dönemde muz günlük kaydı yok.</p>}
      {rows.map(r => { const gt = Object.values(r.g).reduce((s, x) => s + x, 0); return (
        <section key={r.sera} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-1.5">
          <div className="flex items-center justify-between"><h2 className="text-sm font-bold">{r.sera}</h2><span className="text-xs tabular-nums">{t1(r.kg)} t · {r.parties} parti</span></div>
          {gt > 0 ? (<>
            <div className="flex h-3 rounded overflow-hidden">{MUZ_GRADES.map(k => r.g[k] ? <div key={k} style={{ width: `${(r.g[k] / gt) * 100}%`, background: GC[k] }} title={k} /> : null)}</div>
            <div className="flex flex-wrap gap-x-2 text-[10px] text-slate-600">{MUZ_GRADES.filter(k => r.g[k]).map(k => <span key={k}><span className="inline-block w-2 h-2 rounded-sm mr-0.5" style={{ background: GC[k] }} />{k} %{Math.round((r.g[k] / gt) * 100)}</span>)}</div>
          </>) : <p className="text-[11px] text-amber-700">Kalite (sınıf) girilmemiş.</p>}
          <div className="text-[11px] text-slate-600 dark:text-slate-400">
            {r.graded ? <>Gaýtadan işlenen <b className={r.redo ? 'text-amber-700' : 'text-emerald-700'}>{r.redo} / {r.graded}</b></> : null}
            {r.pals ? ` · ${r.pals} palet · ${r.boxes} kutu` : ''}{r.recvDiff ? <b className="text-rose-700"> · lojistikte {r.recvDiff} kutu eksik</b> : ''}
          </div>
        </section>); })}
      <p className="text-[10px] text-slate-500 px-1">Kadaly sınırı muz ayarlarından: ıskarta ≤ %{cfg.maxIskartaPct}, Classic+Mix ≤ %{cfg.maxLowPct} (yer tutucu — gerçek değerler girilince değişir).</p>
    </div>
  );
}
