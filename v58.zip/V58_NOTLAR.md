# V58 — 1.0 hazırlık (v54–v57 dahil) + Yönetici özeti, galeri süzgeci, kurulum/uyarlama durumu, ölü kod temizliği

## Kopyalanacak 19 dosya
- `src/App.tsx` — `66007949a3f59bc7c00c76089b1f53391c06d6c56e0c32867d5e31392e4b2948`
- `src/types.ts` — `a5842dcd4fde3ffa04fea2693a88f3462a28d51c4cf0112ef8c553d2898c0f36`
- `src/config/almond.ts` — `08079ed12fbaaa38d3833b507cbe3f3efe2a9bdf005618de48c43bfbb952fa68`
- `src/services/muzDaily.ts` — `7aee1598fbaa6c7a8d5f8c15360fc91ec4376d8d391dc900760c90499b28ff8e`
- `src/components/views/MuzPanel.tsx` — `8dd8fae3038b0ceb6ce32db0c76e9cad97dfc838ad98ae3058cd64912f6ef7de`
- `src/components/views/OrchardCardsView.tsx` — `8692c4da1a3cbddbb2ccc780c5552c898937b09ea7c47847691dd9c5c24aedbb`
- `src/components/views/ClimateView.tsx` — `dcec86b9ce663a37518a50d2c0004ab56c092ec05d041b39dd3b9e306a5c4262`
- `src/components/views/ManagementViews.tsx` — `2cde481748f9b51b4e525c926b24caa91c4c091ae44b3b47a15e772911ddfaa6`
- `src/components/views/GalleryView.tsx` — `5d093cfdb0824f97a32fad30380f0db93a468f9c9e7b6648c6152acc8fd3d635`
- `src/components/portal/HomeMenu.tsx` — `5fce187e5e61f42f4d76edca4e1d77bcea30d69f0252b69ec90e55f96b423dea`
- `src/components/forms/QuickTestForm.tsx` — `270937557da54f62ca894c7938a72a98f8ff1ec8918a4e335d0b26205b930b76`
- `src/components/forms/QuickParts.tsx` — `51e19507d8ba68b7443750dcaeb16f7de5abb85fab58f596dac629ac852200cf`
- `src/components/forms/QuickAlmondForm.tsx` — `2f36e3ba07d78a465f665a4c3d667396d6de6500886e286e7880127f3b252da5`
- `src/components/forms/QuickExportForm.tsx` — `e75edbabbc93eb0b4f6a4518a8db31928c933c1949198b14b85d256d657f29ac`
- `src/components/forms/QuickFreezeDryForm.tsx` — `3a5be91abef75aa70dd51452f4001fdcef517e8d9d885fd8787a0d07de74c802`
- `src/components/views/BademFlowView.tsx` — `ad4150aeb83287e1b8b0d5ef727b4f9a87e62a52d2dbce0987a2d0dd1c188574`
- `src/components/views/MuzQualityReport.tsx` — `b09f2a19ee9d9f5fbfaa169cc8ad4b90a0287021ca5b1b06799edea484c7ad71`
- `src/components/views/AuditDesk.tsx` — `9ab2f044539f0f02f3830aeb7ae7a83a87a2a067a7ce98b9783c268e12cd731a`
- `src/components/views/ManagerBrief.tsx` — `94285cee27bf0ae362cee1e0ced01d7eb5f33f5b4086ab80765d5617b6d35ef6`

## SİLİNECEK 4 dosya (hiçbir yerden çağrılmıyor)
- `src/components/common/GlobalPlatformFooter.tsx`
- `src/components/dashboard/HomeSummary.tsx`
- `src/components/dashboard/OpsDashboard.tsx`
- `src/config/orchardLocations.ts`

Yeni (9): config/almond.ts, QuickParts, QuickAlmondForm, QuickExportForm, QuickFreezeDryForm, BademFlowView, MuzQualityReport, AuditDesk, ManagerBrief. Eski formlar ve AuditTrailView silinmez. Firestore kuralı değişmedi. TAM_LISTE: 212.
