import React from 'react';
import { Loader2 } from 'lucide-react';
import { cx } from './cx';

export type ButtonVariant = 'primary' | 'secondary' | 'soft' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md';
/** variant="soft" için renk tonu (açık zemin + aynı tonda yazı) */
export type ButtonTone = 'brand' | 'slate' | 'amber' | 'sky' | 'rose' | 'violet' | 'emerald';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Yalnızca variant="soft" ile: açık renkli zemin tonu */
  tone?: ButtonTone;
  /** Sol ikon (lucide, 16px önerilir) */
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  loading?: boolean;
  fullWidth?: boolean;
}

const VARIANTS: Record<ButtonVariant, string> = {
  // Ekran başına TEK birincil düğme kullanın
  primary: 'bg-brand-primary text-white hover:bg-teal-800 active:bg-teal-900 border border-transparent shadow-sm dark:bg-teal-600 dark:hover:bg-teal-500',
  // v2.6: ikincil düğmeler artık yumuşak marka tonunda (beyaz/renksiz değil)
  secondary: 'bg-teal-50 text-teal-900 border border-teal-200 hover:bg-teal-100 hover:border-teal-300 active:bg-teal-100 dark:bg-teal-950/40 dark:text-teal-100 dark:border-teal-900 dark:hover:bg-teal-900/50',
  soft: '', // tonu TONES belirler
  ghost: 'bg-transparent text-slate-700 border border-transparent hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800',
  danger: 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 hover:border-rose-300 dark:bg-rose-950/40 dark:text-rose-200 dark:border-rose-900 dark:hover:bg-rose-900/40'
};

/** Yumuşak tonlar: açık zemin, ince aynı ton çizgi, koyu aynı ton yazı (WCAG AA) */
const TONES: Record<ButtonTone, string> = {
  brand: 'bg-teal-50 text-teal-900 border border-teal-200 hover:bg-teal-100 dark:bg-teal-950/40 dark:text-teal-100 dark:border-teal-900 dark:hover:bg-teal-900/50',
  emerald: 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-100 dark:border-emerald-900 dark:hover:bg-emerald-900/50',
  slate: 'bg-slate-100 text-slate-800 border border-slate-200 hover:bg-slate-200/70 dark:bg-slate-800 dark:text-slate-100 dark:border-slate-700 dark:hover:bg-slate-700',
  amber: 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 dark:bg-amber-950/40 dark:text-amber-100 dark:border-amber-900 dark:hover:bg-amber-900/40',
  sky: 'bg-sky-50 text-sky-900 border border-sky-200 hover:bg-sky-100 dark:bg-sky-950/40 dark:text-sky-100 dark:border-sky-900 dark:hover:bg-sky-900/40',
  rose: 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100 dark:bg-rose-950/40 dark:text-rose-100 dark:border-rose-900 dark:hover:bg-rose-900/40',
  violet: 'bg-violet-50 text-violet-900 border border-violet-200 hover:bg-violet-100 dark:bg-violet-950/40 dark:text-violet-100 dark:border-violet-900 dark:hover:bg-violet-900/40'
};

const SIZES: Record<ButtonSize, string> = {
  sm: 'min-h-[40px] px-3 text-xs gap-1.5',
  md: 'min-h-[44px] px-4 text-sm gap-2'
};

/**
 * Ortak düğme. Varsayılan type="button" — form gönderen düğmelerde type="submit" verin.
 */
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'secondary', size = 'md', tone = 'brand', icon, iconRight, loading = false, fullWidth = false, className, children, disabled, type, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      type={type ?? 'button'}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx(
        'inline-flex items-center justify-center rounded-xl font-semibold whitespace-nowrap select-none',
        'transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        variant === 'soft' ? TONES[tone] : VARIANTS[variant],
        SIZES[size],
        fullWidth && 'w-full',
        className
      )}
      {...rest}
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : icon ? <span className="inline-flex shrink-0 [&>svg]:w-4 [&>svg]:h-4" aria-hidden="true">{icon}</span> : null}
      {children != null && <span className="truncate">{children}</span>}
      {iconRight && !loading && <span className="inline-flex shrink-0 [&>svg]:w-4 [&>svg]:h-4" aria-hidden="true">{iconRight}</span>}
    </button>
  );
});

export default Button;
