import React from 'react';
import { Check, X } from 'lucide-react';
import { Button } from './Button';
import { cx } from './cx';

export interface SaveBarProps {
  /** Vazgeç düğmesi; verilmezse gösterilmez */
  onCancel?: () => void;
  /** type="submit" ise form gönderir; "button" ise onSave çağrılır */
  saveType?: 'submit' | 'button';
  onSave?: () => void;
  saveLabel?: React.ReactNode;
  cancelLabel?: React.ReactNode;
  saving?: boolean;
  disabled?: boolean;
  /** Mobilde ekranın altına yapışık dursun */
  sticky?: boolean;
  /** Düğmelerin solunda kısa bilgi (ör. "2 alan eksik") */
  note?: React.ReactNode;
  className?: string;
}

/** Formların alt "Kaydet / Vazgeç" çubuğu: tek birincil düğme, sağda. */
export function SaveBar({ onCancel, saveType = 'submit', onSave, saveLabel = 'Kaydet', cancelLabel = 'Vazgeç', saving = false, disabled = false, sticky = true, note, className }: SaveBarProps) {
  return (
    <div
      className={cx(
        'flex items-center justify-end gap-2 border-t border-slate-200 bg-white/95 backdrop-blur px-3 sm:px-4 py-3 dark:bg-slate-900/95 dark:border-slate-800',
        sticky && 'sticky bottom-0 z-10 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))]',
        className
      )}
    >
      {note && <div className="mr-auto text-xs text-slate-600 dark:text-slate-400 min-w-0 truncate">{note}</div>}
      {onCancel && (
        <Button variant="soft" tone="slate" onClick={onCancel} icon={<X />} disabled={saving}>
          {cancelLabel}
        </Button>
      )}
      <Button variant="primary" type={saveType} onClick={saveType === 'button' ? onSave : undefined} loading={saving} disabled={disabled} icon={<Check />}>
        {saveLabel}
      </Button>
    </div>
  );
}

export default SaveBar;
