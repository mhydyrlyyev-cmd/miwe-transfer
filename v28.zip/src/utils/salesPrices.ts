import type { SalesRecord, SalesPriceDoc } from '../types';

/** v2.8 — Satış fiyatları gizliliği: fiyat ve para birimi satış kaydında tutulmaz; yalnızca yöneticinin kaydında. */
export function stripSalePrices(r: SalesRecord): SalesRecord {
  return { ...r, items: (r.items || []).map((it: any) => { const { unitPriceTmt, totalPriceTmt, currency, ...rest } = it; return rest; }) } as SalesRecord;
}

export function extractSalePrices(r: SalesRecord, by: string): SalesPriceDoc | null {
  const items = (r.items || []).map((it: any, index: number) => ({ index, unitPriceTmt: it.unitPriceTmt, totalPriceTmt: it.totalPriceTmt, currency: it.currency }))
    .filter(x => x.unitPriceTmt != null || x.totalPriceTmt != null);
  if (!items.length) return null;
  return JSON.parse(JSON.stringify({ saleId: r.id, refId: r.refId, items, updatedAt: new Date().toISOString(), updatedBy: by }));
}

/** Yönetici ekranları için fiyatları satış kalemlerine geri ekler (yalnızca bellekte). */
export function mergeSalePrices(records: SalesRecord[], prices: Record<string, SalesPriceDoc>): SalesRecord[] {
  return records.map(r => {
    const p = prices[r.id];
    if (!p) return r;
    return { ...r, items: (r.items || []).map((it: any, i: number) => { const x = p.items.find(y => y.index === i); return x ? { ...it, unitPriceTmt: x.unitPriceTmt, totalPriceTmt: x.totalPriceTmt, currency: x.currency } : it; }) } as SalesRecord;
  });
}
