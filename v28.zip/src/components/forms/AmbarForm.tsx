import React, { useState, useEffect, useRef } from 'react';
import {
  Warehouse,
  ArrowLeft,
  Save,
  Scale,
  Thermometer,
  Droplets,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Wind,
  Camera,
  Image as ImageIcon,
  Info,
  Globe2,
  BookOpen,
  Plus,
  Trash2,
  Tag,
  FileText,
  Check,
  AlertCircle,
  X,
  Lock
} from 'lucide-react';
import { AmbarRecord, ReferenceItem, SampleBox } from '../../types';
import { calculateWarehouseFire, generateRefId } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { GostDefectMatrixWidget } from '../common/GostDefectMatrixWidget';
import { GostDefectInput, GostSpreadsheetMetadata, calculateGostDefects } from '../../utils/gostQualityCalculators';
import { IoTDataloggerConnector } from '../iot/IoTDataloggerConnector';
import { PhotoLightboxModal } from '../common/PhotoLightboxModal';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';
import { boxNet, sampleTotals, pieceWeightStats, suggestDecision } from '../../utils/intakeCalc';
import { getProductSpec } from '../../config/productSpecs';
import { nextSequence } from '../../utils/docNumbers';
import { getCurrentUser } from '../../utils/authService';

interface AmbarFormProps {
  onSave: (record: AmbarRecord, refId: string) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  existingAmbar?: AmbarRecord[];
  initialRefId?: string;
  initialRecord?: AmbarRecord;
  isReadOnly?: boolean;
  onOpenIncident?: (prefill: {
    refId: string;
    supplier?: string;
    stage?: string;
    description?: string;
    affectedKg?: number;
  }) => void;
}

export const AmbarForm: React.FC<AmbarFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  existingAmbar = [],
  initialRefId,
  initialRecord,
  isReadOnly = false,
  onOpenIncident
}) => {
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || ''); // v2.8: listedeki ilk parti kendiliğinden seçilmez
  // v2.8: gelen yük — içeriden (mevcut parti) / dışarıdan (yeni parti açılır)
  const [incomingSource, setIncomingSource] = useState<'INTERNAL' | 'EXTERNAL'>(initialRecord?.incomingSource || 'INTERNAL');
  const [extProduct, setExtProduct] = useState(initialRecord?.product || '');
  const [extVariety, setExtVariety] = useState(initialRecord?.variety || '');
  const [extSupplier, setExtSupplier] = useState(initialRecord?.supplier || '');
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Depo Kabul Uzmanı');

  // Selected reference context
  const selectedRef = existingRefs.find(r => r.refId === selectedRefId);

  // Form Fields
  const [acceptanceDate, setAcceptanceDate] = useState(initialRecord?.acceptanceDate || new Date().toISOString().split('T')[0]);
  const [warehouse, setWarehouse] = useState(initialRecord?.warehouse || ''); // v2.7: uydurma depo adı yok
  const [roomNo, setRoomNo] = useState(initialRecord?.roomNo || '');
  const [stackRow, setStackRow] = useState(initialRecord?.stackRow || ''); // v2.7: istif yeri (sıra / raf)
  const [treatmentApplied, setTreatmentApplied] = useState(initialRecord?.treatmentApplied || 'Ön Soğutma (Hydrocooling)');
  const [expectedWeightKg, setExpectedWeightKg] = useState<number>(initialRecord?.expectedWeightKg ?? (selectedRef?.quantity || 4500));
  const [acceptedWeightKg, setAcceptedWeightKg] = useState<number>(initialRecord?.acceptedWeightKg ?? (selectedRef ? Math.round(selectedRef.quantity * 0.995) : 4475));
  // v2.2: ölçümler önceden doldurulmaz — boş alan "ölçülmedi" demektir
  const [productTemperature, setProductTemperature] = useState<number | null>(initialRecord?.productTemperature ?? null);
  const [roomTemperature, setRoomTemperature] = useState<number | null>(initialRecord?.roomTemperature ?? null);
  const [humidityPercent, setHumidityPercent] = useState<number | null>(initialRecord?.humidityPercent ?? null);
  const [co2GasLevelPpm, setCo2GasLevelPpm] = useState<number>(initialRecord?.co2GasLevelPpm ?? 450);
  const [packaging, setPackaging] = useState(initialRecord?.packaging || 'Plastik Kasa (IFCO)');
  const [acceptanceStatus, setAcceptanceStatus] = useState<'ACCEPTED' | 'PARTIAL' | 'REJECTED'>(initialRecord?.acceptanceStatus || 'ACCEPTED');
  const [hygieneStatus, setHygieneStatus] = useState<'Uygun' | 'Uygun Değil'>(initialRecord?.hygieneStatus || 'Uygun');
  const [coldChainStatus, setColdChainStatus] = useState<'Uygun' | 'Kritik Sapma' | 'Uygun Değil'>(initialRecord?.coldChainStatus || 'Uygun');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>(initialRecord?.testStatus || 'COMPLETED');
  const [nextStep, setNextStep] = useState(initialRecord?.nextStep || 'Lojistik / Sevkiyat Hazırlık');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [photos, setPhotos] = useState<string[]>(
    initialRecord?.photos && initialRecord.photos.length > 0
      ? initialRecord.photos
      : []
  );
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);

  // Update when selected Ref changes
  useEffect(() => {
    if (selectedRef) {
      if (selectedRef.quantity) {
        setExpectedWeightKg(selectedRef.quantity);
        setAcceptedWeightKg(Math.round(selectedRef.quantity * 0.995));
      }
    }
  }, [selectedRefId]);

  // Inbound Type & GOST States
  const [inboundType, setInboundType] = useState<'DOMESTIC' | 'IMPORT_EURASIA_GOST' | 'IMPORT_OTHER'>(
    initialRecord?.inboundType || 'DOMESTIC'
  );

  // 1. Kabul Mutabakatı Alanları
  const [brand, setBrand] = useState(initialRecord?.brand || '');
  const [intakeReportNo, setIntakeReportNo] = useState(initialRecord?.intakeReportNo || '');
  const [countryOfOrigin, setCountryOfOrigin] = useState(initialRecord?.countryOfOrigin || ''); // v2.8: uydurma menşe yok

  const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const kabPrefix = `KAB-${todayStr.slice(2, 6)}-`;
  const existingReportNos = React.useMemo(() => {
    return existingAmbar.map(a => a.intakeReportNo || '').filter(Boolean);
  }, [existingAmbar]);
  const [declaredPallets, setDeclaredPallets] = useState<number | ''>(initialRecord?.declaredPallets ?? '');
  const [receivedPallets, setReceivedPallets] = useState<number | ''>(initialRecord?.receivedPallets ?? '');
  const [declaredBoxes, setDeclaredBoxes] = useState<number | ''>(initialRecord?.declaredBoxes ?? '');
  const [receivedBoxes, setReceivedBoxes] = useState<number | ''>(initialRecord?.receivedBoxes ?? '');
  const [damagedPallets, setDamagedPallets] = useState<number | ''>(initialRecord?.damagedPallets ?? '');
  const [damagedBoxes, setDamagedBoxes] = useState<number | ''>(initialRecord?.damagedBoxes ?? '');
  const [packingListCompliant, setPackingListCompliant] = useState<boolean>(initialRecord?.packingListCompliant ?? true);
  const [packingListNote, setPackingListNote] = useState(initialRecord?.packingListNote || '');
  const [weighbridgeGrossKg, setWeighbridgeGrossKg] = useState<number | ''>(initialRecord?.weighbridgeGrossKg ?? '');
  const [weighbridgeTareKg, setWeighbridgeTareKg] = useState<number | ''>(initialRecord?.weighbridgeTareKg ?? '');

  const weighbridgeNetKg = React.useMemo(() => {
    if (weighbridgeGrossKg !== '' && weighbridgeTareKg !== '') {
      return Number(weighbridgeGrossKg) - Number(weighbridgeTareKg);
    }
    return null;
  }, [weighbridgeGrossKg, weighbridgeTareKg]);

  // 2. Numune Kutuları (Sample Boxes)
  const [sampleBoxes, setSampleBoxes] = useState<SampleBox[]>(initialRecord?.sampleBoxes || []);
  const [firmnessUnit, setFirmnessUnit] = useState<'kg/cm2' | 'lb' | 'N'>(initialRecord?.firmnessUnit || 'kg/cm2');
  const [weightsInputs, setWeightsInputs] = useState<Record<number, string>>(() => {
    const map: Record<number, string> = {};
    (initialRecord?.sampleBoxes || []).forEach(b => {
      if (b.pieceWeightsG && b.pieceWeightsG.length > 0) {
        map[b.boxNo] = b.pieceWeightsG.join(', ');
      }
    });
    return map;
  });

  const currentTotals = React.useMemo(() => sampleTotals(sampleBoxes), [sampleBoxes]);

  // 3. Karar & Spesifikasyon Önerisi
  const [intakeDecision, setIntakeDecision] = useState<'KABUL' | 'SARTLI_KABUL' | 'RED' | 'TALEP' | ''>(
    initialRecord?.intakeDecision || ''
  );
  const [intakeDecisionNote, setIntakeDecisionNote] = useState(initialRecord?.intakeDecisionNote || '');

  const productSpec = React.useMemo(() => {
    const pName = selectedRef?.product || 'Avokado';
    return getProductSpec(pName);
  }, [selectedRef]);

  const decisionSuggestion = React.useMemo(() => {
    return suggestDecision(currentTotals, productSpec);
  }, [currentTotals, productSpec]);

  // 4. Fotoğraf Meta (photoMeta)
  const [photoMeta, setPhotoMeta] = useState<Array<{
    index: number;
    boxNo?: number;
    category: 'ARAC' | 'MUHUR' | 'KANTAR' | 'DATALOGGER' | 'SINIF1' | 'MEKANIK' | 'CURUK' | 'YUMUSAK' | 'KESIT' | 'SERTLIK' | 'DIGER';
  }>>(() => {
    return (initialRecord?.photoMeta || []).map((m, idx) => ({ ...m, index: idx }));
  });
  const [currentUploadCategory, setCurrentUploadCategory] = useState<'ARAC' | 'MUHUR' | 'KANTAR' | 'DATALOGGER' | 'SINIF1' | 'MEKANIK' | 'CURUK' | 'YUMUSAK' | 'KESIT' | 'SERTLIK' | 'DIGER'>('ARAC');
  const [currentUploadBoxNo, setCurrentUploadBoxNo] = useState<number | ''>('');

  // 5. Tedarikçi Talebi (DÖF) Aç Modalı
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [claimAffectedKg, setClaimAffectedKg] = useState<number | ''>('');

  const suggestedClaimKg = React.useMemo(() => {
    const net = (weighbridgeNetKg !== null ? weighbridgeNetKg : acceptedWeightKg) || 0;
    const defectPct = (currentTotals.rottenPct + currentTotals.moldPct + currentTotals.coldDamagePct + currentTotals.anthracnosePct) / 100;
    return Math.round(net * defectPct);
  }, [weighbridgeNetKg, acceptedWeightKg, currentTotals]);

  const [gostDefects, setGostDefects] = useState<GostDefectInput>({
    sampleBoxCount: initialRecord?.sampleBoxCount || 16,
    sampleWeightKg: initialRecord?.sampleWeightKg || 58.28,
    internalRotNecrosisKg: initialRecord?.internalRotNecrosisKg || 0,
    obviousRotTheRotIsObviousKg: initialRecord?.obviousRotTheRotIsObviousKg || 0,
    mechanicsKg: initialRecord?.mechanicsKg || 0,
    dilutionTopKg: initialRecord?.dilutionTopKg || 0,
    easyDeformationKg: initialRecord?.easyDeformationKg || 0,
    productName: selectedRef?.product || 'Şeftali'
  });

  const [gostMetadata, setGostMetadata] = useState<GostSpreadsheetMetadata>({
    docTemperature: initialRecord?.docTemperature || '',
    coolingUnitTemperature: initialRecord?.coolingUnitTemperature || '',
    actualTemperature: initialRecord?.actualTemperature || '',
    supplier: initialRecord?.supplier || selectedRef?.source || '',
    transportType: initialRecord?.transportType || 'CPT Frigo Tır',
    batchNumber: initialRecord?.batchNumber || selectedRef?.refId || '',
    category: initialRecord?.category || '1',
    palletCount: initialRecord?.palletCount || 1,
    expertName: initialRecord?.expertName || operator,
    testDate: acceptanceDate
  });

  // Live Fire calculation
  const { diffKg, diffPercent } = calculateWarehouseFire(expectedWeightKg, acceptedWeightKg);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const dataUrl = event.target.result as string;
            setPhotos(prev => {
              const nextIdx = prev.length;
              setPhotoMeta(pMeta => [
                ...pMeta,
                {
                  index: nextIdx,
                  category: currentUploadCategory,
                  boxNo: currentUploadBoxNo !== '' ? Number(currentUploadBoxNo) : undefined
                }
              ]);
              return [...prev, dataUrl];
            });
          }
        };
        reader.readAsDataURL(file);
      });
      e.target.value = '';
    }
  };

  const handleAddBox = () => {
    const nextBoxNo = sampleBoxes.length > 0 ? Math.max(...sampleBoxes.map(b => b.boxNo)) + 1 : 1;
    const newBox: SampleBox = {
      boxNo: nextBoxNo,
      countSize: 20,
      grossG: null,
      tareG: 200,
      netG: null,
      class1: 0,
      mechanical: 0,
      rotten: 0,
      soft: 0,
      internal: 0,
      mold: 0,
      coldDamage: 0,
      anthracnose: 0,
      firmness: null,
      pieceWeightsG: []
    };
    setSampleBoxes(prev => [...prev, newBox]);
  };

  const updateBox = (boxNo: number, field: keyof SampleBox, value: any) => {
    setSampleBoxes(prev => prev.map(b => {
      if (b.boxNo !== boxNo) return b;
      const updated = { ...b, [field]: value };
      if (field === 'grossG' || field === 'tareG') {
        updated.netG = boxNet(updated.grossG, updated.tareG);
      }
      return updated;
    }));
  };

  const removeBox = (boxNo: number) => {
    setSampleBoxes(prev => prev.filter(b => b.boxNo !== boxNo));
    setWeightsInputs(prev => {
      const copy = { ...prev };
      delete copy[boxNo];
      return copy;
    });
  };

  const handleWeightsChange = (boxNo: number, text: string) => {
    setWeightsInputs(prev => ({ ...prev, [boxNo]: text }));
    const parsed = text
      .split(/[,;\s]+/)
      .map(s => parseFloat(s.trim()))
      .filter(n => !isNaN(n) && n > 0);
    updateBox(boxNo, 'pieceWeightsG', parsed);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (productTemperature === null || roomTemperature === null || humidityPercent === null) {
      window.alert('Ürün iç sıcaklığı, oda sıcaklığı ve bağıl nem ölçülüp girilmeden kabul kaydı oluşturulamaz.');
      return;
    }

    if (!warehouse.trim() || !roomNo.trim()) {
      window.alert('Partinin konduğu soğuk depoyu ve odayı seçin.');
      return;
    }

    if (packingListCompliant === false && !packingListNote.trim()) {
      window.alert('Ambalaj listesi uygunsuz ise açıklama girilmesi zorunludur.');
      return;
    }

    if (sampleBoxes.length > 0 && !intakeDecision) {
      window.alert('Numune kutusu girilmiş kabul kayıtlarında nihai kabul kararı seçilmesi zorunludur.');
      return;
    }
    
    let finalRefId = initialRecord?.refId || '';
    if (!finalRefId) {
      if (incomingSource === 'EXTERNAL') {
        // Dışarıdan gelen yük: yeni parti açılır
        if (!extProduct.trim() || !extSupplier.trim()) {
          window.alert('Dışarıdan gelen yük için ürün ve tedarikçi / kaynak girin.');
          return;
        }
        finalRefId = generateRefId('AMBAR', existingRefs.map(r => r.refId));
      } else {
        // Kendi hasadımız: mevcut bir parti seçilmeli
        finalRefId = selectedRefId.trim();
        if (!finalRefId || !existingRefs.some(r => r.refId === finalRefId)) {
          window.alert('Kendi hasadınız için listeden mevcut bir parti seçin. Dışarıdan gelen yük ise "Dışarıdan (yeni parti)" seçin.');
          return;
        }
      }
    }

    const finalOperator = operator.trim() || getCurrentUser()?.fullName || ''; // v2.8: unvan değil kişi
    const gostMetrics = calculateGostDefects(gostDefects);

    let finalIntakeReportNo: string | undefined = intakeReportNo.trim() || undefined;
    if (sampleBoxes.length > 0 && !finalIntakeReportNo) {
      finalIntakeReportNo = nextSequence(existingReportNos, kabPrefix);
    }
    if (finalIntakeReportNo) {
      const otherReportNos = existingAmbar
        .filter(a => !initialRecord || a.id !== initialRecord.id)
        .map(a => a.intakeReportNo || '')
        .filter(Boolean);
      if (otherReportNos.includes(finalIntakeReportNo)) {
        finalIntakeReportNo = nextSequence(otherReportNos, kabPrefix);
      }
    }

    const ambarRecord: AmbarRecord = {
      id: initialRecord?.id || `a-${Date.now()}`,
      refId: finalRefId,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      acceptanceDate,
      warehouse: warehouse.trim(),
      roomNo: roomNo.trim(),
      stackRow: stackRow.trim() || undefined,
      treatmentApplied: treatmentApplied.trim() || 'Standart Depolama',
      expectedWeightKg,
      acceptedWeightKg,
      weightDiffKg: diffKg,
      weightDiffPercent: diffPercent,
      productTemperature: productTemperature as number,
      roomTemperature: roomTemperature as number,
      humidityPercent: humidityPercent as number,
      co2GasLevelPpm,
      packaging: packaging.trim() || 'Standart Kasa',
      acceptanceStatus: (inboundType === 'IMPORT_EURASIA_GOST' && gostMetrics.decision === 'REJECTED_INCIDENT') ? 'REJECTED' : acceptanceStatus,
      hygieneStatus,
      coldChainStatus,
      kaliteSinifi,
      testStatus,
      nextStep: nextStep.trim() || 'Sevkiyat Hazırlık',
      notes,
      photos,

      // GOST & Inbound Fields
      inboundType,
      docTemperature: gostMetadata.docTemperature,
      coolingUnitTemperature: gostMetadata.coolingUnitTemperature,
      actualTemperature: gostMetadata.actualTemperature,
      supplier: gostMetadata.supplier,
      transportType: gostMetadata.transportType,
      batchNumber: gostMetadata.batchNumber,
      category: gostMetadata.category,
      palletCount: Number(gostMetadata.palletCount) || undefined,
      sampleBoxCount: gostDefects.sampleBoxCount,
      sampleWeightKg: gostDefects.sampleWeightKg,
      samplePercent: gostMetrics.samplePercent,
      wastePercent: gostMetrics.wastePercent,
      rotKg: gostMetrics.rotKg,
      rotPercent: gostMetrics.rotPercent,
      internalRotNecrosisKg: gostDefects.internalRotNecrosisKg,
      internalRotNecrosisPercent: gostMetrics.internalRotNecrosisPercent,
      obviousRotTheRotIsObviousKg: gostDefects.obviousRotTheRotIsObviousKg,
      obviousRotTheRotIsObviousPercent: gostMetrics.obviousRotTheRotIsObviousPercent,
      nonStandardKg: gostMetrics.nonStandardKg,
      nonStandardPercent: gostMetrics.nonStandardPercent,
      mechanicsKg: gostDefects.mechanicsKg,
      mechanicsPercent: gostMetrics.mechanicsPercent,
      dilutionTopKg: gostDefects.dilutionTopKg,
      dilutionTopPercent: gostMetrics.dilutionTopPercent,
      easyDeformationKg: gostDefects.easyDeformationKg,
      easyDeformationPercent: gostMetrics.easyDeformationPercent,
      expertName: gostMetadata.expertName,
      gostDecision: gostMetrics.decision,

      // Avrupa / İhracat Standardı & Numune Alanları
      brand: brand.trim() || undefined,
      intakeReportNo: finalIntakeReportNo,
      countryOfOrigin,
      incomingSource: initialRecord?.incomingSource || incomingSource,
      product: incomingSource === 'EXTERNAL' ? (extProduct.trim() || undefined) : (initialRecord?.product || undefined),
      variety: incomingSource === 'EXTERNAL' ? (extVariety.trim() || undefined) : (initialRecord?.variety || undefined),
      declaredPallets: declaredPallets !== '' ? Number(declaredPallets) : undefined,
      receivedPallets: receivedPallets !== '' ? Number(receivedPallets) : undefined,
      declaredBoxes: declaredBoxes !== '' ? Number(declaredBoxes) : undefined,
      receivedBoxes: receivedBoxes !== '' ? Number(receivedBoxes) : undefined,
      damagedPallets: damagedPallets !== '' ? Number(damagedPallets) : undefined,
      damagedBoxes: damagedBoxes !== '' ? Number(damagedBoxes) : undefined,
      packingListCompliant,
      packingListNote: packingListNote.trim() || undefined,
      weighbridgeGrossKg: weighbridgeGrossKg !== '' ? Number(weighbridgeGrossKg) : undefined,
      weighbridgeTareKg: weighbridgeTareKg !== '' ? Number(weighbridgeTareKg) : undefined,
      weighbridgeNetKg: weighbridgeNetKg !== null ? weighbridgeNetKg : undefined,
      firmnessUnit,
      sampleBoxes: sampleBoxes.length > 0 ? sampleBoxes : undefined,
      intakeDecision: intakeDecision || undefined,
      intakeDecisionNote: intakeDecisionNote.trim() || undefined,
      photoMeta: photoMeta.length > 0 ? photoMeta : undefined
    };

    onSave(ambarRecord, finalRefId);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-[#0f4a33] text-white px-6 py-4 flex items-center justify-between border-b border-emerald-950">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
            <Warehouse className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                🏭 Ambar Kabul, Oda Takibi & Soğuk Zincir Modülü
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-900 text-emerald-300 border border-emerald-700">
                Datly Miwe • Depolama
              </span>
            </div>
            <p className="text-xs text-emerald-200/80">
              Kantar tartımı, fire hesabı, oda/ürün sıcaklığı, atmosfer ve uygulama takibi
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-1.5 text-xs font-semibold text-emerald-100 hover:text-white bg-emerald-900/60 hover:bg-emerald-900 px-3 py-1.5 rounded-lg border border-emerald-700 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Hızlı Yardımcı Notlar & Standartlar Kutusu */}
        <div className="bg-emerald-50/90 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-emerald-900">
            <Info className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>💡 Ambar & Soğuk Hava Deposu Rehberi (Kritik Eşikler):</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px] text-emerald-900/90 leading-relaxed">
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Sıcaklık Yönetimi:</strong> Muz ön soğutma 13.5°C - 14.5°C; Badem/Kuru depo 15°C - 18°C; Şoklama -35°C altında tutulmalıdır.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Kantar & Fire Toleransı:</strong> Giriş kantar farkı maksimum ±%1.5 olmalıdır. %2 üzeri sapmalarda fire tutanağı tutulur.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Etilen & Gaz Seviyesi:</strong> Muz depolama odalarında etilen &lt;1 ppm, CO2 seviyesi &lt;5000 ppm olmalıdır.
            </div>
          </div>
        </div>

        {/* v2.8: Gelen yükün kaynağı */}
        {!initialRecord && (
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
            <span className="text-xs font-semibold text-slate-700 block">Gelen yük</span>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Gelen yük">
              {([['INTERNAL', 'İçeriden (kendi hasadımız)'], ['EXTERNAL', 'Dışarıdan (tedarikçi / ithal)']] as const).map(([k, l]) => (
                <button key={k} type="button" role="radio" aria-checked={incomingSource === k} onClick={() => setIncomingSource(k)}
                  className={`min-h-[44px] rounded-xl border px-3 text-xs font-semibold ${incomingSource === k ? 'bg-teal-50 border-teal-600 text-teal-900' : 'bg-white border-slate-300 text-slate-700'}`}>
                  {l}
                </button>
              ))}
            </div>
            {incomingSource === 'EXTERNAL' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Ürün *</label>
                  <input list="ambar-ext-products" value={extProduct} onChange={(e) => setExtProduct(e.target.value)} placeholder="Avokado"
                    className="w-full min-h-[44px] text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3" />
                  <datalist id="ambar-ext-products">
                    {Array.from(new Set(existingRefs.map(r => (r.product || '').replace(/\s*\(.*\)\s*$/, '')).filter(Boolean))).map(p => <option key={p} value={p} />)}
                  </datalist>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Çeşit</label>
                  <input value={extVariety} onChange={(e) => setExtVariety(e.target.value)} placeholder="Fuerte"
                    className="w-full min-h-[44px] text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3" />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tedarikçi / kaynak *</label>
                  <input value={extSupplier} onChange={(e) => { setExtSupplier(e.target.value); setGostMetadata(prev => ({ ...prev, supplier: e.target.value })); }} placeholder="Kado Fresh"
                    className="w-full min-h-[44px] text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3" />
                </div>
                <p className="sm:col-span-2 text-xs text-slate-500">Kaydedince yeni parti numarası (AMBAR-…) açılır; ön soğutma, depo kontrolleri, sevk ve PDF bu numarayla izlenir. Menşe ülkeyi "Kabul mutabakatı" bölümünde girin.</p>
              </div>
            )}
          </div>
        )}

        {/* Selected Reference Selector */}
        {(incomingSource === 'INTERNAL' || initialRecord) && (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1">
              Kabulü / Oda Kontrolü Yapılacak Referans (RefID Seçin veya Yazın)
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                list="ambar-ref-list"
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                placeholder="Örn: REF-101 veya listeden seçin..."
                className="w-full md:w-96 text-xs font-mono font-bold bg-white border border-emerald-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="ambar-ref-list">
                {existingRefs.map(r => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} — {r.product} [{r.quantity} {r.unit}] - {r.status}
                  </option>
                ))}
              </datalist>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs flex-wrap">
            <div className="bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 block font-semibold">Seçili Referans Ürünü</span>
              <strong className="text-slate-800 font-bold">{selectedRef?.product || 'Belirtilmedi'}</strong>
            </div>
            <div className="bg-emerald-950 text-white px-3.5 py-2 rounded-xl border border-emerald-500/50 shadow-sm flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="text-[9px] font-black uppercase text-emerald-300 tracking-wider block">
                  Tamamlanmış Hasat Miktarı (Salt Okunur)
                </span>
                <strong className="font-mono text-emerald-400 text-sm block">
                  {selectedRef?.quantity ? `${Number(selectedRef.quantity).toLocaleString('tr-TR')} kg` : '0 kg'}
                  <span className="text-[10px] text-slate-400 ml-1">
                    ({selectedRef?.quantity ? (Number(selectedRef.quantity) / 1000).toFixed(2) : '0.00'} Ton)
                  </span>
                </strong>
              </div>
            </div>
          </div>
        </div>
        )}

        {/* Inbound Origin & Inspection Mode Selector */}
        <div className="bg-slate-100 p-2 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 px-2 text-xs font-bold text-slate-700">
            <Globe2 className="w-4 h-4 text-teal-600" />
            <span>Kabul Kaynağı &amp; Denetim Standardı:</span>
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setInboundType('DOMESTIC')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                inboundType === 'DOMESTIC'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🚚 Yurtiçi Standart Ambar Kabulü</span>
            </button>

            <button
              type="button"
              onClick={() => setInboundType('IMPORT_EURASIA_GOST')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                inboundType === 'IMPORT_EURASIA_GOST'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🇷🇺 Yurtdışı / İthalat Kabulü (GOST &amp; Avrasya Matrisi)</span>
            </button>
          </div>
        </div>

        {/* If Inbound GOST is active, render GostDefectMatrixWidget */}
        {inboundType === 'IMPORT_EURASIA_GOST' && (
          <div className="p-4 bg-amber-50/30 rounded-2xl border-2 border-amber-300 shadow-xs space-y-3">
            <GostDefectMatrixWidget
              defects={gostDefects}
              onChangeDefects={(upd) => setGostDefects(upd)}
              metadata={gostMetadata}
              onChangeMetadata={(upd) => setGostMetadata(upd)}
              productName={selectedRef?.product || 'Şeftali'}
            />
          </div>
        )}

        {/* General Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Operatör Adı *
            </label>
            <input
              type="text"
              list="operators-list"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
              placeholder="Adınızı giriniz"
             
              className="w-full text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            <datalist id="operators-list">
              {AUTOCOMPLETE_LISTS.operators.map(op => (
                <option key={op} value={op} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Kabul / Kontrol Tarihi
            </label>
            <input
              type="date"
              value={acceptanceDate}
              onChange={(e) => setAcceptanceDate(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Ambar / Depo Tesisi
            </label>
            <input
              type="text"
              list="warehouses-list"
              value={warehouse}
              onChange={(e) => setWarehouse(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="warehouses-list">
              {AUTOCOMPLETE_LISTS.warehouses.map(w => (
                <option key={w} value={w} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Hangi Oda / Hücre (Yerleşim)
            </label>
            <input
              type="text"
              list="rooms-list"
              value={roomNo}
              onChange={(e) => setRoomNo(e.target.value)}
              placeholder="Oda No giriniz veya seçiniz"
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="rooms-list">
              <option value="Oda 1 (Sowuk Depo - 1.0°C)" />
              <option value="Oda 2 (Ön Soğutma - 2.0°C)" />
              <option value="Oda 3 (Atmosfer Kontrollü CA - 0.5°C)" />
              <option value="Muz Olgunlaştırma / Gazlama Odası (14.0°C)" />
              <option value="Kuru Depo 1 (Badem İklimlendirme)" />
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              İstif yeri (sıra / raf)
            </label>
            <input
              type="text"
              value={stackRow}
              onChange={(e) => setStackRow(e.target.value)}
              placeholder="B-2"
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Yapılan Uygulama & İklimlendirme */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Yapılan Uygulama / İşlem (Seçiniz veya yazınız)
            </label>
            <input
              type="text"
              list="treatments-list"
              value={treatmentApplied}
              onChange={(e) => setTreatmentApplied(e.target.value)}
              placeholder="Örn. Ön Soğutma, 1-MCP, Ozonlama..."
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="treatments-list">
              <option value="Ön Soğutma (Hydrocooling / Zorlamalı Hava)" />
              <option value="1-MCP SmartFresh Uygulaması (Etilen Blokajı)" />
              <option value="Ozonlama & Sterilizasyon" />
              <option value="Etilen Gazlama (Muz Olgunlaştırma)" />
              <option value="Fümigasyon & İlaçlama" />
              <option value="Standart Soğuk Muhafaza (0-2°C)" />
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Ambalaj & Palet Durumu
            </label>
            <input
              type="text"
              value={packaging}
              onChange={(e) => setPackaging(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Tartım, Fire & Sıcaklık / Nem Metrikleri */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Scale className="w-4 h-4 text-emerald-700" />
              <span>Kantar Tartımı, Fire & İklim Sensör Değerleri</span>
            </h3>
            <button
              type="button"
              onClick={() => setActivePublicationModal(MDPI_ARTICLES.TEMPERATURE_METABOLISM)}
              className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-900 hover:bg-blue-500/30 text-[10px] font-mono font-bold border border-blue-400/40 transition cursor-pointer flex items-center gap-1"
              title="Horticulturae (Temmuz 2026) Sıcaklık & Hücre Duvarı Metabolizması Makale Atıfı"
            >
              <BookOpen className="w-3 h-3 text-blue-700 shrink-0" />
              <span>[Horticulturae 2026]</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                İrsaliye / Beklenen Ağırlık (kg)
              </label>
              <input
                type="number"
                value={expectedWeightKg}
                onChange={(e) => setExpectedWeightKg(parseFloat(e.target.value) || 0)}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Fiili Kabul Edilen Ağırlık (kg)
              </label>
              <input
                type="number"
                value={acceptedWeightKg}
                onChange={(e) => setAcceptedWeightKg(parseFloat(e.target.value) || 0)}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Ürün İç Sıcaklığı (°C)
              </label>
              <input
                type="number"
                step="0.1"
                value={productTemperature ?? ''}
                placeholder="ölçülmedi"
                onChange={(e) => setProductTemperature(e.target.value === '' ? null : parseFloat(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Oda Sıcaklığı / Nem (% / °C)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  step="0.1"
                  value={roomTemperature ?? ''}
                  onChange={(e) => setRoomTemperature(e.target.value === '' ? null : parseFloat(e.target.value))}
                  placeholder="°C"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="number"
                  value={humidityPercent ?? ''}
                  onChange={(e) => setHumidityPercent(e.target.value === '' ? null : parseFloat(e.target.value))}
                  placeholder="%"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Gerçek Zamanlı Soğuk Depo IoT Sensör & Datalogger Bağlantısı (Sadece ADMIN) */}
          {getCurrentUser()?.role === 'ADMIN' && (
            <div className="pt-2">
              <IoTDataloggerConnector
                moduleName="AMBAR"
                targetTempMin={0.5}
                targetTempMax={2.5}
                onTelemetryUpdate={(data) => {
                  if (data) {
                    setRoomTemperature(data.temperatureC);
                    setHumidityPercent(Math.round(data.humidityPercent));
                    setColdChainStatus(data.isBreached ? 'Kritik Sapma' : 'Uygun');
                  }
                }}
              />
            </div>
          )}

          <div className="bg-white p-3 rounded-lg border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-600">Hesaplanan Fire / Fark:</span>
              <strong className={`font-mono text-sm ${diffKg > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                {diffKg.toFixed(1)} kg (%{diffPercent.toFixed(2)})
              </strong>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-slate-600">Soğuk Zincir Uygunluğu:</span>
              <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                coldChainStatus === 'Uygun' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {coldChainStatus}
              </span>
            </div>
          </div>
        </div>

        {/* 1. Kabul Mutabakatı (İrsaliye & Kantar Uygunluğu) */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/80 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-700" />
                <span>1. Kabul Mutabakatı &amp; Kantar Tartımı</span>
              </h3>
              {sampleBoxes.length > 0 && (
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-emerald-100 text-emerald-900 border border-emerald-300">
                  Rapor No: {intakeReportNo || nextSequence(existingReportNos, kabPrefix)}
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-500 font-semibold">İrsaliye &amp; Fiili Sayım Eşleştirmesi</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Menşei Ülke
              </label>
              <input
                type="text"
                value={countryOfOrigin}
                onChange={(e) => setCountryOfOrigin(e.target.value)}
                placeholder="Örn: Türkiye, Peru, İspanya"
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Marka (Brand)
              </label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="Örn: Frutas del Sol"
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Palet Sayımı (Beyan / Teslim)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={declaredPallets}
                  onChange={(e) => setDeclaredPallets(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Beyan"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="number"
                  value={receivedPallets}
                  onChange={(e) => setReceivedPallets(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Teslim"
                  className={`w-full text-xs font-mono font-bold bg-white border rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500 ${
                    declaredPallets !== '' && receivedPallets !== '' && declaredPallets !== receivedPallets
                      ? 'border-rose-500 text-rose-700 bg-rose-50'
                      : 'border-slate-300'
                  }`}
                />
              </div>
              {declaredPallets !== '' && receivedPallets !== '' && declaredPallets !== receivedPallets && (
                <span className="text-[10px] text-rose-600 font-bold block mt-1">
                  ⚠️ Fark: {Number(receivedPallets) - Number(declaredPallets)} palet
                </span>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Kutu Sayımı (Beyan / Teslim)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={declaredBoxes}
                  onChange={(e) => setDeclaredBoxes(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Beyan"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="number"
                  value={receivedBoxes}
                  onChange={(e) => setReceivedBoxes(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Teslim"
                  className={`w-full text-xs font-mono font-bold bg-white border rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500 ${
                    declaredBoxes !== '' && receivedBoxes !== '' && declaredBoxes !== receivedBoxes
                      ? 'border-rose-500 text-rose-700 bg-rose-50'
                      : 'border-slate-300'
                  }`}
                />
              </div>
              {declaredBoxes !== '' && receivedBoxes !== '' && declaredBoxes !== receivedBoxes && (
                <span className="text-[10px] text-rose-600 font-bold block mt-1">
                  ⚠️ Fark: {Number(receivedBoxes) - Number(declaredBoxes)} kutu
                </span>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Hasarlı Sayım (Palet / Kutu)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={damagedPallets}
                  onChange={(e) => setDamagedPallets(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Hasarlı Palet"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="number"
                  value={damagedBoxes}
                  onChange={(e) => setDamagedBoxes(e.target.value === '' ? '' : parseInt(e.target.value))}
                  placeholder="Hasarlı Kutu"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Kantar Tartımı & Ambalaj Listesi Uygunluğu */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-200">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Kantar Tartımı (Brüt / Dara / Net kg)
              </label>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <input
                    type="number"
                    value={weighbridgeGrossKg}
                    onChange={(e) => setWeighbridgeGrossKg(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    placeholder="Brüt kg"
                    className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[9px] text-slate-500 block text-center mt-0.5">Kantar Brüt</span>
                </div>
                <div>
                  <input
                    type="number"
                    value={weighbridgeTareKg}
                    onChange={(e) => setWeighbridgeTareKg(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    placeholder="Dara kg"
                    className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[9px] text-slate-500 block text-center mt-0.5">Kantar Dara</span>
                </div>
                <div>
                  <div className="w-full text-xs font-mono font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg px-2 py-2 text-center">
                    {weighbridgeNetKg !== null ? `${weighbridgeNetKg.toFixed(1)} kg` : '—'}
                  </div>
                  <span className="text-[9px] text-emerald-700 font-semibold block text-center mt-0.5">Kantar Net</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Ambalaj Listesi &amp; İrsaliye Uygunluğu
              </label>
              <div className="flex items-center gap-3 mt-1">
                <label className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer">
                  <input
                    type="radio"
                    name="packingListCompliant"
                    checked={packingListCompliant === true}
                    onChange={() => setPackingListCompliant(true)}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-emerald-800 font-bold">Uygun</span>
                </label>
                <label className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer">
                  <input
                    type="radio"
                    name="packingListCompliant"
                    checked={packingListCompliant === false}
                    onChange={() => setPackingListCompliant(false)}
                    className="text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-rose-700 font-bold">Uygun Değil</span>
                </label>
              </div>

              {!packingListCompliant && (
                <div className="mt-2">
                  <input
                    type="text"
                    value={packingListNote}
                    onChange={(e) => setPackingListNote(e.target.value)}
                    placeholder="Uygunsuzluk açıklaması zorunludur..."
                    className="w-full text-xs bg-rose-50 border border-rose-300 rounded-lg px-3 py-2 text-rose-900 focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 2. Numune Kutuları (Sample Boxes) */}
        <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-4 shadow-xs">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>2. Numune Kutuları (Sample Boxes)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Kutu bazında net ağırlık, adet boyu, GOST/AB kusur dökümü ve tane ağırlık istatistikleri
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-600">Sertlik Birimi:</span>
                <select
                  value={firmnessUnit}
                  onChange={(e) => setFirmnessUnit(e.target.value as any)}
                  className="text-xs font-bold bg-white border border-slate-300 rounded px-1.5 py-0.5"
                >
                  <option value="kg/cm2">kg/cm²</option>
                  <option value="lb">lb</option>
                  <option value="N">N</option>
                </select>
              </div>

              <button
                type="button"
                onClick={handleAddBox}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer transition shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Numune Kutu Ekle</span>
              </button>
            </div>
          </div>

          {currentTotals.mismatchBoxNos.length > 0 && (
            <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Uyarı:</strong> Kutu {currentTotals.mismatchBoxNos.join(', ')} için girilen kusur adetleri toplamı, kutu meyve adedi (count size) ile uyuşmuyor!
              </span>
            </div>
          )}

          {sampleBoxes.length === 0 ? (
            <div className="p-6 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-300 text-xs">
              Henüz numune kutusu eklenmedi. Avrupa/ihracat kalite kontrolü için yukarıdaki "+ Numune Kutu Ekle" butonunu kullanın.
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-bold text-[11px]">
                    <th className="p-2 text-center w-12">Kutu</th>
                    <th className="p-2 text-center w-16">Adet (Boy)</th>
                    <th className="p-2 text-center w-20">Brüt (g)</th>
                    <th className="p-2 text-center w-16">Dara (g)</th>
                    <th className="p-2 text-center w-20">Net (g)</th>
                    <th className="p-2 text-center w-14 bg-emerald-50 text-emerald-900">Sınıf 1</th>
                    <th className="p-2 text-center w-14">Mekanik</th>
                    <th className="p-2 text-center w-14 bg-rose-50 text-rose-900">Çürük</th>
                    <th className="p-2 text-center w-14">Yumuşak</th>
                    <th className="p-2 text-center w-14">İç Boz.</th>
                    <th className="p-2 text-center w-14">Küf</th>
                    <th className="p-2 text-center w-14">Soğuk</th>
                    <th className="p-2 text-center w-14">Antrak.</th>
                    <th className="p-2 text-center w-16">Sertlik</th>
                    <th className="p-2 min-w-[200px]">Tane Ağırlıkları (g) &amp; İstatistik</th>
                    <th className="p-2 text-center w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {sampleBoxes.map(b => {
                    const stats = pieceWeightStats(b.pieceWeightsG || []);
                    const isMismatch = currentTotals.mismatchBoxNos.includes(b.boxNo);
                    return (
                      <tr key={b.boxNo} className={`hover:bg-slate-50 ${isMismatch ? 'bg-amber-50/40' : ''}`}>
                        <td className="p-2 font-mono font-bold text-center text-slate-800">
                          #{b.boxNo}
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.countSize}
                            onChange={(e) => updateBox(b.boxNo, 'countSize', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono font-bold bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.grossG ?? ''}
                            placeholder="g"
                            onChange={(e) => updateBox(b.boxNo, 'grossG', e.target.value === '' ? null : parseFloat(e.target.value))}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.tareG ?? ''}
                            placeholder="g"
                            onChange={(e) => updateBox(b.boxNo, 'tareG', e.target.value === '' ? null : parseFloat(e.target.value))}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2 text-center font-mono font-bold text-emerald-800 bg-slate-50">
                          {b.netG !== null ? `${b.netG} g` : '—'}
                        </td>
                        <td className="p-2 bg-emerald-50/50">
                          <input
                            type="number"
                            value={b.class1}
                            onChange={(e) => updateBox(b.boxNo, 'class1', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono font-bold text-emerald-700 bg-white border border-emerald-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.mechanical}
                            onChange={(e) => updateBox(b.boxNo, 'mechanical', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2 bg-rose-50/50">
                          <input
                            type="number"
                            value={b.rotten}
                            onChange={(e) => updateBox(b.boxNo, 'rotten', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono font-bold text-rose-700 bg-white border border-rose-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.soft}
                            onChange={(e) => updateBox(b.boxNo, 'soft', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.internal}
                            onChange={(e) => updateBox(b.boxNo, 'internal', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.mold}
                            onChange={(e) => updateBox(b.boxNo, 'mold', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.coldDamage}
                            onChange={(e) => updateBox(b.boxNo, 'coldDamage', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={b.anthracnose}
                            onChange={(e) => updateBox(b.boxNo, 'anthracnose', parseInt(e.target.value) || 0)}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.1"
                            value={b.firmness ?? ''}
                            placeholder={firmnessUnit}
                            onChange={(e) => updateBox(b.boxNo, 'firmness', e.target.value === '' ? null : parseFloat(e.target.value))}
                            className="w-full text-center font-mono bg-white border border-slate-300 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={weightsInputs[b.boxNo] ?? (b.pieceWeightsG?.join(', ') || '')}
                            onChange={(e) => handleWeightsChange(b.boxNo, e.target.value)}
                            placeholder="Örn: 204, 198, 186..."
                            className="w-full text-xs font-mono bg-white border border-slate-300 rounded px-2 py-1"
                          />
                          {stats.n > 0 && (
                            <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-600 font-mono">
                              <span>n:{stats.n}</span>
                              <span>Min:{stats.min}g</span>
                              <span>Ort:{stats.mean.toFixed(1)}g</span>
                              <span>Maks:{stats.max}g</span>
                              <span className="font-bold text-emerald-700">CV:%{stats.cvPct.toFixed(1)}</span>
                            </div>
                          )}
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => removeBox(b.boxNo)}
                            className="text-slate-400 hover:text-rose-600 transition p-1 cursor-pointer"
                            title="Kutuyu Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-800 text-[11px]">
                    <td className="p-2 text-center font-mono">TOPLAM / ORT.</td>
                    <td className="p-2 text-center font-mono">{currentTotals.totalFruits} adet</td>
                    <td className="p-2 text-center font-mono">{currentTotals.avgGross !== null ? `${currentTotals.avgGross.toFixed(0)}g` : '—'}</td>
                    <td className="p-2 text-center font-mono">{currentTotals.avgTare !== null ? `${currentTotals.avgTare.toFixed(0)}g` : '—'}</td>
                    <td className="p-2 text-center font-mono text-emerald-800">{currentTotals.avgNet !== null ? `${currentTotals.avgNet.toFixed(1)}g` : '—'}</td>
                    <td className="p-2 text-center font-mono text-emerald-700 bg-emerald-100/60">%{currentTotals.class1Pct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.mechanicalPct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono text-rose-700 bg-rose-100/60">%{currentTotals.rottenPct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.softPct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.internalPct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.moldPct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.coldDamagePct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">%{currentTotals.anthracnosePct.toFixed(1)}</td>
                    <td className="p-2 text-center font-mono">{currentTotals.avgFirmness !== null ? `${currentTotals.avgFirmness.toFixed(1)}` : '—'}</td>
                    <td colSpan={2} className="p-2 text-slate-600 text-[10px]">
                      Örnekleme: {sampleBoxes.length} kutu • Toplam {currentTotals.totalFruits} meyve
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>

        {/* 3. Karar & Spesifikasyon Uygunluğu & DÖF (Claim) */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Tag className="w-4 h-4 text-emerald-700" />
              <span>3. Kabul Kararı &amp; Tedarikçi Talebi</span>
            </h3>
            {decisionSuggestion && (
              <span className={`px-2.5 py-1 rounded-lg text-xs font-extrabold flex items-center gap-1 ${
                decisionSuggestion.decision === 'KABUL'
                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  : 'bg-rose-100 text-rose-900 border border-rose-300'
              }`}>
                {decisionSuggestion.decision === 'KABUL' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />}
                <span>Spesifikasyon Önerisi: {decisionSuggestion.decision}</span>
              </span>
            )}
          </div>

          {/* Spesifikasyon Uyarıları */}
          {decisionSuggestion && decisionSuggestion.reasons.length > 0 && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1">
              <strong className="block text-rose-800 font-bold">⚠️ Tespit Edilen Eşik Aşımı / Kusur Gerekçeleri:</strong>
              <ul className="list-disc pl-5 space-y-0.5 text-[11px]">
                {decisionSuggestion.reasons.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Nihai Kabul / Muayene Kararı *
              </label>
              <select
                value={intakeDecision}
                onChange={(e) => setIntakeDecision(e.target.value as any)}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">Seçiniz...</option>
                <option value="KABUL">KABUL (Şartsız Uygun)</option>
                <option value="SARTLI_KABUL">ŞARTLI KABUL</option>
                <option value="TALEP">TALEP (Tedarikçi Talebi / Claim)</option>
                <option value="RED">RED (Kabul Edilmedi)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Sonraki Adım (Seçiniz veya yazınız)
              </label>
              <input
                type="text"
                list="ambar-next-steps"
                value={nextStep}
                onChange={(e) => setNextStep(e.target.value)}
                placeholder="Seçiniz veya yazınız"
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="ambar-next-steps">
                <option value="Soğuk Muhafaza & Sevkiyat Planlama" />
                <option value="Gazlama Odasına Transfer" />
                <option value="Boylama & Paketleme Hattına Sevk" />
                <option value="İhracat Yüklemesine Sevk" />
                <option value="Karantina / Numune İnceleme" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Referans İşlem Durumu
              </label>
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setTestStatus('ACTIVE')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'ACTIVE'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Aktif (İşlemde)
                </button>
                <button
                  type="button"
                  onClick={() => setTestStatus('COMPLETED')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'COMPLETED'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Tamamlandı
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Kabul Karar Notu &amp; Açıklaması
            </label>
            <textarea
              rows={2}
              value={intakeDecisionNote}
              onChange={(e) => setIntakeDecisionNote(e.target.value)}
              placeholder="Kabul / talep / red kararı gerekçesi ve aksiyon notları..."
              className="w-full text-xs bg-white border border-slate-300 rounded-lg p-3 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* DÖF / Tedarikçi Talebi Aç Butonu */}
          {(intakeDecision === 'RED' || intakeDecision === 'TALEP') && onOpenIncident && (
            <div className="pt-2 flex items-center justify-between bg-rose-50 border border-rose-200 rounded-xl p-3">
              <div className="text-xs text-rose-900">
                <strong>Tedarikçi Talebi Gerekiyor:</strong> Kabul kararı RED veya TALEP olarak belirlendi.
              </div>
              <button
                type="button"
                onClick={() => {
                  setClaimAffectedKg(suggestedClaimKg);
                  setShowClaimModal(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-extrabold shadow-sm transition cursor-pointer"
              >
                <AlertCircle className="w-4 h-4" />
                <span>🚨 Tedarikçi Talebi (DÖF) Aç</span>
              </button>
            </div>
          )}
        </div>

        {/* Notlar & Gözlemler */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Notlar & Depo Gözlemleri
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Kasa durumu, palet şeritleri, forklift istifleme notları..."
            className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-3 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        {/* Fotoğraf Ekleme & Kategori/Kutu Etiketleme */}
        <div className="border-t border-slate-200 pt-4 space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <label className="block text-xs font-bold text-slate-700">
              Fotoğraf Kanıtı Ekle (Kategori &amp; Kutu No Etiketli)
            </label>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-slate-600">Yüklenecek Kategori:</span>
              <select
                value={currentUploadCategory}
                onChange={(e) => setCurrentUploadCategory(e.target.value as any)}
                className="text-xs font-bold bg-white border border-slate-300 rounded-lg px-2 py-1"
              >
                <option value="ARAC">Araç &amp; Römork</option>
                <option value="MUHUR">Konteyner Mührü</option>
                <option value="KANTAR">Kantar Fişi</option>
                <option value="DATALOGGER">Datalogger Cihazı</option>
                <option value="SINIF1">Sınıf 1 (Kusursuz)</option>
                <option value="MEKANIK">Mekanik Hasar</option>
                <option value="CURUK">Çürük / Çürüklük</option>
                <option value="YUMUSAK">Yumuşama / Ezik</option>
                <option value="KESIT">Meyve Kesiti</option>
                <option value="SERTLIK">Sertlik / Penetrometre</option>
                <option value="DIGER">Diğer</option>
              </select>

              <input
                type="number"
                value={currentUploadBoxNo}
                onChange={(e) => setCurrentUploadBoxNo(e.target.value === '' ? '' : parseInt(e.target.value))}
                placeholder="Kutu No (Ops.)"
                className="w-24 text-xs bg-white border border-slate-300 rounded-lg px-2 py-1 text-center"
              />
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer transition shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Fotoğraf Çek</span>
            </button>

            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition shadow-2xs"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>Galeriden Seç</span>
            </button>

            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleAddPhoto}
              className="hidden"
            />

            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleAddPhoto}
              className="hidden"
            />

            {photos.filter(p => p && p.length > 20).map((p, idx) => {
              const meta = photoMeta.find(m => m.index === idx);
              return (
                <div
                  key={idx}
                  onClick={() => setLightboxIndex(idx)}
                  className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-300 shadow-sm group cursor-pointer hover:border-emerald-500 transition"
                  title="Tam ekran önizlemek veya silmek için dokunun"
                >
                  <img src={p} alt={`Ambar Foto ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition" />
                  <div className="absolute top-1 left-1 right-1 flex items-center justify-between">
                    <span className="px-1 py-0.5 rounded text-[8px] font-extrabold uppercase bg-black/70 text-white truncate max-w-[70px]">
                      {meta?.category || 'FOTO'}
                    </span>
                    {meta?.boxNo !== undefined && (
                      <span className="px-1 py-0.5 rounded text-[8px] font-extrabold bg-emerald-700 text-white">
                        #{meta.boxNo}
                      </span>
                    )}
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1">
                    <span className="p-1 bg-white text-slate-800 rounded-md text-[9px] font-bold">Önizle</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Submit */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition cursor-pointer`}
          >
            <Save className="w-4 h-4" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'KAYDET VE İLERLET'}</span>
          </button>
        </div>
        </fieldset>

      </form>

      {/* DÖF Tedarikçi Talebi Modalı */}
      {showClaimModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2 text-rose-700 font-extrabold text-sm">
                <AlertCircle className="w-5 h-5" />
                <span>Tedarikçi Talebi (DÖF) Başlat</span>
              </div>
              <button
                type="button"
                onClick={() => setShowClaimModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Parti / Ref ID:</span>
                  <strong className="font-mono text-slate-800">{selectedRefId}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Tedarikçi:</span>
                  <strong className="text-slate-800">{gostMetadata.supplier || selectedRef?.source || 'Belirtilmedi'}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Kabul Kararı:</span>
                  <span className="font-bold text-rose-700">{intakeDecision}</span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Etkilenen Fire / Kusurlu Net Miktar (kg):
                </label>
                <input
                  type="number"
                  value={claimAffectedKg}
                  onChange={(e) => setClaimAffectedKg(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="Hesaplanan kg"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-rose-500"
                />
                <span className="text-[10px] text-slate-500 block mt-0.5">
                  Önerilen (Çürük/Bozuk orantılı): {suggestedClaimKg} kg
                </span>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-[11px] text-amber-900 leading-relaxed">
                Bu işlem onaylandığında Düzeltici ve Önleyici Faaliyet (Incident/DÖF) modülüne otomatik olarak yönlendirileceksiniz ve talep ön bilgileri aktarılacaktır.
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t">
              <button
                type="button"
                onClick={() => setShowClaimModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100"
              >
                Vazgeç
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onOpenIncident) {
                    onOpenIncident({
                      refId: selectedRefId,
                      supplier: gostMetadata.supplier || selectedRef?.source,
                      stage: 'AMBAR',
                      description: `[Avrupa Standardı Muayene Talebi] ${selectedRefId} partisinde kabul denetiminde kusurlar tespit edildi: ${decisionSuggestion?.reasons.join('; ') || intakeDecisionNote || 'Kusur oranı yüksek'}. Karar: ${intakeDecision}`,
                      affectedKg: claimAffectedKg !== '' ? Number(claimAffectedKg) : suggestedClaimKg
                    });
                  }
                  setShowClaimModal(false);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold shadow-sm"
              >
                DÖF Oluştur ve Aktar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full-Screen Photo Lightbox Modal */}
      <PhotoLightboxModal
        isOpen={lightboxIndex !== null}
        photoUrl={lightboxIndex !== null ? photos[lightboxIndex] : null}
        photoIndex={lightboxIndex ?? 0}
        totalPhotos={photos.length}
        title={`Ambar Kabul Fotoğrafı #${(lightboxIndex ?? 0) + 1}`}
        onClose={() => setLightboxIndex(null)}
        onDelete={(idx) => {
          setPhotos(prev => prev.filter((_, i) => i !== idx));
          setPhotoMeta(prev => {
            return prev
              .filter(m => m.index !== idx)
              .map(m => (m.index > idx ? { ...m, index: m.index - 1 } : m));
          });
          if (photos.length <= 1) {
            setLightboxIndex(null);
          } else if (idx >= photos.length - 1) {
            setLightboxIndex(Math.max(0, photos.length - 2));
          }
        }}
        onPrev={lightboxIndex !== null && lightboxIndex > 0 ? () => setLightboxIndex(prev => (prev !== null ? prev - 1 : 0)) : undefined}
        onNext={lightboxIndex !== null && lightboxIndex < photos.length - 1 ? () => setLightboxIndex(prev => (prev !== null ? prev + 1 : 0)) : undefined}
      />

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
