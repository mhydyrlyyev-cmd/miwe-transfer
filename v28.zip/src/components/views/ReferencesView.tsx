import React, { useState, useMemo } from 'react';
import { Archive, Search, Filter, Eye, Truck, Warehouse, AlertTriangle, ArrowUpRight, CheckCircle2, Clock, Calendar, Download, Printer, FileText, Trash2, AlertCircle, Edit3, Split, Snowflake, Layers, Image as ImageIcon, X, ExternalLink, ArrowUpDown, BellRing, Cloud, CloudCheck, CloudOff, RefreshCw, ShieldAlert, ShieldCheck, Sparkles, FileSpreadsheet, ChevronDown, Check, StickyNote, QrCode, Link2 } from 'lucide-react';
import { ReferenceItem, ModuleKey, AmbarRecord, LojistikRecord, SalesRecord, FieldRecord, HarvestRecord, MuzRecord, BademRecord } from '../../types';
import { CriticalStockAlertCard } from '../dashboard/CriticalStockAlertCard';
import { evaluateBatchQualityRisk, BatchQualityRiskAssessment } from '../../utils/qualityStandards';
import { BulkStatusUpdateModal } from '../modals/BulkStatusUpdateModal';
import { QuickAdminNoteModal } from '../modals/QuickAdminNoteModal';
import { QrCodeModal } from '../modals/QrCodeModal';
import { BulkRejectModal } from '../modals/BulkRejectModal';
import { addNotification } from '../../utils/notificationService';
import { ReferenceStatus } from '../../types';
import { exportFilteredReferences, ExportFormat } from '../../utils/exportHelpers';
import { Button, Card, Badge } from '../ui';

import { isTestReference } from '../../utils/refKind';
interface ReferencesViewProps {
  /** v2.8: ön soğutma fişi (%5 inspeksiyon + şoklama) */
  onOpenPrecooling?: (ref: ReferenceItem) => void;
  /** v2.8: referans zinciri (test → hasat → fiş → depo → çıkış) */
  onOpenChain?: (ref: ReferenceItem) => void;
  references: ReferenceItem[];
  fieldRecords?: FieldRecord[];
  harvestRecords?: HarvestRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  ambarRecords?: AmbarRecord[];
  lojistikRecords?: LojistikRecord[];
  salesRecords?: SalesRecord[];
  offlineQueue?: Array<{ action: string; payload: any }>;
  onOpenTraceability: (ref: ReferenceItem) => void;
  onDispatch: (refId: string) => void;
  onReceive: (refId: string) => void;
  onOpenIncident: (refId: string) => void;
  onEditReference?: (ref: ReferenceItem) => void; // Madde 3: Düzenleme (Edit)
  onDeleteReference?: (refId: string) => void;
  onAddAdminNote?: (
    refId: string,
    noteText: string,
    options?: {
      category?: string;
      priority?: 'NORMAL' | 'WARNING' | 'CRITICAL';
      operator?: string;
      append?: boolean;
    }
  ) => void;
  onBulkUpdateReferences?: (
    refIds: string[],
    newStatus: ReferenceStatus,
    options: { notes?: string; isLocked?: boolean; operator?: string }
  ) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onSelectModule?: (moduleKey: ModuleKey, action?: 'NEW' | 'EXISTING') => void;
  onOpenAnalytics?: () => void;
  title?: string;
  subtitle?: string;
  isRecentLedger?: boolean;
  onViewAll?: () => void;
  totalRefCount?: number;
  completedRefCount?: number;
  currentUserId?: string;
  isReadOnlyUser?: boolean;
  onSyncSingleQueueItem?: (item: any) => Promise<void> | void;
}

export const ReferencesView: React.FC<ReferencesViewProps> = ({
  onOpenPrecooling,
  onOpenChain,
  references,
  fieldRecords = [],
  harvestRecords = [],
  muzRecords = [],
  bademRecords = [],
  ambarRecords,
  lojistikRecords,
  salesRecords,
  offlineQueue = [],
  onOpenTraceability,
  onDispatch,
  onReceive,
  onOpenIncident,
  onEditReference,
  onDeleteReference,
  onAddAdminNote,
  onBulkUpdateReferences,
  onRerouteToFreezeDry,
  onSelectModule,
  onOpenAnalytics,
  title,
  subtitle,
  isRecentLedger = false,
  onViewAll,
  totalRefCount,
  completedRefCount,
  currentUserId,
  isReadOnlyUser = false,
  onSyncSingleQueueItem
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterModule, setFilterModule] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterProductType, setFilterProductType] = useState<string>('ALL');
  const [filterHarvestPeriod, setFilterHarvestPeriod] = useState<string>('ALL');
  const [filterQualityRisk, setFilterQualityRisk] = useState<'ALL' | 'CRITICAL' | 'WARNING' | 'SAFE'>('ALL');
  const [filterSync, setFilterSync] = useState<'ALL' | 'PENDING' | 'SYNCED'>('ALL');
  const [sortBy, setSortBy] = useState<'DATE_DESC' | 'DATE_ASC' | 'REF_ID_ASC' | 'REF_ID_DESC' | 'PRODUCT'>('DATE_DESC');
  // v2.8: Tür (parti / test), "Diğer filtreler" paneli ve sayfalama
  const [filterKind, setFilterKind] = useState<'ALL' | 'LOT' | 'TEST'>('ALL');
  const [filterArchive, setFilterArchive] = useState<'HIDE' | 'SHOW' | 'ONLY'>('HIDE'); // v2.8
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const PAGE_SIZE = 20;
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const baseProduct = (p?: string) => (p || '').replace(/\s*\(.*\)\s*$/, '').trim();
  const [refToDelete, setRefToDelete] = useState<ReferenceItem | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [previewPhoto, setPreviewPhoto] = useState<{ url: string; title: string } | null>(null);
  const [showStockAlerts, setShowStockAlerts] = useState<boolean>(false);
  const [showBananaQualityStandards, setShowBananaQualityStandards] = useState<boolean>(!isRecentLedger);
  const [tableDensity, setTableDensity] = useState<'COMFORTABLE' | 'COMPACT'>('COMFORTABLE');
  const [expandedCardIds, setExpandedCardIds] = useState<Set<string>>(new Set());

  const toggleExpandCard = (refId: string) => {
    setExpandedCardIds(prev => {
      const next = new Set(prev);
      if (next.has(refId)) next.delete(refId);
      else next.add(refId);
      return next;
    });
  };

  // Toplu Seçim & Güncelleme State
  const [selectedRefIds, setSelectedRefIds] = useState<Set<string>>(new Set());
  const [isBulkUpdateModalOpen, setIsBulkUpdateModalOpen] = useState(false);
  const [isBulkRejectModalOpen, setIsBulkRejectModalOpen] = useState(false);
  const [qrModalRef, setQrModalRef] = useState<ReferenceItem | null>(null);

  const handleConfirmBulkReject = (reason: string) => {
    const targetRefIds = Array.from(selectedRefIds);
    if (targetRefIds.length === 0) return;

    if (onBulkUpdateReferences) {
      onBulkUpdateReferences(targetRefIds, 'REJECTED', {
        notes: `🔴 TOPLU RET NEDENİ: ${reason}`,
        isLocked: true,
        operator: currentUserId || 'Yönetici Denetim'
      });
    }

    addNotification(
      'ALL',
      `🔴 TOPLU RET BAYRAĞI KOYULDU (${targetRefIds.length} Parti)`,
      `${targetRefIds.length} adet parti reddedildi (REJECTED). Nedeni: ${reason}. Partiler kilitlendi.`,
      'CRITICAL_ALERT',
      '/references',
      { priority: 'CRITICAL' }
    );

    setSelectedRefIds(new Set());
    setIsBulkRejectModalOpen(false);
  };

  const handleToggleSelect = (refId: string) => {
    setSelectedRefIds(prev => {
      const next = new Set(prev);
      if (next.has(refId)) next.delete(refId);
      else next.add(refId);
      return next;
    });
  };

  const handleToggleSelectAll = (visibleItems: ReferenceItem[]) => {
    setSelectedRefIds(prev => {
      const allSelected = visibleItems.every(r => prev.has(r.refId));
      if (allSelected) {
        const next = new Set(prev);
        visibleItems.forEach(r => next.delete(r.refId));
        return next;
      } else {
        const next = new Set(prev);
        visibleItems.forEach(r => next.add(r.refId));
        return next;
      }
    });
  };

  const handleClearSelection = () => {
    setSelectedRefIds(new Set());
  };

  const selectedItemsList = useMemo(() => {
    return references.filter(r => selectedRefIds.has(r.refId));
  }, [references, selectedRefIds]);

  // Dinamik benzersiz ürün tipleri listesi
  const availableProductTypes = useMemo(() => {
    // v2.8: yalnızca kayıtlarda bulunan ürünler; "Hurma (Hachiya)" → "Hurma"
    const set = new Set<string>();
    references.forEach(r => { const b = (r.product || '').replace(/\s*\(.*\)\s*$/, '').trim(); if (b) set.add(b); });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'tr'));
  }, [references]);

  // Quality Insight Risk Haritası
  const qualityRiskMap = useMemo(() => {
    const map = new Map<string, BatchQualityRiskAssessment>();
    if (!fieldRecords || fieldRecords.length === 0) return map;
    const refMap = new Map<string, ReferenceItem>();
    references.forEach(r => refMap.set(r.refId, r));
    fieldRecords.forEach(rec => {
      const ref = refMap.get(rec.refId);
      const assessment = evaluateBatchQualityRisk(rec, ref);
      map.set(rec.refId, assessment);
    });
    return map;
  }, [fieldRecords, references]);

  // Risk İstatistikleri
  const riskStats = useMemo(() => {
    let critical = 0;
    let warning = 0;
    let safe = 0;
    qualityRiskMap.forEach(assessment => {
      if (assessment.riskLevel === 'CRITICAL') critical++;
      else if (assessment.riskLevel === 'WARNING') warning++;
      else if (assessment.riskLevel === 'SAFE') safe++;
    });
    return { critical, warning, safe, total: qualityRiskMap.size };
  }, [qualityRiskMap]);

  // Helper to check if a reference is waiting in offline queue for server push
  const isItemPendingSync = (refId: string) => {
    return offlineQueue.some(q => {
      const p = q.payload;
      if (!p) return false;
      if (p.refId === refId) return true;
      if (p.record && p.record.refId === refId) return true;
      if (p.newRefData && p.newRefData.refId === refId) return true;
      if (p.id === refId) return true;
      return false;
    });
  };

  const getPendingQueueItem = (refId: string) => {
    return offlineQueue.find(q => {
      const p = q.payload;
      if (!p) return false;
      return p.refId === refId || p.record?.refId === refId || p.newRefData?.refId === refId || p.id === refId;
    });
  };

  const pendingCount = useMemo(() => {
    return references.filter(r => isItemPendingSync(r.refId)).length;
  }, [references, offlineQueue]);

  const filtered = references.filter(r => {
    const matchesSearch = 
      (r.refId || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.product || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.location || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.orchard && r.orchard.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.operator && r.operator.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesModule = filterModule === 'ALL' || r.moduleKey === filterModule;
    const matchesStatus = filterStatus === 'ALL' || r.status === filterStatus;
    
    const isPending = isItemPendingSync(r.refId);
    const matchesSync = 
      filterSync === 'ALL' || 
      (filterSync === 'PENDING' && isPending) || 
      (filterSync === 'SYNCED' && !isPending);

    const risk = qualityRiskMap.get(r.refId);
    const matchesRisk =
      filterQualityRisk === 'ALL' ||
      (filterQualityRisk === 'CRITICAL' && risk?.riskLevel === 'CRITICAL') ||
      (filterQualityRisk === 'WARNING' && risk?.riskLevel === 'WARNING') ||
      (filterQualityRisk === 'SAFE' && risk?.riskLevel === 'SAFE');

    // Ürün Tipi Filtresi
    const matchesProductType =
      filterProductType === 'ALL' ||
      baseProduct(r.product).toLocaleLowerCase('tr') === filterProductType.toLocaleLowerCase('tr');
    const matchesKind = filterKind === 'ALL' || (filterKind === 'TEST' ? isTestReference(r) : !isTestReference(r));
    const matchesArchive = filterArchive === 'SHOW' || (filterArchive === 'ONLY' ? !!r.archived : !r.archived);

    // Hasat Dönemi Canlı Filtresi
    const matchesHarvestPeriod = (() => {
      if (filterHarvestPeriod === 'ALL') return true;
      const dateStr = r.createdAt || (r as any).timestamp;
      if (!dateStr) return true;
      const recordDate = new Date(dateStr).getTime();
      if (isNaN(recordDate)) return true;
      const now = Date.now();
      const diffDays = (now - recordDate) / (1000 * 60 * 60 * 24);

      if (filterHarvestPeriod === 'TODAY') return diffDays <= 1;
      if (filterHarvestPeriod === 'THIS_WEEK') return diffDays <= 7;
      if (filterHarvestPeriod === 'THIS_MONTH') return diffDays <= 30;
      if (filterHarvestPeriod === 'LAST_90_DAYS') return diffDays <= 90;

      const month = new Date(recordDate).getMonth(); // 0-indexed (0: Jan .. 11: Dec)
      if (filterHarvestPeriod === 'SPRING') return month >= 2 && month <= 4; // Mar, Apr, May
      if (filterHarvestPeriod === 'SUMMER') return month >= 5 && month <= 7; // Jun, Jul, Aug
      if (filterHarvestPeriod === 'AUTUMN') return month >= 8 && month <= 10; // Sep, Oct, Nov
      if (filterHarvestPeriod === 'WINTER') return month === 11 || month === 0 || month === 1; // Dec, Jan, Feb
      return true;
    })();

    return matchesSearch && matchesModule && matchesStatus && matchesSync && matchesRisk && matchesProductType && matchesHarvestPeriod && matchesKind && matchesArchive;
  });

  React.useEffect(() => { setVisibleCount(PAGE_SIZE); }, [searchTerm, filterModule, filterStatus, filterProductType, filterHarvestPeriod, filterSync, filterQualityRisk, filterKind, filterArchive, sortBy]);
  const moreFiltersActive = [filterModule !== 'ALL', filterStatus !== 'ALL', filterSync !== 'ALL', sortBy !== 'DATE_DESC', filterArchive !== 'HIDE'].filter(Boolean).length;
  const anyFilterActive = !!searchTerm || filterKind !== 'ALL' || filterProductType !== 'ALL' || filterHarvestPeriod !== 'ALL' || filterQualityRisk !== 'ALL' || moreFiltersActive > 0;
  const clearAllFilters = () => {
    setSearchTerm(''); setFilterKind('ALL'); setFilterModule('ALL'); setFilterStatus('ALL'); setFilterProductType('ALL');
    setFilterHarvestPeriod('ALL'); setFilterSync('ALL'); setFilterQualityRisk('ALL'); setSortBy('DATE_DESC'); setFilterArchive('HIDE');
  };

  const sortedReferences = useMemo(() => {
    return [...filtered].sort((a, b) => {
      if (sortBy === 'DATE_DESC') {
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        if (timeA !== timeB) return timeB - timeA;
        return b.refId.localeCompare(a.refId, undefined, { numeric: true });
      }
      if (sortBy === 'DATE_ASC') {
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        if (timeA !== timeB) return timeA - timeB;
        return a.refId.localeCompare(b.refId, undefined, { numeric: true });
      }
      if (sortBy === 'REF_ID_ASC') {
        return a.refId.localeCompare(b.refId, undefined, { numeric: true });
      }
      if (sortBy === 'REF_ID_DESC') {
        return b.refId.localeCompare(a.refId, undefined, { numeric: true });
      }
      if (sortBy === 'PRODUCT') {
        return a.product.localeCompare(b.product, 'tr');
      }
      return 0;
    });
  }, [filtered, sortBy]);

  const getStatusBadge = (status: ReferenceItem['status'], item?: ReferenceItem) => {
    // v2.7: test / numune kayıtları — stok ve sevkiyat dışı, tamamlanmış işlem
    if (item && isTestReference(item)) {
      return (
        <div className="flex flex-col gap-1">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-50 text-sky-800 border border-sky-200 dark:bg-sky-950/40 dark:text-sky-200 dark:border-sky-900" title="Test kaydı: stok ve sevkiyat oluşturmaz">
            <CheckCircle2 className="w-3 h-3" /> Test — tamamlandı
          </span>
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-1">
        {status === 'COMPLETED' && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-900 text-emerald-300 border border-emerald-500/40 shadow-2xs">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Tamamlandı / Completed
          </span>
        )}
        {status === 'CREATED' && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <Clock className="w-3 h-3" /> Hasat / Ready
          </span>
        )}
        {(status === 'SHIPPED' || status === 'IN_TRANSIT') && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <Truck className="w-3 h-3" /> Yolda / In Transit
          </span>
        )}
        {status === 'RECEIVED' && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <Warehouse className="w-3 h-3" /> Depoda / In Storage
          </span>
        )}
        {status === 'INCIDENT' && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-200 border border-rose-200 dark:border-rose-800">
            <AlertTriangle className="w-3 h-3" /> Incident / Akt
          </span>
        )}

        {/* Freeze & Dry Rozeti */}
        {item?.reroutedToFreezeDry && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-purple-100 text-purple-800 border border-purple-300">
            <Snowflake className="w-2.5 h-2.5 text-purple-600" />
            <span>Freeze & Dry</span>
          </span>
        )}

        {/* Parçalı Yük & Sortlandırma Rozeti */}
        {item?.splitLots && item.splitLots.length > 0 ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-teal-100 text-teal-900 border border-teal-300" title="Yük kalite sınıflarına bölündü, raporlarda çift sayım engellendi">
            <Split className="w-2.5 h-2.5 text-teal-700" />
            <span>Sortlandı ({item.splitLots.length} Klas)</span>
          </span>
        ) : (item?.isUnsorted || item?.kaliteSinifi?.toString().toLowerCase().includes('mix')) ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-900 border border-amber-300" title="Henüz sınıflara ayrılmamış ham yük">
            <Layers className="w-2.5 h-2.5 text-amber-700" />
            <span>Sortlanmamış Yük</span>
          </span>
        ) : null}

        {/* Kalite Öngörü & Risk Radarı Rozeti */}
        {(() => {
          const risk = qualityRiskMap.get(item?.refId);
          if (!risk) return null;
          const actionText = risk.actionType === 'FREEZE_DRY' ? 'Freeze-Dry' : risk.actionType === 'URGENT_DISPATCH' ? 'Hızlı Sevk' : 'Önlem';
          if (risk.riskLevel === 'CRITICAL') {
            return (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black bg-rose-600 text-white shadow-2xs" title={`Risk: ${risk.primaryRiskSummary} (${actionText})`}>
                <ShieldAlert className="w-2.5 h-2.5 text-white" />
                <span>Acil: {actionText}</span>
              </span>
            );
          }
          if (risk.riskLevel === 'WARNING') {
            return (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-900 border border-amber-300" title={`Sınırda: ${risk.primaryRiskSummary}`}>
                <AlertTriangle className="w-2.5 h-2.5 text-amber-700" />
                <span>Sınırda</span>
              </span>
            );
          }
          return (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300" title="OECD/USDA Kalite Standartlarına Uygun">
              <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" />
              <span>{risk.standardOrg} Uygun</span>
            </span>
          );
        })()}
      </div>
    );
  };

  const getModuleBadge = (key: ModuleKey) => {
    switch (key) {
      case 'HARVEST':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200">HASAT / HARVEST</span>;
      case 'FIELD':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-100 text-rose-700 border border-rose-200">MEYVE TESTİ / FRUIT</span>;
      case 'MUZ':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200">MUZ / BANANA</span>;
      case 'BADEM':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-orange-100 text-orange-800 border border-orange-200">BADEM / ALMOND</span>;
      case 'LOJISTIK':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-blue-100 text-blue-800 border border-blue-200">LOJİSTİK / LOGISTICS</span>;
      case 'AMBAR':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-teal-100 text-teal-800 border border-teal-200">AMBAR / STORAGE</span>;
      case 'FREEZE_DRY':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-purple-100 text-purple-800 border border-purple-300">FREEZE-DRY</span>;
      case 'EXPORT_SAMPLE':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-cyan-100 text-cyan-800 border border-cyan-200">EKSPORT / EXPORT</span>;
      case 'SALES':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-200">SATIŞ / SALES</span>;
      case 'INCIDENT':
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-100 text-rose-800 border border-rose-200">AKTI / INCIDENT</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">{key}</span>;
    }
  };

  const [showExportMenu, setShowExportMenu] = useState(false);
  const [exportToast, setExportToast] = useState<{ message: string; filename: string } | null>(null);

  const handleExportData = (format: ExportFormat = 'EXCEL') => {
    setShowExportMenu(false);
    const targetRefs = selectedRefIds.size > 0
      ? sortedReferences.filter(r => selectedRefIds.has(r.refId))
      : sortedReferences;

    if (targetRefs.length === 0) return;

    const result = exportFilteredReferences({
      references: targetRefs,
      qualityRiskMap,
      fieldRecords,
      harvestRecords,
      muzRecords,
      bademRecords,
      ambarRecords,
      lojistikRecords,
      salesRecords,
      format,
      isPendingSyncChecker: isItemPendingSync
    });

    if (result.success) {
      setExportToast({
        message: `${result.count} adet parti (${format === 'EXCEL' ? 'Excel CSV (;)' : 'Standart CSV (,)'}) olarak dışa aktarıldı.`,
        filename: result.filename
      });
      setTimeout(() => setExportToast(null), 4000);
    }
  };

  const [quickNoteRef, setQuickNoteRef] = useState<ReferenceItem | null>(null);
  const [quickNoteToast, setQuickNoteToast] = useState<{ message: string; refId: string } | null>(null);

  const handleSaveQuickNote = (
    refId: string,
    noteText: string,
    options: {
      category?: string;
      priority?: 'NORMAL' | 'WARNING' | 'CRITICAL';
      operator?: string;
      append?: boolean;
    }
  ) => {
    if (onAddAdminNote) {
      onAddAdminNote(refId, noteText, options);
    } else if (onBulkUpdateReferences) {
      const target = references.find(r => r.refId === refId);
      const existing = target?.notes ? target.notes.trim() : '';
      const dateStamp = new Date().toLocaleString('tr-TR');
      const author = options.operator || currentUserId || 'Admin';
      const cat = options.category ? ` [${options.category}]` : '';
      const prio = options.priority && options.priority !== 'NORMAL' ? ` [${options.priority}]` : '';
      const entry = `[${dateStamp} - ${author}${cat}${prio}]: ${noteText}`;
      const finalNote = options.append !== false && existing ? `${existing}\n${entry}` : entry;
      onBulkUpdateReferences([refId], target?.status || 'CREATED', {
        notes: finalNote,
        operator: author
      });
    }

    setQuickNoteToast({
      refId,
      message: `"${refId}" referansına idari not başarıyla işlendi.`
    });
    setTimeout(() => setQuickNoteToast(null), 3500);
  };


  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-sm overflow-hidden transition-colors">
      
      {/* Header */}
      <div className="p-2.5 sm:p-3 border-b border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 bg-slate-50/50 dark:bg-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <Archive className="w-4 h-4 text-teal-700 dark:text-teal-400" />
            <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
              {title || 'Tüm Referanslar & İşlem Kütüğü / Reference Ledger'}
            </h2>
            {(totalRefCount !== undefined || completedRefCount !== undefined || pendingCount > 0) && (
              <div className="flex items-center gap-1.5 ml-2 flex-wrap">
                {totalRefCount !== undefined && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                    Toplam: {totalRefCount}
                  </span>
                )}
                {completedRefCount !== undefined && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    Tamamlandı: {completedRefCount}
                  </span>
                )}
                {pendingCount > 0 && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-extrabold bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 flex items-center gap-1 animate-pulse">
                    <RefreshCw className="w-2.5 h-2.5 text-amber-600 animate-spin" />
                    Push Bekleyen: {pendingCount}
                  </span>
                )}
              </div>
            )}
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            {subtitle || 'Gök Bulut, Hemsaýa ve Datly Miwe entegre parti izlenebilirliği'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Ambar Stok Uyarıları Toggle (Sadece Tüm Kayıtlar sayfasında) */}
          {!isRecentLedger && (
            <>
              <button
                type="button"
                onClick={() => {
                  const next = !showBananaQualityStandards;
                  setShowBananaQualityStandards(next);
                  if (next) {
                    setTimeout(() => {
                      document.getElementById('banana-quality-standards-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 150);
                  }
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer ${
                  showBananaQualityStandards
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100'
                }`}
                title="Muz Hasat & Kalite Kontrol Kriterleri — İhracat (Export) vs Yerel Pazar Standartlarını Göster / Gizle (Sayfa Altı)"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>🍌 Muz Hasat & Kalite Kriterleri</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const next = !showStockAlerts;
                  setShowStockAlerts(next);
                  if (next) {
                    setTimeout(() => {
                      document.getElementById('stock-alerts-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 150);
                  }
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer ${
                  showStockAlerts
                    ? 'bg-amber-500 text-white hover:bg-amber-600'
                    : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800 hover:bg-amber-100'
                }`}
                title="Ambar kritik stok uyarıları ve güvenlik eşiği panelini göster / gizle (Sayfa Altı)"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Stok Uyarıları</span>
              </button>
            </>
          )}

          {onViewAll && isRecentLedger && (
            <button
              onClick={onViewAll}
              className="px-2.5 py-1 bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 text-white rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5"
            >
              <span>Tümünü Gör / View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}

          {/* EXCEL / CSV EXPORT BUTTON & DROPDOWN */}
          <div className="relative">
            <div className="inline-flex rounded-xl shadow-xs border border-emerald-700/60 dark:border-emerald-600/50 overflow-hidden">
              <button
                type="button"
                onClick={() => handleExportData('EXCEL')}
                className="px-2.5 py-1.5 bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer btn-tactile"
                title="Geçerli filtrelenmiş partileri Excel uyumlu CSV olarak indir (Çevrimdışı analiz için)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                <span>
                  {selectedRefIds.size > 0
                    ? `Seçilenleri Excel'e Aktar (${selectedRefIds.size})`
                    : `Excel / CSV İndir (${sortedReferences.length})`}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="px-2 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-emerald-100 border-l border-emerald-600/60 text-xs transition cursor-pointer flex items-center justify-center"
                title="Dışa aktarma formatını seç (Excel / Standart CSV)"
                aria-label="Dışa aktarma formatı menüsü"
              >
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-150 ${showExportMenu ? 'rotate-180' : ''}`} />
              </button>
            </div>

            {/* Dropdown Menu */}
            {showExportMenu && (
              <div 
                className="absolute right-0 top-full mt-1.5 w-72 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-50 p-1.5 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-100"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-2 py-1 border-b border-slate-100 dark:border-slate-700/60 font-mono text-[10px] text-slate-500 font-bold uppercase flex items-center justify-between">
                  <span>Çevrimdışı Analiz Formatı</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                    {selectedRefIds.size > 0 ? `${selectedRefIds.size} Seçili` : `${sortedReferences.length} Kayıt`}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleExportData('EXCEL')}
                  className="w-full text-left p-2 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg text-slate-800 dark:text-slate-200 flex items-start gap-2.5 cursor-pointer transition"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-xs flex items-center justify-between">
                      <span>Excel Uyumlu (.csv)</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 font-black">Önerilen</span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                      Noktalı virgül (;) • UTF-8 BOM • Excel'de doğrudan ayrışan temiz sütunlar
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleExportData('CSV')}
                  className="w-full text-left p-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-lg text-slate-800 dark:text-slate-200 flex items-start gap-2.5 cursor-pointer transition"
                >
                  <Download className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-xs">Standart CSV (.csv)</div>
                    <div className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                      Virgül (,) • RFC 4180 • Google E-Tablolar, Python &amp; Power BI uyumlu
                    </div>
                  </div>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Success Toast Banner */}
      {exportToast && (
        <div className="mx-3 mt-3 p-3 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/80 dark:to-teal-950/80 border border-emerald-300 dark:border-emerald-700/80 rounded-xl flex items-center justify-between gap-3 text-xs text-emerald-950 dark:text-emerald-100 shadow-sm animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold">{exportToast.message}</span>
              <span className="text-[11px] text-emerald-800 dark:text-emerald-300 font-mono ml-2 block sm:inline">
                Dosya: {exportToast.filename}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setExportToast(null)}
            className="p-1 hover:bg-emerald-200/60 dark:hover:bg-emerald-900 rounded-lg text-emerald-800 dark:text-emerald-300 cursor-pointer transition"
            title="Bildirimi Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* v2.8: Filtreler — ana filtreler görünür, diğerleri "Diğer filtreler" altında */}
      <div className="p-2.5 sm:p-3 border-b border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800 space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Ref ID, ürün, bahçe, operatör ara"
            aria-label="Kayıt ara"
            className="w-full min-h-[44px] pl-9 pr-3 text-sm bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-teal-500 outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5" role="radiogroup" aria-label="Kayıt türü">
          {([['ALL', 'Tümü'], ['LOT', 'Partiler'], ['TEST', 'Testler']] as const).map(([k, l]) => (
            <button key={k} type="button" role="radio" aria-checked={filterKind === k} onClick={() => setFilterKind(k)}
              className={`min-h-[36px] px-3 rounded-full text-xs font-semibold border transition ${filterKind === k ? 'bg-teal-700 text-white border-teal-700' : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'}`}>
              {l}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <select
            value={filterProductType}
            onChange={(e) => setFilterProductType(e.target.value)}
            aria-label="Ürün"
            className="w-full min-h-[40px] px-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg outline-none"
          >
            <option value="ALL">Tüm ürünler</option>
            {availableProductTypes.map(prod => <option key={prod} value={prod}>{prod}</option>)}
          </select>
          <select
            value={filterHarvestPeriod}
            onChange={(e) => setFilterHarvestPeriod(e.target.value)}
            aria-label="Dönem"
            className="w-full min-h-[40px] px-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg outline-none"
          >
            <option value="ALL">Tüm tarihler</option>
            <option value="TODAY">Bugün</option>
            <option value="THIS_WEEK">Son 7 gün</option>
            <option value="THIS_MONTH">Son 30 gün</option>
            <option value="LAST_90_DAYS">Son 90 gün</option>
            <option value="SPRING">İlkbahar (Mart–Mayıs)</option>
            <option value="SUMMER">Yaz (Haziran–Ağustos)</option>
            <option value="AUTUMN">Sonbahar (Eylül–Kasım)</option>
            <option value="WINTER">Kış (Aralık–Şubat)</option>
          </select>
        </div>

        <div className="flex items-center justify-between gap-2">
          <button type="button" onClick={() => setShowMoreFilters(v => !v)} aria-expanded={showMoreFilters}
            className="min-h-[36px] inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200">
            <Filter className="w-3.5 h-3.5" /> Diğer filtreler{moreFiltersActive > 0 ? ` (${moreFiltersActive})` : ''}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showMoreFilters ? 'rotate-180' : ''}`} />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-500 dark:text-slate-400"><strong className="text-teal-700 dark:text-teal-400">{filtered.length}</strong> / {references.length} kayıt</span>
            {anyFilterActive && (
              <button type="button" onClick={clearAllFilters} className="min-h-[36px] px-2.5 text-[11px] font-semibold text-rose-700 bg-rose-50 dark:bg-rose-950/40 rounded-lg border border-rose-200 dark:border-rose-900">
                Temizle
              </button>
            )}
          </div>
        </div>

        {showMoreFilters && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-2 border-t border-slate-100 dark:border-slate-700/50">
            <select value={filterArchive} onChange={(e) => setFilterArchive(e.target.value as any)} aria-label="Arşiv"
              className="w-full min-h-[40px] px-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg outline-none">
              <option value="HIDE">Arşivdekileri gizle</option>
              <option value="SHOW">Arşiv dahil göster</option>
              <option value="ONLY">Yalnızca arşiv</option>
            </select>
            <select
              value={filterModule}
              onChange={(e) => setFilterModule(e.target.value)}
              className="w-full min-h-[40px] py-1.5 px-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg outline-none"
            >
              <option value="ALL">📁 Tüm Modüller / All Modules</option>
              <option value="HARVEST">01 Hasat / Daily Harvest</option>
              <option value="FIELD">02 Meyve Testi / Fruit Test</option>
              <option value="MUZ">03 Muz / Banana Quality</option>
              <option value="BADEM">04 Badem / Almond</option>
              <option value="LOJISTIK">05 Lojistik / Logistics</option>
              <option value="AMBAR">06 Ambar / Cold Storage</option>
              <option value="FREEZE_DRY">07 Freeze & Dry</option>
              <option value="EXPORT_SAMPLE">08 Eksport / Export</option>
              <option value="SALES">09 Satış / Sales</option>
              <option value="INCIDENT">10 Incident / Akt</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full min-h-[40px] py-1.5 px-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg outline-none"
            >
              <option value="ALL">🏷️ Tüm Durumlar / All Statuses</option>
              <option value="COMPLETED">Tamamlandı / Completed (COMPLETED)</option>
              <option value="CREATED">Hasat / Ready (CREATED)</option>
              <option value="SHIPPED">Yolda / Sevk (SHIPPED)</option>
              <option value="RECEIVED">Depoya Alındı (RECEIVED)</option>
              <option value="EXPORT_TESTED">İhracat numunesi (EXPORT_TESTED)</option>
              <option value="SOLD">Satıldı (SOLD)</option>
              <option value="INCIDENT">Incident / Tutanağı Var</option>
            </select>
            <select
              value={filterSync}
              onChange={(e) => setFilterSync(e.target.value as any)}
              className="w-full min-h-[40px] py-1.5 px-2.5 text-xs font-bold bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg outline-none"
            >
              <option value="ALL">🌐 Tüm Eşitleme Durumları</option>
              <option value="PENDING">⏳ Push Bekleyenler ({pendingCount})</option>
              <option value="SYNCED">🟢 Senkronize Olanlar</option>
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full min-h-[40px] py-1.5 px-2.5 text-xs font-extrabold bg-teal-50 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-700 text-teal-900 dark:text-teal-200 rounded-lg outline-none"
            >
              <option value="DATE_DESC">⬇️ Sıralama: En Yeni (Kronolojik / Newest)</option>
              <option value="DATE_ASC">⬆️ Sıralama: En Eski (Kronolojik / Oldest)</option>
              <option value="REF_ID_ASC">🔤 Sıralama: Ref ID (A → Z)</option>
              <option value="REF_ID_DESC">🔤 Sıralama: Ref ID (Z → A)</option>
              <option value="PRODUCT">🍏 Sıralama: Ürün Adı (A → Z)</option>
            </select>
          </div>
        )}
      </div>

      {/* Kalite Öngörü & Risk Radarı Hızlı Filtre Barı */}
      {riskStats.total > 0 && (
        <div className="px-3 py-2 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-2 overflow-x-auto">
          <div className="flex items-center gap-1.5 flex-nowrap shrink-0">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1 mr-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
              <span>Risk Radarı:</span>
            </span>

            <button
              type="button"
              onClick={() => setFilterQualityRisk('ALL')}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer whitespace-nowrap ${
                filterQualityRisk === 'ALL'
                  ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              Tümü ({riskStats.total})
            </button>

            {riskStats.critical > 0 && (
              <button
                type="button"
                onClick={() => setFilterQualityRisk('CRITICAL')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-black transition cursor-pointer flex items-center gap-1 whitespace-nowrap ${
                  filterQualityRisk === 'CRITICAL'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-200'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>
                <span>🔴 Acil Risk ({riskStats.critical})</span>
              </button>
            )}

            {riskStats.warning > 0 && (
              <button
                type="button"
                onClick={() => setFilterQualityRisk('WARNING')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer whitespace-nowrap ${
                  filterQualityRisk === 'WARNING'
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 hover:bg-amber-200'
                }`}
              >
                <span>🟡 Sınırda ({riskStats.warning})</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setFilterQualityRisk('SAFE')}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer whitespace-nowrap ${
                filterQualityRisk === 'SAFE'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-200'
              }`}
            >
              <span>🟢 Optimum ({riskStats.safe})</span>
            </button>
          </div>

          {onOpenAnalytics && (
            <button
              type="button"
              onClick={onOpenAnalytics}
              className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 shrink-0 whitespace-nowrap"
            >
              <span>Analiz Radarı</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Floating / Docked Bulk Action Bar */}
      {selectedRefIds.size > 0 && (
        <div className="bg-slate-900 text-white px-4 py-3 border-y-2 border-emerald-500 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg animate-in fade-in slide-in-from-bottom duration-150">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <div className="text-xs">
              <span className="font-extrabold text-emerald-300 font-mono text-sm mr-1">
                {selectedRefIds.size}
              </span>
              <span>adet referans parti kaydı seçildi.</span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => setIsBulkUpdateModalOpen(true)}
              className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>⚡ Toplu Durum Güncelle</span>
            </button>

            <button
              type="button"
              onClick={() => setIsBulkRejectModalOpen(true)}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              title="Seçilen tüm partileri yönetim kararıyla reddet ve sistem uyarısı tetikle"
            >
              <ShieldAlert className="w-4 h-4 text-white" />
              <span>🔴 Toplu Reddet (REJECTED)</span>
            </button>

            <button
              type="button"
              onClick={() => handleExportData('EXCEL')}
              className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              title="Seçilen partileri Excel formatında indir"
            >
              <FileSpreadsheet className="w-4 h-4 text-teal-200" />
              <span>📊 Seçilenleri Excel'e Aktar ({selectedRefIds.size})</span>
            </button>

            <button
              type="button"
              onClick={handleClearSelection}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold transition border border-slate-700 cursor-pointer"
            >
              Seçimi Temizle
            </button>
          </div>
        </div>
      )}

      {/* Density & View Controls Bar */}
      <div className="px-3 py-2 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-700/80 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-bold">Görünüm Yoğunluğu:</span>
          <button
            type="button"
            onClick={() => setTableDensity('COMFORTABLE')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
              tableDensity === 'COMFORTABLE'
                ? 'bg-teal-700 text-white shadow-xs'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300'
            }`}
          >
            Rahat
          </button>
          <button
            type="button"
            onClick={() => setTableDensity('COMPACT')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
              tableDensity === 'COMPACT'
                ? 'bg-teal-700 text-white shadow-xs'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300'
            }`}
          >
            Sıkı (Kompakt)
          </button>
        </div>

        <div className="text-xs text-slate-500 font-mono hidden sm:block">
          {sortedReferences.length} kayıt gösteriliyor
        </div>
      </div>

      {/* MOBILE CARD LIST VIEW (< md breakpoint) */}
      <div className="block md:hidden p-2.5 space-y-3 bg-slate-50/60 dark:bg-slate-900/40">
        {sortedReferences.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-sm">
            Arama kriterlerine uygun referans kaydı bulunamadı.
          </div>
        ) : (
          sortedReferences.slice(0, visibleCount).map((item) => {
            const isPending = isItemPendingSync(item.refId);
            const queueItem = isPending ? getPendingQueueItem(item.refId) : undefined;
            const isSelected = selectedRefIds.has(item.refId);
            const isExpanded = expandedCardIds.has(item.refId);

            return (
              <Card
                key={item.refId}
                padding="sm"
                className={`space-y-2.5 transition ${
                  isSelected ? 'bg-teal-50/80 dark:bg-teal-950/40 border-teal-300 dark:border-teal-700' : ''
                }`}
              >
                {/* Mobile Card Header with Floating Quick Note Action Button */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => handleToggleSelect(item.refId)}
                      className="w-5 h-5 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer shrink-0"
                    />
                    <button
                      type="button"
                      onClick={() => onOpenTraceability(item)}
                      className="font-mono font-black text-sm text-teal-700 dark:text-teal-400 hover:underline truncate text-left"
                    >
                      {item.refId}
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Button
                      variant="soft"
                      tone="slate"
                      size="sm"
                      icon={<StickyNote />}
                      aria-label="Hızlı Yönetici Notu Ekle"
                      onClick={() => setQuickNoteRef(item)}
                      title="Hızlı Yönetici Notu Ekle (Formu açmadan)"
                    >
                      <span className="inline-flex items-center gap-1">
                        <span>Not</span>
                        {item.notes && (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" title="Mevcut not var" />
                        )}
                      </span>
                    </Button>
                    {getStatusBadge(item.status, item)}
                  </div>
                </div>

                {/* Main 3-4 Key Fields */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Ürün & Modül:</span>
                    <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 flex-wrap">
                      <span>{item.product}</span>
                      {getModuleBadge(item.moduleKey)}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Miktar:</span>
                    <div className="font-mono font-black text-slate-900 dark:text-slate-100 text-sm tabular-nums">
                      {!((item.quantity ?? 0) > 0) ? (isTestReference(item) ? 'Test — stok yok' : 'Tartılmadı') : `${(item.quantity ?? 0).toLocaleString('tr-TR')} ${item.unit || 'kg'}`}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Bahçe & Lokasyon:</span>
                    <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {item.orchard || item.source || item.location}
                    </div>
                  </div>
                </div>

                {/* Note preview badge if notes exist */}
                {item.notes && (
                  <div
                    onClick={() => setQuickNoteRef(item)}
                    className="p-2 rounded-xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200/70 dark:border-amber-900/50 text-[11px] text-amber-900 dark:text-amber-200 flex items-start gap-1.5 cursor-pointer hover:bg-amber-100/80 transition"
                    title="İdari notu incele veya yeni not ekle"
                  >
                    <StickyNote className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                    <div className="truncate flex-1 font-sans">
                      <span className="font-bold text-amber-800 dark:text-amber-300">İdari Not: </span>
                      <span className="text-slate-700 dark:text-slate-300">{item.notes.split('\n').pop() || item.notes}</span>
                    </div>
                  </div>
                )}

                {/* Direct Action Bar on Each Reference Card */}
                <div className="pt-2 flex items-center gap-2 flex-wrap border-t border-slate-100 dark:border-slate-700/60">
                  <Button
                    variant="primary"
                    size="sm"
                    icon={<Printer />}
                    onClick={() => onOpenTraceability(item)}
                    className="flex-1"
                    title="Bu partinin tüm modül verilerini (Hasat, Saha, Lojistik, Ambar, Satış) birleştirerek özetleyen PDF raporunu indir veya yazdır"
                  >
                    PDF İndir
                  </Button>

                  {onOpenChain && (
                    <Button variant="soft" tone="brand" size="sm" icon={<Link2 />} aria-label="Zincir" onClick={() => onOpenChain(item)} title="Test → hasat → fiş → depo → çıkış">
                      Zincir
                    </Button>
                  )}

                  {onOpenPrecooling && !isReadOnlyUser && !isTestReference(item) && (
                    <Button variant="soft" tone="emerald" size="sm" icon={<Snowflake />} aria-label="Ön soğutma fişi" onClick={() => onOpenPrecooling(item)} title="%5 inspeksiyon ve şoklama fişi ekle">
                      Ön soğutma{(item.precoolingSlips?.length || 0) > 0 ? ` (${item.precoolingSlips!.length})` : ''}
                    </Button>
                  )}

                  {onEditReference && !isReadOnlyUser && (
                    <Button
                      variant="soft"
                      tone="amber"
                      size="sm"
                      icon={<Edit3 />}
                      aria-label="Kaydı Düzenle"
                      onClick={() => onEditReference(item)}
                      title="Kaydı Düzenle"
                    >
                      Düzenle
                    </Button>
                  )}
                </div>

                {/* Expandable Details Toggle */}
                <div className="pt-1 flex items-center justify-between border-t border-slate-100 dark:border-slate-700/60">
                  <button
                    type="button"
                    onClick={() => toggleExpandCard(item.refId)}
                    className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 min-h-[44px] cursor-pointer"
                  >
                    <span>{isExpanded ? 'Ayrıntıları Gizle ▲' : 'Detayları & İşlemleri Göster ▼'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {isPending ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (queueItem && onSyncSingleQueueItem) {
                            onSyncSingleQueueItem(queueItem);
                          }
                        }}
                        className="px-2 py-1 rounded-full text-xs font-extrabold bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3 text-amber-600 animate-spin" />
                        <span>Push Bekliyor</span>
                      </button>
                    ) : (
                      <Badge tone="ok" icon={<CheckCircle2 className="w-3 h-3" />}>
                        ✓ Senkron
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Expandable Details Content */}
                {isExpanded && (
                  <div className="p-3 bg-slate-50 dark:bg-slate-900/80 rounded-xl space-y-3 text-xs border border-slate-200 dark:border-slate-700">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-500 dark:text-slate-400">Tarih:</span>
                        <div className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                          {item.createdAt ? item.createdAt.slice(0, 10) : '-'}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-slate-400">Operatör:</span>
                        <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {item.operator || 'Sistem'}
                        </div>
                      </div>
                    </div>

                    {item.splitLots && item.splitLots.length > 0 && (
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block mb-1 font-semibold">Parçalı Klas Sınıflandırması:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {item.splitLots.map((sl, idx) => (
                            <span key={idx} className="text-xs font-mono px-2 py-1 rounded bg-teal-100 dark:bg-teal-950 text-teal-900 dark:text-teal-200 border border-teal-300 dark:border-teal-800 tabular-nums">
                              {sl.qualityGrade}: <strong>{(Number(sl.quantityKg) || 0).toLocaleString('tr-TR')} kg</strong>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="pt-2 flex flex-wrap items-center gap-2 border-t border-slate-200 dark:border-slate-700">
                      <Button
                        variant="soft"
                        tone="sky"
                        size="sm"
                        icon={<QrCode />}
                        aria-label="QR Etiket"
                        onClick={() => setQrModalRef(item)}
                        title="Ambar Giriş & Stok QR Kodunu Göster / Yazdır"
                      >
                        QR Etiket
                      </Button>

                      {item.status === 'CREATED' && !isReadOnlyUser && !isTestReference(item) && (
                        <Button
                          variant="soft"
                          tone="violet"
                          size="sm"
                          onClick={() => onDispatch(item.refId)}
                        >
                          Sevk Et
                        </Button>
                      )}

                      {(item.status === 'SHIPPED' || item.status === 'IN_TRANSIT') && !isReadOnlyUser && !isTestReference(item) && (
                        <Button
                          variant="soft"
                          tone="emerald"
                          size="sm"
                          onClick={() => onReceive(item.refId)}
                        >
                          Kabul Et
                        </Button>
                      )}

                      {!isReadOnlyUser && (
                        <Button
                          variant="soft"
                          tone="rose"
                          size="sm"
                          icon={<AlertTriangle />}
                          aria-label="Barlag Akty / Incident"
                          onClick={() => onOpenIncident(item.refId)}
                          title="Barlag Akty / Incident"
                        />
                      )}

                      {onDeleteReference && !isReadOnlyUser && (
                        <Button
                          variant="danger"
                          size="sm"
                          icon={<Trash2 />}
                          aria-label="Sil"
                          onClick={() => setRefToDelete(item)}
                          title="Sil"
                          className="ml-auto"
                        />
                      )}
                    </div>
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>

      {/* DESKTOP STICKY TABLE VIEW (>= md breakpoint) */}
      <div className="hidden md:block overflow-x-auto max-h-[70vh]">
        <table className={`w-full text-left text-slate-700 dark:text-slate-200 ${tableDensity === 'COMPACT' ? 'text-xs' : 'text-sm'}`}>
          <thead className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 uppercase font-black tracking-wider text-xs border-b border-slate-200 dark:border-slate-700 sticky top-0 z-20 shadow-xs">
            <tr>
              <th className={`w-10 text-center sticky left-0 z-30 bg-slate-100 dark:bg-slate-900 ${tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}`}>
                <input
                  type="checkbox"
                  checked={sortedReferences.length > 0 && sortedReferences.every(r => selectedRefIds.has(r.refId))}
                  onChange={() => handleToggleSelectAll(sortedReferences)}
                  className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  title="Görünen Tümünü Seç / Deselect All"
                />
              </th>
              <th className={`sticky left-10 z-30 bg-slate-100 dark:bg-slate-900 ${tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}`}>Ref ID</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Modül</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Ürün & Çeşit</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Miktar</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Bahçe & Lokasyon</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Durum</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Eşitleme</th>
              <th className={tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}>Tarih</th>
              <th className={`text-right ${tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3'}`}>İşlemler</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
            {sortedReferences.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-8 text-center text-slate-500 dark:text-slate-400">
                  Arama kriterlerine uygun referans kaydı bulunamadı.
                </td>
              </tr>
            ) : (
              sortedReferences.slice(0, visibleCount).map((item) => {
                const isPending = isItemPendingSync(item.refId);
                const queueItem = isPending ? getPendingQueueItem(item.refId) : undefined;
                const isSelected = selectedRefIds.has(item.refId);
                const pyClass = tableDensity === 'COMPACT' ? 'py-1.5 px-2' : 'py-2.5 px-3.5';

                return (
                  <tr key={item.refId} className={`transition ${isSelected ? 'bg-teal-50/80 dark:bg-teal-950/40' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'}`}>
                    <td className={`${pyClass} text-center sticky left-0 z-10 bg-white dark:bg-slate-800`}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelect(item.refId)}
                        className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                      />
                    </td>
                    <td className={`${pyClass} font-mono font-bold text-slate-900 dark:text-slate-100 sticky left-10 z-10 bg-white dark:bg-slate-800`}>
                      <button
                        type="button"
                        onClick={() => onOpenTraceability(item)}
                        className="hover:underline text-teal-800 dark:text-teal-300 flex items-center gap-1 cursor-pointer font-black"
                      >
                        <span>{item.refId}</span>
                        <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
                      </button>
                    </td>
                    <td className={pyClass}>
                      {getModuleBadge(item.moduleKey)}
                    </td>
                    <td className={`${pyClass} font-bold text-slate-900 dark:text-slate-100`}>
                      <div>{item.product}</div>
                      {item.splitLots && item.splitLots.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-0.5">
                          {item.splitLots.map((sl, idx) => (
                            <span key={idx} className="text-xs font-mono px-1.5 py-0.2 rounded bg-teal-50 dark:bg-teal-950 text-teal-900 dark:text-teal-200 border border-teal-200 dark:border-teal-800 tabular-nums">
                              {sl.qualityGrade}: <strong>{(Number(sl.quantityKg) || 0).toLocaleString('tr-TR')} kg</strong>
                            </span>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className={`${pyClass} font-mono font-black text-slate-900 dark:text-slate-100 tabular-nums`}>
                      {!((item.quantity ?? 0) > 0) ? (isTestReference(item) ? 'Test — stok yok' : 'Tartılmadı') : `${(item.quantity ?? 0).toLocaleString('tr-TR')} ${item.unit || 'kg'}`}
                    </td>
                    <td className={`${pyClass} text-slate-700 dark:text-slate-300`}>
                      {item.orchard || item.source || item.location}
                    </td>
                    <td className={pyClass}>
                      {getStatusBadge(item.status, item)}
                    </td>
                    <td className={pyClass}>
                      {isPending ? (
                        <button
                          type="button"
                          onClick={() => {
                            if (queueItem && onSyncSingleQueueItem) {
                              onSyncSingleQueueItem(queueItem);
                            }
                          }}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 hover:bg-amber-200 transition cursor-pointer"
                          title="Sunucuya aktarılmayı bekliyor (Offline kuyrukta). Tıklayarak anında gönderebilirsiniz."
                        >
                          <RefreshCw className="w-3 h-3 text-amber-600 animate-spin" />
                          <span>Bekliyor (Push)</span>
                        </button>
                      ) : (
                        <Badge
                          tone="ok"
                          icon={<CheckCircle2 className="w-3.5 h-3.5" />}
                          title="Sunucu ile eşitlenmiş / Güncel"
                        >
                          Senkron
                        </Badge>
                      )}
                    </td>
                    <td className={`${pyClass} text-slate-600 dark:text-slate-400 font-mono text-xs tabular-nums`}>
                      {item.createdAt ? item.createdAt.slice(0, 10) : '-'}
                    </td>
                    <td className={`${pyClass} text-right`}>
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        
                        {(item.photoUrl || (item.photos && item.photos.length > 0)) && (
                          <Button
                            variant="secondary"
                            size="sm"
                            icon={<ImageIcon />}
                            aria-label="Fotoğrafı Tam Boyut Aç"
                            onClick={() => setPreviewPhoto({
                              url: item.photoUrl || item.photos![0],
                              title: `${item.refId} • ${item.product}`
                            })}
                            title="Fotoğrafı Tam Boyut Aç (Lightbox)"
                          >
                            Foto
                          </Button>
                        )}

                        <Button
                          variant="soft"
                          tone="slate"
                          size="sm"
                          icon={<StickyNote />}
                          aria-label="Hızlı Yönetici Notu Ekle"
                          onClick={() => setQuickNoteRef(item)}
                          title="Hızlı Yönetici Notu Ekle (Formu açmadan)"
                        >
                          <span className="inline-flex items-center gap-1">
                            <span className="hidden xl:inline">Hızlı Not</span>
                            {item.notes && (
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" title="Mevcut not var" />
                            )}
                          </span>
                        </Button>

                        {onOpenChain && (
                          <Button variant="soft" tone="brand" size="sm" icon={<Link2 />} aria-label="Zincir" onClick={() => onOpenChain(item)} title="Test → hasat → fiş → depo → çıkış">
                            Zincir
                          </Button>
                        )}

                        {onOpenPrecooling && !isReadOnlyUser && !isTestReference(item) && (
                          <Button variant="soft" tone="emerald" size="sm" icon={<Snowflake />} aria-label="Ön soğutma fişi" onClick={() => onOpenPrecooling(item)} title="%5 inspeksiyon ve şoklama fişi ekle">
                            Ön soğutma{(item.precoolingSlips?.length || 0) > 0 ? ` (${item.precoolingSlips!.length})` : ''}
                          </Button>
                        )}

                        {onEditReference && !isReadOnlyUser && (
                          <Button
                            variant="soft"
                            tone="amber"
                            size="sm"
                            icon={<Edit3 />}
                            aria-label="Düzenle"
                            onClick={() => onEditReference(item)}
                            title="Bu kaydı aç ve hataları düzelt"
                          >
                            Düzenle
                          </Button>
                        )}

                        <Button
                          variant="primary"
                          size="sm"
                          icon={<Printer />}
                          onClick={() => onOpenTraceability(item)}
                          title="PDF Raporu İndir / Yazdır"
                        >
                          PDF İndir
                        </Button>

                        <Button
                          variant="soft"
                          tone="sky"
                          size="sm"
                          icon={<QrCode />}
                          aria-label="QR Etiket"
                          onClick={() => setQrModalRef(item)}
                          title="Ambar Giriş & Stok QR Kodunu Göster / Yazdır"
                        >
                          QR
                        </Button>

                        {item.status === 'CREATED' && !isReadOnlyUser && !isTestReference(item) && (
                          <Button
                            variant="soft"
                            tone="violet"
                            size="sm"
                            onClick={() => onDispatch(item.refId)}
                            title="Lojistik Sevk Aç"
                          >
                            Sevk Et
                          </Button>
                        )}

                        {(item.status === 'SHIPPED' || item.status === 'IN_TRANSIT') && !isReadOnlyUser && !isTestReference(item) && (
                          <Button
                            variant="soft"
                            tone="emerald"
                            size="sm"
                            onClick={() => onReceive(item.refId)}
                            title="Ambar Kabul Formu Aç"
                          >
                            Kabul Et
                          </Button>
                        )}

                        {!isReadOnlyUser && (
                          <Button
                            variant="soft"
                            tone="rose"
                            size="sm"
                            icon={<AlertTriangle />}
                            aria-label="Barlag Akty / Incident Tutanağı"
                            onClick={() => onOpenIncident(item.refId)}
                            title="Barlag Akty / Incident Tutanağı"
                          />
                        )}

                        {onDeleteReference && !isReadOnlyUser && (
                          <Button
                            variant="danger"
                            size="sm"
                            icon={<Trash2 />}
                            aria-label="Sil"
                            onClick={() => setRefToDelete(item)}
                            title="Sil"
                          />
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* v2.8: Daha fazla göster */}
      {sortedReferences.length > visibleCount && (
        <div className="p-3 flex flex-col items-center gap-1 border-t border-slate-200 dark:border-slate-700">
          <Button variant="secondary" onClick={() => setVisibleCount(c => c + PAGE_SIZE)}>
            Daha fazla göster (+{Math.min(PAGE_SIZE, sortedReferences.length - visibleCount)})
          </Button>
          <span className="text-[11px] text-slate-500">{visibleCount} / {sortedReferences.length} kayıt gösteriliyor</span>
        </div>
      )}

      {/* Footer Info */}
      <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
        <div>
          Toplam <strong>{references.length}</strong> partiden <strong>{filtered.length}</strong> tanesi listeleniyor.
        </div>
        <div className="flex items-center gap-3">
          <span>MIWE HIL • Quality Traceability Platformu</span>
        </div>
      </div>

      {/* ALT BÖLÜM: Muz Hasat & Kalite Kontrol Kriterleri — İhracat (Export) vs Yerel Pazar Standartları (Kalite & İzlenebilirlik) */}
      {!isRecentLedger && showBananaQualityStandards && (
        <div id="banana-quality-standards-section" className="p-4 bg-gradient-to-r from-amber-50/90 via-white to-emerald-50/80 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 border-t border-slate-200 dark:border-slate-700/80 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white uppercase tracking-wide flex items-center gap-2">
              🍌 Muz Hasat & Kalite Kontrol Kriterleri — İhracat (Export) vs Yerel Pazar Standartları
            </h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 dark:text-emerald-300 px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/60 cursor-pointer"
              >
                ↑ Yukarı Çık
              </button>
              <button
                type="button"
                onClick={() => setShowBananaQualityStandards(false)}
                className="text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 cursor-pointer"
              >
                Kapat
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700/60 shadow-2xs space-y-1.5">
              <div className="font-black text-emerald-800 dark:text-emerald-300">
                1. İhracat (Export Pazar — Class Extra / Class I)
              </div>
              <ul className="space-y-1 text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                <li>• <strong>Parmak Kalibresi:</strong> 39.0 – 46.0 mm (3/4 köşeli dolgunluk, aşırı şişkin veya zayıf olmamalı).</li>
                <li>• <strong>Parmak Boyu:</strong> Min. 20.0 cm (Extra sınıfı ≥ 22.0 cm, dış yaydan ölçüm).</li>
                <li>• <strong>Renk Skalası & Yeşil Ömür:</strong> Kesimde Skala 1–2 Koyu Yeşil, etilenleme öncesi Green Life ≥ 21 gün.</li>
                <li>• <strong>Ambalaj & Soğuk Zincir:</strong> 18 kg Teleskopik Karton + MAP Poşet + Vakum Ön Soğutma (13.5°C – 14.0°C).</li>
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700/60 shadow-2xs space-y-1.5">
              <div className="font-black text-amber-800 dark:text-amber-300">
                2. Yerel Pazar (İç Piyasa & Zincir Market)
              </div>
              <ul className="space-y-1 text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                <li>• <strong>Parmak Kalibresi:</strong> 34.0 – 48.0 mm (Alt/uç taraklar ve kış/yaz erken kesim tarakları dahil).</li>
                <li>• <strong>Parmak Boyu:</strong> Min. 16.0 – 19.5 cm (Class II toleransı dahil).</li>
                <li>• <strong>Hasat & Sarartma Durumu:</strong> Skala 2–4 Yeşil/Sarı, sarartma odasına hızlı girişe uygun, yüzeysel sürtünme toleransı ≤ %10.</li>
                <li>• <strong>Kasa Tipi:</strong> 13 kg Yerel Pazar Plastik Kasa veya 15 kg Market Kasası.</li>
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-sky-300 dark:border-sky-700/60 shadow-2xs space-y-1.5">
              <div className="font-black text-sky-800 dark:text-sky-300">
                3. Yaz / Kış Erken Kesim & 11. Hafta Kuralı
              </div>
              <ul className="space-y-1 text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                <li>• <strong>11. Hafta (77. Gün) Eşiği:</strong> Doğumdan sonra 11. haftasına gelen kurdeleler resmi olarak Hasat Dönemine girmiştir.</li>
                <li>• <strong>Yaz Dönemi (Mayıs–Eylül):</strong> Yüksek sera sıcaklığıyla 70–78 günde (10–11 hf) kalibre dolar; gecikirse çatlama yapar.</li>
                <li>• <strong>Kış Dönemi (Ekim–Nisan):</strong> Düşük ışık/sıcaklıkla 85–102 günde (12–14.5 hf) hasada gelir.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* ALT BÖLÜM: Ambar Stok Uyarıları Paneli (Kayıtlar Panosu) */}
      {showStockAlerts && (
        <div id="stock-alerts-section" className="p-3 bg-amber-50/20 dark:bg-amber-950/10 border-t border-slate-200 dark:border-slate-700/80">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Ambar Kritik Stok Uyarıları</span>
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-[11px] font-bold text-amber-700 hover:text-amber-900 dark:text-amber-300 px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 cursor-pointer"
              >
                ↑ Yukarı Çık
              </button>
              <button
                type="button"
                onClick={() => setShowStockAlerts(false)}
                className="text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 cursor-pointer"
              >
                Kapat
              </button>
            </div>
          </div>
          <CriticalStockAlertCard
            ambarRecords={ambarRecords || []}
            lojistikRecords={lojistikRecords || []}
            salesRecords={salesRecords || []}
            references={references}
            onSelectModule={onSelectModule || (() => {})}
            onOpenAnalytics={onOpenAnalytics}
            currentUserId={currentUserId}
          />
        </div>
      )}

      {/* Deletion Confirmation Modal */}
      {refToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Referansı Silmek İstediğinize Emin Misiniz?
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  <strong className="font-mono text-slate-800">{refToDelete.refId}</strong> referans kodu ve buna bağlı tüm alt kayıtlar silinecektir.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRefToDelete(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Vazgeç / Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteReference && refToDelete) {
                    onDeleteReference(refToDelete.refId);
                    setRefToDelete(null);
                  }
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition"
              >
                Evet, Sil / Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Photo Preview Lightbox Modal */}
      {previewPhoto && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setPreviewPhoto(null)}
        >
          <div 
            className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-700 flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-100">{previewPhoto.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewPhoto.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg flex items-center gap-1 transition"
                  title="Yeni Sekmede Aç"
                >
                  <span>Tam Boyut</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => setPreviewPhoto(null)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 bg-slate-950 flex items-center justify-center overflow-auto max-h-[75vh]">
              <img
                src={previewPhoto.url}
                alt={previewPhoto.title}
                className="max-h-[70vh] max-w-full object-contain rounded-lg shadow-md"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
              <span>Google Drive / Bulut Depolama Fotoğrafı</span>
              <button
                onClick={() => setPreviewPhoto(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg text-xs transition"
              >
                Kapat / Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Status Update Modal */}
      <BulkStatusUpdateModal
        isOpen={isBulkUpdateModalOpen}
        onClose={() => setIsBulkUpdateModalOpen(false)}
        selectedRefs={selectedItemsList}
        onConfirmBulkUpdate={(refIds, newStatus, options) => {
          if (onBulkUpdateReferences) {
            onBulkUpdateReferences(refIds, newStatus, options);
          }
          handleClearSelection();
        }}
        currentUserId={currentUserId}
      />

      {/* Quick Administrative Note Modal (Formu Açmadan Hızlı Not) */}
      <QuickAdminNoteModal
        isOpen={Boolean(quickNoteRef)}
        onClose={() => setQuickNoteRef(null)}
        reference={quickNoteRef}
        onSaveNote={handleSaveQuickNote}
        currentOperator={currentUserId || 'Yönetici'}
      />

      {/* Quick Note Success Notification Toast */}
      {quickNoteToast && (
        <div className="fixed bottom-6 right-6 z-[130] animate-in slide-in-from-bottom-5 duration-200">
          <div className="bg-slate-900/95 dark:bg-slate-800/95 text-white px-4 py-3 rounded-2xl shadow-2xl border border-amber-500/40 flex items-center gap-3 backdrop-blur-md">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 font-bold">
              <StickyNote className="w-4 h-4 text-slate-950" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-300">İdari Not Kaydedildi</div>
              <div className="text-xs text-slate-200">{quickNoteToast.message}</div>
            </div>
            <button
              onClick={() => setQuickNoteToast(null)}
              className="p-1 text-slate-400 hover:text-white rounded-lg transition ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* QR Code Label Modal for Warehouse Intake */}
      <QrCodeModal
        reference={qrModalRef}
        onClose={() => setQrModalRef(null)}
      />

      {/* Bulk Reject (REJECTED) Modal */}
      <BulkRejectModal
        isOpen={isBulkRejectModalOpen}
        selectedCount={selectedRefIds.size}
        onClose={() => setIsBulkRejectModalOpen(false)}
        onConfirm={handleConfirmBulkReject}
      />

    </div>
  );
};
