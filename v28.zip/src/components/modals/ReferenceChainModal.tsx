import React from 'react';
import { X, FileText, Archive, ArchiveRestore, ChevronRight } from 'lucide-react';
import type { AmbarRecord, FieldRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { isTestReference } from '../../utils/refKind';
import { Badge, Button } from '../ui';

/**
 * v2.8 — Referans zinciri: hangi numaradan girilirse girilsin (test, parti) tüm akış tek yerde.
 * Test → Hasat → Ön soğutma → Depo (+ kontroller) → Çıkış (sevk / satış) → DÖF; ağırlık akışı ve fire.
 */
interface Props {
  refId: string;
  references: ReferenceItem[];
  fieldRecords: FieldRecord[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  incidentRecords?: any[];
  isAdmin?: boolean;
  onOpenRef: (refId: string) => void;
  onOpenPdf?: (ref: ReferenceItem) => void;
  onToggleArchive?: (ref: ReferenceItem) => void;
  onClose: () => void;
}

const kg = (v?: number | null) => (v == null || Number.isNaN(v) ? '—' : `${Number(v).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} kg`);
const d10 = (v?: string) => (v ? String(v).slice(0, 10) : '—');
const lossText = (from?: number | null, to?: number | null) => {
  if (!from || from <= 0 || to == null) return null;
  const loss = from - to;
  return `${loss.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} kg (%${((loss / from) * 100).toLocaleString('tr-TR', { maximumFractionDigits: 2 })})`;
};

export default function ReferenceChainModal({ refId, references, fieldRecords, harvestRecords, ambarRecords, lojistikRecords, salesRecords, incidentRecords = [], isAdmin, onOpenRef, onOpenPdf, onToggleArchive, onClose }: Props) {
  const ref = references.find(r => r.refId === refId);
  const isTest = ref ? isTestReference(ref) : false;

  const tests = fieldRecords.filter(f => f.refId === refId);
  const linkedTests = ref?.linkedTestRefIds || [];
  const lotsUsingThisTest = references.filter(r => (r.linkedTestRefIds || []).includes(refId));
  const harvests = harvestRecords.filter(h => h.refId === refId).sort((a, b) => String(a.recordDate || a.timestamp || '').localeCompare(String(b.recordDate || b.timestamp || '')));
  const slips = [...(ref?.precoolingSlips || [])].sort((a, b) => a.date.localeCompare(b.date));
  const ambars = ambarRecords.filter(a => a.refId === refId);
  const firstEntry = ambars.map(a => a.acceptanceDate || a.timestamp || '').filter(Boolean).sort()[0]?.slice(0, 10) || '';
  const exits = [
    ...lojistikRecords.filter(l => l.refId === refId && (!firstEntry || (l.shipmentDate || '').slice(0, 10) >= firstEntry))
      .map(l => ({ kind: 'Sevk', date: l.shipmentDate, kg: Number(l.weightKg) || 0, to: (l as any).destination || '' })),
    ...salesRecords.filter(s => s.refId === refId).map(s => ({ kind: 'Satış', date: s.salesDate, kg: Number(s.totalQuantityKg) || 0, to: (s as any).customerName || (s as any).customer || '' }))
  ].sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const preEntryMoves = firstEntry ? lojistikRecords.filter(l => l.refId === refId && (l.shipmentDate || '').slice(0, 10) < firstEntry) : [];
  const incidents = incidentRecords.filter((i: any) => i.refId === refId);

  // Ağırlık akışı (fire hasattan sonra başlar)
  const harvestKg = harvests.reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0) || null;
  const shockKg = slips.reduce((s, x) => s + (x.netKg || 0), 0) || null;
  const depotKg = ambars.reduce((s, a) => s + (Number(a.acceptedWeightKg) || 0), 0) || null;
  const outKg = exits.reduce((s, x) => s + x.kg, 0) || null;
  const remaining = depotKg != null ? Math.max(0, depotKg - (outKg || 0)) : null;

  const Chip = ({ id }: { id: string }) => (
    <button type="button" onClick={() => onOpenRef(id)} className="inline-flex items-center gap-1 min-h-[32px] px-2.5 rounded-full border border-teal-200 bg-teal-50 text-teal-900 text-xs font-mono font-semibold dark:bg-teal-950/40 dark:text-teal-100 dark:border-teal-900">
      {id}<ChevronRight className="w-3 h-3" />
    </button>
  );
  const Step = ({ title, count, children, empty }: { title: string; count?: number; children?: React.ReactNode; empty: string }) => (
    <li className="relative pl-6">
      <span className={`absolute left-0 top-1.5 w-3 h-3 rounded-full border-2 ${count ? 'bg-teal-600 border-teal-600' : 'bg-white border-slate-300 dark:bg-slate-900'}`} aria-hidden="true" />
      <p className="text-sm font-semibold text-slate-900 dark:text-white">{title}{count ? <span className="text-slate-500 font-normal"> · {count}</span> : null}</p>
      <div className="text-xs text-slate-700 dark:text-slate-300 mt-0.5 space-y-0.5">{count ? children : <span className="text-slate-500">{empty}</span>}</div>
    </li>
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={`${refId} zinciri`} className="bg-white dark:bg-slate-900 w-full sm:max-w-xl rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-mono text-base font-bold text-slate-900 dark:text-white truncate">{refId}</p>
            <p className="text-xs text-slate-600 dark:text-slate-400 truncate">{ref ? `${ref.product}${ref.variety ? ` (${ref.variety})` : ''} · ${ref.location || '—'}` : 'Kayıt bulunamadı'}</p>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              <Badge tone={isTest ? 'info' : 'ok'}>{isTest ? 'Test' : 'Parti'}</Badge>
              {ref?.archived && <Badge tone="nodata">Arşivde</Badge>}
            </div>
          </div>
          <button type="button" onClick={onClose} aria-label="Kapat" className="p-2 rounded-lg text-slate-500 min-h-[40px] min-w-[40px] flex items-center justify-center"><X className="w-5 h-5" /></button>
        </div>

        <div className="overflow-y-auto p-4 space-y-4">
          {isTest && (
            <section>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Bu teste bağlı partiler</p>
              {lotsUsingThisTest.length ? <div className="flex flex-wrap gap-1.5">{lotsUsingThisTest.map(r => <Chip key={r.refId} id={r.refId} />)}</div>
                : <p className="text-xs text-slate-500">Henüz bu testle bağlanmış hasat yok.</p>}
            </section>
          )}
          {!isTest && linkedTests.length > 0 && (
            <section>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Bağlı testler</p>
              <div className="flex flex-wrap gap-1.5">{linkedTests.map(id => <Chip key={id} id={id} />)}</div>
            </section>
          )}

          {!isTest && (
            <section className="rounded-xl border border-slate-200 dark:border-slate-800 p-3">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Ağırlık akışı</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div><span className="text-slate-500 block">Hasat</span><strong>{harvestKg ? kg(harvestKg) : 'tartılmadı'}</strong></div>
                <div><span className="text-slate-500 block">Şoklanan</span><strong>{kg(shockKg)}</strong></div>
                <div><span className="text-slate-500 block">Depoya giriş</span><strong>{kg(depotKg)}</strong></div>
                <div><span className="text-slate-500 block">Depoda kalan</span><strong>{kg(remaining)}</strong></div>
              </div>
              {(lossText(harvestKg, shockKg) || lossText(shockKg ?? harvestKg, depotKg)) && (
                <div className="mt-2 text-xs text-slate-700 dark:text-slate-300 space-y-0.5">
                  {lossText(harvestKg, shockKg) && <p>Fire hasat → şoklama: <strong>{lossText(harvestKg, shockKg)}</strong></p>}
                  {lossText(shockKg ?? harvestKg, depotKg) && <p>Fire {shockKg ? 'şoklama' : 'hasat'} → depo: <strong>{lossText(shockKg ?? harvestKg, depotKg)}</strong></p>}
                </div>
              )}
            </section>
          )}

          <ol className="space-y-3 border-l border-slate-200 dark:border-slate-800 ml-1.5">
            <Step title="Test" count={tests.length} empty={isTest ? 'Test kaydı yok.' : linkedTests.length ? 'Testler bağlı numaralarda (yukarıda).' : 'Bağlı test yok.'}>
              {tests.map(t => <p key={t.id}>{d10(t.harvestDate || t.timestamp)} · {(t as any).testType || 'Saha testi'} · Brix {t.avgBrix > 0 ? t.avgBrix : '—'} · sertlik {t.avgHardness > 0 ? t.avgHardness : '—'}</p>)}
            </Step>
            {!isTest && <>
              <Step title="Hasat" count={harvests.length} empty="Hasat kaydı yok.">
                {harvests.map(h => <p key={h.id}>{d10(h.recordDate || h.timestamp)}{h.harvestDayNo ? ` · ${h.harvestDayNo}. gün` : ''} · {Number(h.dailyTotalKg) > 0 ? kg(Number(h.dailyTotalKg)) : 'kg girilmedi'}{h.workerCount ? ` · ${h.workerCount} kişi` : ''}{h.rowSection ? ` · sıra ${h.rowSection}` : ''}</p>)}
              </Step>
              <Step title="Ön soğutma" count={slips.length} empty="Fiş yok.">
                {slips.map(sl => <p key={sl.id}><span className="font-mono">{sl.slipNo}</span> · {sl.date} · {kg(sl.netKg)} · {sl.inspectionMode === 'FIVE_PERCENT' ? '%5 inspeksiyon' : sl.inspectionMode === 'SORTING' ? 'doğrudan sorting' : '—'}</p>)}
              </Step>
              <Step title="Depo" count={ambars.length} empty="Depo kaydı yok.">
                {preEntryMoves.length > 0 && <p className="text-slate-500">Depoya taşıma: {preEntryMoves.length} kayıt</p>}
                {ambars.map(a => <p key={a.id}>{d10(a.acceptanceDate || a.timestamp)} · {a.warehouse || '—'} / {a.roomNo || '—'}{a.stackRow ? ` / ${a.stackRow}` : ''} · {kg(a.acceptedWeightKg)}{a.storageChecks?.length ? ` · ${a.storageChecks.length} kontrol` : ''}</p>)}
              </Step>
              <Step title="Çıkış" count={exits.length} empty="Henüz çıkış yok.">
                {exits.map((x, k) => <p key={k}>{d10(x.date)} · {x.kind} · {kg(x.kg)}{x.to ? ` · ${x.to}` : ''}</p>)}
              </Step>
            </>}
            <Step title="DÖF / uygunsuzluk" count={incidents.length} empty="Yok.">
              {incidents.map((i: any) => <p key={i.id}>{d10(i.date || i.timestamp)} · {i.title || i.category || i.type || 'Kayıt'}</p>)}
            </Step>
          </ol>
        </div>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap justify-end gap-2 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))]">
          {isAdmin && ref && onToggleArchive && (
            <Button variant="soft" tone="slate" icon={ref.archived ? <ArchiveRestore /> : <Archive />} onClick={() => onToggleArchive(ref)}>
              {ref.archived ? 'Arşivden çıkar' : 'Arşivle'}
            </Button>
          )}
          {ref && onOpenPdf && <Button variant="primary" icon={<FileText />} onClick={() => onOpenPdf(ref)}>PDF</Button>}
        </div>
      </div>
    </div>
  );
}
