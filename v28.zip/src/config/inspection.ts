/** v2.8 — %5 inspeksiyon sınıfları (tüm ürünlerde aynı). Sıra = raporlardaki sıra. */
export const INSPECTION_CLASSES = ['Extra', 'Exclusive', 'Premium', 'Classic', 'Mix', 'Standart dışı'] as const;

/** Sınıf kg'larından yüzde (3 ondalık). Toplam 0 ise null. */
export function inspectionPercents(rows: { cls: string; kg?: number }[]): { cls: string; kg: number; pct: number | null }[] {
  const total = rows.reduce((s, r) => s + (r.kg && r.kg > 0 ? r.kg : 0), 0);
  return rows.map(r => ({ cls: r.cls, kg: r.kg && r.kg > 0 ? r.kg : 0, pct: total > 0 ? Number((((r.kg && r.kg > 0 ? r.kg : 0) / total) * 100).toFixed(3)) : null }));
}
