# v49c9 — C proje (dış bahçeler) + konum alma + Bahçe profili: Bahçeler · Seralar · Açık tarla (v49c7 ve v49c8 dahil)

v49c7 ve v49c8 bu pakette; ayrıca uygulanmaz.
v49c8 içeriği: Bahçe profili sekmeleri (Bahçeler · Seralar · Açık tarla), tüm bahçelere 2027 planı (v2_1911), Garahan 1600 ha 169 parsel,
firmalara bölünmüş çeşitlerin birleşmesi, seraların ve açık tarlanın plan kartı, Ana sayfa kısayolları.
Yeni (v49c9):
1. "C proje" sekmesi (YENİ config/externalOrchards.ts): bize ait olmayan, sipariş üzerine değerlendirilen 5 birim —
   C · Şyhberdi baglary (Saýwan, Bäherden), C · Durun (Akmyrat-Wepa-Isgender), C · Bugdaýly bagy (Änew), C · Bamy sogan meýdany (Akdepe), C · Sekiz ýap bagy (Gökdepe).
   Her biri: yer, sorumlu, ağaç/alan, beyan edilen plan, konum durumu; ziyaret raporu (tarih, sipariş, ekip, ürün·çeşit, ağaç/ha, plan t, kalite t −%30, hasat ayı;
   satıra dokununca gözlem, uygunluk/saklama, yapılacak kontroller).
2. Yer profillerine bu 5 birim eklenir (profileSeed; var olan profile dokunulmaz). Bahçe ve tarla profiline iki alan: "Sahiplik" (Kendi / C proje) ve "Sorumlu / iletişim".
   C proje birimleri Bahçeler / Açık tarla listelerinde görünmez, yalnız C proje sekmesinde.
3. Yer profili düzenlerken "Konumumu al": telefonun konumu enlem/boylama yazılır (izin ister), Kaydet ile saklanır. Bahçe, sera ve tarlada.
4. Telefon numaraları koda yazılmadı.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (11 dosya)
1a34241c91f940180da31b1c39fed27ec044c283969d000877af224e4433eb7f  src/App.tsx
cb4523ca8d83e229e53a500e48db6d8d1e18e69e8492b33b64b6559c967dd081  src/config/orchardCards.ts
888dcdc56deca923a52a54ba8241c393998bbb4e274297a90b36afaabf18fe2b  src/config/unitPlans.ts
485b8b351289bbf4742c1b7004f89637cc29acaedd015073b79be3f3362a2d2b  src/config/externalOrchards.ts
e1376cf8d428379a44ea93b7fae6722af3439107e0d276a7003c5f02adbd7a92  src/config/profileSeed.ts
4a7879e1b0436608be9f8cd0a3d6ab3d367188ad00cee873ecdb6e4fcc4df472  src/services/orchardOverview.ts
12cd80a09e0f284a09b6f60e70e9db9950a200c5a3234c2bced9ada31614094d  src/services/locationProfiles.ts
2656a0545642c558d0be65c663eba260bbe95208cb7485a225069c2ce7a14518  src/components/views/OrchardCardsView.tsx
0f3fd406ca7de699cc7bb5c087c642c5af6557195b840e0122533088107e023e  src/components/dashboard/OrchardsPanel.tsx
43d24155c02c085e5178e0c8880dd088bf818f517c5bdf936ec4a49f2fc9c231  src/components/portal/HomeMenu.tsx
c24e2ee5829802ca44343c83770f0e3d22b6b44f1c6996a1fa496ccab756d013  src/components/coldchain/LocationProfilesModal.tsx
