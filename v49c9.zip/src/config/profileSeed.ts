/**
 * v49a — Profil tohum verisi (kullanıcının dosyalarından, 23.11.2026):
 *  - tonaj Excel'i (v2_1911 tonajlar genel): bahçe, firma, ürün/çeşit, 2027 plan tonajı
 *  - 2027 verim tahmini (1600 ha): bölüm, parsel, alan, ağaç, çeşit, dikim yılı, anaç
 *  - Book1 (muz): sera bölmeleri, alan, 2027 tonaj
 *  - Açyk ekin býujet 2027: ekin ve alan (para bilgisi alınmadı)
 *  - Bahçe koordinatları: kullanıcının harita noktaları (orchardLocations)
 * Kullanıcı profil ekranında düzenler; bu liste yalnız profil HİÇ yoksa eklenir (id sabit: seed-…).
 */
import type { LocationKind } from '../services/locationProfiles';

export interface SeedProfile {
  id: string;
  kind: LocationKind;
  name: string;
  aliases: string[];
  fields: Record<string, string | number | boolean>;
  note?: string;
}

export const PROFILE_SEED: SeedProfile[] = [
  { id: 'seed-orchard-bagyr', kind: 'ORCHARD', name: 'Bagyr', aliases: ['Bagyr (Nektarin)', 'Bagir'],
    fields: { region: 'Aşgabat', lat: 37.988616, lon: 58.184727, company: 'Nektarin', plan2027Ton: 1042,
      products: 'Elma: Ginger Gold, Golden Delicious, Golden Reinders, Granny Smith, Rosy Glow, Story Inored · Şeftali: Extreme 314, Extreme 436, Plane Summer, Royal Summer, Sweet Dream, UFO-4 · Nektarin: Extreme Red, Fresh Garnet, Gartario · Armut: Williams' } },
  { id: 'seed-orchard-saywan-nektarin', kind: 'ORCHARD', name: 'Saýwan Nektarin', aliases: ['Saywan (Nektarin)', 'Saýwan', 'Saywan', 'Saywan nektarin', 'Saywan nekdarin'],
    fields: { region: 'Balkan', lat: 38.537343, lon: 56.720592, company: 'Nektarin', plan2027Ton: 811,
      products: 'Kiraz: Brooks, Early Burlat, Early Lory, Folfer, Kordia, Lapins, Premier Giant, Regina, Santina, Skeena, Staccato, Sweet Heart · Elma: Early Gold, Gala Vall, Golden Reinders, Rosy Glow, Scarlet Spur · Şeftali: Extreme 436, Plane Delicious, Sweet Dream' } },
  { id: 'seed-orchard-saywan-gursak', kind: 'ORCHARD', name: 'Saýwan Gursak', aliases: ['Gursak', 'Saywan Gursak'],
    fields: { region: 'Balkan', lat: 38.534368, lon: 56.743097, company: 'Gursak', plan2027Ton: 898,
      products: 'Kiraz: Early Burlat, Kordia, Premier Giant, Regina, Staccato · Şeftali: Cresthaven, Extreme 568, Extreme Great, Extreme Gursak, Extreme July, Glohaven, Glosari · Elma: Fuji, Golden Reinders, Rosy Glow, Scarlet Spur · Nektarin: Sweet Lady' } },
  { id: 'seed-orchard-durun', kind: 'ORCHARD', name: 'Durun', aliases: ['Baherden'],
    fields: { region: 'Baherden (Ahal)', lat: 38.383322, lon: 57.432445, company: 'Durun', plan2027Ton: 98,
      products: 'Elma: Scarlet Spur, Golden Reinders, Granny Smith (hasat takviminden)' },
    note: 'Tonaj Excel\'inde "Nektarin · tüm çeşitler, 98 t" yazıyor; hasat takviminde elma. Kontrol edin.' },
  { id: 'seed-orchard-garahan-1200', kind: 'ORCHARD', name: 'Garahan 1200 ha', aliases: ['Garahan (1200)', 'Miwe 1200', 'Garahan1200', 'Garahan 1200'],
    fields: { region: 'Ahal', lat: 37.211482, lon: 59.813087, company: 'MIWE OJSC', sections: 'HS · GB · MA · DM', plan2027Ton: 2500,
      products: 'Badem: Ferraduel, Ferragnes, Lauranne, Makako, Marinada, Nonpareil, Tarraco, Texas, Vairo · Şeftali: Extreme 314, Extreme 514, Extreme Red, Fresh Rock, Gartairo, Plane Sun · Nektarin: Caldesi 85, Extreme 28, Extreme 710, Gartairo, Honey Late · Elma: Ginger Gold, Rosy Glow, Simerenka, Story Inored · Armut: Carmen, Santa Maria, Williams · Nashi: Chojuro, Kosui · Erik: Black Splendor, Pioneer · Hurma: Rojo Brillante' } },
  { id: 'seed-orchard-garahan-1600', kind: 'ORCHARD', name: 'Garahan 1600 ha', aliases: ['Garahan (1628)', '1628 ha', '1628ha', 'Garahan1600', 'Garahan 1600'],
    fields: { region: 'Ahal', lat: 37.190531, lon: 59.888403, areaHa: 1519, treeCount: 632865, rootstock: 'GARNEM', plan2027Ton: 452,
      sections: 'MU 311 ha · 129.537 ağaç · Makako · 2023 | ED 311 ha · 129.537 ağaç · Lauranne + Makako · 2023–26 | IG 300 ha · 124.909 ağaç · Lauranne · 2023 | TE 311 ha · 129.537 ağaç · Vairo + Marta · 2023–25 | LI 286 ha · 119.345 ağaç · Ferragnes + Ferraduel · 2023–24',
      products: 'Badem: Ferraduel, Ferragnes, Lauranne, Makako, Marta, Vairo', plantYears: '2023–2026' } },

  { id: 'seed-gh-garahan-yyladyshana', kind: 'GREENHOUSE', name: 'Garahan Ýyladyşhana', aliases: ['Garahan Teplisa', 'Garahan Yyladyshana', 'Garahan Ýyladyşhana'],
    fields: { crop: 'Kiraz (deneme)', region: 'Ahal' }, note: 'Koordinat girilmedi.' },
  ...([
    ['5 ga', '5GA', 5, 365], ['HS 11-12', 'HS', 10, 870], ['GB 5-6', 'GB', 10, 685], ['GB 7-8', 'GB', 10, 850],
    ['MA 1-2', 'MA', 10, 657], ['MA 3-4', 'MA', 10, 927], ['MU 9-10', 'MU', 10, 911], ['MU 13-14', 'MU', 10, 0],
    ['MU 15-16', 'MU', 10, 0], ['DM 17-18', 'DM', 10, 0], ['DM 19-20', 'DM', 10, 0],
  ] as [string, string, number, number][]).map(([n, sec, ha, t]) => ({
    id: `seed-gh-muz-${n.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`, kind: 'GREENHOUSE' as LocationKind, name: `Muz sera ${n}`,
    aliases: [`Sera ${n}`, `${sec} (${n.split(' ')[1] || n}) muz`],
    fields: { crop: 'Muz', company: sec, areaHa: ha, plan2027Ton: t },
  })),

  // ── v49c: depolar ve odalar (kullanıcının 19.11 / 29.10 oda kontrol tablolarından, 24.11.2026) ──
  // Oda adı "<depo kısa adı> · <oda kodu>"; set aralığı son tablodaki ayardır, ürün değişince profilde güncellenir.
  { id: 'seed-wh-pm', kind: 'WAREHOUSE', name: 'PM · Paýlaýyş nokady', aliases: ['PM', 'Paýlaýyş nokady', 'Paylayys nokady', 'Paýlaýyş nokady (PM)', 'PM Lojistik'],
    fields: { shortName: 'PM', address: 'Aşgabat', roomCount: 17 }, note: 'Lojistik merkez: kabul, sortlama, sarartma, kısa istif, sevk.' },
  { id: 'seed-wh-garahan', kind: 'WAREHOUSE', name: 'Garahan · Kaka', aliases: ['Garahan', 'Kaka', 'Garahan depo', 'Garahan soğuk depo', 'Garahan (Kaka)'],
    fields: { shortName: 'Garahan', address: 'Garahan · Kaka', roomCount: 16 }, note: 'Bina G-1 (meyve, CA) ve G-2 (badem).' },
  { id: 'seed-wh-bagyr', kind: 'WAREHOUSE', name: 'Bagyr depo', aliases: ['Bagyr soğuk depo', 'Bagyr ambar'],
    fields: { shortName: 'Bagyr', address: 'Bagyr bahçesi', roomCount: 2 }, note: 'Her oda 40–60 t; kesin kapasite profilden girilecek.' },
  { id: 'seed-wh-gursak', kind: 'WAREHOUSE', name: 'Saýwan Gursak depo', aliases: ['Gursak depo', 'Saywan Gursak depo'],
    fields: { shortName: 'Gursak', address: 'Saýwan Gursak bahçesi', roomCount: 2 }, note: 'Her oda 40–60 t; kesin kapasite profilden girilecek.' },
  { id: 'seed-wh-muz', kind: 'WAREHOUSE', name: 'Muz seraları', aliases: ['Muz sera soğutma', 'Muz soğutma odaları'],
    fields: { shortName: 'Muz', address: 'Muz seraları', roomCount: 7 }, note: 'Her serada 10–15 t soğutma odası.' },
  ...([
    // [depo adı, kısa, bina, kod, tip, setMin, setMax]
    ['PM · Paýlaýyş nokady', 'PM', '', 'TS-1', 'Satışa hazır', 4, 5], ['PM · Paýlaýyş nokady', 'PM', '', 'TS-2', 'Satışa hazır', 5, 6],
    ['PM · Paýlaýyş nokady', 'PM', '', 'M-1', 'Soğuk depo', -0.5, 0.5], ['PM · Paýlaýyş nokady', 'PM', '', 'M-2', 'Soğuk depo', 0, 1],
    ['PM · Paýlaýyş nokady', 'PM', '', 'M-3', 'Soğuk depo', 1, 3], ['PM · Paýlaýyş nokady', 'PM', '', 'M-4', 'Soğuk depo', 10, 12],
    ['PM · Paýlaýyş nokady', 'PM', '', 'M-5', 'Soğuk depo', -1, 1.5], ['PM · Paýlaýyş nokady', 'PM', '', 'GÖ', 'Soğuk depo', 0, 1],
    ['PM · Paýlaýyş nokady', 'PM', '', 'B-1', 'Sarartma', 13, 14], ['PM · Paýlaýyş nokady', 'PM', '', 'B-2', 'Soğuk depo', 12, 13],
    ['PM · Paýlaýyş nokady', 'PM', '', 'B-3', 'Soğuk depo', 4, 5],
    ['PM · Paýlaýyş nokady', 'PM', '', 'FD-1', 'Donuk depo', -24, -20], ['PM · Paýlaýyş nokady', 'PM', '', 'FD-2', 'Soğuk depo', 4, 8],
    ['PM · Paýlaýyş nokady', 'PM', '', 'FD-3', 'Soğuk depo', 14, 15],
    ['PM · Paýlaýyş nokady', 'PM', '', 'İşleme I', 'İşleme alanı', 14, 15], ['PM · Paýlaýyş nokady', 'PM', '', 'İşleme M', 'İşleme alanı', 14, 15],
    ['PM · Paýlaýyş nokady', 'PM', '', 'İşleme B', 'İşleme alanı', 14, 15],
    ['Garahan · Kaka', 'Garahan', 'G-1', 'M-1', 'Soğuk depo', 0, 1], ['Garahan · Kaka', 'Garahan', 'G-1', 'M-2', 'Soğuk depo', 0.5, 1.5],
    ['Garahan · Kaka', 'Garahan', 'G-1', 'M-3', 'Soğuk depo', 0.5, 1.5], ['Garahan · Kaka', 'Garahan', 'G-1', 'M-4', 'Soğuk depo', 0, 1],
    ['Garahan · Kaka', 'Garahan', 'G-1', 'KA-1', 'Kontrollü atmosfer', 0.5, 1.5], ['Garahan · Kaka', 'Garahan', 'G-1', 'KA-2', 'Kontrollü atmosfer', 0.5, 1.5],
    ['Garahan · Kaka', 'Garahan', 'G-1', 'KA-3', 'Kontrollü atmosfer', 4, 5],
    ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-1', 'Soğuk depo', 0.5, 1.5], ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-3', 'Soğuk depo', 1.2, 2.2],
    ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-4', 'Soğuk depo', 0, 1], ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-5', 'Soğuk depo', 0, 1],
    ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-6', 'Soğuk depo', -5, -4], ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-7', 'Soğuk depo', -3.4, -2.4],
    ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-8', 'Soğuk depo', 0, 1], ['Garahan · Kaka', 'Garahan', 'G-2', 'GÖ-9', 'Soğuk depo', 0, 1],
    ['Garahan · Kaka', 'Garahan', 'G-2', 'TS', 'Satışa hazır', 5, 6],
    ['Bagyr depo', 'Bagyr', '', 'Ön soğutma', 'Ön soğutma', '', ''], ['Bagyr depo', 'Bagyr', '', 'Soğutma odası', 'Soğuk depo', '', ''],
    ['Saýwan Gursak depo', 'Gursak', '', 'Hidrocooling', 'Ön soğutma', '', ''], ['Saýwan Gursak depo', 'Gursak', '', 'Soğutma odası', 'Soğuk depo', '', ''],
    ...['5 ga', 'HS 11-12', 'GB 5-6', 'GB 7-8', 'MA 1-2', 'MA 3-4', 'MU 9-10'].map(n => ['Muz seraları', 'Muz', '', n, 'Soğuk depo', 13, 14]),
  ] as [string, string, string, string, string, number | '', number | ''][]).map(([wh, sh, bld, code, type, mn, mx], i) => ({
    id: `seed-room-${sh.toLowerCase()}-${code.toLowerCase().replace(/ö/g, 'o').replace(/i̇|ı/g, 'i').replace(/[^a-z0-9]+/g, '-')}`,
    kind: 'ROOM' as LocationKind,
    name: `${sh} · ${code}`,
    aliases: [] as string[],
    fields: {
      warehouse: wh, code, roomType: type, sortNo: i, ...(bld ? { building: bld } : {}),
      ...(mn !== '' ? { setMinC: mn } : {}), ...(mx !== '' ? { setMaxC: mx } : {}),
      ...(type === 'Kontrollü atmosfer' ? { atmosphere: 'CA (kontrollü)' } : {}),
      ...(sh === 'Muz' ? { capacityKg: 12500 } : {}),
    },
    note: sh === 'Bagyr' || sh === 'Gursak' ? 'Kapasite 40–60 t (kesin değer girilecek).' : sh === 'Muz' ? 'Kapasite 10–15 t; 12,5 t orta değer girildi, kesin değeri düzeltin.' : undefined,
  })),

  { id: 'seed-field-acyk-ekin', kind: 'FIELD', name: 'Açyk ekin (Garahan)', aliases: ['Açyk ekin', 'Acyk ekin', 'Açık ekin'],
    fields: { region: 'Garahan', areaHa: 398,
      crops: 'Soğan şubat 118 ha · Soğan eylül 2026 40 ha · Soğan eylül 2027 50 ha · Patates şubat 55 ha · Patates ağustos 50 ha · Mısır 50 ha · Gara jöwen 20 ha · Kırmızı pancar 10 ha · Sarımsak 5 ha' } },

  // ── v49c9: C proje — bize ait olmayan, sipariş üzerine değerlendirilen bahçe / tarlalar (ziyaret raporlarından; koordinat sahada "Konumumu al" ile girilir) ──
  { id: 'seed-c-syhberdi', kind: 'ORCHARD', name: 'C · Şyhberdi baglary', aliases: ['Şyhberdi baglary', 'Syhberdi baglary'],
    fields: { ownership: 'C proje (dış bahçe)', region: 'Saýwan, Bäherden', contact: 'Mehmet bey (baş agranom)', products: 'Elma: Granny Smith, Golden Delicious, Red Chief · Armut: Deveci, Santa Maria · Şeftali: Glohaven, Cresthaven', treeCount: 121748 },
    note: 'Ziyaret 11.06.2026 · sipariş: Merkez (güz elmaları).' },
  { id: 'seed-c-durun-akmyrat', kind: 'ORCHARD', name: 'C · Durun (Akmyrat-Wepa-Isgender)', aliases: ['Durun Akmyrat'],
    fields: { ownership: 'C proje (dış bahçe)', region: 'Durun, Bäherden', contact: 'Nury aga (agronom)', products: 'Elma: Scarlet Spur, Golden Delicious, Gala · Soğan: Elena, Sanjar, kırmızı geç soğan' },
    note: 'Ziyaret 07.08 ve 19.08.2026.' },
  { id: 'seed-c-bugdayly', kind: 'ORCHARD', name: 'C · Bugdaýly bagy', aliases: ['Bugdaýly bagy', 'Bugdayly'],
    fields: { ownership: 'C proje (dış bahçe)', region: 'Bugdaýly, Änew', contact: 'Kakyş (müdür)', products: 'Elma: Golden Delicious', areaHa: 2.5 },
    note: 'Ziyaret 11.06.2026 · sipariş: Merkez – Baýram aga ofis.' },
  { id: 'seed-c-bamy', kind: 'FIELD', name: 'C · Bamy sogan meýdany', aliases: ['Bamy sogan'],
    fields: { ownership: 'C proje (dış bahçe)', region: 'Bamy, Bäherden – Akdepe', contact: 'Arslan inžener (müdür)', crops: 'Soğan (Sanjar, Elena, Bereket) 25 ha · Soğan Elena 5 ha', areaHa: 30 },
    note: 'Ziyaret 19.08.2026.' },
  { id: 'seed-c-sekiz-yap', kind: 'ORCHARD', name: 'C · Sekiz ýap bagy', aliases: ['Sekiz ýap', 'Sekiz yap'],
    fields: { ownership: 'C proje (dış bahçe)', region: 'Sekiz ýap, Gökdepe', contact: 'Guwanç (bahçe sahibi)', products: 'Elma: Scarlet Spur', areaHa: 6.5 },
    note: 'Ziyaret 22.08.2026 · 6,5 ha ceviz ve az hurma da var.' },
];
