/**
 * v49c9 — C proje: bize ait olmayan, sipariş üzerine değerlendirdiğimiz bahçe / tarlalar.
 * Kaynak: SAYWAN_Bag_11.06.2026 (1).xlsx — 5 ziyaret raporu (11.06 · 07.08/19.08 · 11.06 · 19.08 · 22.08.2026).
 * Telefon numaraları koda yazılmadı; gerekirse yer profilinin "Sorumlu / iletişim" alanına girilir.
 * "planT" bahçe sorumlusunun beyanı, "qualityT" bizim tahminimiz (−%30).
 */
export interface ExternalItem { fruit: string; variety: string | null; trees: number | null; ha: number | null; planT: number | null; qualityT: string | null; harvest: string | null; note: string | null; suitability: string | null; checks: string | null }
export interface ExternalVisit { code: string; name: string; kind: 'ORCHARD' | 'FIELD'; region: string; title: string | null; basis: string | null; team: string[]; responsible: string | null; dates: string[]; items: ExternalItem[] }
export const EXTERNAL_SOURCE = 'C proje ziyaret raporları (SAYWAN_Bag_11.06.2026)';
export const EXTERNAL_VISITS: ExternalVisit[] = [
 {
  "code": "110626-1",
  "name": "C · Şyhberdi baglary",
  "kind": "ORCHARD",
  "region": "Saýwan, Bäherden",
  "title": "Saýwan bag hasabaty  (Şyhberdi baglary)",
  "basis": "Sargyt, Merkez tarapyndan - Güýz almalary barada hasyl we ýagdaýlary",
  "team": [
   "Fatih Ýalaw (hasyl we soňrasy hünärmeni- maslahatçy)",
   "Sapa Berdiýew (baş agranom),",
   "Sapa Altyýew (hil baş hünärmen)",
   "Maksat Hydyrlyýew ( hil topar müdiri)"
  ],
  "responsible": "Mehmet bey (baş agranom)",
  "dates": [
   "11.06.2026"
  ],
  "items": [
   {
    "fruit": "Elma",
    "variety": "Granny smith",
    "trees": 24462,
    "ha": null,
    "planT": 300,
    "qualityT": "210",
    "harvest": "Oktyabr",
    "note": "seyreltme gowy, gyzyl yanak bar, kalibrlary gowy cykar, miwe sagdyn. (11.06.2026)",
    "suitability": "Uzyn saklamana yaramly 5-8 ay, kalibrlar eksportlyk miwe 40-50% (11.06.2026 ucin).",
    "checks": "*Hasyla cenli her iki ayda bir gormeli. (sun burn- gün yanyklygy barlamak üçin)\n* Hasyla yakyn wagty gün yanyklar barlaglary, test, agaç yagdaýy, miwe kalibr barlaglary etmeli.\n*Hasyly özimiz gözikdirmeli etmeli we özimiziň hasyl edyancilerimiz bilen has gowy netije bolar. (teklip)\n*tomusdan soň çüýreme ýagdaýyny bilmek\n (böcek mücadele)."
   },
   {
    "fruit": "Elma",
    "variety": "Golden Delicious",
    "trees": 12684,
    "ha": null,
    "planT": 850,
    "qualityT": "595",
    "harvest": "Sentyabr",
    "note": "Telli terbiye yeri, üsti açyk, seyreltme gowy, gyzyl yanak bar, kalibrlary gowy cykar, miwe sagdyn. (11.06.2026)",
    "suitability": "Orta -Uzyn saklamana yaramly 6-8 ay, kalibrlar eksportlyk miwe 40-50% (11.06.2026 ucin).",
    "checks": null
   },
   {
    "fruit": "Elma",
    "variety": "Golden Delicious",
    "trees": 31605,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": "Sentyabr",
    "note": "seyreltme gowy, gyzyl yanak bar, kalibrlary gowy cykar, miwe sagdyn. (11.06.2026)",
    "suitability": "Orta-Uzyn saklamana yaramly 6-8 ay, kalibrlar eksportlyk miwe 40-50% (11.06.2026 ucin).",
    "checks": null
   },
   {
    "fruit": "Elma",
    "variety": "Red chief",
    "trees": 39905,
    "ha": null,
    "planT": 450,
    "qualityT": "315",
    "harvest": "Sentyabr",
    "note": "Telli terbiye yeri, üsti açyk, seyreltme gowy, kalibrlary gowy cykar, miwe sagdyn. (11.06.2026)",
    "suitability": "Orta- uzyn saklamana yaramly 6-8 ay, kalibrlar gowy; eksportlyk miwe- renk alyp başlanda aýdylmasy dogry bolar.  % (11.06.2026 ucin).",
    "checks": "*Renkli alma red chief kici alma gaplaryna ýygmaly gerekli bolup biler  (aşagy täçli alma bolany üçin)- maslahatlaşmaly. \n* Gün ýanyklar barlagalary etmeli bu görnüş üçin wajup uzyn saklmak üçin"
   },
   {
    "fruit": "Armut",
    "variety": "Deveci",
    "trees": 1190,
    "ha": null,
    "planT": 15,
    "qualityT": "10.5",
    "harvest": null,
    "note": "Yagdayy gowy",
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Armut",
    "variety": "S.maria",
    "trees": 4522,
    "ha": null,
    "planT": 80,
    "qualityT": "56",
    "harvest": null,
    "note": null,
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Armut",
    "variety": "mini armyt",
    "trees": null,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": "Iyun",
    "note": null,
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Şeftali",
    "variety": "Sary",
    "trees": 380,
    "ha": null,
    "planT": 8,
    "qualityT": "5.6",
    "harvest": null,
    "note": "agaclar bu yylyn seredilisi gowy, yasy uly 6+ ýyl, bolsada bodur. Miwe sanlary we seyreltme gowy, Täze aý talyp bu önümlere.",
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Şeftali",
    "variety": "Glohaven",
    "trees": 4500,
    "ha": null,
    "planT": 90,
    "qualityT": "63",
    "harvest": "Iyul",
    "note": null,
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Şeftali",
    "variety": "Chresthaven",
    "trees": 2500,
    "ha": null,
    "planT": 50,
    "qualityT": "35",
    "harvest": "Awgust",
    "note": null,
    "suitability": null,
    "checks": null
   }
  ]
 },
 {
  "code": "070826-2",
  "name": "C · Durun (Akmyrat-Wepa-Isgender)",
  "kind": "ORCHARD",
  "region": "Durun, Bäherden",
  "title": "C hasabaty",
  "basis": "Sargyt, Merkez tarapyndan",
  "team": [
   "Wepa Gutlyvew (acyk ekin muduri)",
   "Maksat Hydyrlyýew ( hil topar müdiri)",
   "Wepa (satyş bölüm- 19.08.2026)"
  ],
  "responsible": "Nury aga (agranom)",
  "dates": [
   "07.08.2026",
   "19.08.2026"
  ],
  "items": [
   {
    "fruit": "Elma",
    "variety": "Scarlett spur",
    "trees": null,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": "Awgust- Sentyabr",
    "note": "seyreltme yok, gyrkym gowy. Suw ideg pes, renk almadyk, gurcuk tutan. Kalibr exclusive premium - 11% galany pes. (uly kalibr yuzunde gxn yanyk",
    "suitability": "pes",
    "checks": "*sun burn- gün yanyklygy barlamak üçin\n* tohumlama, suw problema, cuyruk (may ayyndan baslan)\n* (böcek mücadele)."
   },
   {
    "fruit": "Elma",
    "variety": "Golden Delicious",
    "trees": null,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": "Sentyabr",
    "note": null,
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Elma",
    "variety": "gala",
    "trees": null,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": null,
    "note": "Telli terbiye yeri, üsti açyk,",
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Soğan",
    "variety": "Elena",
    "trees": null,
    "ha": 5,
    "planT": 80,
    "qualityT": "50",
    "harvest": "Sentyabr",
    "note": "gabyk yuka-orta, paket ekin,yap suwlama, kesel yok, kalibr orta, azot döküni köp berlen, göllenme takip",
    "suitability": "1-3 ay",
    "checks": "suw kesim. Azot barlag, ideg barlag. Yerde kök çüyreme, sezonlyk yagyşlar. Hasyl 40 aşagy halta girenok."
   },
   {
    "fruit": "Soğan",
    "variety": "Sanjar",
    "trees": null,
    "ha": 5,
    "planT": 100,
    "qualityT": null,
    "harvest": "Sentyabr",
    "note": null,
    "suitability": "1-3 ay",
    "checks": null
   },
   {
    "fruit": "Soğan",
    "variety": "gyzyl gicgi sogan",
    "trees": null,
    "ha": 13,
    "planT": 100,
    "qualityT": null,
    "harvest": "Sentyab-2",
    "note": "görkezmedi - daşyndan alynan maglumat, paket ekilen, gymmat satmak üçin niyetlenen ( wepa yegeni seredyar)",
    "suitability": "3-5 ay",
    "checks": null
   }
  ]
 },
 {
  "code": "190826-3",
  "name": "C · Bugdaýly bagy",
  "kind": "ORCHARD",
  "region": "Bugdaýly, Änew",
  "title": "Saýwan bag hasabaty  (Şyhberdi baglary)",
  "basis": "Sargyt, Merkez tarapyndan - Baýram aga ofis",
  "team": [
   "Sapa Altyýew (hil baş hünärmen)",
   "Maksat Hydyrlyýew ( hil topar müdiri)"
  ],
  "responsible": "Kakyş (müdir)",
  "dates": [
   "11.06.2026"
  ],
  "items": [
   {
    "fruit": "Elma",
    "variety": "Golden Delicious",
    "trees": null,
    "ha": 2.5,
    "planT": 35,
    "qualityT": "20",
    "harvest": "Sentyabr",
    "note": "ýap sulama usuly ; sallama. (suw köp ýerinde ). Ideg: pudama ýok, seyretme yok; idegi az ot köp; gurçuk az; gününe ýanan kän. Kalibr: classic, mix, non standart",
    "suitability": "goniden bagdan satuwa, sortlaman.",
    "checks": null
   }
  ]
 },
 {
  "code": "190826-4",
  "name": "C · Bamy sogan meýdany",
  "kind": "FIELD",
  "region": "Bamy, Bäherden – Akdepe",
  "title": "Saýwan bag hasabaty  (Şyhberdi baglary)",
  "basis": "Sargyt, Merkez tarapyndan",
  "team": [
   "Wepa (satuw bölüm)",
   "Maksat Hydyrlyýew ( hil topar müdiri)"
  ],
  "responsible": "Arslan inžener (müdir) (Bamy) - Akdepe belli däl",
  "dates": [
   "19.08.2026"
  ],
  "items": [
   {
    "fruit": "Soğan",
    "variety": "Sanjar, Elena, Bereket",
    "trees": null,
    "ha": 25,
    "planT": 2000,
    "qualityT": "1300-1500",
    "harvest": "Sentyabr",
    "note": "gabyk orta, paket ekin,yap suwlama, kesel yok, kalibr orta- yokary, azot döküni köp berlen, göllenme takip",
    "suitability": "1-5 aý",
    "checks": null
   },
   {
    "fruit": "Soğan",
    "variety": "Elena",
    "trees": null,
    "ha": null,
    "planT": null,
    "qualityT": null,
    "harvest": null,
    "note": null,
    "suitability": null,
    "checks": null
   },
   {
    "fruit": "Soğan",
    "variety": "Elena",
    "trees": null,
    "ha": 5,
    "planT": 60,
    "qualityT": "40",
    "harvest": "Sentyabr",
    "note": "yap suwlama, idegi pes, gabyk yuka-orta; kalibr kiçi-orta; 1 arka tohum (tohumlyk);",
    "suitability": "0-1 aý",
    "checks": "30.07.2026 ý suw kesilen"
   }
  ]
 },
 {
  "code": "220826-5",
  "name": "C · Sekiz ýap bagy",
  "kind": "ORCHARD",
  "region": "Sekiz ýap, Gökdepe",
  "title": "Saýwan bag hasabaty  (Şyhberdi baglary)",
  "basis": "Sargyt, Merkez tarapyndan",
  "team": [
   "Sapa Altyýew (hil baş hünärmen)",
   "Maksat Hydyrlyýew ( hil topar müdiri)",
   "Allakulow Babageldi (Bagyr hil hünärmen)",
   "Wepa (satuw bolum)"
  ],
  "responsible": "Guwanç (bag eýesi- ideg edýän)",
  "dates": [
   "22.08.2026"
  ],
  "items": [
   {
    "fruit": "Elma",
    "variety": "scarlet spur",
    "trees": null,
    "ha": 6.5,
    "planT": 20,
    "qualityT": "13-20",
    "harvest": "Awgust (hasyla gelipdir)",
    "note": "ýap sulama usuly ; sallama. (suw köp ýerinde ). Ideg: gowy pudama edilen, , seyretme bar; yaprak kesel sezonlyk, may tozlanma mesele ic miwe., renk almadyk",
    "suitability": "saklama kadaly dal; goni satys; eksport yaramly dal.",
    "checks": "6.5-ha hoz bar, we az hurma bar. Şitilhana  we ideg hyzmaty almak boyunça, hyzmatlar sorayar."
   }
  ]
 }
];
