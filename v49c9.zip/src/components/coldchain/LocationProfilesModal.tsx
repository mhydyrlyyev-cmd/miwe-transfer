import React, { useMemo, useState } from 'react';
import { CALIBRATION_RULES, calibrationStatus } from '../../config/calibrationRules';
import { MapPin, Plus, Sparkles, X } from 'lucide-react';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import {
  addCustomField, detectNewLocations, fieldsFor, LOCATION_KIND_LABEL, LocationKind, LocationProfile,
  ProfileFieldDef, upsertProfile, useLocationProfiles,
} from '../../services/locationProfiles';
import { Button, Tabs } from '../ui';

/**
 * v3.4 (Madde 5, 9) — Yer profilleri: bahçe, ön soğutma yeri, depo, oda, varış.
 * Operasyondan ayrı ekran: sistem yeni bir ad algılarsa burada "profil oluştur" önerilir.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onClose: () => void;
  /** v49c7: bahçe satırından Bahçe profili sayfasına */
  onOpenOrchardProfile?: (name: string) => void;
}

const KINDS: LocationKind[] = ['ORCHARD', 'GREENHOUSE', 'FIELD', 'PRECOOL', 'WAREHOUSE', 'ROOM', 'DESTINATION', 'DEVICE'];

export default function LocationProfilesModal(p: Props) {
  const [kind, setKind] = useState<LocationKind>('ORCHARD');
  const profiles = useLocationProfiles(kind);
  const allProfiles = useLocationProfiles();
  const detected = useMemo(() => detectNewLocations(p), [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords, allProfiles.length]);
  const detectedHere = detected.filter(d => d.kind === kind);
  const [editing, setEditing] = useState<Partial<LocationProfile> | null>(null);
  const [newField, setNewField] = useState<{ label: string; type: ProfileFieldDef['type']; unit: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [geoMsg, setGeoMsg] = useState('');

  const input = 'w-full min-h-[40px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100';
  const label = 'block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1';

  const save = async () => {
    if (!editing?.name?.trim()) return;
    setSaving(true);
    await upsertProfile({
      id: editing.id, createdAt: editing.createdAt, kind,
      name: editing.name.trim(),
      aliases: (editing.aliases || []).map(a => a.trim()).filter(Boolean),
      fields: editing.fields || {},
      note: editing.note?.trim() || undefined,
      updatedBy: p.currentUserName,
    });
    setSaving(false);
    setEditing(null);
  };

  const setField = (k: string, v: string | number | boolean | undefined) => {
    const f = { ...(editing?.fields || {}) };
    if (v === undefined || v === '') delete f[k]; else f[k] = v;
    setEditing({ ...editing, fields: f });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-end sm:items-center justify-center" onClick={p.onClose}>
      <div role="dialog" aria-modal="true" aria-label="Yer profilleri" className="bg-white dark:bg-slate-900 w-full sm:max-w-2xl rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2"><MapPin className="w-4 h-4 text-teal-600" />Yer profilleri</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">Bahçe, depo, oda ve varış yerlerinin bilgileri. Tüm alanlar isteğe bağlı; analiz ve uyarılar bu bilgileri kullanır.</p>
          </div>
          <button type="button" onClick={p.onClose} aria-label="Kapat" className="p-2 rounded-lg text-slate-500 min-h-[40px] min-w-[40px] flex items-center justify-center"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-4 pt-3">
          <Tabs<LocationKind> ariaLabel="Yer tipi" value={kind} onChange={(k) => { setKind(k); setEditing(null); }}
            items={KINDS.map(k => ({ key: k, label: LOCATION_KIND_LABEL[k], count: detected.filter(d => d.kind === k).length || undefined }))} />
        </div>

        <div className="overflow-y-auto p-4 space-y-3">
          {!editing && detectedHere.length > 0 && !p.isReadOnly && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-900 p-3">
              <div className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5 mb-2"><Sparkles className="w-3.5 h-3.5" />Kayıtlarda profili olmayan {detectedHere.length} {LOCATION_KIND_LABEL[kind].toLocaleLowerCase('tr')}</div>
              <div className="flex flex-wrap gap-1.5">
                {detectedHere.slice(0, 20).map(d => (
                  <button key={d.name} type="button" onClick={() => setEditing({ kind, name: d.name, fields: {} })}
                    className="px-2.5 py-1 rounded-lg border border-amber-300 bg-white dark:bg-slate-900 text-xs font-semibold text-amber-900 dark:text-amber-200 cursor-pointer">
                    + {d.name} <span className="opacity-60">({d.uses})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {!editing && (
            <>
              <ul className="divide-y divide-slate-100 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800">
                {profiles.length === 0 && <li className="p-3 text-sm text-slate-500">Henüz {LOCATION_KIND_LABEL[kind].toLocaleLowerCase('tr')} profili yok.</li>}
                {profiles.map(pr => (
                  <li key={pr.id} className="relative">
                    {kind === 'ORCHARD' && p.onOpenOrchardProfile && (
                      <button type="button" onClick={() => p.onOpenOrchardProfile!(pr.name)} className="absolute right-2 top-2 z-10 px-2.5 min-h-[32px] rounded-lg border border-teal-300 bg-teal-50 text-teal-800 text-xs font-semibold cursor-pointer">Bahçe profili ›</button>
                    )}
                    <button type="button" disabled={p.isReadOnly} onClick={() => setEditing(pr)} className={`w-full text-left p-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer ${kind === 'ORCHARD' && p.onOpenOrchardProfile ? 'pr-32' : ''}`}>
                      <div className="text-sm font-bold text-slate-900 dark:text-white">{pr.name}{pr.aliases?.length ? <span className="text-xs font-normal text-slate-500"> · diğer yazımlar: {pr.aliases.join(', ')}</span> : null}</div>
                      {kind === 'DEVICE' && (() => {
                        const st = calibrationStatus(pr.fields);
                        const tone = st.failed || st.overdue ? 'text-rose-700 dark:text-rose-300' : st.dueSoon ? 'text-amber-700 dark:text-amber-300' : 'text-emerald-700 dark:text-emerald-300';
                        return <div className={`text-xs font-semibold ${tone}`}>{st.failed ? 'Son kontrol KALDI · kullanmayın' : st.next ? `Sıradaki kontrol ${new Date(st.next).toLocaleDateString('tr-TR')}${st.overdue ? ' · gecikti' : st.dueSoon ? ' · yaklaşıyor' : ''}` : 'Kontrol kaydı yok'}</div>;
                      })()}
                      <div className="text-xs text-slate-600 dark:text-slate-400 truncate">
                        {fieldsFor(kind).filter(f => pr.fields[f.key] !== undefined && pr.fields[f.key] !== '').map(f => `${f.label}: ${typeof pr.fields[f.key] === 'boolean' ? (pr.fields[f.key] ? 'evet' : 'hayır') : pr.fields[f.key]}${f.unit ? ' ' + f.unit : ''}`).join(' · ') || 'Bilgi girilmedi'}
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
              {!p.isReadOnly && <Button variant="soft" tone="sky" icon={<Plus />} onClick={() => setEditing({ kind, name: '', fields: {} })}>Yeni {LOCATION_KIND_LABEL[kind].toLocaleLowerCase('tr')}</Button>}
              {kind === 'DEVICE' && (
                <details className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 text-xs text-slate-700 dark:text-slate-300">
                  <summary className="font-semibold cursor-pointer">Kontrol kuralları (iç hedef)</summary>
                  <ul className="mt-2 space-y-1.5">
                    {CALIBRATION_RULES.map(r => <li key={r.type}><b className="font-semibold">{r.type}</b> · her {r.intervalDays === 1 ? 'gün' : `${r.intervalDays} gün`} · {r.method} · tolerans {r.tolerance}{r.certificateDays ? ' · yıllık sertifika' : ''}</li>)}
                  </ul>
                  <p className="mt-2 text-slate-500">Tolerans dışı çıkan cihaz "Kaldı" yazılır ve ölçümde kullanılmaz; o tarihten sonraki ölçümler gözden geçirilir.</p>
                </details>
              )}
            </>
          )}

          {editing && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div><label className={label}>Ad</label><input className={input} value={editing.name || ''} onChange={e => setEditing({ ...editing, name: e.target.value })} /></div>
                <div><label className={label}>Diğer yazımlar (virgülle)</label><input className={input} value={(editing.aliases || []).join(', ')} onChange={e => setEditing({ ...editing, aliases: e.target.value.split(',') })} placeholder="G-1, g1 depo" /></div>
                {fieldsFor(kind).map(f => {
                  const v = editing.fields?.[f.key];
                  return (
                    <div key={f.key}>
                      {f.type === 'boolean' ? (
                        <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 min-h-[40px] mt-5">
                          <input type="checkbox" className="w-4 h-4" checked={!!v} onChange={e => setField(f.key, e.target.checked || undefined)} />{f.label}
                        </label>
                      ) : (
                        <>
                          <label className={label}>{f.label}{f.unit ? ` (${f.unit})` : ''}</label>
                          {f.type === 'select' ? (
                            <select className={input} value={String(v ?? '')} onChange={e => setField(f.key, e.target.value || undefined)}>
                              <option value="">—</option>
                              {(f.options || []).map(o => <option key={o} value={o}>{o}</option>)}
                            </select>
                          ) : (
                            <input className={input} inputMode={f.type === 'number' ? 'decimal' : undefined} value={String(v ?? '')}
                              onChange={e => setField(f.key, f.type === 'number' ? (e.target.value.trim() === '' ? undefined : Number(e.target.value.replace(',', '.'))) : e.target.value)} />
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
                {fieldsFor(kind).some(f => f.key === 'lat') && !p.isReadOnly && (
                  <div className="sm:col-span-2 flex items-center gap-2">
                    <button type="button" onClick={() => {
                      if (!navigator.geolocation) { setGeoMsg('Bu cihaz konum vermiyor.'); return; }
                      setGeoMsg('Konum alınıyor…');
                      navigator.geolocation.getCurrentPosition(
                        pos => { const f = { ...(editing.fields || {}), lat: Math.round(pos.coords.latitude * 1e6) / 1e6, lon: Math.round(pos.coords.longitude * 1e6) / 1e6 }; setEditing({ ...editing, fields: f }); setGeoMsg(`Konum alındı (±${Math.round(pos.coords.accuracy)} m) · Kaydet'e basın`); },
                        () => setGeoMsg('Konum alınamadı — izin verin ya da enlem/boylamı elle girin.'), { enableHighAccuracy: true, timeout: 15000 });
                    }} className="min-h-[40px] px-3 rounded-xl border border-teal-300 bg-teal-50 text-teal-800 text-sm font-semibold cursor-pointer inline-flex items-center gap-1.5"><MapPin className="w-4 h-4" />Konumumu al</button>
                    {geoMsg && <span className="text-xs text-slate-600 dark:text-slate-400">{geoMsg}</span>}
                  </div>
                )}
                <div className="sm:col-span-2"><label className={label}>Dikkat edilecekler / not</label><input className={input} value={editing.note || ''} onChange={e => setEditing({ ...editing, note: e.target.value })} /></div>
              </div>

              {newField ? (
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 grid grid-cols-3 gap-2 items-end">
                  <div><label className={label}>Alan adı</label><input className={input} value={newField.label} onChange={e => setNewField({ ...newField, label: e.target.value })} /></div>
                  <div><label className={label}>Tip</label>
                    <select className={input} value={newField.type} onChange={e => setNewField({ ...newField, type: e.target.value as ProfileFieldDef['type'] })}>
                      <option value="text">Yazı</option><option value="number">Sayı</option><option value="boolean">Evet/Hayır</option>
                    </select></div>
                  <div><label className={label}>Birim</label><input className={input} value={newField.unit} onChange={e => setNewField({ ...newField, unit: e.target.value })} /></div>
                  <div className="col-span-3 flex justify-end gap-2">
                    <Button size="sm" variant="soft" tone="slate" onClick={() => setNewField(null)}>Vazgeç</Button>
                    <Button size="sm" variant="primary" onClick={() => {
                      if (!newField.label.trim()) return;
                      addCustomField(kind, { key: `c_${newField.label.trim().toLocaleLowerCase('tr').replace(/[^a-z0-9çğıöşü]+/gi, '_')}`, label: newField.label.trim(), type: newField.type, unit: newField.unit.trim() || undefined });
                      setNewField(null);
                    }}>Alanı ekle</Button>
                  </div>
                </div>
              ) : (
                <button type="button" className="text-xs font-semibold text-teal-700 dark:text-teal-300 cursor-pointer" onClick={() => setNewField({ label: '', type: 'text', unit: '' })}>+ Bu tip için yeni alan ekle</button>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="soft" tone="slate" onClick={() => setEditing(null)} disabled={saving}>Vazgeç</Button>
                <Button variant="primary" loading={saving} onClick={save} disabled={!editing.name?.trim()}>Profili kaydet</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
