import React, { useMemo, useState } from 'react';
import { Snowflake, Thermometer, Droplets, MoveRight, ClipboardPlus, ChevronDown } from 'lucide-react';
import type { AmbarRecord, LojistikRecord, ReferenceItem, SalesRecord, StorageCheck, RoomMovement } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { roomCapacity } from '../../config/coldStorage';
import { STORAGE_STATUS_LABEL } from '../../config/inspection';
import { STORAGE_TERMS, storageTermForDays } from '../../config/coldChain';
import ColdChainPanel from '../coldchain/ColdChainPanel';
import LocationProfilesModal from '../coldchain/LocationProfilesModal';
import { findProfile, useLocationProfiles, useLocationOptions } from '../../services/locationProfiles';
import { MapPin } from 'lucide-react';
import type { HarvestRecord, BalanceAdjustment } from '../../types';
import { Badge, Button, Card, EmptyState, PageHeader, StageRail } from '../ui';

/**
 * v2.7 — Soğuk Depo: hangi depo, hangi oda, hangi istif yeri; depoda bekleyen partilerin
 * kontrolleri (oda sıcaklığı, nem, meyve içi sıcaklık, sertlik, Brix, çürük %) ve oda değişiklikleri.
 * Yeni koleksiyon yok: her şey ilgili depo kabul kaydının içinde saklanır.
 */

interface ColdStorageViewProps {
  /** v3.4: soğuk zincir paneli için */
  harvestRecords?: HarvestRecord[];
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onOpenPrecooling?: (ref: ReferenceItem) => void;
  onNavigate?: (view: string) => void;
  ambarRecords: AmbarRecord[];
  references: ReferenceItem[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onUpdateAmbar: (record: AmbarRecord) => Promise<boolean | void>;
  onOpenRecord?: (refId: string) => void;
  onBack: () => void;
}

const fmtNum = (v?: number | null, d = 1) => (v === undefined || v === null || Number.isNaN(v) ? '—' : Number(v).toLocaleString('tr-TR', { maximumFractionDigits: d }));
const toNum = (v: string): number | undefined => (v.trim() === '' ? undefined : Number(v.replace(',', '.')));
const daysBetween = (from?: string, to?: Date) => {
  if (!from) return null;
  const a = new Date(from.length === 10 ? `${from}T00:00:00` : from);
  if (Number.isNaN(a.getTime())) return null;
  return Math.max(0, Math.round(((to || new Date()).getTime() - a.getTime()) / 86400000));
};

export default function ColdStorageView({ harvestRecords = [], onNavigate, ambarRecords, references, lojistikRecords, salesRecords, currentUserName, isReadOnly, onUpdateAmbar, onOpenRecord, onBack }: ColdStorageViewProps) {
  const [showDispatched, setShowDispatched] = useState(false);
  const [openForm, setOpenForm] = useState<{ id: string; kind: 'CHECK' | 'MOVE' } | null>(null);
  const [saving, setSaving] = useState(false);
  const [showProfiles, setShowProfiles] = useState(false);
  useLocationProfiles(); // profil değişince oda kapasiteleri yenilenir
  const profileOpts = useLocationOptions();
  const [error, setError] = useState<string | null>(null);

  // Kontrol formu
  const [chk, setChk] = useState({ at: '', setT: '', roomT: '', hum: '', pulpT: '', firm: '', brix: '', rot: '', o2: '', co2: '', vent: false, wet: false, note: '' });
  // Taşıma formu
  const [mv, setMv] = useState({ wh: '', room: '', stack: '', note: '' });

  const refMap = useMemo(() => new Map(references.map(r => [r.refId, r])), [references]);
  // v2.8: depodan çıkışlar (depo girişinden SONRAKİ lojistik sevkleri + satışlar) — kısmi çıkış desteklenir
  const outflows = (refId: string, entry?: string) => {
    const e = entry ? entry.slice(0, 10) : '';
    const list = [
      ...lojistikRecords.filter(l => l.refId === refId && l.shipmentDate && (!e || l.shipmentDate.slice(0, 10) >= e))
        .map(l => ({ date: l.shipmentDate, kg: Number(l.weightKg) || 0 })),
      ...salesRecords.filter(s => s.refId === refId && s.salesDate && (!e || s.salesDate.slice(0, 10) >= e))
        .map(s => ({ date: s.salesDate, kg: Number(s.totalQuantityKg) || 0 }))
    ].sort((x, y) => x.date.localeCompare(y.date));
    return { list, kg: list.reduce((sum, x) => sum + x.kg, 0), last: list[list.length - 1]?.date };
  };

  const items = useMemo(() => ambarRecords.map(a => {
    const out = outflows(a.refId, a.acceptanceDate || a.timestamp);
    const inKg = Number(a.acceptedWeightKg) || 0;
    const remainingKg = inKg > 0 ? Math.max(0, inKg - out.kg) : null;
    // Tamamen çıktı: kalan 0 ya da giriş kg'ı bilinmiyorken bir çıkış var
    const exitDate = out.list.length > 0 && (remainingKg === null || remainingKg <= 0) ? out.last : undefined;
    const checks = [...(a.storageChecks || [])].sort((x, y) => x.at.localeCompare(y.at));
    return {
      a,
      ref: refMap.get(a.refId),
      warehouse: a.warehouse?.trim() || 'Depo belirtilmedi',
      room: a.roomNo?.trim() || 'Oda belirtilmedi',
      exitDate,
      outKg: out.kg,
      remainingKg,
      days: daysBetween(a.acceptanceDate || a.timestamp, exitDate ? new Date(exitDate) : undefined),
      pallets: (a as any).receivedPallets ?? (a as any).palletCount ?? null,
      checks,
      first: checks[0],
      last: checks[checks.length - 1]
    };
  }), [ambarRecords, refMap, lojistikRecords, salesRecords]);

  const visible = items.filter(i => showDispatched || !i.exitDate);
  // v3.1: "G-1 depo" / "g-1  depo" gibi yazım farkları aynı depo/oda sayılır; görünen ad ilk yazılan
  const groups = useMemo(() => {
    const norm = (x: string) => x.trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');
    const whName = new Map<string, string>(); const roomName = new Map<string, string>();
    const g = new Map<string, Map<string, typeof visible>>();
    visible.forEach(i => {
      const wk = norm(i.warehouse); if (!whName.has(wk)) whName.set(wk, i.warehouse.trim());
      const rk = `${wk}|${norm(i.room)}`; if (!roomName.has(rk)) roomName.set(rk, i.room.trim());
      const wName = whName.get(wk)!; const rName = roomName.get(rk)!;
      if (!g.has(wName)) g.set(wName, new Map());
      const rooms = g.get(wName)!;
      if (!rooms.has(rName)) rooms.set(rName, []);
      rooms.get(rName)!.push(i);
    });
    return g;
  }, [visible]);

  const startCheck = (id: string) => {
    const now = new Date();
    const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    setChk({ at: local, setT: '', roomT: '', hum: '', pulpT: '', firm: '', brix: '', rot: '', o2: '', co2: '', vent: false, wet: false, note: '' });
    setError(null);
    setOpenForm({ id, kind: 'CHECK' });
  };
  const startMove = (a: AmbarRecord) => {
    setMv({ wh: a.warehouse || '', room: a.roomNo || '', stack: a.stackRow || '', note: '' });
    setError(null);
    setOpenForm({ id: a.id, kind: 'MOVE' });
  };

  const saveCheck = async (a: AmbarRecord) => {
    const vals = {
      setpointC: toNum(chk.setT), roomTemperatureC: toNum(chk.roomT), humidityPercent: toNum(chk.hum), pulpTemperatureC: toNum(chk.pulpT),
      firmness: toNum(chk.firm), brix: toNum(chk.brix), rotPercent: toNum(chk.rot),
      o2Percent: toNum(chk.o2), co2Percent: toNum(chk.co2)
    };
    if (Object.values(vals).every(v => v === undefined) && !chk.vent && !chk.wet) { setError('En az bir ölçüm girin.'); return; }
    if (Object.values(vals).some(v => v !== undefined && Number.isNaN(v))) { setError('Ölçümler sayı olmalı.'); return; }
    const check: StorageCheck = {
      id: `chk-${Date.now()}`,
      at: chk.at ? new Date(chk.at).toISOString() : new Date().toISOString(),
      inspector: currentUserName || '—',
      ...Object.fromEntries(Object.entries(vals).filter(([, v]) => v !== undefined)),
      ...(chk.vent ? { ventilated: true } : {}),
      ...(chk.wet ? { floorWet: true } : {}),
      note: chk.note.trim() || undefined
    } as StorageCheck;
    setSaving(true);
    await onUpdateAmbar({ ...a, storageChecks: [...(a.storageChecks || []), check] });
    setSaving(false);
    setOpenForm(null);
  };

  const saveMove = async (a: AmbarRecord) => {
    if (!mv.wh.trim() || !mv.room.trim()) { setError('Depo ve oda seçin.'); return; }
    if (mv.wh === a.warehouse && mv.room === a.roomNo && mv.stack === (a.stackRow || '')) { setError('Yer değişmedi.'); return; }
    const move: RoomMovement = {
      at: new Date().toISOString(), by: currentUserName || '—',
      fromWarehouse: a.warehouse, fromRoom: a.roomNo, fromStack: a.stackRow,
      toWarehouse: mv.wh.trim(), toRoom: mv.room.trim(), toStack: mv.stack.trim() || undefined,
      note: mv.note.trim() || undefined
    };
    setSaving(true);
    await onUpdateAmbar({ ...a, warehouse: move.toWarehouse, roomNo: move.toRoom, stackRow: move.toStack, roomMovements: [...(a.roomMovements || []), move] });
    setSaving(false);
    setOpenForm(null);
  };

  const inputCls = 'w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100';
  const labelCls = 'block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1';

  const totalActive = items.filter(i => !i.exitDate);
  const totalKg = totalActive.reduce((s, i) => s + (i.remainingKg ?? (i.a.acceptedWeightKg || 0)), 0);

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader
        onBack={onBack}
        title="Soğuk Depo"
        subtitle="Depodaki partiler, oda kontrolleri, süre sınıfları ve oda uyarıları — yalnızca soğuk depo."
      />
      <StageRail current="SOGUK_DEPO" mode="monitor" onNavigate={onNavigate} />

      <div className="flex justify-end">
        <Button size="sm" variant="soft" tone="slate" icon={<MapPin />} onClick={() => setShowProfiles(true)}>Yer profilleri (bahçe · depo · oda · varış)</Button>
      </div>
      {showProfiles && (
        <LocationProfilesModal
          references={references} harvestRecords={harvestRecords} ambarRecords={ambarRecords}
          lojistikRecords={lojistikRecords} salesRecords={salesRecords}
          currentUserName={currentUserName} isReadOnly={isReadOnly}
          onClose={() => setShowProfiles(false)}
        />
      )}

      <ColdChainPanel
        references={references}
        harvestRecords={harvestRecords}
        ambarRecords={ambarRecords}
        lojistikRecords={lojistikRecords}
        salesRecords={salesRecords}
        currentUserName={currentUserName}
        isReadOnly={isReadOnly}
        stage="SOGUK_DEPO"
        onOpenRecord={onOpenRecord}
      />

      <h2 className="text-sm font-bold text-slate-900 dark:text-white pt-2">Depolar ve odalar</h2>

      <div className="grid grid-cols-2 gap-2.5">
        <Card padding="sm"><div className="text-xs text-slate-600 dark:text-slate-400">Depodaki parti</div><div className="text-2xl font-bold tabular-nums">{totalActive.length}</div></Card>
        <Card padding="sm"><div className="text-xs text-slate-600 dark:text-slate-400">Depodaki miktar</div><div className="text-2xl font-bold tabular-nums">{fmtNum(totalKg, 0)} <span className="text-sm font-medium text-slate-500">kg</span></div></Card>
      </div>

      <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
        <input type="checkbox" checked={showDispatched} onChange={e => setShowDispatched(e.target.checked)} className="w-4 h-4" />
        Çıkışı yapılmış partileri de göster
      </label>

      {groups.size === 0 && (
        <EmptyState icon={<Snowflake className="w-5 h-5" />} title="Depoda kayıtlı parti yok" description="Depo kabul kaydında depo, oda ve istif yeri girildiğinde partiler burada görünür." />
      )}

      {[...groups.entries()].map(([wh, rooms]) => (
        <section key={wh} className="space-y-3">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2"><Snowflake className="w-4 h-4 text-sky-600" />{wh}</h2>
          {[...rooms.entries()].map(([room, list]) => {
            const pallets = list.filter(i => !i.exitDate).reduce((s, i) => s + (Number(i.pallets) || 0), 0);
            const prof = findProfile('ROOM', room);
            const profCap = Number(prof?.fields?.capacityPallets);
            const cap = roomCapacity(wh, room) ?? (Number.isFinite(profCap) && profCap > 0 ? profCap : null);
            const pct = cap ? Math.min(100, Math.round((pallets / cap) * 100)) : null;
            return (
              <Card key={room} title={room} subtitle={`${list.length} parti${pallets ? ` · ${pallets} palet` : ''}${cap ? ` · kapasite ${cap} palet` : ''}`}
                actions={pct !== null ? <Badge tone={pct >= 90 ? 'error' : pct >= 75 ? 'warn' : 'ok'}>%{pct} dolu</Badge> : undefined}>
                {pct !== null && (
                  <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 mb-3 overflow-hidden" aria-hidden="true">
                    <div className={`h-full ${pct >= 90 ? 'bg-rose-500' : pct >= 75 ? 'bg-amber-500' : 'bg-teal-600'}`} style={{ width: `${pct}%` }} />
                  </div>
                )}
                <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                  {list.map(i => {
                    const a = i.a;
                    const isOpen = openForm?.id === a.id;
                    const firmDelta = i.first?.firmness !== undefined && i.last?.firmness !== undefined && i.checks.length > 1 ? i.last.firmness! - i.first.firmness! : null;
                    const brixDelta = i.first?.brix !== undefined && i.last?.brix !== undefined && i.checks.length > 1 ? i.last.brix! - i.first.brix! : null;
                    return (
                      <li key={a.id} className="py-3 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <button type="button" onClick={() => onOpenRecord?.(a.refId)} className="text-left min-w-0">
                            <div className="font-mono text-sm font-semibold text-teal-800 dark:text-teal-300 truncate">{a.refId}</div>
                            <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{i.ref?.product || '—'}</div>
                          </button>
                          {i.exitDate ? <Badge tone="nodata">Çıkış: {i.exitDate}</Badge>
                            : i.outKg > 0 ? <Badge tone="warn">Kısmi çıkış: {fmtNum(i.outKg, 0)} kg</Badge>
                            : <Badge tone="info">{i.days ?? '—'} gündür depoda</Badge>}
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-1 text-xs">
                          <div><span className="text-slate-500">İstif yeri: </span><span className="font-semibold">{a.stackRow || '—'}</span></div>
                          <div><span className="text-slate-500">Görünüş: </span><span className="font-semibold">{a.appearance || 'Sınıflanmamış'}</span></div>
                          <div><span className="text-slate-500">{i.outKg > 0 && !i.exitDate ? 'Kalan: ' : 'Miktar: '}</span><span className="font-semibold">{fmtNum(i.outKg > 0 && i.remainingKg !== null ? i.remainingKg : a.acceptedWeightKg, 0)} kg</span>{i.outKg > 0 && !i.exitDate ? <span className="text-slate-500"> / {fmtNum(a.acceptedWeightKg, 0)}</span> : null}</div>
                          <div><span className="text-slate-500">Palet: </span><span className="font-semibold">{i.pallets ?? '—'}</span></div>
                          <div><span className="text-slate-500">Giriş: </span><span className="font-semibold">{a.acceptanceDate || '—'}</span></div>
                        </div>
                        {i.last ? (
                          <div className="rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs space-y-0.5">
                            <div className="text-slate-500">Son kontrol: {new Date(i.last.at).toLocaleString('tr-TR')} · {i.last.inspector} · toplam {i.checks.length} kontrol</div>
                            <div className="flex flex-wrap gap-x-3 gap-y-0.5">
                              <span className="inline-flex items-center gap-1"><Thermometer className="w-3 h-3" />Oda {fmtNum(i.last.roomTemperatureC)} °C{i.last.setpointC !== undefined ? ` (ayar ${fmtNum(i.last.setpointC)})` : ''}</span>
                              <span className="inline-flex items-center gap-1"><Droplets className="w-3 h-3" />Nem %{fmtNum(i.last.humidityPercent, 0)}</span>
                              <span>Meyve içi {fmtNum(i.last.pulpTemperatureC)} °C</span>
                              <span>Sertlik {fmtNum(i.last.firmness)}{firmDelta !== null ? ` (${firmDelta >= 0 ? '+' : ''}${fmtNum(firmDelta)})` : ''}</span>
                              <span>Brix {fmtNum(i.last.brix)}{brixDelta !== null ? ` (${brixDelta >= 0 ? '+' : ''}${fmtNum(brixDelta)})` : ''}</span>
                              <span>Çürük %{fmtNum(i.last.rotPercent)}</span>
                              {i.last.o2Percent !== undefined && <span>O₂ %{fmtNum(i.last.o2Percent)}</span>}
                              {i.last.co2Percent !== undefined && <span>CO₂ %{fmtNum(i.last.co2Percent)}</span>}
                              {i.last.ventilated && <span>Havalandırıldı</span>}
                              {i.last.floorWet && <span>Yer ıslatıldı</span>}
                            </div>
                          </div>
                        ) : (
                          <div className="text-xs text-slate-500">Henüz depo kontrolü yok.</div>
                        )}
                        {(a.roomMovements?.length || 0) > 0 && (
                          <details className="text-xs text-slate-600 dark:text-slate-400">
                            <summary className="cursor-pointer inline-flex items-center gap-1"><ChevronDown className="w-3 h-3" />{a.roomMovements!.length} yer değişikliği</summary>
                            <ul className="mt-1 space-y-0.5">
                              {a.roomMovements!.map((m, k) => (
                                <li key={k}>{new Date(m.at).toLocaleString('tr-TR')} · {m.fromRoom || '—'}{m.fromStack ? ` / ${m.fromStack}` : ''} → {m.toRoom}{m.toStack ? ` / ${m.toStack}` : ''} · {m.by}</li>
                              ))}
                            </ul>
                          </details>
                        )}
                        {!isReadOnly && !i.exitDate && !isOpen && (
                          <div className="flex flex-wrap gap-2 items-center">
                            {/* v3.0: odadaki mevcut durum */}
                            <select
                              aria-label="Durum"
                              value={a.storageStatus || 'WAITING'}
                              onChange={(e) => onUpdateAmbar({ ...a, storageStatus: e.target.value as AmbarRecord['storageStatus'] })}
                              className="min-h-[40px] rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold text-slate-800 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100"
                            >
                              {Object.entries(STORAGE_STATUS_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                            </select>
                            {/* v3.4: süre sınıfı (kontrol sıklığını belirler) ve oda tipi */}
                            <select
                              aria-label="Depolama süresi"
                              value={a.storageTerm || ''}
                              onChange={(e) => onUpdateAmbar({ ...a, storageTerm: (e.target.value || undefined) as AmbarRecord['storageTerm'] })}
                              className="min-h-[40px] rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold text-slate-800 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100"
                            >
                              <option value="">Süre: otomatik ({storageTermForDays(i.days ?? 0).label})</option>
                              {STORAGE_TERMS.map(t => <option key={t.key} value={t.key}>{t.label} · {t.checkEveryDays} günde kontrol</option>)}
                            </select>
                            <select
                              aria-label="Oda tipi"
                              value={a.atmosphere || 'NORMAL'}
                              onChange={(e) => onUpdateAmbar({ ...a, atmosphere: e.target.value as AmbarRecord['atmosphere'] })}
                              className="min-h-[40px] rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold text-slate-800 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100"
                            >
                              <option value="NORMAL">Normal oda</option>
                              <option value="CA">Kontrollü atmosfer (CA)</option>
                              <option value="ULO">ULO</option>
                            </select>
                            <Button size="sm" variant="soft" tone="sky" icon={<ClipboardPlus />} onClick={() => startCheck(a.id)}>Kontrol ekle</Button>
                            <Button size="sm" variant="soft" tone="violet" icon={<MoveRight />} onClick={() => startMove(a)}>Taşı</Button>
                          </div>
                        )}
                        {isOpen && openForm?.kind === 'CHECK' && (
                          <div className="rounded-xl border border-sky-200 bg-sky-50/50 dark:bg-sky-950/20 dark:border-sky-900 p-3 space-y-2">
                            <div className="grid grid-cols-2 gap-2">
                              <div className="col-span-2"><label className={labelCls}>Tarih-saat</label><input type="datetime-local" className={inputCls} value={chk.at} onChange={e => setChk({ ...chk, at: e.target.value })} /></div>
                              <div><label className={labelCls}>Oda ayar sıcaklığı (°C)</label><input inputMode="decimal" className={inputCls} value={chk.setT} onChange={e => setChk({ ...chk, setT: e.target.value })} /></div>
                              <div><label className={labelCls}>Oda sıcaklığı (°C)</label><input inputMode="decimal" className={inputCls} value={chk.roomT} onChange={e => setChk({ ...chk, roomT: e.target.value })} /></div>
                              <div><label className={labelCls}>Nem (%)</label><input inputMode="decimal" className={inputCls} value={chk.hum} onChange={e => setChk({ ...chk, hum: e.target.value })} /></div>
                              <div><label className={labelCls}>Meyve içi (°C)</label><input inputMode="decimal" className={inputCls} value={chk.pulpT} onChange={e => setChk({ ...chk, pulpT: e.target.value })} /></div>
                              <div><label className={labelCls}>Sertlik (kg/cm²)</label><input inputMode="decimal" className={inputCls} value={chk.firm} onChange={e => setChk({ ...chk, firm: e.target.value })} /></div>
                              <div><label className={labelCls}>Brix (°Bx)</label><input inputMode="decimal" className={inputCls} value={chk.brix} onChange={e => setChk({ ...chk, brix: e.target.value })} /></div>
                              <div><label className={labelCls}>Çürük (%)</label><input inputMode="decimal" className={inputCls} value={chk.rot} onChange={e => setChk({ ...chk, rot: e.target.value })} /></div>
                              {a.atmosphere && a.atmosphere !== 'NORMAL' && (<>
                                <div><label className={labelCls}>O₂ (%)</label><input inputMode="decimal" className={inputCls} value={chk.o2} onChange={e => setChk({ ...chk, o2: e.target.value })} /></div>
                                <div><label className={labelCls}>CO₂ (%)</label><input inputMode="decimal" className={inputCls} value={chk.co2} onChange={e => setChk({ ...chk, co2: e.target.value })} /></div>
                              </>)}
                              <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300"><input type="checkbox" className="w-4 h-4" checked={chk.vent} onChange={e => setChk({ ...chk, vent: e.target.checked })} />Havalandırma yapıldı</label>
                              <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300"><input type="checkbox" className="w-4 h-4" checked={chk.wet} onChange={e => setChk({ ...chk, wet: e.target.checked })} />Yerler ıslatıldı</label>
                              <div className="col-span-2"><label className={labelCls}>Not</label><input className={inputCls} value={chk.note} onChange={e => setChk({ ...chk, note: e.target.value })} /></div>
                            </div>
                            <p className="text-xs text-slate-500">Yalnızca ölçtüğünüz değerleri girin; boş alanlar kaydedilmez.</p>
                            {error && <p className="text-xs text-rose-700" role="alert">{error}</p>}
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="soft" tone="slate" onClick={() => setOpenForm(null)} disabled={saving}>Vazgeç</Button>
                              <Button size="sm" variant="primary" loading={saving} onClick={() => saveCheck(a)}>Kontrolü kaydet</Button>
                            </div>
                          </div>
                        )}
                        {isOpen && openForm?.kind === 'MOVE' && (
                          <div className="rounded-xl border border-violet-200 bg-violet-50/50 dark:bg-violet-950/20 dark:border-violet-900 p-3 space-y-2">
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              <div><label className={labelCls}>Depo</label><input list="cs-warehouses" className={inputCls} value={mv.wh} onChange={e => setMv({ ...mv, wh: e.target.value })} /></div>
                              <div><label className={labelCls}>Oda</label><input list="cs-rooms" className={inputCls} value={mv.room} onChange={e => setMv({ ...mv, room: e.target.value })} /></div>
                              <div><label className={labelCls}>İstif yeri (sıra / raf)</label><input className={inputCls} value={mv.stack} onChange={e => setMv({ ...mv, stack: e.target.value })} placeholder="B-2" /></div>
                              <div className="sm:col-span-3"><label className={labelCls}>Not</label><input className={inputCls} value={mv.note} onChange={e => setMv({ ...mv, note: e.target.value })} /></div>
                            </div>
                            {error && <p className="text-xs text-rose-700" role="alert">{error}</p>}
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="soft" tone="slate" onClick={() => setOpenForm(null)} disabled={saving}>Vazgeç</Button>
                              <Button size="sm" variant="primary" loading={saving} onClick={() => saveMove(a)}>Yeri kaydet</Button>
                            </div>
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </Card>
            );
          })}
        </section>
      ))}

      <datalist id="cs-warehouses">{Array.from(new Set([...profileOpts.warehouses, ...ambarRecords.map(a => (a.warehouse || '').trim()).filter(Boolean), ...AUTOCOMPLETE_LISTS.warehouses])).map(w => <option key={w} value={w} />)}</datalist>
      <datalist id="cs-rooms">{Array.from(new Set([...profileOpts.rooms, ...ambarRecords.map(a => (a.roomNo || '').trim()).filter(Boolean), ...(((AUTOCOMPLETE_LISTS as any).rooms) || [])])).map((r: string) => <option key={r} value={r} />)}</datalist>
    </div>
  );
}
