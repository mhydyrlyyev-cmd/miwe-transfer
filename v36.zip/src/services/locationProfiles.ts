/**
 * v3.4 — Yer Profilleri (Madde 5, 9, 11)
 *
 * Bahçe, depo, oda, ön soğutma yeri ve varış noktası için TEK kayıt defteri.
 * - Adı kullanıcı yazar ("Merkez / Bahçe" sabit değil); aynı yerin farklı yazımları alias ile birleşir.
 * - Alanlar isteğe bağlıdır (zorunlu değil) ve yönetici yeni alan ekleyebilir.
 * - Sistem kayıtlarda geçen ama profili olmayan yeni adları algılar → "profil oluştur" önerir.
 *   Operasyon (hasat, kabul, sevk formu) sırasında form AÇILMAZ; profil ayrı ekranda doldurulur.
 * Kalıcılık: localStorage önbelleği + Firestore 'locationProfiles' koleksiyonu (en iyi çaba).
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../types';

export type LocationKind = 'ORCHARD' | 'PRECOOL' | 'WAREHOUSE' | 'ROOM' | 'DESTINATION';

export const LOCATION_KIND_LABEL: Record<LocationKind, string> = {
  ORCHARD: 'Bahçe',
  PRECOOL: 'Ön soğutma yeri',
  WAREHOUSE: 'Depo',
  ROOM: 'Oda',
  DESTINATION: 'Varış / alıcı',
};

export interface ProfileFieldDef {
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'boolean';
  unit?: string;
  options?: string[];
}

/** Varsayılan (isteğe bağlı) alanlar — yönetici ekleyebilir */
export const DEFAULT_FIELDS: Record<LocationKind, ProfileFieldDef[]> = {
  ORCHARD: [
    { key: 'areaHa', label: 'Alan', type: 'number', unit: 'ha' },
    { key: 'treeCount', label: 'Ağaç sayısı', type: 'number' },
    { key: 'products', label: 'Ürünler / çeşitler', type: 'text' },
    { key: 'region', label: 'Bölge / etrap', type: 'text' },
    { key: 'ownPrecool', label: 'Kendi ön soğutması var', type: 'boolean' },
    { key: 'distanceKm', label: 'Merkeze uzaklık', type: 'number', unit: 'km' },
  ],
  PRECOOL: [
    { key: 'kind', label: 'Tip', type: 'select', options: ['Tünel (hava basınçlı)', 'Hidro-cooling', 'Oda içi', 'Diğer'] },
    { key: 'capacityKg', label: 'Kapasite', type: 'number', unit: 'kg/parti' },
    { key: 'parent', label: 'Bağlı olduğu yer (bahçe / depo)', type: 'text' },
  ],
  WAREHOUSE: [
    { key: 'address', label: 'Konum', type: 'text' },
    { key: 'roomCount', label: 'Oda sayısı', type: 'number' },
  ],
  ROOM: [
    { key: 'warehouse', label: 'Depo', type: 'text' },
    { key: 'volumeM3', label: 'Hacim', type: 'number', unit: 'm³' },
    { key: 'capacityPallets', label: 'Kapasite', type: 'number', unit: 'palet' },
    { key: 'capacityKg', label: 'Kapasite', type: 'number', unit: 'kg' },
    { key: 'use', label: 'Kullanım', type: 'select', options: ['Meyve', 'Sebze', 'Karışık'] },
    { key: 'atmosphere', label: 'Atmosfer', type: 'select', options: ['Normal', 'CA (kontrollü)', 'ULO'] },
    { key: 'ventilation', label: 'Havalandırma var', type: 'boolean' },
    { key: 'setpointC', label: 'Varsayılan set', type: 'number', unit: '°C' },
    { key: 'rhPercent', label: 'Hedef nem', type: 'number', unit: 'RH%' },
  ],
  DESTINATION: [
    { key: 'market', label: 'Pazar', type: 'select', options: ['İç pazar', 'İhracat', 'Numune', 'Sanayi'] },
    { key: 'country', label: 'Ülke / şehir', type: 'text' },
    { key: 'transitDays', label: 'Ortalama yol süresi', type: 'number', unit: 'gün' },
  ],
};

export interface LocationProfile {
  id: string;
  kind: LocationKind;
  name: string;
  aliases?: string[];
  fields: Record<string, string | number | boolean>;
  /** Yönetici notu / dikkat edilecekler */
  note?: string;
  createdAt: string;
  updatedAt?: string;
  updatedBy?: string;
}

interface Store { profiles: LocationProfile[]; extraFields: Partial<Record<LocationKind, ProfileFieldDef[]>> }

const LS_KEY = 'miwe_location_profiles_v1';
const norm = (s: string) => s.trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');

let store: Store = (() => {
  try { const raw = localStorage.getItem(LS_KEY); if (raw) return JSON.parse(raw) as Store; } catch { /* yoksay */ }
  return { profiles: [], extraFields: {} };
})();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS_KEY, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };

let remoteLoaded = false;
async function loadRemoteOnce() {
  if (remoteLoaded) return; remoteLoaded = true;
  try {
    const snap = await getDocs(collection(db, 'locationProfiles'));
    const remote: LocationProfile[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v && v.kind && v.name) remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const map = new Map(store.profiles.map(p => [p.id, p]));
    for (const r of remote) {
      const l = map.get(r.id);
      if (!l || (r.updatedAt || r.createdAt) > (l.updatedAt || l.createdAt)) map.set(r.id, r);
    }
    store = { ...store, profiles: [...map.values()] };
    emit();
  } catch { /* çevrimdışı veya izin yok: yerel önbellek kullanılır */ }
}

export function getProfiles(kind?: LocationKind): LocationProfile[] {
  return store.profiles.filter(p => !kind || p.kind === kind).sort((a, b) => a.name.localeCompare(b.name, 'tr'));
}
export function fieldsFor(kind: LocationKind): ProfileFieldDef[] {
  return [...DEFAULT_FIELDS[kind], ...(store.extraFields[kind] || [])];
}
export function addCustomField(kind: LocationKind, def: ProfileFieldDef) {
  const cur = store.extraFields[kind] || [];
  if (cur.some(f => f.key === def.key) || DEFAULT_FIELDS[kind].some(f => f.key === def.key)) return;
  store = { ...store, extraFields: { ...store.extraFields, [kind]: [...cur, def] } };
  emit();
}

/** Aynı yerin farklı yazımlarını tek profile bağlar ("G-1 depo" = "g-1  Depo") */
export function findProfile(kind: LocationKind, rawName?: string): LocationProfile | undefined {
  if (!rawName) return undefined;
  const n = norm(rawName);
  return store.profiles.find(p => p.kind === kind && (norm(p.name) === n || (p.aliases || []).some(a => norm(a) === n)));
}
export function canonicalName(kind: LocationKind, rawName?: string): string {
  return findProfile(kind, rawName)?.name || (rawName || '').trim();
}

export async function upsertProfile(p: Omit<LocationProfile, 'id' | 'createdAt'> & { id?: string; createdAt?: string }): Promise<LocationProfile> {
  const now = new Date().toISOString();
  const id = p.id || `${p.kind.toLowerCase()}-${norm(p.name).replace(/[^a-z0-9çğıöşü]+/gi, '-').slice(0, 40)}-${Date.now().toString(36)}`;
  const full: LocationProfile = { ...p, id, createdAt: p.createdAt || now, updatedAt: now } as LocationProfile;
  const exists = store.profiles.some(x => x.id === id);
  store = { ...store, profiles: exists ? store.profiles.map(x => (x.id === id ? full : x)) : [...store.profiles, full] };
  emit();
  try { await saveRecordToFirestore('LOCATION_PROFILE', full); } catch { /* yerel kalır */ }
  return full;
}

export function useLocationProfiles(kind?: LocationKind): LocationProfile[] {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force(x => x + 1);
    listeners.add(l);
    loadRemoteOnce();
    return () => { listeners.delete(l); };
  }, []);
  return getProfiles(kind);
}

/** Form seçenekleri (datalist): profil adları önce, sonra kayıtlarda geçen adlar */
export function useLocationOptions(): { orchards: string[]; warehouses: string[]; rooms: string[]; precool: string[]; destinations: string[] } {
  const all = useLocationProfiles();
  const by = (k: LocationKind) => all.filter(p => p.kind === k).map(p => p.name);
  return { orchards: by('ORCHARD'), warehouses: by('WAREHOUSE'), rooms: by('ROOM'), precool: by('PRECOOL'), destinations: by('DESTINATION') };
}

export interface DetectedLocation { kind: LocationKind; name: string; uses: number }

/** Kayıtlarda geçen ama profili olmayan yerler (en çok kullanılan önce) */
export function detectNewLocations(src: {
  references: ReferenceItem[]; harvestRecords: HarvestRecord[]; ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[]; salesRecords: SalesRecord[];
}): DetectedLocation[] {
  const counts = new Map<string, DetectedLocation>();
  const add = (kind: LocationKind, raw?: string) => {
    const name = (raw || '').trim();
    if (!name || name === '—' || findProfile(kind, name)) return;
    const k = `${kind}|${norm(name)}`;
    const cur = counts.get(k) || { kind, name, uses: 0 };
    cur.uses++; counts.set(k, cur);
  };
  src.harvestRecords.forEach(h => add('ORCHARD', h.orchard));
  src.references.forEach(r => add('ORCHARD', r.orchard));
  src.references.forEach(r => (r.precoolingSlips || []).forEach(s => { add('PRECOOL', s.tunnel); add('WAREHOUSE', s.targetWarehouse); add('ROOM', s.targetRoom); }));
  src.ambarRecords.forEach(a => { add('WAREHOUSE', a.warehouse); add('ROOM', a.roomNo); (a.roomMovements || []).forEach(m => { add('WAREHOUSE', m.toWarehouse); add('ROOM', m.toRoom); }); });
  src.lojistikRecords.forEach(l => add('DESTINATION', l.destination));
  src.salesRecords.forEach(s => add('DESTINATION', s.destination || s.customer));
  return [...counts.values()].sort((a, b) => b.uses - a.uses);
}
