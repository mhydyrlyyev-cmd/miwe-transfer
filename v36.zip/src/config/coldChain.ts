/**
 * v3.4 — Soğuk Zincir Kuralları (Madde 3, 8, 9, 11)
 *
 * Bütün süreler ve eşikler burada; ekranlar ve uyarılar yalnızca bu dosyayı okur.
 * Değerler sabit kural değil, VARSAYILAN'dır: yönetici "Ayarlar" ekranından
 * (localStorage: miwe_cold_chain_rules) ürün bazında değiştirebilir.
 */

export interface ProductColdRule {
  /** Ürün adında aranacak anahtar kelimeler (küçük harf, tr) */
  match: string[];
  label: string;
  /** Hasattan ön soğutmaya girişe kadar hedef (saat) — aşılırsa sarı uyarı */
  harvestToPrecoolMaxH: number;
  /** Ön soğutmanın beklenen süresi (saat): min–max. max aşılırsa kırmızı */
  precoolMinH: number;
  precoolMaxH: number;
  /** 1-MCP: hasattan sonra en geç kaç gün içinde uygulanmalı (yoksa 1-MCP uygulanmaz) */
  mcpDeadlineDays?: number;
  /** Depo ayar sıcaklığı ve nem önerisi (bilgi amaçlı) */
  setpointC?: [number, number];
  rhPercent?: [number, number];
  /** Normal fire kıyas değerleri (%) — raporda "beklenen" olarak kullanılır */
  expectedLoss?: { harvestToPrecoolPct: number; sortingCullPct: number; storagePctPerMonth: number };
}

export const DEFAULT_PRODUCT_RULES: ProductColdRule[] = [
  { match: ['elma', 'apple', 'alma'], label: 'Elma', harvestToPrecoolMaxH: 12, precoolMinH: 12, precoolMaxH: 24, mcpDeadlineDays: 7, setpointC: [-0.5, 1.5], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 1, sortingCullPct: 8, storagePctPerMonth: 1 } },
  { match: ['hurma', 'trabzon', 'persimmon', 'hurma'], label: 'Hurma (Trabzon)', harvestToPrecoolMaxH: 12, precoolMinH: 8, precoolMaxH: 24, mcpDeadlineDays: 4, setpointC: [-1, 0], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 1, sortingCullPct: 10, storagePctPerMonth: 1.5 } },
  { match: ['armut', 'pear'], label: 'Armut', harvestToPrecoolMaxH: 12, precoolMinH: 12, precoolMaxH: 24, mcpDeadlineDays: 7, setpointC: [-1, 0], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 1, sortingCullPct: 8, storagePctPerMonth: 1.2 } },
  { match: ['şeftali', 'seftali', 'nektarin', 'peach', 'nectarine', 'erik', 'kayısı', 'kayisi', 'kiraz', 'cherry'], label: 'Sert çekirdekliler', harvestToPrecoolMaxH: 6, precoolMinH: 4, precoolMaxH: 12, setpointC: [-0.5, 1], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 2, sortingCullPct: 12, storagePctPerMonth: 4 } },
  { match: ['üzüm', 'uzum', 'grape'], label: 'Üzüm', harvestToPrecoolMaxH: 6, precoolMinH: 6, precoolMaxH: 12, setpointC: [-1, 0], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 1.5, sortingCullPct: 10, storagePctPerMonth: 2 } },
  { match: ['nar', 'pomegranate'], label: 'Nar', harvestToPrecoolMaxH: 12, precoolMinH: 8, precoolMaxH: 24, setpointC: [5, 7], rhPercent: [90, 95], expectedLoss: { harvestToPrecoolPct: 1, sortingCullPct: 8, storagePctPerMonth: 1.5 } },
];

export const FALLBACK_RULE: ProductColdRule = {
  match: [], label: 'Genel', harvestToPrecoolMaxH: 12, precoolMinH: 4, precoolMaxH: 24,
  expectedLoss: { harvestToPrecoolPct: 1.5, sortingCullPct: 10, storagePctPerMonth: 2 },
};

/** Ön soğutmada bekleme uyarı basamakları (Madde 8C) — saat */
export const PRECOOL_ALERT_STEPS = {
  info: 6,     // 6 sa: "ölçüm yapıldı mı, nereye gidecek?" sorusu
  warning: 12, // 12 sa: sarı — soğuk odaya sevk / ölçüm / oda numarası
  critical: 24 // 24 sa (veya ürünün max süresi): kırmızı
};

/** Depolama süresi sınıfları (Madde 11) — gün aralıkları ve kontrol sıklığı */
export type StorageTerm = 'DIRECT' | 'SHORT' | 'MEDIUM' | 'LONG';
export const STORAGE_TERMS: { key: StorageTerm; label: string; minDay: number; maxDay: number; checkEveryDays: number }[] = [
  { key: 'DIRECT', label: 'Direkt (1–5 gün)', minDay: 0, maxDay: 5, checkEveryDays: 1 },
  { key: 'SHORT', label: 'Kısa (6–18 gün)', minDay: 6, maxDay: 18, checkEveryDays: 2 },
  { key: 'MEDIUM', label: 'Orta (19–90 gün)', minDay: 19, maxDay: 90, checkEveryDays: 3 },
  { key: 'LONG', label: 'Uzun (91–200 gün)', minDay: 91, maxDay: 200, checkEveryDays: 5 },
];

/** Ön soğutmadan sonra odaya girişte ilk set/kontrol uyarısı (Madde 9): 2 gün */
export const FIRST_ROOM_CHECK_AFTER_DAYS = 2;

/** Sahada bekleyen (ön soğutmaya girmemiş) açık bakiye uyarısı — saat */
export const OPEN_BALANCE_ALERT_H = 12;
/** Bu oranın altındaki fark yuvarlama/tartı farkı sayılır, uyarı üretmez (%) */
export const BALANCE_TOLERANCE_PCT = 0.5;

const LS_KEY = 'miwe_cold_chain_rules';

export function loadProductRules(): ProductColdRule[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length) return parsed as ProductColdRule[];
    }
  } catch { /* yoksay */ }
  return DEFAULT_PRODUCT_RULES;
}

export function saveProductRules(rules: ProductColdRule[]) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(rules)); } catch { /* yoksay */ }
}

export function ruleForProduct(product?: string, rules: ProductColdRule[] = loadProductRules()): ProductColdRule {
  const p = (product || '').toLocaleLowerCase('tr');
  return rules.find(r => r.match.some(m => p.includes(m))) || FALLBACK_RULE;
}

export function storageTermForDays(days: number): (typeof STORAGE_TERMS)[number] {
  return STORAGE_TERMS.find(t => days <= t.maxDay) || STORAGE_TERMS[STORAGE_TERMS.length - 1];
}
