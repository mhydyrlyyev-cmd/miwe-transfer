/**
 * v3.4 — Soğuk Zincir Motoru (Madde 3, 4, 8, 9, 11)
 *
 * Tek bir RefID'nin hasattan müşteriye kadar kütle dengesi, aşama süreleri ve uyarıları.
 * Saf fonksiyonlar: yeni koleksiyon yok, mevcut kayıtlardan (hasat, ön soğutma fişi,
 * depo kabul, sevk, satış) hesaplanır. Ref numarası hiçbir adımda değişmez.
 *
 * KÜTLE DENGESİ (bir parti için)
 *   Hasat kg (H)            = Σ günlük hasat + geç gelen hasat düzeltmeleri
 *   Ön soğutmaya giren (P)  = Σ ön soğutma fişi net kg
 *   Doğrudan depoya (D)     = ön soğutmasız depoya alınan kg (düzeltme kaydı)
 *   Fire / kayıp (L)        = yazılan fire kayıtları
 *   AÇIK BAKİYE (B)         = H − P − D − L
 *      B > 0  → sahada / bekleyen meyve (Senaryo: 5000 hasat, 3000 ön soğutma → 2000 bekliyor)
 *      B < 0  → ön soğutmada hasattan fazla tartıldı → hasat kaydı eksik (geç gelen hasat / ölçü)
 *   Sorting ıskarta (C)     = Σ fiş ıskarta kg  → ıskarta oranı = C / P
 *   Depoya kabul (S)        = Σ depo kabul kg
 *   Çıkış (O)               = depo girişinden sonraki sevk + satış
 *   Depoda kalan (R)        = S − O
 */
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../types';
import {
  BALANCE_TOLERANCE_PCT, FIRST_ROOM_CHECK_AFTER_DAYS, OPEN_BALANCE_ALERT_H, PRECOOL_ALERT_STEPS,
  ProductColdRule, ruleForProduct, storageTermForDays, STORAGE_TERMS, StorageTerm,
} from '../config/coldChain';
import { isTestReference } from './refKind';

export type AlertLevel = 'info' | 'warning' | 'critical';
export type AlertKind =
  | 'OPEN_BALANCE' | 'OVER_BALANCE' | 'HARVEST_TO_PRECOOL' | 'PRECOOL_DURATION'
  | 'MCP_UNDECIDED' | 'MCP_DEADLINE' | 'ROOM_CHECK_DUE' | 'TERM_EXCEEDED' | 'TARGET_ROOM_MISSING'
  | 'TRANSIT_LONG';

export interface ColdChainAlert {
  id: string;
  refId: string;
  level: AlertLevel;
  kind: AlertKind;
  title: string;
  detail: string;
  /** Kullanıcıya önerilen eylem(ler) */
  actions: string[];
  location?: string;
  product?: string;
}

export interface LotFlow {
  ref: ReferenceItem;
  rule: ProductColdRule;
  harvestKg: number;
  harvestAt?: string;
  precooledKg: number;
  directToStoreKg: number;
  lossKg: number;
  openBalanceKg: number;
  /** ön soğutma / depo / fire kaydı var mı (yoksa tüm hasat bekliyor sayılır) */
  slipsTracked: boolean;
  culledKg: number;
  packedKg: number;
  storedKg: number;
  outKg: number;
  remainingKg: number | null;
  harvestToPrecoolH: number | null;
  precoolH: number | null;
  precoolOpen: boolean;
  mcp: { required: boolean; decision?: 'YES' | 'NO'; deadline?: string; appliedAt?: string; daysLeft?: number };
  storage: { warehouse: string; room: string; days: number; term: StorageTerm; lastCheckAt?: string; nextCheckDue?: string }[];
  /** Fire oranları (%), hesaplanamıyorsa null */
  lossPct: { harvestToPrecool: number | null; sortingCull: number | null; storage: number | null };
  alerts: ColdChainAlert[];
}

const H = 3600000;
const D = 86400000;
const t = (iso?: string) => {
  if (!iso) return NaN;
  const s = iso.length === 10 ? `${iso}T00:00:00` : iso;
  return new Date(s).getTime();
};
const hoursBetween = (a?: string, b?: string | number) => {
  const x = t(a); const y = typeof b === 'number' ? b : t(b);
  return Number.isFinite(x) && Number.isFinite(y) ? Math.max(0, (y - x) / H) : null;
};
const sum = (xs: (number | undefined | null)[]) => xs.reduce<number>((a, v) => a + (Number(v) || 0), 0);
const fmtKg = (v: number) => `${Math.round(v).toLocaleString('tr-TR')} kg`;
const fmtH = (v: number) => (v < 48 ? `${Math.round(v)} sa` : `${Math.round(v / 24)} gün`);
const pct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 1000) / 10 : null);

export interface ColdChainInput {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  now?: number;
}

export function analyzeLot(ref: ReferenceItem, inp: ColdChainInput): LotFlow {
  const now = inp.now ?? Date.now();
  const rule = ruleForProduct(ref.product);
  const harvests = inp.harvestRecords.filter(h => h.refId === ref.refId);
  const adj = ref.balanceAdjustments || [];
  const slips = ref.precoolingSlips || [];
  const ambars = inp.ambarRecords.filter(a => a.refId === ref.refId);

  const lateHarvest = sum(adj.filter(a => a.kind === 'LATE_HARVEST').map(a => a.kg));
  const correction = sum(adj.filter(a => a.kind === 'CORRECTION').map(a => a.kg));
  const harvestKgRaw = harvests.length ? sum(harvests.map(h => h.dailyTotalKg)) : (Number(ref.quantity) || 0);
  const harvestKg = harvestKgRaw + lateHarvest + correction;
  const harvestTimes = harvests.map(h => h.timestamp || h.recordDate).filter(Boolean).sort();
  const harvestAt = slips.find(s => s.harvestedAt)?.harvestedAt || harvestTimes[0] || ref.createdAt;

  const precooledKg = sum(slips.map(s => s.netKg));
  const culledKg = sum(slips.map(s => s.culledKg));
  const packedKg = sum(slips.map(s => s.packedKg));
  const directToStoreKg = sum(adj.filter(a => a.kind === 'DIRECT_TO_STORE').map(a => a.kg));
  const lossKg = sum(adj.filter(a => a.kind === 'LOSS').map(a => a.kg));
  const tracked = slips.length > 0 || directToStoreKg > 0 || lossKg > 0;
  const openBalanceKg = tracked ? harvestKg - precooledKg - directToStoreKg - lossKg : 0;

  const storedKg = sum(ambars.map(a => a.acceptedWeightKg));
  const firstEntry = ambars.map(a => (a.acceptanceDate || a.timestamp || '').slice(0, 10)).filter(Boolean).sort()[0] || '';
  const outKg = sum(inp.lojistikRecords.filter(l => l.refId === ref.refId && (!firstEntry || (l.shipmentDate || '').slice(0, 10) >= firstEntry)).map(l => l.weightKg))
    + sum(inp.salesRecords.filter(s => s.refId === ref.refId && (!firstEntry || (s.salesDate || '').slice(0, 10) >= firstEntry)).map(s => s.totalQuantityKg));
  const remainingKg = storedKg > 0 ? Math.max(0, storedKg - outKg) : null;

  // Aşama süreleri
  const firstSlip = [...slips].sort((a, b) => (a.startAt || a.date).localeCompare(b.startAt || b.date))[0];
  const harvestToPrecoolH = firstSlip?.startAt ? hoursBetween(harvestAt, firstSlip.startAt) : null;
  const openSlip = slips.find(s => s.startAt && !s.endAt);
  const storedAfterOpen = openSlip && ambars.some(a => t(a.acceptanceDate || a.timestamp) >= t(openSlip.startAt));
  const precoolOpen = !!openSlip && !storedAfterOpen;
  const precoolH = openSlip
    ? hoursBetween(openSlip.startAt, precoolOpen ? now : t(ambars[0]?.acceptanceDate || ambars[0]?.timestamp))
    : firstSlip?.startAt && firstSlip?.endAt ? hoursBetween(firstSlip.startAt, firstSlip.endAt) : null;

  // 1-MCP
  const decided = slips.find(s => s.mcpDecision);
  const mcpRequired = !!rule.mcpDeadlineDays;
  const deadlineMs = mcpRequired && Number.isFinite(t(harvestAt)) ? t(harvestAt) + (rule.mcpDeadlineDays as number) * D : NaN;
  const appliedAt = slips.find(s => s.mcpAppliedAt)?.mcpAppliedAt;
  const daysLeft = Number.isFinite(deadlineMs) ? Math.floor((deadlineMs - now) / D) : undefined;

  // Depo / oda
  const storage = ambars
    .filter(() => remainingKg === null || remainingKg > 0)
    .map(a => {
      const entry = a.acceptanceDate || a.timestamp;
      const days = Math.max(0, Math.floor((now - t(entry)) / D));
      const term = a.storageTerm || storageTermForDays(days).key;
      const termCfg = STORAGE_TERMS.find(x => x.key === term)!;
      const checks = [...(a.storageChecks || [])].sort((x, y) => x.at.localeCompare(y.at));
      const lastCheckAt = checks[checks.length - 1]?.at;
      const dueMs = lastCheckAt
        ? t(lastCheckAt) + termCfg.checkEveryDays * D
        : t(entry) + FIRST_ROOM_CHECK_AFTER_DAYS * D;
      const lastMove = (a.roomMovements || []).slice(-1)[0];
      return {
        warehouse: (lastMove?.toWarehouse || a.warehouse || '—').trim(),
        room: (lastMove?.toRoom || a.roomNo || '—').trim(),
        days, term, lastCheckAt,
        nextCheckDue: Number.isFinite(dueMs) ? new Date(dueMs).toISOString() : undefined,
      };
    });

  const lossPct = {
    harvestToPrecool: tracked && lossKg > 0 ? pct(lossKg, harvestKg) : null,
    sortingCull: culledKg > 0 ? pct(culledKg, precooledKg || harvestKg) : null,
    storage: storedKg > 0 && remainingKg !== null && remainingKg === 0 && outKg > 0 ? pct(Math.max(0, storedKg - outKg), storedKg) : null,
  };

  // ── Uyarılar ──
  const alerts: ColdChainAlert[] = [];
  const loc = ref.orchard || ref.location;
  const push = (a: Omit<ColdChainAlert, 'id' | 'refId' | 'product' | 'location'>) =>
    alerts.push({ ...a, id: `${ref.refId}-${a.kind}-${alerts.length}`, refId: ref.refId, product: ref.product, location: loc });

  const tol = Math.max(1, harvestKg * BALANCE_TOLERANCE_PCT / 100);
  const lastHarvestAt = harvestTimes[harvestTimes.length - 1] || harvestAt;
  const balanceAgeH = hoursBetween(lastHarvestAt, now) ?? 0;
  if (openBalanceKg > tol && ref.status === 'CREATED') {
    push({
      kind: 'OPEN_BALANCE',
      level: balanceAgeH >= OPEN_BALANCE_ALERT_H * 2 ? 'critical' : balanceAgeH >= OPEN_BALANCE_ALERT_H ? 'warning' : 'info',
      title: `${fmtKg(openBalanceKg)} ön soğutmaya girmedi`,
      detail: `Hasat ${fmtKg(harvestKg)} · ön soğutma ${fmtKg(precooledKg)}${directToStoreKg ? ` · doğrudan depo ${fmtKg(directToStoreKg)}` : ''}${lossKg ? ` · fire ${fmtKg(lossKg)}` : ''} · ${fmtH(balanceAgeH)} geçti`,
      actions: ['İkinci ön soğutma fişi aç (aynı RefID)', 'Doğrudan depoya alındı olarak yaz', 'Fire / kayıp yaz (neden ile)', 'Hasat kg yanlışsa düzelt'],
    });
  }
  if (openBalanceKg < -tol) {
    push({
      kind: 'OVER_BALANCE', level: 'warning',
      title: `Ön soğutmada hasattan ${fmtKg(-openBalanceKg)} fazla`,
      detail: `Hasat ${fmtKg(harvestKg)} · ön soğutma ${fmtKg(precooledKg)}. Geç gelen hasat veya tartı farkı olabilir.`,
      actions: ['Geç gelen hasat olarak ekle (günlük hasata yazılır)', 'Ön soğutma fişindeki kg değerini kontrol et'],
    });
  }
  if (harvestToPrecoolH !== null && harvestToPrecoolH > rule.harvestToPrecoolMaxH) {
    push({
      kind: 'HARVEST_TO_PRECOOL', level: harvestToPrecoolH > rule.harvestToPrecoolMaxH * 2 ? 'critical' : 'warning',
      title: `Hasattan ön soğutmaya ${fmtH(harvestToPrecoolH)}`,
      detail: `${rule.label} için hedef en fazla ${rule.harvestToPrecoolMaxH} sa.`,
      actions: ['Gecikme nedenini nota yaz', 'Bahçe / ekip planını gözden geçir'],
    });
  }
  if (precoolOpen && precoolH !== null) {
    const max = Math.min(PRECOOL_ALERT_STEPS.critical, rule.precoolMaxH);
    const level: AlertLevel | null = precoolH >= max ? 'critical' : precoolH >= PRECOOL_ALERT_STEPS.warning ? 'warning' : precoolH >= PRECOOL_ALERT_STEPS.info ? 'info' : null;
    if (level) {
      const target = openSlip?.afterPrecool === 'STAY' ? 'aynı yerde kalacak' : openSlip?.targetRoom ? `hedef: ${openSlip.targetWarehouse || ''} ${openSlip.targetRoom}` : 'hedef depo/oda girilmedi';
      push({
        kind: 'PRECOOL_DURATION', level,
        title: `${fmtH(precoolH)} ön soğutmada`,
        detail: `${rule.label}: beklenen ${rule.precoolMinH}–${rule.precoolMaxH} sa · ${target}${openSlip?.tunnel ? ` · ${openSlip.tunnel}` : ''}`,
        actions: level === 'info'
          ? ['Meyve içi sıcaklığı ölçüldü mü?', 'Ön soğutmadan sonra nereye gidecek?']
          : ['Meyve içi sıcaklığı ölç', 'Soğuk odaya sevk et (depo + oda no)', 'Aynı yerde stok soğutmaya bırak (set değeri gir)'],
      });
    }
    if (openSlip && !openSlip.afterPrecool && !openSlip.targetRoom && precoolH >= PRECOOL_ALERT_STEPS.info) {
      push({ kind: 'TARGET_ROOM_MISSING', level: 'info', title: 'Ön soğutma sonrası hedef oda yok', detail: 'Depo ve oda numarası girilirse sevk ve kontrol uyarıları doğru odaya bağlanır.', actions: ['Hedef depo / oda gir', '“Aynı yerde kalıyor” seç'] });
    }
  }
  if (mcpRequired && !appliedAt && ref.status !== 'SOLD' && ref.status !== 'COMPLETED' && Number.isFinite(deadlineMs)) {
    const dl = new Date(deadlineMs).toLocaleDateString('tr-TR');
    if (!decided && (daysLeft ?? 0) >= 0) {
      push({ kind: 'MCP_UNDECIDED', level: (daysLeft ?? 99) <= 1 ? 'warning' : 'info', title: '1-MCP kararı verilmedi', detail: `${rule.label}: hasattan sonra ${rule.mcpDeadlineDays} gün içinde (son: ${dl}, ${daysLeft} gün kaldı)`, actions: ['Ön soğutma fişinde 1-MCP: Evet / Hayır seç'] });
    } else if (decided?.mcpDecision === 'YES') {
      const level: AlertLevel = (daysLeft ?? 0) < 0 ? 'critical' : (daysLeft ?? 99) <= 1 ? 'warning' : 'info';
      push({ kind: 'MCP_DEADLINE', level, title: (daysLeft ?? 0) < 0 ? '1-MCP süresi geçti' : `1-MCP için ${daysLeft} gün kaldı`, detail: `Son gün ${dl}${decided.mcpPlannedAt ? ` · planlanan ${new Date(decided.mcpPlannedAt).toLocaleString('tr-TR')}` : ''}`, actions: ['Uygulama saatini fişe yaz', 'Oda / doz bilgisini gir'] });
    }
  }
  for (const s of storage) {
    const due = t(s.nextCheckDue);
    if (Number.isFinite(due) && now > due) {
      const termCfg = STORAGE_TERMS.find(x => x.key === s.term)!;
      const late = (now - due) / D;
      push({
        kind: 'ROOM_CHECK_DUE', level: late > termCfg.checkEveryDays ? 'critical' : 'warning',
        title: s.lastCheckAt ? `Oda kontrolü gecikti (${Math.ceil(late)} gün)` : 'Odaya girişte ilk set / kontrol yapılmadı',
        detail: `${s.warehouse} · ${s.room} · ${s.days}. gün · ${termCfg.label}, her ${termCfg.checkEveryDays} günde kontrol`,
        actions: ['Set / oda / meyve içi sıcaklık, nem (RH%)', 'CA odada O₂ / CO₂', 'Havalandırma, yer ıslatma', 'Oda değiştiyse taşıma kaydı'],
      });
    }
    if (s.days > 200) {
      push({ kind: 'TERM_EXCEEDED', level: 'warning', title: `${s.days} gündür depoda`, detail: `${s.warehouse} · ${s.room} · uzun dönem sınırı (200 gün) aşıldı`, actions: ['Kalite kontrol / sorting planla', 'Satış önceliği ver'] });
    }
  }

  // Sevk: yolda beklenenden uzun kalan yükler (varış kaydı / teslim yok)
  if (ref.status === 'SHIPPED' || ref.status === 'IN_TRANSIT') {
    const open = inp.lojistikRecords.filter(l => l.refId === ref.refId && l.status !== 'DELIVERED');
    for (const l of open) {
      const start = l.loadingDate || l.shipmentDate || l.timestamp;
      const hrs = hoursBetween(start, now);
      const limitDays = Number(l.transitDays) > 0 ? Number(l.transitDays) : 3;
      if (hrs !== null && hrs / 24 > limitDays) {
        push({
          kind: 'TRANSIT_LONG', level: hrs / 24 > limitDays * 2 ? 'critical' : 'warning',
          title: `${fmtH(hrs)} yolda`,
          detail: `${l.vehiclePlate || 'araç ?'} · ${l.source || '—'} → ${l.destination || '—'} · beklenen ${limitDays} gün`,
          actions: ['Varışı / teslimi kaydet', 'Şoför veya alıcı ile görüş', 'Datalogger verisini kontrol et'],
        });
      }
    }
  }

  return {
    ref, rule, harvestKg, harvestAt, precooledKg, directToStoreKg, lossKg, openBalanceKg, slipsTracked: tracked, culledKg, packedKg,
    storedKg, outKg, remainingKg, harvestToPrecoolH, precoolH, precoolOpen,
    mcp: { required: mcpRequired, decision: decided?.mcpDecision, deadline: Number.isFinite(deadlineMs) ? new Date(deadlineMs).toISOString() : undefined, appliedAt, daysLeft },
    storage, lossPct, alerts,
  };
}

export interface ColdChainSummary {
  lots: LotFlow[];
  alerts: ColdChainAlert[];
  byRoom: { key: string; warehouse: string; room: string; lots: number; kg: number; avgDays: number; overdueChecks: number }[];
  byOrchard: { orchard: string; lots: number; harvestKg: number; avgHarvestToPrecoolH: number | null; openBalanceKg: number; cullPct: number | null }[];
  byDestination: { destination: string; shipments: number; kg: number }[];
  byProductLoss: { product: string; harvestKg: number; lossKg: number; culledKg: number; precooledKg: number; lossPct: number | null; cullPct: number | null; expectedCullPct?: number }[];
}

const LEVEL_ORDER: Record<AlertLevel, number> = { critical: 0, warning: 1, info: 2 };

export function analyzeColdChain(inp: ColdChainInput): ColdChainSummary {
  const lots = inp.references.filter(r => !r.archived && !isTestReference(r)).map(r => analyzeLot(r, inp));
  const alerts = lots.flatMap(l => l.alerts).sort((a, b) => LEVEL_ORDER[a.level] - LEVEL_ORDER[b.level]);

  const rooms = new Map<string, { warehouse: string; room: string; lots: number; kg: number; days: number; overdue: number }>();
  for (const l of lots) for (const s of l.storage) {
    const k = `${s.warehouse}__${s.room}`;
    const r = rooms.get(k) || { warehouse: s.warehouse, room: s.room, lots: 0, kg: 0, days: 0, overdue: 0 };
    r.lots++; r.kg += l.remainingKg ?? l.storedKg; r.days += s.days;
    if (s.nextCheckDue && Date.parse(s.nextCheckDue) < (inp.now ?? Date.now())) r.overdue++;
    rooms.set(k, r);
  }

  const orch = new Map<string, { lots: number; harvestKg: number; h2p: number[]; open: number; cull: number; pre: number }>();
  const prod = new Map<string, { harvestKg: number; lossKg: number; culledKg: number; precooledKg: number; expected?: number }>();
  for (const l of lots) {
    const o = (l.ref.orchard || l.ref.location || '—').trim();
    const x = orch.get(o) || { lots: 0, harvestKg: 0, h2p: [], open: 0, cull: 0, pre: 0 };
    x.lots++; x.harvestKg += l.harvestKg; if (l.harvestToPrecoolH !== null) x.h2p.push(l.harvestToPrecoolH);
    x.open += Math.max(0, l.openBalanceKg); x.cull += l.culledKg; x.pre += l.precooledKg;
    orch.set(o, x);
    const p = (l.ref.product || '—').replace(/\s*\(.*\)\s*$/, '').trim();
    const y = prod.get(p) || { harvestKg: 0, lossKg: 0, culledKg: 0, precooledKg: 0, expected: l.rule.expectedLoss?.sortingCullPct };
    y.harvestKg += l.harvestKg; y.lossKg += l.lossKg; y.culledKg += l.culledKg; y.precooledKg += l.precooledKg;
    prod.set(p, y);
  }

  const dest = new Map<string, { shipments: number; kg: number }>();
  const lotIds = new Set(lots.map(l => l.ref.refId));
  for (const s of inp.lojistikRecords) if (lotIds.has(s.refId)) {
    const k = (s.destination || '—').trim();
    const d = dest.get(k) || { shipments: 0, kg: 0 }; d.shipments++; d.kg += Number(s.weightKg) || 0; dest.set(k, d);
  }
  for (const s of inp.salesRecords) if (lotIds.has(s.refId)) {
    const k = (s.destination || s.customer || '—').trim();
    const d = dest.get(k) || { shipments: 0, kg: 0 }; d.shipments++; d.kg += Number(s.totalQuantityKg) || 0; dest.set(k, d);
  }

  return {
    lots, alerts,
    byRoom: [...rooms.entries()].map(([key, r]) => ({ key, warehouse: r.warehouse, room: r.room, lots: r.lots, kg: r.kg, avgDays: r.lots ? Math.round(r.days / r.lots) : 0, overdueChecks: r.overdue })).sort((a, b) => b.kg - a.kg),
    byOrchard: [...orch.entries()].map(([orchard, x]) => ({ orchard, lots: x.lots, harvestKg: x.harvestKg, avgHarvestToPrecoolH: x.h2p.length ? Math.round(x.h2p.reduce((a, b) => a + b, 0) / x.h2p.length * 10) / 10 : null, openBalanceKg: x.open, cullPct: pct(x.cull, x.pre) })).sort((a, b) => b.harvestKg - a.harvestKg),
    byDestination: [...dest.entries()].map(([destination, d]) => ({ destination, ...d })).sort((a, b) => b.kg - a.kg),
    byProductLoss: [...prod.entries()].map(([product, y]) => ({ product, harvestKg: y.harvestKg, lossKg: y.lossKg, culledKg: y.culledKg, precooledKg: y.precooledKg, lossPct: pct(y.lossKg, y.harvestKg), cullPct: pct(y.culledKg, y.precooledKg), expectedCullPct: y.expected })).sort((a, b) => b.harvestKg - a.harvestKg),
  };
}
