import type { ReferenceItem, ReferenceStatus, StatusChangeEntry } from '../types';
import { isTestReference } from './refKind';

/**
 * v3.4 — Referans Yaşam Döngüsü (Madde 1)
 *
 * 13 teknik durum kodu, kullanıcının takip ettiği 5 ana aşamaya indirgenir:
 *   SAHADA      → CREATED                         (hasat edildi / ön soğutmada, sevk edilmedi)
 *   YOLDA       → SHIPPED, IN_TRANSIT             (araçta)
 *   DEPODA      → RECEIVED, PARTIAL, EXPORT_TESTED, IN_FREEZE_DRY (soğuk depoda kabul edildi / işlemde)
 *   INCIDENT    → INCIDENT                        (açık tutanak)
 *   TAMAMLANDI  → COMPLETED, SOLD, CLOSED, FREEZE_DRY_COMPLETED, REJECTED
 * Test referansları (refKind=TEST) stok aşamalarına girmez, ayrı sayılır.
 */
export type LifecycleStage = 'SAHADA' | 'YOLDA' | 'DEPODA' | 'INCIDENT' | 'TAMAMLANDI' | 'TEST';

export const LIFECYCLE_STAGES: { key: Exclude<LifecycleStage, 'TEST'>; label: string; short: string; statuses: ReferenceStatus[]; color: string }[] = [
  { key: 'SAHADA', label: 'Sahada', short: 'Saha', statuses: ['CREATED'], color: 'blue' },
  { key: 'YOLDA', label: 'Sevkiyatta / Yolda', short: 'Yolda', statuses: ['SHIPPED', 'IN_TRANSIT'], color: 'amber' },
  { key: 'DEPODA', label: 'Soğuk Depoda (Kabul)', short: 'Depoda', statuses: ['RECEIVED', 'PARTIAL', 'EXPORT_TESTED', 'IN_FREEZE_DRY'], color: 'teal' },
  { key: 'INCIDENT', label: 'Aktif Incident', short: 'Incident', statuses: ['INCIDENT'], color: 'rose' },
  { key: 'TAMAMLANDI', label: 'Tamamlandı', short: 'Bitti', statuses: ['COMPLETED', 'SOLD', 'CLOSED', 'FREEZE_DRY_COMPLETED', 'REJECTED'], color: 'emerald' },
];

export function lifecycleStage(ref: Partial<ReferenceItem>): LifecycleStage {
  if (isTestReference(ref)) return 'TEST';
  const st = ref.status as ReferenceStatus;
  for (const s of LIFECYCLE_STAGES) if (s.statuses.includes(st)) return s.key;
  return 'SAHADA';
}

export interface LifecycleCounts {
  SAHADA: number; YOLDA: number; DEPODA: number; INCIDENT: number; TAMAMLANDI: number; TEST: number;
  kg: { SAHADA: number; YOLDA: number; DEPODA: number; INCIDENT: number; TAMAMLANDI: number };
}

/** Arşivlenmiş kayıtlar sayılmaz. */
export function lifecycleCounts(refs: ReferenceItem[]): LifecycleCounts {
  const c: LifecycleCounts = { SAHADA: 0, YOLDA: 0, DEPODA: 0, INCIDENT: 0, TAMAMLANDI: 0, TEST: 0, kg: { SAHADA: 0, YOLDA: 0, DEPODA: 0, INCIDENT: 0, TAMAMLANDI: 0 } };
  for (const r of refs) {
    if (r.archived) continue;
    const st = lifecycleStage(r);
    c[st]++;
    if (st !== 'TEST') c.kg[st] += Number(r.quantity) || 0;
  }
  return c;
}

/** İşlem (modül) kodunun okunur adı — durum geçmişinde "hangi işlemde değişti" için */
export const MODULE_ACTION_LABEL: Record<string, string> = {
  HARVEST: 'Günlük Hasat',
  FIELD: 'Saha Testi',
  MUZ: 'Muz',
  BADEM: 'Badem',
  LOJISTIK: 'Lojistik / Sevk',
  AMBAR: 'Depo Kabul',
  COLD_STORAGE: 'Soğuk Depo',
  FREEZE_DRY: 'Freeze-Dry',
  EXPORT_SAMPLE: 'İhracat Numunesi',
  SALES: 'Satış',
  INCIDENT: 'Incident / Akt',
  REFERENCES: 'Referans Listesi',
  BULK: 'Toplu Güncelleme',
  SYSTEM: 'Sistem',
};

export function moduleActionLabel(m?: string): string {
  if (!m) return 'Bilinmiyor';
  return MODULE_ACTION_LABEL[m] || m;
}

const MAX_HISTORY = 30;

/**
 * prev → next listesi arasında durumu değişen referanslara geçmiş satırı ekler.
 * Saf fonksiyondur (React StrictMode'da iki kez çağrılsa da aynı sonucu verir).
 */
export function stampStatusChanges(
  prev: ReferenceItem[],
  next: ReferenceItem[],
  actor: { module: string; by?: string; note?: string }
): ReferenceItem[] {
  if (prev === next) return next;
  const before = new Map<string, ReferenceItem>();
  for (const r of prev) before.set(r.refId, r);
  let changed = false;
  const out = next.map(r => {
    const old = before.get(r.refId);
    if (!old || old.status === r.status) return r;
    // Aynı geçiş zaten yazıldıysa tekrar yazma
    const last = r.statusHistory?.[r.statusHistory.length - 1];
    if (last && last.from === old.status && last.to === r.status && r.statusHistory !== old.statusHistory) return r;
    const entry: StatusChangeEntry = {
      at: new Date().toISOString(),
      from: old.status,
      to: r.status,
      module: actor.module,
      ...(actor.by ? { by: actor.by } : {}),
      ...(actor.note ? { note: actor.note } : {}),
    };
    changed = true;
    const hist = [...(old.statusHistory || []), entry].slice(-MAX_HISTORY);
    return { ...r, statusHistory: hist, updatedAt: entry.at };
  });
  return changed ? out : next;
}

export function lastStatusChange(ref: Partial<ReferenceItem>): StatusChangeEntry | undefined {
  const h = ref.statusHistory;
  return h && h.length ? h[h.length - 1] : undefined;
}

/** "3 sa önce", "2 gün önce" */
export function timeAgoTr(iso?: string, now: number = Date.now()): string {
  if (!iso) return '';
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return '';
  const min = Math.max(0, Math.round((now - t) / 60000));
  if (min < 1) return 'şimdi';
  if (min < 60) return `${min} dk önce`;
  const h = Math.round(min / 60);
  if (h < 48) return `${h} sa önce`;
  return `${Math.round(h / 24)} gün önce`;
}
