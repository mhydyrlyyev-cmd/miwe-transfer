# v36 (v3.4 + v3.6) — v35 üzerine yama

Bu zip yalnızca değişen ve yeni dosyaları içerir; proje köküne aynı yollarla kopyalayın.
firestore.rules değişti (locationProfiles koleksiyonu) — kuralları yeniden yükleyin.

v3.4: referans yaşam döngüsü kartları + durum geçmişi, kayıt sonrası başarı ekranı,
soğuk zincir motoru (açık bakiye, ön soğutma süreleri, 1-MCP, depo süre sınıfları), yer profilleri.
v3.6: süreç aşamaları (Hasat → Ön soğutma → Soğuk depo → Sevk) ayrımı: aşama şeridi,
Ön Soğutma ve Yoldaki Yükler izleme sayfaları, uyarılar yalnızca kendi aşamasında,
hasat/depo kabul formlarından ön soğutma ve 1-MCP seçenekleri çıkarıldı.
