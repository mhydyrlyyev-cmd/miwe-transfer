# v49c — Yeni mimari 1. parça: Ana sayfa · Menü · Depolar › bina › oda · Oda kontrol turu (v49b2 dahil)

v49b2 bu pakete DAHİL (hasat başlat/bitir, kalibrasyon, 5 adımlı şerit). v49b2.zip ayrıca gönderilmez.

## Alt menü
Ana · Partiler · [+] · Depolar · Menü. Uyarılar Ana sayfadaki zilde; senkron Menü'de (çevrimdışı / bekleyen kayıt Menü simgesinde turuncu nokta).
Açılış ekranı Ana sayfa. Sayfa başındaki "← Ana menü" yerine "← Ana sayfa".

## Ana sayfa
1. Bugün bakılacaklar: set dışı odalar, yapılmamış oda kontrol turu, soğuk zincir uyarıları, kalibrasyonu geçen cihaz — her satırda iş düğmesi.
2. Akış: Hasat · Ön soğutma · Sortlama · Depo · Sevk (parti + ton), dokununca o aşama.
3. Depolar: depo başına doluluk çubuğu (kapasite girilmemişse açık renk, yüzde yok).
4. Bu hafta: hasat, sevk, kalite testi, açık akt.
Eski 4 aşama paneli, özet kartları ve stok grafiği ana sayfadan kaldırıldı (dosyaları duruyor).

## Menü
Kayıt · Testler · Takvim ve akışlar · Raporlar · Yönetim; her satırda simge.

## Depolar
Depo kartları → depo içi (bina › oda kartları: son sıcaklık, set, doluluk, parti, gün) → oda içi (partiler + kontrol/taşı + hareket defteri: giriş, taşıma, kontrol, oda turu, çıkış).
Profili olmayan depo adları ayrı listede ("Datly Miwe…" deneme kayıtları; sayımlara girmez).

## Oda kontrol turu (yeni, Firestore 'roomChecks')
Bir depodaki tüm odalar tek ekranda: monitör, cihaz, meyve iç, nem; açılınca set, O₂/CO₂ (KA odaları), durum, 1-MCP, not.
Set dışı kutu sarı/kırmızı; monitör–cihaz farkı ≥ 2 °C → kalibrasyon uyarısı.

## Profiller (tohum, kullanıcı düzenler)
- PM · Paýlaýyş nokady: TS-1, TS-2, M-1…M-5, GÖ, B-1…B-3, FD-1…FD-3, İşleme I/M/B (17 oda, set aralıkları 19.11 tablosundan).
- Garahan · Kaka: G-1 (M-1…M-4, KA-1…KA-3 kontrollü atmosfer), G-2 (GÖ-1, GÖ-3…GÖ-9, TS) — 16 oda.
- Bagyr depo, Saýwan Gursak depo (2'şer oda, 40–60 t), Muz seraları (7 oda, 10–15 t).
- Oda profiline yeni alanlar: bina, oda kodu, oda tipi, set alt / üst. Depo profiline: kısa ad, sorumlu, koordinat.
- Depo kabulde oda listesi seçili deponun odaları (kod · tip · set).

## Temizlik ve düzeltmeler
- "Datly Miwe" örnek adı koddan kaldırıldı; PDF'te şirket adı yerine "Kalite kontrol bölümü".
- Kayıt ekranında "Firma" yerine "Bölüm": Saha/bahçeler, Seralar (muz), Muz kalite ve paketleme, Depo, Lojistik/sevk, Satış, Freeze-dry (Erem), Kalite merkezi, Yönetim.
- Badem kusur %: numune boşken 1 g'a bölünüp %3200 çıkıyordu → sağlam + kusur gramına göre; yeni testte hazır örnek gramajlar (312, 12…) kaldırıldı.
- Muz kalite kartı: kalibre ve parmak boyu girilmeden karar vermiyor ("veri bekleniyor").
- Yukarı ok düğmesi formlarda ve depo ekranında gizli; diğerlerinde küçük ve alt menünün üstünde.
- Soğuk depo kartında giriş tarihi okunur biçimde.

## Firestore kuralı DEĞİŞTİ
firestore.rules: operationalCollections listesine 'roomChecks' eklendi → DeployRules GEREKLİ.

## SHA-256 (38 dosya)
f983ff7170c604f1a1bc0882c31006a7dc886154dbd79c62b5b7e23a11ce4d8d  firestore.rules
f5d7f8a17145c09d4d6af14b6276e4e8ae38ca404284cab5bb1957230c74643d  src/App.tsx
442ca801d847f186aa3b5891ebf2aa61fb004110d1b7e4664d86dfd24a5efb8d  src/components/GuideModal.tsx
d88dc01c4d042c9d4c04fd585c82a0c2b4bd6cba6543b4e7a935c3a928128836  src/components/Header.tsx
4503da5c4c437c53fd92d9095a020f99850f8ae9e402fc470ea3680645e585a2  src/components/ModuleCards.tsx
fc12a0814d28d0b0d279e167e22ebfd8f3343aa4087ab3b6f0c504a90e4eb7bb  src/components/admin/AdminOptionsStandardsModal.tsx
823cfdc4644084f3e7ff363de1f602abbb165ede72d2e3eb3eab35cd8341cceb  src/components/auth/LoginView.tsx
957b976a87c1d5e2f638a78e76ddaf61d30045719b39d112b41483029600b04b  src/components/coldchain/LocationProfilesModal.tsx
6fcf2743ad506d2045a8bebd2df982f78ed1c5800ec4ad91f0aa0afacdc3795a  src/components/common/MobileBottomBar.tsx
171036c26bb54f66d078b937967a2a7c946acf7e98425d267fa34b65fdff3a5c  src/components/common/ScrollToTopButton.tsx
db13149a8e8ff8946157e8c8c16f76908ca7929ec722bc1e26ccb11872dbc06f  src/components/dashboard/HomeDashboard.tsx
cff06cf6e7342117cae095a7a872c41b8417696de4d057fff90d6488d430d14d  src/components/forms/AmbarForm.tsx
149d4ae843de067231f5878dc0e54eae2174b6770bb787b780c7065b89befe4c  src/components/forms/BademForm.tsx
1b12a8409335b43760eead06a01ba09b292804a662747ac69469ed7099c6bce4  src/components/forms/FieldForm.tsx
145dd29de6fa652bb4f74c48b5354ae397f753853305fad5cd33c9aea7768362  src/components/forms/InteractiveBananaQualityTraceabilityWidget.tsx
2e9a72179c121a7a1419f866c75e8ddf300526fee4f2e01d215b4439daec6859  src/components/forms/LojistikForm.tsx
36d64d0a205885022cee26e85d0c99bd0513cfbd5745be7e6e276f6c685db1c6  src/components/notifications/CreateNotificationModal.tsx
045eb8db17201fba9e742e34bda58d1d34fe0cae3fa9c8aa005417e4563b1e20  src/components/portal/GuidePortal.tsx
f8c1abb31db6065d6c5fcddbdb16911a6ec1cd0cc107d6ffb26939e9351ac286  src/components/portal/HomeMenu.tsx
f206b8225f5bb4a1c547dedb040130c38d79ed59f018e130b5368292fce9b381  src/components/ui/StageRail.tsx
4144d4a1985ad14d72ea30dfb024792b0f3545ca1fe3755ceadf548c8b281c16  src/components/views/ColdStorageView.tsx
eda850dbd7a90d96bbcd5dc37a151dd75d14b046007bfee2eb5aa2605957729a  src/components/views/DepotsView.tsx
0163b91898c4429881537852c6ff56184eb233e3c9208eb9b1c703f827c10afb  src/components/views/FeedbackView.tsx
4eb9be9ccb3c72a7979c153d40087838e189d1870749e79cadf2886190d6a473  src/components/views/HarvestCalendarView.tsx
278cb4dc8b24a69eba6ffc88528ae61fc0bc2df7d5040f800d3096ccaafbe7e2  src/components/views/MultiPagePdfReportModal.tsx
5d94a86cbaa0cb99b23eef1e6d22d1731db840e65864f3f492a46bc13fd9fa62  src/components/views/RoomCheckTour.tsx
929dc851d121363b1d65e6d97ef16ea3568de2bca142a5782453f31d079110db  src/components/views/StageMonitorView.tsx
bb2d64c025ef796afdb1902ed14cb17d0144c03b3bc0f28fabd20f3fd5548a5a  src/components/views/TraceabilityLedgerView.tsx
c2449b9e36a96d3d646df2be0b151d11a4f0899af56d4cd990fdd8cb4bbe474a  src/config/calibrationRules.ts
69a8213ec7af6fefbfceee7a645d311a717446ae87cab4c495a741ab67c8d2c1  src/config/coldStorage.ts
d471a3fc265a8e245886ec0b460c24a6265cf3175b9b60f478dadf405f0220a4  src/config/profileSeed.ts
579f545c8976dd995095f8547cdff10f4781aa7c216253308b0f15b71cfc91e7  src/data/initialData.ts
9f63d301d9490b6552c6dcd47c112d5bc12f3f81132085b802934aa3a8db4372  src/lib/firestoreService.ts
65642d14c686e0b61c37018e7f499620181dd8711b40a0f67c09e5da17ec05d0  src/services/depots.ts
067e5799748c604c900709c9267b95fa38722917d6415470bfba89eb937f1c4f  src/services/harvestCalendar.ts
5d31cd5e61d0568f410137692b8de54c6b50e502955e983020df573d35a1e66d  src/services/locationProfiles.ts
d123aad2089614ac7c894d2e5abc71bb17bdcaaebddb56b0526b707501b9a947  src/services/optionsService.ts
589a44d771ed6f85869664ee63cfb3b0386a299edf19d876b8eaec322d50e46f  src/types/auth.ts
