import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  IncidentRecord,
  ExportSampleRecord,
  SalesRecord,
  FreezeDryRecord,
  FeedbackRecord
} from '../types';

// CANLI ORTAM (COLD-START MODU): Tüm varsayılan test/demo kayıtları ve örnek Barlag Akty kütükleri temizlendi.
// İlk gerçek veri girilene kadar sistem Sıfır Veri (Veri Bekleniyor) durumunda temiz başlar.

export const INITIAL_REFERENCES: ReferenceItem[] = [];
export const INITIAL_HARVEST_RECORDS: HarvestRecord[] = [];
export const INITIAL_FIELD_RECORDS: FieldRecord[] = [];
export const INITIAL_MUZ_RECORDS: MuzRecord[] = [];
export const INITIAL_BADEM_RECORDS: BademRecord[] = [];
export const INITIAL_LOJISTIK_RECORDS: LojistikRecord[] = [];
export const INITIAL_AMBAR_RECORDS: AmbarRecord[] = [];
export const INITIAL_EXPORT_SAMPLE_RECORDS: ExportSampleRecord[] = [];
export const INITIAL_SALES_RECORDS: SalesRecord[] = [];
export const INITIAL_INCIDENT_RECORDS: IncidentRecord[] = [];
export const INITIAL_FREEZE_DRY_RECORDS: FreezeDryRecord[] = [];
export const INITIAL_FEEDBACKS: FeedbackRecord[] = [];







// Form Açılır Menüleri İçin Standart Sözlük Listeleri (Kullanıcı dinamik olarak '+ Yeni Ekle' ile genişletebilir)
export const AUTOCOMPLETE_LISTS = {
  products: [
    'Şeftali',
    'Nektarin',
    'Kiraz',
    'Elma',
    'Muz',
    'Badem',
    'Gawun (Kavun)',
    'Liyofilizirlenen Miwe (Freeze-Dried Fruit)'
  ],
  customers: [],
  salesChannels: [
    'Eksport (Daşary Ýurt Satışı)',
    'Ýerli Marketler Zynjyry (Modern Retail)',
    'Optom / Toptan Söwda Bazasyna Çykyş',
    'Fabrika / Önümçilik Gaýtadan İşleme',
    'Firmaly Brend Dükany (Retail)'
  ],
  varieties: {
    'Muz': ['Cavendish Grand Nain', 'Cavendish Extra', 'Williams', 'Dwarf Cavendish'],
    'Muz (Grand Nain & Cavendish)': ['Cavendish Grand Nain', 'Cavendish Extra', 'Williams', 'Dwarf Cavendish'],
    'Badem': ['Nonpareil', 'Ferragnes', 'Ferraduel', 'Guara', 'Laurenne', 'Texas', 'Mazzetto'],
    'Badem (Nonpareil & Gabykly/Gabyksyz)': ['Nonpareil', 'Ferragnes', 'Ferraduel', 'Guara', 'Laurenne', 'Texas'],
    'Kiraz': ['Lapins', 'Regina', 'Kordia', 'Ziraat 900', 'Sweetheart', 'Early Burlat'],
    'Kiraz / Ülje': ['Lapins', 'Regina', 'Kordia', 'Ziraat 900', 'Sweetheart', 'Early Burlat'],
    'Kiraz (Lapins & Sweetheart)': ['Lapins', 'Regina', 'Kordia', 'Ziraat 900', 'Sweetheart', 'Early Burlat'],
    'Şetdaly / Şeftali': ['Extreme 314', 'Royal Glory', 'Glohaven', 'Redhaven', 'Sweet Dream'],
    'Şeftali': ['Extreme 314', 'Royal Glory', 'Glohaven', 'Redhaven', 'Sweet Dream'],
    'Nektarin': ['Royal Glory', 'Big Bang', 'Extreme Beauty', 'Caldesi 2000'],
    'Elma': ['Early Gold', 'Gallaval', 'Golden Reinders', 'Scarlet Spur', 'Story Inored', 'Rosy Glow', 'Simerenka', 'Fuji', 'Granny Smith (Sadece Bagyr / Durun)'],
    'Elma (Gala & Fuji & Golden)': ['Early Gold', 'Gallaval', 'Golden Reinders', 'Scarlet Spur', 'Story Inored', 'Rosy Glow', 'Simerenka', 'Fuji'],
    'Gawun (Gulabi & Waharman)': ['Gulabi', 'Waharman', 'Garrygyz'],
    'Liyofilizirlenen Miwe (Freeze-Dried Fruit)': ['Freeze-Dried Muz Dilimleri', 'Freeze-Dried Alma', 'Freeze-Dried Ýertudana', 'Badem Şokoladly']
  },
  qualityClasses: [
    'EXTRA (V-20) — Ekstra Kalite',
    'I (V-22) EXC — 1. Sınıf Mükemmel / Excellent',
    'II (V-24) PRM — 2. Sınıf Premium',
    'III (V26-28) CLS — 3. Sınıf Klasik / Standart',
    'Mix — Karışık / Sanayi & İşleme Sınıfı',
    'Standart Däl / Standart Dışı — Standart Değil (Iskarta / Freeze-Dry)'
  ],
  locations: [
    'Gök Bulut (Meyve Bahçesi & Muz Serası)',
    'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
    'Miweli Atyz (Muz Serası & Kaka Badem Plantasyonu)',
    'PM · Paýlaýyş nokady',
    'Erem™ (İhracat Numune & Raf Ömrü Laboratuvarı)'
  ],
  warehouses: [
    'PM · Paýlaýyş nokady',
    'Garahan · Kaka',
    'Bagyr depo',
    'Saýwan Gursak depo',
    'Muz seraları'
  ],
  rooms: ['M-1', 'M-2', 'M-3', 'M-4', 'M-5', 'GÖ', 'B-1', 'B-2', 'B-3', 'TS-1', 'TS-2'],
  ribbons: ['Mavi Kurdele (H-1)', 'Yeşil Kurdele (H-2)', 'Sarı Kurdele (H-3)', 'Kırmızı Kurdele (H-4)'],
  transportTypes: [
    'Frigorifik Tır (Termoking -18°C / +13°C)',
    'İzotermik Ýapyk Kamyon',
    'Frigorifik Panelvan (Şäher Içi)',
    'Ýapyk Tenteli Kamyon',
    'Konteýner / Ref Konteýner (Eksport)'
  ],
  incidentTypes: [
    'Sowuk Zynjyryň Bozulmagy / Temperatura Gyşarmasy',
    'Ýükleme & Daşamak Zyýany (Palet Agdarylmagy & Kassa Hasary)',
    'Aşa Çeňňek / Kantar Agram Gapma-Garşylygy (Fire)',
    'Miwäniň Eti Ýumşamagy / Çüýreme & Çişme',
    'Zyýankeş & Möjek Ýokaşmagy (Trips / Gurt / Mikroskopik)',
    'Näsaz Etiketka / Delilnama & Ýol Hatynyň Gabat Gelmezligi',
    'Gaplama, Arassaçylyk we Sanitar Standart Gyşarmasy',
    'Standartdan Daşary Kalibrleme & Boýlama Ýalňyşlygy'
  ],
  operators: [],
  orchards: [
    'Gök Bulut (Meyve Bahçesi & Muz Serası)',
    'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
    'Miweli Atyz (Muz Serası & Kaka Badem Plantasyonu)'
  ],
  destinations: [
    'PM · Paýlaýyş nokady',
    'Erem™ (İhracat Numune & Raf Ömrü Laboratuvarı)',
    'Eksport (Daşary Ýurt Satışı)'
  ],
  foremen: [],
  truckPlates: [],
  drivers: [],
  greenhouses: [
    'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
    'Gök Bulut (Meyve Bahçesi & Muz Serası)',
    'Miweli Atyz (Muz Serası & Kaka Badem Plantasyonu)'
  ]
};
