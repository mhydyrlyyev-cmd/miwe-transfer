import React, { useState, useMemo } from 'react';
import { Image as LucideImage, Apple, Banana, Nut, Truck, Warehouse, AlertOctagon, Archive, Clock, BarChart3, ChevronRight, ChevronDown, PlusCircle, Link as LinkIcon, ExternalLink, Globe, Sparkles, ShieldCheck, Factory, Award, CalendarDays, ShoppingBag, Globe2, MessageSquarePlus, Lightbulb, FileBarChart, Smartphone, Snowflake, Info, Building2, Search, AlertTriangle, BookOpen } from 'lucide-react';
import { ModuleKey, AmbarRecord, LojistikRecord, SalesRecord, ReferenceItem } from '../types';
import { AppUser } from '../types/auth';
import { CriticalStockAlertCard } from './dashboard/CriticalStockAlertCard';

interface ModuleCardsProps {
  onSelectModule: (module: ModuleKey, action: 'NEW' | 'EXISTING') => void;
  onOpenSystemView: (view: 'GALLERY' | 'REFERENCES' | 'PENDING' | 'ANALYTICS' | 'MONTHLY_REPORT' | 'FEEDBACK' | 'DIAGNOSTICS' | 'HARVEST_PORTAL' | 'QUALITY_ROADMAP' | 'GUIDE_PORTAL' | 'TRACEABILITY_LEDGER') => void;
  onOpenPwaModal?: () => void;
  onOpenTraceabilityLedger?: () => void;
  onOpenProofModal?: () => void;
  activeView: string;
  pendingCount: number;
  currentUser?: AppUser | null;
  isReadOnlyUser?: boolean;
  ambarRecords?: AmbarRecord[];
  lojistikRecords?: LojistikRecord[];
  salesRecords?: SalesRecord[];
  references?: ReferenceItem[];
}

export const ModuleCards: React.FC<ModuleCardsProps> = ({
  onSelectModule,
  onOpenSystemView,
  onOpenPwaModal,
  onOpenTraceabilityLedger,
  onOpenProofModal,
  activeView,
  pendingCount,
  currentUser,
  isReadOnlyUser = false,
  ambarRecords = [],
  lojistikRecords = [],
  salesRecords = [],
  references = []
}) => {
  const [showStockAlerts, setShowStockAlerts] = useState<boolean>(false);
  const [openMenuModuleKey, setOpenMenuModuleKey] = useState<ModuleKey | null>(null);

  // Quick count for critical stock badge (Cold-Start: only real ambarRecords)
  const criticalStockCount = useMemo(() => {
    if (ambarRecords.length === 0) return 0;
    const threshold = 5000;
    let crit = 0;
    ambarRecords.forEach((a: any) => {
      const kg = a.acceptedWeightKg || 0;
      if (kg < threshold) {
        crit++;
      }
    });
    return crit;
  }, [ambarRecords]);
  const allMasterModules = [
    {
      key: 'FIELD' as ModuleKey,
      title: 'Meyve Kalite Testi / Fruit Quality Test',
      titleTr: 'Meyve Kalite Testi',
      titleEn: 'Fruit Quality Test',
      subtitle: 'Gök Bulut • Şetdaly, Nektarin, Alma',
      description: 'Dinamik numune ekle/sil (+ Add Sample), penetrometre sertlik, brix şeker, nitrat (mg/kg) ve Freeze & Dry kalite sapma yönlendirmesi.',
      icon: Apple,
      accentBg: 'bg-rose-50 text-rose-700 border-rose-200 hover:border-rose-400 group-hover:bg-rose-700 group-hover:text-white',
      badgeColor: 'bg-rose-100 text-rose-900',
      tag: '01 KALİTE / QUALITY'
    },
    {
      key: 'HARVEST' as ModuleKey,
      title: 'Günlük Hasat / Daily Harvest',
      titleTr: 'Günlük Hasat',
      titleEn: 'Daily Harvest',
      subtitle: 'Gök Bulut • Bahçe Hasadı',
      description: 'Bahçe öncelikli, 1./2. Hasat aşaması, fenolojik evre (F-01..F-10), lot no, kantar fişi, tonaj ve parçalı yük (split logistics).',
      icon: CalendarDays,
      accentBg: 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:border-emerald-400 group-hover:bg-emerald-700 group-hover:text-white',
      badgeColor: 'bg-emerald-100 text-emerald-900',
      tag: '02 HASAT'
    },
    {
      key: 'MUZ' as ModuleKey,
      title: 'Muz Kalite Kontrol & MAP / Banana Quality Control',
      titleTr: 'Muz Kalite Kontrol & MAP',
      titleEn: 'Banana Quality Control',
      subtitle: 'Hemsaýa • Grand Nain Cavendish',
      description: 'Şerit rengi (12 hafta), kalibrasyon mm, parmak boyu, 1-7 yeşil hasat skalası, MAP ve KMnO4 absorber şase kontrolü.',
      icon: Banana,
      accentBg: 'bg-amber-50 text-amber-700 border-amber-200 hover:border-amber-400 group-hover:bg-amber-600 group-hover:text-white',
      badgeColor: 'bg-amber-100 text-amber-800',
      tag: '03 MUZ / BANANA'
    },
    {
      key: 'BADEM' as ModuleKey,
      title: 'Badem Testi & Randıman / Almond Quality & Yield',
      titleTr: 'Badem Testi & Randıman',
      titleEn: 'Almond Yield & Quality',
      subtitle: 'Miweli Atyz • Nonpareil & Gabykly',
      description: 'Su kesilme tarihi, ağaç açılma %70+, meyve nem %9-15, kurutma sonrası iç randıman % ve kuru depo yönlendirmesi.',
      icon: Nut,
      accentBg: 'bg-orange-50 text-orange-800 border-orange-200 hover:border-orange-400 group-hover:bg-orange-700 group-hover:text-white',
      badgeColor: 'bg-orange-100 text-orange-900',
      tag: '04 BADEM / ALMOND'
    },
    {
      key: 'LOJISTIK' as ModuleKey,
      title: 'Lojistik & Delilnama / Logistics & Waybill',
      titleTr: 'Lojistik & Delilnama',
      titleEn: 'Logistics & Waybill',
      subtitle: 'Frigorifik Soğuk Zincir / Cold Chain',
      description: 'Araç plakası, sürücü, resmi Delilnama No, palet/kasa sayısı, çıkış ve yol sıcaklığı takibi.',
      icon: Truck,
      accentBg: 'bg-blue-50 text-blue-700 border-blue-200 hover:border-blue-400 group-hover:bg-blue-600 group-hover:text-white',
      badgeColor: 'bg-blue-100 text-blue-800',
      tag: '05 LOJİSTİK / LOGISTICS'
    },
    {
      key: 'AMBAR' as ModuleKey,
      title: 'Ambar Kabul & Soğuk Depo / Warehouse & Cold Storage',
      titleTr: 'Ambar Kabul & Soğuk Depo',
      titleEn: 'Warehouse & Cold Storage',
      subtitle: 'Depo › oda · kabul ve kontrol',
      description: 'Kantar kabul tartımı, fire % hesabı, yapılan işlem (Ön Soğutma, 1-MCP, Ozon), oda ve ürün sıcaklığı/nemi.',
      icon: Warehouse,
      accentBg: 'bg-teal-50 text-teal-800 border-teal-200 hover:border-teal-400 group-hover:bg-teal-700 group-hover:text-white',
      badgeColor: 'bg-teal-100 text-teal-900',
      tag: '06 AMBAR / STORAGE'
    },
    {
      key: 'FREEZE_DRY' as ModuleKey,
      title: 'Freeze & Dry Kurutma / Freeze & Dry Dehydration',
      titleTr: 'Freeze & Dry Kurutma',
      titleEn: 'Freeze & Dry Dehydration',
      subtitle: 'Vakumlu Liyofilizasyon & Kalite Sapma',
      description: 'Kalite sapması veya standart dışı ürünlerin kurutulması, dilimleme, şok dondurma (-40°C) ve vakumlu süblimasyon takibi.',
      icon: Snowflake,
      accentBg: 'bg-purple-50 text-purple-700 border-purple-200 hover:border-purple-400 group-hover:bg-purple-700 group-hover:text-white',
      badgeColor: 'bg-purple-100 text-purple-900',
      tag: '07 FREEZE-DRY'
    },
    {
      key: 'EXPORT_SAMPLE' as ModuleKey,
      title: 'İhracat Numune & Raf Ömrü',
      titleTr: 'İhracat Numune & Raf Ömrü',
      titleEn: 'Export Sample & Shelf Life',
      subtitle: 'Erem™ Daşary Ýurt Çydamlylygy',
      description: 'İhracata giden şahit numunelerin transit sonrası sertlik, brix şeker, su kaybı %, ağırlık kaybı ve raf ömrü testi.',
      icon: Globe2,
      accentBg: 'bg-cyan-50 text-cyan-800 border-cyan-200 hover:border-cyan-400 group-hover:bg-cyan-700 group-hover:text-white',
      badgeColor: 'bg-cyan-100 text-cyan-900',
      tag: '08 EKSPORT / EXPORT'
    },
    {
      key: 'SALES' as ModuleKey,
      title: 'Satış & Sevkiyat Çıkışı / Sales & Outbound Dispatch',
      titleTr: 'Satış & Sevkiyat Çıkışı',
      titleEn: 'Sales & Outbound Dispatch',
      subtitle: 'Ticari Çıkış & Çeşit Dağılımı',
      description: 'Satışa giden yükün zamanı, müşteri, fatura, çeşit/sort kırılımı, kalite sınıfı (görünüş), kg ve kasa çıkış kütüğü.',
      icon: ShoppingBag,
      accentBg: 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:border-indigo-400 group-hover:bg-indigo-700 group-hover:text-white',
      badgeColor: 'bg-indigo-100 text-indigo-900',
      tag: '09 SATIŞ / SALES'
    },
    {
      key: 'INCIDENT' as ModuleKey,
      title: 'Barlag Akty & Uygunsuzluk',
      titleTr: 'Barlag Akty & Uygunsuzluk',
      titleEn: 'Quality Incident & Act',
      subtitle: '5-Why Kök Sebep & Akt Dereje (1-2-3)',
      description: 'Kalite sapması, kasa/palet hasarı tutanağı, Akt derecelendirmesi, hızlı karantina ve önleyici faaliyet (CAPA).',
      icon: AlertOctagon,
      accentBg: 'bg-slate-100 text-slate-800 border-slate-300 hover:border-slate-400 group-hover:bg-slate-800 group-hover:text-white',
      badgeColor: 'bg-slate-200 text-slate-900',
      tag: '10 AKTI / INCIDENT'
    },
    {
      key: 'GALLERY' as any,
      title: 'Saha Galeri & Fotoğraf Arşivi / Field Photo Gallery & Archive',
      titleTr: 'Saha Galeri & Fotoğraf Arşivi',
      titleEn: 'Field Photo Gallery & Archive',
      subtitle: 'Tüm Modüller • Saha & Kalite Fotoğrafları',
      description: 'Hasat, meyve testi, muz, badem, ambar ve barlag akty modüllerinden çekilen tüm fotoğrafların çevrimdışı ve online galerisi.',
      icon: LucideImage,
      accentBg: 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:border-emerald-400 group-hover:bg-emerald-700 group-hover:text-white',
      badgeColor: 'bg-emerald-100 text-emerald-900',
      tag: '11 GALERİ / G'
    }
  ];

  // Filter modules based on user authorization
  const masterModules = allMasterModules.filter(mod => {
    if (!currentUser) return true;
    if (currentUser.role === 'ADMIN') return true;
    if (currentUser.allowedModules?.includes('ALL')) return true;
    return currentUser.allowedModules?.includes(mod.key);
  });

  return (
    <div className="space-y-4">

      {/* SYSTEM NAVIGATION TABS - MODERN GLASS PANEL */}
      <div className="glass-panel rounded-2xl p-2 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:flex md:flex-wrap gap-2 w-full">
          <button
            onClick={() => onOpenSystemView('REFERENCES')}
            className={`flex items-center justify-center sm:justify-start gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeView === 'REFERENCES'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Archive className="w-3.5 h-3.5 text-emerald-600" />
            <span>Kayıtlar</span>
          </button>

          <button
            onClick={() => onOpenSystemView('FEEDBACK')}
            className={`flex items-center justify-center sm:justify-start gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeView === 'FEEDBACK'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-amber-50/60'
            }`}
          >
            <MessageSquarePlus className="w-3.5 h-3.5 text-amber-600" />
            <span>Geri Bildirim</span>
          </button>

          {onOpenProofModal && (
            <button
              onClick={onOpenProofModal}
              className="flex items-center justify-center sm:justify-start gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer bg-white border border-slate-200 text-slate-700 hover:bg-teal-50/60"
              title="Görsel Referans Skalaları, Muz MAP ve Badem Laboratuvar Kanıt Merkezi"
            >
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span> Görsel Standartlar</span>
            </button>
          )}

          {/* Ambar Stok Uyarıları Butonu */}
          <button
            onClick={() => setShowStockAlerts(!showStockAlerts)}
            className={`col-span-2 sm:col-span-1 flex items-center justify-center sm:justify-start gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              showStockAlerts
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-amber-50/60'
            }`}
            title="Ambar kritik stok uyarıları ve güvenlik eşiği panelini aç / kapat"
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${showStockAlerts ? 'text-white' : 'text-amber-600'}`} />
            <span>Stok Uyarıları</span>
            {criticalStockCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] tabular-nums font-bold ${
                showStockAlerts ? 'bg-white text-amber-800' : 'bg-rose-500 text-white animate-pulse'
              }`}>
                {criticalStockCount}
              </span>
            )}
          </button>
        </div>

        <span className="text-[11px] tabular-nums font-semibold text-slate-500 pr-2 hidden md:inline shrink-0">
          {masterModules.length} Modül
        </span>
      </div>

      {/* AMBAR KRİTİK STOK UYARILARI AÇILIR PANELİ (ORTA PANEL) */}
      {showStockAlerts && (
        <div className="w-full transition-all">
          <CriticalStockAlertCard
            ambarRecords={ambarRecords}
            lojistikRecords={lojistikRecords}
            salesRecords={salesRecords}
            references={references}
            onSelectModule={onSelectModule}
            onOpenAnalytics={() => onOpenSystemView('ANALYTICS')}
            currentUserId={currentUser?.id}
          />
        </div>
      )}

      {/* 10 MASTER MODULE CARDS - COMPACT & ERGONOMIC */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h2 className="text-xs sm:text-sm font-bold text-slate-600 flex items-center gap-2">
            <span>Entegre Kalite &amp; İzlenebilirlik Modülleri</span>
            <span className="h-px w-10 bg-slate-200 hidden sm:inline"></span>
          </h2>
          <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">Modül seçerek yeni kayıt oluşturun veya mevcut referansları inceleyin</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 w-full">
          {masterModules.map((mod) => {
            const Icon = mod.icon;
            const isCurrentActive = activeView === mod.key;

            return (
              <div
                key={mod.key}
                title={mod.description}
                className={`group rounded-2xl px-3.5 py-2.5 transition-all flex items-center justify-between gap-2.5 relative min-w-0 w-full bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-emerald-300 hover:shadow-sm ${
                  isCurrentActive ? 'border-emerald-500 ring-2 ring-emerald-500/30' : ''
                }`}
              >
                {/* Sol: İkon + Modül Adı */}
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center border shrink-0 transition-all shadow-2xs ${mod.accentBg}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 text-xs sm:text-sm group-hover:text-emerald-600 transition-colors leading-snug truncate">
                    {mod.titleTr}
                  </h3>
                </div>

                {/* Sağ: "+" düğmesi ve açılır işlem menüsü */}
                <div className="relative shrink-0">
                  <button
                    type="button"
                    aria-label={isReadOnlyUser ? `${mod.titleTr} İncele` : `${mod.titleTr} Kayıt Ekle`}
                    onClick={() => {
                      if (isReadOnlyUser) {
                        if (mod.key === ('GALLERY' as any)) {
                          onOpenSystemView('GALLERY');
                        } else {
                          onSelectModule(mod.key, 'EXISTING');
                        }
                      } else {
                        setOpenMenuModuleKey(openMenuModuleKey === mod.key ? null : mod.key);
                      }
                    }}
                    className={`w-8 h-8 flex items-center justify-center ${
                      isReadOnlyUser ? 'bg-slate-700 hover:bg-slate-800' : 'bg-emerald-600 hover:bg-emerald-700'
                    } text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer`}
                  >
                    {isReadOnlyUser ? <BookOpen className="w-3.5 h-3.5" /> : <PlusCircle className="w-4 h-4" />}
                  </button>

                  {!isReadOnlyUser && openMenuModuleKey === mod.key && (
                    <div className="absolute right-0 bottom-full mb-1.5 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl p-1.5 z-50 space-y-1 text-xs text-slate-800 dark:text-slate-100 animate-in fade-in duration-150">
                      <button
                        type="button"
                        onClick={() => {
                          setOpenMenuModuleKey(null);
                          if (mod.key === ('GALLERY' as any)) {
                            onOpenSystemView('GALLERY');
                          } else {
                            onSelectModule(mod.key, 'NEW');
                          }
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-2 cursor-pointer transition"
                      >
                        <PlusCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Yeni Kayıt Oluştur</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOpenMenuModuleKey(null);
                          if (mod.key === ('GALLERY' as any)) {
                            onOpenSystemView('GALLERY');
                          } else {
                            onSelectModule(mod.key, 'EXISTING');
                          }
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold flex items-center gap-2 cursor-pointer transition"
                      >
                        <LinkIcon className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span>Mevcut Referans Seç</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
