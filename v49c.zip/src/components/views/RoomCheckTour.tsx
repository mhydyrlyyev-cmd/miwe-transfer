import React, { useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';
import { Button, PageHeader } from '../ui';
import type { LocationProfile } from '../../services/locationProfiles';
import {
  roomsOf, roomCode, roomType, setRange, fmtC, readingStatus, calibrationGap, saveRoomCheckRound,
  ROOM_STATE_LABEL, type RoomCheckEntry, type RoomState, type StoredLot,
} from '../../services/depots';

/**
 * v49c — Oda kontrol turu (Excel "soğuk depo oda içi ve set kontrolü" tablosunun yerine).
 * Bir depodaki tüm odalar tek ekranda: monitör, cihaz, meyve iç, nem. Set aralığı profilden gelir,
 * değer aralık dışındaysa kutu sarı/kırmızı olur; monitör–cihaz farkı ≥ 2 °C ise kalibrasyon uyarısı.
 */
interface Props {
  depot: LocationProfile;
  lots: StoredLot[];
  currentUserName: string;
  isReadOnly?: boolean;
  onClose: () => void;
}

type Row = { monitor: string; device: string; fruit: string; rh: string; o2: string; co2: string; setMin: string; setMax: string; state: RoomState; mcp: '' | 'YES' | 'NO'; note: string; open: boolean };
const toNum = (v: string) => { const t = v.trim().replace(',', '.'); if (!t) return undefined; const n = Number(t); return Number.isFinite(n) ? n : NaN; };
const cell = 'h-11 w-full rounded-lg border text-center text-sm tabular-nums bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600';

export default function RoomCheckTour({ depot, lots, currentUserName, isReadOnly, onClose }: Props) {
  const rooms = useMemo(() => roomsOf(depot), [depot]);
  const buildings = useMemo(() => [...new Set(rooms.map(r => String(r.fields?.building || '')).filter(Boolean))], [rooms]);
  const [bld, setBld] = useState<string>('');
  const [rows, setRows] = useState<Record<string, Row>>(() => Object.fromEntries(rooms.map(r => {
    const { min, max } = setRange(r);
    return [r.id, { monitor: '', device: '', fruit: '', rh: '', o2: '', co2: '', setMin: min === undefined ? '' : String(min), setMax: max === undefined ? '' : String(max), state: '' as RoomState, mcp: '' as const, note: '', open: false }];
  })));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const content = (r: LocationProfile) => {
    const inRoom = lots.filter(l => !l.exited && l.room?.id === r.id);
    if (!inRoom.length) return 'Boş';
    const names = [...new Set(inRoom.map(l => [l.ref?.product || l.a.product, l.ref?.variety || l.a.variety].filter(Boolean).join(' ')))].filter(Boolean);
    return names.slice(0, 3).join(' · ') + (names.length > 3 ? ` +${names.length - 3}` : '');
  };
  const set = (id: string, patch: Partial<Row>) => setRows(p => ({ ...p, [id]: { ...p[id], ...patch } }));
  const filled = rooms.filter(r => rows[r.id] && (rows[r.id].monitor || rows[r.id].device)).length;
  const visible = rooms.filter(r => !bld || String(r.fields?.building || '') === bld);

  const tone = (r: LocationProfile, raw: string) => {
    const v = toNum(raw);
    if (v === undefined) return 'border-slate-300 dark:border-slate-700';
    if (Number.isNaN(v)) return 'border-rose-500 bg-rose-50';
    const row = rows[r.id];
    const tmp = { ...r, fields: { ...r.fields, setMinC: row.setMin, setMaxC: row.setMax } } as LocationProfile;
    const st = readingStatus(tmp, v);
    return st === 'bad' ? 'border-rose-400 bg-rose-50 text-rose-900 font-bold' : st === 'warn' ? 'border-amber-400 bg-amber-50 text-amber-900 font-semibold' : 'border-emerald-400';
  };

  const save = async () => {
    setError(null);
    const entries: RoomCheckEntry[] = [];
    for (const r of rooms) {
      const x = rows[r.id];
      const vals = { monitorC: toNum(x.monitor), deviceC: toNum(x.device), fruitC: toNum(x.fruit), rhPercent: toNum(x.rh), o2Percent: toNum(x.o2), co2Percent: toNum(x.co2), setMinC: toNum(x.setMin), setMaxC: toNum(x.setMax) };
      if (Object.values(vals).some(v => Number.isNaN(v))) { setError(`${roomCode(r)}: değerler sayı olmalı (örn. 1,5).`); return; }
      const measured = vals.monitorC !== undefined || vals.deviceC !== undefined || vals.fruitC !== undefined || vals.rhPercent !== undefined || x.state || x.note.trim();
      if (!measured) continue;
      entries.push({ roomId: r.id, roomName: r.name, ...vals, state: x.state, mcp: x.mcp, content: content(r), note: x.note.trim() || undefined } as RoomCheckEntry);
    }
    if (!entries.length) { setError('En az bir odaya ölçüm girin.'); return; }
    setSaving(true);
    await saveRoomCheckRound({ warehouse: depot.name, at: new Date().toISOString(), by: currentUserName || '—', entries });
    setSaving(false);
    setDone(true);
  };

  if (done) {
    return (
      <div className="max-w-3xl mx-auto px-3 py-8 text-center space-y-4">
        <div className="text-lg font-bold text-slate-900 dark:text-white">Tur kaydedildi</div>
        <p className="text-sm text-slate-600 dark:text-slate-400">{depot.name} · {filled} oda. Set dışı odalar ana sayfada "Bugün bakılacaklar"a düştü.</p>
        <Button variant="primary" onClick={onClose}>Depoya dön</Button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3 pb-32">
      <PageHeader onBack={onClose} title="Oda kontrol turu" subtitle={`${depot.name} · ${new Date().toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}`} />
      <div className="flex items-center gap-2">
        <div className="flex-1 h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-indigo-600" style={{ width: `${rooms.length ? (filled / rooms.length) * 100 : 0}%` }} /></div>
        <span className="text-xs font-semibold tabular-nums text-slate-700 dark:text-slate-300">{filled} / {rooms.length}</span>
      </div>
      {buildings.length > 1 && (
        <div className="flex gap-1.5 flex-wrap">
          {['', ...buildings].map(b => (
            <button key={b || 'all'} type="button" onClick={() => setBld(b)}
              className={`px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${bld === b ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{b || 'Tümü'}</button>
          ))}
        </div>
      )}

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3">
        <div className="grid grid-cols-[minmax(0,1fr)_50px_50px_50px_50px_24px] gap-1.5 text-[10px] font-semibold text-slate-500 py-2 border-b border-slate-100 dark:border-slate-800">
          <span>Oda · set °C</span><span className="text-center">Monitör</span><span className="text-center">Cihaz</span><span className="text-center">Meyve</span><span className="text-center">Nem %</span><span />
        </div>
        {visible.map(r => {
          const x = rows[r.id];
          const gap = calibrationGap({ monitorC: toNum(x.monitor) as number | undefined, deviceC: toNum(x.device) as number | undefined });
          return (
            <div key={r.id} className="py-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
              <div className="grid grid-cols-[minmax(0,1fr)_50px_50px_50px_50px_24px] gap-1.5 items-center">
                <div className="min-w-0">
                  <div className="text-sm font-bold text-slate-900 dark:text-white truncate">{roomCode(r)}</div>
                  <div className="text-[11px] text-slate-500 tabular-nums truncate">{x.setMin || x.setMax ? `set ${x.setMin || '?'} – ${x.setMax || '?'} °C` : 'set yok'}</div>
                  <div className="text-[11px] text-slate-500 truncate">{content(r)}</div>
                </div>
                <input aria-label={`${roomCode(r)} monitör °C`} inputMode="decimal" disabled={isReadOnly} value={x.monitor} onChange={e => set(r.id, { monitor: e.target.value })} className={`${cell} ${tone(r, x.monitor)}`} />
                <input aria-label={`${roomCode(r)} cihaz °C`} inputMode="decimal" disabled={isReadOnly} value={x.device} onChange={e => set(r.id, { device: e.target.value })} className={`${cell} border-slate-300 dark:border-slate-700`} />
                <input aria-label={`${roomCode(r)} meyve iç °C`} inputMode="decimal" disabled={isReadOnly} value={x.fruit} onChange={e => set(r.id, { fruit: e.target.value })} className={`${cell} border-slate-300 dark:border-slate-700`} />
                <input aria-label={`${roomCode(r)} nem %`} inputMode="decimal" disabled={isReadOnly} value={x.rh} onChange={e => set(r.id, { rh: e.target.value })} className={`${cell} border-slate-300 dark:border-slate-700`} placeholder="yok" />
                <button type="button" aria-label="Diğer alanlar" onClick={() => set(r.id, { open: !x.open })} className="h-11 flex items-center justify-center text-slate-500 cursor-pointer">{x.open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}</button>
              </div>
              {gap > 0 && <div className="mt-1 text-[11px] font-semibold text-amber-800 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />Monitör–cihaz farkı {fmtC(gap)} °C · sensör kalibrasyonu önerilir</div>}
              {x.open && (
                <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <label className="text-[11px] text-slate-600">Set alt °C<input inputMode="decimal" value={x.setMin} onChange={e => set(r.id, { setMin: e.target.value })} className={`${cell} border-slate-300 mt-0.5`} /></label>
                  <label className="text-[11px] text-slate-600">Set üst °C<input inputMode="decimal" value={x.setMax} onChange={e => set(r.id, { setMax: e.target.value })} className={`${cell} border-slate-300 mt-0.5`} /></label>
                  {roomType(r) === 'Kontrollü atmosfer' && <>
                    <label className="text-[11px] text-slate-600">O₂ %<input inputMode="decimal" value={x.o2} onChange={e => set(r.id, { o2: e.target.value })} className={`${cell} border-slate-300 mt-0.5`} /></label>
                    <label className="text-[11px] text-slate-600">CO₂ %<input inputMode="decimal" value={x.co2} onChange={e => set(r.id, { co2: e.target.value })} className={`${cell} border-slate-300 mt-0.5`} /></label>
                  </>}
                  <div className="col-span-2 flex flex-wrap gap-1.5 items-center">
                    <span className="text-[11px] text-slate-600 mr-1">Durum</span>
                    {(Object.keys(ROOM_STATE_LABEL) as Exclude<RoomState, ''>[]).map(k => (
                      <button key={k} type="button" onClick={() => set(r.id, { state: x.state === k ? '' : k })}
                        className={`px-2.5 min-h-[32px] rounded-full text-xs border cursor-pointer ${x.state === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700'}`}>{ROOM_STATE_LABEL[k]}</button>
                    ))}
                  </div>
                  <div className="col-span-2 flex flex-wrap gap-1.5 items-center">
                    <span className="text-[11px] text-slate-600 mr-1">1-MCP</span>
                    {([['YES', 'Yapıldı'], ['NO', 'Yapılmadı']] as const).map(([k, l]) => (
                      <button key={k} type="button" onClick={() => set(r.id, { mcp: x.mcp === k ? '' : k })}
                        className={`px-2.5 min-h-[32px] rounded-full text-xs border cursor-pointer ${x.mcp === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700'}`}>{l}</button>
                    ))}
                  </div>
                  <input placeholder="Not (koku, kapı, buzlanma…)" value={x.note} onChange={e => set(r.id, { note: e.target.value })} className="col-span-2 sm:col-span-4 min-h-[44px] rounded-lg border border-slate-300 px-3 text-sm" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-800">{error}</div>}
      <div className="fixed left-0 right-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] sm:bottom-4 px-3 z-30">
        <div className="max-w-3xl mx-auto">
          <Button variant="primary" fullWidth size="md" disabled={saving || isReadOnly} onClick={save}>{saving ? 'Kaydediliyor…' : `Turu kaydet · ${filled} oda`}</Button>
        </div>
      </div>
    </div>
  );
}
