import React, { useState } from 'react';
import { 
  MessageSquarePlus, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Filter, 
  Search, 
  Trash2, 
  Lightbulb, 
  Wrench, 
  HelpCircle, 
  ShieldAlert,
  ChevronDown,
  Info,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  UserX,
  FileText,
  ShieldCheck
} from 'lucide-react';
import { FeedbackRecord, FeedbackType, FeedbackPriority, FeedbackStatus } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { isAdminAuthenticated } from '../../utils/authService';

interface FeedbackViewProps {
  feedbacks: FeedbackRecord[];
  onSaveFeedback: (record: FeedbackRecord) => void;
  onUpdateFeedbackStatus: (id: string, status: FeedbackStatus, note?: string) => void;
  onDeleteFeedback: (id: string) => void;
}

const FEEDBACK_TYPE_CONFIG: Record<FeedbackType, { label: string; labelEn: string; icon: React.ReactNode; color: string; badge: string }> = {
  SAHA_YETERSIZLIGI: {
    label: 'Saha Yetersizliği & Ekipman Eksikliği',
    labelEn: 'Field Inadequacy / Missing Equipment',
    icon: <Wrench className="w-4 h-4 text-orange-500" />,
    color: 'text-orange-700 bg-orange-50 border-orange-200',
    badge: 'bg-orange-100 text-orange-800 border-orange-300'
  },
  TUTANAK_TAKIBI: {
    label: 'Tutanak / Akt Takipsizliği Bildirimi',
    labelEn: 'Incident Report Follow-up',
    icon: <FileText className="w-4 h-4 text-rose-500" />,
    color: 'text-rose-700 bg-rose-50 border-rose-200',
    badge: 'bg-rose-100 text-rose-800 border-rose-300'
  },
  KALITE_IYILESTIRME: {
    label: 'Kalite & Metot İyileştirme',
    labelEn: 'Quality & Process Improvement',
    icon: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
    color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-300'
  },
  TAVSIYE: {
    label: 'Tavsiye & Pratik Öneri',
    labelEn: 'Recommendation & Suggestion',
    icon: <Lightbulb className="w-4 h-4 text-amber-500" />,
    color: 'text-amber-700 bg-amber-50 border-amber-200',
    badge: 'bg-amber-100 text-amber-800 border-amber-300'
  },
  SIKAYET: {
    label: 'Süreç / Yönetim Şikayeti',
    labelEn: 'Process / Management Grievance',
    icon: <ShieldAlert className="w-4 h-4 text-red-500" />,
    color: 'text-red-700 bg-red-50 border-red-200',
    badge: 'bg-red-100 text-red-800 border-red-300'
  },
  ARIZA: {
    label: 'Makine / Tesis Arızası',
    labelEn: 'Machine Breakdown',
    icon: <Wrench className="w-4 h-4 text-slate-500" />,
    color: 'text-slate-700 bg-slate-50 border-slate-200',
    badge: 'bg-slate-100 text-slate-800 border-slate-300'
  },
  IYILESTIRME: {
    label: 'Genel İyileştirme',
    labelEn: 'General Improvement',
    icon: <CheckCircle2 className="w-4 h-4 text-teal-500" />,
    color: 'text-teal-700 bg-teal-50 border-teal-200',
    badge: 'bg-teal-100 text-teal-800 border-teal-300'
  },
  DIGER: {
    label: 'Diğer Bildirim',
    labelEn: 'Other Notification',
    icon: <HelpCircle className="w-4 h-4 text-slate-500" />,
    color: 'text-slate-700 bg-slate-50 border-slate-200',
    badge: 'bg-slate-100 text-slate-800 border-slate-300'
  }
};

export const FeedbackView: React.FC<FeedbackViewProps> = ({
  feedbacks,
  onSaveFeedback,
  onUpdateFeedbackStatus,
  onDeleteFeedback
}) => {
  const [showForm, setShowForm] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // GİZLİLİK VE YÖNETİCİ GÖRÜNÜRLÜK KİLİDİ (Madde 3)
  // Varsayılan olarak liste normal kullanıcılardan gizlidir.
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [adminPin, setAdminPin] = useState('');
  const [pinError, setPinError] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);

  // Form State
  const [type, setType] = useState<FeedbackType>('SAHA_YETERSIZLIGI');
  const [department, setDepartment] = useState('');
  const [author, setAuthor] = useState(AUTOCOMPLETE_LISTS.operators[0] || '');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [contactInfo, setContactInfo] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<FeedbackPriority>('NORMAL');
  const [isSubmittedNotice, setIsSubmittedNotice] = useState(false);

  // Resolution modal state
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState('');

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Güvenlik: sabit PIN kaldırıldı — liste yalnızca oturum açmış yöneticiye açılır
    if (isAdminAuthenticated()) {
      setIsAdminUnlocked(true);
      setShowPinModal(false);
      setPinError(false);
      setAdminPin('');
    } else {
      setPinError(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Lütfen bir konu başlığı giriniz / Please enter a title.');
      return;
    }
    if (!description.trim()) {
      alert('Lütfen açıklama / detay alanını yazınız.');
      return;
    }

    const newRecord: FeedbackRecord = {
      id: `fb-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type,
      department,
      author: isAnonymous ? 'İsimsiz Operatör (Anonymous)' : (author.trim() || ''),
      isAnonymous,
      contactInfo: isAnonymous ? '' : contactInfo.trim(),
      title: title.trim(),
      description: description.trim(),
      priority,
      status: 'OPEN'
    };

    onSaveFeedback(newRecord);
    setTitle('');
    setDescription('');
    setContactInfo('');
    setIsSubmittedNotice(true);
    setTimeout(() => setIsSubmittedNotice(false), 5000);
  };

  const filteredFeedbacks = feedbacks.filter(f => {
    const matchesSearch = 
      f.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'ALL' || f.type === typeFilter;
    const matchesStatus = statusFilter === 'ALL' || f.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-emerald-700 hover:bg-emerald-800 rounded-2xl p-6 text-white shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 bg-amber-500/20 rounded-xl border border-amber-400/30 text-amber-300">
              <MessageSquarePlus className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Dilek, Tavsiye & Şikayet Kutusu / Feedback & Suggestions
              </h1>
              <p className="text-xs text-slate-300">
                Saha çalışanları ve operatörler için gizli öneri, yetersizlik ve akt takibi bildirim kanalı
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Admin Role Toggle */}
          {!isAdminUnlocked ? (
            <button
              onClick={() => setShowPinModal(true)}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition"
              title="Sistem Yöneticisi & Kalite Müdürü İnceleme Girişi (Varsayılan PIN: 1234)"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Yetkili Girişi / Admin</span>
            </button>
          ) : (
            <button
              onClick={() => setIsAdminUnlocked(false)}
              className="px-3.5 py-2 bg-emerald-950 text-emerald-300 rounded-xl text-xs font-bold border border-emerald-700 flex items-center gap-1.5"
              title="Yetkili Görünümünü Kilitle"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Yetkili Açık (Kilitle)</span>
            </button>
          )}

          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition shadow-sm"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>{showForm ? 'Formu Gizle' : '+ Yeni Bildirim Yaz'}</span>
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {isSubmittedNotice && (
        <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-4 text-xs text-emerald-950 flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
          <div>
            <h4 className="font-bold text-sm"> Bildiriminiz Başarıyla İletildi!</h4>
            <p className="text-emerald-800 text-[11px] mt-0.5">
              Bildiriminiz şifrelenmiş olarak Kalite Güvence ve Yönetim kuruluna iletilmiştir. {isAnonymous ? 'Kimlik bilgileriniz tamamen gizli tutulmuştur.' : ''}
            </p>
          </div>
        </div>
      )}

      {/* Confidentiality Notice */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-700 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-slate-900"> Gizlilik ve Güvenlik Güvencesi / Confidentiality Protocol</p>
          <p className="text-slate-600 leading-relaxed text-[11px]">
            Sahada yaşadığınız ekipman yetersizlikleri, ambalaj problemleri veya tutulan tutanak/aktların takipsiz kalması gibi durumları doğrudan buradan bildirebilirsiniz. "İsimsiz / Gizli Bildirim" seçeneği işaretlendiğinde adınız ve iletişim bilgileriniz sisteme kaydedilmez ve bildirimler yalnızca Kalite Müdürü yetkisiyle incelenebilir.
          </p>
        </div>
      </div>

      {/* New Feedback Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              Yeni Tavsiye / Şikayet / Yetersizlik Bildirimi
            </h2>
            <span className="text-[11px] text-slate-500 font-medium">
              * İşaretli alanlar zorunludur
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* Bildirim Kategorisi (Madde 3) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Kategori / Bildirim Türü *
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as FeedbackType)}
                className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
              >
                <option value="SAHA_YETERSIZLIGI"> Saha Yetersizliği & Ekipman Eksikliği</option>
                <option value="TUTANAK_TAKIBI"> Tutanak / Akt Takipsizliği</option>
                <option value="KALITE_IYILESTIRME"> Kalite & Süreç İyileştirme</option>
                <option value="TAVSIYE"> Pratik Tavsiye & Öneri</option>
                <option value="SIKAYET"> Süreç / Yönetim Şikayeti</option>
                <option value="ARIZA"> Makine / Tesis Arızası</option>
                <option value="DIGER"> Diğer / Genel Bildirim</option>
              </select>
            </div>

            {/* İlgili Bölüm / Tesis */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                İlgili Bölüm / Departman *
              </label>
              <input
                type="text"
                list="departments-list"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="Örn: Saha Meyve, Ambar, Muz Serası vb."
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
              <datalist id="departments-list">
                <option value="Saha Meyve Bahçesi (Gök Bulut)" />
                <option value="Sera / Muz Toplumy (Hemsaýa)" />
                <option value="Badem Fabrikası & Bahçesi (Miweli Atyz)" />
                <option value="Freeze-Dry Liyofilizasyon Tesisi (Erem)" />
                <option value="Depo" />
                <option value="Lojistik & Frigorifik Taşıma" />
                <option value="İhracat & Paketleme Hattı" />
                <option value="Tüm Tesis / Genel İdare" />
              </datalist>
            </div>

            {/* Önem Derecesi */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Önem / Aciliyet / Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as FeedbackPriority)}
                className="w-full text-xs font-semibold bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
              >
                <option value="DUSUK">Düşük (İleriye dönük planlama)</option>
                <option value="NORMAL">Normal (Standart takip)</option>
                <option value="YUKSEK">Yüksek (Hızlı çözüm gerekir)</option>
                <option value="ACIL"> Acil (Üretim/Kalite riski)</option>
              </select>
            </div>

          </div>

          {/* GİZLİ / ANONİM GÖNDER SEÇENEĞİ (Madde 3) */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 text-amber-600 rounded border-amber-300 focus:ring-amber-500"
                />
                <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                  <UserX className="w-4 h-4 text-amber-700" />
                  <span>İsimsiz / Gizli Bildirim (Anonymous Submission)</span>
                </span>
              </label>
              <span className="text-[10px] text-amber-800 font-semibold bg-amber-200/60 px-2 py-0.5 rounded-full">
                {isAnonymous ? '🔒 Kimliğim Saklı' : 'Açık Kimlik'}
              </span>
            </div>

            {!isAnonymous ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-amber-200/60">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Bildiren Kişi (Ad Soyad)
                  </label>
                  <input
                    type="text"
                    list="feedback-operators"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="Adınızı giriniz veya seçiniz"
                    className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <datalist id="feedback-operators">
                    {AUTOCOMPLETE_LISTS.operators.map(op => (
                      <option key={op} value={op} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    İletişim (Telefon / Telsiz)
                  </label>
                  <input
                    type="text"
                    value={contactInfo}
                    onChange={(e) => setContactInfo(e.target.value)}
                    placeholder="Örn: +993 65 xx xx xx"
                    className="w-full text-xs font-medium bg-white border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>
              </div>
            ) : (
              <p className="text-[11px] text-amber-900 italic pt-1 border-t border-amber-200/60">
                 İsimsiz bildirim seçildi. Sistemde adınız veya telefon bilginiz kaydedilmeyecek, doğrudan anonim olarak aktarılacaktır.
              </p>
            )}
          </div>

          {/* Konu Başlığı */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Konu Başlığı / Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Kısa ve net bir özet başlık (Örn: Parsel 4 kantar fişi takipsizliği veya Delikli kasa eksikliği)"
             
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          {/* Açıklama */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Açıklama / Detay & Çözüm Öneriniz (Description & Details) *
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              placeholder="Karşılaştığınız eksikliği, takipsiz kalan tutanağı veya operasyonu hızlandıracak önerinizi detaylarıyla yazınız..."
             
              className="w-full text-xs font-normal bg-white border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-amber-500 focus:outline-none leading-relaxed"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setTitle('');
                setDescription('');
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
            >
              Temizle
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition shadow-md"
            >
              <Send className="w-4 h-4 text-amber-400" />
              <span>{isAnonymous ? 'Gizli Olarak Gönder' : 'Bildirimi Kaydet & Gönder'}</span>
            </button>
          </div>
        </form>
      )}

      {/* ADMIN YÖNETİCİ PANELİ KİLİT KORUMASI (Madde 3) */}
      {!isAdminUnlocked ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6 text-slate-600" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">
            Kayıtlı Bildirimler Kalite Müdürlüğü Koruması Altındadır
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
            Çalışanların dilek, tavsiye ve şikayetlerinin gizliliğini korumak amacıyla gelen bildirimler genel arayüzde yayınlanmaz. Yalnızca yetkili yöneticiler şifre ile giriş yaparak inceleyebilir.
          </p>
          <button
            onClick={() => setShowPinModal(true)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-sm inline-flex items-center gap-2"
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>Yönetici / Kalite Müdürü Girişi Yap</span>
          </button>
        </div>
      ) : (
        /* Unlocked Admin Panel */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <h3 className="text-xs font-bold text-slate-800">
                Kalite Müdürü İnceleme Paneli ({filteredFeedbacks.length} Bildirim)
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Search */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Ara..."
                  className="text-xs pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 w-40 md:w-52"
                />
              </div>

              {/* Type filter */}
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="text-xs font-semibold py-1.5 px-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                <option value="ALL">Tüm Kategoriler</option>
                <option value="SAHA_YETERSIZLIGI">Saha Yetersizliği</option>
                <option value="TUTANAK_TAKIBI">Tutanak Takibi</option>
                <option value="KALITE_IYILESTIRME">Kalite İyileştirme</option>
                <option value="TAVSIYE">Tavsiyeler</option>
                <option value="SIKAYET">Şikayetler</option>
              </select>

              {/* Status filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-xs font-semibold py-1.5 px-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                <option value="ALL">Tüm Durumlar</option>
                <option value="OPEN">Açık / Yeni</option>
                <option value="IN_PROGRESS">İnceleniyor</option>
                <option value="RESOLVED">Çözüldü</option>
              </select>
            </div>
          </div>

          {/* Feedbacks List */}
          <div className="divide-y divide-slate-100">
            {filteredFeedbacks.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-xs">
                Kayıtlı bildirim veya tavsiye bulunamadı.
              </div>
            ) : (
              filteredFeedbacks.map((item) => {
                const typeCfg = FEEDBACK_TYPE_CONFIG[item.type] || FEEDBACK_TYPE_CONFIG.DIGER;
                return (
                  <div key={item.id} className="p-4 hover:bg-slate-50/80 transition flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${typeCfg.badge}`}>
                          {typeCfg.icon}
                          <span>{typeCfg.label}</span>
                        </span>

                        <span className="text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {item.department}
                        </span>

                        {item.isAnonymous && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                            <UserX className="w-3 h-3" />
                            <span>İsimsiz / Gizli</span>
                          </span>
                        )}

                        {item.priority === 'ACIL' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-600 text-white animate-pulse">
                            ACİL
                          </span>
                        )}

                        <span className="text-[10px] text-slate-400 tabular-nums">
                          {new Date(item.timestamp).toLocaleDateString('tr-TR')} {new Date(item.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <h4 className="text-sm font-bold text-slate-900">
                        {item.title}
                      </h4>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {item.description}
                      </p>

                      <div className="text-[11px] text-slate-500 font-medium">
                        Bildiren: <strong className="text-slate-800">{item.isAnonymous ? '🔒 Anonim Operatör' : item.author}</strong>
                        {!item.isAnonymous && item.contactInfo && <span> ({item.contactInfo})</span>}
                      </div>

                      {item.resolutionNote && (
                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-xs text-emerald-900 mt-2">
                          <div className="font-bold flex items-center gap-1 text-emerald-950">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Uygulanan Yönetim Aksiyonu / Çözüm:</span>
                          </div>
                          <p className="text-[11px] text-emerald-800 mt-0.5">{item.resolutionNote}</p>
                        </div>
                      )}
                    </div>

                    {/* Actions & Status badge */}
                    <div className="flex md:flex-col items-center md:items-end justify-between gap-2 shrink-0">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        item.status === 'RESOLVED'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : item.status === 'IN_PROGRESS'
                          ? 'bg-blue-100 text-blue-800 border border-blue-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}>
                        {item.status === 'RESOLVED' ? '✓ Çözümlendi' : item.status === 'IN_PROGRESS' ? '⏳ İnceleniyor' : '● Açık / Yeni'}
                      </span>

                      <div className="flex items-center gap-1.5 mt-1">
                        {item.status !== 'RESOLVED' && (
                          <button
                            onClick={() => {
                              setResolvingId(item.id);
                              setResolutionNote(item.resolutionNote || '');
                            }}
                            className="px-2.5 py-1 text-[11px] font-bold text-slate-700 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 rounded-lg border border-slate-200 transition flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Çözümle</span>
                          </button>
                        )}

                        <button
                          onClick={() => onDeleteFeedback(item.id)}
                          className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-slate-200 transition"
                          title="Bildirimi Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Admin PIN Login Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <form onSubmit={handleAdminLogin} className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-800">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Yetkili Girişi</h3>
                <p className="text-[11px] text-slate-500">Kalite Müdürü / Yönetici Paneli</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Yönetici PIN Kodu (Varsayılan: 1234)
              </label>
              <input
                type="password"
                value={adminPin}
                onChange={(e) => {
                  setAdminPin(e.target.value);
                  setPinError(false);
                }}
                placeholder="PIN giriniz..."
                autoFocus
                className="w-full text-center text-sm tabular-nums bg-slate-50 border border-slate-300 rounded-xl py-2.5 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
              {pinError && (
                <p className="text-[11px] text-red-600 mt-1 font-semibold">
                  Hatalı PIN! Lütfen 1234 veya MIWE giriniz.
                </p>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowPinModal(false);
                  setPinError(false);
                  setAdminPin('');
                }}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-xl"
              >
                İptal
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-sm"
              >
                Giriş Yap
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Resolution Modal */}
      {resolvingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Bildirimi Çözümle & Aksiyon Notu Ekle</span>
            </h3>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Alınan Aksiyon / Çözüm Detayı
              </label>
              <textarea
                value={resolutionNote}
                onChange={(e) => setResolutionNote(e.target.value)}
                rows={3}
                placeholder="Örn: Saha şefi ile görüşüldü, eksik kasa temin edildi..."
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl p-2.5 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setResolvingId(null)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Vazgeç
              </button>
              <button
                onClick={() => {
                  onUpdateFeedbackStatus(resolvingId, 'RESOLVED', resolutionNote);
                  setResolvingId(null);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-sm flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Çözüldü Olarak Kaydet</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
