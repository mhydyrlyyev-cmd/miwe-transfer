import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  Search, 
  HelpCircle, 
  ShieldCheck, 
  MapPin, 
  Sprout, 
  Banana, 
  Nut, 
  Snowflake, 
  FlaskConical, 
  Truck, 
  Warehouse, 
  AlertOctagon, 
  ChevronDown, 
  ChevronUp, 
  Lightbulb, 
  Info,
  ArrowLeft,
  BookMarked,
  Layers,
  FileSpreadsheet,
  Camera,
  Calendar,
  CheckCircle2,
  ExternalLink,
  Building2,
  ShoppingBag
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

interface GuidePortalProps {
  onBackToDashboard: () => void;
}

export type GuideDepartmentCategory = 
  | 'ALL' 
  | 'GENEL_REHBER'
  | 'HASAT_SAHA' 
  | 'MUZ_HEMSAYA' 
  | 'BADEM_MIWELI' 
  | 'AMBAR_DATLY' 
  | 'FREEZEDRY_EREM' 
  | 'LOJISTIK' 
  | 'LAB_MRL' 
  | 'KALITE_BARLAG';

export const GuidePortal: React.FC<GuidePortalProps> = ({ onBackToDashboard }) => {
  const [searchTerm, setSearchInput] = useState('');
  const [activeCategory, setActiveCategory] = useState<GuideDepartmentCategory>('ALL');
  const [expandedItems, setExpandedCategoryItems] = useState<Set<string>>(new Set(['g-ref-1', 'g-1', 'g-3']));

  // Guide Items (Tüm Portallar ve İstasyonların Rehberleri & Soru Bankası)
  const guideData = useMemo(() => [
    // 0. GENEL SİSTEM & İZLENEBİLİRLİK REHBERİ
    {
      id: 'g-ref-1',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Merkezi Kalite Yönetimi (MIWE HIL)',
      title: 'İzlenebilirlik Zinciri & RefID Numaralandırma Mantığı',
      question: 'RefID nedir, sistemde neden kullanılır ve yeni kayıt ile mevcut referans seçimi ne zaman yapılmalıdır?',
      answer: 'RefID (Referans Kimliği, örn: MUZ-20261005-001 veya GB-5-6-20261005), bir partinin bahçeden nihai müşteriye kadar izlendiği ana kimlik kodudur. Tarlada/serada ilk defa kesilen veya toplanan parti için "Yeni Referans" oluşturulur. Ancak ürün yola çıktığında (Lojistik), depoya vardığında (Ambar Kabul), kalite sapması olduğunda (Barlag Akty) veya müşteriye satıldığında (Satış) kesinlikle "Mevcut Referans Seç" kullanılır. Böylece tek tıkla tarladan faturaya 3-Sayfalı Entegre PDF Pasaportu otomatik üretilir.',
      tips: 'Aynı parti için yeni RefID açmak yerine mevcut RefID\'yi bağlamak kalite zincirinin kopmasını önler.'
    },
    {
      id: 'g-ref-2',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Merkezi Kalite Yönetimi (MIWE HIL)',
      title: 'Kritik Kalite Alarmları & Eşik Değer Kontrolü',
      question: 'Sistem hangi durumlarda otomatik kritik alarm üretir ve personelin ilk aksiyonu ne olmalıdır?',
      answer: 'Üç ana eşikte sistem anında sesli ve renkli kritik kalite alarmı verir: 1) Frigo kamyon veya depoda <11.0°C soğuk zararı (Chilling injury riski), 2) MAP torbalarında veya gaz odalarında >%7.5 CO₂ zehirlenmesi, 3) Cihazda bekleyen 5+ çevrimdışı (offline) kayıt birikmesi. Alarm tetiklendiğinde ilgili kalite uzmanına anında bildirim düşer ve 2 saat içinde düzeltici faaliyet başlatılması zorunludur.',
      tips: 'Header üstündeki zil simgesinden aktif kritik alarmlara tek tıkla erişip ilgili parti kaydına zıplayabilirsiniz.'
    },


    // v4.2 — Yeni akışlar (QR, toplu tarama, etiket, standartlar, test planı, muz sarartma, badem)
    {
      id: 'g-v42-qr',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Merkezi Kalite Yönetimi (MIWE HIL)',
      title: 'QR etiket: kim ne görür, personel ne yapar?',
      question: 'Partinin QR etiketini okutunca ne olur?',
      answer: 'Etiketteki QR platform linkidir. Giriş yapmamış biri (müşteri, denetçi) yalnız "Ürün izlenebilirlik kartı"nı görür: ürün, çeşit, bahçe/sera, hasat tarihi, kalite sınıfı ve hasattan satışa tarihler. Kişi adı, kg, fiyat ve not görünmez. Personel "Personel girişi" ile girer ve işlem menüsünden Referans kartı, Ön soğutma, Depo/sevk kabul, Sevk, Test veya Akt seçer; form RefID dolu açılır.',
      tips: 'Etiket yazıcısı gerekmez: Ana menü › Raporlar › QR etiket sayfası (A4) ile 3×8 veya 2×7 yapışkan etiket kâğıdına yazdırın.'
    },
    {
      id: 'g-v42-batch',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Lojistik & Soğuk Depo',
      title: 'Toplu QR tarama (muz paletleri)',
      question: 'Bir araçta 2–3 seradan gelen paletleri nasıl hızlı kabul ederim?',
      answer: 'Ana menü › Hızlı kayıt › Toplu QR tarama. Kamera açık kalır, paletleri arka arkaya okutun; aynı palet iki kez sayılmaz, liste sera bazında sayar ve farklı ürün varsa uyarır. "Depo kabul" veya "Sevk"e basın: form ilk paletle açılır, her kayıttan sonra "Sıradaki palet" ile devam edin.',
      tips: 'Altta görünen "Toplu depo kabul: 3/8" şeridinden forma dönebilir veya işlemi bitirebilirsiniz.'
    },
    {
      id: 'g-v42-std',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Merkezi Kalite Yönetimi (MIWE HIL)',
      title: 'Standart kataloğu: OECD / UNECE ve "en sıkı değer" kuralı',
      question: 'Testte hangi sınır geçerli: OECD mi, UNECE mi, yerel mi, müşteri mi?',
      answer: 'OECD broşürleri UNECE standartlarını yorumlar; sayılar aynıdır. Her ürün 4 katmanla değerlendirilir: 1) Taban (sağlam, temiz, çürüksüz, zararlısız — tüm sınıflarda), 2) Olgunluk sayısı (yalnız bazı ürünlerde: üzüm, kivi, avokado, şeftali, kavun, karpuz, ananas…), 3) Sınıf toleransları (broşürden), 4) Yerel standart ve müşteri şartı. Kural: en sıkı değer geçerli; yerel daha sıkıysa yerel uygulanır, müşteri değeri yalnız o sevkiyatta. Standartta sayı olmayan ürünlerde platformdaki değer "iç değer" olarak gösterilir.',
      tips: 'Test formunda ürünü seçince altında standart kartı çıkar; tüm liste Ana menü › Raporlar › Standart kataloğu.'
    },
    {
      id: 'g-v42-plan',
      category: 'GENEL_REHBER',
      categoryLabel: '🌐 Genel Sistem & İzlenebilirlik',
      department: 'Merkezi Kalite Yönetimi (MIWE HIL)',
      title: 'Test planı: ne zaman kaç test?',
      question: 'Hasat öncesinden ihracata kadar test sıklığı nedir?',
      answer: 'Hasat öncesi: 2–3 test. Hasat sırasında: 3 günde 1 test (her testin kendi test numarası olur ve kapsadığı hasat günlerine/partilere bağlanır). Soğuk depoda: duruma bağlı (sapma, süre, şikâyet). İhracat yüklemesinde: numune ve durum testi. İhracat varışında: 1 test. Dışarıdan gelen yükler: iç ve dış pazar testi; kökeni "dış tedarikçi" olarak işaretlenir.',
      tips: '1 RefID = 1 bahçe + 1 çeşit + 1 hasat günü. Aynı bahçe ve çeşidin günleri otomatik hasat grubunda toplanır.'
    },
    {
      id: 'g-v42-muz',
      category: 'MUZ_HEMSAYA',
      categoryLabel: '🍌 Muz Serası & MAP',
      department: 'Hemsaýa Muz & Lojistik Merkezi',
      title: 'Muz sarartma standardı (MIWE iç standardı)',
      question: 'Sarartma odasında süre, sıcaklık ve etilen ne olmalı; satışa hangi renkte çıkar?',
      answer: 'Standart sarartma: 14 °C, 35 ppm etilen, 8 gün. Satışa çıkış rengi 1–7 renk skalasında hedef 3. Geç hasat veya teknik nedenlerle erken çıkarılan partiler için mutlaka olay (akt) kaydı açılır ve nedeni yazılır. Muz akışı: Kesim → Paket → Muhafaza 1 → Sevk → Muhafaza 2 (lojistik merkezi) → Sarartma → Satış.',
      tips: 'Uluslararası standartta muz için sayısal olgunluk şartı yoktur (yeşil hasat); bu değerler MIWE iç standardıdır.'
    },
    {
      id: 'g-v42-badem',
      category: 'BADEM_MIWELI',
      categoryLabel: '🌰 Badem Plantasyonu & Kırım',
      department: 'Badem Plantasyonu',
      title: 'Badem: hasat kararından depoya',
      question: 'Badem hasadına ne zaman karar verilir ve sonrasında akış nasıl?',
      answer: 'Hasat öncesi test: kabuk (hull) açılması %75 üzeri ve iç nemi yaklaşık %12 olduğunda sulama kesilir. Hasat kombayn ile yapılır; ardından yeşil kabuk (hull) temizlenir, serilir ve kurutulur. Kabuklu (inshell) satılacak parti etiketlenip depoya gider; uygun değilse badem işlemeye (kırım) gönderilir. UNECE sınırı: kabuklu bademde nem tüm meyvede ≤%11,0 veya içte ≤%7,0.',
      tips: 'Depoya girişten önce nem ölçümünü kaydedin; sınırı aşan parti kurutmaya geri döner.'
    },

    // 1. SAHA & HASAT REHBERİ
    {
      id: 'g-1',
      category: 'HASAT_SAHA',
      categoryLabel: '🌱 Meyve Bahçesi & Hasat',
      department: 'Gök Bulut (Meyve Bahçesi - Şeftali, Nektarin, Elma)',
      title: 'Hasat Sonrası Kantar Fişi Noksanlığı ve Sorumluluk Dağılımı',
      question: 'Hasatta toplanan kantar fişi noksan gelirse kim sorumludur ve ne yapılmalıdır?',
      answer: 'Hasatta toplanan tonaj ile ambar kabul tonajı arasındaki farklar doğrudan Hasat Şefliğinin sorumluluğundadır. Kantar fişi eksik veya belgesiz taşınan yükler için anında 2. Derece Barlag Akty tutulmalı, taşıma sevk lot numarası ile kantar fiş eşleşmesi kontrol edilmelidir. Her parsellere ait lot numarasının kasa etiketinde doğru yazıldığından emin olunmalıdır.',
      tips: 'Her parsel kesiminde lot numarası (örn: GB-5-6-20261005) sevk kasalarına basılmalı ve kantar tartım fişi bu lot numarasıyla eşleştirilmelidir.'
    },
    {
      id: 'g-2',
      category: 'HASAT_SAHA',
      categoryLabel: '🌱 Meyve Bahçesi & Hasat',
      department: 'Gök Bulut (Meyve Bahçesi - Şeftali, Nektarin, Elma)',
      title: 'Fenolojik Evre (F-01..F-10) Takibi ve Doğru Hasat Zamanı',
      question: 'Meyve fenolojik evreleri neden hasat formunda zorunludur ve nasıl takip edilir?',
      answer: 'Meyvelerin çiçek tomurcuğu açımından (F-01) tam olgunluğa (F-10) kadar geçen süre, meyve eti sertliği ve asit dengesini doğrudan belirler. F-08 evresi (Erken Olgun) ihracat ve uzun depolama için idealdir. F-10 evresindeki (Aşırı Olgun) meyveler ise soğuk depolanamaz; doğrudan yerel pazara sevk edilmeli veya Freeze & Dry liyofilizasyon hattına aktarılmalıdır.',
      tips: 'Streif İndeksi (Sertlik / Brix * Nişasta) hesaplanarak F-08/F-09 evre doğrulaması bilimsel olarak yapılmalıdır.'
    },
    {
      id: 'g-field-1',
      category: 'HASAT_SAHA',
      categoryLabel: '🌱 Meyve Bahçesi & Hasat',
      department: 'Gök Bulut Saha Kalite Kontrol Laboratuvarı',
      title: 'Brix (Şeker) ve Penetrometre (Sertlik) Saha Ölçüm Protokolü',
      question: 'Meyve sertliği ve şeker oranı nasıl ölçülür, kabul sınırları nelerdir?',
      answer: 'Şeftali ve nektarin: penetrometre 8 mm uç (0,5 cm²) ile ekvatorda iki zıt noktadan, kabuk soyularak ölçülür. UNECE FFV-26 / OECD şartı: Brix ≥8 °Bx ve sertlik <6,5 kg. Daha yüksek Brix ve 4,5 kg alt sertlik MIWE iç hedefidir. Elma (UNECE FFV-50): genel Brix sınırı yoktur, yalnız mini çeşitlerde ≥12 °Bx aranır; elmadaki Brix, sertlik ve nişasta değerleri iç hedeftir. Her ürünün güncel sınırı Ana menü › Raporlar › Standart kataloğu ekranındadır.',
      tips: 'Penetrometre uygularken cihazı dik tutun ve 2 saniye içinde sabit basınçla piston çizgisini geçmeyin.'
    },

    // 2. MUZ & MAP REHBERİ
    {
      id: 'g-3',
      category: 'MUZ_HEMSAYA',
      categoryLabel: '🍌 Muz Serası & MAP',
      department: 'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
      title: 'Muz Hasat Yaşı ve 12-Haftalık Kurdele Takvimi',
      question: 'Muz hasat yaşı neden 12 haftayı geçmemelidir ve kurdele takibi nasıl işler?',
      answer: 'Muzda hevenklerin (çotların) çiçeklenmesinden hasat gününe kadar geçen sürenin 12 hafta olması gerekir. Eğer 12 hafta aşılırsa, meyve serada veya yolda kendi kendine etilen salgılayarak sararmaya (solunum yükselişi) başlar ve yeşil hasat vizesini kaybeder. Renkli şeritler yardımıyla hangi hevenkin hangi hafta kesileceği (12-haftalık takvim) serada titizlikle işaretlenmelidir.',
      tips: 'Seralarda her hafta farklı renk kurdele (örn. 1. Hafta Kırmızı, 2. Hafta Mavi) bağlanarak kesim günü hatasız olarak izlenir.'
    },
    {
      id: 'g-4',
      category: 'MUZ_HEMSAYA',
      categoryLabel: '🍌 Muz Serası & MAP',
      department: 'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
      title: 'MAP (Banavac) Torba ve KMnO₄ absorber Şase Kullanımı',
      question: 'MAP torbası ve etilen emici potasyum permanganat (KMnO4) absorberi ne amaçla kullanılır?',
      answer: 'Modifiye Atmosfer Paketleme (MAP), muzun solunum yoluyla çıkardığı CO₂ gazını %3-8 aralığında tutarak oksijeni %1-2 seviyesine düşürür ve meyveyi uyku moduna alır. KMnO₄ şaseleri ise serbest kalan etilen gazını absorbe ederek yolda meyvenin sararmasını önler. MAP torba kapatılırken sızdırmazlık kontrolü ve vakum değeri standartlara tam uymalıdır.',
      tips: 'CO₂ oranı %7.5 üzerine çıkarsa "Internal Flesh Breakdown" (İç Doku Bozulması) başlar. Gaz limitlerini NDIR cihazıyla ölçün.'
    },
    {
      id: 'g-muz-2',
      category: 'MUZ_HEMSAYA',
      categoryLabel: '🍌 Muz Serası & MAP',
      department: 'Hemsaýa (Muz Serası - Grand Nain Cavendish)',
      title: 'Muz Kalibrasyonu, Parmak Boyu ve Çiçek Kırma Standartları',
      question: 'Muz hasadında parmak kalibre ve boy sınırları nelerdir?',
      answer: 'UNECE FFV-35 / Codex 205: tüm sınıflarda boy en az 14 cm, kalınlık en az 27 mm. Ölçüm, tarağın dış sırasındaki orta parmakta yapılır: boy dış yüzden sap bağlantısından uca, kalınlık parmağın ortasında. İhracatta alıcı daha yüksek boy/kalınlık isteyebilir; bu iç/müşteri kuralıdır. Hasattan önce doğumun 2. haftasında erkek çiçek ucu kırılmalı (de-budding) ve koruyucu mavi poşet geçirilmelidir.',
      tips: 'Kalibre 45 mm\'yi geçerse meyve kutuya sığmaz ve transit süresinde çatlama yapar.'
    },

    // 3. BADEM & KIRIM REHBERİ
    {
      id: 'g-5',
      category: 'BADEM_MIWELI',
      categoryLabel: '🌰 Badem Plantasyonu & Kırım',
      department: 'Miweli Atyz (Muz Serası & Kaka Badem Plantasyonu)',
      title: 'Su Kesilme Tarihi ve Badem Randıman / Nem İlişkisi',
      question: 'Hasat öncesi sulamanın kesilmesi ve yerde kurutma nemi neden kritiktir?',
      answer: 'Hasattan 15-20 gün önce sulamanın kesilmesi, badem kabuğunun ağaçta %70+ oranında açılmasını (hull split) sağlar. Hasat sonrası yerde kurutulan bademlerin iç nemi kesinlikle %4.5 – %6.0 aralığına düşmelidir. %6.5 ve üzeri nem oranları, depoda aflatoksin üreten aspergillus mantarlarının üremesine sebep olarak tüm partiyi kullanılmaz hale getirir.',
      tips: 'Su aktivitesi (aw) değeri her parti için 0.65 aw altında tutularak aflatoksin riski sıfırlanmalıdır.'
    },
    {
      id: 'g-badem-2',
      category: 'BADEM_MIWELI',
      categoryLabel: '🌰 Badem Plantasyonu & Kırım',
      department: 'Miweli Atyz (Kaka Badem Laboratuvarı)',
      title: 'Badem İç Randıman Hesabı ve İkiz Tane (Double) Toleransı',
      question: 'Badem partilerinde iç randıman formülü ve kusur oranları nasıl tespit edilir?',
      answer: 'Laboratuvarda 1.000 gram kabuklu badem kırılır. Net iç badem ağırlığı tartılarak [(Net İç g / 1000) × 100] formülü ile Randıman % değeri bulunur (Nonpareil hedefi: %62 - %68). İkiz badem oranı %5 altı, mekanik kırık %1.5 altı ve sakız/leke kusuru %1 altı olmalıdır. Randıman verisi kantar kabul fişine doğrudan yazılır.',
      tips: 'Badem nem cihazını her ölçümden önce saf nem referans kalibrasyonuyla sıfırlayın.'
    },

    // 4. AMBAR & SOĞUK DEPO REHBERİ
    {
      id: 'g-6',
      category: 'AMBAR_DATLY',
      categoryLabel: '🏢 Soğuk Depo & Ambar Kabul',
      department: 'Depo',
      title: 'Soğuk Zincir Sıcaklık Rejimleri ve Chilling Injury Riski',
      question: 'Transit ve depolama ideal sıcaklığı neden 13.5°C – 14.5°C aralığında olmalıdır?',
      answer: 'Muz ve tropikal meyveler soğuğa duyarlıdır. Eğer depo veya kamyon sıcaklığı 12.0°C ve altına düşerse, meyve hücresi zarları zarar görür ve "Chilling Injury (Soğuk Zararı)" meydana gelir. Meyve kabuğunda kararma, sapta kuruma ve olgunlaşmama sorunları baş gösterir. Tersine, 15.0°C üzeri sıcaklıklar ise hızlı sararma ve solunum yükselişine yol açarak raf ömrünü tüketir.',
      tips: 'Depolama ve sevkiyatta 13.5°C - 14.5°C koridorundan asla taviz verilmemelidir. Verileri frigo data logger ile izleyin.'
    },
    {
      id: 'g-ambar-2',
      category: 'AMBAR_DATLY',
      categoryLabel: '🏢 Soğuk Depo & Ambar Kabul',
      department: 'Depo',
      title: 'Kantar Tartım Farkı, Kabul Fire Hesaplaması ve Oda Tahsisi',
      question: 'Gelen yük ambara ulaştığında kantar kabul süreci nasıl yürütülür?',
      answer: 'Gelen sevk irsaliyesindeki tonaj ile depo kantar tartımı kıyaslanır. Fark %2.5\'i aşıyorsa otomatik 2. Derece Barlag Akty tutulur. Ardından rasgele 5 koli açılarak sıcaklık, etilen kokusu ve çürük muayenesi yapılır. Kabul onayı verilen parti sistemde ilgili CA/Soğuk odaya (Oda 1..Oda 8) barkodlanarak yerleştirilir.',
      tips: 'Paletler hava sirkülasyonunu engellemeyecek şekilde duvardan en az 40 cm açık istiflenmelidir.'
    },

    // 5. FREEZE & DRY LİYOFİLİZASYON REHBERİ
    {
      id: 'g-7',
      category: 'FREEZEDRY_EREM',
      categoryLabel: '❄️ Freeze & Dry Liyofilizasyon',
      department: 'Kalite merkezi & Erem',
      title: 'Standart Dışı Meyvelerin Freeze & Dry ile Geri Kazanımı',
      question: 'Rüzgardan çizilmiş, hafif şekil kusuru olan veya depoda fazla yumuşayan meyvelere ne yapılır?',
      answer: 'FAO Hedef 12.3 (Toplam gıda kaybı/fire oranı < %3.5) kapsamında, taze pazar standardına girmeyen (Class II veya dışı) ancak tat ve hijyen yönünden kusursuz olan meyveler derhal Freeze & Dry tesisine yönlendirilir. Burada dilimlenen meyveler -40°C’de şok dondurulur ve vakumlu liyofilizasyon kabinlerinde süblimasyonla kurutularak 2 yıl raf ömürlü %100 doğal çıtır meyve dilimlerine dönüştürülür.',
      tips: 'Bu sayede bahçe firesi sıfırlanır ve meyveye katma değer katılarak yüksek fiyatlı ihracat ürünü elde edilir.'
    },
    {
      id: 'g-fd-2',
      category: 'FREEZEDRY_EREM',
      categoryLabel: '❄️ Freeze & Dry Liyofilizasyon',
      department: 'Kalite merkezi & Erem',
      title: 'Liyofilizasyon Vakum, Süblimasyon ve Son Nem Standardı',
      question: 'Freeze & Dry çıtırlık kalitesi ve son ürün nem toleransı nedir?',
      answer: 'Kurutma odasında vakum basıncı 0.1 - 0.2 mbar (10-20 Pa) seviyesinde tutulur. Süblimasyon süreci 18-24 saat sürer. Kurutma sonrası son ürün nemi kesinlikle %2.0\'nin altında olmalıdır. Nem %3.0\'ü geçerse ürün çıtırlığını kaybeder ve ambalajda yumuşar.',
      tips: 'Kabin kapağı açılır açılmaz ürünler nemsiz (<%30 RH) paketleme odasında derhal alüminyum doypack ambalajlara azot basılarak mühürlenmelidir.'
    },

    // 6. LOJİSTİK & FRİGO SOĞUK ZİNCİR REHBERİ
    {
      id: 'g-9',
      category: 'LOJISTIK',
      categoryLabel: '🚛 Lojistik & Frigorifik Taşıma',
      department: 'Lojistik & Frigorifik Soğuk Zincir Şefliği',
      title: 'Resmi Delilnama ve Yolculuk Sıcaklık Takibi',
      question: 'Lojistik modülünde Delilnama No ve data logger takibi neden zorunludur?',
      answer: 'Delilnama, ürünün hasat tarlasından soğuk depoya veya limana transferini belgeleyen resmi taşıma senedidir. Frigorifik kamyonlarda yol boyunca sıcaklık dalgalanmalarını izlemek üzere en az 2 adet USB Data Logger yerleştirilir. Çıkış sıcaklığı ve varış sıcaklığı kantar kabul formunda karşılıklı doğrulanarak soğuk zincir halkası kilitlenir.',
      tips: 'Yoldayken kamyon soğutma sistemi (termoking) mazotsuz kalmamalı ve sıcaklık rejimi 13.5°C - 14.5°C dışına çıkmamalıdır.'
    },
    {
      id: 'g-loj-2',
      category: 'LOJISTIK',
      categoryLabel: '🚛 Lojistik & Frigorifik Taşıma',
      department: 'Lojistik & Frigorifik Soğuk Zincir Şefliği',
      title: 'Parçalı Yük (Split) ve Çoklu Sevkiyat Eşitlemesi',
      question: 'Bir parti ürün birden fazla kamyonla taşınırken sistemde nasıl işlenir?',
      answer: 'Hasatta toplanan 25 tonluk tek bir RefID, 12.5\'er tonluk iki ayrı kamyona bölündüğünde Lojistik modülündeki "Parçalı Sevk (Split)" anahtarı aktif edilir. Her kamyona ayrı plaka, şoför ve Delilnama No tanımlanır; ambar kabulde iki sevkiyat tek referans altında otomatik birleşerek eksiksiz kapanır.',
      tips: 'Aynı parti parçalı sevk edilirken her kamyona farklı renkli koli emniyet mühürü takılmalıdır.'
    },

    // 7. DIŞ LAB & İHRACAT MRL REHBERİ
    {
      id: 'g-8',
      category: 'LAB_MRL',
      categoryLabel: '🔬 Laboratuvar & MRL Analiz',
      department: 'Erem™ (İhracat Numune & Raf Ömrü Laboratuvarı)',
      title: 'Dış Akredite Laboratuvar MRL Pestisit Analizi ve Şahit Numuneler',
      question: 'MRL pestisit kalıntı sınırları ve karantina zararlısı takibi nasıl yapılır?',
      answer: 'EAC (Rosselkhoznadzor) ve AB standartları gereği ihracata giden her partiden şahit numune alınmalı ve akredite dış laboratuvarlarda (TSE, SGS, vb.) 650+ etken madde pestisit taraması ve ağır metal analizleri yaptırılmalıdır. Karantina zararlısı toleransı %0’dır. Numuneler ihracat ülkesindeki teslimat onaylanana kadar Erem™ laboratuvarındaki iklimlendirme odalarında şahit olarak saklanır.',
      tips: 'MRL analiz raporları ve sertifika numaraları (örn: TSE-MRL-2026-0894) her sevk partisinin izlenebilirlik pasaportuna eklenir.'
    },
    {
      id: 'g-lab-2',
      category: 'LAB_MRL',
      categoryLabel: '🔬 Laboratuvar & MRL Analiz',
      department: 'Erem™ (İhracat Numune & Raf Ömrü Laboratuvarı)',
      title: 'Şahit Numune Alma ve Hızlandırılmış Raf Ömrü Testi',
      question: 'İhracata gidecek kasalardan şahit numune nasıl ayrılır ve saklanır?',
      answer: 'Her sevk partisinin başından, ortasından ve sonundan 2\'şer koli (toplam 6 koli) şahit numune olarak ayrılır. Numuneler Erem™ iklim kabininde simüle edilmiş nakliye koşullarında (14°C, %85 Nem) 21 gün boyunca bekletilerek raf ömrü ve sararma indeksi günlük olarak fotoğraflanır.',
      tips: 'Müşteriden gelebilecek itirazlarda bu şahit numunelerin fotoğraflı laboratuvar karnesi tek resmi savunma belgesidir.'
    },

    // 8. BARLAG AKTY & UYGUNSUZLUK REHBERİ
    {
      id: 'g-10',
      category: 'KALITE_BARLAG',
      categoryLabel: '⚠️ Barlag Akty & Uygunsuzluk (CAPA)',
      department: 'Kalite Güvence & CAPA Denetim Ekibi',
      title: 'Uygunsuzluk Durumlarında Barlag Akty Düzenleme ve Hakkaniyet',
      question: 'Sahada çıkan bir uygunsuzlukta Barlag Akty nasıl tutulur ve sorumluluk kime aittir?',
      answer: 'Herhangi bir kasada ezilme, çürüme, kantar farkı veya sıcaklık ihlali tespit edildiğinde fotoğraflarla belgelenmiş Barlag Akty tutulur. Tutanaklar 1. Derece Kritik, 2. Derece Orta ve 3. Derece Hafif olarak derecelendirilir. Hata kime aitse ceza puanı onun departmanına (Hasat, Lojistik, Ambar veya Paketleme) yazılır; böylece kalite ekibinin reytingi adil şekilde korunur.',
      tips: 'Tutanak tutulduktan sonra 5-Why (5 Neden) kök sebep analizi yapılarak bir daha aynı hatanın tekrarlanmaması için DÖF başlatılır.'
    },
    {
      id: 'g-barlag-2',
      category: 'KALITE_BARLAG',
      categoryLabel: '⚠️ Barlag Akty & Uygunsuzluk (CAPA)',
      department: 'Kalite Güvence & CAPA Denetim Ekibi',
      title: '5-Why (5 Neden) Kök Sebep Analizi ve DÖF Kapatma Döngüsü',
      question: '1. Derece Kritik Barlag Akty tutulduğunda DÖF süreci nasıl işletilir?',
      answer: 'Kritik tutanakta kusur için 5 kez "Neden?" sorusu sorularak yüzeysel bahane yerine kök sebep ortaya çıkarılır (örn: "Kamyon sıcaklığı neden 9°C\'ye düştü?" -> "Termoking sensörü bozuldu" -> "Periyodik bakım yapılmadı"). Sorumlu departman 48 saat içinde DÖF planı sunar; Kalite Şefi doğrulamadan tutanak kapatılamaz.',
      tips: 'DÖF kapatma onayı sistemde Audit Trail hareket izleme kütüğüne silinmez olarak kaydedilir.'
    }
  ], []);

  // Filter Guide Items based on category and search query
  const filteredGuideItems = useMemo(() => {
    return guideData.filter((item) => {
      const matchesCategory = activeCategory === 'ALL' || item.category === activeCategory;
      const cleanSearch = searchTerm.toLowerCase().trim();
      if (!cleanSearch) return matchesCategory;

      const matchesSearch = 
        item.title.toLowerCase().includes(cleanSearch) ||
        item.question.toLowerCase().includes(cleanSearch) ||
        item.answer.toLowerCase().includes(cleanSearch) ||
        item.department.toLowerCase().includes(cleanSearch) ||
        item.categoryLabel.toLowerCase().includes(cleanSearch);

      return matchesCategory && matchesSearch;
    });
  }, [guideData, activeCategory, searchTerm]);

  // Sayım istatistikleri
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { ALL: guideData.length };
    guideData.forEach(item => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [guideData]);

  const toggleItem = (itemId: string) => {
    setExpandedCategoryItems((prev) => {
      const next = new Set(prev);
      if (next.has(itemId)) {
        next.delete(itemId);
      } else {
        next.add(itemId);
      }
      return next;
    });
  };

  const expandAll = () => {
    setExpandedCategoryItems(new Set(filteredGuideItems.map(i => i.id)));
  };

  const collapseAll = () => {
    setExpandedCategoryItems(new Set());
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* 1. ÜST HERO & BAŞLIK BÖLÜMÜ */}
      <div className="bg-emerald-700 hover:bg-emerald-800 border border-teal-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5 flex-wrap">
              <button
                type="button"
                onClick={onBackToDashboard}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-teal-200 text-xs font-bold transition active:scale-95 cursor-pointer border border-white/10"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Ana Sayfaya Dön</span>
              </button>

              <div className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-800/80 border border-teal-500/30">
                <BookMarked className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="text-[11px] font-bold text-amber-300 tabular-nums">KILAVUZ &amp; SORU BANKASI MERKEZİ</span>
              </div>

              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-400/40">
                Tüm Portalların Ortak Rehberi &amp; Soru Bankası
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
              <div className="p-2 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-teal-300 shadow-inner">
                <BookOpen className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
              <span>Portallar &amp; İstasyonlar Rehberi (Bölüm Soru Bankası)</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Tüm bağımsız portallara, 10 operasyonel istasyona, saha standartlarına, MAP/gaz normlarına ve kalite uygunsuzluk süreçlerine ait rehberler ile sıkça sorulan sorular (Soru Bankası) bölüm aitliğine göre tek çatı altında toplanmıştır.
            </p>
          </div>

          {/* Hızlı İstatistik Rozeti */}
          <div className="flex lg:flex-col items-center lg:items-end gap-2 shrink-0 bg-slate-900/80 p-3 rounded-2xl border border-teal-500/30">
            <div className="text-[11px] text-slate-400">Toplam Dokümante Rehber:</div>
            <div className="text-xl font-bold text-teal-300 tabular-nums">{guideData.length} Kılavuz Maddesi</div>
            <div className="text-[10px] text-amber-400 font-medium">9 Departman Entegre</div>
          </div>
        </div>
      </div>

      {/* 2. ARAMA VE BÖLÜM SEÇİCİ BARI */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Bölüm rehberlerinde veya soru bankasında ara (örn: kantar, brix, kurdele, nem, dondurma, delilnama)..."
              value={searchTerm}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm rounded-xl pl-10 pr-10 py-3 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 placeholder-slate-400 dark:placeholder-slate-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            {searchTerm && (
              <button
                onClick={() => setSearchInput('')}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold"
              >
                &times;
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <button
              type="button"
              onClick={expandAll}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            >
              Tümünü Aç
            </button>
            <button
              type="button"
              onClick={collapseAll}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            >
              Tümünü Kapat
            </button>
          </div>
        </div>

        {/* Bölüm Aitliğine Göre Kategori Filtre Butonları */}
        <div className="space-y-1.5">
          <div className="text-[10px] font-bold text-slate-400">
            Bölüm Aitliğine Göre Filtrele:
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none flex-nowrap sm:flex-wrap">
            {[
              { key: 'ALL', label: 'Tüm Kılavuzlar & Rehberler', icon: BookOpen },
              { key: 'GENEL_REHBER', label: 'Genel Sistem & İzlenebilirlik', icon: Layers },
              { key: 'HASAT_SAHA', label: 'Meyve Bahçesi & Hasat', icon: Sprout },
              { key: 'MUZ_HEMSAYA', label: 'Hemsaýa Muz & MAP', icon: Banana },
              { key: 'BADEM_MIWELI', label: 'Miweli Atyz Badem', icon: Nut },
              { key: 'AMBAR_DATLY', label: 'Depo', icon: Warehouse },
              { key: 'FREEZEDRY_EREM', label: 'Freeze-Dry Liyofilizasyon', icon: Snowflake },
              { key: 'LOJISTIK', label: 'Frigo Soğuk Lojistik', icon: Truck },
              { key: 'LAB_MRL', label: 'Laboratuvar & MRL Analiz', icon: FlaskConical },
              { key: 'KALITE_BARLAG', label: 'Barlag Akty & DÖF (CAPA)', icon: AlertOctagon }
            ].map((cat) => {
              const CatIcon = cat.icon;
              const isSelected = activeCategory === cat.key;
              const count = categoryCounts[cat.key] || 0;
              return (
                <button
                  key={cat.key}
                  type="button"
                  onClick={() => setActiveCategory(cat.key as GuideDepartmentCategory)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                    isSelected
                      ? 'bg-teal-600 text-white shadow-sm ring-2 ring-teal-400/30'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <CatIcon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums ${
                    isSelected ? 'bg-teal-800 text-teal-100' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. INTERACTIVE QUESTIONS & PROCEDURES ACCORDION LIST */}
      <div className="space-y-3">
        {filteredGuideItems.length === 0 ? (
          <div className="py-12 text-center bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl">
            <HelpCircle className="w-8 h-8 text-slate-400 mx-auto mb-2 animate-bounce" />
            <p className="text-xs font-bold text-slate-600 dark:text-slate-300">Aramanıza Uygun Kılavuz veya Soru Bulunamadı</p>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">Lütfen başka kelimelerle (örn: Brix, kurdele, kantar, delilnama, dondurma) tekrar arayın.</p>
          </div>
        ) : (
          filteredGuideItems.map((item) => {
            const isExpanded = expandedItems.has(item.id);
            return (
              <div 
                key={item.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition duration-200"
              >
                {/* Accordion Trigger Header */}
                <button
                  type="button"
                  onClick={() => toggleItem(item.id)}
                  className="w-full px-5 py-4 flex items-center justify-between text-left gap-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition duration-150 cursor-pointer"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                        {item.categoryLabel}
                      </span>
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-teal-500" />
                        <span>{item.department}</span>
                      </span>
                    </div>
                    <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white leading-tight">
                      {item.title}
                    </h3>
                  </div>

                  <div className="shrink-0 text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg">
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-teal-500" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </button>

                {/* Expanded content */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 space-y-4 text-slate-700 dark:text-slate-300 text-xs sm:text-sm animate-in fade-in duration-200">
                    
                    {/* Q&A Section */}
                    <div className="space-y-2.5">
                      <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-950 dark:text-amber-200 font-bold">
                        <HelpCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[10px] font-bold text-amber-600 block mb-0.5">Soru Bankası / Operasyonel Durum</span>
                          <span className="leading-snug">{item.question}</span>
                        </div>
                      </div>

                      <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-950 dark:text-teal-200 font-medium">
                        <ShieldCheck className="w-5 h-5 text-teal-500 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-teal-600 block">Resmi Prosedür &amp; Uygulama Talimatı</span>
                          <p className="leading-relaxed text-xs sm:text-sm">{item.answer}</p>
                        </div>
                      </div>
                    </div>

                    {/* Operational Tips */}
                    <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-slate-600 dark:text-slate-400 text-[11px] tabular-nums leading-relaxed">
                      <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
                      <div>
                        <strong>Saha İpucu:</strong> {item.tips}
                      </div>
                    </div>

                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* 4. GOOGLE DRIVE RESMİ KALİTE PASAPORTLARI BANNER */}
      <div className="bg-gradient-to-r from-teal-950/70 via-slate-900 to-slate-900 border border-teal-500/30 rounded-3xl p-5 sm:p-7 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="p-3 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-500/40 shrink-0">
            <FlaskConical className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">
              Saha Standartları, Sertifikalar &amp; Analiz Pasaportları Dosyası
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mt-0.5">
              GLOBALG.A.P. IFA v6, BRCGS Food v9 kontrol listeleri, pestisit etken kalıntı limitleri (MRL) tabloları ve Erem™ raf ömrü şablonları resmi klasörüne doğrudan erişin.
            </p>
          </div>
        </div>

        <a
          href="https://drive.google.com/drive/folders/1lFmN0JEvfsd94Z8WT3oeYGxPRLbv2OPa?usp=drive_link"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full md:w-auto shrink-0 flex items-center justify-center gap-1.5 px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm transition shadow-md active:scale-95 cursor-pointer"
        >
          <span>Drive Kalite Klasörünü Aç </span>
        </a>
      </div>

    </div>
  );
};
