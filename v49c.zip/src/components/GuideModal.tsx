import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  CheckCircle2, 
  HelpCircle, 
  Layers, 
  Camera, 
  WifiOff, 
  FileSpreadsheet, 
  Printer, 
  Share2, 
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  Copy,
  Check,
  ExternalLink
} from 'lucide-react';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  isAdmin?: boolean;
  onClearDemoData?: () => void;
}

export const GuideModal: React.FC<GuideModalProps> = ({
  isOpen,
  onClose,
  isAdmin = false,
  onClearDemoData
}) => {
  const [activeTab, setActiveTab] = useState<'MIWE_HIL_GUIDE' | 'REF_LOGIC' | 'FIELD_STANDARDS' | 'PHOTOS_OFFLINE' | 'GOOGLE_SHEETS' | 'DEMO_DATA'>('MIWE_HIL_GUIDE');
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  const [clearedMessage, setClearedMessage] = useState(false);

  if (!isOpen) return null;

  const handleClear = () => {
    if (onClearDemoData) {
      onClearDemoData();
      setConfirmClearOpen(false);
      setClearedMessage(true);
      setTimeout(() => setClearedMessage(false), 4000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-3xl w-full overflow-hidden text-slate-800 animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#0f4a33] text-white px-6 py-4 flex items-center justify-between border-b border-emerald-950 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
                MIWE HIL • Kullanım & Saha Operasyon Rehberi
              </h2>
              <p className="text-xs text-emerald-200/80">
                Saha personeli, kalite uzmanları ve yöneticiler için adım adım kılavuz
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-emerald-300 hover:text-white hover:bg-emerald-800/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-100 border-b border-slate-200 px-4 py-2 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
          <button
            onClick={() => setActiveTab('MIWE_HIL_GUIDE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'MIWE_HIL_GUIDE'
                ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm'
                : 'bg-white text-emerald-800 hover:bg-emerald-50 border border-emerald-300'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
            <span> MIWE HIL Kalite Kılavuzu</span>
          </button>

          <button
            onClick={() => setActiveTab('REF_LOGIC')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'REF_LOGIC'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>1. RefID & İzlenebilirlik</span>
          </button>

          <button
            onClick={() => setActiveTab('FIELD_STANDARDS')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'FIELD_STANDARDS'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>2. Saha & Kalite Standartları</span>
          </button>

          <button
            onClick={() => setActiveTab('PHOTOS_OFFLINE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'PHOTOS_OFFLINE'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>3. Fotoğraflar & Çevrimdışı (Offline)</span>
          </button>

          <button
            onClick={() => setActiveTab('GOOGLE_SHEETS')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'GOOGLE_SHEETS'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>4. Google Sheets Düzeni</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('DEMO_DATA')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                activeTab === 'DEMO_DATA'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>5. Sistem Bakımı (Yönetici)</span>
            </button>
          )}
        </div>

        {/* Tab Content */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-xs text-slate-700 leading-relaxed">
          
          {/* TAB 0: MIWE HIL KALİTE & İZLENEBİLİRLİK KILAVUZU */}
          {activeTab === 'MIWE_HIL_GUIDE' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl p-4 shadow-md border border-emerald-700">
                <div className="flex items-center gap-2.5 mb-1.5">
                  <ShieldCheck className="w-5 h-5 text-amber-300 shrink-0" />
                  <h3 className="text-sm font-bold tracking-tight text-white">
                    MIWE HIL Kalite & İzlenebilirlik Kılavuzu
                  </h3>
                </div>
                <p className="text-emerald-100 text-[11px] leading-relaxed">
                  Saha personeli, ambar kabul operatörleri ve kalite kontrol uzmanları için <strong>Pareto Kusur</strong>, <strong>MAP Gaz</strong>, <strong>Brix/Penetrometre</strong> ve <strong>Barlag Akty</strong> analizlerinin ne amaçla yapıldığını ve sahaya sağladığı faydaları özetleyen resmi rehberdir.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Pareto Kusur Analizi */}
                <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold">
                       Pareto
                    </span>
                    <h4 className="font-bold text-rose-950 text-xs">
                      Pareto Kusur Analizi (80/20 Kuralı)
                    </h4>
                  </div>
                  <div className="text-rose-900/90 text-[11px] space-y-1.5">
                    <p>
                      <strong>Ne İçin Yapılır?</strong> Meyve ve ambar kayıplarının %80’ine yol açan en kritik %20’lik ana kök sebepleri (soğuk zararı, taç çürüklüğü, mekanik ezilme, kantar farkı) tespit etmek için yapılır.
                    </p>
                    <p>
                      <strong>Sahadaki Faydası:</strong> Kalite ekibinin tali konular yerine en çok kilo ve gelir kaybettiren 2-3 temel arızayı hızla çözmesini sağlar, fireyi doğrudan asgariye indirir.
                    </p>
                  </div>
                </div>

                {/* 2. MAP Gaz Analizi */}
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-amber-600 text-white text-xs font-bold">
                       MAP Gaz
                    </span>
                    <h4 className="font-bold text-amber-950 text-xs">
                      MAP (Modifiye Atmosfer) & Gaz Yönetimi
                    </h4>
                  </div>
                  <div className="text-amber-900/90 text-[11px] space-y-1.5">
                    <p>
                      <strong>Ne İçin Yapılır?</strong> Muz ve taze meyvelerin solunum hızını yavaşlatıp etilen gazı üretimini frenleyerek yaşlanmayı (senesens) uyku moduna almak için yapılır.
                    </p>
                    <p>
                      <strong>Sahadaki Faydası:</strong> Banavac vakumlu torbalar ve KMnO₄ etilen tutucu şaseler sayesinde O₂ ve CO₂ dengesi korunur; meyvenin erken sararması, sap kararması ve raf kaybı önlenir.
                    </p>
                  </div>
                </div>

                {/* 3. Brix & Penetrometre Analizi */}
                <div className="bg-sky-50/70 border border-sky-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-sky-600 text-white text-xs font-bold">
                       Brix
                    </span>
                    <h4 className="font-bold text-sky-950 text-xs">
                      Brix (Şeker) & Penetrometre (Sertlik)
                    </h4>
                  </div>
                  <div className="text-sky-900/90 text-[11px] space-y-1.5">
                    <p>
                      <strong>Ne İçin Yapılır?</strong> Meyvenin hasat olgunluğuna erişip erişmediğini, lezzet oranını ve soğuk depoda ne kadar süre diri kalabileceğini bilimsel olarak ölçmek için yapılır.
                    </p>
                    <p>
                      <strong>Sahadaki Faydası:</strong> Refraktometre ile şeker (°Bx), penetrometre (kg/cm²) ile et direnci ve Streif İndeksi hesaplanır; ürünün uzun dönem CA depoya mı, markete mi yoksa Freeze-Dry hattına mı gideceği netleşir.
                    </p>
                  </div>
                </div>

                {/* 4. Barlag Akty */}
                <div className="bg-purple-50/70 border border-purple-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-purple-600 text-white text-xs font-bold">
                       Barlag
                    </span>
                    <h4 className="font-bold text-purple-950 text-xs">
                      Barlag Akty (Fire & Uygunsuzluk Tutanağı)
                    </h4>
                  </div>
                  <div className="text-purple-900/90 text-[11px] space-y-1.5">
                    <p>
                      <strong>Ne İçin Yapılır?</strong> Hasat, kantar, nakliye veya ambar kabulde çıkan tolerans dışı sapmaları (kasa kırığı, aşırı fire, çürük, sıcaklık kırılması) fotoğraflı kanıtlarla resmi tutanağa bağlamak için yapılır.
                    </p>
                    <p>
                      <strong>Sahadaki Faydası:</strong> Olayın derecesine göre (1. Derece Kritik, 2. Derece Orta, 3. Derece Hafif) DÖF ve kök sebep analizi başlatır; zararın kime ait olduğunu şeffaflaştırır.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* TAB 1: NEW VS EXISTING REFID LOGIC */}
          {activeTab === 'REF_LOGIC' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
                <h3 className="text-sm font-bold text-emerald-950 flex items-center gap-2 mb-1">
                  <Lightbulb className="w-4 h-4 text-emerald-700" />
                  <span>İzlenebilirlik Zincirinin Temel Kuralı: RefID Nedir?</span>
                </h3>
                <p className="text-emerald-900/90 text-xs leading-relaxed">
                  RefID (Referans Kimliği), bir parti ürünün tarladan nihai müşteriye teslimine kadar takip edildiği <strong>kimlik numarasıdır</strong> (örn. <code className="bg-emerald-100 px-1 py-0.5 rounded tabular-nums text-emerald-900 font-bold">MUZ-20260907-001</code>).
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50 border-2 border-emerald-500/30 rounded-2xl p-4 space-y-2">
                  <span className="inline-block px-2 py-0.5 bg-emerald-600 text-white rounded font-bold text-[10px]">
                    Durum 1: "Yeni Referans Oluştur" Ne Zaman Seçilir?
                  </span>
                  <ul className="space-y-1.5 list-disc pl-4 text-slate-700">
                    <li><strong>Yeni bir hasada başlandığında:</strong> Bahçeden veya seradan ilk defa toplanan bir ürün partisi için.</li>
                    <li><strong>Yeni bir muz sera kesiminde:</strong> Seradan yeni kesilen taraklar için yeni parti başlatılırken.</li>
                    <li><strong>Yeni bir badem hasadında:</strong> Yeni parselden toplanan badem partisi için.</li>
                    <li><strong>Sistem otomatik kod verir:</strong> Tarih ve numara ile otomatik üretilir veya klavyeden dilediğiniz kod yazılabilir.</li>
                  </ul>
                </div>

                <div className="bg-slate-50 border-2 border-blue-500/30 rounded-2xl p-4 space-y-2">
                  <span className="inline-block px-2 py-0.5 bg-blue-600 text-white rounded font-bold text-[10px]">
                    Durum 2: "Mevcut Referans Seç" Ne Zaman Seçilir?
                  </span>
                  <ul className="space-y-1.5 list-disc pl-4 text-slate-700">
                    <li><strong>Ürün yola çıkarken (Lojistik):</strong> Tarlada hasat edilmiş aynı partiyi araca yüklerken o partinin RefID'si seçilir.</li>
                    <li><strong>Depoya vardığında (Ambar Kabul):</strong> Kamyon ambara yanaştığında aynı RefID seçilerek kantar ve fire tartımı yapılır.</li>
                    <li><strong>Kalite tutanağında (Barlag Akty):</strong> Hasarlı veya çürük çıkan partiye ceza/tutanak düzenlenirken o partinin RefID'si bağlanır.</li>
                    <li><strong>Satışta:</strong> O partiden çıkan kasalar müşteriye faturalanırken aynı RefID bağlanır.</li>
                  </ul>
                </div>
              </div>

              <div className="bg-slate-100 rounded-2xl p-3 border border-slate-200">
                <p className="text-[11px] text-slate-600">
                   <strong>Sonuç:</strong> Aynı RefID kullanıldığında, tek bir tıkla <strong>"3 Sayfalı Çoklu PDF Pasaportu"</strong> oluşturulabilir; müşteriniz tarladan faturaya kadar tüm testleri, sıcaklık kayıtlarını ve fotoğrafları tek evrakta görür.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: FIELD & QUALITY STANDARDS */}
          {activeTab === 'FIELD_STANDARDS' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Official Google Drive Quality Passports Link Banner */}
              <div className="bg-emerald-900 text-white rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md border border-emerald-700">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-emerald-800 text-amber-300 shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-white flex items-center gap-2">
                      <span> Görünüş / Kalite Sınıfı & Resmi Kalite Pasaportları</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-slate-900">
                        Google Drive Arşivi
                      </span>
                    </h4>
                    <p className="text-[11px] text-emerald-200 mt-0.5">
                      Miweli Atyz, Erem™, Hemsaýa ürün kalite pasaportları, tolerans tabloları ve görünüş kriterleri dokümanları.
                    </p>
                  </div>
                </div>

                <a
                  href="https://drive.google.com/drive/folders/1lFmN0JEvfsd94Z8WT3oeYGxPRLbv2OPa?usp=drive_link"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition shadow-sm"
                >
                  <span>Drive Pasaport Klasörünü Aç</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-amber-950 flex items-center gap-1.5">
                     Muz Standartları (Hemsaýa Serası)
                  </h4>
                  <ul className="space-y-1 list-disc pl-4 text-amber-900/90 text-[11px]">
                    <li><strong>Hasat Yaşı:</strong> Çiçeklenmeden sonra 11–13 hafta (İdeal: 12 Hafta).</li>
                    <li><strong>Boyut (UNECE FFV-35):</strong> boy ≥14 cm, kalınlık ≥27 mm. İhracat için daha yüksek iç/müşteri sınırı uygulanabilir.</li>
                    <li><strong>Parmak Boyu:</strong> Minimum 18–20 cm.</li>
                    <li><strong>Olgunluk:</strong> Kesinlikle Aşama 1 (Koyu Yeşil).</li>
                    <li><strong>MAP & Şase:</strong> Banavac torba ve KMnO4 etilen emici şase zorunludur.</li>
                  </ul>
                </div>

                <div className="bg-orange-50/70 border border-orange-200 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-orange-950 flex items-center gap-1.5">
                     Badem Standartları (Miweli Atyz)
                  </h4>
                  <ul className="space-y-1 list-disc pl-4 text-orange-900/90 text-[11px]">
                    <li><strong>Hasat Zamanı:</strong> Ağaçta meyve kabuk açılma oranı (Hull Split) &gt; %70 olmalıdır.</li>
                    <li><strong>Kurutma Nemi:</strong> Yerde kurutma sonrası iç (kernel) nemi %4.5 – %6.0 aralığına inmelidir (%6.5 üstü küflenme riskidir).</li>
                    <li><strong>Su Aktivitesi (aw):</strong> Hedef &lt; 0.65 aw (Aflatoksin üremez).</li>
                    <li><strong>Randıman Hesabı:</strong> (Net İç Gramaj / Brüt Numune Gramajı) × 100.</li>
                  </ul>
                </div>

                <div className="bg-red-50/70 border border-red-200 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-red-950 flex items-center gap-1.5">
                     Saha Meyve Testi (Şeftali, Elma, Nektarin)
                  </h4>
                  <ul className="space-y-1 list-disc pl-4 text-red-900/90 text-[11px]">
                    <li><strong>Brix (Şeker):</strong> Hasat için şeftali/nektarinde min %11 Brix, elmada min %12.5 Brix.</li>
                    <li><strong>Sertlik (Penetrometre):</strong> Şeftali için 4.5 – 6.5 kg/cm².</li>
                    <li><strong>Nitrat Testi:</strong> Maksimum 60 mg/kg sınırına uyulmalıdır.</li>
                    <li><strong>Nişasta-İyot Testi (1-10 CTIFL):</strong> 1-2 ham, 3-4 CA/ULO çok uzun depo, 5-6 standart soğuk depo hasadı, 7-8 taze pazar, 9-10 aşırı olgun.</li>
                    <li><strong>Streif Olgunluk İndeksi (SI):</strong> Formül: <em>Sertlik / (Brix × Nişasta)</em>. SI ≥ 0.18 ise CA/ULO deposu, 0.12 - 0.18 standart depo, SI &lt; 0.07 ise depolamaya uygun değildir (Freeze-Dry veya doğrudan tüketim).</li>
                  </ul>
                </div>

                <div className="bg-teal-50/70 border border-teal-200 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-teal-950 flex items-center gap-1.5">
                     Ambar ve soğuk depo
                  </h4>
                  <ul className="space-y-1 list-disc pl-4 text-teal-900/90 text-[11px]">
                    <li><strong>Muz Depolama:</strong> Kesinlikle 13.5°C – 14.5°C (%85–90 Nem). 12°C altı üşüme zararı (Chilling) yapar.</li>
                    <li><strong>Fire Oranı:</strong> Gelen kantar ile kabul kantar tartımı farkı otomatik hesaplanır (%3 üstü fire riskli kabul edilir).</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PHOTOS & OFFLINE */}
          {activeTab === 'PHOTOS_OFFLINE' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 space-y-2">
                <h4 className="font-bold text-blue-950 flex items-center gap-1.5 text-xs">
                  <Camera className="w-4 h-4 text-blue-700" />
                  <span>Fotoğraf & Görsel Şahit Numune Ekleme</span>
                </h4>
                <p className="text-blue-900/90 text-[11px] leading-relaxed">
                  Formların altındaki <strong>"Fotoğraf / Kamera Ekle"</strong> butonuna basarak telefonunuzun kamerasıyla anında çekim yapabilir veya galeriden görsel yükleyebilirsiniz.
                </p>
                <ul className="space-y-1 list-disc pl-4 text-blue-900 text-[11px]">
                  <li>Yüklenen görseller otomatik olarak sıkıştırılarak yerel belleğe işlenir.</li>
                  <li><strong>PDF Pasaportu ve Barlag Akty</strong> yazdırıldığında veya PDF kaydedildiğinde bu fotoğraflar resmi tutanak evrağına doğrudan basılır.</li>
                </ul>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 space-y-2">
                <h4 className="font-bold text-emerald-950 flex items-center gap-1.5 text-xs">
                  <WifiOff className="w-4 h-4 text-emerald-700" />
                  <span>İnternetsiz (Çevrimdışı / Offline) Çalışma Garantisi</span>
                </h4>
                <p className="text-emerald-900/90 text-[11px] leading-relaxed">
                  Sera, ambar veya bahçede internet kesilse bile uygulama donmaz veya kapanmaz:
                </p>
                <ol className="space-y-1.5 list-decimal pl-5 text-emerald-900 text-[11px]">
                  <li>Formu doldurup <strong>"Kaydet"</strong> butonuna basın.</li>
                  <li>Veri cihazınızın güvenli hafızasına anında kaydedilir ve sağ üstte <strong>"X Senk"</strong> sayısı belirir.</li>
                  <li>İnternet bağlantısı olan bir alana geçtiğinizde sistem ya otomatik olarak ya da butona tek dokunuşunuzla bekleyen tüm formları Google E-Tablo'ya güvenle yollar.</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 4: GOOGLE SHEETS DÜZENİ */}
          {activeTab === 'GOOGLE_SHEETS' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 space-y-2">
                <h4 className="font-bold text-teal-950 flex items-center gap-1.5 text-xs">
                  <FileSpreadsheet className="w-4 h-4 text-teal-700" />
                  <span>Google E-Tabloları Dilediğiniz Gibi Düzenleyin</span>
                </h4>
                <p className="text-teal-900/90 text-[11px] leading-relaxed">
                  Evet, Google Sheets üzerindeki veriler tamamen <strong>sizin kontrolünüzdedir</strong>:
                </p>
                <ul className="space-y-1.5 list-disc pl-4 text-teal-900 text-[11px]">
                  <li><strong>Ayrı Sekmeler:</strong> Her modül kendi adına açılan sekmeye yazar (örn. <code className="bg-white px-1 py-0.5 rounded border border-teal-300 tabular-nums">MUZ_RECORDS</code>, <code className="bg-white px-1 py-0.5 rounded border border-teal-300 tabular-nums">BADEM_RECORDS</code>, <code className="bg-white px-1 py-0.5 rounded border border-teal-300 tabular-nums">AMBAR_RECORDS</code>, <code className="bg-white px-1 py-0.5 rounded border border-teal-300 tabular-nums">FEEDBACK_SUGGESTIONS</code>).</li>
                  <li><strong>Formül ve Grafik Ekleme:</strong> Sayfaların sağına veya altına dilediğiniz Excel formülünü (TOPLA, EĞER, DÜŞEYARA vb.) veya pivot tabloları ekleyebilirsiniz; yeni gelen kayıtlar en alta eklenir ve mevcut formüllerinizi bozmaz.</li>
                  <li><strong>Hücre Boyutlandırma & Renklendirme:</strong> Sütunları genişletebilir, başlıkları renklendirebilir veya şirket logonuzu ekleyebilirsiniz.</li>
                </ul>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-[11px] text-slate-600">
                 <strong>İpucu:</strong> Üst menüdeki <strong>"Google Sheets"</strong> butonuna basarak Apps Script kodunu görüntüleyebilir ve web app dağıtım adresinizi dilediğiniz zaman güncelleyebilirsiniz.
              </div>
            </div>
          )}

          {/* TAB 5: DEMO DATA MANAGEMENT */}
          {activeTab === 'DEMO_DATA' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-2">
                <h4 className="font-bold text-amber-950 flex items-center gap-1.5 text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-700" />
                  <span>Örnek (Demo) Verileri İstediğiniz Zaman Silebilirsiniz!</span>
                </h4>
                <p className="text-amber-900/90 text-[11px] leading-relaxed">
                  Sistemi ilk açtığınızda gösterilen kayıtlar sadece test amaçlı örneklerdir. Kendi şirket verilerinizi girmeye hazır olduğunuzda:
                </p>
                <ul className="space-y-1 list-disc pl-4 text-amber-900 text-[11px]">
                  <li><strong>Tek Tek Silme:</strong> "Tüm Referanslar" tablosundaki her satırın sağında yer alan <strong>çöp kutusu (Sil)</strong> ikonuna basarak istemediğiniz referansı ve bağlı tüm testlerini tek tek silebilirsiniz.</li>
                  <li><strong>Tek Tıkla Sıfırlama:</strong> Aşağıdaki butona basarak tüm örnek kayıtları tek seferde temizleyebilir ve sisteme tamamen boş bir sayfa ile başlayabilirsiniz.</li>
                </ul>
              </div>

              {clearedMessage && (
                <div className="bg-emerald-100 border border-emerald-300 text-emerald-800 p-3 rounded-xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  <span>Örnek veriler başarıyla temizlendi! Artık kendi kayıtlarınızı girebilirsiniz.</span>
                </div>
              )}

              {confirmClearOpen ? (
                <div className="bg-rose-50 border-2 border-rose-300 p-4 rounded-2xl space-y-3">
                  <p className="text-xs font-bold text-rose-900">
                     Tüm örnek referans ve form kayıtları temizlensin mi? (Kendi ekleyeceğiniz veriler için temiz bir sayfa açılır)
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleClear}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-sm transition"
                    >
                      Evet, Örnekleri Temizle
                    </button>
                    <button
                      onClick={() => setConfirmClearOpen(false)}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs transition"
                    >
                      Vazgeç
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    onClick={() => setConfirmClearOpen(true)}
                    className="w-full sm:w-auto px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-2xs"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Veritabanını Sıfırla (Temiz Başla)</span>
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-100 px-6 py-3.5 flex items-center justify-between border-t border-slate-200 shrink-0">
          <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>MIWE HIL • Kalite ve İzlenebilirlik Yönetim Kılavuzu</span>
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-sm"
          >
            Anladım, Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
