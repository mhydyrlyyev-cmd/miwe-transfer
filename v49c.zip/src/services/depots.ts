/**
 * v49c — Depo › bina › oda yapısı ve oda kontrol turları.
 *
 * - Depo = WAREHOUSE profili, oda = ROOM profili (fields.warehouse = depo profilinin adı).
 * - Kayıtlardaki serbest yazı (ambar.warehouse / ambar.roomNo) profile bağlanır:
 *   depo adı veya diğer adı; oda adı, oda kodu ("M-2") veya diğer adı.
 * - Oda kontrol turu: bir depodaki tüm odaların tek seferde ölçümü (Excel "oda içi ve set kontrolü"
 *   tablosunun yerine). Firestore 'roomChecks' + yerel önbellek.
 * - Hesaplar telefonda yapılır; ek sunucu yok.
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import { findProfile, getProfiles, useLocationProfiles, type LocationProfile } from './locationProfiles';
import type { AmbarRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../types';

const norm = (s?: string) => (s || '').trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');
const num = (v: unknown): number | undefined => {
  if (v === '' || v === null || v === undefined) return undefined;
  const n = Number(String(v).replace(',', '.'));
  return Number.isFinite(n) ? n : undefined;
};

/* ───────────── Depo ve oda profilleri ───────────── */

export function depotOf(rawWarehouse?: string): LocationProfile | undefined {
  return findProfile('WAREHOUSE', rawWarehouse);
}
export function roomsOf(depot: LocationProfile): LocationProfile[] {
  const names = [depot.name, ...(depot.aliases || [])].map(norm);
  return getProfiles('ROOM')
    .filter(r => names.includes(norm(String(r.fields?.warehouse || ''))))
    .sort((a, b) => String(a.fields?.building || '').localeCompare(String(b.fields?.building || ''), 'tr')
      || (Number(a.fields?.sortNo ?? 999) - Number(b.fields?.sortNo ?? 999))
      || String(a.fields?.code || a.name).localeCompare(String(b.fields?.code || b.name), 'tr', { numeric: true }));
}
export const roomCode = (r: LocationProfile) => String(r.fields?.code || r.name);
export const roomType = (r: LocationProfile) => String(r.fields?.roomType || 'Soğuk depo');
export const setRange = (r: LocationProfile): { min?: number; max?: number } => {
  const a = num(r.fields?.setMinC), b = num(r.fields?.setMaxC);
  if (a !== undefined && b !== undefined && a > b) return { min: b, max: a };
  return { min: a, max: b };
};
export const fmtC = (v?: number) => (v === undefined ? '—' : v.toLocaleString('tr-TR', { maximumFractionDigits: 1 }));
export const setLabel = (r: LocationProfile) => {
  const { min, max } = setRange(r);
  if (min === undefined && max === undefined) return 'set girilmedi';
  if (min !== undefined && max !== undefined) return `${fmtC(min)} – ${fmtC(max)} °C`;
  return `${fmtC(min ?? max)} °C`;
};
/** Kayıttaki oda yazısı bu odaya mı ait? (depo zaten eşleşmiş olmalı) */
export function roomMatches(room: LocationProfile, rawRoom?: string): boolean {
  const n = norm(rawRoom);
  if (!n) return false;
  const keys = [room.name, roomCode(room), ...(room.aliases || [])].map(norm);
  if (keys.includes(n)) return true;
  // "Oda M-2", "M-2 (soğuk)" gibi yazımlar: kod kelime olarak geçiyorsa
  const code = norm(roomCode(room));
  return code.length >= 2 && new RegExp(`(^|[^a-z0-9çğıöşü])${code.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|[^a-z0-9çğıöşü])`, 'i').test(n);
}
export function capacityKg(r: LocationProfile): number | undefined {
  const c = num(r.fields?.capacityKg);
  return c && c > 0 ? c : undefined;
}

/* ───────────── Depodaki partiler (soğuk depo ekranıyla aynı hesap) ───────────── */

export interface StoredLot {
  a: AmbarRecord;
  ref?: ReferenceItem;
  depot?: LocationProfile;
  room?: LocationProfile;
  inKg: number;
  remainingKg: number;
  days: number;
  exited: boolean;
  exitDate?: string;
}

const dayDiff = (from?: string, to?: Date) => {
  if (!from) return 0;
  const a = new Date(from.length === 10 ? `${from}T00:00:00` : from);
  if (Number.isNaN(a.getTime())) return 0;
  return Math.max(0, Math.round(((to || new Date()).getTime() - a.getTime()) / 86400000));
};

export function storedLots(inp: { ambarRecords: AmbarRecord[]; references: ReferenceItem[]; lojistikRecords: LojistikRecord[]; salesRecords: SalesRecord[] }): StoredLot[] {
  const refMap = new Map(inp.references.map(r => [r.refId, r]));
  return inp.ambarRecords.map(a => {
    const entry = (a.acceptanceDate || a.timestamp || '').slice(0, 10);
    const outs = [
      ...inp.lojistikRecords.filter(l => l.refId === a.refId && l.shipmentDate && (!entry || l.shipmentDate.slice(0, 10) >= entry)).map(l => ({ d: l.shipmentDate, kg: Number(l.weightKg) || 0 })),
      ...inp.salesRecords.filter(s => s.refId === a.refId && s.salesDate && (!entry || s.salesDate.slice(0, 10) >= entry)).map(s => ({ d: s.salesDate, kg: Number(s.totalQuantityKg) || 0 })),
    ].sort((x, y) => x.d.localeCompare(y.d));
    const outKg = outs.reduce((s, x) => s + x.kg, 0);
    const inKg = Number(a.acceptedWeightKg) || 0;
    const remainingKg = inKg > 0 ? Math.max(0, inKg - outKg) : 0;
    const exited = outs.length > 0 && (inKg <= 0 || remainingKg <= 0);
    const exitDate = exited ? outs[outs.length - 1].d : undefined;
    const depot = depotOf(a.warehouse);
    const room = depot ? roomsOf(depot).find(r => roomMatches(r, a.roomNo)) : undefined;
    return { a, ref: refMap.get(a.refId), depot, room, inKg, remainingKg, exited, exitDate, days: dayDiff(a.acceptanceDate || a.timestamp, exitDate ? new Date(exitDate) : undefined) };
  });
}

/* ───────────── Oda kontrol turu ───────────── */

export type RoomState = 'COOLING' | 'DEFROST' | 'OFF' | '';
export const ROOM_STATE_LABEL: Record<Exclude<RoomState, ''>, string> = { COOLING: 'Soğutuyor', DEFROST: 'Defrost', OFF: 'Kapalı' };

export interface RoomCheckEntry {
  roomId: string;
  roomName: string;
  setMinC?: number;
  setMaxC?: number;
  monitorC?: number;
  deviceC?: number;
  fruitC?: number;
  rhPercent?: number;
  o2Percent?: number;
  co2Percent?: number;
  state?: RoomState;
  mcp?: 'YES' | 'NO' | '';
  content?: string;
  note?: string;
}
export interface RoomCheckRound {
  id: string;
  warehouse: string;
  at: string;
  by: string;
  entries: RoomCheckEntry[];
  createdAt: string;
}

const LS_KEY = 'miwe_room_checks_v1';
let rounds: RoomCheckRound[] = (() => { try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS_KEY, JSON.stringify(rounds.slice(0, 400))); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function loadOnce() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'roomChecks'));
    const map = new Map(rounds.map(r => [r.id, r]));
    snap.forEach(d => { const v = d.data() as any; if (v && v.warehouse && Array.isArray(v.entries)) map.set(d.id, { ...v, id: d.id }); });
    rounds = [...map.values()].sort((a, b) => b.at.localeCompare(a.at));
    emit();
  } catch { /* çevrimdışı: yerel önbellek */ }
}

export function useRoomChecks(): RoomCheckRound[] {
  const [, force] = useState(0);
  useLocationProfiles();
  useEffect(() => {
    const l = () => force(x => x + 1);
    listeners.add(l); loadOnce();
    return () => { listeners.delete(l); };
  }, []);
  return rounds;
}

export async function saveRoomCheckRound(r: Omit<RoomCheckRound, 'id' | 'createdAt'>): Promise<RoomCheckRound> {
  const full: RoomCheckRound = { ...r, id: `rc-${Date.now().toString(36)}`, createdAt: new Date().toISOString() };
  // Firestore boş alan (undefined) kabul etmez
  full.entries = full.entries.map(e => Object.fromEntries(Object.entries(e).filter(([, v]) => v !== undefined && v !== '')) as unknown as RoomCheckEntry);
  rounds = [full, ...rounds];
  emit();
  try { await saveRecordToFirestore('ROOM_CHECK', full); } catch { /* yerel kalır, senkronda gönderilir */ }
  return full;
}

/** Odanın son ölçümü (tur + parti kontrolleri arasından en yenisi) */
export interface LastReading { at: string; monitorC?: number; deviceC?: number; fruitC?: number; rhPercent?: number; state?: RoomState; by?: string; source: 'TOUR' | 'LOT' }
export function lastReading(room: LocationProfile, list: RoomCheckRound[], lots: StoredLot[]): LastReading | undefined {
  let best: LastReading | undefined;
  for (const rd of list) {
    const e = rd.entries.find(x => x.roomId === room.id);
    if (e && (e.monitorC !== undefined || e.deviceC !== undefined) && (!best || rd.at > best.at)) {
      best = { at: rd.at, monitorC: e.monitorC, deviceC: e.deviceC, fruitC: e.fruitC, rhPercent: e.rhPercent, state: e.state, by: rd.by, source: 'TOUR' };
      break; // liste yeniden eskiye sıralı
    }
  }
  for (const l of lots) {
    if (l.room?.id !== room.id) continue;
    for (const c of l.a.storageChecks || []) {
      if (c.roomTemperatureC === undefined) continue;
      if (!best || c.at > best.at) best = { at: c.at, monitorC: c.roomTemperatureC, fruitC: c.pulpTemperatureC, rhPercent: c.humidityPercent, by: c.inspector, source: 'LOT' };
    }
  }
  return best;
}

export type RoomStatus = 'ok' | 'warn' | 'bad' | 'none';
/** Set aralığına göre: içinde = ok, 1 °C'ye kadar dışında = warn, daha fazla = bad */
export function readingStatus(room: LocationProfile, value?: number): RoomStatus {
  if (value === undefined) return 'none';
  const { min, max } = setRange(room);
  if (min === undefined && max === undefined) return 'none';
  const lo = min ?? max!, hi = max ?? min!;
  if (value >= lo && value <= hi) return 'ok';
  const off = value < lo ? lo - value : value - hi;
  return off <= 1 ? 'warn' : 'bad';
}
/** Monitör ile cihaz arası fark ≥ 2 °C → kalibrasyon şüphesi */
export const calibrationGap = (r?: { monitorC?: number; deviceC?: number }) =>
  r && r.monitorC !== undefined && r.deviceC !== undefined && Math.abs(r.monitorC - r.deviceC) >= 2 ? Math.abs(r.monitorC - r.deviceC) : 0;

export const isToday = (iso?: string) => !!iso && iso.slice(0, 10) === new Date().toISOString().slice(0, 10);
export const hoursAgo = (iso?: string) => (iso ? (Date.now() - new Date(iso).getTime()) / 3600000 : Infinity);

/* ───────────── Depo özeti (ana sayfa + depolar ekranı) ───────────── */

export interface RoomSummary {
  room: LocationProfile;
  lots: StoredLot[];
  kg: number;
  pct?: number;
  avgDays: number;
  reading?: LastReading;
  status: RoomStatus;
  calGap: number;
}
export interface DepotSummary {
  depot: LocationProfile;
  rooms: RoomSummary[];
  kg: number;
  capKg: number;
  pct?: number;
  lots: number;
  bad: number;
  warn: number;
  checkedToday: number;
  /** odaya bağlanamayan (oda adı profille eşleşmeyen) aktif partiler */
  unplaced: StoredLot[];
}

export function summarizeDepots(lots: StoredLot[], checks: RoomCheckRound[]): DepotSummary[] {
  const active = lots.filter(l => !l.exited);
  return getProfiles('WAREHOUSE').map(depot => {
    const rooms = roomsOf(depot).map(room => {
      const rl = active.filter(l => l.room?.id === room.id);
      const kg = rl.reduce((s, l) => s + (l.remainingKg || l.inKg), 0);
      const cap = capacityKg(room);
      const reading = lastReading(room, checks, lots);
      const fresh = reading && hoursAgo(reading.at) <= 48 ? reading : undefined;
      return {
        room, lots: rl, kg,
        pct: cap ? Math.min(100, Math.round((kg / cap) * 100)) : undefined,
        avgDays: rl.length ? Math.round(rl.reduce((s, l) => s + l.days, 0) / rl.length) : 0,
        reading, status: readingStatus(room, fresh?.monitorC), calGap: calibrationGap(fresh),
      } as RoomSummary;
    });
    const mine = active.filter(l => l.depot?.id === depot.id);
    const kg = mine.reduce((s, l) => s + (l.remainingKg || l.inKg), 0);
    const capKg = rooms.reduce((s, r) => s + (capacityKg(r.room) || 0), 0);
    const tourToday = checks.find(c => norm(c.warehouse) === norm(depot.name) && isToday(c.at));
    return {
      depot, rooms, kg, capKg,
      pct: capKg ? Math.min(100, Math.round((kg / capKg) * 100)) : undefined,
      lots: mine.length,
      bad: rooms.filter(r => r.status === 'bad').length,
      warn: rooms.filter(r => r.status === 'warn').length,
      checkedToday: tourToday ? tourToday.entries.filter(e => e.monitorC !== undefined || e.deviceC !== undefined).length : 0,
      unplaced: mine.filter(l => !l.room),
    };
  });
}

/** Profili olmayan depo adları (ör. deneme kayıtlarındaki eski örnek ad) */
export function unknownDepots(lots: StoredLot[]): { name: string; lots: StoredLot[]; kg: number }[] {
  const m = new Map<string, { name: string; lots: StoredLot[]; kg: number }>();
  lots.filter(l => !l.exited && !l.depot).forEach(l => {
    const name = (l.a.warehouse || '').trim() || 'Depo yazılmamış';
    const k = norm(name);
    const cur = m.get(k) || { name, lots: [], kg: 0 };
    cur.lots.push(l); cur.kg += l.remainingKg || l.inKg; m.set(k, cur);
  });
  return [...m.values()];
}

export const tons = (kg: number) => (kg >= 1000 ? `${(kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t` : `${Math.round(kg).toLocaleString('tr-TR')} kg`);
