/**
 * Centralized Shared Options & Variety Registry Service
 * Manages dynamic options across all modules (Fruit Quality, Harvest, Logistics, etc.)
 * Ensures all user-added options are visible to other users and accessible to Admin for review,
 * spelling correction, approval, or restriction.
 */

export interface OptionItem {
  id: string;
  category: string; // 'varieties' | 'locations' | 'products' | 'orchards' | 'destinations' | 'qualityClasses' | etc.
  value: string;
  productContext?: string; // e.g. 'Elma', 'Şeftali', 'Muz', 'Badem'
  addedBy?: string;
  createdAt: string;
  isApproved: boolean; // Admin approved
  correctedSpelling?: string;
  notes?: string;
}

// Temizlenmiş ve 'örn' kısaltmalarından arındırılmış varsayılan sistem seçenekleri
export const DEFAULT_CLEAN_OPTIONS: Record<string, string[]> = {
  products: [
    'Elma',
    'Şeftali',
    'Nektarin',
    'Kiraz',
    'Muz',
    'Badem',
    'Armut',
    'Gawun (Kavun)',
    'Garpyz (Karpuz)',
    'Hurma',
    'Nar'
  ],
  locations: [
    'B-Z',
    'B-2',
    'Parsel 1.1',
    'Parsel 2.1',
    'Parsel 3.1',
    'Parsel 4.1',
    'Badem Parsel 8',
    'GB-5-6 Sera',
    'GB-7-8 Sera',
    'Maksat 9-10 Sera',
    'Miweli 1-2 Sera',
    'Miweli 3-4 Sera',
    'Hem-5 Sera',
    'Hem-11-12 Sera'
  ],
  orchards: [
    'Gök Bulut Meyve Bahçesi',
    'Hemsaýa Muz Serası',
    'Miweli Atyz Badem Plantasyonu',
    'Garahan Bahçeleri'
  ],
  destinations: [
    'PM · Paýlaýyş nokady',
    'Eksport (Daşary Ýurt Satışı - Rusya / Dubai)',
    'Toptan Hal Pazarı (Aşgabat)',
    'Yerel Market Zinciri (Modern Retail)',
    'Endüstriyel İşleme & Meyve Suyu',
    'Miweli Atyz Tesis Ambarı'
  ],
  qualityClasses: [
    'EXTRA — Ekstra Kalite',
    'I. Sınıf — Birinci Sınıf (Mükemmel)',
    'II. Sınıf — İkinci Kalite (Premium)',
    'Sanayi / İşleme Sınıfı',
    'Standart Dışı / Iskarta'
  ],
  colorationPresets: [
    '0 - 25% (Açık Yeşil / Zayıf Renklenme)',
    '25 - 50% (Kısmi Renklenme)',
    '50 - 75% (Standart İhracat Renklenmesi)',
    '75 - 100% (Üstün / Tam Kırmızı Renklenme)'
  ],
  productFinalStatuses: [
    'Taze Satış / Fresh Sale (İhracat & İç Piyasa)',
    'Soğuk Hava Deposu / CA Cold Storage',
    'Liyofilizasyon & İşleme / Freeze & Dry (-40°C)',
    'Fire / Iskonto / Ayrıştırma'
  ]
};

// Çeşitlerin (Varieties) ürün bazlı standart temiz listesi
export const DEFAULT_PRODUCT_VARIETIES: Record<string, string[]> = {
  'Elma': [
    'Gala',
    'Fuji',
    'Golden Delicious',
    'Granny Smith',
    'Red Chief',
    'Scarlet Spur',
    'Pink Lady',
    'Honeycrisp',
    'Braeburn',
    'Idared',
    'Starking Delicious'
  ],
  'Şeftali': [
    'Extreme 314',
    'Royal Glory',
    'Glohaven',
    'Redhaven',
    'Sweet Dream',
    'Rich May',
    'Francoise'
  ],
  'Nektarin': [
    'Big Top',
    'Royal Glory',
    'Big Bang',
    'Extreme Beauty',
    'Caldesi 2000',
    'Silver King'
  ],
  'Kiraz': [
    'Lapins',
    'Regina',
    'Kordia',
    'Ziraat 900',
    'Sweetheart',
    'Early Burlat'
  ],
  'Muz': [
    'Cavendish Grand Nain',
    'Cavendish Extra',
    'Williams Cavendish',
    'Dwarf Cavendish',
    'Grand Nain (Mega)'
  ],
  'Badem': [
    'Nonpareil',
    'Ferragnes',
    'Ferraduel',
    'Guara',
    'Laurenne',
    'Texas',
    'Mazzetto',
    'Vairo'
  ],
  'Armut': [
    'Santa Maria',
    'Carmen',
    'Deveci',
    'Chojuro (Asya Armudu)',
    'Abate Fetel',
    'Williams Armut'
  ],
  'Gawun (Kavun)': [
    'Waharman',
    'Garrygyz',
    'Gulabi',
    'Gurbek',
    'Gyzyl Güläbi'
  ],
  'Garpyz (Karpuz)': [
    'Jeýhun',
    'Crimson Sweet',
    'Astrakhan'
  ]
};

const STORAGE_KEY = 'miwe_shared_options_registry_v2';
const RESTRICTIONS_KEY = 'miwe_category_restrictions_v2';

class OptionsService {
  private items: OptionItem[] = [];
  private restrictions: Record<string, boolean> = {};

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        this.items = JSON.parse(data);
      } else {
        this.items = [];
      }
    } catch {
      this.items = [];
    }

    try {
      const res = localStorage.getItem(RESTRICTIONS_KEY);
      this.restrictions = res ? JSON.parse(res) : {};
    } catch {
      this.restrictions = {};
    }
  }

  private persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.items));
      localStorage.setItem(RESTRICTIONS_KEY, JSON.stringify(this.restrictions));
      // Notify other components & tabs
      window.dispatchEvent(new CustomEvent('miwe_options_updated'));
    } catch (err) {
      console.error('Failed to persist options registry:', err);
    }
  }

  /**
   * Get all active options for a category, optionally filtered by product
   */
  public getOptions(category: string, productContext?: string): string[] {
    const defaultList = category === 'varieties' && productContext
      ? this.getVarietiesForProduct(productContext)
      : (DEFAULT_CLEAN_OPTIONS[category] || []);

    const userAdded = this.items
      .filter(item => {
        if (item.category !== category) return false;
        if (category === 'varieties' && productContext && item.productContext) {
          const normProduct = (productContext || '').toLowerCase();
          const normItemProd = (item.productContext || '').toLowerCase();
          return normProduct.includes(normItemProd) || normItemProd.includes(normProduct);
        }
        return true;
      })
      .map(item => item.correctedSpelling || item.value);

    // If restricted to approved only by admin
    if (this.isRestricted(category)) {
      const approvedUserAdded = this.items
        .filter(item => item.category === category && item.isApproved)
        .map(item => item.correctedSpelling || item.value);
      return Array.from(new Set([...defaultList, ...approvedUserAdded])).filter(Boolean);
    }

    return Array.from(new Set([...defaultList, ...userAdded])).filter(Boolean);
  }

  /**
   * Get varieties for a specific product
   */
  public getVarietiesForProduct(productName: string): string[] {
    const norm = (productName || '').toLowerCase();
    for (const [key, list] of Object.entries(DEFAULT_PRODUCT_VARIETIES)) {
      if (norm.includes(key.toLowerCase()) || key.toLowerCase().includes(norm)) {
        return [...list];
      }
    }
    // Return all default apple varieties as fallback if product not recognized
    return DEFAULT_PRODUCT_VARIETIES['Elma'] || [];
  }

  /**
   * Add a new option from any user (field operator, quality technician, admin)
   */
  public addOption(category: string, value: string, user?: string, productContext?: string): OptionItem {
    const trimmed = value.trim();
    if (!trimmed) throw new Error('Seçenek boş olamaz');

    // Check if already exists in user items
    const existing = this.items.find(
      i => i.category === category &&
           i.value.toLowerCase() === trimmed.toLowerCase() &&
           (!productContext || i.productContext === productContext)
    );

    if (existing) {
      return existing;
    }

    const newItem: OptionItem = {
      id: `opt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      category,
      value: trimmed,
      productContext,
      addedBy: user || 'Kullanıcı',
      createdAt: new Date().toISOString(),
      isApproved: false // Requires admin verification
    };

    this.items.unshift(newItem);
    this.persist();
    return newItem;
  }

  /**
   * Admin: Correct spelling or update an option
   */
  public updateOptionByAdmin(id: string, updates: Partial<OptionItem>) {
    const index = this.items.findIndex(i => i.id === id);
    if (index !== -1) {
      this.items[index] = { ...this.items[index], ...updates };
      this.persist();
    }
  }

  /**
   * Admin: Approve or toggle approval
   */
  public toggleApproval(id: string, isApproved?: boolean) {
    const item = this.items.find(i => i.id === id);
    if (item) {
      item.isApproved = isApproved !== undefined ? isApproved : !item.isApproved;
      this.persist();
    }
  }

  /**
   * Admin: Delete invalid option
   */
  public deleteOption(id: string) {
    this.items = this.items.filter(i => i.id !== id);
    this.persist();
  }

  /**
   * Check if a category is restricted to admin-approved only
   */
  public isRestricted(category: string): boolean {
    return Boolean(this.restrictions[category]);
  }

  /**
   * Set category restriction (e.g. only allow approved varieties)
   */
  public setRestriction(category: string, restricted: boolean) {
    this.restrictions[category] = restricted;
    this.persist();
  }

  /**
   * Get all registry items for the Admin Management Portal
   */
  public getAllRegistryItems(): OptionItem[] {
    return [...this.items];
  }
}

export const optionsService = new OptionsService();
