/**
 * v49b — Ölçüm cihazı kontrol (doğrulama / kalibrasyon) kuralları.
 * Hepsi "İç hedef": yaygın laboratuvar ve GLOBALG.A.P. uygulamasına dayanan öneri aralıkları; profil ekranında değiştirilebilir.
 * Doğrulama (verification) = referansla kontrol, cihazda ayar yok. Kalibrasyon = akredite laboratuvar sertifikası.
 */
export interface CalRule { type: string; intervalDays: number; method: string; tolerance: string; certificateDays?: number }

export const CALIBRATION_RULES: CalRule[] = [
  { type: 'Termometre (problu)', intervalDays: 30, method: 'Buzlu su (0 °C) kontrolü', tolerance: '± 0,5 °C', certificateDays: 365 },
  { type: 'Refraktometre (Brix)', intervalDays: 1, method: 'Saf suyla sıfır; haftada bir %10 sakaroz çözeltisi', tolerance: '± 0,2 °Bx' },
  { type: 'Penetrometre (sertlik)', intervalDays: 7, method: 'Referans ağırlık / test bloğu', tolerance: '± 0,2 kg' },
  { type: 'Terazi / kantar', intervalDays: 7, method: 'Bilinen test ağırlığı (kapasitenin %10–50’si)', tolerance: '± %0,5', certificateDays: 365 },
  { type: 'Datalogger', intervalDays: 365, method: 'Akredite laboratuvar sertifikası; ayda bir buzlu su kontrolü', tolerance: '± 0,5 °C', certificateDays: 365 },
  { type: 'Gaz ölçer (O₂ / CO₂)', intervalDays: 30, method: 'Hava (20,9 % O₂) ve sıfır/span gazı', tolerance: '± 0,3 %', certificateDays: 365 },
  { type: 'Nem ölçer (RH)', intervalDays: 90, method: 'Tuz testi (%75 RH) veya referans cihaz', tolerance: '± 3 % RH' },
];

export const ruleFor = (type?: string) => CALIBRATION_RULES.find(r => r.type === type);

/** Sıradaki kontrol tarihi ve durum. */
export function calibrationStatus(fields: Record<string, any>, today = Date.now()): { next?: number; overdue: boolean; dueSoon: boolean; failed: boolean } {
  const last = fields.lastCheck ? Date.parse(`${String(fields.lastCheck).slice(0, 10)}T00:00:00`) : NaN;
  const interval = Number(fields.intervalDays) || ruleFor(fields.deviceType)?.intervalDays || 0;
  const failed = /kald|fail|red/i.test(String(fields.lastResult || ''));
  if (!Number.isFinite(last) || !interval) return { overdue: !Number.isFinite(last) && !!fields.deviceType, dueSoon: false, failed };
  const next = last + interval * 86400000;
  return { next, overdue: today > next, dueSoon: !(today > next) && next - today < 3 * 86400000, failed };
}
