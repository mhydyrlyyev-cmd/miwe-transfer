import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  Globe,
  Store,
  Package,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Scale,
  ThermometerSnowflake,
  FileSpreadsheet
} from 'lucide-react';
import { normalizeBananaGreenhouseName } from '../../data/banana2027Data';
import { DELILNAMA_2026_GREENHOUSE_QUALITY_TOTALS } from '../../data/delilnamaBanan2026Data';

export interface InteractiveBananaQualityTraceabilityProps {
  greenhouseNo: string;
  ribbonColor: string;
  harvestAgeWeeks: number;
  calibrationMm: number;
  fingerLengthCm: number;
  ripenessScale: number;
  pulpTemperatureC: number;
  mapPackaging: boolean;
  ethyleneAbsorber: boolean;
  netWeightKg: number;
  packaging: string;
  kaliteSinifi: string;
  onApplyDecisionToForm: (decision: {
    targetMarketLabel: string;
    crateType: string;
    kaliteSinifi: string;
    qualityStatus: 'Ekstra / A Kalite' | 'Sınıf 1 / B Kalite' | 'Sınıf 2 / C Kalite' | 'Sanayi / Fire';
    mapPackaging: boolean;
    ethyleneAbsorber: boolean;
    polybagType: 'Vakumlu Banavac' | 'Delikli Polietilen' | 'Açık Dökme';
    destination: string;
    calibrationMm?: number;
    fingerLengthCm?: number;
    harvestAgeWeeks?: number;
  }) => void;
}

export const InteractiveBananaQualityTraceabilityWidget: React.FC<
  InteractiveBananaQualityTraceabilityProps
> = ({
  greenhouseNo,
  ribbonColor,
  harvestAgeWeeks,
  calibrationMm,
  fingerLengthCm,
  ripenessScale,
  pulpTemperatureC,
  mapPackaging,
  ethyleneAbsorber,
  netWeightKg,
  packaging,
  kaliteSinifi,
  onApplyDecisionToForm
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [selectedSeasonMode, setSelectedSeasonMode] = useState<'AUTO' | 'SUMMER' | 'WINTER'>('AUTO');
  const [appliedBanner, setAppliedBanner] = useState<string | null>(null);

  const canonicalGh = useMemo(
    () => normalizeBananaGreenhouseName(greenhouseNo || 'GB-5-6'),
    [greenhouseNo]
  );

  const ghDelilnamaSummary = useMemo(() => {
    return (
      DELILNAMA_2026_GREENHOUSE_QUALITY_TOTALS.find(s => s.greenhouseName === canonicalGh) ||
      DELILNAMA_2026_GREENHOUSE_QUALITY_TOTALS[0]
    );
  }, [canonicalGh]);

  const decisionResult = useMemo(() => {
    const cal = Number(calibrationMm) || 0;
    const len = Number(fingerLengthCm) || 0;
    const weeks = Number(harvestAgeWeeks) || 11;
    const daysApprox = Math.round(weeks * 7);

    // Yaz vs Kış döngüsü
    const currentMonth = new Date().getMonth() + 1;
    const isSummer =
      selectedSeasonMode === 'SUMMER'
        ? true
        : selectedSeasonMode === 'WINTER'
          ? false
          : currentMonth >= 5 && currentMonth <= 9;

    // 1. Kalibre & Boy Kriter Kontrolü
    const isExportCaliber = cal >= 39.0 && cal <= 46.0;
    const isExportLength = len >= 20.0;
    const isExtraLength = len >= 22.0 && cal >= 40.0 && cal <= 45.0;
    const isExportRipeness = ripenessScale >= 1 && ripenessScale <= 2;
    const isColdChainOptimal = pulpTemperatureC >= 13.2 && pulpTemperatureC <= 14.5;

    const isLocalCaliber = cal >= 34.0 && cal <= 48.0;
    const isLocalLength = len >= 16.0;

    // 2. Pazar & Kasa Kararı
    let targetMarketCode: 'EXPORT_EXTRA' | 'EXPORT_CLASS1' | 'LOCAL_MARKET' | 'INDUSTRY' = 'LOCAL_MARKET';
    let targetMarketLabel = '🏪 Yerel Pazar (İç Piyasa & Zincir Market)';
    let crateType = '13 kg Yerel Pazar Plastik Kasa';
    let recommendedKaliteSinifi = 'ORTA (O-18)';
    let recommendedQualityStatus:
      | 'Ekstra / A Kalite'
      | 'Sınıf 1 / B Kalite'
      | 'Sınıf 2 / C Kalite'
      | 'Sanayi / Fire' = 'Sınıf 1 / B Kalite';
    let recommendedPolybag: 'Vakumlu Banavac' | 'Delikli Polietilen' | 'Açık Dökme' =
      'Delikli Polietilen';
    let recommendedDestination = 'Yerel Pazar & Sarartma Tesisi';

    // v45: UNECE FFV-35 asgarisi (boy ≥14 cm, kalınlık ≥27 mm) altı hiçbir pazara gitmez; ihracat/yerel ayrımı iç kuraldır
    const belowUnece = (len > 0 && len < 14) || (cal > 0 && cal < 27);
    if (belowUnece) {
      targetMarketCode = 'INDUSTRY';
      targetMarketLabel = '🏭 UNECE asgarisinin altında (sanayi)';
      crateType = '20 kg Endüstriyel / Püre Kasası';
      recommendedKaliteSinifi = 'ÇIKMA / ENDÜSTRİYEL';
      recommendedQualityStatus = 'Sanayi / Fire';
      recommendedPolybag = 'Açık Dökme';
      recommendedDestination = 'Endüstriyel İşleme / Ayrıştırma';
    } else if (isExportCaliber && isExportLength && isExportRipeness) {
      if (isExtraLength) {
        targetMarketCode = 'EXPORT_EXTRA';
        targetMarketLabel = '🌍 İhracat (Export Pazar — Class Extra)';
        recommendedKaliteSinifi = 'EXTRA (V-20)';
        recommendedQualityStatus = 'Ekstra / A Kalite';
      } else {
        targetMarketCode = 'EXPORT_CLASS1';
        targetMarketLabel = '🌍 İhracat (Export Pazar — Class I)';
        recommendedKaliteSinifi = 'YÜKSEK (Y-19)';
        recommendedQualityStatus = 'Ekstra / A Kalite';
      }
      crateType = '18 kg Export Teleskopik Karton (MAP Poşetli)';
      recommendedPolybag = 'Vakumlu Banavac';
      recommendedDestination = 'İhracat soğuk zinciri (13–14 °C hava ile ön soğutma)';
    } else if (isLocalCaliber && isLocalLength) {
      targetMarketCode = 'LOCAL_MARKET';
      targetMarketLabel = '🏪 Yerel Pazar (İç Piyasa & Zincir Market)';
      crateType = len >= 18.5 ? '15 kg Zincir Market Plastik Kasa' : '13 kg Yerel Pazar Plastik Kasa';
      recommendedKaliteSinifi = len >= 18.5 ? 'ORTA (O-18)' : 'KÜÇÜK (K-16)';
      recommendedQualityStatus = len >= 18.0 ? 'Sınıf 1 / B Kalite' : 'Sınıf 2 / C Kalite';
      recommendedPolybag = 'Delikli Polietilen';
      recommendedDestination = 'Hemsaýa Muz Gazlama & Yerel Sevkiyat';
    } else {
      targetMarketCode = 'INDUSTRY';
      targetMarketLabel = '🏭 Endüstriyel / Çıkma & Püre Sınıfı';
      crateType = '20 kg Endüstriyel / Püre Kasası';
      recommendedKaliteSinifi = 'ÇIKMA / ENDÜSTRİYEL';
      recommendedQualityStatus = 'Sanayi / Fire';
      recommendedPolybag = 'Açık Dökme';
      recommendedDestination = 'Endüstriyel İşleme / Ayrıştırma';
    }

    // 3. 11. Hafta (77. Gün) & Yaz/Kış Erken Kesim Durumu
    const isReached11thWeek = weeks >= 11;
    let weekRuleStatus: 'OPTIMAL' | 'EARLY' | 'LATE' = 'OPTIMAL';
    let weekRuleText = '';

    if (isSummer) {
      if (weeks < 10) {
        weekRuleStatus = 'EARLY';
        weekRuleText = `Yaz Erken Kesim (${weeks} Hf / ~${daysApprox} Gün < 70 Gün) — Kalibre dolumu eksik kalabilir`;
      } else if (weeks <= 11.5) {
        weekRuleStatus = 'OPTIMAL';
        weekRuleText = `Yaz Optimal Hasat (${weeks} Hf / ~${daysApprox} Gün) — 11. Hafta standardına tam uygun`;
      } else {
        weekRuleStatus = 'LATE';
        weekRuleText = `Yaz Gecikmiş Kesim (${weeks} Hf / ~${daysApprox} Gün > 78 Gün) — Parmak çatlama riski!`;
      }
    } else {
      if (weeks < 11) {
        weekRuleStatus = 'EARLY';
        weekRuleText = `Kış Erken Kesim (${weeks} Hf / ~${daysApprox} Gün < 11. Hafta / 77 Gün)`;
      } else if (weeks <= 14.5) {
        weekRuleStatus = 'OPTIMAL';
        weekRuleText = `Kış Optimal Hasat (${weeks} Hf / ~${daysApprox} Gün) — 85–102 gün kış dolumuna uygun`;
      } else {
        weekRuleStatus = 'LATE';
        weekRuleText = `Kış Gecikmiş Kesim (${weeks} Hf / ~${daysApprox} Gün > 102 Gün) — Green Life kısalır`;
      }
    }

    const crateKg = crateType.startsWith('18')
      ? 18
      : crateType.startsWith('15')
        ? 15
        : crateType.startsWith('20')
          ? 20
          : 13;
    const estimatedCrateCount = Math.max(1, Math.round((Number(netWeightKg) || 0) / crateKg));

    return {
      targetMarketCode,
      targetMarketLabel,
      crateType,
      crateKg,
      estimatedCrateCount,
      recommendedKaliteSinifi,
      recommendedQualityStatus,
      recommendedPolybag,
      recommendedDestination,
      isExportCaliber,
      isExportLength,
      isExportRipeness,
      isColdChainOptimal,
      isReached11thWeek,
      isSummer,
      daysApprox,
      weekRuleStatus,
      weekRuleText
    };
  }, [
    calibrationMm,
    fingerLengthCm,
    harvestAgeWeeks,
    ripenessScale,
    pulpTemperatureC,
    netWeightKg,
    selectedSeasonMode
  ]);

  const handleApplyCurrentDecision = () => {
    onApplyDecisionToForm({
      targetMarketLabel: decisionResult.targetMarketLabel,
      crateType: decisionResult.crateType,
      kaliteSinifi: decisionResult.recommendedKaliteSinifi,
      qualityStatus: decisionResult.recommendedQualityStatus,
      mapPackaging: decisionResult.targetMarketCode.startsWith('EXPORT'),
      ethyleneAbsorber: decisionResult.targetMarketCode.startsWith('EXPORT'),
      polybagType: decisionResult.recommendedPolybag,
      destination: decisionResult.recommendedDestination
    });
    setAppliedBanner(
      `✅ Eşleştirme Rapor & Forma Uygulandı: ${decisionResult.targetMarketLabel} · ${decisionResult.crateType} (${decisionResult.estimatedCrateCount} Kutu)`
    );
    setTimeout(() => setAppliedBanner(null), 4000);
  };

  const handleApplyPresetScenario = (preset: 'EXPORT_EXTRA' | 'LOCAL_MARKET' | 'SUMMER_11W') => {
    if (preset === 'EXPORT_EXTRA') {
      onApplyDecisionToForm({
        targetMarketLabel: '🌍 İhracat (Export Pazar — Class Extra)',
        crateType: '18 kg Export Teleskopik Karton (MAP Poşetli)',
        kaliteSinifi: 'EXTRA (V-20)',
        qualityStatus: 'Ekstra / A Kalite',
        mapPackaging: true,
        ethyleneAbsorber: true,
        polybagType: 'Vakumlu Banavac',
        destination: 'İhracat soğuk zinciri (13–14 °C hava ile ön soğutma)',
        calibrationMm: 42.0,
        fingerLengthCm: 22.5,
        harvestAgeWeeks: 11
      });
      setAppliedBanner('🌍 İhracat (Class Extra — 42mm / 22.5cm / 18kg MAP Karton) profili forma yüklendi.');
    } else if (preset === 'LOCAL_MARKET') {
      onApplyDecisionToForm({
        targetMarketLabel: '🏪 Yerel Pazar (İç Piyasa & Zincir Market)',
        crateType: '13 kg Yerel Pazar Plastik Kasa',
        kaliteSinifi: 'ORTA (O-18)',
        qualityStatus: 'Sınıf 1 / B Kalite',
        mapPackaging: false,
        ethyleneAbsorber: false,
        polybagType: 'Delikli Polietilen',
        destination: 'Hemsaýa Muz Gazlama & Yerel Sevkiyat',
        calibrationMm: 36.5,
        fingerLengthCm: 18.0,
        harvestAgeWeeks: 11
      });
      setAppliedBanner('🏪 Yerel Pazar (36.5mm / 18.0cm / 13kg Plastik Kasa) profili forma yüklendi.');
    } else {
      onApplyDecisionToForm({
        targetMarketLabel: decisionResult.targetMarketLabel,
        crateType: decisionResult.crateType,
        kaliteSinifi: decisionResult.recommendedKaliteSinifi,
        qualityStatus: decisionResult.recommendedQualityStatus,
        mapPackaging: decisionResult.targetMarketCode.startsWith('EXPORT'),
        ethyleneAbsorber: decisionResult.targetMarketCode.startsWith('EXPORT'),
        polybagType: decisionResult.recommendedPolybag,
        destination: decisionResult.recommendedDestination,
        harvestAgeWeeks: 11
      });
      setAppliedBanner('🟢 11. Hafta (77. Gün) Resmi Hasat Yaşı standardı forma uygulandı.');
    }
    setTimeout(() => setAppliedBanner(null), 4000);
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl border border-emerald-500/40 shadow-md overflow-hidden">
      {/* HER ZAMAN GÖRÜNÜR KOMPAKT CANLI SONUÇ & İZLENEBİLİRLİK ÖZET BARI */}
      <div className="p-3.5 sm:p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                İnteraktif Kalite & İzlenebilirlik Eşleştirmesi (Takvimden Bağımsız)
              </span>
              <span className="text-[11px] font-mono text-slate-300">
                Sera: <strong className="text-white">{canonicalGh}</strong> · Şerit:{' '}
                <strong className="text-amber-300">{ribbonColor || 'Belirtilmedi'}</strong>
              </span>
            </div>
            <h3 className="text-xs sm:text-sm font-black text-white mt-0.5">
              Kalite Standartları, Kasa Tipi & Hedef Pazar (Export / Yerel) Canlı Karar Özeti
            </h3>
          </div>
        </div>

        {/* CANLI HESAPLANAN SONUÇ ROZETLERİ */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Hedef Pazar Sonucu */}
          <div
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 ${
              decisionResult.targetMarketCode.startsWith('EXPORT')
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                : decisionResult.targetMarketCode === 'LOCAL_MARKET'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                  : 'bg-rose-500/20 border-rose-400 text-rose-200'
            }`}
          >
            {decisionResult.targetMarketCode.startsWith('EXPORT') ? (
              <Globe className="w-3.5 h-3.5 text-emerald-300" />
            ) : (
              <Store className="w-3.5 h-3.5 text-amber-300" />
            )}
            <span>{decisionResult.targetMarketLabel}</span>
          </div>

          {/* Kasa Tipi & Adet Sonucu */}
          <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-600 text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-sky-400" />
            <span>
              {decisionResult.crateType} ({decisionResult.estimatedCrateCount} Kutu)
            </span>
          </div>

          {/* 11. Hafta / Hasat Yaşı Sonucu */}
          <div
            className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-black flex items-center gap-1 ${
              decisionResult.weekRuleStatus === 'OPTIMAL'
                ? 'bg-teal-500/20 border-teal-400/50 text-teal-200'
                : decisionResult.weekRuleStatus === 'EARLY'
                  ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                  : 'bg-rose-500/20 border-rose-400/50 text-rose-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>
              {harvestAgeWeeks} Hf (~{decisionResult.daysApprox}g) ·{' '}
              {decisionResult.isReached11thWeek ? '11.Hf Uygun' : 'Erken Kesim'}
            </span>
          </div>

          {/* Tek Tıkla Forma & Rapora Aktar */}
          <button
            type="button"
            onClick={handleApplyCurrentDecision}
            className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-sm cursor-pointer transition"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sonucu Forma & Rapora Uygula</span>
          </button>

          {/* Detay Aç / Kapat (Yer Kaplamaması İçin) */}
          <button
            type="button"
            onClick={() => setIsExpanded(prev => !prev)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-xs font-bold text-slate-200 flex items-center gap-1 cursor-pointer transition"
          >
            <span>{isExpanded ? 'Detayı Küçült' : 'Standartlar & Etkileşimli Matris'}</span>
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* UYGULANDI BİLDİRİMİ */}
      {appliedBanner && (
        <div className="bg-emerald-600/90 text-white px-4 py-1.5 text-xs font-bold flex items-center justify-between border-t border-emerald-400/40">
          <span>{appliedBanner}</span>
          <span className="text-[10px] font-mono uppercase">İzlenebilirlik Kaydına Eklendi</span>
        </div>
      )}

      {/* HER ZAMAN GÖRÜNÜR TEK SATIR CANLI KRİTER DURUMU (KOMPAKT BÜTÜN GÖRÜNÜM) */}
      <div className="bg-slate-950/60 px-4 py-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px]">
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1">
            {decisionResult.isExportCaliber ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="text-slate-300">Kalibre:</span>
            <strong className="font-mono text-white">{calibrationMm} mm</strong>
            <span className="text-slate-400">
              ({decisionResult.isExportCaliber ? 'İç ihracat sınırına uygun' : 'İç yerel pazar sınırı'})
            </span>
          </span>

          <span className="text-slate-700">|</span>

          <span className="flex items-center gap-1">
            {decisionResult.isExportLength ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="text-slate-300">Parmak Boyu:</span>
            <strong className="font-mono text-white">{fingerLengthCm} cm</strong>
            <span className="text-slate-400">
              ({decisionResult.isExportLength ? 'Export ≥20cm Uygun' : 'Yerel 16-19.5cm'})
            </span>
          </span>

          <span className="text-slate-700">|</span>

          <span className="flex items-center gap-1">
            <ThermometerSnowflake
              className={`w-3.5 h-3.5 ${
                decisionResult.isColdChainOptimal ? 'text-sky-400' : 'text-amber-400'
              }`}
            />
            <span className="text-slate-300">Meyve İçi:</span>
            <strong className="font-mono text-white">{pulpTemperatureC}°C</strong>
            <span className="text-slate-400">· Skala {ripenessScale}</span>
          </span>

          <span className="text-slate-700">|</span>

          <span className="text-slate-300">
            Seçili Kasa/Sınıf:{' '}
            <strong className="text-amber-300">{packaging || decisionResult.crateType}</strong> ·{' '}
            <strong className="text-emerald-300">
              {kaliteSinifi || decisionResult.recommendedKaliteSinifi}
            </strong>
          </span>
        </div>

        <div className="text-[10px] font-mono text-slate-400">
          2026 Delilnama ({canonicalGh}):{' '}
          <strong className="text-emerald-300">
            {ghDelilnamaSummary.totalAgramKg.toLocaleString('tr-TR')} kg
          </strong>{' '}
          (Export Oranı: %{ghDelilnamaSummary.exportSharePct})
        </div>
      </div>

      {/* AÇILIR DETAYLI İNTERAKTİF STANDARTLAR & RAPOR EŞLEŞTİRME PANELİ */}
      {isExpanded && (
        <div className="p-4 bg-slate-50 text-slate-900 border-t border-slate-200 space-y-4 text-xs">
          {/* Hızlı Senaryo / Standart Seçici Butonlar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-emerald-700" />
              <span className="font-black text-slate-800">
                Hızlı Standart Profil Simülasyonu & Forma Aktarım:
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => handleApplyPresetScenario('EXPORT_EXTRA')}
                className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-black text-[11px] cursor-pointer transition"
              >
                🌍 1. İhracat (iç kural: kalınlık 39–46 / boy ≥20 cm) uygula
              </button>
              <button
                type="button"
                onClick={() => handleApplyPresetScenario('LOCAL_MARKET')}
                className="px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-black text-[11px] cursor-pointer transition"
              >
                🏪 2. Yerel Pazar (34-48mm / 16-19.5cm / 13kg Plastik Kasa) Uygula
              </button>
              <button
                type="button"
                onClick={() => handleApplyPresetScenario('SUMMER_11W')}
                className="px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 font-black text-[11px] cursor-pointer transition"
              >
                🟢 3. 11. Hafta (77. Gün) Resmi Hasat Eşiğini Uygula
              </button>
            </div>
          </div>

          {/* 3 Sütunlu İnteraktif Karşılaştırma (Canlı Ölçüm Değerleriyle Eşleşen) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            {/* Kart 1: Export Standartları vs Mevcut Parti */}
            <div
              className={`p-3.5 rounded-xl border-2 space-y-2 transition ${
                decisionResult.targetMarketCode.startsWith('EXPORT')
                  ? 'bg-emerald-50/70 border-emerald-500 shadow-sm'
                  : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <strong className="text-emerald-950 font-black text-xs flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-emerald-600" />
                  <span>1. İhracat (Export — Class Extra / I)</span>
                </strong>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-black ${
                    decisionResult.targetMarketCode.startsWith('EXPORT')
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {decisionResult.targetMarketCode.startsWith('EXPORT') ? 'AKTİF HEDEF' : 'KRİTER DIŞI'}
                </span>
              </div>
              <div className="space-y-1 text-[11px] text-slate-700">
                <div className="flex items-center justify-between">
                  <span>• Parmak Kalibresi (39.0–46.0 mm):</span>
                  <strong
                    className={`font-mono ${
                      decisionResult.isExportCaliber ? 'text-emerald-700' : 'text-rose-600'
                    }`}
                  >
                    {calibrationMm} mm {decisionResult.isExportCaliber ? '✓' : '✗'}
                  </strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>• Parmak Boyu (Min 20.0 cm / Extra ≥22):</span>
                  <strong
                    className={`font-mono ${
                      decisionResult.isExportLength ? 'text-emerald-700' : 'text-rose-600'
                    }`}
                  >
                    {fingerLengthCm} cm {decisionResult.isExportLength ? '✓' : '✗'}
                  </strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>• Yeşil Ömür & Skala (Skala 1–2, ≥21g):</span>
                  <strong
                    className={`font-mono ${
                      decisionResult.isExportRipeness ? 'text-emerald-700' : 'text-amber-700'
                    }`}
                  >
                    Skala {ripenessScale} {decisionResult.isExportRipeness ? '✓' : '!'}
                  </strong>
                </div>
                <div className="pt-1 border-t border-emerald-200/70 text-[10px] text-emerald-900 font-semibold">
                  Ambalaj: <strong>Karton + polietilen poşet, 13–14 °C hava ile ön soğutma</strong>
                </div>
              </div>
            </div>

            {/* Kart 2: Yerel Pazar Standartları vs Mevcut Parti */}
            <div
              className={`p-3.5 rounded-xl border-2 space-y-2 transition ${
                decisionResult.targetMarketCode === 'LOCAL_MARKET'
                  ? 'bg-amber-50/70 border-amber-500 shadow-sm'
                  : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <strong className="text-amber-950 font-black text-xs flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-amber-600" />
                  <span>2. Yerel Pazar (İç Piyasa & Market)</span>
                </strong>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-black ${
                    decisionResult.targetMarketCode === 'LOCAL_MARKET'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {decisionResult.targetMarketCode === 'LOCAL_MARKET' ? 'AKTİF HEDEF' : 'ALTERNATİF'}
                </span>
              </div>
              <div className="space-y-1 text-[11px] text-slate-700">
                <div className="flex items-center justify-between">
                  <span>• Parmak Kalibresi (34.0–48.0 mm):</span>
                  <strong className="font-mono text-amber-800">{calibrationMm} mm ✓</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>• Parmak Boyu (16.0–19.5 cm Class II):</span>
                  <strong className="font-mono text-amber-800">{fingerLengthCm} cm</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>• Sarartma Durumu (Skala 2–4, ≤%10 iz):</span>
                  <strong className="font-mono text-amber-800">Skala {ripenessScale}</strong>
                </div>
                <div className="pt-1 border-t border-amber-200/70 text-[10px] text-amber-900 font-semibold">
                  Kasa Tipi: <strong>13 kg Yerel Pazar Plastik Kasa</strong> veya <strong>15 kg Market Kasası</strong>
                </div>
              </div>
            </div>

            {/* Kart 3: Yaz/Kış Erken Kesim & 11. Hafta + 2026 Delilnama Sera Özeti */}
            <div className="p-3.5 rounded-xl border-2 border-sky-300 bg-sky-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <strong className="text-sky-950 font-black text-xs flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-sky-600" />
                  <span>3. Yaz/Kış & 11. Hafta + 2026 Sonuç</span>
                </strong>
                <div className="flex items-center gap-1">
                  {(['AUTO', 'SUMMER', 'WINTER'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setSelectedSeasonMode(m)}
                      className={`px-1.5 py-0.5 rounded text-[9px] font-black cursor-pointer ${
                        selectedSeasonMode === m
                          ? 'bg-sky-700 text-white'
                          : 'bg-white text-sky-800 border border-sky-200'
                      }`}
                    >
                      {m === 'AUTO' ? 'Oto' : m === 'SUMMER' ? '☀️ Yaz' : '❄️ Kış'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-2 rounded-lg bg-white border border-sky-200 text-[11px] space-y-1">
                <div className="font-bold text-sky-950">{decisionResult.weekRuleText}</div>
                <div className="text-[10px] text-slate-600">
                  • <strong>Yaz (Mayıs–Eylül):</strong> 70–78 gün (10–11 hf) · <strong>Kış (Ekim–Nisan):</strong> 85–102 gün (12–14.5 hf)
                </div>
              </div>

              {/* Seçili Seranın 2026 Delilnama Gerçekleşen Kalite Dağılımı */}
              <div className="p-2 rounded-lg bg-emerald-950 text-white text-[10px] space-y-1">
                <div className="flex items-center justify-between font-bold text-emerald-300">
                  <span className="flex items-center gap-1">
                    <FileSpreadsheet className="w-3 h-3" />
                    <span>{canonicalGh} — 2026 Delilnama Hasat Dağılımı:</span>
                  </span>
                  <span className="font-mono">{ghDelilnamaSummary.totalAgramKg.toLocaleString('tr-TR')} kg</span>
                </div>
                <div className="grid grid-cols-4 gap-1 text-center font-mono text-[9px] pt-0.5">
                  <div className="bg-emerald-900/80 rounded px-1 py-0.5">
                    Extra: {Math.round(ghDelilnamaSummary.extraKg).toLocaleString('tr-TR')}
                  </div>
                  <div className="bg-teal-900/80 rounded px-1 py-0.5">
                    Excl: {Math.round(ghDelilnamaSummary.exclusiveKg).toLocaleString('tr-TR')}
                  </div>
                  <div className="bg-amber-900/80 rounded px-1 py-0.5">
                    Prem: {Math.round(ghDelilnamaSummary.premiumKg).toLocaleString('tr-TR')}
                  </div>
                  <div className="bg-rose-900/80 rounded px-1 py-0.5">
                    Çıkma: {Math.round(ghDelilnamaSummary.yekeliGarysykEzikMixKg).toLocaleString('tr-TR')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
