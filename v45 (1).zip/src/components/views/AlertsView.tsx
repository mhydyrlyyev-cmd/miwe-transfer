import React, { useMemo, useState } from 'react';
import { Copy } from 'lucide-react';
import { findRefConflicts } from '../../utils/refConflicts';
import { cleanName } from '../../utils/qrRef';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord, BalanceAdjustment, FieldRecord } from '../../types';
import ColdChainPanel from '../coldchain/ColdChainPanel';
import { PageHeader } from '../ui';

/**
 * v3.7 — Tüm uyarılar tek sayfada (ana panel "Tümü" ve mobil alt menü "Uyarılar").
 * Her uyarı kendi aşama etiketini taşır; ayrıntılı işlem kendi aşama sayfasında yapılır.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  /** v3.8: RefID çakışma kontrolü için */
  fieldRecords?: FieldRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onOpenRecord: (refId: string) => void;
  onOpenPrecooling: (ref: ReferenceItem) => void;
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onBack: () => void;
}

const fmtD = (d: string) => d.split('-').reverse().slice(0, 2).join('.');

export default function AlertsView(p: Props) {
  const conflicts = useMemo(() => findRefConflicts(p.references, p.harvestRecords, p.fieldRecords || []), [p.references, p.harvestRecords, p.fieldRecords]);
  const [showAll, setShowAll] = useState(false);
  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader onBack={p.onBack} title="Uyarılar" subtitle="Tüm aşamaların uyarıları; en acil olan üstte. Etiket, uyarının hangi aşamaya ait olduğunu gösterir." />
      {/* v3.8: aynı RefID'yi paylaşan farklı partiler (eski numaralandırma hatasından) */}
      {conflicts.length > 0 && (
        <section className="rounded-2xl border border-rose-200 bg-rose-50 dark:bg-rose-950/30 dark:border-rose-900 p-4">
          <div className="flex items-start gap-2">
            <Copy className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="min-w-0">
              <h2 className="font-display text-base font-bold text-rose-900 dark:text-rose-200">{conflicts.length} RefID kontrol edilmeli (kayıt hatası)</h2>
              <p className="text-xs text-rose-800 dark:text-rose-300">Aynı numara altında farklı ürün/bahçe veya birbirinden uzak hasat tarihleri var. Eski sürümde aynı gün açılan partiler aynı numarayı alabiliyordu; yeni kayıtlarda bu düzeltildi. Bu partileri kontrol edip gerekirse yeni numara ile ayırın.</p>
            </div>
          </div>
          <ul className="mt-3 space-y-2">
            {(showAll ? conflicts : conflicts.slice(0, 5)).map(c => (
              <li key={c.refId} className="rounded-xl bg-white dark:bg-slate-900 border border-rose-100 dark:border-rose-900 p-2.5">
                <button type="button" onClick={() => p.onOpenRecord(c.refId)} className="font-ref font-bold text-sm text-slate-900 dark:text-white cursor-pointer">{c.refId}</button>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                  {c.reason === 'DATE_SPREAD' ? `Hasat tarihleri: ${c.dates.map(fmtD).join(', ')}` : c.variants.map(v => `${cleanName(v.product)} · ${cleanName(v.orchard)}`).join('  |  ')}
                </div>
              </li>
            ))}
          </ul>
          {conflicts.length > 5 && (
            <button type="button" onClick={() => setShowAll(v => !v)} className="mt-2 text-xs font-bold text-rose-800 dark:text-rose-200 cursor-pointer">{showAll ? 'Daha az göster' : `Tümünü göster (${conflicts.length})`}</button>
          )}
        </section>
      )}

      <ColdChainPanel
        references={p.references} harvestRecords={p.harvestRecords} ambarRecords={p.ambarRecords}
        lojistikRecords={p.lojistikRecords} salesRecords={p.salesRecords}
        currentUserName={p.currentUserName} isReadOnly={p.isReadOnly}
        onOpenRecord={p.onOpenRecord} onOpenPrecooling={p.onOpenPrecooling}
        onAddBalanceAdjustment={p.onAddBalanceAdjustment}
      />
    </div>
  );
}
