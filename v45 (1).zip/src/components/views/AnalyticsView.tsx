import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  Layers,
  Percent,
  CalendarDays,
  ShoppingBag,
  Snowflake,
  Warehouse,
  Filter,
  CheckCircle2,
  Scale,
  Award,
  Apple,
  Banana,
  Nut,
  Truck,
  PlusCircle,
  FileSpreadsheet,
  ArrowUpRight,
  Clock,
  Sparkles,
  Check,
  Search,
  ExternalLink,
  Thermometer,
  Download,
  ChevronDown,
  X
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  FreezeDryRecord,
  IncidentRecord,
  ExportSampleRecord,
  SalesRecord,
  ModuleKey
} from '../../types';
import { calculateColdRoomStats, calculateBademAnalytics, exportComprehensivePivotDataset } from '../../utils/calculations';
import { exportFilteredAnalytics, ExportFormat } from '../../utils/exportHelpers';
import { HarvestAnalyticsSection } from '../analytics/HarvestAnalyticsSection';
import { FreshProduceBenchmarkModal } from '../modals/FreshProduceBenchmarkModal';
import { DateRangePicker, DateRangeState } from '../analytics/DateRangePicker';

interface AnalyticsViewProps {
  stats?: any;
  fieldBreakdown?: any;
  references?: ReferenceItem[];
  harvestRecords?: HarvestRecord[];
  fieldRecords?: FieldRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  lojistikRecords?: LojistikRecord[];
  ambarRecords?: AmbarRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  exportSampleRecords?: ExportSampleRecord[];
  salesRecords?: SalesRecord[];
  incidentRecords?: IncidentRecord[];
  onSelectModule?: (moduleKey: ModuleKey, action?: 'NEW' | 'EXISTING') => void;
  onSelectReference?: (refId: string) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onOpenTraceability?: (ref: ReferenceItem) => void;
  onOpenFieldTest?: (refId: string) => void;
  currentUserId?: string;
  initialTab?: 'QUALITY_TOOLS' | 'TRACKING_TOOLS';
}

const QUALITY_PALETTE = ['#10b981', '#06b6d4', '#f59e0b', '#8b5cf6', '#ef4444'];

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  references = [],
  harvestRecords = [],
  fieldRecords = [],
  muzRecords = [],
  bademRecords = [],
  lojistikRecords = [],
  ambarRecords = [],
  freezeDryRecords = [],
  exportSampleRecords = [],
  salesRecords = [],
  incidentRecords = [],
  onSelectModule,
  onSelectReference,
  initialTab = 'QUALITY_TOOLS'
}) => {
  const [activeCategory, setActiveCategory] = useState<'QUALITY_TOOLS' | 'TRACKING_TOOLS'>(initialTab === 'TRACKING_TOOLS' ? 'TRACKING_TOOLS' : 'QUALITY_TOOLS');
  const [qualitySubTab, setQualitySubTab] = useState<'FIELD' | 'MUZ' | 'BADEM' | 'INCIDENT' | 'FREEZE_EXPORT'>('FIELD');
  const [trackingSubTab, setTrackingSubTab] = useState<'HARVEST' | 'COLD_ROOM' | 'LOGISTICS_SALES'>('HARVEST');
  const [filterSearch, setFilterSearch] = useState('');
  const [showBenchmarkModal, setShowBenchmarkModal] = useState(false);

  // 0. DATE RANGE FILTER STATE & LOGIC
  const [dateRange, setDateRange] = useState<DateRangeState>({
    preset: 'ALL',
    startDate: '',
    endDate: ''
  });

  const isDateInRange = useMemo(() => {
    return (dateStr?: string) => {
      if (!dateStr) return dateRange.preset === 'ALL';
      if (dateRange.preset === 'ALL' && !dateRange.startDate && !dateRange.endDate) return true;

      const dateOnly = dateStr.slice(0, 10);
      if (dateRange.startDate && dateOnly < dateRange.startDate) return false;
      if (dateRange.endDate && dateOnly > dateRange.endDate) return false;
      return true;
    };
  }, [dateRange]);

  // Filtered Datasets based on selected Date Range
  const filteredReferences = useMemo(() => {
    return references.filter(r => isDateInRange(r.createdAt || (r as any).timestamp));
  }, [references, isDateInRange]);

  const filteredHarvestRecords = useMemo(() => {
    return harvestRecords.filter(h => isDateInRange(h.recordDate || h.timestamp));
  }, [harvestRecords, isDateInRange]);

  const filteredFieldRecords = useMemo(() => {
    return fieldRecords.filter(f => isDateInRange(f.harvestDate || f.timestamp));
  }, [fieldRecords, isDateInRange]);

  const filteredMuzRecords = useMemo(() => {
    return muzRecords.filter(m => isDateInRange(m.timestamp));
  }, [muzRecords, isDateInRange]);

  const filteredBademRecords = useMemo(() => {
    return bademRecords.filter(b => isDateInRange(b.timestamp || b.waterCutOffDate));
  }, [bademRecords, isDateInRange]);

  const filteredLojistikRecords = useMemo(() => {
    return lojistikRecords.filter(l => isDateInRange(l.timestamp));
  }, [lojistikRecords, isDateInRange]);

  const filteredAmbarRecords = useMemo(() => {
    return ambarRecords.filter(a => isDateInRange(a.timestamp));
  }, [ambarRecords, isDateInRange]);

  const filteredFreezeDryRecords = useMemo(() => {
    return freezeDryRecords.filter(fd => isDateInRange(fd.processDate || fd.timestamp));
  }, [freezeDryRecords, isDateInRange]);

  const filteredExportSampleRecords = useMemo(() => {
    return exportSampleRecords.filter(es => isDateInRange(es.testDate || es.timestamp));
  }, [exportSampleRecords, isDateInRange]);

  const filteredSalesRecords = useMemo(() => {
    return salesRecords.filter(s => isDateInRange(s.timestamp));
  }, [salesRecords, isDateInRange]);

  const filteredIncidentRecords = useMemo(() => {
    return incidentRecords.filter(i => isDateInRange(i.timestamp));
  }, [incidentRecords, isDateInRange]);

  const totalFilteredCount = filteredReferences.length + filteredHarvestRecords.length + filteredFieldRecords.length;
  const totalAllCount = references.length + harvestRecords.length + fieldRecords.length;

  // Export State & Toast
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [exportToast, setExportToast] = useState<{ message: string; filename: string } | null>(null);

  const totalAnalyticsRecordsCount = useMemo(() => {
    return (
      filteredHarvestRecords.length +
      filteredFieldRecords.length +
      filteredMuzRecords.length +
      filteredBademRecords.length +
      filteredLojistikRecords.length +
      filteredAmbarRecords.length +
      filteredFreezeDryRecords.length +
      filteredExportSampleRecords.length +
      filteredSalesRecords.length +
      filteredIncidentRecords.length
    );
  }, [
    filteredHarvestRecords,
    filteredFieldRecords,
    filteredMuzRecords,
    filteredBademRecords,
    filteredLojistikRecords,
    filteredAmbarRecords,
    filteredFreezeDryRecords,
    filteredExportSampleRecords,
    filteredSalesRecords,
    filteredIncidentRecords
  ]);

  const handleExportAnalytics = (format: ExportFormat = 'EXCEL', onlyActiveCategory: boolean = false) => {
    setShowExportMenu(false);
    const categoryLabel = activeCategory === 'QUALITY_TOOLS' ? `Kalite_${qualitySubTab}` : `Izlenebilirlik_${trackingSubTab}`;

    const res = exportFilteredAnalytics({
      references: filteredReferences,
      harvestRecords: (onlyActiveCategory && trackingSubTab !== 'HARVEST') ? [] : filteredHarvestRecords,
      fieldRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'FIELD')) ? [] : filteredFieldRecords,
      muzRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'MUZ')) ? [] : filteredMuzRecords,
      bademRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'BADEM')) ? [] : filteredBademRecords,
      lojistikRecords: (onlyActiveCategory && (activeCategory !== 'TRACKING_TOOLS' || trackingSubTab !== 'LOGISTICS_SALES')) ? [] : filteredLojistikRecords,
      ambarRecords: (onlyActiveCategory && (activeCategory !== 'TRACKING_TOOLS' || trackingSubTab !== 'COLD_ROOM')) ? [] : filteredAmbarRecords,
      freezeDryRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'FREEZE_EXPORT')) ? [] : filteredFreezeDryRecords,
      exportSampleRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'FREEZE_EXPORT')) ? [] : filteredExportSampleRecords,
      salesRecords: (onlyActiveCategory && (activeCategory !== 'TRACKING_TOOLS' || trackingSubTab !== 'LOGISTICS_SALES')) ? [] : filteredSalesRecords,
      incidentRecords: (onlyActiveCategory && (activeCategory !== 'QUALITY_TOOLS' || qualitySubTab !== 'INCIDENT')) ? [] : filteredIncidentRecords,
      format,
      activeCategoryName: onlyActiveCategory ? categoryLabel : 'Tum_Moduller'
    });

    if (res.success) {
      setExportToast({
        message: `${res.count} adet filtrelenmiş analitik veri kaydı (${format === 'EXCEL' ? 'Excel CSV (;)' : 'Standart CSV (,)'}) formatında indirildi.`,
        filename: res.filename
      });
      setTimeout(() => setExportToast(null), 4000);
    }
  };

  // 1. Cold Room Analytics (Filtered)
  const coldRoomAnalytics = useMemo(() => {
    return calculateColdRoomStats(filteredAmbarRecords, filteredLojistikRecords, filteredSalesRecords, []);
  }, [filteredAmbarRecords, filteredLojistikRecords, filteredSalesRecords]);

  // 2. Badem Analytics (Filtered)
  const bademAnalytics = useMemo(() => {
    return calculateBademAnalytics(filteredBademRecords);
  }, [filteredBademRecords]);

  // 3. Quality Grades Breakdown (Filtered)
  const qualityGradeStats = useMemo(() => {
    const gradeCounts: Record<string, number> = {
      'Ekstra Sınıf': 0,
      '1. Sınıf': 0,
      '2. Sınıf': 0,
      'Mix / Standart': 0,
      'Iskarta / Sanayi': 0
    };

    filteredReferences.forEach(r => {
      const g = (r.kaliteSinifi || '').toLowerCase();
      if (g.includes('extra') || g.includes('ekstra') || g.includes('v-20')) gradeCounts['Ekstra Sınıf'] += 1;
      else if (g.includes('1') || g.includes('exc') || g.includes('v-22')) gradeCounts['1. Sınıf'] += 1;
      else if (g.includes('2') || g.includes('prm') || g.includes('v-24')) gradeCounts['2. Sınıf'] += 1;
      else if (g.includes('iskarta') || g.includes('sanayi') || g.includes('dış')) gradeCounts['Iskarta / Sanayi'] += 1;
      else gradeCounts['Mix / Standart'] += 1;
    });

    const pieData = Object.entries(gradeCounts).map(([name, value]) => ({ name, value }));
    const totalCount = filteredReferences.length;
    const highQualityCount = gradeCounts['Ekstra Sınıf'] + gradeCounts['1. Sınıf'];
    const qualityScorePct = totalCount > 0 ? Math.round((highQualityCount / totalCount) * 100) : 0;

    return { gradeCounts, pieData, qualityScorePct, totalCount };
  }, [filteredReferences]);

  // 4. Field Quality (Brix, Hardness, Diameter) (Filtered - Cold-Start Ready)
  const fieldQualityStats = useMemo(() => {
    if (filteredFieldRecords.length === 0) {
      return {
        avgBrix: 0,
        avgHardness: 0,
        avgDiameter: 0,
        nitratePassCount: 0,
        totalTests: 0,
        chartData: []
      };
    }

    const totalBrix = filteredFieldRecords.reduce((s, f) => s + (f.avgBrix || 0), 0);
    const totalHardness = filteredFieldRecords.reduce((s, f) => s + (f.avgHardness || 0), 0);
    const totalDiameter = filteredFieldRecords.reduce((s, f) => s + (f.avgDiameter || 0), 0);
    const nitratePass = filteredFieldRecords.filter(f => f.nitratePass !== false).length;

    const chartData = filteredFieldRecords.slice(0, 8).map(f => ({
      name: `${f.sortVariety || f.product} (${f.refId.slice(-4)})`,
      brix: f.avgBrix || 0,
      hardness: f.avgHardness || 0,
      diameter: f.avgDiameter || 0
    }));

    return {
      avgBrix: Number((totalBrix / filteredFieldRecords.length).toFixed(1)),
      avgHardness: Number((totalHardness / filteredFieldRecords.length).toFixed(1)),
      avgDiameter: Number((totalDiameter / filteredFieldRecords.length).toFixed(1)),
      nitratePassCount: nitratePass,
      totalTests: filteredFieldRecords.length,
      chartData
    };
  }, [filteredFieldRecords]);

  // 5. Banana Quality (Filtered - Cold-Start Ready)
  const muzQualityStats = useMemo(() => {
    if (filteredMuzRecords.length === 0) {
      return {
        avgCalibration: 0,
        avgFingerLength: 0,
        avgScale: 0,
        totalMuzTests: 0
      };
    }
    const calib = filteredMuzRecords.reduce((s, m) => s + (m.calibrationMm || 0), 0) / filteredMuzRecords.length;
    const len = filteredMuzRecords.reduce((s, m) => s + (m.fingerLengthCm || 0), 0) / filteredMuzRecords.length;
    const scale = filteredMuzRecords.reduce((s, m) => s + (m.ripenessScale || 0), 0) / filteredMuzRecords.length;
    return {
      avgCalibration: Number(calib.toFixed(1)),
      avgFingerLength: Number(len.toFixed(1)),
      avgScale: Number(scale.toFixed(1)),
      totalMuzTests: filteredMuzRecords.length
    };
  }, [filteredMuzRecords]);

  // 6. Incidents & Barlag Akty + Pareto Kusur Analizi (80/20 Kuralı)
  const incidentStats = useMemo(() => {
    const total = filteredIncidentRecords.length;
    const critical = filteredIncidentRecords.filter(i => (i.actDegree as any) === 1 || (i.actDegree as any) === '1' || (i as any).priority === 'CRITICAL').length;
    const medium = filteredIncidentRecords.filter(i => (i.actDegree as any) === 2 || (i.actDegree as any) === '2' || (i as any).priority === 'HIGH' || (i as any).priority === 'MEDIUM').length;
    const low = filteredIncidentRecords.filter(i => (i.actDegree as any) === 3 || (i.actDegree as any) === '3' || (i as any).priority === 'LOW').length;
    const resolved = filteredIncidentRecords.filter(i => i.status === 'RESOLVED').length;
    const affectedKg = filteredIncidentRecords.reduce((s, i) => s + (Number(i.affectedQuantityKg) || 0), 0);
    const resolveRate = total > 0 ? Math.round((resolved / total) * 100) : 0;

    // Pareto 80/20 Defect Aggregation across Barlag Akty, Muz, Badem & Field records
    const defectMap: Record<string, number> = {};
    filteredIncidentRecords.forEach(inc => {
      const key = inc.incidentType || 'Genel Kalite Sapması';
      defectMap[key] = (defectMap[key] || 0) + Math.max(1, Number(inc.affectedQuantityKg) || 10);
    });
    filteredMuzRecords.forEach(m => {
      if (m.pulpTemperatureC !== undefined && m.pulpTemperatureC < 11.0) {
        defectMap['Soğuk Zararı (<11°C Chilling)'] = (defectMap['Soğuk Zararı (<11°C Chilling)'] || 0) + 15;
      }
      if (m.flowerEndDefect) {
        defectMap['Taç Çürüklüğü (Crown Rot)'] = (defectMap['Taç Çürüklüğü (Crown Rot)'] || 0) + 12;
      }
      if (m.mechanicalDamage) {
        defectMap['Mekanik Zedelenme / Sürtünme'] = (defectMap['Mekanik Zedelenme / Sürtünme'] || 0) + 10;
      }
    });
    filteredBademRecords.forEach(b => {
      if (b.seriousDefectPercent > 0) {
        defectMap['Badem İç Kusur / İkiz-Kırık'] = (defectMap['Badem İç Kusur / İkiz-Kırık'] || 0) + Math.round(b.seriousDefectPercent * 10);
      }
    });
    filteredFieldRecords.forEach(f => {
      if (f.nitratePass === false) {
        defectMap['Nitrat Limit Aşımı (mg/kg)'] = (defectMap['Nitrat Limit Aşımı (mg/kg)'] || 0) + 20;
      }
    });

    const sortedDefects = Object.entries(defectMap).sort((a, b) => b[1] - a[1]);
    const totalDefectWeight = sortedDefects.reduce((acc, [, v]) => acc + v, 0);
    let runningTotal = 0;
    const paretoChartData = sortedDefects.map(([name, count]) => {
      runningTotal += count;
      return {
        name,
        KusurMiktari: count,
        KumulatifYuzde: totalDefectWeight > 0 ? Math.round((runningTotal / totalDefectWeight) * 100) : 0
      };
    });

    return { total, critical, medium, low, resolved, affectedKg, resolveRate, paretoChartData };
  }, [filteredIncidentRecords, filteredMuzRecords, filteredBademRecords, filteredFieldRecords]);

  // 7. Harvest Performance (Filtered)
  const harvestStats = useMemo(() => {
    const totalKg = filteredHarvestRecords.reduce((s, h) => s + (h.dailyTotalKg || 0), 0);
    const totalWorkers = filteredHarvestRecords.reduce((s, h) => s + (h.workerCount || 0), 0);
    const avgKgPerWorker = totalWorkers > 0 ? Math.round(totalKg / totalWorkers) : 0;

    const orchardMap: Record<string, number> = {};
    filteredHarvestRecords.forEach(h => {
      const o = h.orchard || h.location || 'Garahan';
      orchardMap[o] = (orchardMap[o] || 0) + h.dailyTotalKg;
    });

    const chartData = Object.entries(orchardMap).map(([name, kg]) => ({
      name,
      Tonaj: +(kg / 1000).toFixed(2),
      kg
    }));

    return { totalKg, totalWorkers, avgKgPerWorker, recordCount: filteredHarvestRecords.length, chartData };
  }, [filteredHarvestRecords]);

  // 8. Sales & Logistics (Filtered)
  const salesLogisticsStats = useMemo(() => {
    const totalSalesKg = filteredSalesRecords.reduce((s, sl) => s + (sl.totalQuantityKg || 0), 0);
    const totalCases = filteredSalesRecords.reduce((s, sl) => s + (sl.totalCases || 0), 0);
    const totalLogisticsVehicles = filteredLojistikRecords.length;

    const customerSalesMap: Record<string, number> = {};
    filteredSalesRecords.forEach(s => {
      const c = s.customer || 'Yerel Market';
      customerSalesMap[c] = (customerSalesMap[c] || 0) + s.totalQuantityKg;
    });

    const chartData = Object.entries(customerSalesMap).map(([customer, kg]) => ({
      customer: customer.length > 14 ? customer.slice(0, 12) + '...' : customer,
      Tonaj: +(kg / 1000).toFixed(2),
      kg
    }));

    return { totalSalesKg, totalCases, totalLogisticsVehicles, salesCount: filteredSalesRecords.length, chartData };
  }, [filteredSalesRecords, filteredLojistikRecords]);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* 1. TOP HEADER & MAIN TAB SWITCHER */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase bg-teal-500/20 text-teal-300 border border-teal-500/40">
              📊 Kalite & İzlenebilirlik Analitiği
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
              Anlaşılır & Denetlenebilir Görünüm
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-teal-400" />
            <span>Kalite Araçları & İzlenebilirlik Analiz Panosu</span>
          </h2>
          <p className="text-xs text-slate-300">
            Sadece kalite testleri, depo bekleme süreleri, bahçe hasatları ve lojistik sevkiyat hareketlerine odaklanan sadeleştirilmiş özet.
          </p>
        </div>

        {/* Category Switcher & Export */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700 flex-wrap">
            <button
              type="button"
              onClick={() => setActiveCategory('QUALITY_TOOLS')}
              className={`px-3.5 py-2 rounded-lg text-xs font-black transition flex items-center gap-2 cursor-pointer ${
                activeCategory === 'QUALITY_TOOLS'
                  ? 'bg-emerald-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Award className="w-4 h-4 text-emerald-950" />
              <span>🔬 Kalite Araçları</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveCategory('TRACKING_TOOLS')}
              className={`px-3.5 py-2 rounded-lg text-xs font-black transition flex items-center gap-2 cursor-pointer ${
                activeCategory === 'TRACKING_TOOLS'
                  ? 'bg-teal-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Warehouse className="w-4 h-4 text-emerald-950" />
              <span>📦 İzlenebilirlik</span>
            </button>
          </div>

          {/* FOODREADY 2026 & GOST BENCHMARK MODAL TRIGGER BUTTON */}
          <button
            type="button"
            onClick={() => setShowBenchmarkModal(true)}
            className="px-3.5 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black rounded-xl transition flex items-center gap-1.5 shadow-sm cursor-pointer btn-tactile"
            title="FoodReady 2026 Dünya Sıralaması Kıyaslaması ve Avrasya/GOST İthalat Kabul Rehberi"
          >
            <Award className="w-3.5 h-3.5 text-slate-950" />
            <span>FoodReady 2026 &amp; GOST Rehberi</span>
          </button>

          {/* EXCEL / CSV ANALYTICS EXPORT BUTTON & DROPDOWN */}
          <div className="relative">
            <div className="inline-flex rounded-xl shadow-xs border border-emerald-500/50 overflow-hidden">
              <button
                type="button"
                onClick={() => handleExportAnalytics('EXCEL', false)}
                className="px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer btn-tactile"
                title="Tüm filtrelenmiş analitik verileri Excel pivot uyumlu CSV olarak indir (Çevrimdışı analiz için)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                <span>Excel / CSV İndir ({totalAnalyticsRecordsCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="px-2 py-2 bg-emerald-800 hover:bg-emerald-700 text-emerald-100 border-l border-emerald-500/60 text-xs transition cursor-pointer flex items-center justify-center"
                title="Dışa aktarma formatını ve kapsamını seç"
                aria-label="Analitik dışa aktarma menüsü"
              >
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-150 ${showExportMenu ? 'rotate-180' : ''}`} />
              </button>
            </div>

            {/* Dropdown Menu */}
            {showExportMenu && (
              <div
                className="absolute right-0 top-full mt-1.5 w-80 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 p-1.5 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-100 text-white"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-2.5 py-1.5 border-b border-slate-800 font-mono text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
                  <span>Çevrimdışı Analiz Veri Seti</span>
                  <span className="text-emerald-400 font-mono">{totalAnalyticsRecordsCount} Kayıt</span>
                </div>

                <button
                  type="button"
                  onClick={() => handleExportAnalytics('EXCEL', false)}
                  className="w-full text-left p-2 hover:bg-slate-800 rounded-lg text-slate-200 flex items-start gap-2.5 cursor-pointer transition"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-xs flex items-center justify-between">
                      <span>Excel Pivot Uyumlu (.csv)</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-black">Önerilen</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                      Noktalı virgül (;) • UTF-8 BOM • Excel Pivot Tabloları &amp; Grafikler için hazır
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleExportAnalytics('CSV', false)}
                  className="w-full text-left p-2 hover:bg-slate-800 rounded-lg text-slate-200 flex items-start gap-2.5 cursor-pointer transition"
                >
                  <Download className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-xs">Standart CSV (.csv)</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                      Virgül (,) • RFC 4180 • Google E-Tablolar &amp; Power BI uyumlu
                    </div>
                  </div>
                </button>

                <div className="pt-1 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => handleExportAnalytics('EXCEL', true)}
                    className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800 rounded-lg text-amber-300 flex items-center gap-2 cursor-pointer transition text-xs font-semibold"
                  >
                    <Filter className="w-3.5 h-3.5 text-amber-400" />
                    <span>Sadece Geçerli Sekmeyi Aktar (Aktif Kategori)</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* DATE RANGE FILTER PICKER COMPONENT */}
      <DateRangePicker
        value={dateRange}
        onChange={setDateRange}
        totalFilteredCount={totalFilteredCount}
        totalAllCount={totalAllCount}
      />

      {/* Export Success Notification Banner */}
      {exportToast && (
        <div className="p-3 bg-gradient-to-r from-emerald-950/90 to-teal-950/90 border border-emerald-500/70 rounded-xl flex items-center justify-between gap-3 text-xs text-emerald-100 shadow-md animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 font-black shadow-2xs">
              ✓
            </div>
            <div>
              <span className="font-bold">{exportToast.message}</span>
              <span className="text-[11px] text-emerald-300 font-mono ml-2 block sm:inline">
                Dosya: {exportToast.filename}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setExportToast(null)}
            className="p-1 hover:bg-emerald-900 rounded-lg text-emerald-300 cursor-pointer transition"
            title="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2. TOP EXECUTIVE 4-CARD OVERVIEW */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-emerald-200 p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-emerald-800 text-xs font-bold mb-1">
            <span>KALİTE SKORU (UNECE)</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-950 font-mono">
            %{qualityGradeStats.qualityScorePct}
          </div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-1">
            Ekstra + 1. Sınıf Oranı ({qualityGradeStats.totalCount} Parti)
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold mb-1">
            <span>TOPLAM SAHA HASADI</span>
            <CalendarDays className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {(harvestStats.totalKg / 1000).toFixed(1)} <span className="text-xs text-slate-500">Ton</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {harvestStats.recordCount} Hasat Partisi • {harvestStats.totalWorkers} İşçi
          </div>
        </div>

        <div className="bg-white rounded-xl border border-cyan-200 p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-cyan-800 text-xs font-bold mb-1">
            <span>SOĞUK DEPO STOĞU</span>
            <Warehouse className="w-4 h-4 text-cyan-600" />
          </div>
          <div className="text-2xl font-black text-cyan-950 font-mono">
            {coldRoomAnalytics.overallStats.totalStockTons} <span className="text-xs text-cyan-700">Ton</span>
          </div>
          <div className="text-[11px] text-cyan-800 font-semibold mt-1">
            Ort. {coldRoomAnalytics.overallStats.avgWaitDays} Gün Bekleme • {coldRoomAnalytics.overallStats.activeRoomCount} Aktif Oda
          </div>
        </div>

        <div className="bg-white rounded-xl border border-rose-200 p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-rose-800 text-xs font-bold mb-1">
            <span>BARLAG AKTY & DÖF</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-950 font-mono">
            {incidentStats.total} <span className="text-xs text-slate-500">Kayıt</span>
          </div>
          <div className="text-[11px] text-rose-700 font-semibold mt-1">
            %{incidentStats.resolveRate} Çözüldü ({incidentStats.critical} Kritik)
          </div>
        </div>
      </div>


      {/* ========================================================================= */}
      {/* SÜTUN 1: KALİTE ARAÇLARI (QUALITY TOOLS ANALİZİ)                           */}
      {/* ========================================================================= */}
      {activeCategory === 'QUALITY_TOOLS' && (
        <div className="space-y-4">
          {/* Sub-tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setQualitySubTab('FIELD')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                qualitySubTab === 'FIELD'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Apple className="w-3.5 h-3.5" />
              <span>Meyve Kalite (Brix & Sertlik)</span>
            </button>

            <button
              type="button"
              onClick={() => setQualitySubTab('MUZ')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                qualitySubTab === 'MUZ'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Banana className="w-3.5 h-3.5" />
              <span>Muz Kalite & Kalibrasyon</span>
            </button>

            <button
              type="button"
              onClick={() => setQualitySubTab('BADEM')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                qualitySubTab === 'BADEM'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Nut className="w-3.5 h-3.5" />
              <span>Badem Randıman (%) & Nem</span>
            </button>

            <button
              type="button"
              onClick={() => setQualitySubTab('INCIDENT')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                qualitySubTab === 'INCIDENT'
                  ? 'bg-rose-700 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Barlag Akty & Kalite Sapmaları</span>
            </button>

            <button
              type="button"
              onClick={() => setQualitySubTab('FREEZE_EXPORT')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                qualitySubTab === 'FREEZE_EXPORT'
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Snowflake className="w-3.5 h-3.5" />
              <span>Freeze-Dry &amp; İhracat Numune</span>
            </button>

            <button
              type="button"
              onClick={() => handleExportAnalytics('EXCEL', true)}
              className="ml-auto px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-50 dark:hover:bg-slate-700 flex items-center gap-1.5 cursor-pointer shrink-0 shadow-2xs btn-tactile"
              title="Sadece seçili kalite araçları sekmesinin kayıtlarını Excel olarak indir"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden sm:inline">Bu Sekmeyi Excel'e İndir</span>
              <span className="sm:hidden">Excel</span>
            </button>
          </div>

          {/* 1. MEYVE KALİTE TESTLERİ */}
          {qualitySubTab === 'FIELD' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-rose-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-rose-700 block">Ortalama Brix (°Bx)</span>
                  <div className="text-2xl font-black text-rose-600 font-mono mt-1">{fieldQualityStats.avgBrix} °Bx</div>
                  <div className="text-[10px] text-slate-500 mt-1">Şeker oranı ortalaması</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-blue-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-blue-700 block">Penetrometre Sertlik</span>
                  <div className="text-2xl font-black text-blue-600 font-mono mt-1">{fieldQualityStats.avgHardness} <span className="text-xs">kg/cm²</span></div>
                  <div className="text-[10px] text-slate-500 mt-1">Meyve et sertliği</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 block">Ortalama Çap</span>
                  <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{fieldQualityStats.avgDiameter} <span className="text-xs">mm</span></div>
                  <div className="text-[10px] text-slate-500 mt-1">Kalibre standart boyu</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Toplam Test</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{fieldQualityStats.totalTests} <span className="text-xs text-slate-500">Test</span></div>
                  <div className="text-[10px] text-slate-500 mt-1">Laboratuvar & Saha</div>
                </div>
              </div>

              {/* Chart & Quality Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                      Meyve Kalite Ölçümleri (Brix vs. Sertlik)
                    </h4>
                    {onSelectModule && (
                      <button
                        type="button"
                        onClick={() => onSelectModule('FIELD', 'NEW')}
                        className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 text-[11px] font-bold hover:bg-rose-100 flex items-center gap-1 cursor-pointer"
                      >
                        <PlusCircle className="w-3 h-3" />
                        <span>+ Yeni Test Gir</span>
                      </button>
                    )}
                  </div>
                  <div className="h-60 w-full">
                    {fieldQualityStats.chartData.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <p className="text-xs font-bold text-slate-600">⏳ Sıfır Veri / Veri Bekleniyor</p>
                        <p className="text-[11px] text-slate-400 mt-1">
                          İlk gerçek Meyve Kalite (Brix & Penetrometre) testi girildiğinde grafik otomatik hesaplanacaktır.
                        </p>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={fieldQualityStats.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                          <YAxis tick={{ fontSize: 10 }} />
                          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                          <Legend wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="brix" name="Brix (°Bx)" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="hardness" name="Sertlik (kg/cm²)" fill="#0284c7" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider mb-2">
                    UNECE Kalite Sınıfı Dağılımı
                  </h4>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={qualityGradeStats.pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={65}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {qualityGradeStats.pieData.map((_, i) => (
                            <Cell key={i} fill={QUALITY_PALETTE[i % QUALITY_PALETTE.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-1 text-[11px] font-medium divide-y divide-slate-100 mt-1">
                    {Object.entries(qualityGradeStats.gradeCounts).map(([g, cnt], idx) => (
                      <div key={g} className="flex justify-between py-1">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: QUALITY_PALETTE[idx % QUALITY_PALETTE.length] }} />
                          <span>{g}:</span>
                        </span>
                        <strong>{cnt} Parti</strong>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. MUZ KALİTE & KALİBRASYON */}
          {qualitySubTab === 'MUZ' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-amber-700 block">Ortalama Kalibre</span>
                  <div className="text-2xl font-black text-amber-600 font-mono mt-1">{muzQualityStats.avgCalibration} mm</div>
                  <div className="text-[10px] text-slate-500 mt-1">Standart: 39 - 44 mm</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 block">Parmak Boyu</span>
                  <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{muzQualityStats.avgFingerLength} cm</div>
                  <div className="text-[10px] text-slate-500 mt-1">Standart: 20 - 24 cm</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Olgunluk Skalası</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{muzQualityStats.avgScale} / 7</div>
                  <div className="text-[10px] text-slate-500 mt-1">1-2 Yeşil Hasat Eşiği</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Toplam Muz Testi</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{muzQualityStats.totalMuzTests} Kayıt</div>
                  <div className="text-[10px] text-slate-500 mt-1">MAP & KMnO4 Kontrollü</div>
                </div>
              </div>

              {/* Muz Tablosu */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Muz Kalite Kontrol Partileri
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('MUZ', 'NEW')}
                      className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-900 text-[11px] font-bold hover:bg-amber-100 flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>+ Yeni Muz Testi</span>
                    </button>
                  )}
                </div>
                {muzRecords.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">Henüz muz kalite kaydı girilmemiş.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-[10px] font-bold text-slate-600 uppercase border-b">
                        <tr>
                          <th className="py-2 px-3">RefID</th>
                          <th className="py-2 px-3">Sera</th>
                          <th className="py-2 px-3">Şerit Rengi</th>
                          <th className="py-2 px-3">Kalibrasyon</th>
                          <th className="py-2 px-3">Parmak Boyu</th>
                          <th className="py-2 px-3">Skala</th>
                          <th className="py-2 px-3 text-right">Net Kg</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-mono">
                        {muzRecords.map((m, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="py-2 px-3 font-bold text-teal-700">{m.refId}</td>
                            <td className="py-2 px-3 font-sans">{m.greenhouseNo}</td>
                            <td className="py-2 px-3 font-sans">{m.ribbonColor || '—'}</td>
                            <td className="py-2 px-3">{m.calibrationMm} mm</td>
                            <td className="py-2 px-3">{m.fingerLengthCm} cm</td>
                            <td className="py-2 px-3">{m.ripenessScale} / 7</td>
                            <td className="py-2 px-3 text-right font-bold">{m.netWeightKg?.toLocaleString('tr-TR')} kg</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. BADEM LAB & RANDIMAN */}
          {qualitySubTab === 'BADEM' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-orange-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-orange-700 block">İç Randıman %</span>
                  <div className="text-2xl font-black text-orange-600 font-mono mt-1">%{bademAnalytics.avgYieldPercent}</div>
                  <div className="text-[10px] text-slate-500 mt-1">İç / Kabuklu Ağırlık</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 block">Ortalama Nem</span>
                  <div className="text-2xl font-black text-emerald-600 font-mono mt-1">%{bademAnalytics.avgMoisturePercent}</div>
                  <div className="text-[10px] text-slate-500 mt-1">Hedef: &le; %6.0 Nem</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-rose-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-rose-700 block">Kusur Oranı</span>
                  <div className="text-2xl font-black text-rose-600 font-mono mt-1">%{bademAnalytics.defectAverages.totalPercent}</div>
                  <div className="text-[10px] text-slate-500 mt-1">Ciddi Kusur: %{bademAnalytics.defectAverages.seriousPercent}</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Toplam Badem</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{(bademAnalytics.totalLoadKg / 1000).toFixed(1)} T</div>
                  <div className="text-[10px] text-slate-500 mt-1">{bademRecords.length} Parti Analiz Edildi</div>
                </div>
              </div>

              {/* Badem Çeşit Grafiği */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Badem Çeşitleri Randıman (%) ve Nem (%)
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('BADEM', 'NEW')}
                      className="px-2.5 py-1 rounded-lg bg-orange-50 text-orange-800 text-[11px] font-bold hover:bg-orange-100 flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>+ Yeni Badem Testi</span>
                    </button>
                  )}
                </div>
                <div className="h-60 w-full">
                  {bademAnalytics.varietyBreakdown.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                      <p className="text-xs font-bold text-slate-600">⏳ Sıfır Veri / Veri Bekleniyor</p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        İlk gerçek Badem Randıman ve Nem testi girildiğinde çeşit karşılaştırma grafiği aktifleşecektir.
                      </p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={bademAnalytics.varietyBreakdown} margin={{ top: 10, right: 10, left: -20, bottom: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="variety" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="avgYield" name="İç Randıman (%)" fill="#ea580c" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="avgMoisture" name="Nem Oranı (%)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 4. BARLAG AKTY & KALİTE SAPMALARI */}
          {qualitySubTab === 'INCIDENT' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-rose-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-rose-700 block">Toplam Olay</span>
                  <div className="text-2xl font-black text-rose-600 font-mono mt-1">{incidentStats.total} Adet</div>
                  <div className="text-[10px] text-slate-500 mt-1">{incidentStats.critical} Adet 1. Derece Kritik</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 block">DÖF Çözüm Oranı</span>
                  <div className="text-2xl font-black text-emerald-600 font-mono mt-1">%{incidentStats.resolveRate}</div>
                  <div className="text-[10px] text-slate-500 mt-1">{incidentStats.resolved} Olay Çözüldü</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-amber-700 block">Etkilenen Fire</span>
                  <div className="text-2xl font-black text-amber-600 font-mono mt-1">{(incidentStats.affectedKg / 1000).toFixed(2)} T</div>
                  <div className="text-[10px] text-slate-500 mt-1">{incidentStats.affectedKg.toLocaleString('tr-TR')} kg toplam</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Derece Dağılımı</span>
                  <div className="text-xs font-bold text-slate-800 mt-1.5 space-y-0.5">
                    <div>1. Derece: <span className="text-rose-600 font-mono">{incidentStats.critical}</span></div>
                    <div>2. Derece: <span className="font-mono">{incidentStats.medium}</span> • 3. Derece: <span className="font-mono">{incidentStats.low}</span></div>
                  </div>
                </div>
              </div>

              {/* Pareto Kusur Analizi (80/20 Kuralı) Grafiği */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                      📊 Pareto Kusur Analizi (80/20 Kuralı — Kümülatif Kalite Sapma Dağılımı)
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      En sık karşılaşılan kalite kusurlarının ağırlık ve kümülatif yüzde (%) etkisi
                    </p>
                  </div>
                </div>
                <div className="h-60 w-full">
                  {incidentStats.paretoChartData.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                      <p className="text-xs font-bold text-slate-600">⏳ Sıfır Veri / Veri Bekleniyor (Pareto Kusur Analizi)</p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        İlk gerçek Barlag Akty veya kalite kusur kaydı girildiğinde Pareto 80/20 eğrisi otomatik oluşturulacaktır.
                      </p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={incidentStats.paretoChartData} margin={{ top: 10, right: 15, left: -15, bottom: 15 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis yAxisId="left" tick={{ fontSize: 10 }} />
                        <YAxis yAxisId="right" orientation="right" domain={[0, 100]} unit="%" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Bar yAxisId="left" dataKey="KusurMiktari" name="Kusur Etki Puanı / Kg" fill="#e11d48" radius={[4, 4, 0, 0]} />
                        <Line yAxisId="right" type="monotone" dataKey="KumulatifYuzde" name="Kümülatif Pay (%)" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Olay Listesi */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Kalite Sapmaları & Barlag Akty Kütüğü
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('INCIDENT', 'NEW')}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 text-[11px] font-bold hover:bg-rose-100 flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>+ Yeni Barlag Akty</span>
                    </button>
                  )}
                </div>
                {incidentRecords.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">Kayıtlı kalite sapması bulunmuyor.</div>
                ) : (
                  <div className="divide-y divide-slate-100 text-xs">
                    {incidentRecords.map(inc => (
                      <div key={inc.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900 flex items-center gap-2">
                            <span className="font-mono text-rose-600">{inc.refId}</span>
                            <span>{inc.incidentType}</span>
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                              {inc.actDegree || inc.priority}. Derece
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{inc.description}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            inc.status === 'RESOLVED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {inc.status === 'RESOLVED' ? 'Çözüldü' : 'Devam Ediyor'}
                          </span>
                          <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                            {inc.affectedQuantityKg ? `${inc.affectedQuantityKg} kg` : '—'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 5. FREEZE-DRY & İHRACAT NUMUNE */}
          {qualitySubTab === 'FREEZE_EXPORT' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    ❄️ Freeze-Dry Liyofilizasyon Randımanı
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('FREEZE_DRY', 'NEW')}
                      className="px-2 py-1 rounded-lg bg-cyan-50 text-cyan-800 text-[11px] font-bold hover:bg-cyan-100 cursor-pointer"
                    >
                      + Yeni Freeze-Dry
                    </button>
                  )}
                </div>
                {freezeDryRecords.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">Freeze-dry kaydı bulunmuyor.</div>
                ) : (
                  <div className="space-y-2 text-xs">
                    {freezeDryRecords.slice(0, 5).map(fd => (
                      <div key={fd.id} className="p-2.5 bg-slate-50 rounded-xl flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">{fd.product} ({fd.refId})</div>
                          <div className="text-[10px] text-slate-500">Yaş: {fd.rawWeightKg} kg → Kuru: {fd.finalDryWeightKg} kg</div>
                        </div>
                        <span className="font-mono font-black text-cyan-700 text-sm">
                          %{fd.yieldRatioPercent || ((fd.finalDryWeightKg / (fd.rawWeightKg || 1)) * 100).toFixed(1)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    ✈️ İhracat Şahit Numune & Raf Ömrü
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('EXPORT_SAMPLE', 'NEW')}
                      className="px-2 py-1 rounded-lg bg-blue-50 text-blue-800 text-[11px] font-bold hover:bg-blue-100 cursor-pointer"
                    >
                      + Yeni İhracat Numune
                    </button>
                  )}
                </div>
                {exportSampleRecords.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">İhracat numune kaydı bulunmuyor.</div>
                ) : (
                  <div className="space-y-2 text-xs">
                    {exportSampleRecords.slice(0, 5).map(ex => (
                      <div key={ex.id} className="p-2.5 bg-slate-50 rounded-xl flex justify-between items-center">
                        <div>
                          <div className="font-bold text-slate-900">{ex.product} ({ex.destinationCountry})</div>
                          <div className="text-[10px] text-slate-500">Ağırlık Kaybı: %{ex.weightLossPercent} • Su Kaybı: %{ex.waterLossPercent}</div>
                        </div>
                        <span className="font-mono font-bold text-blue-600">
                          {ex.avgBrix}°Bx / {ex.avgHardness}kg
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SÜTUN 2: İZLENEBİLİRLİK VE TAKİP ARAÇLARI (TRACKING TOOLS ANALİZİ)          */}
      {/* ========================================================================= */}
      {activeCategory === 'TRACKING_TOOLS' && (
        <div className="space-y-4">
          {/* Sub-tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setTrackingSubTab('HARVEST')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                trackingSubTab === 'HARVEST'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Günlük Saha Hasat Takibi</span>
            </button>

            <button
              type="button"
              onClick={() => setTrackingSubTab('COLD_ROOM')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                trackingSubTab === 'COLD_ROOM'
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Warehouse className="w-3.5 h-3.5" />
              <span>Soğuk Hava Deposu & Bekleme Süreleri</span>
            </button>

            <button
              type="button"
              onClick={() => setTrackingSubTab('LOGISTICS_SALES')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                trackingSubTab === 'LOGISTICS_SALES'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Lojistik &amp; Ticari Satış Çıkışları</span>
            </button>

            <button
              type="button"
              onClick={() => handleExportAnalytics('EXCEL', true)}
              className="ml-auto px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-50 dark:hover:bg-slate-700 flex items-center gap-1.5 cursor-pointer shrink-0 shadow-2xs btn-tactile"
              title="Sadece seçili izlenebilirlik araçları sekmesinin kayıtlarını Excel olarak indir"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden sm:inline">Bu Sekmeyi Excel'e İndir</span>
              <span className="sm:hidden">Excel</span>
            </button>
          </div>

          {/* 1. GÜNLÜK SAHA HASAT TAKİBİ */}
          {trackingSubTab === 'HARVEST' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-emerald-700 block">Toplam Hasat</span>
                  <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{(harvestStats.totalKg / 1000).toFixed(2)} T</div>
                  <div className="text-[10px] text-slate-500 mt-1">{harvestStats.totalKg.toLocaleString('tr-TR')} kg net</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Hasat Partisi</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{harvestStats.recordCount} Parti</div>
                  <div className="text-[10px] text-slate-500 mt-1">Kantar kayıtları</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">İşçi Gücü</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{harvestStats.totalWorkers} Kişi</div>
                  <div className="text-[10px] text-slate-500 mt-1">Saha toplamı</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-teal-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-teal-700 block">Kişi Başı Verim</span>
                  <div className="text-2xl font-black text-teal-600 font-mono mt-1">{harvestStats.avgKgPerWorker} <span className="text-xs">kg/kişi</span></div>
                  <div className="text-[10px] text-slate-500 mt-1">Ortalama toplama hızı</div>
                </div>
              </div>

              {/* Bahçe Bazlı Grafiği */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Bahçe Bazlı Toplanan Hasat Miktarları (Ton)
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('HARVEST', 'NEW')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 text-[11px] font-bold hover:bg-emerald-100 flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>+ Yeni Hasat Gir</span>
                    </button>
                  )}
                </div>
                <div className="h-60 w-full">
                  {harvestStats.chartData.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                      <p className="text-xs font-bold text-slate-600">⏳ Sıfır Veri / Veri Bekleniyor (Kantar Verimlilik & Tonaj İlerleme)</p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        İlk gerçek Günlük Hasat / Kantar fişi girildiğinde bahçe bazlı kantar verimlilik grafiği ve tonaj ilerleme çubukları aktifleşecektir.
                      </p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={harvestStats.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                        <Bar dataKey="Tonaj" name="Toplam Hasat (Ton)" fill="#059669" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>

                {/* Tonaj İlerleme Çubukları (Tonnage Progress Bars) */}
                {harvestStats.chartData.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                    <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">
                      Parsel / Bahçe Tonaj İlerleme Çubukları
                    </span>
                    {harvestStats.chartData.map((row) => {
                      const pct = Math.min(100, Math.max(5, Math.round((row.kg / Math.max(1, harvestStats.totalKg)) * 100)));
                      return (
                        <div key={row.name} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="font-bold text-slate-700">{row.name}</span>
                            <span className="font-mono font-bold text-emerald-700">{row.Tonaj} Ton (%{pct})</span>
                          </div>
                          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-600 rounded-full transition-all" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. SOĞUK HAVA DEPOSU & BEKLEME SÜRELERİ */}
          {trackingSubTab === 'COLD_ROOM' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-cyan-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-cyan-700 block">Depo Stoğu</span>
                  <div className="text-2xl font-black text-cyan-600 font-mono mt-1">{coldRoomAnalytics.overallStats.totalStockTons} T</div>
                  <div className="text-[10px] text-slate-500 mt-1">{coldRoomAnalytics.overallStats.totalStockKg?.toLocaleString('tr-TR')} kg net</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Aktif Odalar</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{coldRoomAnalytics.overallStats.activeRoomCount} Oda</div>
                  <div className="text-[10px] text-slate-500 mt-1">Sıcaklık/Nem Kontrollü</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-amber-700 block">Ort. Bekleme</span>
                  <div className="text-2xl font-black text-amber-600 font-mono mt-1">{coldRoomAnalytics.overallStats.avgWaitDays} Gün</div>
                  <div className="text-[10px] text-slate-500 mt-1">Odada kalış süresi</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-rose-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-rose-700 block">En Uzun Bekleyen</span>
                  <div className="text-2xl font-black text-rose-600 font-mono mt-1">{coldRoomAnalytics.overallStats.longestWaiting?.waitDays || 0} Gün</div>
                  <div className="text-[10px] text-slate-500 mt-1 truncate">{coldRoomAnalytics.overallStats.longestWaiting?.product || 'Yok'}</div>
                </div>
              </div>

              {/* Oda Oda Özet Kartları ve Soğuk Depo Sıcaklık Göstergeleri */}
              {coldRoomAnalytics.rooms.length === 0 ? (
                <div className="bg-white p-6 rounded-2xl border border-dashed border-slate-200 text-center">
                  <Thermometer className="w-6 h-6 text-cyan-600 mx-auto mb-1.5 opacity-80" />
                  <p className="text-xs font-bold text-slate-700">
                    ⏳ Sıfır Veri / Veri Bekleniyor (Soğuk Depo Sıcaklık Göstergeleri & Oda Stokları)
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    İlk gerçek Ambar Kabul kaydı girildiğinde soğuk oda sıcaklık (°C), nem (%RH) göstergeleri ve bekleme süreleri otomatik hesaplanacaktır.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {coldRoomAnalytics.rooms.map((room, idx) => {
                    const roomItem = coldRoomAnalytics.stockItems.find(si => si.roomNo === room.roomNo);
                    const tempC = roomItem?.roomTemperature ?? 2.0;
                    const humPct = roomItem?.humidityPercent ?? 90;
                    return (
                      <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                        <div className="flex justify-between items-center border-b pb-2">
                          <span className="font-black text-slate-900 text-xs">{room.roomNo}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-100 text-cyan-900">
                            {room.totalTons} Ton
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] bg-cyan-50/70 px-2.5 py-1.5 rounded-lg border border-cyan-100">
                          <span className="flex items-center gap-1 font-bold text-cyan-900">
                            <Thermometer className="w-3.5 h-3.5 text-cyan-600" />
                            Oda Sıcaklığı: {tempC}°C
                          </span>
                          <span className="font-mono font-semibold text-cyan-700">Nem: %{humPct}</span>
                        </div>
                        <div className="space-y-1 text-xs">
                          {room.products.map((p, pIdx) => (
                            <div key={pIdx} className="flex justify-between text-[11px]">
                              <span className="text-slate-600">{p.product}:</span>
                              <span className="font-mono font-bold">{p.tons} Ton ({p.avgWaitDays} gün)</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 3. LOJİSTİK & TİCARİ SATIŞ ÇIKIŞLARI */}
          {trackingSubTab === 'LOGISTICS_SALES' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-indigo-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-indigo-700 block">Toplam Satış</span>
                  <div className="text-2xl font-black text-indigo-600 font-mono mt-1">{(salesLogisticsStats.totalSalesKg / 1000).toFixed(2)} T</div>
                  <div className="text-[10px] text-slate-500 mt-1">{salesLogisticsStats.totalSalesKg.toLocaleString('tr-TR')} kg sevk edildi</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Kasa / Koli</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{salesLogisticsStats.totalCases.toLocaleString('tr-TR')} Kasa</div>
                  <div className="text-[10px] text-slate-500 mt-1">Paketli ticari sevkiyat</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Lojistik Seferi</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{salesLogisticsStats.totalLogisticsVehicles} Sefer</div>
                  <div className="text-[10px] text-slate-500 mt-1">Frigorifik Tır/Kamyon</div>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Fatura Sayısı</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-1">{salesLogisticsStats.salesCount} Fatura</div>
                  <div className="text-[10px] text-slate-500 mt-1">Ticari çıkış partileri</div>
                </div>
              </div>

              {/* Müşteri Bazlı Grafiği */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Müşteri Bazlı Sevk Edilen Net Tonajlar
                  </h4>
                  {onSelectModule && (
                    <button
                      type="button"
                      onClick={() => onSelectModule('SALES', 'NEW')}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-800 text-[11px] font-bold hover:bg-indigo-100 flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>+ Yeni Satış Çıkışı Gir</span>
                    </button>
                  )}
                </div>
                <div className="h-60 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesLogisticsStats.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="customer" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Bar dataKey="Tonaj" name="Sevk Edilen (Ton)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Fresh Produce Benchmark & GOST Import SOP Modal */}
      {showBenchmarkModal && (
        <FreshProduceBenchmarkModal
          isOpen={showBenchmarkModal}
          onClose={() => setShowBenchmarkModal(false)}
          onNavigateToAmbar={() => {
            setShowBenchmarkModal(false);
            onSelectModule?.('AMBAR', 'NEW');
          }}
          onNavigateToNumune={() => {
            setShowBenchmarkModal(false);
            onSelectModule?.('EXPORT_SAMPLE', 'NEW');
          }}
        />
      )}
    </div>
  );
};
