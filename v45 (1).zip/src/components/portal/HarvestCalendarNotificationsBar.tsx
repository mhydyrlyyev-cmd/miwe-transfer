import React, { useState, useMemo } from 'react';
import {
  Bell,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Sprout,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Sparkles,
  FileCheck2
} from 'lucide-react';
import {
  Miwe2026Row,
  Miwe2026HarvestStatus,
  PlanCrateOption,
  computeHarvestCalendarNotifications,
  loadCustomOrchards,
  addCustomOrchardToStorage,
  loadCustomCrops,
  addCustomCropToStorage,
  loadDelilnamaSyncLogs,
  recalculateMiwe2026Row
} from '../../data/miwe2026Schema';

interface HarvestCalendarNotificationsBarProps {
  rows: Miwe2026Row[];
  activeYear: '2026' | '2027';
  crateOptions: PlanCrateOption[];
  onAddDirectRow: (newRow: Miwe2026Row, targetYear: '2026' | '2027') => void;
  onUpdateRowStatus: (rowId: string, status: Miwe2026HarvestStatus) => void;
  onOrchardsUpdated: (orchards: string[], crops: string[]) => void;
}

export const HarvestCalendarNotificationsBar: React.FC<HarvestCalendarNotificationsBarProps> = ({
  rows,
  activeYear,
  crateOptions,
  onAddDirectRow,
  onUpdateRowStatus,
  onOrchardsUpdated
}) => {
  // Bildirim & 10-15 Gün Ön Test Kontrolü
  const [showNotifications, setShowNotifications] = useState<boolean>(true);
  const [simDateStr, setSimDateStr] = useState<string>(`20.05.${activeYear}`);

  // Doğrudan Platformdan Hızlı Satır Girişi (2026 / 2027)
  const [showDirectEntry, setShowDirectEntry] = useState<boolean>(activeYear === '2027');
  const [customOrchards, setCustomOrchards] = useState<string[]>(() => loadCustomOrchards());
  const [customCrops, setCustomCrops] = useState<string[]>(() => loadCustomCrops());

  // Yeni Ek Bahçe / Ürün Ekleme
  const [showAddOrchardBox, setShowAddOrchardBox] = useState<boolean>(false);
  const [newOrchardInput, setNewOrchardInput] = useState<string>('');
  const [newCropInput, setNewCropInput] = useState<string>('');

  // Direkt Satır Giriş State'leri (Kullanıcının istediği tüm sütunlar)
  const [dBahce, setDBahce] = useState<string>('Garahan');
  const [dMeyve, setDMeyve] = useState<string>('Şetdaly');
  const [dGrant, setDGrant] = useState<string>('');
  const [dAy, setDAy] = useState<string>('Haziran');
  const [dBbch65, setDBbch65] = useState<string>(`22.03.${activeYear}`);
  const [dBbch71, setDBbch71] = useState<string>(`25.04.${activeYear}`);
  const [dTahminiHasat, setDTahminiHasat] = useState<string>(`08.06.${activeYear}`);
  const [dHasat2027, setDHasat2027] = useState<string>('08.06.2027');
  const [dGunSayisi, setDGunSayisi] = useState<number>(10);
  const [dIsciKg, setDIsciKg] = useState<number>(200);
  const [dKutuAdi, setDKutuAdi] = useState<string>(crateOptions[0]?.name || '50×30 Orta Kasa (8.5 kg)');
  const [dButceTon, setDButceTon] = useState<number>(25);
  const [dDelilnamaTon, setDDelilnamaTon] = useState<string>('');
  const [dStatus, setDStatus] = useState<Miwe2026HarvestStatus>('Başlamady');

  const syncLogs = useMemo(() => loadDelilnamaSyncLogs(), [rows]);

  const notifications = useMemo(
    () => computeHarvestCalendarNotifications(rows, simDateStr),
    [rows, simDateStr]
  );

  const preTestAlerts = notifications.filter(n => n.type === 'PRE_HARVEST_TEST_10_15_DAYS');
  const activeHarvestAlerts = notifications.filter(n => n.type === 'HARVEST_READY_OR_ACTIVE');

  // Canlı Önizleme Hesapları (Direkt Giriş Satırı İçin)
  const selectedCrateObj = crateOptions.find(c => c.name === dKutuAdi) || crateOptions[0];
  const crateCapKg = selectedCrateObj?.capacityKg || 8.5;
  const activeTon = dDelilnamaTon !== '' ? Number(dDelilnamaTon) : Number(dButceTon) || 0;
  const previewDailyTon = dGunSayisi > 0 ? Number((activeTon / dGunSayisi).toFixed(2)) : 0;
  const previewWorkers = dIsciKg > 0 ? Math.round((activeTon * 1000) / dIsciKg) : 0;
  const previewCrates = crateCapKg > 0 ? Math.round((activeTon * 1000) / crateCapKg) : 0;
  const previewAnalysisPct =
    dButceTon > 0 && dDelilnamaTon !== ''
      ? Math.round((Number(dDelilnamaTon) / dButceTon) * 100)
      : 0;

  const handleSaveCustomOrchardOrCrop = (e: React.FormEvent) => {
    e.preventDefault();
    let nextOrchards = customOrchards;
    let nextCrops = customCrops;
    if (newOrchardInput.trim()) {
      nextOrchards = addCustomOrchardToStorage(newOrchardInput.trim());
      setCustomOrchards(nextOrchards);
      setDBahce(newOrchardInput.trim());
      setNewOrchardInput('');
    }
    if (newCropInput.trim()) {
      nextCrops = addCustomCropToStorage(newCropInput.trim());
      setCustomCrops(nextCrops);
      setDMeyve(newCropInput.trim());
      setNewCropInput('');
    }
    onOrchardsUpdated(nextOrchards, nextCrops);
    setShowAddOrchardBox(false);
  };

  const handleDirectRowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dBahce.trim() || !dMeyve.trim() || !dGrant.trim()) return;

    const nextNum = rows.length > 0 ? Math.max(...rows.map(r => r.rowNumber)) + 1 : 1;
    const rawDelilnama = dDelilnamaTon.trim() !== '' ? Number(dDelilnamaTon) : null;

    const created = recalculateMiwe2026Row({
      id: `MIWE-${activeYear}-DIR-${Date.now()}`,
      rowNumber: nextNum,
      A3_bahce: dBahce.trim(),
      B3_meyve: dMeyve.trim(),
      C3_meyveGrant: dGrant.trim(),
      D3_ortalamaHasatAy: dAy.trim() || 'Haziran',
      E3_haftaninGunu: '1',
      F3_bbch65CiceklemeTarihi: dBbch65.trim(),
      G3_bbch71SeyreltmeBaslama: dBbch71.trim(),
      H3_seyreltmeBitmeTarihi: '',
      I3_seyreltmeSuresiGun: '7',
      J3_suKesmeTarihiBadem: '',
      K3_testTarihiNotu: '',
      L3_hasat2024Tarihi: '',
      M3_hasat2025Tarihi: '',
      N3_yilinGunuMin: '',
      O3_yilinGunuMax: '',
      P3_bbchMinGun: '85',
      Q3_bbchMaxGun: '110',
      R3_tahminiHasatTarihi: dTahminiHasat.trim(),
      S3_optimalWindowTarihi: dTahminiHasat.trim(),
      T3_hasat2027Baslama: dHasat2027.trim(),
      U3_gunlukIsciGucuKg: Number(dIsciKg) || 200,
      V3_gerekenIsciSayisi: previewWorkers,
      W3_seftaliKutu50x30Kg: crateCapKg,
      X3_gerekenKutu50x30Adet: previewCrates,
      Y3_kutuCesit1Bilgi: '',
      Z3_kutuCesit2Bilgi: '',
      AA3_kutuCesit3Bilgi: '',
      AB3_yonetimButcePlanTon: Number(dButceTon) || 0,
      AC3_agronomRewizPlanTon: Number(dButceTon) || 0,
      AD3_fiili2026Baslama: dTahminiHasat.trim(),
      AE3_fiili2026BitisNot: '',
      AF3_delilnamaHamTon: rawDelilnama,
      AG3_hasatStatusu: dStatus,
      AH3_netSortSonrasiTon: rawDelilnama,
      hasatGunSayisi: Number(dGunSayisi) || 10,
      gunlukOrtalamaHasatTon: previewDailyTon,
      butceGerceklesmePct: previewAnalysisPct,
      secilenKutuAdi: dKutuAdi
    });

    onAddDirectRow(created, activeYear);
    setDGrant('');
  };

  return (
    <div className="space-y-3">
      {/* 1. HASAT ÖNCESİ 10-15 GÜN TEST UYARISI & HASAT BİLDİRİM MERKEZİ */}
      <div className="bg-gradient-to-r from-amber-950/70 via-slate-900 to-emerald-950/70 border border-amber-500/30 rounded-2xl overflow-hidden shadow-lg">
        <div className="px-4 py-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="text-xs sm:text-sm font-black text-white">
                  Hasat Takvimi Bildirimleri & Hasat Öncesi 10–15 Gün Ön Test Uyarı Sistemi
                </h4>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  {preTestAlerts.length} Ön Test Uyarısı
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  {activeHarvestAlerts.length} Hasat Bildirimi
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                Tahmini hasat tarihinden <strong>10–15 gün önce</strong> ön kalite testi (Brix, Sertlik, Boyun Kuruluğu, Özgül Ağırlık) uyarısı verir; test sonrası hasat bildirimi başlatır.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Kontrol Tarihi Seçici (Sezon Simülasyonu) */}
            <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-700 text-xs">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] text-slate-400 font-bold">Kontrol Tarihi:</span>
              <select
                value={simDateStr}
                onChange={e => setSimDateStr(e.target.value)}
                className="bg-transparent text-amber-300 font-mono font-bold outline-none cursor-pointer text-xs"
              >
                <option value={`05.05.${activeYear}`} className="bg-slate-900 text-white">
                  05.05.{activeYear} (Mayıs Başı - Erkenci Kiraz/Şeftali)
                </option>
                <option value={`20.05.${activeYear}`} className="bg-slate-900 text-white">
                  20.05.{activeYear} (Mayıs Sonu - Haziran Ön Testleri)
                </option>
                <option value={`10.06.${activeYear}`} className="bg-slate-900 text-white">
                  10.06.{activeYear} (Haziran Ortası - Ana Sezon)
                </option>
                <option value={`05.07.${activeYear}`} className="bg-slate-900 text-white">
                  05.07.{activeYear} (Temmuz Başı - Elma/Armut/Erik)
                </option>
                <option value={`01.08.${activeYear}`} className="bg-slate-900 text-white">
                  01.08.{activeYear} (Ağustos Başı - Badem & Geç Çeşitler)
                </option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => setShowNotifications(!showNotifications)}
              className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>{showNotifications ? 'Gizle' : 'Göster'}</span>
              {showNotifications ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {showNotifications && (
          <div className="p-3.5 grid grid-cols-1 lg:grid-cols-2 gap-3 max-h-72 overflow-y-auto">
            {/* Sol: Hasat Öncesi 10-15 Gün Test Uyarıları (Test Edilmediyse Test) */}
            <div className="space-y-2">
              <div className="text-[11px] font-black text-amber-300 uppercase tracking-wider flex items-center justify-between gap-1.5">
                <span className="flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Bahçede Henüz Test Edilmeyen & Tarihi Yaklaşanlar ({preTestAlerts.length})</span>
                </span>
                <span className="text-[10px] font-normal text-slate-400">
                  Test edilmediyse Test • Meyve yoksa Hasat Yok
                </span>
              </div>
              {preTestAlerts.length === 0 ? (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-400">
                  Seçili kontrol tarihinde ({simDateStr}) 10–15 gün içinde ön test bekleyen çeşit bulunmuyor.
                </div>
              ) : (
                preTestAlerts.slice(0, 8).map(item => (
                  <div
                    key={item.id}
                    className="bg-slate-950/90 border border-amber-500/30 rounded-xl p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-amber-200">{item.title}</div>
                      <div className="text-[11px] text-slate-300">
                        <strong className="text-white">{item.bahce}</strong> · {item.meyve} (
                        <strong className="text-amber-300">{item.cesit}</strong>) — Tahmini Hasat:{' '}
                        <span className="font-mono font-bold text-white">{item.targetDateStr}</span>
                      </div>
                      <div className="text-[10px] text-cyan-300/90 font-medium">
                        {item.recommendedTestParams}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onUpdateRowStatus(item.rowId, 'Test Edildi')}
                        className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-black cursor-pointer"
                        title="Ön kalite testi yapıldı olarak işaretle"
                      >
                        🔬 Test Edildi
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateRowStatus(item.rowId, 'Yygym yok')}
                        className="px-2 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-500/40 text-[10px] font-bold cursor-pointer"
                        title="Bahçede bu çeşitte meyve yoksa Hasat Yok olarak işaretle (Uyarıları kapatır)"
                      >
                        🚫 Hasat Yok
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Sağ: Testi Tamamlanan & 1. Hasat -> 2. Hasat -> 3. Hasat Kademeli Takibi + Otomatik Delilnama Kayıtları */}
            <div className="space-y-2">
              <div className="text-[11px] font-black text-emerald-300 uppercase tracking-wider flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Hasat Zamanı Gelenler (1. Hasat ➔ 2. Hasat ➔ 3. Hasat) & Delilnama</span>
                </span>
                {syncLogs.length > 0 && (
                  <span className="text-[10px] font-mono text-emerald-400">
                    Son Aktarım: {syncLogs[0].cesit} (+{syncLogs[0].eklenenTon}T)
                  </span>
                )}
              </div>

              {activeHarvestAlerts.length === 0 ? (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-400">
                  Şu an "Test Edildi" veya kademeli hasatta (Hasat-1 / Hasat-2 / Hasat-3) bekleyen çeşit yok. ("Hasat Yok" olanlar hariç tutulur).
                </div>
              ) : (
                activeHarvestAlerts.slice(0, 8).map(item => (
                  <div
                    key={item.id}
                    className="bg-slate-950/90 border border-emerald-500/30 rounded-xl p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-emerald-300">{item.title}</div>
                      <div className="text-[11px] text-slate-300">{item.message}</div>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onUpdateRowStatus(item.rowId, item.nextSuggestedStatus)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-[10px] font-black cursor-pointer shadow-xs"
                      >
                        {item.nextActionLabel}
                      </button>
                      {(item.currentStatus === 'Hasat-1' || item.currentStatus === 'Hasat-2') && (
                        <button
                          type="button"
                          onClick={() => onUpdateRowStatus(item.rowId, 'Tamamlandy')}
                          className="px-2 py-1.5 rounded-lg bg-teal-950 hover:bg-teal-900 text-teal-200 border border-teal-500/40 text-[10px] font-bold cursor-pointer"
                          title="Sezon hasadını tamamen bitir"
                        >
                          ✅ Tamamla
                        </button>
                      )}
                      {item.currentStatus === 'Test Edildi' && (
                        <button
                          type="button"
                          onClick={() => onUpdateRowStatus(item.rowId, 'Yygym yok')}
                          className="px-2 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-500/40 text-[10px] font-bold cursor-pointer"
                          title="Meyve yoksa Hasat Yok işaretle"
                        >
                          🚫 Meyve Yok
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}

              {syncLogs.slice(0, 2).map(log => (
                <div
                  key={log.id}
                  className="bg-emerald-950/30 border border-emerald-500/40 rounded-xl p-2 text-[11px] flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <span className="font-bold text-emerald-200">
                        Delilnama Otomatik İşlendi ({log.refId}):
                      </span>{' '}
                      <span className="text-white">
                        {log.bahce} · {log.meyve} ({log.cesit})
                      </span>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-emerald-300 shrink-0">
                    +{log.eklenenTon} T (Toplam: {log.yeniToplamTon} T)
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 2. DOĞRUDAN PLATFORMDAN HIZLI VERİ GİRİŞ BANDI & EK BAHÇE (SOĞAN, HAVUÇ, PATATES) EKLEME */}
      <div className="bg-slate-900/95 border border-indigo-500/40 rounded-2xl p-3.5 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span className="text-xs sm:text-sm font-black text-white">
              ⚡ {activeYear} Meyve & Sebze Planlama — Doğrudan Platformdan Hızlı Satır Girişi
            </span>
            <span className="px-2 py-0.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
              Soğan, Havuç, Patates ve Tüm Meyve Bahçeleri
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowAddOrchardBox(!showAddOrchardBox)}
              className="px-3 py-1.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              <span>+ Listede Olmayan Ek Bahçe / Ürün Ekle</span>
            </button>

            <button
              type="button"
              onClick={() => setShowDirectEntry(!showDirectEntry)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>{showDirectEntry ? 'Hızlı Girişi Daralt' : 'Doğrudan Giriş Satırını Aç'}</span>
              {showDirectEntry ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Listede Olmayan Ek Bahçe Ekleme Kutusu */}
        {showAddOrchardBox && (
          <form
            onSubmit={handleSaveCustomOrchardOrCrop}
            className="bg-slate-950 border border-emerald-500/40 rounded-xl p-3 flex flex-wrap items-end gap-3 text-xs"
          >
            <div className="flex-1 min-w-[200px]">
              <label className="block text-[10px] font-bold text-emerald-300 uppercase mb-1">
                Yeni Bahçe / Tarla Adı (Örn: Ahal Soğan Tarlası, Blok-9 Havuç)
              </label>
              <input
                type="text"
                value={newOrchardInput}
                onChange={e => setNewOrchardInput(e.target.value)}
                placeholder="Bahçe veya tarla adını yazın..."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
              />
            </div>
            <div className="flex-1 min-w-[180px]">
              <label className="block text-[10px] font-bold text-amber-300 uppercase mb-1">
                Yeni Ürün Türü (İsteğe Bağlı - Örn: Soğan, Havuç, Patates)
              </label>
              <input
                type="text"
                value={newCropInput}
                onChange={e => setNewCropInput(e.target.value)}
                placeholder="Ürün adını yazın..."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black cursor-pointer"
            >
              ✓ Listeye Kaydet
            </button>
          </form>
        )}

        {/* Doğrudan Platformdan Hızlı Satır Giriş Formu (Tüm Sütunlar Tek Satırda) */}
        {showDirectEntry && (
          <form onSubmit={handleDirectRowSubmit} className="space-y-2.5 pt-1 border-t border-slate-800">
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-12 gap-2 text-xs">
              <div className="lg:col-span-2">
                <label className="block text-[10px] text-slate-400 mb-0.5">Bahçe Adı (Üretim Bölgesi)</label>
                <input
                  list="custom-orchards-datalist"
                  value={dBahce}
                  onChange={e => setDBahce(e.target.value)}
                  placeholder="Bahçe seç veya yaz..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-white font-semibold"
                />
                <datalist id="custom-orchards-datalist">
                  {customOrchards.map(o => (
                    <option key={o} value={o} />
                  ))}
                </datalist>
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-amber-300 mb-0.5">Meyve / Ürün</label>
                <input
                  list="custom-crops-datalist"
                  value={dMeyve}
                  onChange={e => setDMeyve(e.target.value)}
                  placeholder="Meyve/Sebze"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-amber-300 font-bold"
                />
                <datalist id="custom-crops-datalist">
                  {customCrops.map(c => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>

              <div className="lg:col-span-2">
                <label className="block text-[10px] text-white font-bold mb-0.5">
                  Meyve Çeşidi (Grant / Görnüşi) *
                </label>
                <input
                  type="text"
                  required
                  value={dGrant}
                  onChange={e => setDGrant(e.target.value)}
                  placeholder="Örn: Extreme 314, Daytona, Nantes..."
                  className="w-full bg-slate-950 border border-indigo-500/60 rounded-lg px-2 py-1.5 text-white font-bold"
                />
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-emerald-300 mb-0.5">Ort. Hasat Ayı</label>
                <input
                  type="text"
                  value={dAy}
                  onChange={e => setDAy(e.target.value)}
                  placeholder="Haziran"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-emerald-200"
                />
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-emerald-300 mb-0.5">%75 Çiçeklenme</label>
                <input
                  type="text"
                  value={dBbch65}
                  onChange={e => setDBbch65(e.target.value)}
                  placeholder="22.03.2027"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-emerald-300 font-mono"
                />
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-teal-300 mb-0.5">Seyreltme Baş.</label>
                <input
                  type="text"
                  value={dBbch71}
                  onChange={e => setDBbch71(e.target.value)}
                  placeholder="25.04.2027"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-teal-300 font-mono"
                />
              </div>

              <div className="lg:col-span-2">
                <label className="block text-[10px] text-indigo-300 mb-0.5">
                  Tahmini Hasat / 2027 Başlama
                </label>
                <div className="flex gap-1">
                  <input
                    type="text"
                    value={dTahminiHasat}
                    onChange={e => setDTahminiHasat(e.target.value)}
                    placeholder="08.06.2026"
                    className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-indigo-300 font-mono"
                  />
                  <input
                    type="text"
                    value={dHasat2027}
                    onChange={e => setDHasat2027(e.target.value)}
                    placeholder="08.06.2027"
                    className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-cyan-300 font-mono"
                  />
                </div>
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-violet-300 mb-0.5">Hasat Günü</label>
                <input
                  type="number"
                  min="1"
                  value={dGunSayisi}
                  onChange={e => setDGunSayisi(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-violet-300 font-mono font-bold"
                />
              </div>

              <div className="lg:col-span-1">
                <label className="block text-[10px] text-sky-300 mb-0.5">1 İşçi Kg/Gün</label>
                <input
                  type="number"
                  min="10"
                  value={dIsciKg}
                  onChange={e => setDIsciKg(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-sky-300 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-12 gap-2 items-end text-xs">
              <div className="lg:col-span-3">
                <label className="block text-[10px] text-indigo-300 mb-0.5">
                  Seçilen Kutu Tipi (Planda Kutu Seçimi)
                </label>
                <select
                  value={dKutuAdi}
                  onChange={e => setDKutuAdi(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-indigo-200"
                >
                  {crateOptions.map(c => (
                    <option key={c.id} value={c.name} className="bg-slate-900 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-2">
                <label className="block text-[10px] text-amber-300 mb-0.5">
                  Yönetim Bütçe Planlanan (Ton)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={dButceTon}
                  onChange={e => setDButceTon(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-amber-500/50 rounded-lg px-2 py-1.5 text-amber-300 font-mono font-bold"
                />
              </div>

              <div className="lg:col-span-2">
                <label className="block text-[10px] text-emerald-300 mb-0.5">
                  Delilnama Onaylı Ham (Ton)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={dDelilnamaTon}
                  onChange={e => setDDelilnamaTon(e.target.value)}
                  placeholder="Opsiyonel"
                  className="w-full bg-slate-950 border border-emerald-500/50 rounded-lg px-2 py-1.5 text-emerald-400 font-mono font-bold"
                />
              </div>

              <div className="lg:col-span-3 bg-slate-950/90 border border-slate-800 rounded-lg px-2.5 py-1.5 font-mono text-[11px] flex items-center justify-between">
                <div>
                  <span className="text-slate-400">Günlük:</span>{' '}
                  <strong className="text-violet-300">{previewDailyTon} T/g</strong>
                </div>
                <div>
                  <span className="text-slate-400">İşçi:</span>{' '}
                  <strong className="text-sky-300">{previewWorkers}</strong>
                </div>
                <div>
                  <span className="text-slate-400">Kutu:</span>{' '}
                  <strong className="text-indigo-300">{previewCrates.toLocaleString('tr-TR')}</strong>
                </div>
              </div>

              <div className="lg:col-span-2 flex justify-end">
                <button
                  type="submit"
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{activeYear} Tablosuna Ekle</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
