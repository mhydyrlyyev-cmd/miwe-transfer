import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Zap,
  TrendingDown,
  Filter,
  Search,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Snowflake,
  Truck,
  FileCheck2,
  Sparkles,
  Info,
  CheckCircle2,
  XCircle,
  AlertCircle,
  BarChart3,
  Printer
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';
import { FieldRecord, ReferenceItem, SpecialCropType } from '../../types';
import {
  evaluateBatchQualityRisk,
  BatchQualityRiskAssessment,
  QualityStandardOrg,
  QUALITY_STANDARDS_ORGS
} from '../../utils/qualityStandards';

interface QualityInsightCardProps {
  fieldRecords: FieldRecord[];
  references?: ReferenceItem[];
  onSelectReference?: (refId: string) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onOpenTraceability?: (ref: ReferenceItem) => void;
  onOpenFieldTest?: (refId: string) => void;
  isCompact?: boolean;
  defaultExpanded?: boolean;
  onNavigateToAnalytics?: () => void;
  onNavigateToRecords?: () => void;
}

/** v3.8: "Garahan · Eksport Lab (Rusya (Moskva))" → "Garahan · Eksport Lab (Rusya, Moskva)" — iç içe / fazla parantezi temizler */
function cleanPlace(s: string): string {
  let out = s.replace(/\(([^()]*)\(([^()]*)\)\)/g, (_m, a: string, b: string) => `(${a.trim()}, ${b.trim()})`);
  let depth = 0;
  out = [...out].filter(ch => {
    if (ch === '(') { depth++; return true; }
    if (ch === ')') { if (depth === 0) return false; depth--; return true; }
    return true;
  }).join('');
  return out.replace(/\s+/g, ' ').trim();
}
/** v3.8: kural adındaki İngilizce standart önekini Türkçeleştirir ("GENERAL Kusur…" → "Genel Kusur…") */
function cleanRuleName(n: string): string {
  return (n || '').replace(/^GENERAL\b/, 'Genel');
}

const QualityInsightCardInner: React.FC<QualityInsightCardProps> = ({
  fieldRecords = [],
  references = [],
  onSelectReference,
  onRerouteToFreezeDry,
  onOpenTraceability,
  onOpenFieldTest,
  isCompact = false,
  defaultExpanded = false,
  onNavigateToAnalytics,
  onNavigateToRecords
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [selectedTab, setSelectedTab] = useState<'ALL' | 'CRITICAL' | 'WARNING' | 'SAFE'>('ALL');
  const [selectedStandard, setSelectedStandard] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [showRerouteModal, setShowRerouteModal] = useState<BatchQualityRiskAssessment | null>(null);
  // v3.8: kartta ilk neden görünür; diğerleri kart bazında açılır
  const [expandedRules, setExpandedRules] = useState<Set<string>>(new Set());
  const toggleRules = (refId: string) => setExpandedRules(prev => { const n = new Set(prev); if (n.has(refId)) n.delete(refId); else n.add(refId); return n; });
  const [rerouteReason, setRerouteReason] = useState('Kalite standart altı / Hızlı bozulma önleme (-40°C Şoklama)');

  // Harici referans haritası (Hızlı arama için)
  const referenceMap = useMemo(() => {
    const map = new Map<string, ReferenceItem>();
    references.forEach(r => map.set(r.refId, r));
    return map;
  }, [references]);

  // Tüm saha kayıtlarının OECD / USDA eşik ve raf ömrü analizi
  const batchAssessments: BatchQualityRiskAssessment[] = useMemo(() => {
    return fieldRecords.map(rec => {
      const ref = referenceMap.get(rec.refId);
      return evaluateBatchQualityRisk(rec, ref);
    });
  }, [fieldRecords, referenceMap]);

  // İstatistiksel Özet
  const stats = useMemo(() => {
    const total = batchAssessments.length;
    const criticalCount = batchAssessments.filter(b => b.riskLevel === 'CRITICAL').length;
    const warningCount = batchAssessments.filter(b => b.riskLevel === 'WARNING').length;
    const safeCount = batchAssessments.filter(b => b.riskLevel === 'SAFE').length;
    const expiringCount = batchAssessments.filter(b => b.isShelfLifeExpiring).length;
    const freezeDryCandidates = batchAssessments.filter(b => b.actionType === 'FREEZE_DRY').length;
    const complianceRate = total > 0 ? Math.round(((total - criticalCount) / total) * 100) : 100;

    return {
      total,
      criticalCount,
      warningCount,
      safeCount,
      expiringCount,
      freezeDryCandidates,
      complianceRate
    };
  }, [batchAssessments]);

  // Last 7 Days Harvest Tonnage vs Quality Score Trend Chart Data
  const chartData = useMemo(() => {
    const daysMap = new Map<string, { dateStr: string; ton: number; scoreSum: number; count: number }>();
    
    // Initialize last 7 days
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateKey = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
      daysMap.set(dateKey, { dateStr: label, ton: 0, scoreSum: 0, count: 0 });
    }

    fieldRecords.forEach((rec, idx) => {
      const dayKey = (rec.timestamp || new Date().toISOString()).slice(0, 10);
      const ref = referenceMap.get(rec.refId);
      const kg = Number(ref?.quantity) || 1200;
      const score = Number(rec.avgHardness) ? Math.min(100, Math.round(Number(rec.avgHardness) * 12)) : 88;

      if (daysMap.has(dayKey)) {
        const item = daysMap.get(dayKey)!;
        item.ton += (kg / 1000);
        item.scoreSum += score;
        item.count += 1;
      } else {
        // Fallback to first day if outside 7 days window
        const firstKey = Array.from(daysMap.keys())[0];
        if (firstKey) {
          const item = daysMap.get(firstKey)!;
          item.ton += (kg / 1000);
          item.scoreSum += score;
          item.count += 1;
        }
      }
    });

    const hasData = Array.from(daysMap.values()).some(item => item.count > 0);
    const data = Array.from(daysMap.values()).map(item => ({
      date: item.dateStr,
      tonnage: Number(item.ton.toFixed(1)),
      qualityScore: item.count > 0 ? Math.round(item.scoreSum / item.count) : null
    }));

    return { hasData, data };
  }, [fieldRecords, referenceMap]);

  // Filtrelenmiş Liste
  const filteredBatches = useMemo(() => {
    return batchAssessments.filter(b => {
      // Tab Filtresi
      if (selectedTab !== 'ALL' && b.riskLevel !== selectedTab) {
        return false;
      }
      // Standart Filtresi
      if (selectedStandard !== 'ALL' && b.standardOrg !== selectedStandard) {
        return false;
      }
      // Arama Filtresi
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesRef = b.refId.toLowerCase().includes(q);
        const matchesProd = b.product.toLowerCase().includes(q);
        const matchesVar = b.variety.toLowerCase().includes(q);
        const matchesOrchard = (b.orchard || '').toLowerCase().includes(q);
        if (!matchesRef && !matchesProd && !matchesVar && !matchesOrchard) {
          return false;
        }
      }
      return true;
    });
  }, [batchAssessments, selectedTab, selectedStandard, searchQuery]);

  const handleExecuteReroute = () => {
    if (!showRerouteModal) return;
    if (onRerouteToFreezeDry) {
      onRerouteToFreezeDry(showRerouteModal.refId, rerouteReason);
    }
    setShowRerouteModal(null);
  };

  if (fieldRecords.length === 0) {
    return null;
  }

  return (
    <div
      id="quality-insight-card"
      className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden transition-all duration-200 ${
        isCompact ? 'mb-3' : 'mb-6'
      }`}
    >
      {/* Sadece Başlık Barı (Tıklanınca Açılır/Kapanır) */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => setIsExpanded(!isExpanded)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setIsExpanded(!isExpanded);
          }
        }}
        className={`w-full text-left p-3.5 sm:p-4 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-transparent flex items-center justify-between gap-3 cursor-pointer select-none hover:bg-slate-50/80 dark:hover:bg-slate-800/60 transition-colors ${
          isExpanded ? 'border-b border-slate-200 dark:border-slate-800' : ''
        }`}
        title={isExpanded ? 'Verileri Gizle' : 'Tıklayarak Kalite Öngörü & Risk Verilerini Gör'}
      >
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate">
                Kalite Öngörü & Risk Radarı (Quality Insight)
              </h3>
              {stats.criticalCount > 0 ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-600 text-white flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                  {stats.criticalCount} Acil Risk
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300/40">
                  %{stats.complianceRate} Uyum
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/60 dark:border-indigo-800/60">
            <span>{isExpanded ? 'Verileri Gizle' : 'Verileri Gör'}</span>
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </span>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4">
          {/* KPI İstatistik Sayaçları */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div 
              onClick={() => setSelectedTab('ALL')}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                selectedTab === 'ALL'
                  ? 'bg-slate-100 dark:bg-slate-800 border-slate-400 dark:border-slate-600 shadow-sm'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 font-medium">Toplam Analiz</span>
                <BarChart3 className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                {stats.total} <span className="text-xs font-normal text-slate-400">Parti</span>
              </div>
            </div>

            <div 
              onClick={() => setSelectedTab('CRITICAL')}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                selectedTab === 'CRITICAL'
                  ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 shadow-sm'
                  : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50 hover:border-rose-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-rose-700 dark:text-rose-300 font-medium">🔴 Acil & Raf Sonu</span>
                <AlertTriangle className="w-4 h-4 text-rose-500" />
              </div>
              <div className="text-xl font-bold text-rose-700 dark:text-rose-300 mt-1">
                {stats.criticalCount} <span className="text-xs font-normal text-rose-500">Parti</span>
              </div>
            </div>

            <div 
              onClick={() => setSelectedTab('WARNING')}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                selectedTab === 'WARNING'
                  ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 shadow-sm'
                  : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50 hover:border-amber-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-amber-700 dark:text-amber-300 font-medium">🟡 Eşik Sınırında</span>
                <Clock className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-xl font-bold text-amber-700 dark:text-amber-300 mt-1">
                {stats.warningCount} <span className="text-xs font-normal text-amber-500">Parti</span>
              </div>
            </div>

            <div 
              onClick={() => setSelectedTab('SAFE')}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                selectedTab === 'SAFE'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 shadow-sm'
                  : 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/50 hover:border-emerald-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-emerald-700 dark:text-emerald-300 font-medium">🟢 Optimum Kalite</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">
                {stats.safeCount} <span className="text-xs font-normal text-emerald-500">Parti</span>
              </div>
            </div>
          </div>

          {/* v45: 7 günlük tonaj/kalite grafiği ve otomatik Freeze-Dry önerisi kaldırıldı (yanıltıcıydı) */}
          {/* Filtre & Arama Araç Çubuğu & Hızlı Geçişler */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Parti No, Ürün, Bahçe ara..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end overflow-x-auto pb-1 sm:pb-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Filter className="w-3.5 h-3.5" /> Standart:
                </span>
                {['ALL', 'OECD', 'USDA', 'UNECE', 'TESCO'].map(std => (
                  <button
                    key={std}
                    onClick={() => setSelectedStandard(std)}
                    className={`px-2 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedStandard === std
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {std === 'ALL' ? 'Tümü' : std}
                  </button>
                ))}
              </div>

              {onNavigateToAnalytics && (
                <button
                  type="button"
                  onClick={onNavigateToAnalytics}
                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-2xs transition flex items-center gap-1 cursor-pointer shrink-0 ml-1"
                  title="Analiz & Rapor Paneline Git"
                >
                  <span>Analiz Paneli</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Parti Risk Kartları Listesi */}
          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {filteredBatches.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                <ShieldCheck className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Filtreye uygun riskli parti bulunamadı.
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Seçili kriterlerdeki tüm partiler standartlara uygun ve güvenli durumda.
                </p>
              </div>
            ) : (
              filteredBatches.map(batch => {
                const isCritical = batch.riskLevel === 'CRITICAL';
                const isWarning = batch.riskLevel === 'WARNING';
                const ref = referenceMap.get(batch.refId);

                return (
                  <div
                    key={batch.recordId}
                    className={`p-3.5 sm:p-4 rounded-xl border transition-all ${
                      isCritical
                        ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-300 dark:border-rose-900/60 hover:border-rose-400'
                        : isWarning
                        ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-900/60 hover:border-amber-400'
                        : 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    {/* v3.8: sade test kartı — puan halkası, Türkçe sonuç, raf ömrü, tek satır neden */}
                    {(() => {
                      const hs = batch.healthScore;
                      const hsColor = hs >= 80 ? '#2F7D3A' : hs >= 50 ? '#8A5300' : '#B42318';
                      const r = 18, circ = 2 * Math.PI * r;
                      const verdict = batch.standardVerdict === 'PASS'
                        ? { t: 'Uygun', c: 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300' }
                        : batch.standardVerdict === 'CONDITIONAL'
                        ? { t: 'Koşullu', c: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300' }
                        : { t: 'Standart dışı', c: 'bg-rose-50 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300' };
                      const org = ({ GENERAL: 'Genel', GOST: 'GOST' } as Record<string, string>)[String(batch.standardOrg)] || batch.standardOrg;
                      const place = cleanPlace([batch.orchard || 'Bahçe 1', batch.location].filter(Boolean).join(' · '));
                      const life = batch.estimatedRemainingShelfLifeDays;
                      return (
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="font-ref font-bold text-sm text-slate-900 dark:text-white">{batch.refId}</div>
                            <div className="text-sm text-slate-700 dark:text-slate-200">{batch.product}{batch.variety ? ` · ${batch.variety}` : ''}</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 truncate" title={`Kontrol: ${batch.operator}`}>{place} · hasat {batch.harvestDate} ({batch.daysElapsed} gün önce)</div>
                            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${verdict.c}`}>{verdict.t}</span>
                              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{org}</span>
                              <span className={`inline-flex items-center gap-1 text-[11px] ${life <= 3 ? 'text-rose-700 font-bold' : life <= 7 ? 'text-amber-700 font-semibold' : 'text-slate-500 dark:text-slate-400'}`}>
                                <Clock className="w-3 h-3" />{life <= 0 ? 'Raf ömrü doldu' : `~${life} gün raf ömrü`}
                              </span>
                            </div>
                          </div>
                          <span className="relative w-12 h-12 shrink-0 flex items-center justify-center" title={`Sağlık puanı ${hs}/100`}>
                            <svg width="48" height="48" viewBox="0 0 48 48" className="absolute inset-0 -rotate-90" aria-hidden="true">
                              <circle cx="24" cy="24" r={r} fill="none" stroke="#E5E7EB" strokeWidth="5" />
                              <circle cx="24" cy="24" r={r} fill="none" stroke={hsColor} strokeWidth="5" strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - hs / 100)} />
                            </svg>
                            <span className="font-display font-bold text-sm" style={{ color: hsColor }}>{hs}</span>
                          </span>
                        </div>
                      );
                    })()}

                    {/* Raf ömrü — geçen süre (etiketli; renk sağlık puanından bağımsız olduğu için yazıyla açıklanır) */}
                    <div className="mt-2.5">
                      <div className="flex justify-between text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">
                        <span>Geçen raf ömrü</span><span className="tabular-nums">%{Math.round(batch.shelfLifeProgressPercent)}</span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            batch.shelfLifeProgressPercent >= 85 ? 'bg-rose-500' : batch.shelfLifeProgressPercent >= 60 ? 'bg-amber-500' : 'bg-slate-400'
                          }`}
                          style={{ width: `${batch.shelfLifeProgressPercent}%` }}
                        />
                      </div>
                    </div>

                    {/* Nedenler: ilk (en önemli) neden tek satır; diğerleri "+N neden" ile açılır */}
                    {batch.triggeredRules.length > 0 && (() => {
                      const rules = [...batch.triggeredRules].sort((a, b) => (a.severity === 'CRITICAL' ? 0 : 1) - (b.severity === 'CRITICAL' ? 0 : 1));
                      const open = expandedRules.has(batch.refId);
                      const shown = open ? rules : rules.slice(0, 1);
                      return (
                        <div className="mt-2 space-y-1">
                          {shown.map((rule, idx) => (
                            <div key={idx} className={`text-xs flex items-start gap-1.5 ${rule.severity === 'CRITICAL' ? 'text-rose-800 dark:text-rose-300' : 'text-amber-800 dark:text-amber-300'}`}>
                              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                              <span><strong>{cleanRuleName(rule.ruleName)}</strong> · {rule.currentValue} / {rule.thresholdValue}{open && rule.description ? <span className="block text-slate-600 dark:text-slate-400 font-normal">{rule.description}</span> : null}</span>
                            </div>
                          ))}
                          {rules.length > 1 && (
                            <button type="button" onClick={() => toggleRules(batch.refId)} className="text-[11px] font-bold text-slate-600 dark:text-slate-300 underline-offset-2 hover:underline cursor-pointer">
                              {open ? 'Daha az' : `+${rules.length - 1} neden daha`}
                            </button>
                          )}
                        </div>
                      );
                    })()}

                    {/* Hızlı Eylem Butonları */}
                    <div className="mt-3 pt-2.5 border-t border-slate-200/80 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">Aksiyon: </span>
                        {batch.recommendedAction}
                      </div>

                      <div className="flex items-center gap-2">
                        {batch.actionType === 'FREEZE_DRY' && !batch.isReroutedToFreezeDry && (
                          <button
                            onClick={() => setShowRerouteModal(batch)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold bg-cyan-600 hover:bg-cyan-700 text-white flex items-center gap-1 shadow-sm transition-colors"
                          >
                            <Snowflake className="w-3.5 h-3.5" /> Freeze & Dry'a Yönlendir
                          </button>
                        )}

                        {batch.actionType === 'URGENT_DISPATCH' && (
                          <button
                            onClick={() => onSelectReference && onSelectReference(batch.refId)}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white flex items-center gap-1 transition-colors"
                          >
                            <Truck className="w-3.5 h-3.5" /> Hızlı Sevk
                          </button>
                        )}

                        {ref && onOpenTraceability && (
                          <button
                            onClick={() => onOpenTraceability(ref)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold bg-teal-800 hover:bg-teal-900 text-white transition-colors flex items-center gap-1 shadow-xs cursor-pointer btn-tactile"
                            title="Tüm modül verilerini birleştirerek özetleyen PDF raporunu indir / yazdır"
                          >
                            <Printer className="w-3.5 h-3.5 text-amber-300" /> PDF İndir
                          </button>
                        )}

                        {onOpenFieldTest && (
                          <button
                            onClick={() => onOpenFieldTest(batch.refId)}
                            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors"
                            title="Test Raporunu Aç"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Freeze & Dry Yönlendirme Onay Modalı */}
      {showRerouteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-3 text-cyan-600 dark:text-cyan-400">
              <div className="p-3 rounded-xl bg-cyan-100 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-800">
                <Snowflake className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 dark:text-white">
                  Freeze & Dry Hattına Yönlendir
                </h4>
                <p className="text-xs text-slate-500">Parti: {showRerouteModal.refId}</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Bu parti ({showRerouteModal.product} - {showRerouteModal.variety}), OECD/USDA standart limitlerinin altında kaldığı veya aşırı yumuşadığı için taze pazarda çürüme riski taşımaktadır. -40°C şok dondurma ve vakumlu süblimasyon (Freeze-Dry) hattına aktarılarak katma değerli kurutulmuş meyveye dönüştürülecektir.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Yönlendirme / Kalite Gerekçesi:
              </label>
              <textarea
                value={rerouteReason}
                onChange={e => setRerouteReason(e.target.value)}
                rows={2}
                className="w-full p-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowRerouteModal(null)}
                className="px-3 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                onClick={handleExecuteReroute}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-700 text-white shadow-sm flex items-center gap-1.5"
              >
                <Snowflake className="w-3.5 h-3.5" /> Onayla & Yönlendir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export class QualityInsightCard extends React.Component<QualityInsightCardProps, { hasError: boolean }> {
  constructor(props: QualityInsightCardProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  override componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.warn('QualityInsightCard render boundary caught error:', error, errorInfo);
  }

  override render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200 flex items-center justify-between">
          <span>Kalite içgörü paneli yüklenirken bir sorun oluştu.</span>
          <button
            onClick={() => this.setState({ hasError: false })}
            className="px-2.5 py-1 bg-amber-200 dark:bg-amber-800 rounded-lg text-[11px] font-bold cursor-pointer"
          >
            Yeniden Dene
          </button>
        </div>
      );
    }
    return <QualityInsightCardInner {...this.props} />;
  }
}

export default QualityInsightCard;
