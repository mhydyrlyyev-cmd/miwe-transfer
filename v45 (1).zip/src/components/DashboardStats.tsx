import React, { useMemo, useState } from 'react';
import { Package, Truck, Warehouse, AlertTriangle, Layers, Snowflake, CheckCircle2, BarChart3, ChevronDown, ChevronUp, Scale, Trash2, Sliders, Plus, X, Settings2, AlertCircle, Activity, Zap } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { SystemStats, ReferenceItem, AmbarRecord } from '../types';

const DEFAULT_STOCK_THRESHOLDS: Record<string, number> = {
  'Muz (Cavendish)': 1500,
  'Nonpareil Badem': 300,
  'Extreme 314 Şeftali': 1000,
  'Big Top Nektarin': 800,
  'Elma (Gala / Fuji)': 1200,
};

import { SyncHealthCard } from './dashboard/SyncHealthCard';
import { StockRiskRadarCard } from './dashboard/StockRiskRadarCard';
import { StockDepletionChart } from './dashboard/StockDepletionChart';
import { ModuleKey } from '../types';

export interface DashboardStatsProps {
  stats: SystemStats;
  fieldBreakdown?: {
    hasatBekleyen: number;
    freezeDry: number;
    ambar: number;
    lojistik: number;
  };
  onFilterStatus?: (status: string) => void;
  activeFilter?: string;
  references?: ReferenceItem[];
  ambarRecords?: AmbarRecord[];
  onResetStocks?: () => void;
  lastSyncTime?: string | null;
  offlineQueueCount?: number;
  isSyncing?: boolean;
  isOnline?: boolean;
  onManualSync?: () => void;
  onOpenSyncModal?: () => void;
  onSelectModule?: (moduleKey: ModuleKey, action?: 'NEW' | 'EXISTING') => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  stats,
  fieldBreakdown = { hasatBekleyen: stats.created, freezeDry: 0, ambar: 0, lojistik: 0 },
  onFilterStatus,
  activeFilter,
  references = [],
  ambarRecords = [],
  onResetStocks,
  lastSyncTime,
  offlineQueueCount = 0,
  isSyncing = false,
  isOnline = true,
  onManualSync,
  onOpenSyncModal,
  onSelectModule
}) => {
  const [showStockChart, setShowStockChart] = useState(false);
  const [isThresholdModalOpen, setIsThresholdModalOpen] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductThreshold, setNewProductThreshold] = useState<number>(500);

  const [isTopPanelExpanded, setIsTopPanelExpanded] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('miwe_sync_top_panel_expanded');
      return saved !== null ? JSON.parse(saved) : false;
    } catch (e) {}
    return false;
  });

  const toggleTopPanel = () => {
    const nextVal = !isTopPanelExpanded;
    setIsTopPanelExpanded(nextVal);
    try {
      localStorage.setItem('miwe_sync_top_panel_expanded', JSON.stringify(nextVal));
    } catch (e) {}
  };

  const [thresholds, setThresholds] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('miwe_stock_thresholds');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_STOCK_THRESHOLDS;
  });

  const handleUpdateThreshold = (prod: string, val: number) => {
    const updated = { ...thresholds, [prod]: Math.max(0, val) };
    setThresholds(updated);
    localStorage.setItem('miwe_stock_thresholds', JSON.stringify(updated));
  };

  const handleAddCustomThreshold = () => {
    if (!newProductName.trim()) return;
    const updated = { ...thresholds, [newProductName.trim()]: Number(newProductThreshold) || 500 };
    setThresholds(updated);
    localStorage.setItem('miwe_stock_thresholds', JSON.stringify(updated));
    setNewProductName('');
  };

  const handleDeleteThreshold = (prod: string) => {
    const copy = { ...thresholds };
    delete copy[prod];
    setThresholds(copy);
    localStorage.setItem('miwe_stock_thresholds', JSON.stringify(copy));
  };

  const handleResetToDefaultThresholds = () => {
    setThresholds(DEFAULT_STOCK_THRESHOLDS);
    localStorage.setItem('miwe_stock_thresholds', JSON.stringify(DEFAULT_STOCK_THRESHOLDS));
  };

  // Compute stock quantities (kg) by product
  const stockChartData = useMemo(() => {
    const productMap = new Map<string, { product: string; stockKg: number; batchCount: number }>();

    // 1. Process from Ambar records if available
    if (ambarRecords.length > 0) {
      ambarRecords.forEach((amb) => {
        const weight = Number(amb.acceptedWeightKg) || 0;
        if (weight <= 0) return; // Exclude zero or invalid weight records

        // Look up reference to get product name if needed
        const ref = references.find(r => r.refId === amb.refId);
        const prod = ref?.product || amb.notes?.split(' ')?.[0] || 'Genel Meyve';
        
        const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
        existing.stockKg += weight;
        existing.batchCount += 1;
        productMap.set(prod, existing);
      });
    }

    // 2. Supplement ONLY from references with verified RECEIVED status
    if (references.length > 0) {
      references.forEach((ref) => {
        if (ref.status !== 'RECEIVED') return; // Only count received warehouse lots
        let kg = Number(ref.quantity) || 0;
        if (kg <= 0) return; // Exclude zero or invalid quantity records

        const u = (ref.unit || '').toLowerCase();
        if (u.includes('ton')) kg *= 1000;
        if (u.includes('kasa') || u.includes('box')) kg *= 15; // standard avg 15kg/crate
        
        // Check if already captured from ambar
        if (!ambarRecords.some(a => a.refId === ref.refId)) {
          const prod = ref.product || 'Genel Meyve';
          const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
          existing.stockKg += kg;
          existing.batchCount += 1;
          productMap.set(prod, existing);
        }
      });
    }

    // Exclude zero or negative stocks
    const activeProducts = Array.from(productMap.values()).filter(p => p.stockKg > 0);

    // Cold-Start Mode: Return empty array if no real data exists yet
    if (activeProducts.length === 0) {
      return [];
    }

    // Color palette for bars
    const palette = ['#10b981', '#0d9488', '#0284c7', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6', '#14b8a6'];

    return activeProducts
      .sort((a, b) => b.stockKg - a.stockKg)
      .slice(0, 8)
      .map((item, idx) => {
        const threshold = thresholds[item.product] ?? 500;
        const isCritical = item.stockKg < threshold;
        return {
          ...item,
          threshold,
          isCritical,
          fill: isCritical ? '#f59e0b' : palette[idx % palette.length]
        };
      });
  }, [references, ambarRecords, thresholds]);

  const totalStockKg = useMemo(() => {
    return stockChartData.reduce((acc, curr) => acc + curr.stockKg, 0);
  }, [stockChartData]);
  // KPI Summary Cards
  const cards = [
    {
      id: 'ALL',
      title: 'Toplam Referans',
      value: stats.totalReferences,
      subtext: 'Tüm aktif ve arşiv kayıtlar',
      icon: Layers,
      color: 'text-slate-700 bg-slate-50 border-slate-200'
    },
    {
      id: 'CREATED',
      title: 'Saha & Hasat Hazır',
      value: stats.created,
      subtext: 'Sevkiyat bekleyen partiler',
      icon: Package,
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      hasBreakdown: true
    },
    {
      id: 'SHIPPED',
      title: 'Sevkiyatta / Yolda',
      value: stats.shipped,
      subtext: 'Delilnamalı transit yükler',
      icon: Truck,
      color: 'text-amber-700 bg-amber-50 border-amber-200'
    },
    {
      id: 'RECEIVED',
      title: 'Ambar Kabul',
      value: stats.received,
      subtext: 'Depoya kabul edilmiş partiler',
      icon: Warehouse,
      color: 'text-teal-700 bg-teal-50 border-teal-200'
    },
    {
      id: 'INCIDENT',
      title: 'Aktif Incident',
      value: stats.incidents,
      subtext: 'Açık Barlag Akty & DÖF',
      icon: AlertTriangle,
      color: 'text-rose-700 bg-rose-50 border-rose-200'
    },
    {
      id: 'COMPLETED',
      title: 'Tamamlandı / Lock',
      value: stats.completedCount || 0,
      subtext: 'Kilitlenmiş & onaylı partiler',
      icon: CheckCircle2,
      color: 'text-emerald-800 bg-emerald-100 border-emerald-200'
    }
  ];

  return (
    <div className="space-y-4 mb-6">


      {/* 1. TOP STAT CARDS GRID (Mobile vertical stack col-1 -> Tablet col-3 -> Desktop col-6) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 w-full">
        {cards.map((card) => {
          const Icon = card.icon;
          const isSelected = activeFilter === card.id;
          const percentage = stats.totalReferences > 0 
            ? Math.round((card.value / stats.totalReferences) * 100) 
            : 0;

          return (
            <div
              key={card.id}
              onClick={() => onFilterStatus && onFilterStatus(card.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between min-w-0 w-full ${
                isSelected 
                  ? 'ring-2 ring-emerald-500 bg-white shadow-sm border-emerald-500' 
                  : 'bg-white border-slate-200/90 hover:border-emerald-300 shadow-xs hover:shadow-sm hover:-translate-y-0.5'
              }`}
            >
              <div className="min-w-0 w-full space-y-2.5">
                {/* Header */}
                <div className="flex items-center justify-between gap-1.5 min-w-0">
                  <span className="text-xs font-semibold text-slate-600 truncate min-w-0 flex-1 tracking-tight">
                    {card.title}
                  </span>
                  <div className={`p-2 rounded-xl shrink-0 border ${card.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                </div>

                {/* Value & Percentage Badge */}
                <div className="flex items-baseline justify-between gap-2 min-w-0">
                  <div className="flex items-baseline gap-1.5 min-w-0">
                    <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-mono tabular-nums">
                      {card.value}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">parti</span>
                  </div>

                  {card.id !== 'ALL' && (
                    <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200 shrink-0">
                      %{percentage}
                    </span>
                  )}
                </div>

                {/* Percentage Visual Progress Bar */}
                {card.id !== 'ALL' && (
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 rounded-full ${
                        card.id === 'COMPLETED' ? 'bg-emerald-600' :
                        card.id === 'INCIDENT' ? 'bg-rose-500' :
                        card.id === 'SHIPPED' ? 'bg-amber-500' : 'bg-teal-600'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(5, percentage))}%` }}
                    />
                  </div>
                )}

                <p className="text-[11px] text-slate-500 truncate min-w-0">
                  {card.subtext}
                </p>
              </div>

              {/* Sub-breakdown for SAHA & HASAT HAZIR */}
              {card.hasBreakdown && (
                <div className="mt-3 pt-2.5 border-t border-slate-100 grid grid-cols-2 gap-1.5 text-xs font-mono min-w-0">
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-50 border border-slate-100 text-slate-700 rounded-lg font-bold min-w-0">
                    <span className="truncate">Hasat:</span>
                    <span className="font-extrabold ml-1 tabular-nums text-emerald-700">{fieldBreakdown.hasatBekleyen}</span>
                  </div>
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-50 border border-slate-100 text-slate-700 rounded-lg font-bold min-w-0">
                    <span className="truncate flex items-center gap-0.5">
                      <Snowflake className="w-3 h-3 inline text-cyan-600" />
                      FD:
                    </span>
                    <span className="font-extrabold ml-1 tabular-nums text-cyan-700">{fieldBreakdown.freezeDry}</span>
                  </div>
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-50 border border-slate-100 text-slate-700 rounded-lg font-bold min-w-0">
                    <span className="truncate">Ambar:</span>
                    <span className="font-extrabold ml-1 tabular-nums text-teal-700">{fieldBreakdown.ambar}</span>
                  </div>
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-50 border border-slate-100 text-slate-700 rounded-lg font-bold min-w-0">
                    <span className="truncate">Lojistik:</span>
                    <span className="font-extrabold ml-1 tabular-nums text-amber-700">{fieldBreakdown.lojistik}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 2. RECHARTS STOCK LEVELS BAR CHART (Mevcut Stok Miktarları - kg) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-50 text-teal-700 border border-teal-200">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                  Mevcut Ürün Stok Dağılımı (kg)
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono">
                  {(totalStockKg / 1000).toFixed(1)} Ton Toplam
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                Ambar kabulü yapılmış ve depolardaki aktif ürün partilerinin kilogram bazlı anlık stok hacmi
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setIsThresholdModalOpen(prev => !prev)}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                isThresholdModalOpen
                  ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                  : 'text-teal-700 hover:bg-teal-100 bg-teal-50 border-teal-200'
              }`}
              title="Kritik Stok Eşik Ayarlarını Kişiselleştir"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Stok Ayarları</span>
            </button>

            {onResetStocks && (
              <button
                type="button"
                onClick={onResetStocks}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-700 hover:bg-rose-100 bg-rose-50 border border-rose-200 rounded-lg transition cursor-pointer"
                title="Mevcut Ürün Stok Dağılımını Sıfırla"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Stokları Sıfırla</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowStockChart(!showStockChart)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-200 bg-slate-100 border border-slate-200 rounded-lg transition cursor-pointer"
              title={showStockChart ? 'Grafiği Gizle' : 'Grafiği Göster'}
            >
              <span className="hidden sm:inline">{showStockChart ? 'Gizle' : 'Grafiği Göster'}</span>
              {showStockChart ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* 2.1 KULLANICI KİŞİSELLEŞTİRİLEBİLİR KRİTİK STOK AYARLARI PANELİ */}
        {isThresholdModalOpen && (
          <div className="mb-4 p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-teal-200 shadow-2xs space-y-3 animate-in fade-in slide-in-from-top-1 duration-150">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-teal-600" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                  Ürün Bazlı Kritik Asgari Stok Eşikleri (kg)
                </h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetToDefaultThresholds}
                  className="text-[10px] text-slate-500 hover:text-slate-800 underline font-medium cursor-pointer"
                >
                  Varsayılana Dön
                </button>
                <button
                  type="button"
                  onClick={() => setIsThresholdModalOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
                  title="Paneli Kapat"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-[11px] text-slate-500">
              Depodaki ürün miktarı belirlenen eşik değerinin altına düştüğünde sistem sarı/kırmızı kritik seviye uyarısı verir.
            </p>

            {/* Eşik Kartları Listesi */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {Object.entries(thresholds).map(([prod, thVal]) => {
                const currentItem = stockChartData.find(s => s.product === prod);
                const currentKg = currentItem ? currentItem.stockKg : 0;
                const isBelow = currentKg < thVal;
                return (
                  <div
                    key={prod}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition ${
                      isBelow ? 'bg-amber-50/90 border-amber-300' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-800 truncate" title={prod}>{prod}</div>
                      <div className="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span>Mevcut: <strong className="font-mono text-slate-700">{currentKg} kg</strong></span>
                        {isBelow && (
                          <span className="text-[9px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-1 py-0.2 rounded font-mono">
                            Kritik
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <input
                        type="number"
                        min="0"
                        step="50"
                        value={thVal}
                        onChange={(e) => handleUpdateThreshold(prod, Number(e.target.value) || 0)}
                        className="w-20 px-2 py-1 text-xs text-right font-mono font-bold bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-500"
                        title="Eşik kg"
                      />
                      <span className="text-[10px] font-mono text-slate-400">kg</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteThreshold(prod)}
                        className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                        title="Eşiği Kaldır"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Yeni Ürün Eşiği Ekleme Satırı */}
            <div className="flex items-center gap-2 pt-1 border-t border-slate-200/60 flex-wrap">
              <input
                type="text"
                placeholder="Yeni Ürün Adı (örn: Elma Starking)..."
                value={newProductName}
                onChange={(e) => setNewProductName(e.target.value)}
                className="text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg flex-1 min-w-[140px]"
              />
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  step="50"
                  placeholder="Eşik (kg)"
                  value={newProductThreshold}
                  onChange={(e) => setNewProductThreshold(Number(e.target.value) || 0)}
                  className="w-24 text-xs px-2 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-right"
                />
                <span className="text-xs text-slate-500 font-mono">kg</span>
              </div>
              <button
                type="button"
                onClick={handleAddCustomThreshold}
                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ekle</span>
              </button>
            </div>
          </div>
        )}

        {showStockChart && (
          <div className="mt-2">
            {stockChartData.length === 0 ? (
              <div className="py-8 px-4 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <p className="text-xs font-bold text-slate-700">
                  ⏳ Sıfır Veri / Veri Bekleniyor (Cold-Start Modu)
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  İlk gerçek Ambar Kabul veya Hasat partisi girildiğinde ürün bazlı stok grafiği otomatik hesaplanacaktır.
                </p>
              </div>
            ) : (
              <>
                <div className="w-full h-44 sm:h-48 min-w-0">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stockChartData} margin={{ top: 10, right: 10, left: -15, bottom: 25 }}>
                      <XAxis
                        dataKey="product"
                        tick={{ fontSize: 10, fill: '#64748b' }}
                        interval={0}
                        angle={-15}
                        textAnchor="end"
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#64748b' }}
                        tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-xl border border-slate-700 space-y-1">
                                <div className="flex items-center justify-between gap-3">
                                  <p className="font-bold text-teal-300">{data.product}</p>
                                  {data.isCritical && (
                                    <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[9px] font-bold">
                                      ⚠️ Kritik Seviye
                                    </span>
                                  )}
                                </div>
                                <p className="text-slate-200 mt-1 flex items-center gap-2">
                                  <span>Stok Miktarı:</span>
                                  <strong className="font-mono text-emerald-400">
                                    {data.stockKg.toLocaleString('tr-TR')} kg
                                  </strong>
                                </p>
                                <div className="text-[10px] text-slate-400 flex items-center justify-between gap-2 pt-0.5 border-t border-slate-800">
                                  <span>Kritik Eşik: <strong className="font-mono text-slate-300">{data.threshold || 500} kg</strong></span>
                                  <span>{data.batchCount} Parti</span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar
                        dataKey="stockKg"
                        radius={[6, 6, 0, 0]}
                        maxBarSize={45}
                      >
                        {stockChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill || '#10b981'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Quick summary product badges */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 mt-1 text-[11px]">
                  {stockChartData.map((item, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border whitespace-nowrap shrink-0 transition ${
                        item.isCritical
                          ? 'bg-amber-50 border-amber-300 text-amber-900'
                          : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: item.fill || '#10b981' }}
                      />
                      <span className="font-medium text-slate-800">
                        {item.product}:
                      </span>
                      <span className="font-bold font-mono">
                        {item.stockKg.toLocaleString('tr-TR')} kg
                      </span>
                      {item.isCritical && (
                        <span className="text-[9px] font-black text-rose-700 bg-rose-100 px-1 py-0.2 rounded font-mono">
                          Eşik Altı (&lt;{item.threshold}kg)
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* COLLAPSIBLE DASHBOARD PANEL: SYNC HEALTH & STOK RİSK RADARI (ALTA ALINDI) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm transition-all mt-4">
        {/* Toggle Bar */}
        <div 
          onClick={toggleTopPanel}
          className="p-3.5 px-4 bg-slate-900 hover:bg-slate-800 flex items-center justify-between gap-3 cursor-pointer select-none transition border-b border-slate-800/80"
        >
          <div className="flex items-center gap-2.5 flex-wrap min-w-0">
            <div className="p-1.5 rounded-lg bg-teal-500/20 text-teal-400 border border-teal-500/30">
              <Activity className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-xs sm:text-sm text-white tracking-tight">
              Senkronizasyon Sağlığı &amp; Stok Risk Paneli
            </span>
            
            {/* Quick Badges when collapsed */}
            <div className="flex items-center gap-2 text-[10px] font-mono">
              <span className={`px-2 py-0.5 rounded border ${
                isOnline ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              }`}>
                {isOnline ? '🟢 Online' : '🔴 Offline'}
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 hidden sm:inline">
                Son Senkron: {lastSyncTime || 'Anlık'}
              </span>
              {offlineQueueCount > 0 && (
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                  ⚠️ {offlineQueueCount} Kuyrukta
                </span>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleTopPanel();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer shrink-0"
          >
            <span>{isTopPanelExpanded ? 'Paneli Gizle' : 'Paneli Göster'}</span>
            {isTopPanelExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Collapsible Content */}
        {isTopPanelExpanded && (
          <div className="p-3 sm:p-4 bg-slate-950/40 space-y-4">
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              <SyncHealthCard
                lastSyncTime={lastSyncTime}
                offlineQueueCount={offlineQueueCount}
                isSyncing={isSyncing}
                isOnline={isOnline}
                onManualSync={onManualSync}
                onOpenSyncModal={onOpenSyncModal}
              />
              <StockRiskRadarCard
                references={references}
                ambarRecords={ambarRecords}
                thresholds={thresholds}
                onOpenThresholdSettings={() => setIsThresholdModalOpen(true)}
              />
            </div>

            {/* Stok Tükeniş Tarihi (D3 Bar Grafiği) */}
            <StockDepletionChart
              references={references}
              ambarRecords={ambarRecords}
            />
          </div>
        )}
      </div>

    </div>
  );
};
