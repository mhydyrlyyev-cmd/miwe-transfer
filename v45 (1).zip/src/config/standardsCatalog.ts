/**
 * v4.2 — MIWE HIL Standart kataloğu (OECD / UNECE, "en sıkı değer geçerli").
 *
 * Her ürün için 4 katman:
 *   1) Taban: tüm sınıflarda ortak minimum gereklilikler (sağlam, temiz, çürüksüz, zararlısız, anormal nem/koku yok)
 *   2) Olgunluk: kaynaklı sayısal şart (varsa)
 *   3) Sınıf toleransları: ürün broşüründen (Extra / I / II)
 *   4) Yerel (TDS/GOST) ve müşteri şartı: yerel daha sıkıysa yerel geçerli; müşteri yalnız o sevkiyatta
 *
 * status: VERIFIED = kaynakla doğrulandı · INTERNAL = standartta sayı yok, platform değeri iç hedef ·
 *         TO_VERIFY = kaynak henüz okunmadı · PLATFORM = MIWE HIL iç standardı (ör. muz sarartma)
 */
export type StdStatus = 'VERIFIED' | 'INTERNAL' | 'TO_VERIFY' | 'PLATFORM';

export interface StdEntry {
  key: string;
  product: string;
  match: string[];          // ürün adında aranacak kelimeler (küçük harf)
  code: string;             // UNECE / OECD / Codex kodu
  maturity: string;         // uluslararası sayısal şart (yoksa açıklama)
  internal?: string;        // platform iç hedefi
  status: StdStatus;
  source?: { label: string; url: string };
  note?: string;
}

export const BASE_REQUIREMENTS =
  'Tüm sınıflarda: sağlam, bütün, temiz, çürük ve bozulma yok, zararlı ve zararlı hasarı yok, anormal dış nem ve yabancı koku/tat yok; taşıma ve elleçlemeye dayanacak gelişmişlikte.';

export const STATUS_LABEL: Record<StdStatus, string> = {
  VERIFIED: 'Doğrulandı',
  INTERNAL: 'İç değer',
  TO_VERIFY: 'Doğrulanacak',
  PLATFORM: 'MIWE iç standardı',
};

export const STANDARDS_CATALOG: StdEntry[] = [
  { key: 'grape', product: 'Sofralık üzüm', match: ['üzüm', 'uzum', 'grape'], code: 'UNECE FFV-19', status: 'VERIFIED',
    maturity: '≥16 °Bx. Daha düşükse şeker/asit: 14–16 °Bx → ≥18:1; 12,5–14 °Bx → ≥20:1',
    source: { label: 'UNECE FFV-19 (2007)', url: 'https://digitallibrary.un.org/record/605452/files/%5BE_%5DECE_TRADE_C_WP.7_2007_6-EN.pdf' },
    note: 'AB 543/2011 (12/13/14 °Bx) daha gevşek → UNECE geçerli.' },
  { key: 'kiwi', product: 'Kivi', match: ['kivi', 'kiwi'], code: 'UNECE FFV-46', status: 'VERIFIED',
    maturity: 'Paketlemede ≥6,2 °Bx veya ortalama kuru madde ≥%15; dağıtıma girişte ≥9,5 °Bx',
    source: { label: 'Kivi pazarlama standardı', url: 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/869234/marketing-standard-kiwifruit.pdf' } },
  { key: 'avocado', product: 'Avokado', match: ['avokado', 'avocado', 'avakado'], code: 'UNECE FFV-42', status: 'VERIFIED',
    maturity: 'Kuru madde: Hass ≥%21; Fuerte, Pinkerton, Reed, Edranol ≥%20; diğer ≥%19',
    internal: 'Hass %23 (Avrupa alıcı tercihi → müşteri katmanı)',
    source: { label: 'UNECE FFV-42', url: 'https://digitallibrary.un.org/record/459264/files/%5BE_ECE_%5DTRADE_WP.7_2001_9_Add.6-EN.pdf' } },
  { key: 'peach', product: 'Şeftali / Nektarin', match: ['şeftali', 'seftali', 'nektarin', 'peach', 'nectarine'], code: 'UNECE FFV-26', status: 'VERIFIED',
    maturity: '≥8 °Bx ve sertlik <6,5 kg (8 mm uç, 0,5 cm², ekvatorda 2 nokta)',
    internal: 'Alt sertlik sınırı (4,5 kg) iç hedef',
    source: { label: 'UNECE FFV-26 (2006)', url: 'https://digitallibrary.un.org/record/581808/files/%5BE_%5DECE_TRADE_C_WP.7_2006_6-EN.pdf' } },
  { key: 'melon', product: 'Kavun', match: ['kavun', 'gawun', 'melon'], code: 'UNECE FFV-23', status: 'VERIFIED',
    maturity: 'Charentais tipi ≥10 °Bx; diğer kavunlar ≥8 °Bx', internal: '10,5–12 °Bx iç hedef / müşteri',
    source: { label: 'AB 1615/2001 (UNECE ile aynı)', url: 'https://legislation.gov.uk/eur/2001/1615/pdfs/eur_20011615_2006-07-25_en.pdf' } },
  { key: 'watermelon', product: 'Karpuz', match: ['karpuz', 'garpyz', 'watermelon'], code: 'UNECE FFV-37', status: 'VERIFIED',
    maturity: '≥8 °Bx (meyve etinin ortası, ekvator kesiti)', internal: '10,5–12 °Bx iç hedef',
    source: { label: 'AB 1862/2004 (FFV-37 temelli)', url: 'https://www.legislation.gov.uk/eur/2004/1862/data.html' } },
  { key: 'pineapple', product: 'Ananas', match: ['ananas', 'pineapple'], code: 'UNECE FFV-49', status: 'VERIFIED',
    maturity: '≥12 °Bx (meyve eti)', internal: 'Alıcılar genelde 13–17 °Bx ister (müşteri katmanı)',
    source: { label: 'Codex CXS 182', url: 'https://www.fao.org/input/download/standards/313/CXS_182e.pdf' } },
  { key: 'apple', product: 'Elma', match: ['elma', 'alma', 'apple'], code: 'UNECE FFV-50', status: 'INTERNAL',
    maturity: 'Genel Brix sınırı yok; yalnız mini çeşitlerde ≥12 °Bx. Yeterince gelişmiş ve olgun olmalı',
    internal: 'Brix, sertlik, nişasta ve Streif değerleri iç hedef',
    source: { label: 'Elma pazarlama standardı', url: 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/869232/marketing-standard-apples.pdf' },
    note: 'FFV-01 2002\'de kaldırıldı; armut ayrı standart.' },
  { key: 'persimmon', product: 'Trabzon hurması', match: ['hurma', 'persimmon', 'kaki', 'hurmа'], code: 'UNECE FFV-63 (2015)', status: 'INTERNAL',
    maturity: 'Sayısal şart yok: yeterince gelişmiş, hasattan sonra olgunlaşmayı sürdürebilir olmalı', internal: 'Tanen 1–5 ve renk iç değer' },
  { key: 'pomegranate', product: 'Nar', match: ['nar ', 'nar(', 'pomegranate'], code: 'Codex 2013 · OECD broşürü 2014', status: 'INTERNAL',
    maturity: 'Sayısal şart görülmedi: yeterince gelişmiş ve olgun olmalı', internal: '14 °Bx ve %40 randıman iç değer',
    source: { label: 'OECD nar broşürü', url: 'https://www.oecd.org/en/publications/2014/03/pomegranate_g1g39429.html' } },
  { key: 'pistachio', product: 'Antep fıstığı', match: ['fıstık', 'fistik', 'pistachio', 'piste'], code: 'UNECE DDP-09', status: 'VERIFIED',
    maturity: 'Kabuklu fıstık içi nem ≤%6,5', internal: '%85 doğal çıtlak iç hedef (kaynak doğrulanacak)',
    source: { label: 'UNECE kabuklu fıstık', url: 'https://digitallibrary.un.org/record/439325/files/%5EE_ECE_%5ETRADE_WP.7_GE.2_2001_6--TRADE_WP.7_GE.2_2001_6-EN.pdf' } },
  { key: 'almond', product: 'Badem', match: ['badem', 'almond'], code: 'UNECE DDP (kabuklu / iç)', status: 'VERIFIED',
    maturity: 'Kabuklu: tüm meyvede nem ≤%11,0 veya içte ≤%7,0. İç badem ≤%6,5 (teyit edilecek)',
    internal: 'Hasat öncesi: kabuk (hull) açılması ≥%75, iç nem ~%12 → sulama kesilir, kombayn hasadı',
    source: { label: 'UNECE kabuklu badem (2005)', url: 'https://digitallibrary.un.org/record/556180/files/%5EE_ECE_%5ETRADE_WP-7_GE-2_2005_19_Add-1-EN.pdf' } },
  { key: 'banana', product: 'Muz', match: ['muz', 'banana', 'banan'], code: 'UNECE FFV-35 / Codex 205', status: 'VERIFIED',
    maturity: 'Yeşil, olgunlaşmamış hasat (sayısal Brix şartı yok). Boyut: boy ≥14 cm, kalınlık ≥27 mm (dış sıranın orta parmağı). Kabuk kusuru: Ekstra ≤1 cm², I ≤2 cm², II ≤4 cm². Tolerans: kalite %5 / %10 / %10; boyut %10 (en fazla 1 cm kısa)',
    source: { label: 'Codex STAN 205 (UNECE FFV-35 ile aynı değerler)', url: 'https://www.fao.org/input/download/standards/329/CXS_205e.pdf' },
    internal: 'Sarartma: 14 °C, 35 ppm etilen, 8 gün (standart); satış rengi 1–7 skalasında hedef 3. Erken çıkış → olay (akt) kaydı' },
  { key: 'mango', product: 'Mango', match: ['mango'], code: 'UNECE FFV-45', status: 'VERIFIED',
    maturity: 'Sayısal olgunluk şartı yok (yeterince gelişmiş olmalı). Boyut ağırlığa göre: A 100–350 g, B 351–550 g, C 551–800 g, D >800 g. Tolerans: kalite I. sınıf %10, boyut %10',
    internal: 'Kuru madde %14–16 iç hedef (alıcıyla Brix/olgunluk anlaşılır)',
    source: { label: 'CBI özet (UNECE FFV-45 2023)', url: 'https://cbi.eu/sites/default/files/pdf/research/1207.pdf' } },
  { key: 'plum', product: 'Erik', match: ['erik', 'plum'], code: '—', status: 'INTERNAL', maturity: '2009 OECD listesinde sayısal şart yok', internal: '12 °Bx iç hedef' },
  { key: 'tomato', product: 'Domates', match: ['domates', 'pomidor', 'tomato'], code: 'UNECE FFV-36', status: 'INTERNAL', maturity: '2009 OECD listesinde sayısal şart yok', internal: '4,5 °Bx iç hedef' },
  { key: 'onion', product: 'Soğan', match: ['soğan', 'sogan', 'onion'], code: 'UNECE FFV-25', status: 'INTERNAL', maturity: '2009 OECD listesinde sayısal şart yok', internal: 'Boyun kuruluğu ≥%90, KM ≥%13 iç hedef' },
  { key: 'carrot', product: 'Havuç', match: ['havuç', 'havuc', 'käşir', 'carrot'], code: 'UNECE FFV-10', status: 'INTERNAL', maturity: '2009 OECD listesinde sayısal şart yok', internal: '8,5 °Bx iç hedef' },
  { key: 'potato', product: 'Patates', match: ['patates', 'kartoşka', 'kartoska', 'potato'], code: 'UNECE FFV-52', status: 'VERIFIED',
    maturity: 'Asgari boyut (kare elek): sofralık 35 mm, uzun çeşit 30 mm, turfanda 28 mm. Kalite toleransı: asgari şartı karşılamayan sofralıkta %6, turfandada %4; atık %2 (yapışık toprak en fazla %1)',
    internal: 'Özgül ağırlık 1,075–1,095 iç hedef',
    source: { label: 'UNECE FFV-52 (2009)', url: 'https://digitallibrary.un.org/record/671675/files/%5BE_%5DECE_TRADE_C_WP.7_2009_12-EN.pdf' } },
  { key: 'pear', product: 'Armut', match: ['armut', 'pear'], code: 'UNECE FFV-51', status: 'VERIFIED',
    maturity: 'Asgari çap — iri meyveli: Ekstra 60, I 55, II 55 mm; diğer: 55 / 50 / 45 mm (ağırlıkla: iri 130/110/110 g, diğer 110/100/75 g). Yaz armutlarında asgari boyut yok. Boyut toleransı %10, en fazla 5 mm altı',
    source: { label: 'AB 543/2011 armut standardı (UNECE FFV-51 ile aynı)', url: 'https://webgate.ec.europa.eu/reqs2/public/v2/requirement/auxi/eu/32011R0543_mktfrveg_annex_1b_pears.pdf/' } },
  { key: 'blueberry', product: 'Yaban mersini', match: ['yaban mersini', 'blueberry', 'mersin'], code: 'UNECE FFV-57 (meyve çilekleri)', status: 'VERIFIED',
    maturity: 'Sayısal şart yok: yeterince gelişmiş ve olgun. Yaban mersini çeşide uygun şekilde pusla (bloom) neredeyse tamamen kaplı ve yapışık tane içermemeli',
    source: { label: 'OECD meyve çilekleri broşürü (UNECE FFV-57)', url: 'https://www.baib.gov.tr/files/downloads/PageFiles/53074dd5-9771-e911-9bde-001a64655414/Files/ek%201%20oecd%20bro%C5%9F%C3%BCr%C3%BCekbro%C5%9F%C3%BCr.pdf' } },
  { key: 'garlic', product: 'Sarımsak', match: ['sarımsak', 'sarimsak', 'garlic'], code: 'UNECE FFV-18', status: 'VERIFIED',
    maturity: 'Asgari çap: Ekstra 45 mm, I ve II. sınıf 30 mm. Boyut toleransı %10 (en fazla %3\'ü asgarinin altında ama ≥25 mm). Dişlerinde dışarıdan görünür filiz olan baş en fazla %5',
    source: { label: 'UNECE FFV-18 / AB 2288/97', url: 'https://legislation.gov.uk/eur/1997/2288/pdfs/eur_19972288_2005-01-06_en.pdf' } },
  { key: 'coconut', product: 'Hindistan cevizi', match: ['hindistan', 'coconut'], code: 'Taze olgun ceviz için UNECE standardı yok', status: 'INTERNAL',
    maturity: 'Uluslararası taze standart bulunamadı (UNECE yalnız kurutulmuş parçalar için)',
    internal: 'Kabul kontrolü: çatlak/sızıntı yok, sallayınca su sesi var, göz bölgesinde küf yok, yabancı koku yok' },
  { key: 'corn', product: 'Mısır', match: ['mısır', 'misir', 'corn', 'meke'], code: 'USDA (taze koçan; UNECE standardı yok)', status: 'VERIFIED',
    maturity: 'USDA tatlı mısır: koçan boyu U.S. Fancy ≥127 mm, U.S. No. 1 ≥101,6 mm; taneler dolgun ve sütlü',
    internal: 'Depoluk/silo mısırda %14 nem iç hedef',
    source: { label: 'USDA sweet corn grade standards', url: 'https://www.ams.usda.gov/node/5059' } },
];

/** Ürün adına göre katalog satırı (en uzun eşleşme önce). */
export function findStandard(productName?: string): StdEntry | undefined {
  const p = ` ${String(productName || '').toLocaleLowerCase('tr')} `;
  let best: StdEntry | undefined; let len = 0;
  for (const e of STANDARDS_CATALOG) {
    for (const m of e.match) {
      if (p.includes(m) && m.length > len) { best = e; len = m.length; }
    }
  }
  return best;
}
