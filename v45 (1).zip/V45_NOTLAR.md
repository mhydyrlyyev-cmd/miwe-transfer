# v45 — Sadeleştirme, muz UNECE FFV-35, test kaynak etiketleri

Kural: kaynağı doğrulanan değer "UNECE/OECD", doğrulanmayan değer "İç hedef" olarak yazılır.

## Kaldırılanlar (neden)
- Kalite analizi: "Son 7 gün tonaj vs kalite skoru" grafiği — iki farklı ölçek, hasatsız günler 0 ton, kalite yalnız 2 nokta; yanıltıcı.
- Kalite analizi: otomatik "Freeze & Dry'a aktar" bandı — ölçülmeyen (0) sertlik değerleri yüzünden tüm partileri acil gösteriyordu.
- Profil: oturum/token kartı — yalnız Yönetici paneli › Sistem (teknik) sekmesinde.
- Google Sheets ayarı: eski gömülü Code.gs ve eski "17 sayfa" listesi — güncel değildi; yerine kısa açıklama.
- "Senk" düğmesindeki "Sheets'ten veri çekiliyor" mesajı — içeri aktarma kapalı olduğu için yanlıştı.
- Kiraz alanları (Hue açısı, gübreleme notu) ve doğrulanamayan "[MDPI 2026]" / "[Horticulturae 2025]" atıfları — artık yalnız kiraz/vişnede görünür, atıflar kaldırıldı.
- Kayıp grafiği tek aşamada çubuk grafik yerine tek cümle.

## Düzeltilenler
- Analiz kuralları: ölçülmeyen değer kural tetiklemez; sertlik/Streif "İç hedef", nitrat "Yerel limit"; sertlik %10'dan az eksikse uyarı, fazlaysa kritik.
- Gıda kaybı: olay kaydındaki "etkilenen kg" kayıp sayılmaz (ayrıca gösterilir).
- Muz: UNECE FFV-35 / Codex 205 (boy ≥14 cm, kalınlık ≥27 mm, sınıf/kusur/tolerans) — kriter paneli, sınıflama, denetim, rehber, katalog. Vakum soğutma ifadesi kaldırıldı. 45 mm üstü kalınlıkta birim uyarısı.
- Muz pasaportu: Kesim → Paket/muhafaza → Sarartma → Sevk/satış; satış "sevk" sayılır; ön soğutma bölümü muzda gizli; renk evresi ≠ kalite sınıfı; Brix °Bx.
- Test şablonları: kivi ve havuç seçenekleri eklendi (kivide "Mango" görünme hatası); 16 ürünün açıklaması kaynak/iç hedef olarak düzeltildi.
- Uyarılar: RefID çakışması "kayıt hatası" başlığıyla; boş "()" temizliği; "Soğuk zincirde açık uyarı yok".
- Depo durumu: haftanın sonu gelecekteyse "Bugün itibarıyla".
- Kullanıcıya görünen kod yolu (src/config/…) kaldırıldı. Sayılar Türkçe biçim (4.500).

DeployRules: GEREKMEZ (firestore.rules değişmedi). Yeni paket yok.

## Ek (v45 son hali)
- Standart kataloğu: mango (FFV-45), patates (FFV-52), armut (FFV-51), yaban mersini (FFV-57), sarımsak (FFV-18) doğrulandı; mısır USDA (UNECE standardı yok); hindistan cevizi iç kontrol (taze olgun ceviz için uluslararası standart yok). "Doğrulanacak" ürün kalmadı.
- Giriş (önizleme): uygulama iframe içindeyse ve Google penceresi açılamazsa "Uygulamayı yeni sekmede aç" düğmesi çıkar; iframe dışında açılır pencere engellenirse yönlendirmeli girişe geçer ve dönüşte oturum tamamlanır. "unauthorized-domain" hatası hangi alan adının Firebase'e ekleneceğini söyler. Giriş hata kutusunun okunmayan açık renkli yazısı düzeltildi.
