import React, { useMemo, useState } from 'react';
import { ArrowLeft, Plus, X } from 'lucide-react';
import type { AmbarRecord, ReferenceItem } from '../../types';
import { generateRefId } from '../../utils/calculations';
import { getCurrentUser } from '../../utils/authService';
import { useLocationProfiles } from '../../services/locationProfiles';
import { roomsOf, roomCode, roomType, setLabel } from '../../services/depots';
import { specForProduct } from '../../config/productSpecs';
import { calculateGostDefects, getGostProductTolerances } from '../../utils/gostQualityCalculators';

/**
 * v53 — Depo kabul (görsel 33). Kantar brüt − dara = net (otomatik), irsaliyeye göre fire,
 * ürün iç sıcaklığı (ürün spesifikasyonundaki taşıma üst sınırı), numune kutuları → GOST kusur oranı ve karar.
 * Eşikler: productSpecs (taşıma °C) ve gostQualityCalculators (GOST toleransı) — burada yeni eşik yok.
 * Kayıt eski formla aynı AmbarRecord. Eski form: düzenleme ve "ayrıntılı form" (palet, ambalaj listesi, kutu kutu sınıf).
 */
type Inbound = 'DOMESTIC' | 'IMPORT_EURASIA_GOST' | 'IMPORT_OTHER';
const INB: { k: Inbound; l: string }[] = [{ k: 'DOMESTIC', l: 'Yurtiçi' }, { k: 'IMPORT_EURASIA_GOST', l: 'İthalat (GOST)' }, { k: 'IMPORT_OTHER', l: 'Diğer ithalat' }];
interface Box { kg: string; rot: string; mech: string; nonstd: string }
const emptyBox = (): Box => ({ kg: '', rot: '', mech: '', nonstd: '' });
const n = (s: string) => { if (s === '' || s == null) return undefined; const v = Number(String(s).replace(/\s/g, '').replace(',', '.')); return Number.isFinite(v) ? v : undefined; };
const f = (x: number, d = 1) => x.toLocaleString('tr-TR', { maximumFractionDigits: d });

interface Props {
  onSave: (record: AmbarRecord, refId: string) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  existingAmbar: AmbarRecord[];
  initialRefId?: string;
  isReadOnly?: boolean;
}

export default function QuickIntakeForm(p: Props) {
  const depots = useLocationProfiles('WAREHOUSE');
  useLocationProfiles('ROOM');
  const inDepot = useMemo(() => new Set(p.existingAmbar.map(a => a.refId)), [p.existingAmbar]);
  const waiting = useMemo(() => p.existingRefs.filter(r => !inDepot.has(r.refId) && r.refKind !== 'TEST' && !/SHIPPED|SOLD|DELIVERED/i.test(String(r.status || ''))).slice(0, 12), [p.existingRefs, inDepot]);
  const [inb, setInb] = useState<Inbound>('DOMESTIC');
  const [src, setSrc] = useState<'INTERNAL' | 'EXTERNAL'>(p.initialRefId ? 'INTERNAL' : 'INTERNAL');
  const [refId, setRefId] = useState(p.initialRefId || '');
  const [extProduct, setExtProduct] = useState('');
  const [extVariety, setExtVariety] = useState('');
  const [supplier, setSupplier] = useState('');
  const [depotId, setDepotId] = useState('');
  const [room, setRoom] = useState('');
  const [gross, setGross] = useState('');
  const [tare, setTare] = useState('');
  const [waybill, setWaybill] = useState('');
  const [pulp, setPulp] = useState('');
  const [roomT, setRoomT] = useState('');
  const [boxes, setBoxes] = useState<Box[]>([]);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const ref = p.existingRefs.find(r => r.refId === refId);
  const product = src === 'EXTERNAL' ? extProduct : (ref?.product || '').replace(/\s*\(.*\)$/, '');
  const depot = depots.find(d => d.id === depotId);
  const rooms = depot ? roomsOf(depot) : [];
  const G = n(gross), T = n(tare), Wb = n(waybill), P = n(pulp);
  const net = G !== undefined ? G - (T || 0) : undefined;
  const diff = net !== undefined && Wb ? net - Wb : undefined;
  const diffPct = diff !== undefined && Wb ? (diff / Wb) * 100 : undefined;
  const spec = specForProduct(product);
  const tMax = spec.transportTempMaxC ?? spec.storageTempMaxC ?? undefined;
  const hot = P !== undefined && tMax !== undefined && tMax !== null && P > tMax;
  const tol = getGostProductTolerances(product);
  const sumK = (k: keyof Box) => boxes.reduce((s, b) => s + (n(b[k]) || 0), 0);
  const sampleKg = sumK('kg');
  const gost = sampleKg > 0 ? calculateGostDefects({ sampleBoxCount: boxes.length, sampleWeightKg: sampleKg, internalRotNecrosisKg: 0, obviousRotTheRotIsObviousKg: sumK('rot'), mechanicsKg: sumK('mech'), dilutionTopKg: sumK('nonstd'), easyDeformationKg: 0, productName: product }) : undefined;
  const fireOk = diffPct === undefined || Math.abs(diffPct) <= 2;

  const verdict = !net ? '' : gost?.decision === 'REJECTED_INCIDENT' ? 'Red · akt aç' : gost?.decision === 'CONDITIONAL_DISCOUNT' ? 'Şartlı kabul' : hot || !fireOk ? `Kabul · tedarikçiye not: ${[hot ? 'sıcaklık' : '', !fireOk ? 'fire' : ''].filter(Boolean).join(', ')}` : 'Kabul';
  const canSave = !!net && net > 0 && !!depot && !!room && (src === 'INTERNAL' ? !!ref : !!extProduct.trim() && !!supplier.trim()) && !p.isReadOnly;

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const id = src === 'INTERNAL' ? refId : generateRefId('AMBAR', p.existingRefs.map(r => r.refId));
    const g = gost;
    const rec: AmbarRecord = {
      id: `amb-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, refId: id, timestamp: new Date().toISOString(), operator: getCurrentUser()?.fullName || '',
      acceptanceDate: new Date().toISOString().slice(0, 10), warehouse: depot!.name, roomNo: room, treatmentApplied: 'Standart Depolama',
      expectedWeightKg: Wb, acceptedWeightKg: net!, weightDiffKg: diff !== undefined ? Number(diff.toFixed(1)) : undefined, weightDiffPercent: diffPct !== undefined ? Number(diffPct.toFixed(2)) : undefined,
      weighbridgeGrossKg: G, weighbridgeTareKg: T, weighbridgeNetKg: net,
      productTemperature: P as number, roomTemperature: n(roomT) as number, humidityPercent: undefined as unknown as number,
      packaging: 'Standart Kasa', acceptanceStatus: g?.decision === 'REJECTED_INCIDENT' ? 'REJECTED' : g?.decision === 'CONDITIONAL_DISCOUNT' ? 'PARTIAL' : 'ACCEPTED',
      hygieneStatus: 'Uygun', coldChainStatus: hot ? 'Kritik Sapma' : 'Uygun', testStatus: 'COMPLETED', nextStep: 'Depolama', notes: note,
      inboundType: inb, supplier: supplier || undefined, incomingSource: src, product: src === 'EXTERNAL' ? extProduct.trim() : undefined, variety: src === 'EXTERNAL' ? (extVariety.trim() || undefined) : undefined,
      ...(g ? {
        sampleBoxCount: g.sampleBoxCount, sampleWeightKg: g.sampleWeightKg, samplePercent: g.samplePercent, wastePercent: g.wastePercent, rotKg: g.rotKg, rotPercent: g.rotPercent,
        obviousRotTheRotIsObviousKg: g.obviousRotTheRotIsObviousKg, obviousRotTheRotIsObviousPercent: g.obviousRotTheRotIsObviousPercent,
        mechanicsKg: g.mechanicsKg, mechanicsPercent: g.mechanicsPercent, dilutionTopKg: g.dilutionTopKg, dilutionTopPercent: g.dilutionTopPercent,
        nonStandardKg: g.nonStandardKg, nonStandardPercent: g.nonStandardPercent, gostDecision: g.decision,
      } : {}),
    };
    try { await p.onSave(rec, id); } finally { setSaving(false); }
  };

  const inp = 'w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 text-sm';
  const tile = (l: string, v: string, set: (s: string) => void, unit: string, sub?: React.ReactNode, warn?: boolean, auto?: boolean) => (
    <label className={`rounded-xl border px-3 py-2 min-w-0 ${warn ? 'border-amber-300 bg-amber-50 dark:bg-amber-950/30' : v ? 'border-teal-300' : 'border-slate-200 dark:border-slate-700'}`}>
      <div className="text-[10px] font-semibold text-slate-500">{l}</div>
      <div className="flex items-baseline gap-1"><input inputMode="decimal" readOnly={auto} value={v} onChange={e => set(e.target.value.replace(/[^\d.,-]/g, ''))} placeholder="—" className="w-full min-w-0 bg-transparent text-xl font-bold tabular-nums outline-none placeholder:text-slate-300" /><span className="text-[10px] text-slate-400">{unit}</span></div>
      {sub && <div className={`text-[10px] ${warn ? 'text-amber-800 font-semibold' : 'text-slate-400'}`}>{sub}</div>}
    </label>);
  const sec = 'rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-2';
  const chip = (on: boolean) => `shrink-0 px-3 min-h-[32px] rounded-full border text-xs cursor-pointer ${on ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'border-slate-300'}`;
  const row = (l: string, v: string, badge: string, ok: boolean) => (
    <div className="flex items-center justify-between py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0"><div><div className="text-[11px] text-slate-500">{l}</div><div className="text-sm font-bold tabular-nums">{v}</div></div>
      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${ok ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-amber-300 bg-amber-50 text-amber-800'}`}>{badge}</span></div>);

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onCancel} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Depo kabul</h1><p className="text-xs text-slate-500 truncate">{refId || (src === 'EXTERNAL' ? 'yeni parti açılacak' : 'parti seçin')}{depot ? ` · ${String(depot.fields?.shortName || depot.name)}` : ''}{room ? ` · ${room}` : ''}</p></div>
      </div>
      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1">{INB.map(x => <button key={x.k} type="button" onClick={() => { setInb(x.k); if (x.k !== 'DOMESTIC') setSrc('EXTERNAL'); }} className={chip(inb === x.k)}>{x.l}</button>)}</div>

      <section className={sec}>
        <div className="flex gap-1.5">{(['INTERNAL', 'EXTERNAL'] as const).map(k => <button key={k} type="button" onClick={() => setSrc(k)} className={chip(src === k)}>{k === 'INTERNAL' ? 'Kendi partimiz' : 'Dışarıdan (yeni parti)'}</button>)}</div>
        {src === 'INTERNAL' ? (
          waiting.length === 0 && !ref ? <p className="text-[11px] text-slate-500">Depoya girmemiş parti yok.</p> : (
            <div className="space-y-1">{(ref && !waiting.includes(ref) ? [ref, ...waiting] : waiting).map(r => (
              <button key={r.refId} type="button" onClick={() => { setRefId(r.refId); if (r.quantity) setWaybill(String(r.quantity)); }} className={`w-full text-left rounded-xl border px-3 py-1.5 text-xs cursor-pointer ${refId === r.refId ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/30' : 'border-slate-200 dark:border-slate-700'}`}>
                <b className="font-mono">{r.refId}</b> · {r.product}{r.orchard ? ` · ${r.orchard}` : ''}{r.quantity ? ` · ${f(r.quantity, 0)} kg` : ''}</button>))}</div>)
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <label className="text-[11px] text-slate-500">Ürün<input value={extProduct} onChange={e => setExtProduct(e.target.value)} className={inp} /></label>
            <label className="text-[11px] text-slate-500">Çeşit<input value={extVariety} onChange={e => setExtVariety(e.target.value)} className={inp} /></label>
            <label className="text-[11px] text-slate-500">Tedarikçi<input value={supplier} onChange={e => setSupplier(e.target.value)} className={inp} /></label>
          </div>
        )}
        <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{depots.map(d => <button key={d.id} type="button" onClick={() => { setDepotId(d.id); setRoom(''); }} className={chip(depotId === d.id)}>{String(d.fields?.shortName || d.name)}</button>)}</div>
        {depot && (rooms.length ? (
          <div className="grid grid-cols-4 gap-1.5">{rooms.map(r => (
            <button key={r.id} type="button" onClick={() => setRoom(roomCode(r))} className={`rounded-lg border px-1.5 py-1 text-left cursor-pointer ${room === roomCode(r) ? 'border-teal-600 bg-teal-50 dark:bg-teal-950/30' : 'border-slate-200 dark:border-slate-700'}`}>
              <div className="text-xs font-bold">{roomCode(r)}</div><div className="text-[9px] text-slate-500 truncate">{roomType(r)} · {setLabel(r)}</div></button>))}</div>
        ) : <label className="text-[11px] text-slate-500 block">Oda<input value={room} onChange={e => setRoom(e.target.value)} className={inp} /></label>)}
      </section>

      <div className="grid grid-cols-3 gap-2">
        {tile('Kantar brüt', gross, setGross, 'kg')}
        {tile('Dara', tare, setTare, 'kg')}
        {tile('Net', net !== undefined ? String(Math.round(net)) : '', () => {}, 'kg', 'otomatik', false, true)}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {tile('İrsaliye', waybill, setWaybill, 'kg')}
        {tile('Ürün iç °C', pulp, setPulp, '°C', tMax !== undefined && tMax !== null ? `${hot ? '>' : '≤'} ${f(tMax)} ${hot ? 'dikkat' : 'uygun'}` : 'sınır tanımsız', hot)}
        {tile('Oda °C', roomT, setRoomT, '°C')}
      </div>

      <section className={sec}>
        <div className="flex items-center justify-between"><h2 className="text-sm font-bold">Numune kutuları</h2>
          <button type="button" onClick={() => setBoxes(b => [...b, emptyBox()])} className="text-xs font-semibold text-teal-800 dark:text-teal-300 inline-flex items-center gap-1 cursor-pointer"><Plus className="w-3.5 h-3.5" />kutu</button></div>
        {boxes.length === 0 ? <p className="text-[11px] text-slate-500">Kutu ekleyin: kutu kg ve kusurlu meyve kg (çürük · mekanik · standart dışı). Kusur oranı ve GOST kararı kendiliğinden çıkar.</p> : (
          <div className="space-y-1.5">
            <div className="grid grid-cols-[28px_repeat(4,minmax(0,1fr))_24px] gap-1 text-[9px] text-slate-500 font-semibold"><span>#</span><span>Kutu kg</span><span>Çürük</span><span>Mekanik</span><span>Std. dışı</span><span /></div>
            {boxes.map((b, i) => (
              <div key={i} className="grid grid-cols-[28px_repeat(4,minmax(0,1fr))_24px] gap-1 items-center">
                <span className="text-xs text-slate-500">{i + 1}</span>
                {(['kg', 'rot', 'mech', 'nonstd'] as const).map(k => (
                  <input key={k} inputMode="decimal" value={b[k]} onChange={e => setBoxes(x => x.map((y, j) => (j === i ? { ...y, [k]: e.target.value.replace(/[^\d.,]/g, '') } : y)))} placeholder="0" className="min-h-[34px] w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-1.5 text-sm tabular-nums" />))}
                <button type="button" onClick={() => setBoxes(x => x.filter((_, j) => j !== i))} aria-label="Kutuyu sil" className="text-slate-400 cursor-pointer"><X className="w-4 h-4" /></button>
              </div>))}
          </div>
        )}
      </section>

      {(net || gost) && (
        <section className={sec}>
          {diff !== undefined && row('Fire / fark (net − irsaliye)', `${diff >= 0 ? '+' : '−'}${f(Math.abs(diff), 0)} kg · ${diffPct! >= 0 ? '+' : '−'}${f(Math.abs(diffPct!))} %`, '≤ 2 %', fireOk)}
          {gost && row(`Numune kusur oranı (${tol.product})`, `% ${f(gost.wastePercent)} · çürük % ${f(gost.rotPercent)}`, `≤ ${f(tol.maxWastePercent)} · çürük ≤ ${f(tol.maxRotPercent)}`, gost.decision === 'COMPLIANT')}
          {P !== undefined && row('Soğuk zincir', hot ? 'Dikkat' : 'Uygun', tMax !== undefined && tMax !== null ? `ürün ${f(P)} °C` : 'sınır tanımsız', !hot)}
        </section>
      )}

      <section className={sec}>
        <textarea rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="Not (araç, mühür, datalogger…)" className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-sm" />
        <button type="button" onClick={p.onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 cursor-pointer">Palet, ambalaj listesi, kutu kutu sınıf ve fotoğraf → ayrıntılı form</button>
      </section>

      <div className="fixed left-0 right-0 bottom-[68px] sm:bottom-4 z-30 px-3">
        <div className="max-w-xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-lg px-4 py-2.5 flex items-center gap-3">
          <div className="min-w-0 flex-1"><div className="text-[10px] text-slate-500">Sonuç</div>
            <div className={`text-sm font-bold truncate ${!verdict ? 'text-slate-500' : /Red/.test(verdict) ? 'text-rose-700' : /not|Şartlı/.test(verdict) ? 'text-amber-700' : 'text-emerald-700'}`}>{verdict || (!depot || !room ? 'Depo ve oda seçin' : 'Kantar brüt girin')}</div></div>
          <button type="button" disabled={!canSave || saving} onClick={save} className="min-h-[44px] px-6 rounded-xl bg-teal-700 text-white font-semibold disabled:opacity-40 cursor-pointer">{saving ? '…' : 'Kaydet'}</button>
        </div>
      </div>
    </div>
  );
}
