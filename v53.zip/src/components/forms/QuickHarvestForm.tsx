import React, { useMemo, useRef, useState } from 'react';
import { ArrowLeft, Camera, Check, X } from 'lucide-react';
import type { ActiveFieldContext, BademRecord, FieldRecord, HarvestRecord, MuzRecord, ReferenceItem } from '../../types';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { generateRefId } from '../../utils/calculations';
import { getCurrentUser } from '../../utils/authService';
import { canonicalOrchard, useLocationProfiles } from '../../services/locationProfiles';
import { buildCalendar, useCalOverrides } from '../../services/harvestCalendar';
import { compressImageFile } from '../../utils/imageCompressor';

/**
 * v53 — Günlük hasat, tek sayfa (görsel 31): 1 Nereden · 2 Bağlı testler · 3 Ne kadar · 4 Fotoğraf ve not.
 * Kayıt eski formla aynı HarvestRecord → parti, takvim, raporlar aynen çalışır. Eski form: düzenleme ve "ayrıntılı form".
 */
interface Props {
  onSave: (record: HarvestRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  ctx?: ActiveFieldContext | null;
  fieldRecords: FieldRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  harvestRecords?: HarvestRecord[];
  isReadOnly?: boolean;
}

const n = (s: string) => { const v = Number(String(s).replace(/\s/g, '').replace(',', '.')); return Number.isFinite(v) && s !== '' ? v : undefined; };
const kgf = (x: number) => x.toLocaleString('tr-TR', { maximumFractionDigits: 1 });
const today = () => new Date().toISOString().slice(0, 10);

export default function QuickHarvestForm(p: Props) {
  const orchProfiles = useLocationProfiles('ORCHARD');
  const whProfiles = useLocationProfiles('WAREHOUSE');
  const ovs = useCalOverrides();
  const existing = p.initialRefId ? p.existingRefs.find(r => r.refId === p.initialRefId) : undefined;
  const [orchard, setOrchard] = useState(p.ctx?.orchard || existing?.orchard || '');
  const [product, setProduct] = useState(p.ctx?.product || (existing?.product || '').replace(/\s*\(.*\)$/, ''));
  const [variety, setVariety] = useState(p.ctx?.variety || (existing?.product || '').match(/\((.*)\)/)?.[1] || '');
  const [parcel, setParcel] = useState(p.ctx?.parcelCode || '');
  const [date, setDate] = useState(today());
  const [crates, setCrates] = useState('');
  const [kg, setKg] = useState('');
  const [workers, setWorkers] = useState('');
  const [dest, setDest] = useState('');
  const [linked, setLinked] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const orchards = useMemo(() => {
    const s = new Set<string>([...Object.keys(ORCHARD_CARDS), ...orchProfiles.filter(o => !/^C proje/i.test(String(o.fields?.ownership || ''))).map(o => o.name)]);
    return [...s];
  }, [orchProfiles]);
  const card = ORCHARD_CARDS[orchard];
  const varChips = card ? card.varieties.filter(v => !/belirsiz/i.test(v.cesit)) : [];

  // Bağlı testler: bu bahçe (ve ürün) son 21 gün — eski formdaki kural
  const tests = useMemo(() => {
    const ref = Date.parse(`${date}T00:00:00`) || Date.now();
    const o = canonicalOrchard(orchard).toLocaleLowerCase('tr');
    const pr = product.split(/[ (/]/)[0].toLocaleLowerCase('tr');
    const rows: { refId: string; date: string; label: string }[] = [];
    for (const f of p.fieldRecords) rows.push({ refId: f.refId, date: (f.timestamp || '').slice(0, 10), label: `${f.testType?.split(' (')[0] || 'Saha testi'} · ${f.sortVariety || f.product}${f.avgHardness ? ` · sertlik ${f.avgHardness.toFixed(1)}` : ''}${f.avgBrix ? ` · Brix ${f.avgBrix.toFixed(1)}` : ''}${f.streifIndex ? ` · Streif ${f.streifIndex.toLocaleString('tr-TR', { maximumFractionDigits: 3 })}` : ''}`, ...{ o: f.orchard || f.location || '', p: f.product || '' } } as any);
    for (const m of p.muzRecords || []) rows.push({ refId: m.refId, date: (m.timestamp || '').slice(0, 10), label: `Muz testi · ${m.greenhouseNo || ''}`, ...{ o: m.greenhouseNo || '', p: 'Muz' } } as any);
    for (const b of p.bademRecords || []) rows.push({ refId: b.refId, date: (b.timestamp || '').slice(0, 10), label: `Badem testi · nem %${b.moisturePercent ?? '—'}`, ...{ o: b.location || '', p: 'Badem' } } as any);
    return rows.filter((t: any) => {
      const age = (ref - Date.parse(`${t.date}T00:00:00`)) / 864e5;
      if (!t.date || age < -1 || age > 21) return false;
      if (o && canonicalOrchard(t.o).toLocaleLowerCase('tr') !== o) return false;
      if (pr && !String(t.p).toLocaleLowerCase('tr').startsWith(pr)) return false;
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  }, [p.fieldRecords, p.muzRecords, p.bademRecords, orchard, product, date]);

  // Norm (kg / işçi / gün) — hasat takviminde girilmişse
  const norm = useMemo(() => {
    if (!orchard || !variety) return undefined;
    const it = buildCalendar(Number(date.slice(0, 4)) || 2027, ovs, p.harvestRecords || []).find(i => canonicalOrchard(i.orchard) === canonicalOrchard(orchard) && i.variety.toLocaleLowerCase('tr') === variety.toLocaleLowerCase('tr'));
    return it?.kgPerWorker;
  }, [orchard, variety, date, ovs, p.harvestRecords]);

  const K = n(kg), C = n(crates), W = n(workers);
  const perCrate = K && C ? K / C : undefined;
  const perWorker = K && W ? K / W : undefined;
  const refPreview = p.initialRefId || 'HARV-…';
  const canSave = !!orchard.trim() && !!product.trim() && (K ?? 0) > 0 && !p.isReadOnly;

  const addPhoto = async (files: FileList | null) => {
    if (!files?.length) return;
    for (const f of Array.from(files)) {
      try { const d = await compressImageFile(f); if (d) setPhotos(x => [...x, d]); } catch { /* yoksay */ }
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const isNew = !p.initialRefId;
    const refId = p.initialRefId || generateRefId('HARVEST', p.existingRefs.map(r => r.refId));
    const by = getCurrentUser()?.fullName || 'Saha Personeli';
    const rec: HarvestRecord = {
      id: `harv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, refId, timestamp: new Date().toISOString(), recordDate: date,
      operator: by, product: product.trim(), variety: variety.trim(), orchard: orchard.trim(), parcel: parcel.trim() || undefined, rowSection: parcel.trim() || undefined,
      harvestStage: 'Ana Hasat', lotNo: '', dailyTotalKg: K || 0, cumulativeTotalKg: K || 0, workerCount: W || 0, crateCount: C || undefined,
      foreman: by, nextStep: 'Ön soğutma', destination: dest, status: 'COMPLETED', notes: note, photos: photos.length ? photos : undefined,
      linkedTestRefId: linked[0], linkedTestRefIds: linked.length ? linked : undefined,
    };
    const refData: Partial<ReferenceItem> | undefined = isNew ? {
      refId, moduleKey: 'HARVEST', product: `${rec.product}${rec.variety ? ` (${rec.variety})` : ''}`, orchard: rec.orchard, location: dest, source: rec.orchard,
      destination: dest || undefined, finalDestination: dest || undefined, quantity: rec.dailyTotalKg, unit: 'kg', status: 'CREATED', createdAt: new Date().toISOString(), operator: by,
      notes: `Günlük hasat · ${rec.orchard}${C ? ` · ${C} kasa` : ''}${W ? ` · ${W} işçi` : ''}${linked.length ? ` (ön test: ${linked.join(', ')})` : ''}`,
    } : undefined;
    try { await p.onSave(rec, isNew, refData); } finally { setSaving(false); }
  };

  const inp = 'w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 text-sm';
  const big = 'w-full bg-transparent text-2xl font-bold tabular-nums outline-none placeholder:text-slate-300';
  const sec = 'rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-2';
  const h = (t: string, r?: React.ReactNode) => <div className="flex items-center justify-between"><h2 className="text-sm font-bold text-slate-900 dark:text-white">{t}</h2>{r}</div>;

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onCancel} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Günlük hasat</h1><p className="text-xs text-slate-500">{p.initialRefId ? `${p.initialRefId} · aynı partiye ekleniyor` : 'Tek sayfa · 4 bölüm'}</p></div>
      </div>

      <section className={sec}>
        {h('1 · Nereden', <input type="date" value={date} onChange={e => setDate(e.target.value)} className="min-h-[34px] rounded-lg border border-slate-300 px-2 text-xs" aria-label="Tarih" />)}
        <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{orchards.slice(0, 14).map(o => (
          <button key={o} type="button" onClick={() => { setOrchard(o); if (o !== orchard) { setVariety(''); setLinked([]); } }} className={`shrink-0 px-3 min-h-[34px] rounded-full border text-xs cursor-pointer ${orchard === o ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{o}</button>))}</div>
        {varChips.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{varChips.map(v => (
            <button key={v.tur + v.cesit} type="button" onClick={() => { setProduct(v.tur); setVariety(v.cesit); }} className={`shrink-0 px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${variety === v.cesit ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{v.tur} · {v.cesit}</button>))}</div>
        )}
        <div className="grid grid-cols-3 gap-2">
          <label className="text-[11px] text-slate-500">Ürün<input value={product} onChange={e => setProduct(e.target.value)} className={inp} placeholder="Elma" /></label>
          <label className="text-[11px] text-slate-500">Çeşit<input value={variety} onChange={e => setVariety(e.target.value)} className={inp} placeholder="Fuji" /></label>
          <label className="text-[11px] text-slate-500">Parsel / sıra<input value={parcel} onChange={e => setParcel(e.target.value)} className={inp} placeholder="B-4 · 12–18" /></label>
        </div>
        {!orchards.includes(orchard) && <label className="text-[11px] text-slate-500 block">Bahçe (listede yoksa)<input value={orchard} onChange={e => setOrchard(e.target.value)} className={inp} /></label>}
      </section>

      <section className={sec}>
        {h('2 · Bağlı testler', <span className="text-[11px] text-slate-500">son 3 hafta · bu bahçe</span>)}
        {tests.length === 0 ? <p className="text-[11px] text-slate-500">{orchard ? 'Bu bahçede son 3 haftada test yok.' : 'Bahçe seçince testler gelir.'}</p> : (
          <div className="space-y-1.5">{tests.map(t => { const on = linked.includes(t.refId); return (
            <button key={t.refId + t.date} type="button" onClick={() => setLinked(x => on ? x.filter(y => y !== t.refId) : [...x, t.refId])} className={`w-full text-left rounded-xl border px-3 py-2 text-xs flex items-center gap-2 cursor-pointer ${on ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/30' : 'border-slate-200 dark:border-slate-700'}`}>
              <span className="text-slate-500 tabular-nums shrink-0">{t.date.slice(8, 10)}.{t.date.slice(5, 7)}</span><span className="min-w-0 flex-1 truncate">{t.label}</span>
              <span className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 ${on ? 'bg-teal-600 border-teal-600 text-white' : 'border-slate-300'}`}>{on && <Check className="w-3.5 h-3.5" />}</span>
            </button>); })}</div>
        )}
      </section>

      <section className={sec}>
        {h('3 · Ne kadar')}
        <div className="grid grid-cols-3 gap-2">
          {([['Kasa', crates, setCrates, ''], ['Net kg', kg, setKg, 'kantar'], ['İşçi', workers, setWorkers, '']] as const).map(([l, v, set, sub]) => (
            <label key={l} className={`rounded-xl border px-3 py-2 ${v ? 'border-teal-300' : 'border-slate-200 dark:border-slate-700'}`}>
              <div className="text-[10px] font-semibold text-slate-500">{l}</div>
              <input inputMode="decimal" value={v} onChange={e => set(e.target.value.replace(/[^\d.,]/g, ''))} placeholder="0" className={big} />
              {sub && <div className="text-[10px] text-slate-400">{sub}</div>}
            </label>))}
        </div>
        {(perCrate || perWorker) && (
          <div className="flex items-center justify-between rounded-lg bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs">
            <span><span className="text-slate-500">Kasa başı / kişi başı</span><br /><b className="tabular-nums">{perCrate ? `${kgf(perCrate)} kg` : '—'} · {perWorker ? `${kgf(perWorker)} kg` : '—'}</b></span>
            {norm ? <span className={`text-[10px] px-2 py-0.5 rounded-full border ${perWorker && perWorker < norm * 0.8 ? 'border-amber-300 bg-amber-50 text-amber-800' : 'border-emerald-200 bg-emerald-50 text-emerald-800'}`}>norm {kgf(norm)}</span> : null}
          </div>
        )}
        {whProfiles.length > 0 && (
          <div>
            <div className="text-[11px] text-slate-500 mb-1">Nereye gidiyor</div>
            <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{whProfiles.map(w => (
              <button key={w.id} type="button" onClick={() => setDest(dest === w.name ? '' : w.name)} className={`shrink-0 px-3 min-h-[32px] rounded-full border text-xs cursor-pointer ${dest === w.name ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{String(w.fields?.shortName || w.name)}</button>))}</div>
          </div>
        )}
      </section>

      <section className={sec}>
        {h('4 · Fotoğraf ve not', <button type="button" onClick={() => fileRef.current?.click()} aria-label="Fotoğraf ekle" className="w-9 h-9 rounded-lg border border-slate-300 flex items-center justify-center cursor-pointer"><Camera className="w-4 h-4" /></button>)}
        <input ref={fileRef} type="file" accept="image/*" capture="environment" multiple className="hidden" onChange={e => addPhoto(e.target.files)} />
        {photos.length > 0 && <div className="flex gap-1.5 flex-wrap">{photos.map((ph, i) => (
          <div key={i} className="relative"><img src={ph} alt="" className="w-16 h-16 rounded-lg object-cover" /><button type="button" onClick={() => setPhotos(x => x.filter((_, j) => j !== i))} aria-label="Sil" className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center"><X className="w-3 h-3" /></button></div>))}</div>}
        <textarea rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="Not (hava, kalite, sorun…)" className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-sm" />
        <button type="button" onClick={p.onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 cursor-pointer">Lot / fiş no, hasat aşaması, parçalı yük → ayrıntılı form</button>
      </section>

      <div className="fixed left-0 right-0 bottom-[68px] sm:bottom-4 z-30 px-3">
        <div className="max-w-xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-lg px-4 py-2.5 flex items-center gap-3">
          <div className="min-w-0 flex-1"><div className="text-[10px] text-slate-500">Sonuç</div>
            <div className={`text-sm font-bold truncate ${canSave ? 'text-emerald-700' : 'text-slate-500'}`}>{!orchard ? 'Bahçe seçin' : !product ? 'Ürün girin' : !K ? 'Net kg girin' : `RefID ${refPreview} ${p.initialRefId ? 'güncellenecek' : 'açılacak'} · ${kgf(K)} kg`}</div></div>
          <button type="button" disabled={!canSave || saving} onClick={save} className="min-h-[44px] px-6 rounded-xl bg-teal-700 text-white font-semibold disabled:opacity-40 cursor-pointer">{saving ? '…' : 'Kaydet'}</button>
        </div>
      </div>
    </div>
  );
}
