# V53 — Günlük hasat tek sayfa (görsel 31) + Depo kabul (görsel 33)

- `src/App.tsx` — `bdc24e9abef7aa625b45dbadd33211c3b0398774652af782b9d1f06272f78a30`
- `src/types.ts` — `e5b4e6e30eb305b21036ed2ac5c95b68fcdf899469bb2c7773ae5f1ce0f5966e`
- `src/components/forms/QuickHarvestForm.tsx` — `943aad73bd5eff07c6ba4d29656b8ae92e9b251953708a4a4605d8c8e8d70444`
- `src/components/forms/QuickIntakeForm.tsx` — `f09d9eded7d0845276119464d3551ad072ad598121e2cbf45aff8eec5cf8c063`

Yeni: QuickHarvestForm.tsx, QuickIntakeForm.tsx. types.ts: HarvestRecord.crateCount (isteğe bağlı) eklendi. DailyHarvestForm / AmbarForm silinmez (düzenleme + ayrıntılı form). Firestore kuralı değişmedi. TAM_LISTE: 207.
