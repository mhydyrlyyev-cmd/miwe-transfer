# v49c13 — Seyreltme penceresi · akt içeriği · bahçe bilgisi (yükseklik) · kısa listeler · iklim sade

1. Seyreltme (orchardTasks.ts, harvestCalendar.ts, OrchardCardsView): tek tarih yerine PENCERE — meyve ceviz büyüklüğünde.
   2027 meyve tutumu (BBCH 71) girildiyse "BBCH 71 + (2026 seyreltme − 2026 BBCH 71)" gün; girilmediyse 2026 tarihleri (çiçek farkıyla).
   Giriş: Başladı / Bitti. Yapılacaklar: 10 gün önce listede, 5 gün kala ve pencerede sarı, pencere geçip bitmediyse kırmızı.
2. Aktlar (aktStatus.ts, AktRows.tsx): akta dokun → içeriği (platform: tür, parti, miktar, açıklama, kök neden, düzeltici faaliyet, sorumlu, not, fotoğraf sayısı; arşiv: akt adı, yer, konu).
   Platform aktı da "Açık / Giderildi" işaretlenebilir. Giderildi tarihi ve kişi görünür.
3. Yönetim analizi (analytics.ts, ManagementViews): Bahçe ve depo puanında akt = 2026 arşivi + platform (seçili dönem), "x açık" altında.
   Alttaki kutu yalnız oda ve test uyarıları (aktlar konu kutusunda; tekrar yok).
4. Bahçe profili: üstte "Bahçe bilgisi" — konum (haritada aç), denizden yükseklik (Open-Meteo), en alçak bahçeye göre kaba gecikme (Hopkins ~4 gün/122 m),
   sorumlu, 2027 çiçeklenme girişi. Profil farkı yönetici için tek satır (açılır). Alttaki uzun "Profil bilgisi" ve kaynak yazısı kaldırıldı (Kaynaklar ▾).
5. Kısa listeler: 2026 arşivi aşama adı tam yazılır, sayılar altında; "Günlük değişim" (sertlik/brix ya da kabuk/nem, gün başına). Dikimler: anaç/firma yoksa o sütun gizli. BBCH adları kesilmez.
6. Bahçe iklimi (agroClimate.ts, ClimateView): mevsime göre tek gösterge (Kasım–Şubat soğuklama, Mart–Ekim gün-derece → hasat); don kutusu yalnız çiçeklenmede; 7 gün tahmini yalnız soğuk varsa; yükseklik ve "+N gün".

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (9 dosya)
271d8f86211063db27f23fe3ad4899b296496474d513c64181c2fb8793e89476  src/services/harvestCalendar.ts
e897a4acaa49172f556867254c61cd03423ab10ca8f93f82ef39779da2e0ab55  src/services/orchardTasks.ts
2e8c5b5034146c5c5aa823be874bd9e8a063ecff21f024e83856f29b67c244ab  src/services/aktStatus.ts
abde58df6fa7e39692f8da21ba772e71b367858700e964a50a854bb84ffd189e  src/services/analytics.ts
7c08b02cc836e1a880975bf6963897597eb35ce17193026ef5c1ce7becf1b659  src/services/agroClimate.ts
682617519c01ec1263c305ddce4e361c0280fd01d483619806c973734b7c76d3  src/components/views/AktRows.tsx
21efb79fa25523075e28c92e7cc09b433b2d09d082863b48cea5701b37da09bc  src/components/views/ManagementViews.tsx
fee47bb0ac199af85046e04b94dd5fb75a0f8b5ceb22f1ea71ab881524a93c04  src/components/views/ClimateView.tsx
5bc7eb503202d783d06167acffba9cc19fe299dfc06ef002595e0c8e7348d83e  src/components/views/OrchardCardsView.tsx
