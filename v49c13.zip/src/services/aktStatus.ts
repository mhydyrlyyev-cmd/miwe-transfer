/**
 * v49c12 — Akt durumu: 2026 arşiv aktları için "Giderildi / Açık" işareti + platformda açılan yeni aktlar tek listede.
 *  · Arşiv aktının durumu ayrı kayıt olarak saklanır (ganttParcels koleksiyonu, calV: 'AKT'; kural değişmez). Arşiv dosyası değişmez.
 *  · Platformdaki akt (Incident) kendi durum alanını kullanır (Çözüldü / Kapandı = giderildi).
 */
import { useEffect, useMemo, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import type { IncidentRecord } from '../types';
import { ARCHIVE_AKTS_2026, type ArchiveAkt } from '../config/archive2026';
import { canonicalOrchard } from './locationProfiles';

export interface AktStatus { id: string; calV: 'AKT'; no: string; done: boolean; at: string; by?: string; note?: string }
const LS = 'miwe_akt_status_v1';
let store: AktStatus[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: AktStatus[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'AKT') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || r.at > l.at) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useAktStatuses(): AktStatus[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store;
}
export async function setAktStatus(no: string, done: boolean, by?: string): Promise<boolean> {
  const id = `akt26-${String(no).replace(/[^\w-]/g, '_')}`;
  const next: AktStatus = { id, calV: 'AKT', no, done, at: new Date().toISOString(), by };
  store = [...store.filter(s => s.id !== id), next]; emit();
  try { return await saveRecordToFirestore('GANTT', next); } catch { return false; }
}

/** Tek liste: arşiv + platform aktları. done: giderildi mi. detail: akt içeriği (dokununca açılır) */
export interface AktRow extends ArchiveAkt { source: 'arşiv' | 'platform'; done: boolean; doneAt?: string; doneBy?: string; detail?: [string, string][]; refId?: string }
const DONE_RE = /çözül|cozul|kapan|resolved|closed|tamam|giderildi/i;
/** v49c13: platform aktı da "Giderildi / Açık" işaretlenebilir — işaret varsa o geçerli, yoksa aktın kendi durumu */
export function useAllAkts(incidents: IncidentRecord[] = []): AktRow[] {
  const st = useAktStatuses();
  return useMemo(() => {
    const m = new Map(st.map(s => [s.no, s]));
    const mark = (no: string, fallback: boolean) => { const x = m.get(no); return x ? { done: x.done, doneAt: x.done ? x.at : undefined, doneBy: x.by } : { done: fallback }; };
    const arch: AktRow[] = ARCHIVE_AKTS_2026.map(a => ({ ...a, source: 'arşiv', ...mark(a.no, false),
      detail: ([['Akt', a.name], ['Yer (kayıtta)', a.placeRaw], ['Ürün', a.product], ['Konu', a.summary]] as [string, string][]).filter(([, v]) => v) }));
    const plat: AktRow[] = incidents.filter(i => !/dfsd|deneme|test/i.test(`${i.description} ${i.notes}`)).map(i => {
      const no = i.incidentId || i.id;
      const kg = Number(i.affectedQuantityKg) || 0;
      const detail = ([
        ['Akt no', [i.actNumber, i.incidentId].filter(Boolean).join(' · ')], ['Tür', i.incidentType], ['Derece', i.actDegree ? String(i.actDegree) : ''], ['Öncelik', String(i.priority || '')],
        ['Parti', [i.refId, i.lotNo].filter(Boolean).join(' · ')], ['Aşama', i.detectionStage || ''], ['Miktar', kg ? `${kg.toLocaleString('tr-TR')} kg${i.affectedCasesCount ? ` · ${i.affectedCasesCount} kasa` : ''}` : ''],
        ['Açıklama', i.description], ['Kök neden', [i.rootCauseCategory, i.rootCause].filter(Boolean).join(' — ')], ['İlk müdahale', i.immediateAction || ''],
        ['Düzeltici faaliyet', i.correctiveAction], ['Sorumlu', i.responsible || i.assignedTo || ''], ['Hedef tarih', i.targetResolutionDate || ''],
        ['Durum (kayıtta)', String(i.status || '')], ['Not', i.notes], ['Fotoğraf', (i.photos?.length || i.photoIds?.length) ? `${i.photos?.length || i.photoIds?.length} adet — partide görülür` : ''], ['Yazan', i.operator],
      ] as [string, string][]).filter(([, v]) => v && String(v).trim());
      return {
        no, d: String(i.incidentDate || i.timestamp || '').slice(0, 10) || null,
        place: canonicalOrchard(i.location || (i as any).orchard || '') || i.location || '—', placeRaw: i.location || '',
        summary: [i.incidentType, i.description].filter(Boolean).join(' — '), product: (i as any).product || '', name: i.actNumber || i.incidentId || '',
        source: 'platform' as const, refId: i.refId || undefined, ...mark(no, DONE_RE.test(String(i.status || ''))), detail,
      };
    });
    return [...plat, ...arch].sort((a, b) => String(b.d).localeCompare(String(a.d)));
  }, [st, incidents]);
}
