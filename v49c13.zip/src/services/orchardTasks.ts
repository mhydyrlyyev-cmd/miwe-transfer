/**
 * v49c10 — Bahçe yapılacakları (Ana sayfa · Bugün yapılacaklar › Bahçe).
 * Kurallar (kullanıcı, 26.11.2026):
 *  1. BBCH rasadı: 2026 tarihi bu sezona taşınır (2027 çiçeklenmesi girildiyse o kadar kaydırılır). 10 gün önce listeye girer, 5 gün kala sarıya döner;
 *     gözlenen tarih girilince kalkar.
 *  2. Hasat öncesi test: pencere (çiçeklenme girildiyse "BBCH 65 + gün", girilmediyse geçmiş yıl ortalaması) başlangıcından 14 gün önce başlar;
 *     son test 4 günden eskiyse tekrar gelir; hasat başlayınca kalkar.
 *  3. Hasat başlangıcı Gantt / Hasat takviminde izlenir (burada ayrıca uyarı yok).
 *  5. Çiçek donu: çiçeklenme (girilen ya da geçen yılın tarihi) −10 / +25 gün içinde 7 gün tahmininde Tmin ≤ 0 °C.
 *  6. C proje yalnız bilgi — hatırlatma yok.
 *  + Seyreltme: 2026 seyreltme tarihleri (çiçeklenme farkı kadar kaydırılır); 10 gün önce girer, "yapıldı" girilince kalkar.
 *  + Meyve sayımı ve tonaj rasadı: meyve tutumundan (BBCH 71) 7 gün sonra – 30 gün içinde; sayım girilince kalkar.
 */
import { useEffect, useMemo, useState } from 'react';
import type { FieldRecord, HarvestRecord } from '../types';
import { buildCalendar, useCalOverrides, expectedBbch, parseD, BBCH_LABEL, type BbchStage, type CalItem } from './harvestCalendar';
import { canonicalOrchard, findProfile, useLocationProfiles } from './locationProfiles';
import { fetchClimate } from './agroClimate';
import { vkey, matchCardVariety } from './orchardOverview';
import { firstTest2026 } from './archive2026';
import { ORCHARD_CARDS } from '../config/orchardCards';

const DAY = 86400000;
const dm = (t: number) => new Date(t).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' });
export type OrchardTaskKind = 'bbch' | 'test' | 'thin' | 'count' | 'frost';
export interface OrchardTask {
  id: string; kind: OrchardTaskKind; level: 'bad' | 'warn' | 'info';
  orchard: string; variety: string; title: string; detail: string; due: number;
}

/** 2027 çiçeklenme girildiyse 2026'ya göre kaç gün kaydığı (yoksa 0) */
function bloomShift(it: CalItem): number {
  const b27 = parseD(it.ov?.bbch?.['65']);
  const b26 = expectedBbch(it, '65');
  return Number.isFinite(b27) && b26 ? Math.round((b27 - b26) / DAY) : 0;
}
/** 2026 tarihini (YYYY-AA-GG) bu sezona taşır + çiçeklenme kayması */
function shifted(it: CalItem, iso?: string | null): number | undefined {
  const t = parseD(iso);
  if (!Number.isFinite(t)) return undefined;
  const d = new Date(t); d.setFullYear(it.season);
  return d.getTime() + bloomShift(it) * DAY;
}

/** v49c13 — seyreltme penceresi: meyve ceviz büyüklüğüne geldiğinde. 2027 meyve tutumu (BBCH 71) girildiyse
 *  "BBCH 71 + (2026 seyreltme − 2026 BBCH 71)" gün; girilmediyse 2026 tarihleri (çiçek farkı kadar kaydırılır). */
export function thinWindow(it: CalItem): { from: number; to: number; basis: string } | undefined {
  const s0 = parseD(it.seed.thinStart);
  if (!Number.isFinite(s0)) return undefined;
  const e0 = Number.isFinite(parseD(it.seed.thinEnd)) ? parseD(it.seed.thinEnd) : s0;
  const b26 = parseD(it.seed.bbch71), b27 = parseD(it.ov?.bbch?.['71']);
  if (Number.isFinite(b26) && Number.isFinite(b27)) {
    const off = s0 - b26;
    return { from: b27 + off, to: b27 + off + (e0 - s0), basis: `meyve tutumu ${dm(b27)} + ${Math.round(off / DAY)} gün (2026 aralığı)` };
  }
  const from = shifted(it, it.seed.thinStart)!, to = shifted(it, it.seed.thinEnd) ?? from;
  return { from, to, basis: bloomShift(it) ? '2026 tarihleri, çiçeklenme farkıyla' : '2026 tarihleri · BBCH 71 girilince kesinleşir' };
}

export function computeOrchardTasks(items: CalItem[], fieldRecords: FieldRecord[], now = Date.now()): OrchardTask[] {
  const out: OrchardTask[] = [];
  const today = new Date(now); today.setHours(0, 0, 0, 0);
  const T = today.getTime();
  const seen = new Set<string>();
  for (const it of items) {
    if (!it.orchard || /ýyladyş|yyladys/i.test(it.orchard)) continue;
    if (/näbelli|nabelli|belirsiz|bakıla|bakila/i.test(it.variety)) continue;
    const mk = matchCardVariety(it.orchard, it.variety);
    const card = mk ? ORCHARD_CARDS[it.orchard]?.varieties.find(x => vkey(x.cesit) === mk) : undefined;
    const v = card?.cesit || it.variety.split('(')[0].trim();
    const key = `${it.orchard}|${mk || vkey(v)}`;
    if (seen.has(key)) continue; seen.add(key);
    const base = { orchard: it.orchard, variety: v };
    // 1) BBCH rasadı
    for (const st of ['65', '71', '81', '85'] as BbchStage[]) {
      if (it.ov?.bbch?.[st]) continue;
      const exp = st === '65' ? expectedBbch(it, st) : shifted(it, (it.seed as any)[`bbch${st}`]);
      if (!exp) continue;
      const days = Math.round((exp - T) / DAY);
      if (days > 10 || days < -10) continue;
      out.push({ ...base, id: `bahce-bbch-${st}-${key}`, kind: 'bbch', due: exp, level: days <= 5 ? 'warn' : 'info',
        title: `${it.orchard} · ${v} · BBCH ${st} rasadı`, detail: `${BBCH_LABEL[st]} beklenen ${dm(exp)} (${days > 0 ? `${days} gün kaldı` : days === 0 ? 'bugün' : `${-days} gün geçti`}) — gözlenen tarihi gir` });
    }
    // 2) Hasat öncesi test
    if (it.windowStart && !it.start && it.status !== 'DONE') {
      // çiçeklenme girilmediyse: geçen yılın ilk testi (bu yıla taşınmış) ya da pencere − 14 gün — hangisi önceyse
      const ft = !it.ov?.bbch?.['65'] ? firstTest2026(it.orchard, mk || vkey(v)) : undefined;
      const ftT = ft ? shifted(it, ft) : undefined;
      const from = Math.min(it.windowStart - 14 * DAY, ftT && ftT < it.windowStart ? ftT : Infinity);
      if (T >= from && T <= (it.windowEnd || it.windowStart) + 3 * DAY) {
        const tests = fieldRecords.filter(r => canonicalOrchard(r.orchard) === it.orchard && vkey(r.sortVariety) === vkey(v) && Date.parse(r.timestamp) >= from - 7 * DAY);
        const last = tests.reduce((m, r) => Math.max(m, Date.parse(r.timestamp)), 0);
        const age = last ? Math.floor((now - last) / DAY) : undefined;
        if (age === undefined || age >= 4) {
          const toWin = Math.round((it.windowStart - T) / DAY);
          out.push({ ...base, id: `bahce-test-${key}`, kind: 'test', due: it.windowStart, level: toWin <= 7 ? 'warn' : 'info',
            title: `${it.orchard} · ${v} · hasat öncesi test`, detail: `Pencere ${dm(it.windowStart)}${toWin > 0 ? ` (${toWin} gün)` : ' açıldı'} · ${age === undefined ? 'bu sezon test yok' : `son test ${age} gün önce`}` });
        }
      }
    }
    // + Seyreltme (v49c13: pencere — meyve ceviz büyüklüğünde; kaçırılmamalı)
    const tw = thinWindow(it);
    if (tw && !it.ov?.thinDoneAt) {
      const days = Math.round((tw.from - T) / DAY);
      if (days <= 10 && T <= tw.to + 5 * DAY) {
        const inWin = T >= tw.from, past = T > tw.to;
        out.push({ ...base, id: `bahce-thin-${key}`, kind: 'thin', due: tw.from, level: past ? 'bad' : inWin || days <= 5 ? 'warn' : 'info',
          title: `${it.orchard} · ${v} · seyreltme`,
          detail: `Pencere ${dm(tw.from)}–${dm(tw.to)} (meyve ceviz büyüklüğü) · ${past ? `pencere ${Math.round((T - tw.to) / DAY)} gün geçti` : inWin ? (it.ov?.thinStartAt ? `başladı ${dm(parseD(it.ov.thinStartAt))}` : 'pencere açık') : `${days} gün kaldı`} — bitince "Bitti" gir` });
      }
    }
    // + Meyve sayımı ve tonaj rasadı
    const b71 = parseD(it.ov?.bbch?.['71']) || shifted(it, it.seed.bbch71);
    if (b71 && Number.isFinite(b71) && !it.ov?.fruitCount) {
      const from = b71 + 7 * DAY, to = b71 + 30 * DAY;
      if (T >= from - 5 * DAY && T <= to) out.push({ ...base, id: `bahce-count-${key}`, kind: 'count', due: from, level: T >= from ? 'warn' : 'info',
        title: `${it.orchard} · ${v} · meyve sayımı`, detail: `Meyve tutumu ${dm(b71)} · sayım ${dm(from)}–${dm(to)} → tonaj rasadı` });
    }
  }
  return out.sort((a, b) => a.due - b.due);
}

const KIND_LABEL: Record<OrchardTaskKind, string> = { bbch: 'BBCH rasadı', test: 'hasat öncesi test', thin: 'seyreltme', count: 'meyve sayımı', frost: 'çiçek donu' };
/** Aynı bahçe + aynı iş türü tek satırda toplanır: "Bagyr · meyve sayımı · 8 çeşit" (en acil çeşit önce) */
export function groupTasks(list: OrchardTask[]): OrchardTask[] {
  const by = new Map<string, OrchardTask[]>();
  for (const t of list) { const k = `${t.orchard}|${t.kind}`; by.set(k, [...(by.get(k) || []), t]); }
  const rank = { bad: 0, warn: 1, info: 2 } as const;
  return [...by.values()].map(g => {
    if (g.length === 1) return g[0];
    g.sort((a, b) => rank[a.level] - rank[b.level] || a.due - b.due);
    const f = g[0];
    return { ...f, id: `bahce-${f.kind}-grp-${f.orchard}`, title: `${f.orchard} · ${KIND_LABEL[f.kind]} · ${g.length} çeşit`,
      detail: `${g.slice(0, 3).map(x => `${x.variety} ${dm(x.due)}`).join(' · ')}${g.length > 3 ? ` · +${g.length - 3}` : ''}` };
  }).sort((a, b) => rank[a.level] - rank[b.level] || a.due - b.due);
}

/** Çiçeklenme penceresindeki bahçeler için yalnız 7 günlük tahmin çekilir (az istek) */
function useBloomFrost(items: CalItem[]): OrchardTask[] {
  useLocationProfiles('ORCHARD');
  const [tasks, setTasks] = useState<OrchardTask[]>([]);
  const targets = useMemo(() => {
    const T = Date.now();
    const by = new Map<string, number>();
    for (const it of items) {
      const b = parseD(it.ov?.bbch?.['65']) || expectedBbch(it, '65');
      if (!b || !Number.isFinite(b)) continue;
      if (T >= b - 17 * DAY && T <= b + 25 * DAY) { const cur = by.get(it.orchard); if (!cur || b < cur) by.set(it.orchard, b); }
    }
    return [...by.entries()];
  }, [items]);
  const sig = targets.map(([o, b]) => `${o}:${b}`).join('|');
  useEffect(() => {
    let alive = true;
    (async () => {
      const out: OrchardTask[] = [];
      const today = new Date().toISOString().slice(0, 10);
      for (const [orchard, bloom] of targets) {
        const pr = findProfile('ORCHARD', orchard);
        const lat = Number(pr?.fields?.lat), lon = Number(pr?.fields?.lon);
        if (!lat || !lon) continue;
        try {
          const days = (await fetchClimate(lat, lon, today, true)).filter(d => d.date >= today);
          const min = days.reduce((m, d) => (d.tMin < m.tMin ? d : m), days[0]);
          if (min && min.tMin <= 0) out.push({ id: `bahce-frost-${orchard}`, kind: 'frost', orchard, variety: '', due: Date.parse(`${min.date}T00:00:00`), level: min.tMin <= -2 ? 'bad' : 'warn',
            title: `${orchard} · çiçek donu riski`, detail: `${min.date.slice(8)}.${min.date.slice(5, 7)} en düşük ${min.tMin.toFixed(1)} °C · çiçeklenme ≈ ${dm(bloom)}` });
        } catch { /* bağlantı yoksa sessiz */ }
      }
      if (alive) setTasks(out);
    })();
    return () => { alive = false; };
  }, [sig]);
  return tasks;
}

/** Bu sezonun takvimi: Kasım'dan sonra (hasat bittiyse) bir sonraki yıl */
export function useOrchardTasks(harvestRecords: HarvestRecord[], fieldRecords: FieldRecord[]): OrchardTask[] {
  const ovs = useCalOverrides();
  const items = useMemo(() => {
    const y = new Date().getFullYear();
    const recent = harvestRecords.some(h => { const t = Date.parse(String(h.recordDate || h.timestamp || '')); return Number.isFinite(t) && Date.now() - t < 10 * DAY; });
    const nd = new Date(); const lateNov = nd.getMonth() === 11 || (nd.getMonth() === 10 && nd.getDate() >= 15);
    const season = lateNov || (nd.getMonth() >= 10 && !recent) ? y + 1 : y;
    return buildCalendar(season, ovs, harvestRecords);
  }, [ovs, harvestRecords]);
  const base = useMemo(() => groupTasks(computeOrchardTasks(items, fieldRecords)), [items, fieldRecords]);
  const frost = useBloomFrost(items);
  return useMemo(() => [...frost, ...base], [frost, base]);
}
