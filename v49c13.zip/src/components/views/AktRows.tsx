import React, { useState } from 'react';
import { Check, CircleDot, ChevronDown } from 'lucide-react';
import { setAktStatus, type AktRow } from '../../services/aktStatus';

/** v49c13 — akt satırı: tarih · yer · konu · durum. Satıra dokun → aktın içeriği. Arşiv ve platform aktı "Giderildi / Açık" işaretlenebilir. */
export default function AktRows({ list, by, readOnly, showPlace = true }: { list: AktRow[]; by: string; readOnly?: boolean; showPlace?: boolean }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  return (
    <ul className="space-y-1">{list.map(a => {
      const k = a.source + a.no;
      const isOpen = open === k;
      return (
        <li key={k} className="text-[11px] text-slate-700 dark:text-slate-300">
          <div className="flex items-start gap-2">
            <span className="tabular-nums text-slate-500 shrink-0 w-10 pt-0.5">{a.d ? `${a.d.slice(8, 10)}.${a.d.slice(5, 7)}` : '—'}</span>
            <button type="button" onClick={() => setOpen(isOpen ? null : k)} className="min-w-0 flex-1 pt-0.5 text-left cursor-pointer">
              {showPlace && <b>{a.place}</b>}{a.product ? `${showPlace ? ' · ' : ''}${a.product}` : ''}{showPlace || a.product ? ' — ' : ''}
              <span className={isOpen ? '' : 'line-clamp-2'}>{a.summary || a.name}</span>
              {a.source === 'platform' ? <span className="ml-1 text-[10px] text-sky-700">(platform)</span> : null}
              <ChevronDown className={`w-3 h-3 inline ml-0.5 text-slate-400 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {!readOnly ? (
              <button type="button" disabled={busy === a.no} onClick={async () => { setBusy(a.no); await setAktStatus(a.no, !a.done, by); setBusy(null); }}
                className={`shrink-0 inline-flex items-center gap-1 px-2 min-h-[28px] rounded-full border text-[10px] font-semibold cursor-pointer ${a.done ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-white text-amber-800 border-amber-300 dark:bg-slate-900'}`}>
                {a.done ? <><Check className="w-3 h-3" />Giderildi</> : <><CircleDot className="w-3 h-3" />Açık</>}
              </button>
            ) : (
              <span className={`shrink-0 px-2 py-0.5 rounded-full border text-[10px] font-semibold ${a.done ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'}`}>{a.done ? 'Giderildi' : 'Açık'}</span>
            )}
          </div>
          {isOpen && (
            <dl className="ml-12 mt-1 mb-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 space-y-0.5">
              {(a.detail || []).map(([l, v]) => (
                <div key={l} className="grid grid-cols-[96px_minmax(0,1fr)] gap-2"><dt className="text-slate-500">{l}</dt><dd className="whitespace-pre-line break-words">{v}</dd></div>))}
              {a.done && a.doneAt && <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-2"><dt className="text-slate-500">Giderildi</dt><dd>{new Date(a.doneAt).toLocaleDateString('tr-TR')}{a.doneBy ? ` · ${a.doneBy}` : ''}</dd></div>}
            </dl>
          )}
        </li>);
    })}</ul>
  );
}
