/**
 * v50 — Muz günlüğü (seralar).
 *  · RefID = gün + sera + sektör + kurdele rengi  (ör. MUZ-261127-GB56-S2-MAVI). Aynı gün aynı sektör aynı renk = aynı parti.
 *  · Gün içinde salkım sayımı (birden çok giriş toplanır), akşam kg, paketleme sınıf dağılımı (kg).
 *  · Karar: ıskarta oranı ya da Classic+Mix oranı sınırı aşarsa "Gaýtadan işlenen", değilse "Kadaly". Sınırlar ayarlanabilir.
 *  · v50b Kurdele: renk dönemi (varsayılan 10 gün) — dönem içinde bağlanan her salkım o dönemin rengini alır; renkler aynı sırayla tekrar eder.
 *    Beklenen hasat = bağlama günü + standart süre (varsayılan 98 gün) − geç bağlanan gün. Kayıp (hastalık, kırılma, kuruma…): renkliyse renkten düşülür,
 *    renksizse sektör · sıra ile ayrı tutulur. Net salkım × ortalama salkım kg → beklenen tonaj ve günlük hasat gücü.
 * Kayıt: Firestore 'ganttParcels' (calV: 'MUZ'; kural değişmez) + yerel önbellek.
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';

export const MUZ_GRADES = ['Extra', 'Exclusive', 'Premium', 'Classic', 'Mix', 'Iskarta'] as const;
export type MuzGrade = typeof MUZ_GRADES[number];
export const GRADE_LABEL: Record<MuzGrade, string> = { Extra: 'Extra', Exclusive: 'Exclusive', Premium: 'Premium', Classic: 'Classic', Mix: 'Mix', Iskarta: 'Iskarta (standart dışı)' };

export interface MuzCount { at: string; n: number; by?: string }
export interface MuzDay {
  id: string; calV: 'MUZ'; kind: 'day';
  date: string; sera: string; sector: string; color: string; refId: string;
  counts: MuzCount[]; kg?: number; kgAt?: string;
  grades?: Partial<Record<MuzGrade, number>>; gradesAt?: string;
  note?: string; at: string; by?: string;
}
/** Kurdele bağlama kaydı (gezinti / bağlama turu) */
export interface MuzBag { id: string; calV: 'MUZ'; kind: 'bag'; sera: string; date: string; k: number; color: string; sector?: string; row?: string; bunches: number; lateDays?: number; at: string; by?: string }
/** Kayıp: hastalık, kırılma, kuruma … renkliyse color dolu; renksizse sektör · sıra */
export interface MuzLoss { id: string; calV: 'MUZ'; kind: 'loss'; sera: string; date: string; color?: string; k?: number; sector?: string; row?: string; plants: number; reason: string; note?: string; at: string; by?: string }
export const LOSS_REASONS = ['Hastalık', 'Kırılma', 'Kuruma', 'Devrilme', 'Diğer'] as const;
export interface RibbonColor { name: string; hex: string }
export interface MuzCfg {
  id: 'muz-cfg'; calV: 'MUZ'; kind: 'cfg';
  colors: RibbonColor[];
  /** çapa: bu tarihte başlayan dönemin rengi colors[idx] */
  anchor: { date: string; idx: number };
  periodDays: number; harvestDays: number; bunchKg: number;
  maxIskartaPct: number; maxLowPct: number;
  at: string; by?: string;
}
/** v50c: sera içi iklim — otomasyon ekranından ya da dışa aktarımdan günlük giriş */
export interface MuzClim { id: string; calV: 'MUZ'; kind: 'clim'; sera: string; date: string; tMin?: number; tMax?: number; tAvg?: number; rh?: number; source?: string; at: string; by?: string }
/** Muz için iç sıcaklık sınırları (°C): altında soğuk zararı / büyüme durur, üstünde sıcak stresi */
export const CLIM_LIMITS = { cold: 13, coldWarn: 15, hot: 36 };
export type MuzDoc = MuzDay | MuzBag | MuzLoss | MuzCfg | MuzClim;

export const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

/* ───────── ayar ───────── */
export const DEFAULT_CFG: MuzCfg = {
  id: 'muz-cfg', calV: 'MUZ', kind: 'cfg',
  colors: [
    { name: 'Mavi', hex: '#378ADD' }, { name: 'Kırmızı', hex: '#E24B4A' }, { name: 'Yeşil', hex: '#639922' }, { name: 'Sarı', hex: '#EF9F27' },
    { name: 'Beyaz', hex: '#D3D1C7' }, { name: 'Turuncu', hex: '#D85A30' }, { name: 'Mor', hex: '#7F77DD' }, { name: 'Kahverengi', hex: '#854F0B' },
    { name: 'Siyah', hex: '#2C2C2A' }, { name: 'Pembe', hex: '#D4537E' }, { name: 'Gri', hex: '#888780' }, { name: 'Lacivert', hex: '#0C447C' },
  ],
  anchor: { date: '2026-11-21', idx: 0 }, periodDays: 10, harvestDays: 98, bunchKg: 25, maxIskartaPct: 10, maxLowPct: 40, at: '',
};
const DAYMS = 86400000;
const dms = (iso: string) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10));
export const isoOf = (ms: number) => new Date(ms).toISOString().slice(0, 10);
export const addDays = (iso: string, n: number) => isoOf(dms(iso) + n * DAYMS);
export const daysBetween = (a: string, b: string) => Math.round((dms(b) - dms(a)) / DAYMS);
/** tarih → renk dönemi no (çapa dönemi 0) */
export const periodOf = (cfg: MuzCfg, iso: string) => Math.floor(daysBetween(cfg.anchor.date, iso) / (cfg.periodDays || 10));
export const periodStart = (cfg: MuzCfg, k: number) => addDays(cfg.anchor.date, k * (cfg.periodDays || 10));
export function colorOfPeriod(cfg: MuzCfg, k: number): RibbonColor {
  const n = cfg.colors.length || 1;
  return cfg.colors[(((cfg.anchor.idx + k) % n) + n) % n] || { name: '?', hex: '#888780' };
}
export const colorOfDate = (cfg: MuzCfg, iso: string) => colorOfPeriod(cfg, periodOf(cfg, iso));
export const colorHex = (cfg: MuzCfg, name: string) => cfg.colors.find(c => c.name === name)?.hex || '#888780';
/** Aynı renk kaç günde bir döner; hasat süresi + bir dönem yayılmadan kısaysa sahada aynı renkten iki kuşak olur */
export function cycleCheck(cfg: MuzCfg) {
  const cycle = cfg.colors.length * cfg.periodDays, need = cfg.harvestDays + cfg.periodDays;
  return { cycle, need, ok: cycle >= need, minColors: Math.ceil(need / (cfg.periodDays || 10)) };
}
/** Bir bağlama kaydının beklenen hasat günü */
export const bagHarvest = (cfg: MuzCfg, b: MuzBag) => addDays(b.date, cfg.harvestDays - (b.lateDays || 0));
/** Renk dönemi özeti: bağlanan, kayıp, net, beklenen hasat aralığı ve ortalaması, hasat edilen */
export interface PeriodRow { k: number; color: RibbonColor; from: string; to: string; bagged: number; lost: number; net: number; hFrom?: string; hTo?: string; hAvg?: string; harvested: number }
export function periodRows(cfg: MuzCfg, bags: MuzBag[], losses: MuzLoss[], days: MuzDay[]): PeriodRow[] {
  const ks = new Set<number>([...bags.map(b => b.k), ...losses.filter(l => l.k !== undefined).map(l => l.k!)]);
  const rows = new Map<number, PeriodRow>();
  for (const k of ks) {
    const bs = bags.filter(b => b.k === k);
    const bagged = bs.reduce((s, b) => s + b.bunches, 0);
    const lost = losses.filter(l => l.k === k).reduce((s, l) => s + l.plants, 0);
    const hs = bs.map(b => bagHarvest(cfg, b)).sort();
    const avgMs = bagged ? bs.reduce((s, b) => s + dms(bagHarvest(cfg, b)) * b.bunches, 0) / bagged : undefined;
    rows.set(k, { k, color: colorOfPeriod(cfg, k), from: periodStart(cfg, k), to: addDays(periodStart(cfg, k), cfg.periodDays - 1), bagged, lost, net: Math.max(0, bagged - lost),
      hFrom: hs[0], hTo: hs[hs.length - 1], hAvg: avgMs !== undefined ? isoOf(Math.round(avgMs / DAYMS) * DAYMS) : undefined, harvested: 0 });
  }
  // hasat edilen: gün kaydının rengi + tarihi → aynı renkli, beklenen hasadı en yakın dönem
  for (const d of days) {
    let best: PeriodRow | undefined, bd = Infinity;
    for (const r of rows.values()) {
      if (r.color.name !== d.color) continue;
      const mid = r.hAvg || addDays(r.from, cfg.harvestDays + Math.floor(cfg.periodDays / 2));
      const dd = Math.abs(daysBetween(mid, d.date));
      if (dd < bd) { bd = dd; best = r; }
    }
    if (best && bd <= cfg.harvestDays / 2) best.harvested += dayBunches(d);
  }
  return [...rows.values()].sort((a, b) => a.k - b.k);
}

/* ───────── RefID ───────── */
const ascii = (s: string) => s.toLocaleUpperCase('tr-TR').replace(/İ/g, 'I').replace(/Ş/g, 'S').replace(/Ğ/g, 'G').replace(/Ü/g, 'U').replace(/Ö/g, 'O').replace(/Ç/g, 'C').replace(/Ý/g, 'Y').replace(/Ň/g, 'N').replace(/Ž/g, 'Z').replace(/Ä/g, 'A').replace(/[^A-Z0-9]/g, '');
export const seraCode = (sera: string) => ascii(sera.replace(/^muz\s*sera(sı|lary)?\s*/i, '')) || 'SERA';
export function muzRefId(date: string, sera: string, sector: string, color: string): string {
  return `MUZ-${date.slice(2, 4)}${date.slice(5, 7)}${date.slice(8, 10)}-${seraCode(sera)}-S${ascii(sector) || '0'}-${ascii(color)}`;
}

/* ───────── karar ───────── */
export interface MuzVerdict { decision: 'Kadaly' | 'Gaýtadan işlenen'; total: number; iskartaPct: number; lowPct: number; reason: string }
export function muzVerdict(g: Partial<Record<MuzGrade, number>> | undefined, cfg: MuzCfg): MuzVerdict | undefined {
  if (!g) return undefined;
  const total = MUZ_GRADES.reduce((s, k) => s + (Number(g[k]) || 0), 0);
  if (!total) return undefined;
  const iskartaPct = ((Number(g.Iskarta) || 0) / total) * 100;
  const lowPct = (((Number(g.Classic) || 0) + (Number(g.Mix) || 0)) / total) * 100;
  const over1 = iskartaPct > cfg.maxIskartaPct, over2 = lowPct > cfg.maxLowPct;
  return {
    decision: over1 || over2 ? 'Gaýtadan işlenen' : 'Kadaly', total, iskartaPct, lowPct,
    reason: over1 ? `ıskarta %${iskartaPct.toFixed(0)} > %${cfg.maxIskartaPct}` : over2 ? `Classic+Mix %${lowPct.toFixed(0)} > %${cfg.maxLowPct}` : `ıskarta %${iskartaPct.toFixed(0)} · Classic+Mix %${lowPct.toFixed(0)} — sınırlar içinde`,
  };
}
export const dayBunches = (d: MuzDay) => d.counts.reduce((s, c) => s + (Number(c.n) || 0), 0);

/* ───────── depo ───────── */
const LS = 'miwe_muz_v1';
let store: MuzDoc[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: MuzDoc[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'MUZ') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || String(r.at) > String(l.at)) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useMuzDocs(): MuzDoc[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store;
}
export function useMuzCfg(): MuzCfg {
  const docs = useMuzDocs();
  const c = docs.find(d => d.kind === 'cfg') as MuzCfg | undefined;
  return c && (c as any).anchor?.date ? { ...DEFAULT_CFG, ...c } : DEFAULT_CFG;
}
async function put(doc: MuzDoc): Promise<boolean> {
  store = [...store.filter(s => s.id !== doc.id), doc]; emit();
  try { return await saveRecordToFirestore('GANTT', doc as any); } catch { return false; }
}
export const saveMuzCfg = (cfg: Omit<MuzCfg, 'id' | 'calV' | 'kind' | 'at' | 'by'>, by?: string) => put({ ...cfg, id: 'muz-cfg', calV: 'MUZ', kind: 'cfg', at: new Date().toISOString(), by });

const dayId = (date: string, sera: string, sector: string, color: string) => `muz-${muzRefId(date, sera, sector, color)}`;
export function getDay(date: string, sera: string, sector: string, color: string): MuzDay | undefined {
  return store.find(s => s.id === dayId(date, sera, sector, color)) as MuzDay | undefined;
}
/** Gün kaydını aç ya da güncelle (salkım sayımı eklenir; kg ve sınıflar üzerine yazılır) */
export async function upsertDay(date: string, sera: string, sector: string, color: string, patch: { addCount?: number; kg?: number; grades?: Partial<Record<MuzGrade, number>>; note?: string }, by?: string) {
  const id = dayId(date, sera, sector, color);
  const cur = store.find(s => s.id === id) as MuzDay | undefined;
  const now = new Date().toISOString();
  const next: MuzDay = {
    ...(cur || { id, calV: 'MUZ', kind: 'day', date, sera, sector, color, refId: muzRefId(date, sera, sector, color), counts: [] }),
    at: now, by,
  };
  if (patch.addCount) next.counts = [...next.counts, { at: now, n: patch.addCount, by }];
  if (patch.kg !== undefined) { next.kg = patch.kg; next.kgAt = now; }
  if (patch.grades) { next.grades = patch.grades; next.gradesAt = now; }
  if (patch.note !== undefined) next.note = patch.note;
  return put(next);
}
/** Son sayım girişini geri al */
export async function undoCount(day: MuzDay, by?: string) {
  if (!day.counts.length) return false;
  return put({ ...day, counts: day.counts.slice(0, -1), at: new Date().toISOString(), by });
}
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
export async function saveBag(cfg: MuzCfg, sera: string, e: { date: string; color?: string; sector?: string; row?: string; bunches: number; lateDays?: number }, by?: string) {
  const k = periodOf(cfg, e.date);
  return put({ id: `muzbag-${seraCode(sera)}-${uid()}`, calV: 'MUZ', kind: 'bag', sera, date: e.date, k, color: e.color || colorOfPeriod(cfg, k).name, sector: e.sector, row: e.row, bunches: e.bunches, lateDays: e.lateDays || 0, at: new Date().toISOString(), by });
}
/** Renkli kayıp: o renkli, bu tarihten önce bağlanmış en son dönemden düşülür */
export async function saveLoss(cfg: MuzCfg, sera: string, e: { date: string; color?: string; sector?: string; row?: string; plants: number; reason: string; note?: string }, bags: MuzBag[], by?: string) {
  let k: number | undefined;
  if (e.color) {
    k = bags.filter(b => b.color === e.color && b.date <= e.date).sort((a, b) => b.date.localeCompare(a.date))[0]?.k;
    if (k === undefined) { let x = periodOf(cfg, e.date); for (let i = 0; i < cfg.colors.length; i++, x--) if (colorOfPeriod(cfg, x).name === e.color) { k = x; break; } }
  }
  return put({ id: `muzloss-${seraCode(sera)}-${uid()}`, calV: 'MUZ', kind: 'loss', sera, date: e.date, color: e.color, k, sector: e.sector, row: e.row, plants: e.plants, reason: e.reason, note: e.note, at: new Date().toISOString(), by });
}
/** Yanlış girişi sil (kayıt silinmez, boşaltılıp "removed" işaretlenir) */
export async function removeMuzDoc(d: MuzBag | MuzLoss, by?: string) {
  return put({ ...d, removed: true, at: new Date().toISOString(), by } as any);
}
export const isDay = (d: MuzDoc): d is MuzDay => d.kind === 'day';
export const isBag = (d: MuzDoc): d is MuzBag => d.kind === 'bag' && !(d as any).removed && typeof (d as any).k === 'number';
export const isClim = (d: MuzDoc): d is MuzClim => d.kind === 'clim';
/** Günlük iklim kaydı (sera + gün başına bir kayıt; yeniden girilirse üzerine yazılır) */
export async function saveClim(sera: string, rows: { date: string; tMin?: number; tMax?: number; tAvg?: number; rh?: number }[], source: string, by?: string) {
  let ok = true;
  for (const r of rows) ok = (await put({ id: `muzclim-${seraCode(sera)}-${r.date}`, calV: 'MUZ', kind: 'clim', sera, ...r, source, at: new Date().toISOString(), by })) && ok;
  return ok;
}
/** Otomasyondan yapıştırılan satırlar: "tarih; min; max; [ortalama]; [nem]" — ayraç ; , sekme ya da boşluk; tarih 27.11.2026 ya da 2026-11-27 */
export function parseClimPaste(text: string): { rows: { date: string; tMin?: number; tMax?: number; tAvg?: number; rh?: number }[]; bad: number } {
  const rows: { date: string; tMin?: number; tMax?: number; tAvg?: number; rh?: number }[] = []; let bad = 0;
  for (const line of text.split(/\r?\n/).map(l => l.trim()).filter(Boolean)) {
    const parts = line.split(/[;\t]|\s{2,}|\s(?=-?\d)/).map(x => x.trim()).filter(Boolean);
    const dRaw = parts[0] || '';
    let date = '';
    let m = dRaw.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) date = `${m[1]}-${m[2]}-${m[3]}`;
    m = dRaw.match(/^(\d{1,2})[./](\d{1,2})[./](\d{2,4})/); if (m) date = `${m[3].length === 2 ? '20' + m[3] : m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    const nums = parts.slice(1).map(x => Number(x.replace(',', '.'))).filter(x => Number.isFinite(x));
    if (!date || nums.length < 2) { bad++; continue; }
    rows.push({ date, tMin: nums[0], tMax: nums[1], tAvg: nums[2], rh: nums[3] });
  }
  return { rows, bad };
}
export const isLoss = (d: MuzDoc): d is MuzLoss => d.kind === 'loss' && !(d as any).removed;
