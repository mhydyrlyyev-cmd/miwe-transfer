import React from 'react';
import { ChevronRight, Flower2, TreeDeciduous } from 'lucide-react';
import type { HarvestRecord } from '../../types';
import { useOrchardOverview } from '../../services/orchardOverview';
import { UNIT_PLANS } from '../../config/unitPlans';
import { useMuzDocs } from '../../services/muzDaily';
import { muzTodaySummary } from '../views/MuzPanel';

/** v49c6 — Ana sayfa › Bahçeler: meyve türüne göre sezon gidişatı + bahçe kartları */
const t = (kg: number) => (kg >= 1000 ? `${(kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 })} t` : `${Math.round(kg)} kg`);
const dm = (ms: number) => new Date(ms).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' });

export default function OrchardsPanel({ harvestRecords, onOpenOrchard, onOpenCalendar }: { harvestRecords: HarvestRecord[]; onOpenOrchard: (name: string) => void; onOpenCalendar: () => void }) {
  const { season, orchards, fruits } = useOrchardOverview(harvestRecords);
  const muz = muzTodaySummary(useMuzDocs());
  if (!orchards.length) return null;
  const max = Math.max(...fruits.map(f => Math.max(f.plan, f.ref2026, f.done)), 1);
  const totPlan = orchards.reduce((s, o) => s + o.plan, 0), totDone = orchards.reduce((s, o) => s + o.done, 0), totRef = orchards.reduce((s, o) => s + o.ref2026, 0);
  const bloomIn = orchards.reduce((s, o) => s + o.bloomEntered, 0), bloomAll = orchards.reduce((s, o) => s + o.bloomNeeded, 0);
  const pre = totDone === 0;
  return (
    <section className="min-w-0 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><TreeDeciduous className="w-4 h-4 text-teal-700" />Bahçeler · {season} sezonu</h2>
        <button type="button" onClick={onOpenCalendar} className="text-xs font-semibold text-teal-700 cursor-pointer inline-flex items-center">Hasat takvimi<ChevronRight className="w-3.5 h-3.5" /></button>
      </div>
      <div className="text-xs text-slate-600 dark:text-slate-400">
        {pre ? <>Plan <b className="text-slate-900 dark:text-white tabular-nums">{t(totPlan)}</b>{totRef ? <> · 2026 gerçekleşen <b className="tabular-nums">{t(totRef)}</b> ({totPlan >= totRef ? '+' : ''}{Math.round(((totPlan - totRef) / (totRef || 1)) * 100)}%)</> : null}</>
          : <>Hasat <b className="text-slate-900 dark:text-white tabular-nums">{t(totDone)}</b> / plan {t(totPlan)} · %{Math.round((totDone / (totPlan || 1)) * 100)}</>}
      </div>

      <div>
        <div className="text-[11px] font-semibold text-slate-500 mb-1.5">Meyve türüne göre gidişat</div>
        <ul className="space-y-2">{fruits.map(f => (
          <li key={f.fruit}>
            <div className="flex items-baseline justify-between text-xs"><span className="font-semibold text-slate-800 dark:text-slate-200">{f.fruit}</span>
              <span className="tabular-nums text-slate-600 dark:text-slate-400">{pre ? `${t(f.ref2026)} → ${t(f.plan)}` : `${t(f.done)} / ${t(f.plan)}`}</span></div>
            <div className="relative h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 mt-1 overflow-hidden">
              <div className="absolute inset-y-0 left-0 bg-teal-200 dark:bg-teal-900" style={{ width: `${(f.plan / max) * 100}%` }} />
              <div className="absolute inset-y-0 left-0 bg-teal-700" style={{ width: `${(f.done / max) * 100}%` }} />
              {f.ref2026 > 0 && <div className="absolute inset-y-0 w-0.5 bg-slate-700 dark:bg-slate-300" style={{ left: `${Math.min(99.5, (f.ref2026 / max) * 100)}%` }} title="2026" />}
            </div>
          </li>))}</ul>
        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5 text-[10px] text-slate-500">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2 rounded-sm bg-teal-200 inline-block" />{season} plan</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2 rounded-sm bg-teal-700 inline-block" />hasat edilen</span>
          <span className="flex items-center gap-1"><span className="w-0.5 h-2.5 bg-slate-700 inline-block" />2026 gerçekleşen</span>
        </div>
      </div>

      {bloomAll > 0 && (
        <div className={`rounded-xl border px-3 py-2 text-xs flex gap-2 ${bloomIn < bloomAll ? 'border-teal-200 bg-teal-50 text-teal-900' : 'border-emerald-200 bg-emerald-50 text-emerald-900'}`}>
          <Flower2 className="w-4 h-4 shrink-0" /><span>{season} çiçeklenme girildi <b className="tabular-nums">{bloomIn} / {bloomAll}</b> çeşit — tahmini hasat tarihleri buna göre çıkar.</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">{orchards.map(o => (
        <button key={o.orchard} type="button" onClick={() => onOpenOrchard(o.orchard)} className="text-left rounded-xl border border-slate-200 dark:border-slate-800 px-3 py-2.5 cursor-pointer hover:border-teal-300">
          <div className="flex items-center justify-between gap-2"><span className="text-sm font-semibold text-slate-900 dark:text-white truncate">{o.orchard}</span><ChevronRight className="w-4 h-4 text-slate-300 shrink-0" /></div>
          <div className="text-xs text-slate-600 dark:text-slate-400 tabular-nums">{pre ? `Plan ${t(o.plan)}${o.ref2026 ? ` · 2026: ${t(o.ref2026)}` : ''}` : `Hasat ${t(o.done)} / ${t(o.plan)}`}</div>
          <div className="text-[11px] text-slate-500 mt-0.5 flex flex-wrap gap-x-2">
            {o.bloomNeeded > 0 && <span className={o.bloomEntered ? '' : 'text-amber-700'}>Çiçek {o.bloomEntered}/{o.bloomNeeded}</span>}
            {o.next && <span>İlk hasat ≈ {dm(o.next.at)} · {o.next.variety}</span>}
          </div>
        </button>))}
      </div>
      {(() => {
        const gh = Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'GREENHOUSE'), fl = Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'FIELD');
        const sum = (xs: typeof gh) => xs.reduce((s, [, u]) => s + u.rows.reduce((a, r) => a + r.kg, 0), 0);
        return (
          <div className="grid grid-cols-2 gap-2">
            {gh.length > 0 && <button type="button" onClick={() => onOpenOrchard(muz.days[0]?.sera || gh[0][0])} className="text-left rounded-xl border border-slate-200 dark:border-slate-800 px-3 py-2 cursor-pointer"><div className="text-xs font-semibold">Muz seraları · {gh.length}</div><div className="text-[11px] text-slate-500 tabular-nums">{muz.bunches ? `Bugün ${muz.bunches.toLocaleString('tr-TR')} salkım${muz.kg ? ` · ${t(muz.kg)}` : ''}` : `${season} plan ${t(sum(gh))}`}</div></button>}
            {fl.length > 0 && <button type="button" onClick={() => onOpenOrchard(fl[0][0])} className="text-left rounded-xl border border-slate-200 dark:border-slate-800 px-3 py-2 cursor-pointer"><div className="text-xs font-semibold">Açık tarla</div><div className="text-[11px] text-slate-500 tabular-nums">{season} plan {t(sum(fl))}</div></button>}
          </div>
        );
      })()}
    </section>
  );
}
