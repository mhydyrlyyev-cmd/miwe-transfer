import React, { useMemo, useState } from 'react';
import { MapPin, Thermometer, LocateFixed, ClipboardPaste } from 'lucide-react';
import { findProfile, upsertProfile } from '../../services/locationProfiles';
import { useElevations, useOutsideRecent } from '../../services/agroClimate';
import { useMuzDocs, isClim, saveClim, parseClimPaste, todayISO, addDays, CLIM_LIMITS } from '../../services/muzDaily';

/** v50c — Sera bilgisi (konum, yükseklik, dış hava) + sera içi iklim (otomasyondan günlük giriş ya da toplu yapıştırma; dış hava ile yan yana) */
const inp = 'w-full min-h-[36px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm tabular-nums';
const dm = (iso: string) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}`;
const r1 = (x?: number) => (typeof x === 'number' ? x.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—');

export function SeraInfo({ name, by = '', readOnly }: { name: string; by?: string; readOnly?: boolean }) {
  const pr = findProfile('GREENHOUSE', name);
  const lat = Number(pr?.fields?.lat) || undefined, lon = Number(pr?.fields?.lon) || undefined;
  const [elev] = useElevations([{ lat, lon }]);
  const out = useOutsideRecent(lat, lon);
  const [msg, setMsg] = useState('');
  const [manual, setManual] = useState('');
  const save = async (la: number, lo: number, how: string) => {
    if (!pr) { setMsg('Bu sera için profil yok.'); return; }
    await upsertProfile({ ...pr, fields: { ...pr.fields, lat: Math.round(la * 1e6) / 1e6, lon: Math.round(lo * 1e6) / 1e6 }, updatedBy: by });
    setMsg(`Konum kaydedildi (${how}).`); setManual('');
  };
  const today = out?.days.find(d => d.date === todayISO());
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1.5"><MapPin className="w-4 h-4 text-teal-700" />Sera bilgisi</h2>
      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Konum</div>
          <div className="text-sm font-semibold tabular-nums truncate">{lat && lon ? <a href={`https://maps.google.com/?q=${lat},${lon}`} target="_blank" rel="noreferrer" className="text-teal-800 dark:text-teal-300 underline">{lat.toFixed(4)}, {lon.toFixed(4)}</a> : <span className="text-amber-700">girilmedi</span>}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Denizden yükseklik</div><div className="text-sm font-semibold tabular-nums">{elev !== undefined ? `${elev.toLocaleString('tr-TR')} m` : lat ? '…' : '—'}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Dış hava şu an</div><div className="text-sm font-semibold tabular-nums">{out?.now !== undefined ? `${r1(out.now)} °C` : lat ? (out?.error ? '—' : '…') : '—'}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Dış bugün</div><div className="text-sm font-semibold tabular-nums">{today ? `${r1(today.tMin)} … ${r1(today.tMax)} °C` : '—'}</div></div>
      </div>
      {!readOnly && (
        <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
          <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] gap-1.5">
            <button type="button" onClick={() => {
              if (!navigator.geolocation) { setMsg('Bu cihaz konum vermiyor.'); return; }
              setMsg('Konum alınıyor…');
              navigator.geolocation.getCurrentPosition(p => save(p.coords.latitude, p.coords.longitude, `±${Math.round(p.coords.accuracy)} m`), () => setMsg('Konum alınamadı — izin verin ya da elle yazın.'), { enableHighAccuracy: true, timeout: 15000 });
            }} className="min-h-[36px] px-2.5 rounded-lg border border-teal-300 text-teal-800 dark:text-teal-300 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"><LocateFixed className="w-3.5 h-3.5" />Konumumu al</button>
            <input placeholder="ya da 37.9512, 58.3801" aria-label="Konum (enlem, boylam)" value={manual} onChange={e => setManual(e.target.value)} className={inp} />
            <button type="button" disabled={!/^\s*-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?\s*$/.test(manual)} onClick={() => { const [a, b] = manual.split(',').map(Number); save(a, b, 'elle'); }} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          </div>
          <p className="text-[10px] text-slate-500">{msg || 'Seranın dışında durup "Konumumu al"a basın; ya da Google Haritalar\'dan koordinatı yapıştırın.'}</p>
        </div>
      )}
    </section>
  );
}

export default function SeraClimate({ name, by = '', readOnly }: { name: string; by?: string; readOnly?: boolean }) {
  const docs = useMuzDocs();
  const pr = findProfile('GREENHOUSE', name);
  const out = useOutsideRecent(Number(pr?.fields?.lat) || undefined, Number(pr?.fields?.lon) || undefined);
  const today = todayISO();
  const [f, setF] = useState({ date: today, tMin: '', tMax: '', tAvg: '', rh: '' });
  const [paste, setPaste] = useState('');
  const [msg, setMsg] = useState('');
  const clim = useMemo(() => docs.filter(isClim).filter(c => c.sera === name), [docs, name]);
  const days = Array.from({ length: 14 }, (_, i) => addDays(today, -i));
  const rowOf = (d: string) => clim.find(c => c.date === d);
  const outOf = (d: string) => out?.days.find(x => x.date === d);
  const last7 = days.slice(0, 7).map(rowOf).filter(Boolean) as NonNullable<ReturnType<typeof rowOf>>[];
  const cold = last7.filter(c => typeof c.tMin === 'number' && c.tMin < CLIM_LIMITS.cold).length;
  const hot = last7.filter(c => typeof c.tMax === 'number' && c.tMax > CLIM_LIMITS.hot).length;
  const num = (x: string) => (x.trim() === '' ? undefined : Number(x.replace(',', '.')));
  const pp = paste.trim() ? parseClimPaste(paste) : undefined;
  // ölçek: -5 … 45 °C
  const X = (t: number) => `${Math.max(0, Math.min(100, ((t + 5) / 50) * 100))}%`;
  const tone = (c?: { tMin?: number; tMax?: number }) => !c ? '' : (c.tMin ?? 99) < CLIM_LIMITS.cold || (c.tMax ?? -99) > CLIM_LIMITS.hot ? 'text-rose-700 font-semibold' : (c.tMin ?? 99) < CLIM_LIMITS.coldWarn ? 'text-amber-700' : '';
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2.5">
      <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Thermometer className="w-4 h-4 text-teal-700" />Sera içi iklim</h2>
      <p className="text-[11px] text-slate-500">Otomasyon ekranındaki günlük en düşük / en yüksek. Muz için gece {CLIM_LIMITS.cold} °C altı soğuk zararı, gündüz {CLIM_LIMITS.hot} °C üstü sıcak stresi.</p>
      {last7.length > 0 && (
        <div className={`rounded-lg border px-2.5 py-1.5 text-xs ${cold || hot ? 'border-rose-200 bg-rose-50 text-rose-900' : 'border-emerald-200 bg-emerald-50 text-emerald-900'}`}>
          Son 7 gün ({last7.length} kayıt): {cold ? `${cold} gece < ${CLIM_LIMITS.cold} °C` : 'soğuk gece yok'} · {hot ? `${hot} gün > ${CLIM_LIMITS.hot} °C` : 'sıcak stresi yok'}
        </div>
      )}
      {!readOnly && (
        <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5 space-y-1.5">
          <div className="grid grid-cols-3 gap-1.5">
            <label className="text-[10px] text-slate-500 col-span-3">Gün<input type="date" max={today} value={f.date} onChange={e => e.target.value && setF({ ...f, date: e.target.value })} className={inp} /></label>
            <label className="text-[10px] text-slate-500">En düşük °C<input inputMode="decimal" value={f.tMin} onChange={e => setF({ ...f, tMin: e.target.value })} className={inp} /></label>
            <label className="text-[10px] text-slate-500">En yüksek °C<input inputMode="decimal" value={f.tMax} onChange={e => setF({ ...f, tMax: e.target.value })} className={inp} /></label>
            <label className="text-[10px] text-slate-500">Nem %<input inputMode="decimal" value={f.rh} onChange={e => setF({ ...f, rh: e.target.value })} className={inp} /></label>
          </div>
          <button type="button" disabled={num(f.tMin) === undefined || num(f.tMax) === undefined} onClick={async () => { await saveClim(name, [{ date: f.date, tMin: num(f.tMin), tMax: num(f.tMax), rh: num(f.rh) }], 'el', by); setF({ ...f, tMin: '', tMax: '', rh: '' }); setMsg(`${dm(f.date)} kaydedildi.`); }}
            className="w-full min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          <details>
            <summary className="text-[11px] text-slate-600 dark:text-slate-400 cursor-pointer flex items-center gap-1"><ClipboardPaste className="w-3.5 h-3.5" />Otomasyondan toplu yapıştır</summary>
            <textarea rows={4} value={paste} onChange={e => setPaste(e.target.value)} placeholder={'27.11.2026; 16,5; 31,2; 24; 78\n26.11.2026; 15,8; 30,4'} className="mt-1 w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-xs font-mono" />
            <p className="text-[10px] text-slate-500">Her satır: tarih; en düşük; en yüksek; [ortalama]; [nem]. Aynı gün yeniden gelirse üzerine yazılır.</p>
            {pp && <p className="text-[10px] text-slate-600">{pp.rows.length} satır okundu{pp.bad ? ` · ${pp.bad} satır okunamadı` : ''}</p>}
            <button type="button" disabled={!pp?.rows.length} onClick={async () => { await saveClim(name, pp!.rows, 'otomasyon', by); setMsg(`${pp!.rows.length} gün kaydedildi.`); setPaste(''); }} className="mt-1 w-full min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Yapıştırılanları kaydet</button>
          </details>
          {msg && <p className="text-[10px] text-emerald-700">{msg}</p>}
        </div>
      )}
      <div>
        <div className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 text-[10px] text-slate-500 font-semibold"><span>Gün</span><span>İç min–max</span><span className="flex items-center gap-2"><span className="inline-block w-3 h-1.5 rounded bg-teal-600" />iç <span className="inline-block w-3 h-1.5 rounded bg-slate-300" />dış</span><span className="text-right">Dış</span></div>
        {days.map(d => {
          const c = rowOf(d), o = outOf(d);
          return (
            <div key={d} className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 items-center text-[11px] tabular-nums py-0.5">
              <span>{dm(d)}</span>
              <span className={tone(c)}>{c ? `${r1(c.tMin)} … ${r1(c.tMax)}` : '—'}</span>
              <div className="relative h-3">
                <div className="absolute inset-y-0 bg-rose-50 dark:bg-rose-950/30" style={{ left: 0, width: X(CLIM_LIMITS.cold) }} />
                {o && <div className="absolute top-[9px] h-1 rounded bg-slate-300 dark:bg-slate-600" style={{ left: X(o.tMin), width: `calc(${X(o.tMax)} - ${X(o.tMin)})` }} />}
                {c && typeof c.tMin === 'number' && typeof c.tMax === 'number' && <div className="absolute top-0.5 h-1.5 rounded bg-teal-600" style={{ left: X(c.tMin), width: `calc(${X(c.tMax)} - ${X(c.tMin)})` }} />}
              </div>
              <span className="text-right text-slate-500">{o ? `${Math.round(o.tMin)} … ${Math.round(o.tMax)}` : '—'}</span>
            </div>);
        })}
        <div className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 text-[9px] text-slate-400"><span /><span /><span className="flex justify-between"><span>−5</span><span>20</span><span>45 °C</span></span><span /></div>
      </div>
    </section>
  );
}
