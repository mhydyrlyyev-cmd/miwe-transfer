# v50c — Muz + sera (v50 ve v50b dahil; onları ayrıca uygulama)

1. YENİ services/muzDaily.ts: muz günlüğü (ganttParcels, calV 'MUZ'; Firestore kuralı DEĞİŞMEZ).
   RefID: MUZ-YYAAGG-<sera kodu>-S<sektör>-<RENK>. Karar: ıskarta % ya da Classic+Mix % sınırı aşarsa "Gaýtadan işlenen", değilse "Kadaly".
   Kurdele: renk dönemi (10 gün), renkler aynı sırayla tekrar; beklenen hasat = bağlama + 98 gün − geç gün; kayıp renkliyse dönemden düşülür, renksizse sektör · sıra.
   Net salkım × ortalama salkım kg = beklenen ton. Döngü kontrolü (renk sayısı × dönem < hasat + dönem → uyarı).
   v50c: sera içi iklim kaydı (gün başına en düşük / en yüksek / nem; elle ya da otomasyondan toplu yapıştırma). Muz sınırları: gece < 13 °C, gündüz > 36 °C.
2. YENİ components/views/MuzPanel.tsx: Günlük (partiler, salkım, akşam kg, kalite → karar) + Kurdele · hasat takvimi (bağlama, kayıp, dönemler, 30 gün tonaj, ayar).
   v50c: geç bağlama dönem gününü aşınca uyarı (doğduğu dönemin rengi kaçırıldı); dönem satırında "geç" salkım sayısı.
3. YENİ components/views/SeraClimate.tsx: "Sera bilgisi" (konum — Konumumu al ya da koordinat yapıştır, profile kaydeder; denizden yükseklik; dış hava şu an ve bugün)
   ve "Sera içi iklim" (giriş, toplu yapıştırma, son 14 gün iç ve dış min–max yan yana; soğuk / sıcak günler renkli).
4. agroClimate.ts: useOutsideRecent (Open-Meteo, son 14 gün + şu an; 3 saat önbellek).
5. OrchardCardsView: her serada Sera bilgisi + Sera içi iklim; muz serasında MuzPanel. OrchardsPanel: "Muz seraları" kutusunda bugün salkım · ton.
6. HomeDashboard: Bugün bakılacaklar › Bahçe: sera başına — akşam kg yok (17:00 sonrası), kalite yok, gaýtadan işlenen parti.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (7 dosya)
1aff617914c532742cdab3db1c56da7dc21a0eaec5c942a7906a095b79cf774f  src/services/muzDaily.ts
abd1d4e2aff042e4eb76992e2ad7636fcf9207782b4b4e8bfdede27e7e7e4102  src/services/agroClimate.ts
8b9ea265e332666bd4d2d4066f4633c136882c93031aaaaf485fd4e69b1c3c27  src/components/views/MuzPanel.tsx
6ab48a8e0993300920122b6ccec554859ee6ae8e62c7420fc037a69e024bfebd  src/components/views/SeraClimate.tsx
297f9f73ee3dd00e8cc2e3b8dcf54b21781f3bf8bc26ee3af8490a8753df4743  src/components/views/OrchardCardsView.tsx
25964166d9910ae87975a2a40fc63208d97493e85bb027b58dc05dffda691c33  src/components/dashboard/OrchardsPanel.tsx
7c167cb1eabd69c245579e66a7aa834994dd21456033a3187103b1c7620c7dd7  src/components/dashboard/HomeDashboard.tsx
