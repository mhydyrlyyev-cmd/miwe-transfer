/**
 * v59 — Ağaç defteri (bahçeler): muzdaki kayıp mantığıyla. Başlangıç: bütçedeki parsel ağaç sayısı (ORCHARD_CARDS).
 *  − kayıp (hastalık, kuruma, kırılma, söküm) · + yeni dikim (yıl ile) · = sayım düzeltmesi (sayılan gerçek sayı).
 * Net ağaç × kg/ağaç → 2027 plan etkisi. Kayıt: Firestore 'ganttParcels' (calV: 'AGAC'; kural değişmez) + yerel önbellek.
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import { ORCHARD_CARDS } from '../config/orchardCards';
import { vkey } from './orchardOverview';

export type TreeKind = 'loss' | 'plant' | 'count';
export const LOSS_REASONS = ['Hastalık', 'Kuruma', 'Kırılma / rüzgâr', 'Söküm', 'Diğer'] as const;
export interface TreeDoc {
  id: string; calV: 'AGAC'; orchard: string; variety: string; tur: string; kind: TreeKind;
  n: number; parsel?: string; year?: number; reason?: string; note?: string; date: string;
  removed?: boolean; at: string; by?: string;
}

const LS = 'miwe_agac_v1';
let store: TreeDoc[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: TreeDoc[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'AGAC') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || String(r.at) > String(l.at)) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useTreeDocs(): TreeDoc[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store.filter(d => !d.removed);
}
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
async function put(doc: TreeDoc) {
  store = [...store.filter(s => s.id !== doc.id), doc]; emit();
  try { return await saveRecordToFirestore('GANTT', doc as any); } catch { return false; }
}
export const addTreeDoc = (d: Omit<TreeDoc, 'id' | 'calV' | 'at'>, by?: string) =>
  put({ ...d, id: `agac-${uid()}`, calV: 'AGAC', at: new Date().toISOString(), by });
export const removeTreeDoc = (d: TreeDoc, by?: string) => put({ ...d, removed: true, at: new Date().toISOString(), by });

export interface TreeRow { tur: string; variety: string; key: string; base: number; lost: number; planted: number; net: number; kgAgac: number; planKg: number; netPlanKg: number; bearing?: number; budgetKg?: number; counted?: TreeDoc; years: number[] }
/** Bahçe başına çeşit çeşit: bütçe ağacı, kayıp, yeni dikim, net (son sayım varsa sayım + sonrası) ve plan etkisi */
export function treeRows(orchard: string, docs: TreeDoc[]): TreeRow[] {
  const card = ORCHARD_CARDS[orchard];
  const m = new Map<string, TreeRow>();
  for (const p of card?.parcels || []) {
    const key = vkey(p.cesit);
    const r = m.get(key) || { tur: p.tur, variety: p.cesit, key, base: 0, lost: 0, planted: 0, net: 0, kgAgac: 0, planKg: 0, netPlanKg: 0, years: [] };
    r.base += Number(p.agac) || 0; r.planKg += Number(p.planKg) || 0; if ((Number(p.planKg) || 0) > 0) r.bearing = (r.bearing || 0) + (Number(p.agac) || 0); const y = Number(p.yil); if (y && !r.years.includes(y)) r.years.push(y);
    m.set(key, r);
  }
  const mine = docs.filter(d => d.orchard === orchard).sort((a, b) => a.date.localeCompare(b.date) || a.at.localeCompare(b.at));
  for (const d of mine) {
    const key = vkey(d.variety);
    const r = m.get(key) || { tur: d.tur, variety: d.variety, key, base: 0, lost: 0, planted: 0, net: 0, kgAgac: 0, planKg: 0, netPlanKg: 0, years: [] };
    if (d.kind === 'count') { r.counted = d; r.lost = 0; r.planted = 0; }
    else if (d.kind === 'loss') r.lost += d.n;
    else { r.planted += d.n; if (d.year && !r.years.includes(d.year)) r.years.push(d.year); }
    m.set(key, r);
  }
  // v60: tonaj Özet ile aynı kaynaktan (çeşit 2027 planı); ağaç sayısı ve dikim yılı parsel listesinden
  for (const v of card?.varieties || []) { const r = m.get(vkey(v.cesit)); if (r && v.plan2027Kg > 0) { r.budgetKg = r.planKg; r.planKg = v.plan2027Kg; } }
  for (const r of m.values()) {
    const start = r.counted ? r.counted.n : r.base;
    r.net = Math.max(0, start - r.lost + r.planted);
    // verimdeki ağaç: parsel planı > 0 olanlar (genç dikim verime girmez); yoksa hepsi
    const bearing = r.bearing || r.base;
    r.kgAgac = bearing ? r.planKg / bearing : 0;
    const youngBase = r.base - bearing;
    const productive = r.counted ? Math.max(0, r.counted.n - youngBase - r.lost) : Math.max(0, bearing - r.lost);
    r.netPlanKg = r.kgAgac * productive;
    r.years.sort();
  }
  return [...m.values()].sort((a, b) => a.tur.localeCompare(b.tur, 'tr') || b.base - a.base);
}
