import React, { useState } from 'react';
import { TreeDeciduous, X } from 'lucide-react';
import { useTreeDocs, addTreeDoc, removeTreeDoc, treeRows, LOSS_REASONS, type TreeKind } from '../../services/treeLedger';

/**
 * v59 — Bahçe › Profil › Ağaçlar: bütçedeki ağaç sayısı, kayıp (hastalık, kuruma…), yeni dikim, sayım düzeltmesi → net ağaç ve 2027 plan etkisi.
 */
const n0 = (x: number) => Math.round(x).toLocaleString('tr-TR');
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 });
const today = () => new Date().toISOString().slice(0, 10);

export default function TreesPanel({ orchard, by, readOnly }: { orchard: string; by: string; readOnly?: boolean }) {
  const docs = useTreeDocs();
  const rows = treeRows(orchard, docs);
  const [form, setForm] = useState(false);
  const [f, setF] = useState<{ variety: string; kind: TreeKind; n: string; reason: string; year: string; parsel: string; date: string; note: string }>({ variety: '', kind: 'loss', n: '', reason: 'Hastalık', year: String(new Date().getFullYear()), parsel: '', date: today(), note: '' });
  const [showLog, setShowLog] = useState(false);
  const mine = docs.filter(d => d.orchard === orchard).sort((a, b) => b.date.localeCompare(a.date));
  const tot = rows.reduce((a, r) => ({ base: a.base + r.base, lost: a.lost + r.lost, planted: a.planted + r.planted, net: a.net + r.net, plan: a.plan + r.planKg, netPlan: a.netPlan + r.netPlanKg }), { base: 0, lost: 0, planted: 0, net: 0, plan: 0, netPlan: 0 });
  const sel = rows.find(r => r.variety === f.variety);
  const inp = 'w-full min-h-[38px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm';
  if (!rows.length) return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <h2 className="text-sm font-bold flex items-center gap-1.5"><TreeDeciduous className="w-4 h-4 text-teal-700" />Ağaçlar</h2>
      <p className="text-[11px] text-slate-500 mt-1">Bu bahçenin parsel / ağaç listesi bütçede yok. Liste gelince buraya eklenir (Uyarlama rehberi › prompt 1).</p>
    </section>
  );
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2">
      <div className="flex items-center justify-between"><h2 className="text-sm font-bold flex items-center gap-1.5"><TreeDeciduous className="w-4 h-4 text-teal-700" />Ağaçlar</h2>
        <span className="text-[11px] tabular-nums text-slate-600">{n0(tot.net)} ağaç{tot.lost ? <span className="text-rose-700"> · −{n0(tot.lost)}</span> : null}{tot.planted ? <span className="text-emerald-700"> · +{n0(tot.planted)}</span> : null}</span></div>
      {(tot.lost > 0 || tot.netPlan !== tot.plan) && tot.plan > 0 && <p className="text-[11px] text-amber-800 bg-amber-50 rounded-lg px-2.5 py-1">2027 plan etkisi: {t1(tot.plan)} t → {t1(tot.netPlan)} t (kayıp ve sayıma göre; yeni dikim bu yıl verime girmez)</p>}
      <div className="grid grid-cols-[minmax(0,1fr)_52px_44px_44px_56px] gap-1 text-[9px] font-semibold text-slate-500 border-b border-slate-100 pb-1"><span>Çeşit · dikim</span><span className="text-right">bütçe</span><span className="text-right">kayıp</span><span className="text-right">yeni</span><span className="text-right">net</span></div>
      {rows.map(r => (
        <div key={r.key} className="grid grid-cols-[minmax(0,1fr)_52px_44px_44px_56px] gap-1 text-xs tabular-nums py-0.5">
          <span className="min-w-0 truncate"><b>{r.variety}</b> <span className="text-slate-500">· {r.tur} · {r.years.join(', ')}</span>{r.counted ? <span className="text-[9px] ml-1 px-1 rounded border border-sky-200 bg-sky-50 text-sky-800">sayım {r.counted.date.slice(8, 10)}.{r.counted.date.slice(5, 7)}</span> : null}</span>
          <span className="text-right text-slate-500">{n0(r.base)}</span><span className={`text-right ${r.lost ? 'text-rose-700' : 'text-slate-300'}`}>{r.lost ? `−${n0(r.lost)}` : '·'}</span>
          <span className={`text-right ${r.planted ? 'text-emerald-700' : 'text-slate-300'}`}>{r.planted ? `+${n0(r.planted)}` : '·'}</span><b className="text-right">{n0(r.net)}</b>
        </div>))}
      {!readOnly && (form ? (
        <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5 space-y-1.5">
          <div className="flex gap-1">{([['loss', 'Kayıp −'], ['plant', 'Yeni dikim +'], ['count', 'Sayım =']] as const).map(([k, l]) => (
            <button key={k} type="button" onClick={() => setF({ ...f, kind: k })} className={`flex-1 min-h-[34px] rounded-lg border text-xs font-semibold cursor-pointer ${f.kind === k ? (k === 'loss' ? 'bg-rose-600 text-white border-rose-600' : k === 'plant' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-sky-600 text-white border-sky-600') : 'border-slate-300'}`}>{l}</button>))}</div>
          <select aria-label="Çeşit" value={f.variety} onChange={e => setF({ ...f, variety: e.target.value })} className={inp}><option value="">Çeşit seçin</option>{rows.map(r => <option key={r.key} value={r.variety}>{r.tur} · {r.variety}</option>)}</select>
          <div className="grid grid-cols-3 gap-1.5">
            <label className="text-[10px] text-slate-500">{f.kind === 'count' ? 'Sayılan ağaç' : 'Adet'}<input inputMode="numeric" value={f.n} onChange={e => setF({ ...f, n: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
            {f.kind === 'plant' ? <label className="text-[10px] text-slate-500">Dikim yılı<input inputMode="numeric" value={f.year} onChange={e => setF({ ...f, year: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
              : <label className="text-[10px] text-slate-500">Tarih<input type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} className={inp} /></label>}
            <label className="text-[10px] text-slate-500">Parsel<input value={f.parsel} onChange={e => setF({ ...f, parsel: e.target.value })} className={inp} placeholder="isteğe bağlı" /></label>
          </div>
          {f.kind === 'loss' && <div className="flex flex-wrap gap-1">{LOSS_REASONS.map(x => <button key={x} type="button" onClick={() => setF({ ...f, reason: x })} className={`px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${f.reason === x ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{x}</button>)}</div>}
          {f.kind === 'count' && sel && <p className="text-[10px] text-slate-500">Şu an {n0(sel.net)} görünüyor; sayım girilince net bu sayıdan devam eder (önceki kayıp / dikimler sıfırlanır).</p>}
          <input value={f.note} onChange={e => setF({ ...f, note: e.target.value })} placeholder="Not (hastalık adı, sebep…)" className={inp} />
          <div className="grid grid-cols-2 gap-1.5">
            <button type="button" onClick={() => setForm(false)} className="min-h-[36px] rounded-lg border border-slate-300 text-xs cursor-pointer">Vazgeç</button>
            <button type="button" disabled={!sel || !Number(f.n)} onClick={async () => { await addTreeDoc({ orchard, variety: sel!.variety, tur: sel!.tur, kind: f.kind, n: Number(f.n), parsel: f.parsel || undefined, year: f.kind === 'plant' ? Number(f.year) || undefined : undefined, reason: f.kind === 'loss' ? f.reason : undefined, note: f.note || undefined, date: f.kind === 'plant' ? `${f.year || new Date().getFullYear()}-${today().slice(5)}` : f.date }, by); setForm(false); setF({ ...f, n: '', note: '', parsel: '' }); }} className="min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          </div>
        </div>
      ) : <button type="button" onClick={() => setForm(true)} className="w-full min-h-[36px] rounded-lg border border-dashed border-teal-400 text-teal-800 dark:text-teal-300 text-xs font-semibold cursor-pointer">+ Kayıp / yeni dikim / sayım</button>)}
      {mine.length > 0 && (
        <div>
          <button type="button" onClick={() => setShowLog(v => !v)} className="text-[11px] font-semibold text-slate-600 cursor-pointer">{showLog ? 'Kayıtları gizle' : `Kayıtlar (${mine.length}) ›`}</button>
          {showLog && <ul className="mt-1 divide-y divide-slate-100 dark:divide-slate-800">{mine.map(d => (
            <li key={d.id} className="flex items-center justify-between gap-2 py-1 text-[11px]">
              <span className="min-w-0 truncate">{d.date.slice(8, 10)}.{d.date.slice(5, 7)}.{d.date.slice(2, 4)} · <b>{d.variety}</b> · {d.kind === 'loss' ? <span className="text-rose-700">−{d.n} {d.reason}</span> : d.kind === 'plant' ? <span className="text-emerald-700">+{d.n} dikim {d.year || ''}</span> : <span className="text-sky-700">sayım {d.n}</span>}{d.parsel ? ` · ${d.parsel}` : ''}{d.note ? ` · ${d.note}` : ''}{d.by ? ` · ${d.by}` : ''}</span>
              {!readOnly && <button type="button" aria-label="Sil" onClick={() => removeTreeDoc(d, by)} className="text-slate-400 cursor-pointer"><X className="w-3.5 h-3.5" /></button>}
            </li>))}</ul>}
        </div>
      )}
      <p className="text-[10px] text-slate-500">Ağaç sayısı ve dikim yılı: BYUJET 2027 parsel listesi (Saýwan: "Saywan Nektarin" sayfası). Tonaj: Özet'teki 2027 planı. Kayıp ve sayım bu tonajı verimdeki ağaç başına kg ile düşürür; genç dikim verime girmez.</p>
    </section>
  );
}
