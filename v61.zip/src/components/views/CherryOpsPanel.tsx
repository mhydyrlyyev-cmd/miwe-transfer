import React, { useState } from 'react';
import { Users } from 'lucide-react';
import { CHERRY_FACT_2026, CHERRY_PLAN_2026, CHERRY_DAILY_2026, CHERRY_SOURCE, CHERRY_PLAN_KG_PER_WORKER } from '../../config/cherryOps2026';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { vkey } from '../../services/orchardOverview';

/**
 * v60 — Saýwan Nektarin / Saýwan Gursak › Özet: 2026 kiraz hasadı ve işçi dağılımı (Gantt › CHERRY- OPER).
 * Günlük çubuk iki bahçenin toplamıdır (kaynak sayfada bahçe ayrımı yok).
 */
const n0 = (x: number) => Math.round(x).toLocaleString('tr-TR');
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 });
const dm = (iso: string) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}`;
const addDays = (iso: string, n: number) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

export function hasCherryOps(orchard: string) { return CHERRY_FACT_2026.some(f => f.orchard === orchard); }

export default function CherryOpsPanel({ orchard }: { orchard: string }) {
  const [open, setOpen] = useState(false);
  const fact = CHERRY_FACT_2026.filter(f => f.orchard === orchard);
  const plan = CHERRY_PLAN_2026.filter(p => p.orchard === orchard);
  if (!fact.length) return null;
  const kg = fact.reduce((s, f) => s + f.kg, 0);
  const wd = fact.reduce((s, f) => s + f.workerDays, 0);
  const kgW = fact.filter(f => f.workerDays > 0);
  const avg = kgW.reduce((s, f) => s + f.workerDays, 0) ? kgW.reduce((s, f) => s + f.kg, 0) / kgW.reduce((s, f) => s + f.workerDays, 0) : 0;
  const first = fact.map(f => f.start).sort()[0], last = fact.map(f => f.end).sort().slice(-1)[0];
  const cherry27 = (ORCHARD_CARDS[orchard]?.varieties || []).filter(v => v.tur === 'Kiraz').reduce((s, v) => s + v.plan2027Kg, 0);
  // günlük: iki seri farklı günde başlıyor → ortak eksen
  const days: string[] = [];
  const s0 = [CHERRY_DAILY_2026.plan.start, CHERRY_DAILY_2026.fact.start].sort()[0];
  const e0 = [addDays(CHERRY_DAILY_2026.plan.start, CHERRY_DAILY_2026.plan.v.length - 1), addDays(CHERRY_DAILY_2026.fact.start, CHERRY_DAILY_2026.fact.v.length - 1)].sort().slice(-1)[0];
  for (let d = s0; d <= e0; d = addDays(d, 1)) days.push(d);
  const at = (ser: { start: string; v: number[] }, d: string) => { const i = Math.round((Date.parse(d) - Date.parse(ser.start)) / 864e5); return i >= 0 && i < ser.v.length ? ser.v[i] : 0; };
  const max = Math.max(1, ...days.map(d => Math.max(at(CHERRY_DAILY_2026.plan, d), at(CHERRY_DAILY_2026.fact, d))));
  const peak = days.reduce((b, d) => (at(CHERRY_DAILY_2026.fact, d) > at(CHERRY_DAILY_2026.fact, b) ? d : b), days[0]);
  const planOf = (v: string) => plan.find(p => vkey(p.variety) === vkey(v));
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold flex items-center gap-1.5"><Users className="w-4 h-4 text-teal-700" />Kiraz 2026 · hasat ve işçi</h2>
        <span className="text-[10px] text-slate-400">{dm(first)}–{dm(last)}</span>
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        {[[`${t1(kg)} t`, 'hasat edilen'], [n0(wd), 'işçi-gün'], [avg ? `${n0(avg)} kg` : '—', `işçi/gün (plan ${CHERRY_PLAN_KG_PER_WORKER})`]].map(([a, b]) => (
          <div key={b} className="rounded-xl bg-slate-50 dark:bg-slate-800/60 py-1.5"><div className="text-sm font-bold tabular-nums">{a}</div><div className="text-[10px] text-slate-500">{b}</div></div>
        ))}
      </div>
      <div>
        <div className="flex items-end gap-px h-16" aria-label="Günlük işçi: plan ve gelen">
          {days.map(d => { const pv = at(CHERRY_DAILY_2026.plan, d), fv = at(CHERRY_DAILY_2026.fact, d); return (
            <div key={d} className="flex-1 flex items-end gap-px h-full" title={`${dm(d)} · plan ${pv} · gelen ${fv}`}>
              <div className="flex-1 bg-slate-200 dark:bg-slate-700 rounded-t-sm" style={{ height: `${(pv / max) * 100}%` }} />
              <div className="flex-1 bg-teal-600 rounded-t-sm" style={{ height: `${(fv / max) * 100}%` }} />
            </div>); })}
        </div>
        <div className="flex justify-between text-[9px] text-slate-400 mt-0.5"><span>{dm(days[0])}</span><span>{dm(days[Math.floor(days.length / 2)])}</span><span>{dm(days[days.length - 1])}</span></div>
        <p className="text-[10px] text-slate-500"><span className="inline-block w-2 h-2 bg-slate-300 rounded-sm mr-1" />plan işçi <span className="inline-block w-2 h-2 bg-teal-600 rounded-sm mx-1" />gelen işçi · iki Saýwan bahçesi birlikte · en yoğun gün {dm(peak)}: {at(CHERRY_DAILY_2026.fact, peak)} kişi</p>
      </div>
      {cherry27 > 0 && avg > 0 && <p className="text-[11px] text-teal-900 bg-teal-50 dark:bg-teal-950/40 rounded-lg px-2.5 py-1">2027 kiraz planı {t1(cherry27)} t → 2026 verimiyle ({n0(avg)} kg/işçi) ≈ {n0(cherry27 / avg)} işçi-gün; plan normuyla ({CHERRY_PLAN_KG_PER_WORKER} kg) ≈ {n0(cherry27 / CHERRY_PLAN_KG_PER_WORKER)} işçi-gün.</p>}
      <button type="button" onClick={() => setOpen(o => !o)} className="text-xs font-semibold text-teal-700 cursor-pointer">{open ? 'Çeşitleri gizle' : `Çeşit çeşit (${fact.length})`} ›</button>
      {open && (
        <div className="text-[11px]">
          <div className="grid grid-cols-[minmax(0,1fr)_64px_46px_44px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Çeşit</span><span>dönem</span><span className="text-right">t</span><span className="text-right">işçi-gün</span><span className="text-right">kg/işçi</span></div>
          {fact.map((f, i) => { const pl = planOf(f.variety); return (
            <div key={i} className="py-1 border-t border-slate-100 dark:border-slate-800">
              <div className="grid grid-cols-[minmax(0,1fr)_64px_46px_44px_40px] gap-1 tabular-nums">
                <span className="truncate font-semibold">{f.variety}{f.note && <span className="font-normal text-slate-400"> · {f.note}</span>}</span>
                <span>{dm(f.start)}–{dm(f.end)}</span><span className="text-right">{t1(f.kg)}</span><span className="text-right">{f.workerDays || '—'}</span><span className="text-right">{f.kgPerWorker ? n0(f.kgPerWorker) : '—'}</span>
              </div>
              {pl && <div className="text-[10px] text-slate-400">plan {dm(pl.start)}–{dm(pl.end)} · bütçe {pl.budgetKg != null ? `${t1(pl.budgetKg)} t` : '—'} · saha sayımı {t1(pl.countKg)} t · {pl.workersPerDay} işçi/gün</div>}
            </div>); })}
        </div>
      )}
      <p className="text-[10px] text-slate-400">Kaynak: {CHERRY_SOURCE}. Değerler sayfadaki gibi.</p>
    </section>
  );
}
