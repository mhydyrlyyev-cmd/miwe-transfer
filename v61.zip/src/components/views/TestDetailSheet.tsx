import React from 'react';
import { X } from 'lucide-react';
import type { FieldRecord, HarvestRecord } from '../../types';
import type { ArchiveTest } from '../../config/archive2026';

/**
 * v59 — Teste dokununca: o testin bütün bilgisi (okuma görünümü) + aynı bahçe / çeşidin geçmişi
 * (2026 arşivi kaç test, kaç hasat testi; 2027 kaç test; kaç hasat kaydı). Düzenleme: "Ayrıntılı formda aç".
 */
const f1 = (x?: number, d = 1) => (x === undefined || x === null || Number.isNaN(x) || x === 0 ? '—' : x.toLocaleString('tr-TR', { maximumFractionDigits: d }));
const dt = (iso?: string) => (iso ? new Date(iso).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—');
const VTXT: Record<string, [string, string]> = { PASS: ['Uygun', 'border-emerald-200 bg-emerald-50 text-emerald-800'], CONDITIONAL: ['Dikkat', 'border-amber-200 bg-amber-50 text-amber-800'], FAIL: ['Uygun değil', 'border-rose-200 bg-rose-50 text-rose-800'] };

export default function TestDetailSheet({ r, sameVariety, arch, harvests, onClose, onEdit }: {
  r: FieldRecord; sameVariety: FieldRecord[]; arch: ArchiveTest[]; harvests: HarvestRecord[]; onClose: () => void; onEdit?: () => void;
}) {
  const v = r.qualityStandardVerdict ? VTXT[r.qualityStandardVerdict] : undefined;
  const archH = arch.filter(t => /^ýygym-?\d/i.test(t.type.replace(/\s/g, '')));
  const w26 = (archH.length ? archH : arch).map(t => t.w).filter((x): x is number => !!x);
  const avgW26 = w26.length ? w26.reduce((a, b) => a + b, 0) / w26.length : undefined;
  const kg27 = harvests.reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0);
  const cell = (l: string, val: string, sub?: string) => <div className="rounded-xl border border-slate-200 dark:border-slate-700 px-2.5 py-2"><div className="text-[10px] text-slate-500">{l}</div><div className="text-base font-bold tabular-nums">{val}</div>{sub && <div className="text-[10px] text-slate-500">{sub}</div>}</div>;
  const sp = (r as any).specialCropTest as { cropNameTr?: string; metric1Name?: string; metric1Value?: number; metric1Unit?: string; metric2Name?: string; metric2Value?: number; metric2Unit?: string; interpretation?: string } | undefined;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/40" onClick={onClose}>
      <div className="w-full max-w-xl max-h-[88vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white dark:bg-slate-900 p-4 space-y-3" onClick={e => e.stopPropagation()} style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0"><div className="text-base font-bold">{r.sortVariety || r.product} · {r.testType?.split(' (')[0]}</div>
            <div className="text-[11px] text-slate-500">{dt(r.timestamp)} · {r.orchard}{r.location ? ` · ${r.location}` : ''} · {r.operator}</div>
            <div className="text-[11px] font-mono text-slate-500">{r.refId}</div></div>
          <button type="button" onClick={onClose} aria-label="Kapat" className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 cursor-pointer"><X className="w-4 h-4" /></button>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {v && <span className={`text-[11px] px-2 py-0.5 rounded-full border ${v[1]}`}>{v[0]}{r.qualityStandardOrg ? ` · ${r.qualityStandardOrg}` : ''}</span>}
          {r.decision && <span className="text-[11px] px-2 py-0.5 rounded-full border border-slate-200 text-slate-700">{r.decision}</span>}
          <span className="text-[11px] px-2 py-0.5 rounded-full border border-slate-200 text-slate-600">{r.sampleCount || r.samples?.length || 0} numune</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {cell('Sertlik', f1(r.avgHardness), 'kg/cm²')}
          {cell('Brix', f1(r.avgBrix), '°Bx')}
          {cell('Çap', f1(r.avgDiameter, 0), 'mm')}
          {cell('Ağırlık', f1(r.avgFruitWeightG, 0), avgW26 ? `2026 ort. ${f1(avgW26, 0)} g` : 'g')}
          {r.starchIndex ? cell('Nişasta', f1(r.starchIndex), '1–10') : null}
          {r.streifIndex ? cell('Streif', f1(r.streifIndex, 3)) : null}
          {r.nitrateMgKg !== undefined ? cell('Nitrat', f1(r.nitrateMgKg, 0), `sınır ${f1(r.nitrateLimitMgKg, 0)}`) : null}
          {r.defectPercent !== undefined ? cell('Kusur', `%${f1(r.defectPercent)}`) : null}
          {r.hueAngle !== undefined ? cell('Renk (hue)', f1(r.hueAngle, 0), '°') : null}
        </div>
        {sp && sp.metric1Value !== undefined && (
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs"><b>{sp.cropNameTr}</b> · {sp.metric1Name}: {sp.metric1Value} {sp.metric1Unit}{sp.metric2Value !== undefined ? ` · ${sp.metric2Name}: ${sp.metric2Value} ${sp.metric2Unit || ''}` : ''}<div className="text-slate-600 mt-0.5">{sp.interpretation}</div></div>
        )}
        {r.streifInterpretation && <p className="text-[11px] text-slate-600">{r.streifInterpretation}</p>}
        {r.samples?.length > 1 && (
          <details className="rounded-xl border border-slate-200 dark:border-slate-700 px-3 py-2">
            <summary className="text-xs font-semibold cursor-pointer">Meyve meyve ({r.samples.length})</summary>
            <div className="grid grid-cols-[28px_repeat(4,minmax(0,1fr))] gap-1 text-[10px] text-slate-500 font-semibold mt-1"><span>#</span><span>Sertlik</span><span>Brix</span><span>Çap</span><span>g</span></div>
            {r.samples.map(s => <div key={s.sample} className="grid grid-cols-[28px_repeat(4,minmax(0,1fr))] gap-1 text-xs tabular-nums"><span>{s.sample}</span><span>{f1(s.hardness)}</span><span>{f1(s.brix)}</span><span>{f1(s.diameterMm, 0)}</span><span>{f1(s.weightG, 0)}</span></div>)}
          </details>
        )}
        {r.notes && <p className="text-xs text-slate-700 dark:text-slate-300 rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2">{r.notes}</p>}
        {r.photos?.length ? <div className="flex gap-1.5 overflow-x-auto">{r.photos.map((p, i) => <img key={i} src={typeof p === 'string' ? p : (p as any).url || (p as any).dataUrl} alt="" className="w-20 h-20 rounded-lg object-cover shrink-0" />)}</div> : null}
        <div className="rounded-xl border border-slate-200 dark:border-slate-700 px-3 py-2">
          <div className="text-xs font-bold mb-1">Bu çeşidin geçmişi</div>
          <div className="grid grid-cols-4 gap-1.5 text-center">
            {[['2026 test', String(arch.length)], ['2026 hasat testi', String(archH.length)], ['2027 test', String(sameVariety.length)], ['2027 hasat', harvests.length ? `${harvests.length} · ${f1(kg27 / 1000)} t` : '0']].map(([l, x]) => (
              <div key={l}><div className="text-sm font-bold tabular-nums">{x}</div><div className="text-[9px] text-slate-500 leading-tight">{l}</div></div>))}
          </div>
          {sameVariety.length > 1 && <div className="mt-1.5 space-y-0.5">{sameVariety.slice(0, 6).map(x => (
            <div key={x.id} className={`flex justify-between text-[11px] tabular-nums ${x.id === r.id ? 'font-bold' : 'text-slate-600'}`}><span>{dt(x.timestamp)} · {x.testType?.split(' (')[0]}</span><span>{f1(x.avgHardness)} · {f1(x.avgBrix)} · {f1(x.avgFruitWeightG, 0)} g</span></div>))}</div>}
        </div>
        {onEdit && <button type="button" onClick={onEdit} className="w-full min-h-[42px] rounded-xl border border-slate-300 text-sm font-semibold cursor-pointer">Ayrıntılı formda aç (düzenle)</button>}
      </div>
    </div>
  );
}
