import React, { useEffect, useMemo, useState } from 'react';
import { ChevronDown, TreeDeciduous, AlertTriangle, Flower2, Check, FlaskConical, Plus, RefreshCw, CalendarRange, MapPin, Scissors } from 'lucide-react';
import type { FieldRecord, HarvestRecord, IncidentRecord } from '../../types';
import { ORCHARD_CARDS, ORCHARD_SOURCES, type VarietyRow, type ParcelRow } from '../../config/orchardCards';
import { CAL_SEED_ROWS } from '../../config/harvestCalendarSeed';
import { UNIT_PLANS, UNIT_PLAN_SOURCE } from '../../config/unitPlans';
import { FIELD_UNIT } from '../../config/fieldCrops';
import { EXTERNAL_VISITS, EXTERNAL_SOURCE } from '../../config/externalOrchards';
import { actual2026, vkey, matchCardVariety } from '../../services/orchardOverview';
import { archiveTestsFor } from '../../services/archive2026';
import type { ArchiveTest } from '../../config/archive2026';
import { buildCalendar, useCalOverrides, saveCalOverride, expectedBbch, bbchVerdict, BBCH_LABEL, type CalItem, type BbchStage } from '../../services/harvestCalendar';
import { canonicalOrchard, findProfile, upsertProfile, useLocationProfiles } from '../../services/locationProfiles';
import { thinWindow } from '../../services/orchardTasks';
import MuzPanel from './MuzPanel';
import FieldPanel from './FieldPanel';
import SeraClimate, { SeraInfo } from './SeraClimate';
import { OrchardClimateCard } from './ClimateView';
import TreesPanel from './TreesPanel';
import CherryOpsPanel from './CherryOpsPanel';
import TestDetailSheet from './TestDetailSheet';
import { useTreeDocs, treeRows } from '../../services/treeLedger';
import { useElevations, HOPKINS_DAYS_PER_M } from '../../services/agroClimate';

/**
 * v49c7 — Bahçe profili (tüm bahçeler).
 *  Hasat pencereleri 2026 · 2027 (tek zaman çizgisi) · BBCH adımları (2026 · 2027 beklenen · 2027 gözlenen) ·
 *  hasat rasatları (saha testleri) · tonaj (2026 gerçekleşen · 2027 plan) · parseller · profile işleme.
 *  Veri kaynakları ayrı tutulur: parseller/ağaç = bütçe Excel'i; 2026 = hasat fişleri (yoksa Gantt); 2027 plan = tonaj Excel'i;
 *  BBCH/çiçeklenme = hasat takvimi kaydı (girilen). Hiçbiri birbirinin yerine yazılmaz.
 */
const DAY = 86400000;
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const n0 = (v: number) => Math.round(v).toLocaleString('tr-TR');
const dm = (s?: string | null) => (s ? s.slice(5, 10).split('-').reverse().join('.') : '');
const dmT = (t?: number) => (t ? new Date(t).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }) : '—');
const MON = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
const GRADE_CLS: Record<string, string> = { Extra: '#0f766e', Exclusive: '#14b8a6', Premium: '#5eead4', Classic: '#a7f3d0', Mix: '#cbd5e1', Ballyk: '#94a3b8', 'Off-grade': '#64748b' };
const FRUIT_ORDER = ['Kiraz', 'Erik', 'Şeftali', 'Nektarin', 'Elma', 'Armut', 'Nashi', 'Hurma', 'Badem'];
const FRUIT_NORM = (f: string) => /alma|elma/i.test(f) ? 'Elma' : /şet|seft|şeft/i.test(f) ? 'Şeftali' : /çer|cer|kiraz/i.test(f) ? 'Kiraz' : f;
/** gün-of-year → 2027 eksenine (yıl farkı atılır) */
const doy = (t: number) => { const d = new Date(t); return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / DAY); };

interface VarietyModel {
  key: string; fruit: string; name: string;
  card?: VarietyRow; seedVariety?: string; seedVarieties: string[];
  it26?: CalItem; it27?: CalItem;
  a26: ReturnType<typeof actual2026>;
  plan27: number;
}

function buildModels(orchard: string, items26: CalItem[], items27: CalItem[]): VarietyModel[] {
  const card = ORCHARD_CARDS[orchard];
  const map = new Map<string, VarietyModel>();
  const add = (key: string, fruit: string, name: string) => { if (!map.has(key)) map.set(key, { key, fruit: FRUIT_NORM(fruit), name, seedVarieties: [], a26: { kg: 0, src: null }, plan27: 0 }); return map.get(key)!; };
  const keyOf = (v: string) => (card ? matchCardVariety(orchard, v) : null) || vkey(v);
  /** aynı çeşidin birden çok takvim satırı (firmalara bölünmüş) tek pencereye birleşir: en erken başlangıç – en geç bitiş */
  const merge = (a: CalItem | undefined, b: CalItem): CalItem => {
    if (!a) return b;
    const mn = (x?: number, y?: number) => (x && y ? Math.min(x, y) : x || y), mx = (x?: number, y?: number) => (x && y ? Math.max(x, y) : x || y);
    return { ...a, windowStart: mn(a.windowStart, b.windowStart), windowEnd: mx(a.windowEnd, b.windowEnd), start: mn(a.start, b.start), end: mx(a.end, b.end), ov: a.ov || b.ov };
  };
  for (const v of card?.varieties || []) { const m = add(vkey(v.cesit), v.tur, v.cesit); m.card = v; m.plan27 = v.plan2027Kg; }
  for (const it of items27.filter(i => i.orchard === orchard)) {
    const k = keyOf(it.variety);
    const m = map.get(k) || add(k, it.fruit, it.variety.split('(')[0].trim());
    m.it27 = merge(m.it27, it); m.seedVariety = m.seedVariety || it.variety;
    if (!m.seedVarieties.includes(it.variety)) m.seedVarieties.push(it.variety);
    if (!card) m.plan27 += (it.targetTon || 0) * 1000;
  }
  for (const it of items26.filter(i => i.orchard === orchard)) { const m = map.get(keyOf(it.variety)); if (m) m.it26 = merge(m.it26, it); }
  for (const m of map.values()) m.a26 = actual2026(orchard, m.card ? m.card.cesit : (m.seedVariety || m.name));
  // ne 2026 hasadı ne 2027 planı olan satırlar (ör. Gantt'ta başlanmamış not satırı) gösterilmez
  return [...map.values()].filter(m => m.a26.kg > 0 || m.plan27 > 0).sort((a, b) => (FRUIT_ORDER.indexOf(a.fruit) - FRUIT_ORDER.indexOf(b.fruit)) || ((a.it27?.windowStart || 9e15) - (b.it27?.windowStart || 9e15)));
}

function Delta({ a, b }: { a: number; b: number }) {
  if (!a && !b) return null;
  if (!a) return <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">2026 yok</span>;
  if (!b) return <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">plan yok</span>;
  const p = Math.round(((b - a) / a) * 100);
  return <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border tabular-nums ${p >= 0 ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'}`}>{p >= 0 ? '+' : ''}{p}%</span>;
}

function GradeBar({ g }: { g: Record<string, number> }) {
  const tot = Object.values(g).reduce((s, v) => s + v, 0);
  if (!tot) return null;
  return (
    <div>
      <div className="flex h-2.5 rounded-full overflow-hidden">{Object.entries(g).map(([k, v]) => <div key={k} style={{ width: `${(v / tot) * 100}%`, background: GRADE_CLS[k] || '#94a3b8' }} />)}</div>
      <div className="flex flex-wrap gap-x-2.5 gap-y-0.5 mt-1">{Object.entries(g).map(([k, v]) => (
        <span key={k} className="text-[10px] text-slate-600 dark:text-slate-400 flex items-center gap-1"><span className="w-2 h-2 rounded-sm inline-block" style={{ background: GRADE_CLS[k] || '#94a3b8' }} />{k} %{Math.round((v / tot) * 100)}</span>))}</div>
    </div>
  );
}

/** Tek satırlık zaman çizgisi: gri = 2026 gerçek hasat, çerçeveli yeşil = 2027 tahmini pencere, pembe nokta = 2027 çiçeklenme */
function Track({ m, axis }: { m: VarietyModel; axis: { a: number; b: number } }) {
  const x = (t?: number) => (t === undefined ? undefined : Math.max(0, Math.min(100, ((doy(t) - axis.a) / (axis.b - axis.a)) * 100)));
  const s26 = x(m.it26?.start), e26 = x(m.it26?.end ?? m.it26?.start);
  const w26s = x(m.it26?.windowStart), w26e = x(m.it26?.windowEnd);
  const s27 = x(m.it27?.windowStart), e27 = x(m.it27?.windowEnd);
  const b27 = m.it27?.ov?.bbch?.['65'] ? x(Date.parse(`${m.it27.ov.bbch['65']}T00:00:00`)) : undefined;
  return (
    <div className="relative h-5 mt-1" aria-hidden>
      <div className="absolute inset-x-0 top-1/2 h-px bg-slate-200 dark:bg-slate-700" />
      {w26s !== undefined && w26e !== undefined && <div className="absolute top-0.5 h-1 rounded-full bg-slate-300 dark:bg-slate-600" style={{ left: `${w26s}%`, width: `${Math.max(1, w26e - w26s)}%` }} title="2026 penceresi" />}
      {s26 !== undefined && e26 !== undefined && <div className="absolute top-[7px] h-1.5 rounded-full bg-slate-600 dark:bg-slate-300" style={{ left: `${s26}%`, width: `${Math.max(1.2, e26 - s26)}%` }} title="2026 gerçek hasat" />}
      {s27 !== undefined && e27 !== undefined && <div className="absolute bottom-0 h-1.5 rounded-full border border-teal-600 bg-teal-100 dark:bg-teal-900" style={{ left: `${s27}%`, width: `${Math.max(1.2, e27 - s27)}%` }} title="2027 tahmini pencere" />}
      {b27 !== undefined && <div className="absolute top-1/2 -mt-1 w-2 h-2 rounded-full bg-pink-500" style={{ left: `${b27}%` }} title="2027 çiçeklenme" />}
    </div>
  );
}

function BbchTable({ m, orchard, by, readOnly }: { m: VarietyModel; orchard: string; by: string; readOnly: boolean }) {
  const it = m.it27;
  const [vals, setVals] = useState<Partial<Record<BbchStage, string>>>(it?.ov?.bbch || {});
  const [state, setState] = useState<'idle' | 'ok' | 'err'>('idle');
  const stored = JSON.stringify(it?.ov?.bbch || {});
  useEffect(() => { setVals(JSON.parse(stored)); }, [stored]);
  if (!it || !m.seedVariety) return <p className="text-[11px] text-slate-500">Bu çeşit hasat takviminde yok — BBCH ve hasat penceresi izlenemiyor.</p>;
  const dirty = JSON.stringify(vals) !== stored;
  const save = async () => { const clean = Object.fromEntries(Object.entries(vals).filter(([, v]) => v)); let ok = true; for (const sv of m.seedVarieties) ok = (await saveCalOverride(2027, orchard, sv, { bbch: clean }, by)) && ok; setState(ok ? 'ok' : 'err'); };
  const seed = it.seed as any;
  return (
    <div>
      <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1"><Flower2 className="w-3.5 h-3.5" />BBCH adımları</div>
      <div className="grid grid-cols-[minmax(0,1fr)_44px_44px_116px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Aşama</span><span className="text-right">2026</span><span className="text-right">2027 bek.</span><span className="text-right">2027 gözlenen</span></div>
      {(['65', '71', '81', '85'] as BbchStage[]).map(st => {
        const exp = expectedBbch(it, st);
        const v = bbchVerdict(vals[st], exp);
        return (
          <div key={st} className="grid grid-cols-[minmax(0,1fr)_44px_44px_116px] gap-1 items-center text-xs py-1 border-b border-slate-100 dark:border-slate-700 last:border-0">
            <span className="min-w-0"><span className="block font-semibold">BBCH {st}</span><span className="block text-[10px] text-slate-500 leading-tight">{BBCH_LABEL[st]}{v ? <b className={`ml-1 ${v.tone === 'ok' ? 'text-emerald-700' : v.tone === 'late' ? 'text-amber-700' : 'text-sky-700'}`}>· {v.label}</b> : null}</span></span>
            <span className="text-right tabular-nums">{dm(seed[`bbch${st}`]) || '—'}</span>
            <span className="text-right tabular-nums text-slate-500">{exp ? dmT(exp) : '—'}</span>
            {readOnly ? <span className="text-right tabular-nums">{dm(vals[st]) || '—'}</span> : (
              <input type="date" aria-label={`2027 BBCH ${st}`} value={vals[st] || ''} min="2027-01-15" max="2027-12-15" onChange={e => { setVals({ ...vals, [st]: e.target.value }); setState('idle'); }}
                className="min-h-[36px] w-full rounded-lg border border-slate-300 px-1 text-xs bg-white dark:bg-slate-900" />)}
          </div>
        );
      })}
      {!readOnly && (
        <div className="flex items-center justify-end gap-2 mt-1.5">
          {state === 'err' && <span className="text-[11px] text-amber-800">Telefonda kaydedildi, internet gelince gönderilecek.</span>}
          {state === 'ok' && !dirty && <span className="text-[11px] text-emerald-700 flex items-center gap-1"><Check className="w-3.5 h-3.5" />Kaydedildi · hasat takvimi güncellendi</span>}
          <button type="button" disabled={!dirty} onClick={save} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
        </div>
      )}
    </div>
  );
}

/** v49c10: seyreltme (2026 tarihleri → 2027) ve meyve sayımı → tonaj rasadı */
function ThinAndCount({ m, orchard, trees, by, readOnly }: { m: VarietyModel; orchard: string; trees: number; by: string; readOnly: boolean }) {
  const it = m.it27;
  const fc = it?.ov?.fruitCount;
  const [thin, setThin] = useState(it?.ov?.thinDoneAt || '');
  const [thinS, setThinS] = useState(it?.ov?.thinStartAt || '');
  const [cnt, setCnt] = useState({ date: fc?.date || new Date().toISOString().slice(0, 10), trees: String(fc?.trees || trees || ''), fruits: String(fc?.fruitsPerTree || ''), g: String(fc?.weightG || '') });
  const [msg, setMsg] = useState('');
  if (!it || !m.seedVarieties.length) return null;
  const seed = it.seed;
  const tw = thinWindow(it);
  const T = Date.now();
  const thinState = it.ov?.thinDoneAt ? `bitti ${dm(it.ov.thinDoneAt)}` : !tw ? '' : T > tw.to ? 'pencere geçti!' : T >= tw.from ? (it.ov?.thinStartAt ? `başladı ${dm(it.ov.thinStartAt)}` : 'şimdi') : `${Math.ceil((tw.from - T) / DAY)} gün kaldı`;
  const thinTone = it.ov?.thinDoneAt ? 'border-emerald-200 bg-emerald-50 text-emerald-900' : tw && T > tw.to ? 'border-rose-200 bg-rose-50 text-rose-900' : tw && T >= tw.from - 5 * DAY ? 'border-amber-200 bg-amber-50 text-amber-900' : 'border-slate-200 bg-white text-slate-800 dark:bg-slate-900 dark:text-slate-200';
  const nTrees = Number(cnt.trees.replace(',', '.')) || 0, nF = Number(cnt.fruits.replace(',', '.')) || 0, nG = Number(cnt.g.replace(',', '.')) || 0;
  const est = nTrees * nF * nG / 1000;
  const saveAll = async (patch: Record<string, unknown>) => { let ok = true; for (const sv of m.seedVarieties) ok = (await saveCalOverride(2027, orchard, sv, patch as any, by)) && ok; setMsg(ok ? 'Kaydedildi' : 'Telefonda kaydedildi, internet gelince gönderilecek'); };
  const inp = 'min-h-[36px] w-full rounded-lg border border-slate-300 px-2 text-xs bg-white dark:bg-slate-900';
  return (
    <div className="space-y-2">
      <div>
        <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1"><Scissors className="w-3.5 h-3.5" />Seyreltme · meyve ceviz büyüklüğünde</div>
        {tw ? (
          <div className={`rounded-lg border px-2.5 py-1.5 text-xs ${thinTone}`}>
            <div className="flex items-baseline justify-between gap-2"><b className="tabular-nums">2027 pencere {dmT(tw.from)}–{dmT(tw.to)}</b><span className="text-[10px] shrink-0">{thinState}</span></div>
            <div className="text-[10px] opacity-80">{tw.basis} · 2026: {dm(seed.thinStart)}–{dm(seed.thinEnd || seed.thinStart)}</div>
          </div>
        ) : <p className="text-[11px] text-slate-500">2026 seyreltme tarihi yok — yapıldığında aşağıya girin, 2028 için örnek olur.</p>}
        {readOnly ? <p className="text-xs mt-1">{it.ov?.thinStartAt ? `Başladı ${dm(it.ov.thinStartAt)}` : ''}{it.ov?.thinDoneAt ? ` · bitti ${dm(it.ov.thinDoneAt)}` : ''}</p> : (
          <div className="grid grid-cols-[1fr_1fr_auto] gap-1.5 mt-1.5 items-end">
            <label className="text-[10px] text-slate-500">Başladı<input type="date" aria-label="2027 seyreltme başladı" value={thinS} onChange={e => setThinS(e.target.value)} className={inp} /></label>
            <label className="text-[10px] text-slate-500">Bitti<input type="date" aria-label="2027 seyreltme bitti" value={thin} onChange={e => setThin(e.target.value)} className={inp} /></label>
            <button type="button" disabled={(!thin && !thinS) || (thin === (it.ov?.thinDoneAt || '') && thinS === (it.ov?.thinStartAt || ''))} onClick={() => saveAll({ thinStartAt: thinS || undefined, thinDoneAt: thin || undefined })} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          </div>
        )}
      </div>
      <div>
        <div className="text-[11px] font-semibold text-slate-500 mb-1">Meyve sayımı → tonaj rasadı</div>
        {readOnly ? <p className="text-xs">{fc ? `${dm(fc.date)} · ${n0(fc.trees)} ağaç × ${fc.fruitsPerTree} meyve × ${fc.weightG} g ≈ ${t1(fc.estKg)} t` : 'girilmedi'}</p> : (
          <>
            <div className="grid grid-cols-4 gap-1.5">
              <label className="text-[10px] text-slate-500">Tarih<input type="date" value={cnt.date} onChange={e => setCnt({ ...cnt, date: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Ağaç<input inputMode="numeric" value={cnt.trees} onChange={e => setCnt({ ...cnt, trees: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Meyve/ağaç<input inputMode="decimal" placeholder="örnek ort." value={cnt.fruits} onChange={e => setCnt({ ...cnt, fruits: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Hasatta g<input inputMode="decimal" placeholder="meyve ağ." value={cnt.g} onChange={e => setCnt({ ...cnt, g: e.target.value })} className={inp} /></label>
            </div>
            <div className="flex items-center justify-between gap-2 mt-1.5 text-xs">
              <span>Tahmin: <b className="tabular-nums">{est ? `${t1(est)} t` : '—'}</b>{est && m.plan27 ? <span className="text-slate-500"> · plan {t1(m.plan27)} t · {est >= m.plan27 ? '+' : ''}{Math.round(((est - m.plan27) / m.plan27) * 100)}%</span> : null}</span>
              <button type="button" disabled={!est} onClick={() => saveAll({ fruitCount: { date: cnt.date, trees: nTrees, fruitsPerTree: nF, weightG: nG, estKg: Math.round(est) } })} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
            </div>
          </>
        )}
        {msg && <p className="text-[11px] text-emerald-700 mt-1">{msg}</p>}
      </div>
    </div>
  );
}

function Rasatlar({ m, orchard, fieldRecords, harvestRecords = [], onStartTest, onEditTest, readOnly }: { m: VarietyModel; orchard: string; fieldRecords: FieldRecord[]; harvestRecords?: HarvestRecord[]; onStartTest?: (c: { orchard: string; product: string; variety: string }) => void; onEditTest?: (r: FieldRecord) => void; readOnly: boolean }) {
  const allRows = fieldRecords
    .filter(r => canonicalOrchard(r.orchard) === orchard && (vkey(r.sortVariety) === m.key || matchCardVariety(orchard, r.sortVariety) === m.key))
    .sort((a, b) => String(b.timestamp).localeCompare(String(a.timestamp)));
  const rows = allRows.slice(0, 6);
  const [openT, setOpenT] = useState<FieldRecord | null>(null);
  const harv = harvestRecords.filter(h => canonicalOrchard(h.orchard) === orchard && (vkey(h.variety) === m.key || matchCardVariety(orchard, h.variety || '') === m.key));
  const arch = archiveTestsFor(orchard, m.key);
  const [showArch, setShowArch] = useState(false);
  const almond = m.fruit === 'Badem' || arch.some(t => t.rh !== undefined || t.hull !== undefined);
  const firstT = arch.filter(t => !/^ýygym-?\d/i.test(t.type.replace(/\s/g, ''))).map(t => t.d).sort()[0];
  const h26 = m.it26?.start;
  const lead = firstT && h26 ? Math.round((h26 - Date.parse(`${firstT}T00:00:00`)) / 86400000) : undefined;
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1"><FlaskConical className="w-3.5 h-3.5" />Hasat rasatları (saha testleri)</span>
        {onStartTest && !readOnly && <button type="button" onClick={() => onStartTest({ orchard, product: m.fruit, variety: m.seedVariety || m.name })} className="text-[11px] font-semibold text-teal-700 flex items-center gap-0.5 cursor-pointer"><Plus className="w-3.5 h-3.5" />Rasat ekle</button>}
      </div>
      {rows.length === 0 ? <p className="text-[11px] text-slate-500">Bu çeşit için saha testi yok.</p> : (
        <>
          <p className="text-[10px] text-slate-400 mb-0.5">Teste dokunun: bütün bilgisi ve geçmişi.</p>
          <div className="grid grid-cols-[52px_minmax(0,1fr)_44px_40px_40px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Tarih</span><span>Test</span><span className="text-right">Sertlik</span><span className="text-right">Brix</span><span className="text-right">Nişasta</span><span className="text-right">Çap</span></div>
          {rows.map(r => (
            <div key={r.id} role="button" tabIndex={0} onClick={() => setOpenT(r)} className="grid grid-cols-[52px_minmax(0,1fr)_44px_40px_40px_40px] gap-1 text-xs tabular-nums py-1 rounded hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
              <span>{new Date(r.timestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit' })}</span><span className="truncate">{r.testType}</span>
              <span className="text-right">{r.avgHardness ? r.avgHardness.toFixed(1) : '—'}</span><span className="text-right">{r.avgBrix ? r.avgBrix.toFixed(1) : '—'}</span>
              <span className="text-right">{r.starchIndex ? r.starchIndex.toFixed(1) : '—'}</span><span className="text-right">{r.avgDiameter ? Math.round(r.avgDiameter) : '—'}</span>
            </div>))}
        </>
      )}
      {arch.length > 0 && (
        <div className="mt-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2">
          <button type="button" onClick={() => setShowArch(v => !v)} className="w-full flex items-center justify-between text-left cursor-pointer">
            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">2026 arşivi · {arch.length} test{lead !== undefined ? ` · ilk test hasattan ${Math.abs(lead)} gün ${lead >= 0 ? 'önce' : 'sonra'}` : ''}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 ${showArch ? 'rotate-180' : ''}`} />
          </button>
          {showArch && <ArchiveStages arch={arch} almond={almond} />}
        </div>
      )}
      {openT && <TestDetailSheet r={openT} sameVariety={allRows} arch={arch} harvests={harv} onClose={() => setOpenT(null)} onEdit={onEditTest && !readOnly ? () => { const x = openT; setOpenT(null); onEditTest(x); } : undefined} />}
    </div>
  );
}

/** v49c12: dikimler kısa liste — firma · dikim yılı · anaç grupları; istenirse tüm parseller */
/** v52 — Testler sekmesi: çeşit başına açılır satır (son testler + 2026 arşivi) */
function TestGroup({ m, orchard, fieldRecords, harvestRecords = [], onStartTest, onEditTest, readOnly }: { m: VarietyModel; orchard: string; fieldRecords: FieldRecord[]; harvestRecords?: HarvestRecord[]; onStartTest?: (c: { orchard: string; product: string; variety: string }) => void; onEditTest?: (r: FieldRecord) => void; readOnly: boolean }) {
  const [open, setOpen] = useState(false);
  const n = fieldRecords.filter(r => canonicalOrchard(r.orchard) === orchard && (vkey(r.sortVariety) === m.key || matchCardVariety(orchard, r.sortVariety) === m.key)).length;
  const a = archiveTestsFor(orchard, m.key).length;
  return (
    <div className="py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0">
      <button type="button" onClick={() => setOpen(o => !o)} className="w-full flex items-center justify-between text-left cursor-pointer">
        <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">{m.name}</span>
        <span className="flex items-center gap-1.5 text-[11px] text-slate-500 shrink-0">{n ? <b className="text-teal-800 dark:text-teal-300">{n} test</b> : 'test yok'}{a ? ` · arşiv ${a}` : ''}<ChevronDown className={`w-4 h-4 text-slate-400 ${open ? 'rotate-180' : ''}`} /></span>
      </button>
      {open && <div className="mt-1.5"><Rasatlar m={m} orchard={orchard} fieldRecords={fieldRecords} harvestRecords={harvestRecords} onStartTest={onStartTest} onEditTest={onEditTest} readOnly={readOnly} /></div>}
    </div>
  );
}

function ParcelSummary({ ps }: { ps: ParcelRow[] }) {
  const [all, setAll] = useState(false);
  const groups = useMemo(() => {
    const m = new Map<string, { firma: string; yil: string; anac: string; n: number; agac: number; ha: number; kg: number }>();
    for (const p of ps) {
      const k = `${p.firma || ''}|${p.yil}|${p.anac || ''}`;
      const g = m.get(k) || { firma: p.firma || '', yil: String(p.yil ?? '—'), anac: p.anac || '', n: 0, agac: 0, ha: 0, kg: 0 };
      g.n++; g.agac += p.agac; g.ha += p.ha; g.kg += p.planKg || 0; m.set(k, g);
    }
    return [...m.values()].sort((a, b) => a.firma.localeCompare(b.firma) || a.yil.localeCompare(b.yil));
  }, [ps]);
  const trees = ps.reduce((s, p) => s + p.agac, 0), ha = ps.reduce((s, p) => s + p.ha, 0);
  const hasF = groups.some(g => g.firma);
  const hasL = groups.some(g => g.firma || g.anac);
  const cols = hasL ? 'grid-cols-[minmax(0,1fr)_40px_40px_60px_44px]' : 'grid-cols-[minmax(0,1fr)_48px_72px_56px]';
  return (
    <div>
      <div className="text-[11px] font-semibold text-slate-500 mb-1">Dikimler · {n0(trees)} ağaç · {ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha · {ps.length} parsel</div>
      <div className={`grid ${cols} gap-1 text-[10px] text-slate-500 font-semibold`}>{hasL && <span>{hasF ? 'Firma · anaç' : 'Anaç'}</span>}<span className={hasL ? 'text-right' : ''}>Dikim</span><span className="text-right">Parsel</span><span className="text-right">Ağaç</span><span className="text-right">ha</span></div>
      {groups.map((g, i) => (
        <div key={i} className={`grid ${cols} gap-1 text-xs tabular-nums py-0.5`}>
          {hasL && <span className="break-words">{[g.firma, g.anac].filter(Boolean).join(' · ') || '—'}</span>}<span className={hasL ? 'text-right' : ''}>{g.yil}</span><span className="text-right">{g.n}</span><span className="text-right">{n0(g.agac)}</span><span className="text-right">{g.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}</span>
        </div>))}
      {ps.length > groups.length && (
        <>
          <button type="button" onClick={() => setAll(v => !v)} className="text-[11px] font-semibold text-teal-700 mt-1 cursor-pointer">{all ? 'Kısa liste' : `Tüm parseller (${ps.length})`}</button>
          {all && <div className="mt-1 max-h-64 overflow-y-auto">{ps.map((p, i) => (
            <div key={i} className="grid grid-cols-[minmax(0,1fr)_40px_60px_44px_44px] gap-1 text-[11px] tabular-nums py-0.5">
              <span className="truncate">{[p.parsel, p.anac].filter(Boolean).join(' · ') || '—'}</span><span className="text-right">{p.yil}</span><span className="text-right">{n0(p.agac)}</span><span className="text-right">{p.ha.toLocaleString('tr-TR', { maximumFractionDigits: 2 })}</span><span className="text-right">{p.kgAgac || '—'}</span>
            </div>))}</div>}
        </>
      )}
    </div>
  );
}

/** v49c13: 2026 testleri kısa liste — aşama adı tam, sayılar altında; dokununca testler; olgunlaşma hızı (günlük değişim) */
function ArchiveStages({ arch, almond }: { arch: ArchiveTest[]; almond: boolean }) {
  const [open, setOpen] = useState<string | null>(null);
  const norm = (t: string) => t.replace(/\s+/g, ' ').replace(/\s*-\s*/g, ' - ').trim();
  const val = (t: ArchiveTest) => (almond ? t.hull : t.hard), val2 = (t: ArchiveTest) => (almond ? t.rh : t.brix);
  const stages = useMemo(() => {
    const m = new Map<string, ArchiveTest[]>();
    for (const t of arch) m.set(norm(t.type), [...(m.get(norm(t.type)) || []), t]);
    const avg = (xs: (number | undefined)[]) => { const v = xs.filter((x): x is number => typeof x === 'number' && x > 0); return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : undefined; };
    return [...m.entries()].map(([type, ts]) => ({ type, ts, n: ts.reduce((s, t) => s + t.n, 0), from: ts[0].d, to: ts[ts.length - 1].d,
      a: avg(ts.map(val)), b: avg(ts.map(val2)) })).sort((x, y) => x.from.localeCompare(y.from));
  }, [arch, almond]);
  /** günlük değişim: ilk ve son test tarihi arasında (en az 2 gün arayla, değer olan testler) */
  const rate = useMemo(() => {
    const f = (g: (t: ArchiveTest) => number | undefined) => {
      const xs = arch.filter(t => typeof g(t) === 'number' && g(t)! > 0).sort((a, b) => a.d.localeCompare(b.d));
      if (xs.length < 2) return undefined;
      const d = (Date.parse(xs[xs.length - 1].d) - Date.parse(xs[0].d)) / 86400000;
      return d >= 2 ? { per: (g(xs[xs.length - 1])! - g(xs[0])!) / d, days: Math.round(d) } : undefined;
    };
    return { a: f(val), b: f(val2) };
  }, [arch, almond]);
  const d = (s: string) => `${s.slice(8, 10)}.${s.slice(5, 7)}`;
  const la = almond ? 'Kabuk' : 'Sertlik', lb = almond ? 'Nem' : 'Brix';
  const sg = (x: number) => `${x >= 0 ? '+' : '−'}${Math.abs(x).toLocaleString('tr-TR', { maximumFractionDigits: 2 })}`;
  return (
    <div className="mt-1.5 divide-y divide-slate-100 dark:divide-slate-800">
      {stages.map(st => (
        <div key={st.type} className="py-1.5">
          <button type="button" onClick={() => setOpen(open === st.type ? null : st.type)} className="w-full text-left cursor-pointer">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 break-words">{st.type}</span>
              <span className="text-[11px] tabular-nums text-slate-500 shrink-0">{st.ts.length} test · {st.n} meyve <ChevronDown className={`w-3 h-3 inline ${open === st.type ? 'rotate-180' : ''}`} /></span>
            </div>
            <div className="text-[11px] tabular-nums text-slate-600 dark:text-slate-400">{d(st.from)}{st.to !== st.from ? `–${d(st.to)}` : ''} · {la} <b>{st.a ?? '—'}</b>{almond ? '%' : ''} · {lb} <b>{st.b ?? '—'}</b>{almond ? '%' : ''}</div>
          </button>
          {open === st.type && (
            <ul className="mt-1 ml-2 space-y-0.5">{st.ts.map((t, i) => (
              <li key={i} className="text-[11px] tabular-nums text-slate-600 dark:text-slate-400">
                <span className="text-slate-800 dark:text-slate-200">{d(t.d)}</span> · {t.by}{t.parcel ? ` · parsel ${t.parcel}` : ''} · {t.n} meyve · {la} {val(t) ?? '—'} · {lb} {val2(t) ?? '—'}{t.dia ? ` · çap ${Math.round(t.dia)}` : ''}{t.note ? ` · ${t.note}` : ''}
              </li>))}</ul>
          )}
        </div>))}
      <div className="py-1.5 text-xs font-bold flex justify-between"><span>Toplam</span><span className="tabular-nums">{arch.length} test · {arch.reduce((s, t) => s + t.n, 0)} meyve</span></div>
      {(rate.a || rate.b) && (
        <div className="py-1.5 text-[11px] text-slate-700 dark:text-slate-300">
          <b>Günlük değişim</b> ({(rate.a || rate.b)!.days} günde): {rate.a ? `${la} ${sg(rate.a.per)}/gün` : ''}{rate.a && rate.b ? ' · ' : ''}{rate.b ? `${lb} ${sg(rate.b.per)}/gün` : ''}
        </div>
      )}
    </div>
  );
}

function VarietyItem({ m, orchard, parcels, axis, ctx, focus }: { m: VarietyModel; orchard: string; parcels: ParcelRow[]; axis: { a: number; b: number }; ctx: { by: string; readOnly: boolean; fieldRecords: FieldRecord[]; hideTests?: boolean; onStartTest?: (c: { orchard: string; product: string; variety: string }) => void }; focus?: boolean }) {
  const [open, setOpen] = useState(!!focus);
  const ref = React.useRef<HTMLLIElement>(null);
  useEffect(() => { if (focus) setTimeout(() => ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300); }, [focus]);
  const ps = parcels.filter(p => vkey(p.cesit) === m.key);
  const trees = ps.reduce((s, p) => s + p.agac, 0), ha = ps.reduce((s, p) => s + p.ha, 0);
  const v = m.card;
  const maxM = v ? Math.max(...v.plan2027Months, 1) : 1;
  const late26 = m.it26?.start && m.it26?.windowStart ? Math.round((m.it26.start - m.it26.windowStart) / DAY) : undefined;
  return (
    <li ref={ref} className={`py-2 ${focus ? 'scroll-mt-4' : ''}`}>
      <button type="button" onClick={() => setOpen(o => !o)} className="w-full text-left cursor-pointer">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">{m.name}</span>
          <span className="flex items-center gap-1.5 shrink-0 text-xs tabular-nums">
            <span className="text-slate-500">{m.a26.kg ? t1(m.a26.kg) : '—'} →</span><b>{m.plan27 ? `${t1(m.plan27)} t` : '—'}</b>
            <Delta a={m.a26.kg} b={m.plan27} />
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
          </span>
        </div>
        <Track m={m} axis={axis} />
        <div className="text-[10px] text-slate-500 flex flex-wrap gap-x-2">
          {m.it26?.start ? <span>2026: {dmT(m.it26.start)}–{dmT(m.it26.end)}</span> : <span>2026: —</span>}
          {m.it27?.windowStart ? <span className="text-teal-800 dark:text-teal-300">2027 ≈ {dmT(m.it27.windowStart)}–{dmT(m.it27.windowEnd)}</span> : null}
          {m.it27?.ov?.bbch?.['65'] ? <span className="text-pink-700">çiçek {dm(m.it27.ov.bbch['65'])}</span> : m.it27 ? <span className="text-amber-700">çiçek girilmedi</span> : null}
        </div>
      </button>
      {open && (
        <div className="mt-2 space-y-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 p-2">
              <div className="text-[10px] text-slate-500">2026 hasat</div>
              <div className="font-semibold tabular-nums">{m.it26?.start ? `${dmT(m.it26.start)}–${dmT(m.it26.end)}` : '—'}</div>
              <div className="text-[10px] text-slate-500">{m.a26.kg ? `${t1(m.a26.kg)} t · ${m.a26.src === 'Gantt' ? 'Gantt' : 'hasat fişi'}` : 'kayıt yok'}{late26 !== undefined ? ` · pencereye göre ${late26 === 0 ? 'zamanında' : late26 > 0 ? `${late26} gün geç` : `${-late26} gün erken`}` : ''}</div>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-teal-200 p-2">
              <div className="text-[10px] text-slate-500">2027 tahmini pencere</div>
              <div className="font-semibold tabular-nums text-teal-800 dark:text-teal-300">{m.it27?.windowStart ? `${dmT(m.it27.windowStart)}–${dmT(m.it27.windowEnd)}` : '—'}</div>
              <div className="text-[10px] text-slate-500 truncate">{m.it27?.windowSource || ''}{m.plan27 ? ` · plan ${t1(m.plan27)} t` : ''}</div>
            </div>
          </div>
          <BbchTable m={m} orchard={orchard} by={ctx.by} readOnly={ctx.readOnly} />
          <ThinAndCount m={m} orchard={orchard} trees={trees} by={ctx.by} readOnly={ctx.readOnly} />
          {!ctx.hideTests && <Rasatlar m={m} orchard={orchard} fieldRecords={ctx.fieldRecords} onStartTest={ctx.onStartTest} readOnly={ctx.readOnly} />}
          {ps.length > 0 && <ParcelSummary ps={ps} />}
          {v && v.actual2026Kg > 0 && <div><div className="text-[11px] font-semibold text-slate-500 mb-1">2026 sınıf dağılımı (hasat fişleri)</div><GradeBar g={v.grades2026} /></div>}
          {v && v.plan2027Kg > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">2027 plan · ay</div>
              <div className="grid grid-cols-12 gap-0.5 items-end h-10">{v.plan2027Months.map((x, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: x ? `${Math.max(8, (x / maxM) * 100)}%` : 2, opacity: x ? 1 : 0.15 }} />)}</div>
              <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mt-0.5">{MON.map(x => <span key={x}>{x[0]}</span>)}</div>
              <div className="mt-2"><GradeBar g={v.plan2027Grades} /></div>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

/** Kart verisinden profile yazılacak alanlar (yalnız Bahçe kartı olan bahçe) */
function profilePatch(orchard: string, models: VarietyModel[]) {
  const card = ORCHARD_CARDS[orchard];
  if (!card) return null;
  const byTur = new Map<string, string[]>();
  for (const v of card.varieties) if (!/belirsiz/i.test(v.cesit)) byTur.set(v.tur, [...(byTur.get(v.tur) || []), v.cesit]);
  const years = card.parcels.map(p => Number(p.yil)).filter(Number.isFinite);
  const anac = [...new Set(card.parcels.map(p => p.anac).filter(Boolean))];
  const codes = [...new Set(card.parcels.map(p => p.parsel).filter(Boolean))];
  const hasP = card.parcels.length > 0;
  const out: Record<string, string | number> = {
    products: [...byTur.entries()].map(([t, vs]) => `${t}: ${vs.join(', ')}`).join(' · '),
    actual2026Ton: Math.round(models.reduce((s, m) => s + m.a26.kg, 0) / 100) / 10,
    plan2027Ton: Math.round(card.varieties.reduce((s, v) => s + v.plan2027Kg, 0) / 100) / 10,
  };
  if (hasP) Object.assign(out, {
    treeCount: card.parcels.reduce((s, p) => s + p.agac, 0),
    areaHa: Math.round(card.parcels.reduce((s, p) => s + p.ha, 0) * 100) / 100,
    sections: card.parcels.some(p => p.firma)
      ? [...new Set(card.parcels.map(p => p.firma!))].map(fm => { const ps = card.parcels.filter(p => p.firma === fm); return `${fm} ${Math.round(ps.reduce((s, p) => s + p.ha, 0))} ha · ${ps.reduce((s, p) => s + p.agac, 0).toLocaleString('tr-TR')} ağaç · ${[...new Set(ps.map(p => p.cesit))].join(' + ')}`; }).join(' | ')
      : codes.length ? `${codes.length} parsel (${codes.slice(0, 12).join(', ')}${codes.length > 12 ? '…' : ''})` : `${card.parcels.length} parsel satırı`,
    plantYears: years.length ? `${Math.min(...years)}–${Math.max(...years)}` : '',
    ...(anac.length ? { rootstock: anac.join(', ') } : {}),
  });
  return out;
}
const PATCH_LABEL: Record<string, string> = { treeCount: 'Ağaç sayısı', areaHa: 'Alan (ha)', products: 'Ürünler / çeşitler', sections: 'Bölümler / parseller', plantYears: 'Dikim yılı', rootstock: 'Anaç', actual2026Ton: '2026 gerçekleşen (t)', plan2027Ton: '2027 plan (t)' };

/** v49c13: Bahçe bilgisi — konum, denizden yükseklik, sorumlu, çiçeklenme girişi; profil farkı (yönetici) burada tek satır */
function OrchardInfo({ orchard, models, bloom, cal, by, canEdit, onOpenProfiles }: { orchard: string; models: VarietyModel[]; bloom: number; cal: number; by: string; canEdit: boolean; onOpenProfiles?: () => void }) {
  const all = useLocationProfiles('ORCHARD');
  const pr = findProfile('ORCHARD', orchard);
  const f = pr?.fields || {};
  const lat = Number(f.lat) || undefined, lon = Number(f.lon) || undefined;
  const pts = useMemo(() => [{ lat, lon }, ...all.filter(x => !isC(x.fields)).map(x => ({ lat: Number(x.fields?.lat) || undefined, lon: Number(x.fields?.lon) || undefined }))], [all, lat, lon]);
  const el = useElevations(pts);
  const me = el[0];
  const others = el.slice(1).filter((e): e is number => e !== undefined);
  const low = others.length ? Math.min(...others) : undefined;
  const hop = me !== undefined && low !== undefined && me - low >= 50 ? Math.round((me - low) * HOPKINS_DAYS_PER_M) : 0;
  const patch = profilePatch(orchard, models);
  const diff = patch && pr ? Object.entries(patch).filter(([k, v]) => v !== '' && String(pr.fields[k] ?? '') !== String(v)) : [];
  const [showDiff, setShowDiff] = useState(false);
  const [done, setDone] = useState(false);
  const cell = (a: string, b: React.ReactNode, c?: React.ReactNode, warn?: boolean) => (
    <div className="min-w-0"><div className="text-[10px] text-slate-500">{a}</div><div className={`text-sm font-semibold tabular-nums truncate ${warn ? 'text-amber-700' : 'text-slate-900 dark:text-white'}`}>{b}</div>{c && <div className="text-[10px] text-slate-500 truncate">{c}</div>}</div>);
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <div className="flex items-center justify-between mb-1.5"><h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><MapPin className="w-4 h-4 text-teal-700" />Bahçe bilgisi</h2>
        {onOpenProfiles && <button type="button" onClick={onOpenProfiles} className="text-[11px] font-semibold text-teal-700 cursor-pointer">Profili düzenle ›</button>}</div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        {cell('Konum', lat && lon ? <a href={`https://maps.google.com/?q=${lat},${lon}`} target="_blank" rel="noreferrer" className="text-teal-800 dark:text-teal-300 underline">{lat.toFixed(3)}, {lon.toFixed(3)}</a> : 'girilmedi', String(f.region || ''), !(lat && lon))}
        {cell('Denizden yükseklik', me !== undefined ? `${me.toLocaleString('tr-TR')} m` : lat ? '…' : '—', hop ? `en alçak bahçeye göre ≈ ${hop} gün geç` : me !== undefined ? 'en alçak bahçelerle aynı kuşak' : '')}
        {cell('Sorumlu', String(f.contact || '—'), '', !f.contact)}
        {cell('2027 çiçeklenme', `${bloom} / ${cal} çeşit`, bloom < cal ? 'girilmeyen: 2026 ortalaması' : 'tamam', bloom < cal)}
      </div>
      {canEdit && diff.length > 0 && !done && (
        <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <button type="button" onClick={() => setShowDiff(v => !v)} className="w-full flex items-center justify-between text-left text-[11px] cursor-pointer"><span className="text-amber-800 flex items-center gap-1"><RefreshCw className="w-3.5 h-3.5" />Profilde {diff.length} alan bütçe verisinden farklı</span><ChevronDown className={`w-3.5 h-3.5 text-slate-400 ${showDiff ? 'rotate-180' : ''}`} /></button>
          {showDiff && (<>
            <ul className="mt-1 space-y-0.5">{diff.map(([k, v]) => (<li key={k} className="text-[11px]"><b>{PATCH_LABEL[k] || k}</b>: <span className="text-slate-400 line-through">{String(pr!.fields[k] ?? '—').slice(0, 30)}</span> → {String(v).slice(0, 90)}</li>))}</ul>
            <button type="button" onClick={async () => { await upsertProfile({ ...pr!, fields: { ...pr!.fields, ...Object.fromEntries(diff) }, updatedBy: by }); setDone(true); }} className="mt-1.5 min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer">Profili güncelle</button>
          </>)}
        </div>
      )}
      {done && <p className="text-[11px] text-emerald-700 mt-1.5 flex items-center gap-1"><Check className="w-3.5 h-3.5" />Profil güncellendi</p>}
    </section>
  );
}

type Props = {
  onBack: () => void; initial?: string; focusVariety?: string; harvestRecords?: HarvestRecord[]; incidentRecords?: IncidentRecord[]; fieldRecords?: FieldRecord[]; currentUserName?: string; isReadOnly?: boolean; isAdmin?: boolean;
  onStartTest?: (c: { orchard: string; product: string; variety: string }) => void; onOpenCalendar?: () => void; onOpenProfiles?: () => void; onOpenClimate?: () => void; onEditTest?: (r: FieldRecord) => void;
};
type UnitKind = 'ORCHARD' | 'GREENHOUSE' | 'FIELD' | 'EXTERNAL';
const KIND_LABEL: Record<UnitKind, string> = { ORCHARD: 'Bahçeler', GREENHOUSE: 'Seralar', FIELD: 'Açık tarla', EXTERNAL: 'C proje' };
const isC = (fields?: Record<string, unknown>) => /^C proje/i.test(String(fields?.ownership || ''));

/** v49c8 — Bahçe profili: Bahçeler · Seralar · Açık tarla. Yer profillerine eklenen yeni bahçe / sera / tarla burada kendiliğinden görünür. */
export default function OrchardCardsView(p0: Props) {
  const [initOrchard, focusVariety] = (p0.initial || '').split('|');
  const p = { ...p0, initial: initOrchard || undefined, focusVariety: focusVariety || undefined };
  useLocationProfiles();
  const orchardProfiles = useLocationProfiles('ORCHARD'), ghProfiles = useLocationProfiles('GREENHOUSE'), fieldProfiles = useLocationProfiles('FIELD');
  const lists = useMemo(() => {
    const plan = new Map<string, number>();
    for (const r of CAL_SEED_ROWS) if (r.orchard && r.orchard !== '—' && !/ýyladyş/i.test(r.orchard)) plan.set(canonicalOrchard(r.orchard), (plan.get(canonicalOrchard(r.orchard)) || 0) + (r.plan2027Ton || 0) + (r.soldTon || 0));
    for (const [n, c] of Object.entries(ORCHARD_CARDS)) plan.set(n, (plan.get(n) || 0) + c.varieties.reduce((s, v) => s + v.plan2027Kg, 0) / 1000);
    for (const pr of orchardProfiles) if (!plan.has(pr.name) && !isC(pr.fields)) plan.set(pr.name, 0);
    const orch = [...plan.entries()].sort((a, b) => b[1] - a[1]).map(([n]) => n);
    const byPlan = (names: string[]) => names.sort((a, b) => ((UNIT_PLANS[b]?.rows.reduce((s, r) => s + r.kg, 0) || 0) - (UNIT_PLANS[a]?.rows.reduce((s, r) => s + r.kg, 0) || 0)) || a.localeCompare(b, 'tr'));
    const gh = byPlan([...new Set([...ghProfiles.map(x => x.name), ...Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'GREENHOUSE').map(([n]) => n)])]);
    const fl = byPlan([...new Set([...fieldProfiles.filter(x => !isC(x.fields)).map(x => x.name), ...Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'FIELD').map(([n]) => n)])]);
    const ext = [...new Set([...EXTERNAL_VISITS.map(v => v.name), ...[...orchardProfiles, ...fieldProfiles].filter(x => isC(x.fields)).map(x => x.name)])];
    return { ORCHARD: orch, GREENHOUSE: gh, FIELD: fl, EXTERNAL: ext } as Record<UnitKind, string[]>;
  }, [orchardProfiles, ghProfiles, fieldProfiles]);
  const initKind = (Object.keys(lists) as UnitKind[]).find(k => p.initial && lists[k].includes(p.initial)) || 'ORCHARD';
  const [kind, setKind] = useState<UnitKind>(initKind);
  const [sel, setSel] = useState(p.initial && lists[initKind].includes(p.initial) ? p.initial : lists.ORCHARD[0]);
  const names = lists[kind];
  const cur = names.includes(sel) ? sel : names[0];
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer">←</button>
        <div className="min-w-0 flex-1"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Bahçeler</h1><p className="text-xs text-slate-500">Takvim · testler · iklim · profil — hepsi bahçenin içinde</p></div>
        {p.onOpenCalendar && <button type="button" onClick={p.onOpenCalendar} className="shrink-0 min-h-[36px] px-3 rounded-xl border border-teal-300 text-teal-800 dark:text-teal-300 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"><CalendarRange className="w-4 h-4" />Tüm takvim</button>}
      </div>
      <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">{(Object.keys(KIND_LABEL) as UnitKind[]).map(k => (
        <button key={k} type="button" onClick={() => { setKind(k); setSel(lists[k][0]); }} className={`min-h-[36px] rounded-lg text-xs font-semibold cursor-pointer ${kind === k ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'}`}>{KIND_LABEL[k]}<span className="hidden sm:inline"> · {lists[k].length}</span></button>))}</div>
      <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">{names.map(n => (
        <button key={n} type="button" onClick={() => setSel(n)} className={`shrink-0 px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${cur === n ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{n}</button>))}</div>
      {!cur ? <p className="text-sm text-slate-500">Bu türde birim yok. Yer profillerinden ekleyin.</p>
        : kind === 'ORCHARD' ? <OrchardBody key={cur} sel={cur} {...p} /> : kind === 'EXTERNAL' ? <ExternalBody key={cur} name={cur} onOpenProfiles={p.onOpenProfiles} /> : <UnitBody key={cur} name={cur} kind={kind} onOpenProfiles={p.onOpenProfiles} incidentRecords={p.incidentRecords} by={p.currentUserName} readOnly={p.isReadOnly} isAdmin={p.isAdmin} />}
    </div>
  );
}

function ExternalBody({ name, onOpenProfiles }: { name: string; onOpenProfiles?: () => void }) {
  const pr = findProfile('ORCHARD', name) || findProfile('FIELD', name);
  const f = pr?.fields || {};
  const visits = EXTERNAL_VISITS.filter(v => v.name === name);
  const items = visits.flatMap(v => v.items);
  const trees = items.reduce((s, i) => s + (i.trees || 0), 0), ha = items.reduce((s, i) => s + (i.ha || 0), 0) || Number(f.areaHa) || 0;
  const planT = items.reduce((s, i) => s + (i.planT || 0), 0);
  const hasGeo = Number(f.lat) && Number(f.lon);
  const [open, setOpen] = useState<number | null>(null);
  return (
    <>
      <div className="rounded-2xl border border-violet-200 bg-violet-50 dark:bg-violet-950/30 px-4 py-2.5 text-xs text-violet-900 dark:text-violet-200">
        <b>C proje</b> — bize ait değil; sipariş üzerine değerlendirildi. Plan tonu bahçe sorumlusunun beyanı, kalite tonu bizim tahminimiz (−%30).
      </div>
      <div className="grid grid-cols-2 gap-2">
        {([['Yer', String(f.region || visits[0]?.region || '—'), String(f.contact || visits[0]?.responsible || '')],
          [trees ? 'Ağaç' : 'Alan', trees ? n0(trees) : ha ? `${ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha` : '—', `${visits.length} ziyaret · ${visits.flatMap(v => v.dates).join(', ') || '—'}`],
          ['Beyan edilen plan', planT ? `${n0(planT)} t` : '—', 'bahçe sorumlusu'],
          ['Konum', hasGeo ? `${Number(f.lat).toFixed(4)}, ${Number(f.lon).toFixed(4)}` : 'girilmedi', hasGeo ? 'yer profilinden' : 'Yer profili › Konumumu al']] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 min-w-0"><div className="text-xs text-slate-500">{a}</div><div className={`text-sm font-bold text-slate-900 dark:text-white ${a === 'Konum' && !hasGeo ? 'text-amber-700' : ''}`}>{b}</div><div className="text-[11px] text-slate-500 truncate">{c}</div></div>))}
      </div>
      {!hasGeo && onOpenProfiles && <button type="button" onClick={onOpenProfiles} className="w-full text-left rounded-2xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 cursor-pointer">Konum yok — sahada Yer profilleri › {name} › <b>Konumumu al</b> ile ekleyin ›</button>}
      {visits.map(v => (
        <section key={v.code} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-slate-900 dark:text-white">Ziyaret raporu · {v.dates.join(' / ')}</h2><span className="text-[10px] text-slate-400">{v.code}</span></div>
          <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">{v.basis}</div>
          <div className="text-[11px] text-slate-500">Ekip: {v.team.join(' · ')}</div>
          <div className="text-[11px] text-slate-500">Bahçe sorumlusu: {v.responsible || '—'}</div>
          <div className="grid grid-cols-[minmax(0,1fr)_56px_48px_48px_64px] gap-1 text-[10px] text-slate-500 font-semibold mt-2 border-b border-slate-100 dark:border-slate-800 pb-1"><span>Ürün · çeşit</span><span className="text-right">Ağaç/ha</span><span className="text-right">Plan t</span><span className="text-right">Kalite t</span><span className="text-right">Hasat</span></div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{v.items.map((it, i) => {
            const k = EXTERNAL_VISITS.indexOf(v) * 100 + i;
            const more = it.note || it.suitability || it.checks;
            return (
              <li key={i}>
                <button type="button" disabled={!more} onClick={() => setOpen(open === k ? null : k)} className="w-full grid grid-cols-[minmax(0,1fr)_56px_48px_48px_64px] gap-1 text-xs tabular-nums py-1.5 text-left cursor-pointer disabled:cursor-default">
                  <span className="min-w-0 truncate"><b>{it.fruit}</b> · {it.variety || '—'}{more ? <ChevronDown className={`w-3 h-3 inline ml-0.5 text-slate-400 ${open === k ? 'rotate-180' : ''}`} /> : null}</span>
                  <span className="text-right">{it.trees ? n0(it.trees) : it.ha ? `${it.ha} ha` : '—'}</span><span className="text-right">{it.planT ?? '—'}</span><span className="text-right">{it.qualityT ?? '—'}</span><span className="text-right truncate">{it.harvest || '—'}</span>
                </button>
                {open === k && (
                  <div className="text-[11px] space-y-1 pb-2 text-slate-700 dark:text-slate-300">
                    {it.note && <p><span className="font-semibold text-slate-500">Gözlem: </span>{it.note}</p>}
                    {it.suitability && <p><span className="font-semibold text-slate-500">Uygunluk / saklama: </span>{it.suitability}</p>}
                    {it.checks && <p className="whitespace-pre-line"><span className="font-semibold text-slate-500">Yapılacak kontroller: </span>{it.checks}</p>}
                  </div>
                )}
              </li>);
          })}</ul>
        </section>
      ))}
      {visits.length === 0 && <p className="text-sm text-slate-500">Bu birim için ziyaret raporu yok. Bilgileri yer profiline girin.</p>}
      <p className="text-[11px] text-slate-500 px-1">Kaynak: {EXTERNAL_SOURCE}. Telefon numaraları uygulamaya yazılmadı; gerekirse yer profilindeki "Sorumlu / iletişim" alanına girin.</p>
    </>
  );
}

/* v54: aktlar yalnız Yönetim'de (bahçe / sera / tarla sayfalarında akt listesi yok) */
function UnitBody({ name, kind, onOpenProfiles, incidentRecords = [], by = '', readOnly, isAdmin }: { name: string; kind: UnitKind; onOpenProfiles?: () => void; incidentRecords?: IncidentRecord[]; by?: string; readOnly?: boolean; isAdmin?: boolean }) {
  const u = UNIT_PLANS[name];
  const pr = findProfile(kind as 'GREENHOUSE' | 'FIELD', name);
  const f = pr?.fields || {};
  const kg = u ? u.rows.reduce((s, r) => s + r.kg, 0) : 0;
  const months = Array.from({ length: 12 }, (_, i) => (u ? u.rows.reduce((s, r) => s + (r.months[i] || 0), 0) : 0));
  const maxM = Math.max(...months, 1);
  const grades: Record<string, number> = {};
  for (const r of u?.rows || []) for (const [g, v] of Object.entries(r.grades)) grades[g] = (grades[g] || 0) + v;
  const ha = Number(f.areaHa) || (u?.crops ? u.crops.reduce((s, c) => s + c.ha, 0) : 0);
  const products = [...new Set((u?.rows || []).map(r => r.product))];
  const isMuz = kind === 'GREENHOUSE' && (/muz|banan/i.test(name) || products.includes('Muz'));
  const noLoc = kind === 'GREENHOUSE' && !(f.lat && f.lon);
  // v51 düzen: açık tarla → ekin paneli (bütçe + günlük); sera → muz · iklim · plan (kapalı) · bilgi; aktlar kısa
  if (kind === 'FIELD' && name === FIELD_UNIT) return (
    <>
      <FieldPanel by={by} readOnly={readOnly} />
    </>
  );
  return (
    <>
      {noLoc && <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-900">Seranın dış konumu girilmemiş — dış hava ve iklim karşılaştırması için aşağıdaki <b>Sera bilgisi</b>'nden enlem/boylam girin.</div>}
      {isMuz && <MuzPanel sera={name} by={by} readOnly={readOnly} isAdmin={isAdmin} />}
      {kind === 'GREENHOUSE' && <SeraClimate name={name} by={by} readOnly={readOnly} />}
      {!u && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
          Bu birim için plan verisi yok. {kind === 'GREENHOUSE' ? 'Ürün, alan ve 2027 planını' : 'Ekinleri, alanı ve 2027 planını'} yer profiline girin; Excel ile gelirse sonraki pakette buraya işlenir.
          {onOpenProfiles && <button type="button" onClick={onOpenProfiles} className="block mt-1.5 font-semibold text-teal-800 cursor-pointer">Yer profillerini aç ›</button>}
        </div>
      )}
      {u && kind === 'GREENHOUSE' ? (
        <details className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 group">
          <summary className="text-sm font-bold text-slate-900 dark:text-white cursor-pointer flex items-center justify-between list-none">2027 plan · {t1(kg)} t{ha ? ` · ${ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha` : ''}<ChevronDown className="w-4 h-4 text-slate-400 group-open:rotate-180 transition-transform" /></summary>
          <div className="mt-2 space-y-3">
          <div>
            <div className="text-[11px] font-semibold text-slate-500 mb-1">Ay dağılımı (t)</div>
            <div className="grid grid-cols-12 gap-0.5 items-end h-16">{months.map((x, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: x ? `${Math.max(6, (x / maxM) * 100)}%` : 2, opacity: x ? 1 : 0.15 }} title={`${MON[i]} ${t1(x)} t`} />)}</div>
            <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mt-0.5">{MON.map(x => <span key={x}>{x.slice(0, 3)}</span>)}</div>
            <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-600 text-center tabular-nums">{months.map((x, i) => <span key={i}>{x ? Math.round(x / 1000) : ''}</span>)}</div>
          </div>
          <div><div className="text-[11px] font-semibold text-slate-500 mb-1">Sınıf dağılımı (plan)</div><GradeBar g={grades} /></div>
          <p className="text-[11px] text-slate-500">Kaynak: {UNIT_PLAN_SOURCE}.</p>
          </div>
        </details>
      ) : null}
      {kind !== 'GREENHOUSE' && (
        <div className="grid grid-cols-2 gap-2">
        {([['Alan', ha ? `${ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha` : '—', String(f.company || f.region || '')], ['2027 plan', kg ? `${t1(kg)} t` : '—', ha && kg ? `${(kg / 1000 / ha).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t/ha` : '']] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div></div>))}
      </div>
      )}
      {kind === 'GREENHOUSE' && <SeraInfo name={name} by={by} readOnly={readOnly} />}
    </>
  );
}

function OrchardBody({ sel, focusVariety, harvestRecords = [], fieldRecords = [], incidentRecords = [], currentUserName = '', isReadOnly = false, isAdmin = false, onStartTest, onOpenCalendar, onOpenProfiles, onOpenClimate, onEditTest }: Props & { sel: string }) {
  const treeDocs = useTreeDocs();
  const trees = treeRows(sel, treeDocs);
  const treeNet = trees.reduce((a, r) => a + r.net, 0), treeLost = trees.reduce((a, r) => a + r.lost, 0), treePlanted = trees.reduce((a, r) => a + r.planted, 0);
  const [showSrc, setShowSrc] = useState(false);
  const ovs = useCalOverrides();
  const items26 = useMemo(() => buildCalendar(2026, ovs, harvestRecords), [ovs, harvestRecords]);
  const items27 = useMemo(() => buildCalendar(2027, ovs, harvestRecords), [ovs, harvestRecords]);
  const card = ORCHARD_CARDS[sel];
  const models = useMemo(() => buildModels(sel, items26, items27), [sel, items26, items27]);
  const axis = useMemo(() => {
    const ts = models.flatMap(m => [m.it26?.start, m.it26?.end, m.it26?.windowStart, m.it26?.windowEnd, m.it27?.windowStart, m.it27?.windowEnd]).filter((t): t is number => !!t).map(doy);
    if (!ts.length) return { a: 120, b: 320 };
    return { a: Math.max(0, Math.min(...ts) - 7), b: Math.min(366, Math.max(...ts) + 7) };
  }, [models]);
  const months = useMemo(() => { const out: { l: string; x: number }[] = []; for (let mo = 0; mo < 12; mo++) { const d = doy(Date.UTC(2027, mo, 1)); if (d >= axis.a && d <= axis.b) out.push({ l: MON[mo], x: ((d - axis.a) / (axis.b - axis.a)) * 100 }); } return out; }, [axis]);
  const tot = useMemo(() => {
    const a = models.reduce((s, m) => s + m.a26.kg, 0), p = models.reduce((s, m) => s + m.plan27, 0);
    const withCal = models.filter(m => m.it27), bloom = withCal.filter(m => m.it27?.ov?.bbch?.['65']).length;
    const agac = card?.parcels.reduce((s, x) => s + x.agac, 0) || 0, ha = card?.parcels.reduce((s, x) => s + x.ha, 0) || 0;
    const noActual = models.filter(m => !m.a26.kg && m.plan27 > 5000);
    return { a, p, bloom, cal: withCal.length, agac, ha, noActual };
  }, [models, card]);
  const fruits = [...new Set(models.map(m => m.fruit))];
  const ctx = { by: currentUserName, readOnly: isReadOnly, fieldRecords, onStartTest, hideTests: true };
  const [tab, setTab] = useState<'ozet' | 'takvim' | 'test' | 'iklim' | 'profil'>(focusVariety ? 'takvim' : 'ozet');
  const tests = fieldRecords.filter(r => canonicalOrchard(r.orchard) === sel);
  const upcoming = models.filter(m => m.it27?.windowStart).sort((x, y) => x.it27!.windowStart! - y.it27!.windowStart!);
  const TABS = [['ozet', 'Özet'], ['takvim', 'Takvim'], ['test', `Testler${tests.length ? ` · ${tests.length}` : ''}`], ['iklim', 'İklim'], ['profil', 'Profil']] as const;
  return (
    <>
      <div className="grid grid-cols-5 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 sticky top-0 z-10">{TABS.map(([k, l]) => (
        <button key={k} type="button" onClick={() => setTab(k)} className={`min-h-[36px] rounded-lg text-[11px] font-semibold cursor-pointer truncate px-1 ${tab === k ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}>{l}</button>))}</div>
      {tab === 'ozet' && (<>
      <div className="grid grid-cols-2 gap-2">
        {([
          ['Ağaç · alan', card?.parcels.length ? n0(treeNet) : '—', card?.parcels.length ? `${tot.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha${treeLost ? ` · −${n0(treeLost)} kayıp` : ''}${treePlanted ? ` · +${n0(treePlanted)} yeni` : ''}${!treeLost && !treePlanted ? ` · ${card.parcels.length} parsel satırı` : ''}` : 'parsel bilgisi yok'],
          ['Çeşit', String(models.length), `${tot.cal} çeşit hasat takviminde`],
          ['2026 gerçekleşen', `${t1(tot.a)} t`, card?.varieties.some(v => v.actual2026Kg > 0) ? 'hasat fişleri + Gantt' : 'Gantt (satylan)'],
          ['2027 plan', `${t1(tot.p)} t`, tot.a ? `${tot.p >= tot.a ? '+' : ''}${Math.round(((tot.p - tot.a) / tot.a) * 100)}% 2026'ya göre` : ''],
        ] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div></div>))}
      </div>
      {upcoming.length > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="flex items-center justify-between"><h2 className="text-sm font-bold text-slate-900 dark:text-white">2027 hasat sırası</h2><button type="button" onClick={() => setTab('takvim')} className="text-[11px] font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">Takvim ›</button></div>
          <ul className="mt-1 divide-y divide-slate-100 dark:divide-slate-800">{upcoming.slice(0, 6).map(m => (
            <li key={m.key} className="flex items-center justify-between gap-2 py-1 text-xs"><span className="truncate"><b>{m.name}</b> · {m.fruit}</span><span className="tabular-nums shrink-0 text-teal-800 dark:text-teal-300">{dmT(m.it27!.windowStart)}–{dmT(m.it27!.windowEnd)}{m.plan27 ? <span className="text-slate-500"> · {t1(m.plan27)} t</span> : null}</span></li>))}
          </ul>
          {upcoming.length > 6 && <p className="text-[10px] text-slate-500 mt-0.5">+{upcoming.length - 6} çeşit daha — Takvim sekmesinde</p>}
        </section>
      )}
      <CherryOpsPanel orchard={sel} />
      {tests.length > 0 && (() => { const last = [...tests].sort((x, y) => String(y.timestamp).localeCompare(String(x.timestamp)))[0]; return (
        <button type="button" onClick={() => setTab('test')} className="w-full text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-2.5 cursor-pointer">
          <div className="text-[11px] text-slate-500">Son test · {new Date(last.timestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' })}</div>
          <div className="text-xs truncate"><b>{last.sortVariety || last.product}</b> · {last.testType} · sertlik {last.avgHardness ? last.avgHardness.toFixed(1) : '—'} · Brix {last.avgBrix ? last.avgBrix.toFixed(1) : '—'}</div>
        </button>); })()}

      {tot.noActual.length > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>2027 planı olup 2026 hasadı bulunmayan: <b>{tot.noActual.map(m => m.name).join(', ')}</b></span></div>
      )}

      </>)}
      {tab === 'takvim' && (<>
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
        <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><CalendarRange className="w-4 h-4 text-teal-700" />Hasat pencereleri 2026 · 2027</h2>
</div>
        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-slate-500">
          <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-slate-300 inline-block" />2026 penceresi</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-full bg-slate-600 inline-block" />2026 gerçek hasat</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-full border border-teal-600 bg-teal-100 inline-block" />2027 tahmini</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-pink-500 inline-block" />2027 çiçek</span>
        </div>
        {(() => {
          // v50e: sezon sonucu — hasat penceresi (tahmin) ile gerçek başlangıç arasındaki fark
          const res = (k: 'it26' | 'it27') => models.map(m => ({ m, it: m[k] })).filter(x => x.it?.start && x.it?.windowStart).map(x => ({ name: x.m.name, d: Math.round((x.it!.start! - x.it!.windowStart!) / DAY) }));
          const row = (label: string, r: { name: string; d: number }[]) => {
            if (!r.length) return null;
            const avg = Math.round(r.reduce((a2, x) => a2 + Math.abs(x.d), 0) / r.length);
            const early = r.reduce((a2, x) => (x.d < a2.d ? x : a2)), late = r.reduce((a2, x) => (x.d > a2.d ? x : a2));
            return <div className="text-[11px] text-slate-600 dark:text-slate-400"><b className="text-slate-800 dark:text-slate-200">{label}</b>: {r.length} çeşit · tahmin ile gerçek başlangıç farkı ort. <b className={avg > 7 ? 'text-amber-700' : 'text-emerald-700'}>±{avg} gün</b>{early.d < 0 ? ` · en erken ${early.name} (${early.d})` : ''}{late.d > 0 ? ` · en geç ${late.name} (+${late.d})` : ''}</div>;
          };
          const r26 = res('it26'), r27 = res('it27');
          return r26.length || r27.length ? <div className="mt-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 space-y-0.5">{row('Sezon sonucu 2026', r26)}{row('2027 (başlayanlar)', r27)}</div> : null;
        })()}
        <div className="relative h-4 mt-2 text-[9px] text-slate-400">{months.map(mo => <span key={mo.l} className="absolute -translate-x-1/2" style={{ left: `${mo.x}%` }}>{mo.l}</span>)}</div>
        {fruits.map(f => (
          <div key={f} className="mt-1">
            <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 pt-1.5 border-t border-slate-100 dark:border-slate-800"><TreeDeciduous className="w-3.5 h-3.5 text-teal-700" />{f}</div>
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">{models.filter(m => m.fruit === f).map(m => <VarietyItem key={sel + m.key} m={m} orchard={sel} parcels={card?.parcels || []} axis={axis} ctx={ctx} focus={!!focusVariety && vkey(focusVariety) === m.key} />)}</ul>
          </div>
        ))}
      </section>

      </>)}
      {tab === 'test' && (<>
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
        <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><FlaskConical className="w-4 h-4 text-teal-700" />Saha testleri</h2>
          {onStartTest && !isReadOnly && <button type="button" onClick={() => onStartTest({ orchard: sel, product: fruits[0] || '', variety: '' })} className="min-h-[34px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"><Plus className="w-3.5 h-3.5" />Yeni test</button>}</div>
        <p className="text-[11px] text-slate-500 mt-0.5">Çeşide dokunun: son testler ve 2026 arşivi. Çeşidin satırındaki "+ Test" o çeşidi hazır açar.</p>
        {fruits.map(f => (
          <div key={f} className="mt-1">
            <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 pt-1.5 border-t border-slate-100 dark:border-slate-800"><TreeDeciduous className="w-3.5 h-3.5 text-teal-700" />{f}</div>
            {models.filter(m => m.fruit === f).map(m => <TestGroup key={sel + m.key} m={m} orchard={sel} fieldRecords={fieldRecords} harvestRecords={harvestRecords} onStartTest={onStartTest} onEditTest={onEditTest} readOnly={isReadOnly} />)}
          </div>
        ))}
        {(() => {
          const other = tests.filter(r => !models.some(m => vkey(r.sortVariety) === m.key || matchCardVariety(sel, r.sortVariety) === m.key)).sort((x, y) => String(y.timestamp).localeCompare(String(x.timestamp)));
          return other.length ? (
            <div className="mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-800">
              <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Çeşidi eşleşmeyen testler · {other.length}</div>
              {other.slice(0, 8).map(r => (
                <div key={r.id} className="flex justify-between gap-2 text-xs py-0.5"><span className="truncate">{new Date(r.timestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' })} · {r.product} {r.sortVariety || '—'} · {r.testType}</span>
                  <span className="tabular-nums shrink-0 text-slate-600">{r.avgHardness ? r.avgHardness.toFixed(1) : '—'} · {r.avgBrix ? r.avgBrix.toFixed(1) : '—'}</span></div>))}
            </div>) : null;
        })()}
      </section>
      </>)}
      {tab === 'iklim' && (<>
      <OrchardClimateCard name={sel} onOpenProfiles={onOpenProfiles || (() => {})} />
      {onOpenClimate && <button type="button" onClick={onOpenClimate} className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">Tüm bahçelerin iklimi ›</button>}
      </>)}
      {tab === 'profil' && (<>
      <TreesPanel orchard={sel} by={currentUserName} readOnly={isReadOnly} />
      <OrchardInfo orchard={sel} models={models} bloom={tot.bloom} cal={tot.cal} by={currentUserName} canEdit={isAdmin && !isReadOnly} onOpenProfiles={onOpenProfiles} />
      {card?.parcels.some(x => x.firma) && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-1">Firmaya göre ağaç</h2>
          <div className="grid grid-cols-[minmax(0,1fr)_64px_52px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Firma · çeşit</span><span className="text-right">Ağaç</span><span className="text-right">ha</span><span className="text-right">Prs</span></div>
          {[...new Set(card.parcels.map(x => x.firma || '—'))].map(fm => { const ps = card.parcels.filter(x => (x.firma || '—') === fm); return (
            <div key={fm} className="grid grid-cols-[minmax(0,1fr)_64px_52px_40px] gap-1 text-xs tabular-nums py-0.5"><span className="truncate"><b>{fm}</b> · {[...new Set(ps.map(x => x.cesit))].join(', ')}</span><span className="text-right">{n0(ps.reduce((s, x) => s + x.agac, 0))}</span><span className="text-right">{Math.round(ps.reduce((s, x) => s + x.ha, 0))}</span><span className="text-right">{ps.length}</span></div>); })}
        </section>
      )}
      <button type="button" onClick={() => setShowSrc(v => !v)} className="text-[11px] text-slate-500 px-1 cursor-pointer">Kaynaklar {showSrc ? '▴' : '▾'}</button>
      {showSrc && <p className="text-[11px] text-slate-500 px-1 -mt-2">Parseller/ağaç — {ORCHARD_SOURCES.parcels} · 2026 — {ORCHARD_SOURCES.actual2026}, yoksa Gantt "satylan" · 2027 plan — {ORCHARD_SOURCES.plan2027} · BBCH ve pencereler — girdiğiniz tarihler. Kaynaklar birbirine karışmaz.</p>}
      </>)}
    </>
  );
}
