# V61 NOTLAR — v59 + v60 dahil + aynı bahçenin ayrı görünmesi düzeltildi

Taban: v58 (212 dosya). v59 ve v60 ayrıca uygulanmadıysa GÖNDERME, içinde var. Sonuç: 218 dosya (6 yeni, 7 değişen). Silinecek dosya YOK. Firestore kuralı değişmedi.

## Dosyalar (SHA-256)
d7a03c18356ba7a9d55d8f9e43d9d9382feb1bdf2a0c73cb83aa81cfcaf0fbdf  src/App.tsx
29a6a825d9a8f7c38c38618a3e83d38d8841edadf41b49fe43f213198776bcac  src/components/views/OrchardCardsView.tsx
e08891478590a0fed2671a71055202eeb7f6971cb0b8ff5029859bde338317cc  src/components/views/ManagementViews.tsx
74c263f30c899a74626428599ed312d76604ab907b6944d65781974fcffedfd7  src/components/views/ManagerBrief.tsx
5bb391f2f41715bb27cdf51d7dd292a0199d91082167da5a4d4b75a91a2e41b3  src/config/fieldCrops.ts
bb07a3e1b4576a03a89cef6b0a9e13bfad7b4a24d5b24446d65b24f1c941b777  src/services/treeLedger.ts
142b8a54291b15b2e7fbab32ad6087a244cbcf3eb50e5e6dfedd082c81e522a8  src/components/views/TreesPanel.tsx
538d3167b6252af53af69a6c2c9587fb1ad0bc9cf052feb3aca9c971eb115c57  src/components/views/TestDetailSheet.tsx
60e0010c6b0b378ea34e27df55b518d53ec8357e0c846cab8c60b828211ac83d  src/components/views/Archive2026View.tsx
51bb7af0464c25892ca093ea1525cf0df44094514bdf638b4c81e9fcf95c9bba  src/components/views/CherryOpsPanel.tsx
ed42ac17cd8813511538712ba1357f07661e058ff45cf460014370eeb5d856d9  src/config/cherryOps2026.ts
2f16ab06d6d133e10c626dc72ffa612bfb483ec4f8d83a20fac900dbe8c108fb  src/services/locationProfiles.ts
4d85d168e526babaea52a549b41694f70c16ffa477f942e29d383fb04960ec43  src/config/profileSeed.ts

Yeni: treeLedger.ts, TreesPanel.tsx, TestDetailSheet.tsx, Archive2026View.tsx, CherryOpsPanel.tsx, cherryOps2026.ts

## Ne değişti
- v59: ağaç kayıp / yeni dikim / sayım defteri; teste dokununca ayrıntı + çeşit geçmişi; 2026 arşivi analiz ekranı; Yönetici masası "Bahçeler · ayrıntı"; patates awgust hasadı yalnız Kasım.
- v60: Saýwan Nektarin / Gursak › Özet › "Kiraz 2026 · hasat ve işçi" (Gantt › CHERRY- OPER); Ağaçlar tonajı Özet'teki 2027 planından.
- v61: "Garahan 1200, Kaka" gibi, bir bahçenin adıyla başlayıp virgül / parantez / • ile devam eden yer adları ayrı bahçe sayılmaz; o bahçeye bağlanır (bahçe listesi, kayıtlar, testler, takvim). Kayıtlardan otomatik "yeni yer" önerisi bu adlar için çıkmaz. Garahan 1200 ha'ya diğer adlar eklendi (Garahan 1200 Kaka, Garahan Hurma…). Boşlukla devam eden adlar birleşmez ("Saýwan Gursak" ≠ "Saýwan").
