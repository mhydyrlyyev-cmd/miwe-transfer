# v49c3 — Rapor merkezi · Yönetici masası · Yönetim analizi · şahit numune hatırlatması

1. Rapor merkezi (Menü › Raporlar › Rapor merkezi, yeni görünüm REPORTS): Bu hafta / Bu ay / Bu yıl seçici; 4 gösterge
   (hasat t, sevk t, dikkat/uygun değil %, set dışı oda); hazır rapor satırları mevcut ekranlara gider; Oda turları ve Partiler Excel indirme.
2. Yönetici masası (yalnız yönetici, ADMIN_DESK): onay bekleyen kullanıcılar, rol sayıları, veri sağlığı (bölümü listede olmayan kullanıcı,
   profilsiz depo partisi, deneme kaydı, kalibrasyonu geçen cihaz, bugün oda turu girilmemiş depo); Yönetim analizi / Denetim izi / Profiller bağlantıları.
3. Yönetim analizi (yalnız yönetici, MGMT_ANALYSIS): Bahçe ve depo (hareket, akt, ton, puan) · Kişiler (kayıt, düzeltme, silme, son işlem)
   · Kritik noktalar (tekrarlanan test sorunu, set dışı oda, monitör–cihaz farkı ≥ 2 °C, akt türleri). Ek veri girişi yok.
4. Bugün yapılacaklar ve Ana sayfa: şahit numune 7. ve 14. gün ölçüm hatırlatması (ihracat numunesi kayıtlarından).
5. v49c2b'nin 5 dosyası da pakette (aynı SHA) — v49c2b uygulanmadıysa birlikte gelir.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (11 dosya)
6ad4eff9733fea7b835cdc21283c1e3874fcab53355f2e21b6eb6bfcd5e06582  src/App.tsx
cc42ac441b2a3ab926040b842aa69963eef2d9d5f534d9a9818b36d6f2fccde7  src/types.ts
3c8614e4eb6fda22fcfc3ea090a05a7127c427839c829e3e7e8f46424357f0a9  src/services/lotTests.ts
6c10c72c9bc624c3ef6281c0127296d1a792f29f7e8d40358fb8d9e0ca374bbd  src/services/analytics.ts
021afe40b3d6c9d7de08f2d56c907fc8bcd5471e9a88198926ee30148d3fc5f0  src/components/forms/DailyHarvestForm.tsx
f61bb770f25232b9e871804fff1ed76cfe74f2af3a764e7190475eaf6d57778e  src/components/views/LotsView.tsx
a4627c3d25eef292a996579ed7eb44e8f97cc4af9115619ca54da72a506c6fb3  src/components/views/RoomCheckTour.tsx
566137690d90ce2b48b133fb847940af4d15495929c8b2d6d9df2241cfe491a4  src/components/views/TodayView.tsx
b19f1dfe2990f3b0112131f337e5670001647b02926fdb1cba8580a04417c36d  src/components/views/ManagementViews.tsx
91fdb4b9f0e37d020f302592b1b7f20ade83fda2f5d90f80a5d5e074fd8b8bc4  src/components/dashboard/HomeDashboard.tsx
4f7e1dd2f96cecc0e5030f4d4f178f044599045b42dfc6fa08f8ce7acd030a3e  src/components/portal/HomeMenu.tsx
