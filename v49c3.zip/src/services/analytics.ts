/**
 * v49c3 — Yönetim analizi (yalnız yönetici). Ek veri girişi yok: kayıtlardaki kişi, yer, tarih, kg ve test sonuçları.
 * Puan (100) = kalite uygunluğu 55 + kayıt eksiksizliği 25 + akt sıklığı 20. Amaç ceza değil, desteğe ihtiyaç duyan yeri görmek.
 */
import type { ActivityLogItem, AppUser } from '../types/auth';
import { buildLot, type LotSources, type Verdict } from './lotTests';
import { canonicalOrchard } from './locationProfiles';
import { isTestReference } from '../utils/refKind';
import type { IncidentRecord } from '../types';
import type { RoomCheckRound } from './depots';
import { calibrationGap, depotOf } from './depots';
/** depo adı profil adına bağlanır (PM, "PM · Paýlaýyş nokady" → tek satır) */
const depotName = (w?: string) => { const d = depotOf(w); return d ? String(d.fields?.shortName || d.name) : (w || 'Depo yazılmamış').split('(')[0].trim() + ' (profilsiz)'; };

export interface PlaceRow { name: string; kind: string; moves: number; akts: number; kg: number; tests: number; ok: number; withTest: number; lots: number; score: number }
export interface PersonRow { name: string; dept: string; records: number; edits: number; deletes: number; last?: string; lastWhat?: string }
export interface CriticalRow { label: string; where: string; count: number; level: 'high' | 'mid' }

const inRange = (iso: string | undefined, from: string) => !!iso && iso.slice(0, 10) >= from;

export function analyze(src: LotSources & { incidentRecords: IncidentRecord[]; logs: ActivityLogItem[]; users: AppUser[]; roomChecks: RoomCheckRound[] }, fromDate: string) {
  const places = new Map<string, PlaceRow>();
  const place = (name: string, kind: string) => {
    const k = `${kind}|${name}`;
    if (!places.has(k)) places.set(k, { name, kind, moves: 0, akts: 0, kg: 0, tests: 0, ok: 0, withTest: 0, lots: 0, score: 0 });
    return places.get(k)!;
  };
  const verdictCount: Record<string, Record<Verdict, number>> = {};

  for (const r of src.references) {
    if (r.archived || isTestReference(r) || !inRange(r.createdAt, fromDate)) continue;
    const lot = buildLot(r.refId, src);
    if (!lot) continue;
    const orch = canonicalOrchard(r.orchard || r.location || '') || 'Yer yazılmamış';
    const p = place(orch, r.product && /muz/i.test(r.product) ? 'Sera' : 'Bahçe');
    p.lots++; p.kg += Number(r.quantity) || 0; p.moves += lot.events.length;
    const tests = lot.tests.filter(t => t.stage !== 'HARVEST' || t.moduleKey !== 'HARVEST');
    if (tests.length) p.withTest++;
    p.tests += tests.length; p.ok += tests.filter(t => t.verdict === 'ok').length;
    for (const t of tests) {
      if (t.verdict !== 'warn' && t.verdict !== 'bad') continue;
      const key = `${t.title.split(' · ')[0]}|${orch}`;
      verdictCount[key] = verdictCount[key] || { ok: 0, warn: 0, bad: 0, none: 0 };
      verdictCount[key][t.verdict]++;
    }
  }
  // depolar: kabul ve oda turu hareketleri
  for (const a of src.ambarRecords.filter(x => inRange(x.acceptanceDate || x.timestamp, fromDate))) {
    const p = place(depotName(a.warehouse), 'Depo');
    p.moves += 1 + (a.storageChecks || []).length + (a.roomMovements || []).length;
  }
  for (const rc of src.roomChecks.filter(x => inRange(x.at, fromDate))) place(depotName(rc.warehouse), 'Depo').moves += rc.entries.length;
  // aktlar: partinin bahçesine, yoksa olayın yerine
  const refOrch = new Map(src.references.map(r => [r.refId, canonicalOrchard(r.orchard || r.location || '')]));
  for (const i of src.incidentRecords.filter(x => inRange(x.incidentDate || x.timestamp, fromDate))) {
    const name = refOrch.get(i.refId) || i.location || 'Yer yazılmamış';
    const row = [...places.values()].find(p => p.name === name) || place(name, 'Bahçe');
    row.akts++;
  }
  for (const p of places.values()) {
    const quality = p.tests ? p.ok / p.tests : 1;
    const complete = p.lots ? p.withTest / p.lots : 1;
    const aktRate = p.moves ? Math.min(1, (p.akts / p.moves) * 10) : 0;
    p.score = Math.round(quality * 55 + complete * 25 + (1 - aktRate) * 20);
  }

  // kişiler
  const dept = new Map(src.users.map(u => [u.fullName, u.company]));
  const people = new Map<string, PersonRow>();
  const full = src.users.map(u => u.fullName).filter(Boolean);
  const canon = (n: string) => { const m = n.trim().match(/^(\S+)\s+(\S)\.?$/); if (!m) return n.trim(); const hit = full.filter(f => f.split(/\s+/)[0] === m[1] && (f.split(/\s+/)[1] || '').startsWith(m[2])); return hit.length === 1 ? hit[0] : n.trim(); };
  const person = (n: string) => { const k = canon(n); if (!people.has(k)) people.set(k, { name: k, dept: dept.get(k) || '—', records: 0, edits: 0, deletes: 0 }); return people.get(k)!; };
  for (const l of src.logs.filter(x => inRange(x.timestamp, fromDate))) {
    if (!l.userName) continue;
    const p = person(l.userName);
    if (l.action === 'CREATE_RECORD') p.records++;
    else if (l.action === 'UPDATE_RECORD') p.edits++;
    else if (l.action === 'DELETE_RECORD') p.deletes++;
    else continue;
    if (!p.last || l.timestamp > p.last) { p.last = l.timestamp; p.lastWhat = [l.refId, l.details].filter(Boolean).join(' · ').slice(0, 80); }
  }
  // kayıtlardaki operatör adları (log tutulmamış eski kayıtlar için)
  const ops: [string | undefined, string | undefined][] = [
    ...src.harvestRecords.map(h => [h.operator, h.recordDate || h.timestamp] as [string, string]),
    ...src.ambarRecords.map(a => [a.operator, a.acceptanceDate || a.timestamp] as [string, string]),
    ...src.fieldRecords.map(f => [f.operator, f.timestamp] as [string, string]),
    ...src.muzRecords.map(m => [m.operator, m.timestamp] as [string, string]),
    ...src.bademRecords.map(b => [b.operator, b.timestamp] as [string, string]),
    ...src.roomChecks.map(r => [r.by, r.at] as [string, string]),
  ];
  const fromLogs = new Set([...people.values()].filter(p => p.records).map(p => p.name));
  for (const [op, at] of ops) {
    if (!op || !inRange(at, fromDate) || fromLogs.has(op.trim())) continue;
    const p = person(op); p.records++;
    if (!p.last || (at || '') > p.last) p.last = at;
  }

  // kritik noktalar
  const crit: CriticalRow[] = Object.entries(verdictCount).map(([k, v]) => {
    const [label, where] = k.split('|');
    return { label, where, count: v.warn + v.bad, level: v.bad ? 'high' : 'mid' } as CriticalRow;
  });
  const setOut = new Map<string, number>(), calib = new Map<string, number>();
  for (const rc of src.roomChecks.filter(x => inRange(x.at, fromDate))) for (const e of rc.entries) {
    const lo = e.setMinC ?? e.setMaxC, hi = e.setMaxC ?? e.setMinC;
    if (e.monitorC !== undefined && lo !== undefined && hi !== undefined && (e.monitorC < lo - 1 || e.monitorC > hi + 1)) setOut.set(e.roomName, (setOut.get(e.roomName) || 0) + 1);
    if (calibrationGap(e)) calib.set(e.roomName, (calib.get(e.roomName) || 0) + 1);
  }
  if (setOut.size) crit.push({ label: 'Oda set dışı', where: [...setOut.keys()].slice(0, 4).join(', '), count: [...setOut.values()].reduce((a, b) => a + b, 0), level: 'high' });
  if (calib.size) crit.push({ label: 'Monitör–cihaz farkı ≥ 2 °C', where: [...calib.keys()].slice(0, 4).join(', '), count: [...calib.values()].reduce((a, b) => a + b, 0), level: 'mid' });
  const byType = new Map<string, number>();
  for (const i of src.incidentRecords.filter(x => inRange(x.incidentDate || x.timestamp, fromDate))) byType.set(i.incidentType || 'Diğer', (byType.get(i.incidentType || 'Diğer') || 0) + 1);
  for (const [t, n] of byType) crit.push({ label: `Akt: ${t}`, where: '', count: n, level: n >= 3 ? 'high' : 'mid' });

  return {
    places: [...places.values()].filter(p => p.moves || p.lots || p.akts).sort((a, b) => b.moves - a.moves),
    people: [...people.values()].sort((a, b) => b.records + b.edits - (a.records + a.edits)),
    critical: crit.sort((a, b) => (a.level === b.level ? b.count - a.count : a.level === 'high' ? -1 : 1)),
  };
}
