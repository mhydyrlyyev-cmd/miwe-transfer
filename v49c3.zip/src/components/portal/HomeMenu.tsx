import { OnionIcon, PotatoIcon } from '../common/CropIcons';
import React, { useMemo } from 'react';
import { useLocationProfiles } from '../../services/locationProfiles';
import { calibrationStatus } from '../../config/calibrationRules';
import {
  Leaf, Snowflake, Warehouse, Truck, Search, FlaskConical, ShieldAlert, Banana, Nut, Wind, ShoppingCart, Globe2,
  BarChart3, FileText, BookOpen, ListChecks, CalendarRange, MapPin, HelpCircle, History, Users, AlertTriangle, ArrowRight, Wifi, WifiOff, LayoutDashboard,
  ScanLine, Tags, Images, MessageSquarePlus, BookCheck, Thermometer, ClipboardCheck,
} from 'lucide-react';
import type { ReferenceItem } from '../../types';
import type { AppUser } from '../../types/auth';
import type { StageKey } from '../../config/processStages';
import { lifecycleCounts } from '../../utils/refLifecycle';

/**
 * v49c — Menü (alt menüdeki "Menü"): Kayıt · Testler · Takvim · Raporlar · Yönetim.
 * Simgeli satırlar; aşama sayıları ve bugün bakılacaklar Ana sayfada.
 */
interface Props {
  currentUser?: AppUser | null;
  references: ReferenceItem[];
  isOnline: boolean;
  pendingCount: number;
  alertCount: number;
  stageBadges: Partial<Record<StageKey, number>>;
  onNavigate: (view: string, tab?: string) => void;
  onOpenSearch: () => void;
  onOpenUsers?: () => void;
}


type Item = { label: string; view: string; tab?: string; icon: React.ReactNode; tone: string; badge?: string; adminOnly?: boolean };
const I = (c: string) => `w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${c}`;
const T = {
  em: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300', sk: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300',
  vi: 'bg-violet-50 text-violet-700 dark:bg-violet-950/50 dark:text-violet-300', in: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300',
  am: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', ye: 'bg-yellow-50 text-yellow-700 dark:bg-yellow-950/50 dark:text-yellow-300',
  or: 'bg-orange-50 text-orange-800 dark:bg-orange-950/50 dark:text-orange-300', ro: 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300',
  sl: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', cy: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300',
};

export default function HomeMenu(p: Props) {
  // v49b: kalibrasyonu geciken / kalan cihazlar
  const devices = useLocationProfiles('DEVICE');
  const devLate = devices.filter(d => { const st = calibrationStatus(d.fields); return st.overdue || st.failed; }).length;
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);
  const isAdmin = p.currentUser?.role === 'ADMIN';

  /** v49c — Menü: dört başlık, simgeli satırlar; aşama sayıları ve uyarılar Ana sayfada */
  const groups: [string, Item[]][] = [
    ['Kayıt', [
      { label: 'Günlük hasat', view: 'HARVEST', icon: <Leaf className="w-4 h-4" />, tone: T.em },
      { label: 'Ön soğutma fişi', view: 'PRECOOLING', icon: <Snowflake className="w-4 h-4" />, tone: T.sk },
      { label: 'Sortlama ve paketleme', view: 'SORTING_STATUS', icon: <ListChecks className="w-4 h-4" />, tone: T.vi },
      { label: 'Depo kabul', view: 'AMBAR', icon: <Warehouse className="w-4 h-4" />, tone: T.in },
      { label: 'Depolar · oda turu', view: 'COLD_STORAGE', icon: <Thermometer className="w-4 h-4" />, tone: T.in, badge: life.DEPODA ? `${life.DEPODA} parti` : undefined },
      { label: 'Sevk kaydı', view: 'LOJISTIK', icon: <Truck className="w-4 h-4" />, tone: T.am },
      { label: 'Satış', view: 'SALES', icon: <ShoppingCart className="w-4 h-4" />, tone: T.am },
      { label: 'Akt / olay', view: 'INCIDENT', icon: <ShieldAlert className="w-4 h-4" />, tone: T.ro },
      { label: 'Toplu QR tarama', view: '__BATCH_SCAN', icon: <ScanLine className="w-4 h-4" />, tone: T.sl },
    ]],
    ['Testler', [
      { label: 'Saha testi (meyve)', view: 'FIELD', icon: <FlaskConical className="w-4 h-4" />, tone: T.em },
      { label: 'Muz', view: 'MUZ', icon: <Banana className="w-4 h-4" />, tone: T.ye },
      { label: 'Badem', view: 'BADEM', icon: <Nut className="w-4 h-4" />, tone: T.or },
      { label: 'İhracat numunesi', view: 'EXPORT_SAMPLE', icon: <Globe2 className="w-4 h-4" />, tone: T.sl },
      { label: 'Freeze-dry', view: 'FREEZE_DRY', icon: <Wind className="w-4 h-4" />, tone: T.cy },
      { label: 'Soğan, patates ve diğer', view: 'FIELD', icon: <span className="inline-flex -space-x-1"><OnionIcon className="w-4 h-4" /><PotatoIcon className="w-4 h-4" /></span>, tone: T.sl },
    ]],
    ['Takvim ve akışlar', [
      { label: 'Hasat takvimi', view: 'HARVEST_CALENDAR', icon: <CalendarRange className="w-4 h-4" />, tone: T.em },
      { label: 'Muz akışı', view: '__FLOW_MUZ', icon: <Banana className="w-4 h-4" />, tone: T.ye },
      { label: 'Badem akışı', view: '__FLOW_BADEM', icon: <Nut className="w-4 h-4" />, tone: T.or },
    ]],
    ['Raporlar', [
      { label: 'Bugün yapılacaklar', view: 'TODAY', icon: <ClipboardCheck className="w-4 h-4" />, tone: T.sl },
      { label: 'Partiler ve testler', view: 'LOTS', icon: <ListChecks className="w-4 h-4" />, tone: T.sl },
      { label: 'Rapor merkezi', view: 'REPORTS', icon: <BarChart3 className="w-4 h-4" />, tone: T.sl },
      { label: 'Kalite raporu', view: 'REPORTING_PORTAL', tab: 'quality', icon: <FileText className="w-4 h-4" />, tone: T.sl },
      { label: 'Aylık rapor (PDF)', view: 'MONTHLY_REPORT', icon: <FileText className="w-4 h-4" />, tone: T.sl },
      { label: 'İzlenebilirlik defteri', view: 'TRACEABILITY_LEDGER', icon: <BookOpen className="w-4 h-4" />, tone: T.sl },
      { label: 'Uyarılar', view: 'ALERTS', icon: <AlertTriangle className="w-4 h-4" />, tone: p.alertCount ? T.ro : T.sl, badge: p.alertCount ? String(p.alertCount) : undefined },
      { label: 'Bekleyen işlemler', view: 'PENDING', icon: <History className="w-4 h-4" />, tone: T.sl },
      { label: 'QR etiket sayfası (A4)', view: '__LABELS', icon: <Tags className="w-4 h-4" />, tone: T.sl },
    ]],
    ['Yönetim', [
      { label: 'Profiller (bahçe · sera · depo · oda · cihaz)', view: '__PROFILES', icon: <MapPin className="w-4 h-4" />, tone: devLate ? T.ro : T.sl, badge: devLate ? `${devLate} cihaz gecikti` : undefined },
      { label: 'Standart kataloğu', view: '__STANDARDS', icon: <BookCheck className="w-4 h-4" />, tone: T.sl },
      { label: 'Görsel standartlar', view: '__VISUAL_STANDARDS', icon: <Images className="w-4 h-4" />, tone: T.sl },
      { label: 'Senkron', view: '__SYNC', icon: p.isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />, tone: p.isOnline && !p.pendingCount ? T.sl : T.am, badge: !p.isOnline ? 'çevrimdışı' : p.pendingCount ? `${p.pendingCount} bekliyor` : undefined },
      { label: 'Yönetici masası', view: 'ADMIN_DESK', icon: <LayoutDashboard className="w-4 h-4" />, tone: T.sl, adminOnly: true },
      { label: 'Yönetim analizi', view: 'MGMT_ANALYSIS', icon: <BarChart3 className="w-4 h-4" />, tone: T.sl, adminOnly: true },
      { label: 'Denetim izi', view: 'AUDIT_TRAIL', icon: <History className="w-4 h-4" />, tone: T.sl, adminOnly: true },
      { label: 'Rehber ve sorular', view: 'GUIDE_PORTAL', icon: <HelpCircle className="w-4 h-4" />, tone: T.sl },
      { label: 'Geri bildirim', view: 'FEEDBACK', icon: <MessageSquarePlus className="w-4 h-4" />, tone: T.sl },
    ]],
  ];

  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-3">
      <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Menü</h1>
      <button type="button" onClick={p.onOpenSearch}
        className="w-full flex items-center gap-3 min-h-[48px] px-4 rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-left text-slate-500 dark:text-slate-400 cursor-pointer hover:border-slate-400">
        <Search className="w-5 h-5" /><span className="text-[15px]">RefID, bahçe veya ürün ara…</span>
      </button>
      {groups.map(([title, items]) => (
        <section key={title} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5">
          <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400 pt-1.5 pb-1">{title}</h2>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {items.filter(it => !it.adminOnly || isAdmin).map(it => (
              <li key={it.label}>
                <button type="button" onClick={() => p.onNavigate(it.view, it.tab)} className="w-full flex items-center justify-between gap-3 min-h-[48px] py-1.5 text-left cursor-pointer">
                  <span className="flex items-center gap-3 min-w-0"><span className={I(it.tone)}>{it.icon}</span><span className="text-sm text-slate-900 dark:text-slate-100 truncate">{it.label}</span></span>
                  <span className="flex items-center gap-2 shrink-0">{it.badge && <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-full px-2 py-0.5">{it.badge}</span>}<ArrowRight className="w-4 h-4 text-slate-300" /></span>
                </button>
              </li>
            ))}
            {title === 'Yönetim' && isAdmin && p.onOpenUsers && (
              <li>
                <button type="button" onClick={p.onOpenUsers} className="w-full flex items-center justify-between gap-3 min-h-[48px] py-1.5 text-left cursor-pointer">
                  <span className="flex items-center gap-3"><span className={I(T.sl)}><Users className="w-4 h-4" /></span><span className="text-sm text-slate-900 dark:text-slate-100">Kullanıcılar ve onaylar</span></span>
                  <ArrowRight className="w-4 h-4 text-slate-300" />
                </button>
              </li>
            )}
          </ul>
        </section>
      ))}
    </div>
  );
}
