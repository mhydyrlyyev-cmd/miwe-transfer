import React, { useMemo } from 'react';
import { Search, Bell, Thermometer, ClipboardCheck, AlertTriangle, Wrench, ChevronRight, Wifi, WifiOff } from 'lucide-react';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord, IncidentRecord, ExportSampleRecord } from '../../types';
import type { AppUser } from '../../types/auth';
import { analyzeColdChain } from '../../utils/coldChainEngine';
import { ALERT_STAGE, STAGE_BY_KEY } from '../../config/processStages';
import { lifecycleCounts } from '../../utils/refLifecycle';
import { useLocationProfiles } from '../../services/locationProfiles';
import { calibrationStatus } from '../../config/calibrationRules';
import { storedLots, summarizeDepots, useRoomChecks, roomCode, setLabel, fmtC, tons } from '../../services/depots';

/**
 * v49c — Ana sayfa: 1) bugün bakılacaklar (eylem düğmeli) 2) akış (5 aşama) 3) depo doluluğu 4) bu hafta.
 * Uzun açıklama ve grafik yok; her satır bir işe götürür. Ayrıntı Rapor merkezinde.
 */
interface Props {
  currentUser?: AppUser | null;
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  incidentRecords: IncidentRecord[];
  testCountThisWeek: number;
  isOnline: boolean;
  pendingCount: number;
  alertCount: number;
  onNavigate: (view: string) => void;
  onOpenDepot: (target: { depotId?: string; roomId?: string; tour?: boolean }) => void;
  onOpenSearch: () => void;
  onOpenAlerts: () => void;
  onOpenProfiles: () => void;
  /** v49c2: uyarı satırı partinin sayfasını açar */
  onOpenLot?: (refId: string) => void;
  /** v49c3: şahit numune 7. ve 14. gün hatırlatması */
  exportSampleRecords?: ExportSampleRecord[];
}

export type Todo = { id: string; level: 'bad' | 'warn' | 'info'; title: string; detail: string; action: string; run: () => void };

const STAGES = [
  { key: 'HASAT', label: 'Hasat', view: 'HARVEST_STATUS', cls: 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-900 dark:text-emerald-200' },
  { key: 'ON_SOGUTMA', label: 'Ön soğ.', view: 'PRECOOLING', cls: 'border-sky-200 bg-sky-50 text-sky-800 dark:bg-sky-950/40 dark:border-sky-900 dark:text-sky-200' },
  { key: 'SORTING', label: 'Sortlama', view: 'SORTING_STATUS', cls: 'border-violet-200 bg-violet-50 text-violet-800 dark:bg-violet-950/40 dark:border-violet-900 dark:text-violet-200' },
  { key: 'SOGUK_DEPO', label: 'Depo', view: 'COLD_STORAGE', cls: 'border-indigo-200 bg-indigo-50 text-indigo-800 dark:bg-indigo-950/40 dark:border-indigo-900 dark:text-indigo-200' },
  { key: 'SEVK', label: 'Sevk', view: 'TRANSIT', cls: 'border-amber-200 bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:border-amber-900 dark:text-amber-200' },
] as const;

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return 'İyi geceler';
  if (h < 12) return 'Günaydın';
  if (h < 18) return 'İyi günler';
  return 'İyi akşamlar';
}
const weekStart = () => { const d = new Date(); const day = (d.getDay() + 6) % 7; d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - day); return d.toISOString().slice(0, 10); };

type TodoInput = Pick<Props, 'references' | 'harvestRecords' | 'ambarRecords' | 'lojistikRecords' | 'salesRecords' | 'incidentRecords' | 'onNavigate' | 'onOpenDepot' | 'onOpenProfiles' | 'onOpenLot' | 'exportSampleRecords'>;

/** v49c2: ana sayfa ve "Bugün yapılacaklar" aynı listeyi kullanır */
export function useHomeData(p: TodoInput) {
  useLocationProfiles();
  const devices = useLocationProfiles('DEVICE');
  const checks = useRoomChecks();
  const summary = useMemo(() => analyzeColdChain({ references: p.references, harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords, lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords }),
    [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);
  const lots = useMemo(() => storedLots(p), [p.ambarRecords, p.references, p.lojistikRecords, p.salesRecords, checks]);
  const depots = useMemo(() => summarizeDepots(lots, checks), [lots, checks]);
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);

  // ── Akış: aşama başına parti ve kg ──
  const flow = useMemo(() => {
    const live = p.references.filter(r => !r.archived);
    const pre = live.filter(r => r.status === 'CREATED' && (r.precoolingSlips || []).length > 0);
    const sorting = live.filter((r: any) => {
      const slips = (r.precoolingSlips || []) as any[];
      if (!slips.some(s => s.inspectionMode === 'SORTING' || s.packedKg || s.culledKg)) return false;
      const net = slips.reduce((a, s) => a + (Number(s.netKg) || 0), 0);
      const done = slips.reduce((a, s) => a + (Number(s.packedKg) || 0) + (Number(s.culledKg) || 0), 0);
      return net === 0 || done < net * 0.98;
    });
    const kgOf = (list: ReferenceItem[]) => list.reduce((s, r) => s + (Number(r.quantity) || 0), 0);
    return {
      HASAT: { n: Math.max(0, life.SAHADA - pre.length), kg: Math.max(0, life.kg.SAHADA - kgOf(pre)) },
      ON_SOGUTMA: { n: pre.length, kg: kgOf(pre) },
      SORTING: { n: sorting.length, kg: kgOf(sorting) },
      SOGUK_DEPO: { n: life.DEPODA, kg: depots.reduce((s, d) => s + d.kg, 0) || life.kg.DEPODA },
      SEVK: { n: life.YOLDA, kg: life.kg.YOLDA },
    } as Record<string, { n: number; kg: number }>;
  }, [p.references, life, depots]);

  // ── Bugün bakılacaklar ──
  const todos = useMemo(() => {
    const t: Todo[] = [];
    for (const d of depots) {
      for (const r of d.rooms) {
        if (r.status !== 'bad' && r.status !== 'warn') continue;
        t.push({ id: `room-${r.room.id}`, level: r.status === 'bad' ? 'bad' : 'warn', title: `${String(d.depot.fields?.shortName || d.depot.name)} · ${roomCode(r.room)}`,
          detail: `Son ölçüm ${fmtC(r.reading?.monitorC)} °C · set ${setLabel(r.room)}`, action: 'Odaya git', run: () => p.onOpenDepot({ depotId: d.depot.id, roomId: r.room.id }) });
      }
    }
    for (const d of depots) {
      if (d.rooms.length < 3 && d.lots === 0) continue; // küçük ve boş depoya her gün tur önerilmez
      if (d.checkedToday >= d.rooms.length) continue;
      t.push({ id: `tour-${d.depot.id}`, level: 'info', title: `Oda kontrol turu · ${String(d.depot.fields?.shortName || d.depot.name)}`,
        detail: `${d.checkedToday} / ${d.rooms.length} oda girildi`, action: d.checkedToday ? 'Devam' : 'Başla', run: () => p.onOpenDepot({ depotId: d.depot.id, tour: true }) });
    }
    const testRefs = new Set(lots.filter(l => !l.depot && !l.exited).map(l => l.a.refId)); // profili olmayan depo = deneme
    for (const a of summary.alerts.filter(x => !testRefs.has(x.refId)).slice(0, 6)) {
      const sk = ALERT_STAGE[a.kind];
      const def = STAGE_BY_KEY[sk];
      t.push({ id: a.id, level: a.level === 'critical' ? 'bad' : a.level === 'warning' ? 'warn' : 'info', title: `${a.refId} · ${a.title}`, detail: a.detail,
        action: p.onOpenLot ? 'Partiyi aç' : def.short, run: () => (p.onOpenLot ? p.onOpenLot(a.refId) : p.onNavigate(def.monitorView || def.entryView)) });
    }
    // v49c3: şahit numune — ilk ölçümden sonra 7. ve 14. gün ölçümü
    const byRef = new Map<string, ExportSampleRecord[]>();
    for (const r of p.exportSampleRecords || []) { if (!r.refId) continue; const a = byRef.get(r.refId) || []; a.push(r); byRef.set(r.refId, a); }
    for (const [refId, rs] of byRef) {
      const dates = rs.map(r => String(r.testDate || r.timestamp || '').slice(0, 10)).filter(Boolean).sort();
      if (!dates.length) continue;
      const day = Math.floor((Date.now() - new Date(dates[0]).getTime()) / 86400000);
      if (day > 30) continue;
      const need = day >= 14 && rs.length < 3 ? 14 : day >= 7 && rs.length < 2 ? 7 : 0;
      if (!need) continue;
      t.push({ id: `sahit-${refId}`, level: day >= need + 2 ? 'warn' : 'info', title: `${refId} · şahit numune ${need}. gün`,
        detail: `İlk ölçüm ${dates[0].split('-').reverse().join('.')} · bugün ${day}. gün · ${rs.length} ölçüm var`,
        action: p.onOpenLot ? 'Partiyi aç' : 'Testler', run: () => (p.onOpenLot ? p.onOpenLot(refId) : p.onNavigate('LOTS')) });
    }
    const late = devices.filter(dv => { const st = calibrationStatus(dv.fields); return st.overdue || st.failed; });
    if (late.length) t.push({ id: 'cal', level: 'warn', title: `Kalibrasyon: ${late.length} cihaz`, detail: late.slice(0, 2).map(x => x.name).join(', '), action: 'Profiller', run: p.onOpenProfiles });
    const ord = { bad: 0, warn: 1, info: 2 };
    return t.sort((a, b) => ord[a.level] - ord[b.level]);
  }, [depots, summary, devices, lots, p]);

  // ── Bu hafta ──
  const ws = weekStart();
  const week = useMemo(() => ({
    harvest: p.harvestRecords.filter(h => (h.recordDate || h.timestamp || '').slice(0, 10) >= ws).reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0),
    ship: p.lojistikRecords.filter(l => (l.shipmentDate || '').slice(0, 10) >= ws).reduce((s, l) => s + (Number(l.weightKg) || 0), 0),
    incidents: p.incidentRecords.filter(i => !/RESOLVED|CLOSED|KAPAN|ÇÖZ/i.test(String(i.status || ''))).length,
  }), [p.harvestRecords, p.lojistikRecords, p.incidentRecords, ws]);

  return { todos, flow, depots, week };
}

export default function HomeDashboard(p: Props) {
  const { todos, flow, depots, week } = useHomeData(p);
  const first = (p.currentUser?.fullName || '').split(' ')[0];
  const today = new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  const shown = todos.slice(0, 7);
  const dot = { bad: 'bg-rose-600', warn: 'bg-amber-500', info: 'bg-sky-500' };
  const icon = (id: string) => id.startsWith('room-') ? <Thermometer className="w-4 h-4" /> : id.startsWith('tour-') ? <ClipboardCheck className="w-4 h-4" /> : id === 'cal' ? <Wrench className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />;

  return (
    <div className="max-w-5xl mx-auto space-y-3 sm:space-y-4 min-w-0">
      <header className="flex items-end justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">{today}</div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">{greeting()}{first ? `, ${first}` : ''}</h1>
        </div>
        <div className="flex gap-2 shrink-0">
          {(!p.isOnline || p.pendingCount > 0) && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900">{p.isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}{p.pendingCount ? `${p.pendingCount} bekliyor` : 'Çevrimdışı'}</span>
          )}
{/* v49c1: arama ve zil üst çubukta; burada tekrar yok */}
        </div>
      </header>

      <div className="grid gap-3 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        {/* 1) Bugün bakılacaklar */}
        <section className="min-w-0 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Bugün bakılacaklar</h2>
            <span className="text-xs text-slate-500 tabular-nums">{todos.length}</span>
          </div>
          {shown.length === 0 && <p className="py-5 text-center text-sm text-slate-500">Şu an bakılacak bir şey yok.</p>}
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {shown.map(t => (
              <li key={t.id}>
                <button type="button" onClick={t.run} className="w-full flex items-center justify-between gap-3 py-2.5 text-left cursor-pointer">
                  <span className="flex items-center gap-3 min-w-0">
                    <span className="relative w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0">{icon(t.id)}<span className={`absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${dot[t.level]}`} /></span>
                    <span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white truncate">{t.title}</span><span className="block text-xs text-slate-500 truncate">{t.detail}</span></span>
                  </span>
                  <span className="text-xs font-semibold text-teal-700 dark:text-teal-300 whitespace-nowrap">{t.action} ›</span>
                </button>
              </li>
            ))}
          </ul>
          {todos.length > shown.length && <button type="button" onClick={p.onOpenAlerts} className="mt-1 text-xs font-semibold text-teal-700 cursor-pointer">+{todos.length - shown.length} daha</button>}
        </section>

        <div className="space-y-3 min-w-0">
          {/* 2) Akış */}
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Akış · şu an</h2>
            <div className="grid grid-cols-5 gap-1 text-center">
              {STAGES.map(s => (
                <button key={s.key} type="button" onClick={() => p.onNavigate(s.view)} className={`rounded-xl border py-2 cursor-pointer active:scale-95 transition ${s.cls}`}>
                  <div className="text-lg font-bold tabular-nums">{flow[s.key].n}</div>
                  <div className="text-[10px] text-slate-600 dark:text-slate-300">{s.label}</div>
                  <div className="text-[10px] text-slate-500 tabular-nums">{flow[s.key].kg ? tons(flow[s.key].kg) : '—'}</div>
                </button>
              ))}
            </div>
          </section>

          {/* 3) Depolar */}
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Depolar</h2>
              <button type="button" onClick={() => p.onOpenDepot({})} className="text-xs font-semibold text-teal-700 dark:text-teal-300 cursor-pointer">Tümü ›</button>
            </div>
            {depots.length === 0 && <p className="text-sm text-slate-500">Depo profili yok.</p>}
            <ul className="space-y-2.5">
              {depots.map(d => {
                const w = d.pct ?? (d.kg > 0 ? 100 : 0);
                const barCls = d.pct === undefined ? 'bg-indigo-200 dark:bg-indigo-900' : w >= 90 ? 'bg-rose-600' : 'bg-indigo-600';
                return (
                  <li key={d.depot.id}>
                    <button type="button" onClick={() => p.onOpenDepot({ depotId: d.depot.id })} className="w-full text-left cursor-pointer">
                      <div className="flex justify-between text-xs mb-1 gap-2">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">{d.depot.name} <span className="font-normal text-slate-500">· {d.rooms.length} oda</span>{d.bad > 0 && <span className="ml-1 text-rose-700 font-semibold">· {d.bad} set dışı</span>}</span>
                        <span className="tabular-nums text-slate-600 dark:text-slate-300 shrink-0">{d.kg ? tons(d.kg) : 'boş'}{d.pct !== undefined ? ` · %${d.pct}` : ''}</span>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className={`h-full rounded-full ${barCls}`} style={{ width: `${w}%` }} /></div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>

          {/* 4) Bu hafta */}
          <section className="grid grid-cols-2 gap-2">
            {[['Bu hafta hasat', tons(week.harvest), 'HARVEST_STATUS'], ['Bu hafta sevk', tons(week.ship), 'TRANSIT'], ['Kalite testi', String(p.testCountThisWeek), 'LOTS'], ['Açık akt', String(week.incidents), 'ALERTS']].map(([a, b, v]) => (
              <button key={a} type="button" onClick={() => p.onNavigate(v)} className="text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 cursor-pointer">
                <div className="text-xs text-slate-500 flex items-center justify-between">{a}<ChevronRight className="w-3.5 h-3.5 text-slate-300" /></div>
                <div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div>
              </button>
            ))}
          </section>
        </div>
      </div>
    </div>
  );
}
