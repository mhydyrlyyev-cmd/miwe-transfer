# v40.1 — Sadeleştirme (ekran görüntüsü geri bildirimi)

Uygulama sırası: v40'tan SONRA. Dosyaları AYNEN (byte-identical) kopyala.
Firestore kuralı DEĞİŞMEDİ (DeployRules GEREKMEZ).

## Değişenler
1. Giriş sayfası: ürün simgeleri şeridi (meyve, muz, badem, soğan, patates) kaldırıldı; logo + 4 aşama kaldı.
2. Bildirim paneli: başlık 2 satır ("Bildirimler" + kapat / "+ Alarm · Tümünü okundu yap · Temizle");
   "+ Alarm" artık yazının üstüne binmiyor; büyük "ÇÖZÜLDÜ OLARAK İŞARETLE" yerine küçük "Çözüldü".
3. ☰ menüsü: Ana menüyü tekrar eden "Raporlar" ve gezinme düğmeleri (Ön soğutma, Yoldaki yükler,
   Soğuk depo, Saha galeri, Kılavuz, Tavsiye) kaldırıldı; "🏠 Portallar" → "Ana menü".
   Kalan: profil, bugün yapılacaklar, alarmlar, Ana menü, karanlık mod, eşitleme, Sistem (uygulama kur, yedek, Google Sheets).
4. Referanslar: "🍌 Muz Hasat & Kalite Kriterleri" ve "Stok Uyarıları" sade çerçeveli düğme ("Muz kriterleri",
   "Stok uyarıları"); "Excel / CSV İndir (10)" → "Excel (10)"; aşama kutularında kg kesilmiyor (27,3 t).
5. QR tarayıcı en üst katmanda (yukarı-kaydır düğmesi "Sevk" düğmesinin üstüne binmiyordu).
6. Etiket, toplu tarama ve herkese açık kartta "Meyve / Genel Ürün ()" → "Meyve / Genel Ürün".

## Dosyalar
src/components/auth/LoginView.tsx · src/components/Header.tsx · src/components/views/ReferencesView.tsx ·
src/components/common/QRScannerModal.tsx · src/utils/qrRef.ts · src/components/qr/LabelSheetModal.tsx ·
src/components/qr/BatchScanModal.tsx · src/services/publicRefs.ts

## Kabul testleri
1. Giriş sayfasında yalnız logo + 4 aşama simgesi; ürün simgeleri yok; giriş çalışıyor.
2. Zil → başlık iki satır, "+ Alarm" çakışmıyor; olay bildiriminde küçük "Çözüldü" düğmesi çalışıyor.
3. ☰ menüsünde Raporlar / Araçlar gezinme düğmeleri yok; "Ana menü" düğmesi Ana menüyü açıyor; Google Sheets ve yedek indir duruyor.
4. Referanslar başlığında "Muz kriterleri", "Stok uyarıları", "Excel (n)"; ikisi de bölümleri açıp kapatıyor.
5. Toplu QR tarama açıkken yukarı-kaydır düğmesi görünmüyor.
6. QR etiket listesinde "()" yok.
7. TypeScript derleme hatası yok.
