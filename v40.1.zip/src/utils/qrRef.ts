/**
 * v3.9.2 — QR içerik biçimi ve tarama çözümleyici.
 *
 * Yeni etiketler: platform linki  →  https://<site>/?ref=<RefID>
 *   - Telefon kamerası okutunca platform doğrudan açılır.
 * Tarayıcı üç biçimi de tanır (eski etiketler çalışmaya devam eder):
 *   1) link (?ref=… veya /r/…)   2) eski JSON etiket ({refId|ref|id})   3) düz RefID metni
 */

export const QR_PARAM = 'ref';
const PENDING_KEY = 'miwe_pending_ref';

export function buildRefQrUrl(refId: string): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return `${origin}/?${QR_PARAM}=${encodeURIComponent(refId)}`;
}

/** Okutulan metinden RefID çıkarır; bulunamazsa null. */
export function parseScannedRef(raw: string): string | null {
  const text = (raw || '').trim();
  if (!text) return null;

  // 1) Link
  if (/^https?:\/\//i.test(text)) {
    try {
      const u = new URL(text);
      const q = u.searchParams.get(QR_PARAM) || u.searchParams.get('refId');
      if (q) return q.trim();
      const m = u.pathname.match(/\/r\/([^/?#]+)/);
      if (m) return decodeURIComponent(m[1]).trim();
    } catch { /* geçersiz link — aşağıda düz metin olarak denenir */ }
  }

  // 2) Eski JSON etiket
  if (text.startsWith('{')) {
    try {
      const o = JSON.parse(text);
      const v = o.refId || o.ref || o.parentRefId || o.id;
      if (typeof v === 'string' && v.trim()) return v.trim();
    } catch { /* JSON değil */ }
  }

  // 3) Düz RefID (boşlukları ve görünmez karakterleri temizle)
  const plain = text.replace(/[​-‍﻿]/g, '').split(/\s+/)[0];
  return plain || null;
}

/** Açılış linkindeki ?ref= değerini alır, oturum için saklar ve adres çubuğundan siler. */
export function captureRefFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const u = new URL(window.location.href);
    const v = u.searchParams.get(QR_PARAM);
    if (v) {
      sessionStorage.setItem(PENDING_KEY, v.trim());
      u.searchParams.delete(QR_PARAM);
      window.history.replaceState(null, '', u.pathname + (u.search ? u.search : '') + u.hash);
    }
    return sessionStorage.getItem(PENDING_KEY);
  } catch {
    return null;
  }
}

export function clearPendingRef(): void {
  try { sessionStorage.removeItem(PENDING_KEY); } catch { /* yok say */ }
}

/** v4.0.1: eski kayıtlardaki "Meyve / Genel Ürün ()" gibi boş parantezleri temizler */
export function cleanName(v?: string): string {
  return String(v || '').replace(/\s*\(\s*\)\s*/g, ' ').replace(/\s{2,}/g, ' ').trim();
}
