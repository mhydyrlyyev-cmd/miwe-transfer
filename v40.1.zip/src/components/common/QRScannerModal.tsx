import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Camera, 
  Video, 
  AlertCircle, 
  Search, 
  RefreshCw, 
  Check, 
  QrCode, 
  Info 
} from 'lucide-react';
import jsQR from 'jsqr';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (refId: string) => void;
  /** v4.0: sürekli tarama (toplu palet okutma) — okutunca kapanmaz, aynı kodu 2,5 sn içinde tekrar saymaz */
  continuous?: boolean;
  title?: string;
  subtitle?: string;
  /** v4.0: kameranın altında gösterilecek içerik (ör. okutulan palet listesi) */
  footer?: React.ReactNode;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
  continuous = false,
  title,
  subtitle,
  footer,
}) => {
  const lastValueRef = useRef<{ v: string; t: number }>({ v: '', t: 0 });
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [manualRefId, setManualRefId] = useState<string>('');
  const [detectedRefId, setDetectedRefId] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const requestRef = useRef<number | null>(null);

  // Load available camera devices on mount
  useEffect(() => {
    if (!isOpen) return;

    const getCameras = async () => {
      try {
        const mediaDevices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = mediaDevices.filter(device => device.kind === 'videoinput');
        setDevices(videoDevices);
        
        if (videoDevices.length > 0) {
          // Default to environment (back) camera if found, else first camera
          const backCam = videoDevices.find(d => d.label.toLowerCase().includes('back') || d.label.toLowerCase().includes('environment'));
          setSelectedDeviceId(backCam ? backCam.deviceId : videoDevices[0].deviceId);
        }
      } catch (err) {
        console.error('Error listing video input devices:', err);
      }
    };

    getCameras();
  }, [isOpen]);

  // Start / Stop camera stream when modal opens/closes or selected device changes
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen, selectedDeviceId]);

  const startCamera = async () => {
    stopCamera();
    setErrorMsg(null);
    setDetectedRefId(null);
    setIsScanning(true);

    const constraints: MediaStreamConstraints = {
      video: selectedDeviceId 
        ? { deviceId: { exact: selectedDeviceId } } 
        : { facingMode: 'environment' }
    };

    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      setHasPermission(true);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true'); // iOS specific requirement
        videoRef.current.play().then(() => {
          // Start decoding frames
          requestRef.current = requestAnimationFrame(scanFrame);
        }).catch(err => {
          console.error("Video play failed:", err);
        });
      }
    } catch (err: any) {
      console.error('Camera access failed:', err);
      setHasPermission(false);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMsg('Tarayıcı kamera izni reddedildi. Lütfen adres çubuğundan kamera erişimine izin verin.');
      } else {
        setErrorMsg(`Kamera başlatılamadı: ${err.message || 'Bilinmeyen hata'}`);
      }
    }
  };

  const stopCamera = () => {
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
      requestRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const lastScanTimeRef = useRef<number>(0);

  const scanFrame = (timestamp: number) => {
    if (!isScanning) return;

    // Throttle decoding to at most every 120ms (~8-9 FPS) instead of 60fps
    if (timestamp - lastScanTimeRef.current >= 120) {
      lastScanTimeRef.current = timestamp;

      const video = videoRef.current;
      const canvas = canvasRef.current;

      if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          // Set canvas sizing equal to the actual video stream dimensions
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          
          // Draw video frame to hidden canvas
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          
          // Get raw pixel data from canvas
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          
          // Feed pixels into jsQR decoder
          const decoder = typeof jsQR === 'function' ? jsQR : (jsQR as any)?.default;
          const code = typeof decoder === 'function' 
            ? decoder(imageData.data, imageData.width, imageData.height, {
                inversionAttempts: 'dontInvert',
              })
            : null;

          if (code && code.data) {
            // Success! Code detected
            const scannedValue = code.data.trim();
            
            // Pattern checking: look for something resembling typical RefIDs: e.g. MUZ-20260912-001 or EXPORT-XXX
            // We will trigger a tactile feedback (vibration) and render detection status
            if (continuous) {
              // v4.0: toplu tarama — kamera açık kalır; aynı kod 2,5 sn içinde tekrar sayılmaz
              const now = Date.now();
              if (!(lastValueRef.current.v === scannedValue && now - lastValueRef.current.t < 2500)) {
                lastValueRef.current = { v: scannedValue, t: now };
                if (navigator.vibrate) navigator.vibrate(80);
                setDetectedRefId(scannedValue);
                onScanSuccess(scannedValue);
                setTimeout(() => setDetectedRefId(null), 900);
              } else {
                lastValueRef.current.t = now;
              }
              requestRef.current = requestAnimationFrame(scanFrame);
              return;
            }

            setIsScanning(false);
            setDetectedRefId(scannedValue);
            
            if (navigator.vibrate) {
              navigator.vibrate(150);
            }

            // Small delay for awesome visual feedback, then submit success
            setTimeout(() => {
              onScanSuccess(scannedValue);
              onClose();
            }, 800);
            return;
          }
        }
      }
    }

    // Keep scanning
    requestRef.current = requestAnimationFrame(scanFrame);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualRefId.trim()) {
      onScanSuccess(manualRefId.trim());
      if (continuous) setManualRefId('');
      else onClose();
    }
  };

  const cycleCamera = () => {
    if (devices.length <= 1) return;
    const currentIndex = devices.findIndex(d => d.deviceId === selectedDeviceId);
    const nextIndex = (currentIndex + 1) % devices.length;
    setSelectedDeviceId(devices[nextIndex].deviceId);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-in fade-in duration-200 overflow-hidden">
      <div 
        className="bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh] mx-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/40 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">{title || 'QR / Barkod Tarayıcı'}</h3>
              <p className="text-[10px] text-slate-400">{subtitle || 'Canlı kamera ile hızlı RefID arama'}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Viewfinder/Scanner Window */}
        <div className="p-5 flex-1 flex flex-col justify-center items-center relative overflow-y-auto min-h-[300px]">
          
          {hasPermission === false && (
            <div className="text-center p-6 bg-rose-950/30 border border-rose-500/30 rounded-2xl max-w-sm space-y-3">
              <AlertCircle className="w-10 h-10 text-rose-400 mx-auto" />
              <h4 className="text-xs font-bold text-rose-300">Kamera İzni Eksik</h4>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {errorMsg || 'QR kod tarayıcıyı kullanabilmek için kamera donanımına erişim vermeniz gerekmektedir.'}
              </p>
              <button 
                onClick={startCamera}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-black transition cursor-pointer"
              >
                Kamerayı Tekrar Dene
              </button>
            </div>
          )}

          {hasPermission === null && !errorMsg && (
            <div className="text-center p-6 space-y-3">
              <RefreshCw className="w-8 h-8 text-teal-400 animate-spin mx-auto" />
              <p className="text-xs text-slate-400">Kamera donanımı başlatılıyor...</p>
            </div>
          )}

          {hasPermission && (
            <div className="w-full flex flex-col items-center">
              {/* Viewfinder Wrapper */}
              <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl overflow-hidden border-2 border-slate-700 bg-black shadow-inner flex items-center justify-center">
                
                {/* HTML5 Video Layer */}
                <video 
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  muted
                  playsInline
                />

                {/* Offscreen Canvas for analysis */}
                <canvas ref={canvasRef} className="hidden" />

                {/* Viewfinder Overlay Reticle */}
                <div className="absolute inset-0 border-[24px] border-slate-900/60 pointer-events-none flex items-center justify-center">
                  <div className={`w-48 h-48 sm:w-56 sm:h-56 border-2 relative rounded-2xl transition-all duration-300 ${
                    detectedRefId 
                      ? 'border-emerald-400 bg-emerald-500/10' 
                      : 'border-teal-400/80'
                  }`}>
                    {/* Corners details */}
                    <div className="absolute -top-1 -left-1 w-4 h-4 border-t-4 border-l-4 border-teal-400 rounded-tl-md"></div>
                    <div className="absolute -top-1 -right-1 w-4 h-4 border-t-4 border-r-4 border-teal-400 rounded-tr-md"></div>
                    <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-4 border-l-4 border-teal-400 rounded-bl-md"></div>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-4 border-r-4 border-teal-400 rounded-br-md"></div>

                    {/* Animated Scanning Line */}
                    {isScanning && (
                      <div className="absolute left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-teal-400 to-transparent top-0 animate-scanner-line pointer-events-none" />
                    )}

                    {/* Success Checked Marker */}
                    {detectedRefId && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/80 animate-in zoom-in-95 duration-150 p-3 text-center">
                        <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 flex items-center justify-center mb-1">
                          <Check className="w-5 h-5" />
                        </div>
                        <span className="text-[11px] font-black text-emerald-300 uppercase tracking-wider">Kod Okundu!</span>
                        <span className="text-xs text-white font-mono mt-1 font-bold truncate max-w-full bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                          {detectedRefId}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Multi-Camera Switcher (only show if > 1 camera) */}
              {devices.length > 1 && !detectedRefId && (
                <button
                  onClick={cycleCamera}
                  className="mt-3.5 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-bold border border-slate-700 transition cursor-pointer active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Kamerayı Değiştir ({devices.length} Kamera)</span>
                </button>
              )}
            </div>
          )}

          {/* Quick Guidance */}
          <div className="mt-4 flex items-start gap-1.5 text-[10px] text-slate-400 max-w-xs mx-auto leading-relaxed">
            <Info className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
            <span>
              Herhangi bir sevkiyat kutusu, kantar fişi, analiz raporu veya koli üzerindeki 
              <strong> QR kodu / barkodu</strong> merceğe ortalayarak otomatik taratabilirsiniz.
            </span>
          </div>

        </div>

        {footer && <div className="shrink-0 max-h-[38vh] overflow-y-auto border-t border-slate-800 bg-slate-900">{footer}</div>}

        {/* Fallback Manual Entry Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 shrink-0">
          <form onSubmit={handleManualSubmit} className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              VEYA MANUEL REFERANS NO GİRİN
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="örn: MUZ-20260912-001..."
                  value={manualRefId}
                  onChange={(e) => setManualRefId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-white text-xs font-mono rounded-xl pl-8 pr-3 py-2.5 focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400 placeholder-slate-500"
                />
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-3" />
              </div>
              <button
                type="submit"
                disabled={!manualRefId.trim()}
                className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-40 disabled:hover:bg-teal-600 text-white text-xs font-black transition cursor-pointer shrink-0 shadow-md flex items-center gap-1"
              >
                <span>Sorgula</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
