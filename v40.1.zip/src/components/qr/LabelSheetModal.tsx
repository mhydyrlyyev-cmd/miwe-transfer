import React, { useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { X, Printer, Search, Loader2, Tags } from 'lucide-react';
import { ReferenceItem } from '../../types';
import { buildRefQrUrl, cleanName } from '../../utils/qrRef';

/**
 * v4.0 — A4 QR etiket sayfası (etiket yazıcısı gerekmez).
 * Partiler seçilir, A4 yapışkan etiket kâğıdına (3×8 = 24 veya 2×7 = 14 etiket) yazdırılır.
 * Her etikette platform linkli QR, RefID, ürün · çeşit, bahçe/sera ve tarih bulunur.
 */
interface Props {
  isOpen: boolean;
  references: ReferenceItem[];
  onClose: () => void;
}

const LAYOUTS = {
  '3x8': { cols: 3, rows: 8, w: 70, h: 37, qr: 30, label: '3 × 8 (70×37 mm, 24 etiket)' },
  '2x7': { cols: 2, rows: 7, w: 99.1, h: 38.1, qr: 32, label: '2 × 7 (99×38 mm, 14 etiket)' },
} as const;
type LayoutKey = keyof typeof LAYOUTS;

const esc = (s: string) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));
const dayOf = (iso?: string) => (iso ? String(iso).slice(0, 10) : '');

export const LabelSheetModal: React.FC<Props> = ({ isOpen, references, onClose }) => {
  const [q, setQ] = useState('');
  const [days, setDays] = useState(3);
  const [layout, setLayout] = useState<LayoutKey>('3x8');
  const [copies, setCopies] = useState(1);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const list = useMemo(() => {
    const cutoff = days > 0 ? Date.now() - days * 864e5 : 0;
    const qq = q.trim().toLowerCase();
    return references
      .filter(r => !(r as any).archived)
      .filter(r => !cutoff || Date.parse(r.createdAt || '') >= cutoff)
      .filter(r => !qq || [r.refId, r.product, r.variety, r.orchard, r.greenhouse, r.location].some(v => String(v || '').toLowerCase().includes(qq)))
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
      .slice(0, 300);
  }, [references, q, days]);

  if (!isOpen) return null;

  const toggle = (id: string) => setSel(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const allOn = list.length > 0 && list.every(r => sel.has(r.refId));
  const toggleAll = () => setSel(s => { const n = new Set(s); list.forEach(r => (allOn ? n.delete(r.refId) : n.add(r.refId))); return n; });

  const print = async () => {
    const chosen = references.filter(r => sel.has(r.refId));
    if (!chosen.length) return;
    setBusy(true);
    try {
      const L = LAYOUTS[layout];
      const cells: string[] = [];
      for (const r of chosen) {
        const qr = await QRCode.toDataURL(buildRefQrUrl(r.refId), { width: 300, margin: 0, errorCorrectionLevel: 'M' });
        const title = [cleanName(r.product), cleanName(r.sortVariety || r.variety)].filter(Boolean).join(' · ');
        const place = r.greenhouse || r.orchard || r.location || '';
        const cell = `<div class="lb"><img src="${qr}" alt=""/><div class="tx"><div class="t">${esc(title)}</div><div class="id">${esc(r.refId)}</div><div class="m">${esc(place)}</div><div class="m">${esc(dayOf(r.createdAt))}</div><div class="b">MIWE HIL</div></div></div>`;
        for (let c = 0; c < Math.max(1, copies); c++) cells.push(cell);
      }
      const per = L.cols * L.rows;
      const pages: string[] = [];
      for (let i = 0; i < cells.length; i += per) pages.push(`<div class="pg">${cells.slice(i, i + per).join('')}</div>`);
      const mx = (210 - L.cols * L.w) / 2;
      const my = (297 - L.rows * L.h) / 2;
      const html = `<!doctype html><html><head><meta charset="utf-8"><title>MIWE HIL etiketler</title><style>
@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;color:#0f172a}
.pg{width:210mm;height:297mm;padding:${my.toFixed(1)}mm ${mx.toFixed(1)}mm;display:grid;grid-template-columns:repeat(${L.cols},${L.w}mm);grid-auto-rows:${L.h}mm;page-break-after:always;overflow:hidden}
.lb{display:flex;align-items:center;gap:2.5mm;padding:2.5mm 3mm;overflow:hidden}
.lb img{width:${L.qr}mm;height:${L.qr}mm;flex:none}
.tx{min-width:0;line-height:1.15}.t{font-weight:800;font-size:9.5pt}.id{font-family:'JetBrains Mono',Consolas,monospace;font-weight:700;font-size:7.5pt;word-break:break-all;margin:1mm 0}
.m{font-size:7pt;color:#334155}.b{margin-top:1mm;font-size:6pt;font-weight:800;letter-spacing:.12em;color:#0F3D2E}
</style></head><body>${pages.join('')}<script>window.onload=function(){setTimeout(function(){window.print()},300)}<\/script></body></html>`;
      const w = window.open('', '_blank');
      if (!w) { alert('Yazdırma penceresi açılamadı. Tarayıcıda açılır pencere iznini verin.'); return; }
      w.document.open(); w.document.write(html); w.document.close();
    } finally {
      setBusy(false);
    }
  };

  const L = LAYOUTS[layout];
  const total = sel.size * Math.max(1, copies);
  const pagesNeeded = Math.ceil(total / (L.cols * L.rows));

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full sm:max-w-2xl max-h-[92vh] flex flex-col bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl" onClick={e => e.stopPropagation()} role="dialog" aria-label="QR etiket sayfası">
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center"><Tags className="w-5 h-5" /></span>
            <div>
              <div className="font-bold text-slate-900 dark:text-white">QR etiket sayfası (A4)</div>
              <div className="text-xs text-slate-500">Etiket yazıcısı gerekmez; A4 yapışkan etiket kâğıdına yazdırın.</div>
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Kapat"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-5 py-3 grid grid-cols-1 sm:grid-cols-3 gap-2 border-b border-slate-100 dark:border-slate-800">
          <label className="relative sm:col-span-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, ürün, bahçe…" className="w-full min-h-[40px] pl-9 pr-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
          </label>
          <select value={days} onChange={e => setDays(Number(e.target.value))} className="min-h-[40px] px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm">
            <option value={1}>Son 1 gün</option><option value={3}>Son 3 gün</option><option value={7}>Son 7 gün</option><option value={30}>Son 30 gün</option><option value={0}>Tümü</option>
          </select>
          <select value={layout} onChange={e => setLayout(e.target.value as LayoutKey)} className="min-h-[40px] px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm">
            {Object.entries(LAYOUTS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>

        <div className="px-5 py-2 flex items-center justify-between text-sm">
          <label className="inline-flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={allOn} onChange={toggleAll} className="w-4 h-4" /> Listedekilerin tümü ({list.length})</label>
          <label className="inline-flex items-center gap-2">Her partiden
            <input type="number" min={1} max={24} value={copies} onChange={e => setCopies(Math.max(1, Math.min(24, Number(e.target.value) || 1)))} className="w-16 min-h-[36px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" /> adet
          </label>
        </div>

        <ul className="flex-1 overflow-y-auto px-5 pb-3 space-y-1.5">
          {list.map(r => (
            <li key={r.refId}>
              <label className={`flex items-center gap-3 px-3 py-2 rounded-xl border cursor-pointer ${sel.has(r.refId) ? 'border-emerald-400 bg-emerald-50/60 dark:bg-emerald-950/30' : 'border-slate-200 dark:border-slate-800'}`}>
                <input type="checkbox" checked={sel.has(r.refId)} onChange={() => toggle(r.refId)} className="w-4 h-4" />
                <span className="min-w-0 flex-1">
                  <span className="block font-mono text-xs font-bold text-slate-900 dark:text-white truncate">{r.refId}</span>
                  <span className="block text-xs text-slate-500 truncate">{[cleanName(r.product), cleanName(r.sortVariety || r.variety), cleanName(r.greenhouse || r.orchard || r.location), dayOf(r.createdAt)].filter(Boolean).join(' · ')}</span>
                </span>
              </label>
            </li>
          ))}
          {list.length === 0 && <li className="py-10 text-center text-sm text-slate-500">Bu filtrede parti yok.</li>}
        </ul>

        <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500">{total} etiket · {pagesNeeded || 0} sayfa</div>
          <button type="button" disabled={!sel.size || busy} onClick={print}
            className="inline-flex items-center gap-2 min-h-[46px] px-5 rounded-xl bg-[#0F3D2E] hover:bg-[#0b2f23] disabled:opacity-40 text-white font-bold cursor-pointer">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />} Yazdır
          </button>
        </div>
      </div>
    </div>
  );
};

export default LabelSheetModal;
