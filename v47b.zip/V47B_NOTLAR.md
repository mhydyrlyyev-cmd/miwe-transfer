# v47b — Kayıt uyarısı, rapor birleştirme, ürün kabul kartı

## Neden
- Depo kabulde "Kaydet" sessiz kalıyordu: zorunlu alan boşken uyarı window.alert ile veriliyordu; AI Studio önizlemesi (iframe) alert'i engeller. Artık tüm alert'ler ekranda bildirim (toast) olarak çıkar.
- Sahte IoT simülatörü (gerçek cihaz yok) kaldırıldı; bilimsel makale butonları kaldırıldı.
- Rapor kutuları aynı ekrana gidiyordu (Aylık yönetim özeti, İstatistik analizi, Standartlar kılavuzu). Tek "Kalite raporu" + "Aylık rapor (PDF)" kaldı.
- Standart kataloğunda her ürün için kabul kartı: UNECE/OECD şartı, iç hedef, MIWE sınıfları (Extra/Exclusive/Premium ihracat; Classic/Mix tonaja girer; Standart dışı girmez).

## Dosyalar (13) + 1 silme
SİL: src/components/iot/IoTDataloggerConnector.tsx (artık kimse import etmiyor)

## SHA-256
11951bd488860456c49db37a2328cbd338273291b12b48b265104dbf40d21f56  src/App.tsx
6b7c3c2b27641b39c78bd432e3d1237dccf8e9d092dc1dbd3908e1a5a862a589  src/components/Header.tsx
5f60d2752a87dab80409c441836418083224fb75c02805d23d97ac0cdfef5a87  src/components/forms/AmbarForm.tsx
513d5a7377d07085b32a0ff12b82f7cac1a6ec7e1e4f28658178a38c63aec1a5  src/components/forms/ExportSampleForm.tsx
6e0f5f84fca722b18dcad7f4b26c059f38a69d6e95c3f81b4a32440accf589e0  src/components/forms/FieldForm.tsx
2acac4a0fcffd9acb526b048bc4474e5e8b640b97f61b2efea653eb1ba850eba  src/components/forms/LojistikForm.tsx
13723e5ea769c662093208601210d7424908b135644c35326b4924d04ce21493  src/components/portal/HarvestPlanningPortal.tsx
1c7db925c28a8d15967943505b1110cee192847feb244df36d0dd26c6417d87e  src/components/portal/HomeMenu.tsx
4118dbb99887c0a11cdaa3582b558fecb1f122a0770c420e9355a81b97f3a4ea  src/components/standards/StandardCard.tsx
161e53704b6c6bfc8c1d2d5212afc2b9703a3484d8a114c74abf9da6e6974559  src/components/standards/StandardsCatalogModal.tsx
6e1af221b48899537110baf63a90e442bb350ae99eeb480da5b445fde0dd5a01  src/components/views/PendingOperationsView.tsx
64da067be9389f7c3dd4d6af91d7ede4ca9aebdde3cbdda411f0d57df593ff16  src/config/inspection.ts
721688696c06b9732f11a72a91438b9152c8277e300791270e4726a8de203fe2  src/context/ToastContext.tsx
