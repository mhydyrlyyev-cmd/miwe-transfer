import React from 'react';
import { BookCheck, ExternalLink } from 'lucide-react';
import { findStandard, STATUS_LABEL, BASE_REQUIREMENTS, StdEntry } from '../../config/standardsCatalog';
import { INSPECTION_CLASSES, CLASS_ROLE, CLASS_ROLE_LABEL, UNECE_GENERAL_TOLERANCE, ClassRole } from '../../config/inspection';

const ROLE_TONE: Record<ClassRole, string> = {
  EXPORT: 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200',
  TONNAGE: 'border-slate-200 bg-slate-50 text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200',
  OUT: 'border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200',
};

/** v47b — Kabul kartı sınıf şeridi: hangi sınıf ihracat, hangisi tonaja girer. */
export const ClassStrip: React.FC = () => (
  <div>
    <dt className="text-xs font-semibold text-slate-500">Sınıflar <span className="font-normal">· eşleşme iç hedef</span></dt>
    <dd className="mt-1 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
      {INSPECTION_CLASSES.map(c => (
        <span key={c} className={`rounded-lg border px-2 py-1 text-xs ${ROLE_TONE[CLASS_ROLE[c].role]}`}>
          <span className="font-bold">{c}</span> · {CLASS_ROLE_LABEL[CLASS_ROLE[c].role]}
          <span className="block text-[11px] opacity-80">{CLASS_ROLE[c].unece}</span>
        </span>
      ))}
    </dd>
    <p className="mt-1 text-[11px] text-slate-500">{UNECE_GENERAL_TOLERANCE}</p>
  </div>
);

/**
 * v4.2 — Seçilen ürünün standart özeti (OECD / UNECE · en sıkı değer geçerli).
 * Test formunda ürünün altında görünür; ölçüm yapılacak sınırları ve kaynağını gösterir.
 */
const TONE: Record<StdEntry['status'], string> = {
  VERIFIED: 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200 dark:border-emerald-900',
  INTERNAL: 'bg-amber-50 text-amber-900 border-amber-200 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-900',
  TO_VERIFY: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700',
  PLATFORM: 'bg-sky-50 text-sky-800 border-sky-200 dark:bg-sky-950/40 dark:text-sky-200 dark:border-sky-900',
};

export const StandardCard: React.FC<{ product?: string; entry?: StdEntry; compact?: boolean; showClasses?: boolean }> = ({ product, entry, compact, showClasses }) => {
  const e = entry || findStandard(product);
  if (!e) return null;
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-sm">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <BookCheck className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-bold text-slate-900 dark:text-white truncate">{e.product}</span>
          <span className="text-xs text-slate-500 truncate">{e.code}</span>
        </div>
        <span className={`shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold border ${TONE[e.status]}`}>{STATUS_LABEL[e.status]}</span>
      </div>
      <dl className="mt-2 space-y-1.5">
        <div>
          <dt className="text-xs font-semibold text-slate-500">Kabul şartı <span className="font-normal">· UNECE/OECD</span></dt>
          <dd className="text-slate-800 dark:text-slate-100">{e.maturity}</dd>
        </div>
        {e.internal && (
          <div>
            <dt className="text-xs font-semibold text-slate-500">MIWE hedefi <span className="font-normal">· İç hedef</span></dt>
            <dd className="text-slate-700 dark:text-slate-300">{e.internal}</dd>
          </div>
        )}
        {!compact && (
          <div>
            <dt className="text-xs font-semibold text-slate-500">Taban (tüm sınıflar)</dt>
            <dd className="text-slate-600 dark:text-slate-400 text-xs">{BASE_REQUIREMENTS}</dd>
          </div>
        )}
        {showClasses && <ClassStrip />}
        {e.note && <dd className="text-xs text-slate-500">{e.note}</dd>}
      </dl>
      {e.source && (
        <a href={e.source.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline">
          Kaynak: {e.source.label} <ExternalLink className="w-3 h-3" />
        </a>
      )}
      <p className="mt-1 text-[11px] text-slate-500">Kural: en sıkı değer geçerli · yerel standart daha sıkıysa yerel uygulanır.</p>
    </div>
  );
};

export default StandardCard;
