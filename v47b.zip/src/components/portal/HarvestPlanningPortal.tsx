import React, { useState, useMemo } from 'react';
import { MIWE_GOOGLE_SHEET_URL } from '../../data/miwe2026Schema';
import { Fruit2026MatrixTable } from './Fruit2026MatrixTable';
import { BananaRibbonCalendarHub } from './BananaRibbonCalendarHub';
import { BrandLogo } from '../common/BrandLogo';
import { PortalTabItem } from './PortalNavigationBar';
import {
  MuzRecord,
  HarvestRecord,
  BademRecord,
  FreezeDryRecord,
  ActiveFieldContext
} from '../../types';
import {
  ArrowLeft,
  Maximize2,
  Minimize2,
  FileSpreadsheet,
  Sparkles,
  Calendar,
  Layers,
  CheckCircle2,
  RefreshCw,
  Bell,
  Snowflake,
  Sprout,
  TrendingUp,
  Scale,
  ShieldCheck,
  AlertTriangle,
  ChevronRight,
  Info,
  CalendarDays,
  Target,
  Clock,
  Compass,
  Home,
  LayoutGrid,
  MapPin,
  BookOpen
} from 'lucide-react';
import { PRESET_PARCELS, PARCEL_GROUPS } from '../../config/parcels';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';

export const HARVEST_PORTAL_TABS: PortalTabItem[] = [
  { id: 'BENTO_OVERVIEW', title: '⭐ Bento Analitik Panosu', description: 'Tüm tarla, sera ve bahçelerin canlı durum ve özet kartları' },
  { id: 'FRUIT_VEG_2026_CALENDAR', title: '🍑 2026 Hasat Takvimi', badge: 'Canlı', description: 'Aylık ve günlük meyve/sebze hasat matrisi ve tonajlar' },
  { id: 'FRUIT_VEG_2027_PLANNER', title: '🚀 2027 Planlama Paneli', badge: 'Bütçe', description: 'Gelecek sezon ekim alanları, dekar hedefleri ve bütçeleme' },
  { id: 'BANANA_RIBBON_CALENDAR_HUB', title: '🍌 Muz 12-Ay Kurdele', badge: '12-Ay', description: 'Haftalık kurdele renkleri, doğum vadeleri ve kesim günleri' },
  { id: 'ALMOND_CALENDAR_HUB', title: '🥜 Badem & Sert Kabuklu', description: 'Badem silkeleme, çatlama ve nem hasat takibi' },
  { id: 'FREEZEDRY_CONCENTRATE_HUB', title: '❄️ Freeze-Dry Hazırlık', description: 'Liyofilizasyon için hasat parti koordinasyonu ve yönlendirme' }
];

interface HarvestPlanningPortalProps {
  onBackToMainApp: () => void;
  onBackToPortals?: () => void;
  onBackToDashboard?: () => void;
  onSwitchPortal?: (targetView: string, targetTab?: string, portalInfo?: any) => void;
  currentUserId?: string;
  muzRecords?: MuzRecord[];
  dailyHarvestRecords?: HarvestRecord[];
  bademRecords?: BademRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  activeFieldContext?: ActiveFieldContext | null;
  onSelectFieldContext?: (ctx: ActiveFieldContext | null) => void;
  initialTab?: CalendarHubTab;
}

export type CalendarHubTab =
  | 'BENTO_OVERVIEW'
  | 'FRUIT_VEG_2026_CALENDAR'
  | 'FRUIT_VEG_2027_PLANNER'
  | 'BANANA_RIBBON_CALENDAR_HUB'
  | 'ALMOND_CALENDAR_HUB'
  | 'FREEZEDRY_CONCENTRATE_HUB';

export const HarvestPlanningPortal: React.FC<HarvestPlanningPortalProps> = ({
  onBackToMainApp,
  onBackToPortals,
  onBackToDashboard,
  onSwitchPortal,
  muzRecords = [],
  dailyHarvestRecords = [],
  bademRecords = [],
  freezeDryRecords = [],
  activeFieldContext,
  onSelectFieldContext,
  initialTab
}) => {
  const [activeHub, setActiveHub] = useState<CalendarHubTab>(initialTab || 'BENTO_OVERVIEW');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);

  React.useEffect(() => {
    if (initialTab) {
      setActiveHub(initialTab);
    }
  }, [initialTab]);

  // 1. GERÇEKLEŞEN 2026 HASAT TONAJLARI (SADECE GERÇEK KAYITLAR)
  const actual2026Stats = useMemo(() => {
    let totalKg = 0;
    let harvestCount = 0;
    
    // Günlük hasat kayıtları
    dailyHarvestRecords.forEach(r => {
      const kg = Number((r as any).netWeightKg || (r as any).grossWeightKg || (r as any).quantity || 0);
      totalKg += kg;
      harvestCount++;
    });

    // Muz hasat tartımları
    let bananaKg = 0;
    muzRecords.forEach(m => {
      const w = Number((m as any).bunchWeightKg || (m as any).clusterWeightKg || 0);
      if (w > 0) {
        bananaKg += w;
      } else {
        bananaKg += 25; // ortalama standart dal ağırlığı
      }
      harvestCount++;
    });
    totalKg += bananaKg;

    // Badem kayıtları
    let bademKg = 0;
    bademRecords.forEach(b => {
      const w = Number((b as any).sampleWeightGrams || 0) / 1000;
      bademKg += w;
    });
    totalKg += bademKg;

    return {
      totalTon: (totalKg / 1000).toFixed(1),
      totalKg: Math.round(totalKg),
      harvestCount,
      bananaCount: muzRecords.length,
      bademCount: bademRecords.length,
      freezeDryCount: freezeDryRecords.length
    };
  }, [dailyHarvestRecords, muzRecords, bademRecords, freezeDryRecords]);

  // 2. 2027 HEDEF PROJEKSİYON BÜTÇESİ (GELECEK SEZON HEDEFİ - DEPOYA DAHİL EDİLMEZ!)
  const forecast2027Plan = {
    targetTon: '3,850',
    totalSectors: 45,
    bananaBudgetTon: '1,200',
    fruitBudgetTon: '2,450',
    bademBudgetTon: '200',
    status: 'Gelecek Sezon Planı (Henüz Fiili Hasat Değildir)'
  };

  const isBananaTheme = activeHub === 'BANANA_RIBBON_CALENDAR_HUB';
  const isParcelSelectorVisible =
    activeHub === 'BENTO_OVERVIEW' ||
    activeHub === 'FRUIT_VEG_2026_CALENDAR' ||
    activeHub === 'FRUIT_VEG_2027_PLANNER';

  return (
    <div
      className={`w-full space-y-4 font-sans antialiased bg-white text-slate-900 ${
        isFullscreen ? 'fixed inset-0 z-50 overflow-y-auto bg-slate-50 p-4 sm:p-6' : ''
      }`}
    >
      {/* 📍 PARSEL SEÇİCİ KARTI (SADECE BENTO, 2026 VE 2027 PLANLAMA SEKMELERİNDE) */}
      {isParcelSelectorVisible && (
        <div className="bg-slate-50 text-slate-800 rounded-xl p-3 sm:p-4 border border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-50 text-teal-700 rounded-lg border border-teal-200 shrink-0">
              <MapPin className="w-4 h-4 text-teal-600" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-teal-700">
                  Aktif Saha &amp; Parsel:
                </span>
                {activeFieldContext ? (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200 font-mono flex items-center gap-1.5 truncate">
                    <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                    <span className="truncate">{activeFieldContext.parcelCode} • {activeFieldContext.product} ({activeFieldContext.orchard})</span>
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 font-mono">
                    🌐 Tüm Parseller (Genel Mod)
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Seçilen parsele göre tüm saha ve hasat planlama tabloları otomatik filtrelenir.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={activeFieldContext?.parcelCode || ''}
              onChange={(e) => {
                const val = e.target.value;
                if (!val) {
                  onSelectFieldContext?.(null);
                  return;
                }
                if (PRESET_PARCELS[val]) {
                  onSelectFieldContext?.(PRESET_PARCELS[val]);
                }
              }}
              className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-semibold text-xs rounded-xl px-3 py-2 cursor-pointer focus:outline-none focus:border-teal-500 transition shadow-2xs"
              title="Parsel seçerek hasat tablolarını ilgili sektöre bağlayın"
            >
              <option value="" className="text-slate-700">
                🌐 Parsel Seçimi (Tüm Parseller)...
              </option>
              {PARCEL_GROUPS.map((grp) => (
                <optgroup key={grp.label} label={`${grp.icon} ${grp.label}`} className="text-slate-800 font-bold">
                  {grp.parcels.map((p) => (
                    <option key={p.code} value={p.code} className="text-slate-800 font-medium">
                      {p.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>

            {activeFieldContext && (
              <button
                type="button"
                onClick={() => onSelectFieldContext?.(null)}
                className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 hover:bg-rose-100 active:bg-rose-200 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs transition cursor-pointer"
                title="Seçimi sıfırla ve tüm parsel verilerine geri dön"
              >
                <span>✕ Seçimi Temizle</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* SEKME ÇUBUĞU (SEGMENTED HUB NAVIGATION) */}
      <div className="flex items-center justify-between gap-2 p-1 bg-slate-100 border border-slate-200 rounded-xl overflow-x-auto shadow-2xs">
        <div className="flex items-center gap-1">
          {HARVEST_PORTAL_TABS.map(tab => {
            const isActive = activeHub === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveHub(tab.id as CalendarHubTab)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-white text-teal-800 font-bold shadow-2xs border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
                title={tab.description}
              >
                <span>{tab.title}</span>
                {tab.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                      isActive
                        ? 'bg-teal-100 text-teal-800'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="p-2 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg text-xs transition cursor-pointer shrink-0 ml-2 shadow-2xs"
          title={isFullscreen ? 'Tam Ekrandan Çık' : 'Tam Ekran Modu'}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* ========================================================================= */}
      {/* SEKME 0: BENTO GRID ANALİTİK & MİNİMALİST KART DÜZENİ                    */}
      {/* ========================================================================= */}
      {activeHub === 'BENTO_OVERVIEW' && (
        <div className="space-y-4">
          
          {/* ÜST BENTO BANNER */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-teal-600 text-white shadow-2xs">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Meyve-Sebze Hasat ve Bütçe Analitik Stüdyosu
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Canlı hasat verileri, bütçe karşılaştırmaları ve sektör bazlı rekolte paneli
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  2026 Sezonu Canlı
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                  2027 Bütçe Projeksiyonu
                </span>
              </div>
            </div>

            {/* KRİTİK VERİ BİLGİLENDİRMESİ */}
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong className="text-amber-950">Veri Ayrımı Kuralı:</strong> 2027 Hasat Takvimindeki bütçe tonajları (3,850 Ton), henüz hasat edilmemiş <strong>gelecek sezon planlamasıdır</strong>. Mevcut ambar stoklarına veya gerçekleşen tartımlara dahil edilmez. Sadece gerçekleşen 2026 fiili hasat kayıtları ({actual2026Stats.totalTon} Ton) canlı stok doluluğunu etkiler.
              </div>
            </div>
          </div>

          {/* BENTO GRID (KARTLAR) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
            
            {/* KART 1: 2026 FİİLİ GERÇEKLEŞEN HASAT */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 flex items-center gap-1.5">
                    <Scale className="w-4 h-4" />
                    1. 2026 Sezonu Fiili Gerçekleşen Hasat (Canlı)
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-teal-50 text-teal-800 border border-teal-200">
                    Aktif Veritabanı
                  </span>
                </div>

                <div className="mt-3 flex items-baseline gap-2.5">
                  <span className="text-4xl font-extrabold text-slate-900 font-mono tracking-tight">
                    {actual2026Stats.totalTon}
                  </span>
                  <span className="text-base font-bold text-teal-700">Ton Toplam</span>
                  <span className="text-xs text-slate-500 font-mono">({actual2026Stats.totalKg.toLocaleString('tr-TR')} kg)</span>
                </div>

                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Saha tartımı, kantar kabul fişi ve muz hevenk kesimi tamamlanmış kesin gerçekleşen hasat hacmi.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-100 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-500">Saha Hasadı</div>
                  <div className="text-base font-bold text-slate-900">{dailyHarvestRecords.length} Parti</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-500">Muz Kurdele</div>
                  <div className="text-base font-bold text-slate-900">{muzRecords.length} Kayıt</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-500">Badem Kırım</div>
                  <div className="text-base font-bold text-slate-900">{bademRecords.length} Analiz</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] text-slate-500">Freeze-Dry</div>
                  <div className="text-base font-bold text-slate-900">{freezeDryRecords.length} Parti</div>
                </div>
              </div>
            </div>

            {/* KART 2: 2027 HEDEF BÜTÇE PROJEKSİYONU */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 flex items-center gap-1.5">
                    <Target className="w-4 h-4" />
                    2. 2027 Bütçe &amp; Hasat Hedefi (Projeksiyon)
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-50 text-blue-800 border border-blue-200">
                    Gelecek Hedef
                  </span>
                </div>

                <div className="mt-3 flex items-baseline gap-2.5">
                  <span className="text-4xl font-extrabold text-slate-900 font-mono tracking-tight">
                    {forecast2027Plan.targetTon}
                  </span>
                  <span className="text-base font-bold text-blue-700">Ton Plan</span>
                </div>

                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  2027 sezonu için 45 parselde hedeflenen toplam rekolte projeksiyonudur.
                </p>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-100 text-xs">
                <div className="flex items-center justify-between text-slate-700">
                  <span>🍌 Muz Seraları (7 Sektör):</span>
                  <span className="font-mono font-bold text-amber-700">{forecast2027Plan.bananaBudgetTon} Ton</span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span>🍑 Bahçe Meyveleri (Şeftali, Nektarin, Elma):</span>
                  <span className="font-mono font-bold text-teal-700">{forecast2027Plan.fruitBudgetTon} Ton</span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span>🌰 Badem Plantasyonu:</span>
                  <span className="font-mono font-bold text-orange-700">{forecast2027Plan.bademBudgetTon} Ton</span>
                </div>
              </div>
            </div>

            {/* KART 3: 12-AY MUZ KURDELE */}
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-[11px] font-bold uppercase text-amber-700">
                  <span>🍌 12-Ay Muz Kurdele Takvimi</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold">Sera Hub</span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mt-2">
                  Sera Kesim Döngüsü &amp; Olgunluk
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  12-haftalık renkli kurdele sistemi ile hevenklerin aynı gün kesilmesi ve MAP torba kalitesi takip edilir.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveHub('BANANA_RIBBON_CALENDAR_HUB')}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-2xs"
              >
                <span>Muz Kurdele Takvimini Aç</span>
                <ChevronRight className="w-4 h-4 text-amber-700" />
              </button>
            </div>

            {/* KART 4: 2026 MEYVE-SEBZE MATRİS TABLOSU */}
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-[11px] font-bold uppercase text-teal-700">
                  <span>🍑🥕 Meyve &amp; Sebze Matrisi</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200 font-semibold">2026 Sezon</span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mt-2">
                  Google Sheets Entegre Tablo
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Gök Bulut, Maksat ve Miweli Atyz parsellerinin gerçek zamanlı hasat takvimi ve tonaj dökümü.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveHub('FRUIT_VEG_2026_CALENDAR')}
                className="w-full py-2.5 px-4 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-2xs"
              >
                <span>2026 Hasat Tablosunu Aç</span>
                <ChevronRight className="w-4 h-4 text-teal-700" />
              </button>
            </div>

            {/* KART 5: FREEZE-DRY & BADEM HUB */}
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-[11px] font-bold uppercase text-cyan-700">
                  <span>❄️ Katma Değerli Kurtarma</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-50 text-cyan-800 border border-cyan-200 font-semibold">Sıfır Atık</span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mt-2">
                  Freeze-Dry &amp; Badem Kırım
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Standart dışı meyvelerin liyofilizasyonla kurtarılması ve Gursak badem su kesimi/kurutma planı.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveHub('ALMOND_CALENDAR_HUB')}
                  className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-bold text-[11px] text-center cursor-pointer transition"
                >
                  Badem Hub
                </button>
                <button
                  type="button"
                  onClick={() => setActiveHub('FREEZEDRY_CONCENTRATE_HUB')}
                  className="py-2 px-3 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-900 border border-cyan-200 font-bold text-[11px] text-center cursor-pointer transition"
                >
                  Freeze-Dry Hub
                </button>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* HUB 1 & 2: MEYVE & SEBZE 2026 HASAT TAKVİMİ VE 2027 DOĞRUDAN PLANLAMA PANELİ */}
      {(activeHub === 'FRUIT_VEG_2026_CALENDAR' || activeHub === 'FRUIT_VEG_2027_PLANNER') && (
        <Fruit2026MatrixTable
          activeYear={activeHub === 'FRUIT_VEG_2027_PLANNER' ? '2027' : '2026'}
          onSwitchYear={y =>
            setActiveHub(y === '2027' ? 'FRUIT_VEG_2027_PLANNER' : 'FRUIT_VEG_2026_CALENDAR')
          }
          harvestRecords={dailyHarvestRecords as any}
        />
      )}

      {/* HUB 3: AYRI MUZ KURDELE & GÜNLÜK SERA HASAT TAKVİMİ PLATFORMU */}
      {activeHub === 'BANANA_RIBBON_CALENDAR_HUB' && (
        <BananaRibbonCalendarHub
          muzRecords={muzRecords}
          dailyHarvestRecords={dailyHarvestRecords}
        />
      )}

      {/* HUB 4: BADEM HASAT, SU KESİMİ, TENİAS KURUTMA & KIRIM TAKVİMİ HUB */}
      {activeHub === 'ALMOND_CALENDAR_HUB' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-2xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-amber-50 text-amber-800 border border-amber-200">
                🌰 BAĞIMSIZ BADEM TAKVİMİ &amp; İŞLEME HUB
              </span>
              <h2 className="text-lg font-bold text-slate-900 mt-1">
                Badem (Guara, Ferragnes, Nonpareil) Su Kesimi • Tenias Silkeleme • Yerde Kurutma &amp; Kırım Takvimi
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Meyve Takvimi (Gursak Badem Parselleri) ve Kalite Modülü Badem Kırım Analizleri ({bademRecords.length} kayıt) ile karşılıklı veri alışverişi yapar.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveHub('FRUIT_VEG_2026_CALENDAR')}
              className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer transition shadow-2xs"
            >
              Gursak Badem Parsellerini Gör ➔
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="font-bold text-teal-800 uppercase text-[11px]">1. Suwy Kesilen (Su Kesimi)</div>
              <p className="text-slate-600 mt-1 leading-relaxed">
                Tenias makinesi ile silkeleme hasadından 12-15 gün önce ağaçların suyu kesilir; kabuk ayrılması (%95 Hull Split) sağlanır.
              </p>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="font-bold text-amber-800 uppercase text-[11px]">2. Tenias Hasat &amp; Gurutma</div>
              <p className="text-slate-600 mt-1 leading-relaxed">
                Hasattan 10-15 gün önce nem testi yapılır. Silkelendikten sonra yerde kurutulup (%5.5 - %6.0 iç nem) sortinge sevk edilir.
              </p>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="font-bold text-emerald-800 uppercase text-[11px]">3. İç Randıman &amp; Kalibre</div>
              <p className="text-slate-600 mt-1 leading-relaxed">
                Kalite modülündeki Badem Kırım kayıtlarından iç randıman (%32-%38), çift badem ve kırık oranı takvime otomatik yansır.
              </p>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="font-bold text-blue-800 uppercase text-[11px]">4. 2026 / 2027 Badem Tonajı</div>
              <p className="text-slate-600 mt-1 leading-relaxed">
                Gursak Badem (Guara vb.) 2026 Bütçe: <strong className="text-amber-800">200 Ton</strong> • 2027 Optimal Hedef: <strong className="text-teal-800">245 Ton</strong>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* HUB 5: FREEZE-DRY */}
      {activeHub === 'FREEZEDRY_CONCENTRATE_HUB' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-2xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-cyan-50 text-cyan-800 border border-cyan-200">
                ❄️🧪 FREEZE-DRY &amp; KONSANTRE İŞLEME TAKVİMİ HUB
              </span>
              <h2 className="text-lg font-bold text-slate-900 mt-1">
                Liyofilizasyon (Freeze &amp; Dry) ve Meyve Suyu / Püre Konsantre Hammadde Takvimi
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Meyve-Sebze ve Muz takvimlerinden çıkan 2. Sınıf / Endüstriyel ve Özel Hasat ürünlerin Freeze-Dry ({freezeDryRecords.length} parti) ve AIJN standartlarına göre işleme planı.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <div className="font-bold text-cyan-800 uppercase text-[11px]">
                ❄️ Freeze &amp; Dry (Liyofilizasyon) Takvim Eşleşmesi
              </div>
              <p className="text-slate-600 leading-relaxed">
                • <strong>Haziran-Ağustos:</strong> Şeftali, Nektarin, Kiraz, Erik dilim/küp liyofilizasyon (Brix ≥11°, Son Nem ≤%3.0, aw ≤0.25).
              </p>
              <p className="text-slate-600 leading-relaxed">
                • <strong>Eylül-Aralık:</strong> Elma, Armut, Hurma ve Sera Muzu cips/toz liyofilizasyon döngüsü.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <div className="font-bold text-purple-800 uppercase text-[11px]">
                🧃 Konsantre &amp; Meyve Suyu (AIJN / Codex) Takvimi
              </div>
              <p className="text-slate-600 leading-relaxed">
                • <strong>Üst Hasat &amp; Sortirowka:</strong> Meyve takviminde "Sortirowka" veya "Üst hasat" statüsündeki sağlıklı meyveler doğrudan püre/konsantre (65-70°Bx) hattına yönlendirilir.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1.5">
              <div className="font-bold text-teal-800 uppercase text-[11px]">
                🔄 Hub'lar Arası Karşılıklı Veri Alışverişi
              </div>
              <p className="text-slate-600 leading-relaxed">
                • Kalite modülünde yapılan numune testinde <strong>Freeze &amp; Dry</strong> veya <strong>Konsantre</strong> standardına uygun çıkan partiler ve Delilnama tonajları tüm takvim hub'ları arasında karşılıklı eşleşir.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
