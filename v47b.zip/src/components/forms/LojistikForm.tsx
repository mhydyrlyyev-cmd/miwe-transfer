import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Truck,
  ArrowLeft,
  Save,
  Thermometer,
  FileText,
  CheckCircle2,
  AlertCircle,
  Info,
  Split,
  Plus,
  Trash2,
  Sparkles,
  Printer,
  Scale,
  ShieldCheck,
  ChevronRight,
  Layers,
  Snowflake,
  ExternalLink,
  Edit,
  X,
  Camera,
  Image as ImageIcon,
  Eye,
  UploadCloud,
  BookOpen,
  Activity,
  AlertTriangle,
  Upload,
  FileSpreadsheet,
  Lock
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ReferenceLine
} from 'recharts';
import {
  LojistikRecord,
  ReferenceItem,
  SplitLotItem,
  DelilnamaPassport,
  DelilnamaGradeRow,
  BademDepderceItem,
  BademDelilnamaPassport,
  StandardQualityClassKey,
  STANDARD_QUALITY_CLASSES,
  DataloggerRecord,
  DataloggerReading,
  DataloggerStats
} from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { generateRefId } from '../../utils/calculations';
import { QualityGradeSelect } from '../common/QualityGradeSelect';
import { SmartCreatableSelect } from '../common/SmartField';
import { compressImage, cachePhoto } from '../../utils/photoStorage';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';
import { parseLoggerCsv, computeStats, downsample } from '../../utils/dataloggerParser';
import { PRODUCT_SPECS, LOGGER_CONFLICT_WARN_C, getProductSpec } from '../../config/productSpecs';

import { getCurrentUser } from '../../utils/authService';
interface LojistikFormProps {
  onSave: (record: LojistikRecord, refId: string) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: LojistikRecord;
  onOpenGallery?: () => void;
  isReadOnly?: boolean;
}

export const LojistikForm: React.FC<LojistikFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  onOpenGallery,
  isReadOnly = false
}) => {
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId || ''));
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Lojistik Sevkiyat Uzmanı');

  // Selected reference context
  const selectedRef = existingRefs.find(r => r.refId === selectedRefId);

  // 1. Dinamik Meyve Seçimi (Muz vs Diğer Meyveler vs Badem)
  const initialIsBanana = (initialRecord?.fruitCategory === 'MUZ') || selectedRef?.product?.toLowerCase().includes('muz') || false;
  const initialIsBadem = (initialRecord?.fruitCategory === 'BADEM') || selectedRef?.product?.toLowerCase().includes('badem') || false;
  const [fruitCategory, setFruitCategory] = useState<'MUZ' | 'DIGER' | 'BADEM'>(
    initialRecord?.fruitCategory || (initialIsBadem ? 'BADEM' : (initialIsBanana ? 'MUZ' : 'DIGER'))
  );
  const [customFruit, setCustomFruit] = useState<string>(
    initialRecord?.product || selectedRef?.product || (initialIsBadem ? 'Badem' : (initialIsBanana ? 'Muz' : ''))
  );
  const [customVariety, setCustomVariety] = useState<string>(initialRecord?.variety || selectedRef?.variety || ''); // v2.8: uydurma çeşit yok

  // Form Fields
  const [shipmentDate, setShipmentDate] = useState(initialRecord?.shipmentDate || new Date().toISOString().split('T')[0]);
  const [source, setSource] = useState(initialRecord?.source || selectedRef?.source || 'Merkez Soğuk Hava Deposu');
  const [destination, setDestination] = useState(initialRecord?.destination || selectedRef?.destination || 'Aşgabat / İhracat');
  const [vehiclePlate, setVehiclePlate] = useState(initialRecord?.vehiclePlate || 'AG 7721 AH');
  const [driver, setDriver] = useState(initialRecord?.driver || 'Merdan Orazow');
  const [driverPhone, setDriverPhone] = useState(initialRecord?.driverPhone || '+993 65 442190');
  const [delilnamaNo, setDelilnamaNo] = useState(initialRecord?.delilnamaNo || '');
  const [transportType, setTransportType] = useState(initialRecord?.transportType || 'Frigorifik Tır (Reefer)');
  const [palletCount, setPalletCount] = useState<number>(initialRecord?.palletCount ?? 0);
  const [caseCount, setCaseCount] = useState<number>(initialRecord?.caseCount ?? 0);
  const [weightKg, setWeightKg] = useState<number>(initialRecord?.weightKg ?? (selectedRef?.quantity || 4500));
  // v2.8: sıcaklıklar ölçülerek girilir; ürüne göre uydurma varsayılan yok
  const [departureTemperature, setDepartureTemperature] = useState<number | null>(
    initialRecord?.departureTemperature ?? null
  );
  const [transitTemperature, setTransitTemperature] = useState<number | null>(
    initialRecord?.transitTemperature ?? null
  );
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [status, setStatus] = useState<'SHIPPED' | 'IN_TRANSIT' | 'DELIVERED'>(initialRecord?.status || 'SHIPPED');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);

  // Konteyner & Reefer Alanları
  const [containerNo, setContainerNo] = useState(initialRecord?.containerNo || '');
  const [sealNo, setSealNo] = useState(initialRecord?.sealNo || '');
  const [transportMode, setTransportMode] = useState<'DENIZ' | 'KARA' | 'HAVA'>(
    initialRecord?.transportMode || 'DENIZ'
  );
  const [portOfDeparture, setPortOfDeparture] = useState(initialRecord?.portOfDeparture || '');
  const [portOfArrival, setPortOfArrival] = useState(initialRecord?.portOfArrival || '');
  const [loadingDate, setLoadingDate] = useState(
    initialRecord?.loadingDate || initialRecord?.shipmentDate || ''
  );
  const [arrivalDate, setArrivalDate] = useState(initialRecord?.arrivalDate || '');
  const [reeferSetpointC, setReeferSetpointC] = useState<number | ''>(
    initialRecord?.reeferSetpointC !== undefined ? initialRecord.reeferSetpointC : ''
  );
  const [reeferSupplyC, setReeferSupplyC] = useState<number | ''>(
    initialRecord?.reeferSupplyC !== undefined ? initialRecord.reeferSupplyC : ''
  );

  // Otomatik transitDays (salt okunur)
  const transitDays = useMemo(() => {
    if (!loadingDate || !arrivalDate) return undefined;
    const d1 = new Date(loadingDate).getTime();
    const d2 = new Date(arrivalDate).getTime();
    if (isNaN(d1) || isNaN(d2) || d2 < d1) return undefined;
    return Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
  }, [loadingDate, arrivalDate]);

  // Datalogger Listesi
  const [dataloggers, setDataloggers] = useState<DataloggerRecord[]>(initialRecord?.dataloggers || []);

  // Logger modal / form state
  const [showLoggerModal, setShowLoggerModal] = useState(false);
  const [loggerModalTab, setLoggerModalTab] = useState<'CSV' | 'MANUEL'>('CSV');
  const [editingLoggerId, setEditingLoggerId] = useState<string | null>(null);

  // Modal Input state
  const [logBrand, setLogBrand] = useState('Copeland');
  const [logDeviceId, setLogDeviceId] = useState('');
  const [logPlacement, setLogPlacement] = useState<'PALET_ICI' | 'HAVA_CIKISI' | 'HAVA_DONUSU' | 'KAPI_TARAFI' | 'DIGER'>('PALET_ICI');
  const [logSourceTz, setLogSourceTz] = useState('UTC');
  const [logDateFormat, setLogDateFormat] = useState<'AUTO' | 'MDY' | 'YMD' | 'DMY'>('AUTO');
  const [logUpperLimit, setLogUpperLimit] = useState<number | ''>('');
  const [logLowerLimit, setLogLowerLimit] = useState<number | ''>('');

  // CSV State
  const [csvRawText, setCsvRawText] = useState('');
  const [csvFileName, setCsvFileName] = useState('');
  const [csvPreview, setCsvPreview] = useState<{ headers: string[]; rows: string[][] } | null>(null);

  // Manuel State
  const [manualMinC, setManualMinC] = useState<number | ''>('');
  const [manualMaxC, setManualMaxC] = useState<number | ''>('');
  const [manualAvgC, setManualAvgC] = useState<number | ''>('');
  const [manualMktC, setManualMktC] = useState<number | ''>('');
  const [manualStartAt, setManualStartAt] = useState('');
  const [manualStopAt, setManualStopAt] = useState('');
  const [manualMinutesAbove, setManualMinutesAbove] = useState<number | ''>('');
  const [manualMinutesBelow, setManualMinutesBelow] = useState<number | ''>('');
  const [manualViolations, setManualViolations] = useState<number | ''>('');

  const currentProductSpec = useMemo(() => {
    const pName = fruitCategory === 'BADEM' ? 'Badem' : (fruitCategory === 'MUZ' ? 'Muz' : customFruit);
    return getProductSpec(pName);
  }, [fruitCategory, customFruit]);

  const loggerConflictWarning = useMemo(() => {
    if (dataloggers.length < 2) return null;
    const avgs = dataloggers
      .map(l => (l.tripStats?.avgC !== undefined ? l.tripStats.avgC : l.fullStats?.avgC))
      .filter((v): v is number => v !== undefined && v !== null);
    if (avgs.length < 2) return null;
    const minAvg = Math.min(...avgs);
    const maxAvg = Math.max(...avgs);
    const diff = Number((maxAvg - minAvg).toFixed(1));
    if (diff > LOGGER_CONFLICT_WARN_C) {
      return `Loggerlar arasında ${diff} °C fark var; cihazların konteynerdeki yerini kontrol edin.`;
    }
    return null;
  }, [dataloggers]);

  // Saha & Lojistik Kanıt Fotoğrafları (Field & Shipment Verification Photos)
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Look up field & harvest photos related to selectedRefId
  const relatedBatchPhotos = useMemo(() => {
    const found: Array<{ url: string; label: string; date?: string }> = [];
    try {
      if (selectedRefId) {
        // 1. check harvest records
        const hrStr = localStorage.getItem('miwe_harvest_records');
        if (hrStr) {
          const list = JSON.parse(hrStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🌿 Hasat Fotoğrafı #${idx + 1} (${x.orchard || ''})`, date: x.date });
            });
          });
        }
        // 2. check field records
        const frStr = localStorage.getItem('miwe_field_records');
        if (frStr) {
          const list = JSON.parse(frStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🍎 Meyve Kalite Testi #${idx + 1}`, date: x.testDate });
            });
          });
        }
        // 3. check muz records
        const mrStr = localStorage.getItem('miwe_muz_records');
        if (mrStr) {
          const list = JSON.parse(mrStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🍌 Muz Kalite Kontrol #${idx + 1}`, date: x.date });
            });
          });
        }
        // 4. check badem records
        const brStr = localStorage.getItem('miwe_badem_records');
        if (brStr) {
          const list = JSON.parse(brStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🥜 Badem Randıman Testi #${idx + 1}`, date: x.date });
            });
          });
        }
      }
    } catch (e) {
      console.warn('Could not load related photos', e);
    }
    return found;
  }, [selectedRefId]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsCompressingPhoto(true);
    try {
      const files = Array.from(e.target.files) as File[];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        try {
          const compressedBase64 = await compressImage(file, 1600, 1600, 0.8);
          const photoKey = `photo_lojistik_${Date.now()}_${i}`;
          await cachePhoto(photoKey, compressedBase64);
          setPhotos(prev => [...prev, compressedBase64]);
        } catch (err) {
          const reader = new FileReader();
          reader.onload = (re) => {
            if (re.target?.result) {
              setPhotos(prev => [...prev, re.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        }
      }
    } finally {
      setIsCompressingPhoto(false);
      if (cameraInputRef.current) cameraInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // 2. Parçalı Yük & Kalite Sortları Dağıtımı (Split Lots)
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>([]);

  // 3. Delilnama / Standart Meyve Kalite Pasaportu
  const [enableDelilnama, setEnableDelilnama] = useState(true);
  const [delilnamaPassport, setDelilnamaPassport] = useState<DelilnamaPassport>({
    delilnamaNo: delilnamaNo,
    sene: shipmentDate,
    yeri: source,
    miwe: fruitCategory === 'MUZ' ? 'Muz' : customFruit,
    miweGornusi: customVariety,
    agacSany: 120,
    gabynGornusi: 'Ýaşşik (Plastik Agro Kasa)',
    grades: [
      { gradeKey: 'EXTRA (V-20)', gradeLabelTr: 'Ekstra Kalite', yassikliKg: 1850, hasylNetKg: 1820, satysaBerlenKg: 1820, gapSany: 91 },
      { gradeKey: 'I (V-22) EXC', gradeLabelTr: '1. Sınıf Seçkin', yassikliKg: 1600, hasylNetKg: 1560, satysaBerlenKg: 1560, gapSany: 78 },
      { gradeKey: 'II (V-24) PRM', gradeLabelTr: '2. Sınıf Standart', yassikliKg: 1080, hasylNetKg: 1040, satysaBerlenKg: 1040, gapSany: 52 },
      { gradeKey: 'III (V26-28) CLS', gradeLabelTr: '3. Sınıf Klasik', yassikliKg: 420, hasylNetKg: 416, satysaBerlenKg: 416, gapSany: 21 },
      { gradeKey: 'Mix', gradeLabelTr: 'Gatyşyk / Mix', yassikliKg: 215, hasylNetKg: 208, satysaBerlenKg: 208, gapSany: 10 },
      { gradeKey: 'Standart Däl / Standart Dışı', gradeLabelTr: 'Standart Däl / Sanayi', yassikliKg: 160, hasylNetKg: 156, satysaBerlenKg: 156, gapSany: 8 }
    ],
    jemiNetKg: 5200,
    jemiSatysaKg: 5200,
    jemiGapSany: 260,
    onduriji: 'Orazow R. (Çavuş / Brigadir)',
    hilciHunarmen: 'Saparow M. (Baş Hilçi Hünärmen)',
    satuwHunarmen: 'Mämmetgulyýew M. (Satuw Hünärmen)'
  });

  // 4. RESMİ BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI ("MIWE" AGPJ) - № 0000417 Standardı
  const [bademPassport, setBademPassport] = useState<BademDelilnamaPassport>({
    depderceNo: '№ 0000417',
    sene: shipmentDate,
    ulagBelgisi: vehiclePlate,
    bellik: 'Big Bag gaplanan täze hasyl arassalanan Laurenne maňzy',
    cykysEden: 'Badam zawod (Amanow B.)',
    girisEden: 'Sowuk depo (Myradow G.)',
    tassyklan: 'Hil hünärmen (Kadyrow D.)',
    premiumItems: [
      {
        id: 'bp-1',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '21/22 Premium',
        arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 1162.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      },
      {
        id: 'bp-2',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '25-27 Premium',
        arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 524.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      },
      {
        id: 'bp-3',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '29-31 Premium',
        arassalananGornusi: 'Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 182.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      }
    ],
    sortlamaItems: [
      {
        id: 'bs-1',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '33-35 Classic',
        sortlamaGaplama: 'I sort',
        agramyKg: 56.0,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-2',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '38-40 Mix',
        sortlamaGaplama: 'II sort',
        agramyKg: 28.0,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-3',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: 'Döwük Mix',
        sortlamaGaplama: 'III sort',
        agramyKg: 50.0,
        haltaSany: 'Halta 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-4',
        cykysYeri: 'MZ / Söwda / Sowuk depo',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '—',
        sortlamaGaplama: 'Pak we heňli',
        agramyKg: 0,
        haltaSany: '—',
        tableType: 'SORTLAMA_GAPLAMA'
      }
    ],
    jemiAgramKg: 2003.5,
    jemiHaltaSany: 6
  });

  const [showPrintModal, setShowPrintModal] = useState(false);
  const [newGradeKey, setNewGradeKey] = useState<string>('EXTRA (V-20)');

  // Badem Passport Sums (NaN-free)
  const bademSums = useMemo(() => {
    const totalPremium = bademPassport.premiumItems.reduce((acc, curr) => acc + (Number(curr.agramyKg) || 0), 0);
    const totalSortlama = bademPassport.sortlamaItems.reduce((acc, curr) => acc + (Number(curr.agramyKg) || 0), 0);
    const totalKg = totalPremium + totalSortlama;
    return {
      totalPremium: Number(totalPremium.toFixed(2)),
      totalSortlama: Number(totalSortlama.toFixed(2)),
      totalKg: Number(totalKg.toFixed(2)),
      totalRows: bademPassport.premiumItems.length + bademPassport.sortlamaItems.length
    };
  }, [bademPassport]);

  // Keep badem totals synchronized
  useEffect(() => {
    setBademPassport(prev => {
      if (
        prev.jemiAgramKg === bademSums.totalKg &&
        prev.sene === shipmentDate &&
        prev.ulagBelgisi === vehiclePlate
      ) {
        return prev;
      }
      return {
        ...prev,
        jemiAgramKg: bademSums.totalKg,
        sene: shipmentDate,
        ulagBelgisi: vehiclePlate
      };
    });
    if (fruitCategory === 'BADEM' && bademSums.totalKg > 0) {
      setWeightKg(prev => prev === bademSums.totalKg ? prev : bademSums.totalKg);
    }
  }, [bademSums.totalKg, shipmentDate, vehiclePlate, fruitCategory]);

  // Safe tonage calculation
  const safeTotalKg = useMemo(() => {
    return Number.isFinite(weightKg) && weightKg > 0 ? Number(weightKg) : 0;
  }, [weightKg]);

  // Split lots allocated sum (NaN-free)
  const allocatedSplitKg = useMemo(() => {
    return splitLots.reduce((sum, item) => {
      const q = Number(item.quantityKg);
      return sum + (Number.isFinite(q) ? q : 0);
    }, 0);
  }, [splitLots]);

  const rawDiff = safeTotalKg - allocatedSplitKg;
  const remainingSplitKg = isNaN(rawDiff) ? 0 : Math.max(0, Number(rawDiff.toFixed(3)));
  const isOverAllocated = safeTotalKg > 0 && allocatedSplitKg > safeTotalKg + 0.001;

  // Delilnama sums (NaN-free)
  const delilnamaSums = useMemo(() => {
    let totalYassikli = 0;
    let totalNet = 0;
    let totalSatysa = 0;
    let totalGap = 0;

    delilnamaPassport.grades.forEach(g => {
      totalYassikli += Number.isFinite(Number(g.yassikliKg)) ? Number(g.yassikliKg) : 0;
      totalNet += Number.isFinite(Number(g.hasylNetKg)) ? Number(g.hasylNetKg) : 0;
      totalSatysa += Number.isFinite(Number(g.satysaBerlenKg)) ? Number(g.satysaBerlenKg) : 0;
      totalGap += Number.isFinite(Number(g.gapSany)) ? Number(g.gapSany) : 0;
    });

    return {
      totalYassikli: Number(totalYassikli.toFixed(3)),
      totalNet: Number(totalNet.toFixed(3)),
      totalSatysa: Number(totalSatysa.toFixed(3)),
      totalGap: Math.round(totalGap)
    };
  }, [delilnamaPassport.grades]);

  // Keep delilnama totals synchronized
  useEffect(() => {
    setDelilnamaPassport(prev => {
      // Avoid state updates if values are already synchronized to prevent loop
      if (
        prev.jemiNetKg === delilnamaSums.totalNet &&
        prev.jemiSatysaKg === delilnamaSums.totalSatysa &&
        prev.jemiGapSany === delilnamaSums.totalGap
      ) {
        return prev;
      }
      return {
        ...prev,
        jemiNetKg: delilnamaSums.totalNet,
        jemiSatysaKg: delilnamaSums.totalSatysa,
        jemiGapSany: delilnamaSums.totalGap
      };
    });
  }, [delilnamaSums.totalNet, delilnamaSums.totalSatysa, delilnamaSums.totalGap]);

  // Keep delilnama header fields synchronized with form state
  useEffect(() => {
    setDelilnamaPassport(prev => {
      const targetMiwe = fruitCategory === 'MUZ' ? 'Muz' : customFruit;
      if (
        prev.delilnamaNo === delilnamaNo &&
        prev.sene === shipmentDate &&
        prev.yeri === source &&
        prev.miwe === targetMiwe &&
        prev.miweGornusi === customVariety
      ) {
        return prev;
      }
      return {
        ...prev,
        delilnamaNo,
        sene: shipmentDate,
        yeri: source,
        miwe: targetMiwe,
        miweGornusi: customVariety
      };
    });
  }, [delilnamaNo, shipmentDate, source, fruitCategory, customFruit, customVariety]);

  // Update fields when selected Ref changes
  useEffect(() => {
    if (selectedRef) {
      if (selectedRef.source) setSource(selectedRef.source);
      if (selectedRef.destination) setDestination(selectedRef.destination);
      if (selectedRef.quantity) setWeightKg(selectedRef.quantity);
      if (selectedRef.product) {
        // v2.8: ürün ve çeşit partiden gelir; sıcaklıklar ölçülerek girilir (uydurma değer yok)
        const p = selectedRef.product.toLowerCase();
        setFruitCategory(p.includes('muz') ? 'MUZ' : p.includes('badem') ? 'BADEM' : 'DIGER');
        setCustomFruit(selectedRef.product);
        setCustomVariety(selectedRef.variety || '');
      }
    }
  }, [selectedRefId]);

  // Fruit category toggle handler
  const handleFruitCategoryChange = (category: 'MUZ' | 'DIGER' | 'BADEM') => {
    // v2.8: kategori değişince yalnızca ürün adı değişir; kaynak, hedef, çeşit ve sıcaklıklar uydurulmaz
    setFruitCategory(category);
    setCustomFruit(category === 'MUZ' ? 'Muz' : category === 'BADEM' ? 'Badem' : '');
    if (!selectedRef) {
      setCustomVariety('');
      setDepartureTemperature(null);
      setTransitTemperature(null);
    }
  };

  // Badem Table 1: Premium / Arassalanan Maňyz Row Handlers
  const handleUpdateBademPremiumRow = (index: number, field: keyof BademDepderceItem, value: any) => {
    setBademPassport(prev => {
      const updated = [...prev.premiumItems];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, premiumItems: updated };
    });
  };

  const handleAddBademPremiumRow = () => {
    setBademPassport(prev => ({
      ...prev,
      premiumItems: [
        ...prev.premiumItems,
        {
          id: `bp-${Date.now()}`,
          cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
          girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
          badamSorty: customVariety || '',
          meydany: '25-27 Premium',
          arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz',
          agramyKg: 500,
          haltaSany: 'Big Bag 1 sany',
          tableType: 'PREMIUM_MANYZ'
        }
      ]
    }));
  };

  const handleDeleteBademPremiumRow = (index: number) => {
    if (bademPassport.premiumItems.length <= 1) {
      alert('Iň az 1 sany Esasy Maňyz satary bolmalydyr.');
      return;
    }
    setBademPassport(prev => ({
      ...prev,
      premiumItems: prev.premiumItems.filter((_, i) => i !== index)
    }));
  };

  // Badem Table 2: Sortlama & Gaplama Row Handlers
  const handleUpdateBademSortlamaRow = (index: number, field: keyof BademDepderceItem, value: any) => {
    setBademPassport(prev => {
      const updated = [...prev.sortlamaItems];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, sortlamaItems: updated };
    });
  };

  const handleAddBademSortlamaRow = () => {
    setBademPassport(prev => ({
      ...prev,
      sortlamaItems: [
        ...prev.sortlamaItems,
        {
          id: `bs-${Date.now()}`,
          cykysYeri: 'MZ / Sowuk depo / Söwda',
          girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
          badamSorty: customVariety || '',
          meydany: '38-40 Mix',
          sortlamaGaplama: 'II sort',
          agramyKg: 50,
          haltaSany: 'Halta 1 sany',
          tableType: 'SORTLAMA_GAPLAMA'
        }
      ]
    }));
  };

  const handleDeleteBademSortlamaRow = (index: number) => {
    if (bademPassport.sortlamaItems.length <= 1) {
      alert('Iň az 1 sany Sortlama satary bolmalydyr.');
      return;
    }
    setBademPassport(prev => ({
      ...prev,
      sortlamaItems: prev.sortlamaItems.filter((_, i) => i !== index)
    }));
  };

  // Convert Badem Depderce rows into Split Lots
  const handleTransferBademToSplitLots = () => {
    const newLots: SplitLotItem[] = [];
    let charCode = 65; // A

    bademPassport.premiumItems.forEach(item => {
      if (item.agramyKg > 0) {
        newLots.push({
          id: `split-badem-${item.id}`,
          subLotId: `split-badem-${item.id}`,
          subLotCode: `${selectedRefId || ''}-${String.fromCharCode(charCode++)}`,
          kaliteSinifi: `Premium (${item.meydany})`,
          quantityKg: Number(item.agramyKg),
          packageType: item.haltaSany,
          packageCount: 1,
          destination: item.girisYeri || destination,
          targetMarket: 'Eksport & İç Piyasa (Premium Maňyz)',
          temperatureRequirement: 16.0,
          notes: `${item.arassalananGornusi || ''} - ${item.badamSorty}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    bademPassport.sortlamaItems.forEach(item => {
      if (item.agramyKg > 0) {
        newLots.push({
          id: `split-badem-${item.id}`,
          subLotId: `split-badem-${item.id}`,
          subLotCode: `${selectedRefId || ''}-${String.fromCharCode(charCode++)}`,
          kaliteSinifi: `${item.sortlamaGaplama || ''} (${item.meydany})`,
          quantityKg: Number(item.agramyKg),
          packageType: item.haltaSany,
          packageCount: 1,
          destination: item.girisYeri || destination,
          targetMarket: item.sortlamaGaplama === 'Pak we heňli' ? 'Sanayi / İmha' : 'İç Piyasa',
          temperatureRequirement: 16.0,
          notes: `${item.sortlamaGaplama || ''} - ${item.badamSorty}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    setSplitLots(newLots);
    alert(`🥜 Badam Çykyş we Giriş Depderçesinden ${newLots.length} alt-parti (Jemi: ${bademSums.totalKg} kg) Parçalı Yüke aktarıldı.`);
  };

  // ----------------------------------------------------
  // Split Lots: 6 Standart Sınıfa Bölme Şablonları (NaNsız)
  // ----------------------------------------------------
  const handleApplySixClassesPreset = () => {
    const total = safeTotalKg > 0 ? safeTotalKg : 4800;

    // Banana vs Fruit ratios
    const ratios = fruitCategory === 'MUZ'
      ? [0.35, 0.30, 0.20, 0.08, 0.04, 0.03] // Extra %35, Class I %30, Class II %20, Class III %8, Mix %4, Sanayi %3
      : [0.30, 0.35, 0.20, 0.08, 0.04, 0.03]; // General Fruit ratio

    const newLots: SplitLotItem[] = STANDARD_QUALITY_CLASSES.map((qc, i) => {
      const subLotLetter = String.fromCharCode(65 + i);
      const isNonStandard = qc.isProcessingOrNonStandard || qc.key.includes('Standart Däl') || qc.key.includes('Mix');
      const allocated = Number((total * ratios[i]).toFixed(3));

      let targetDestination = destination;
      if (fruitCategory === 'MUZ') {
        targetDestination = isNonStandard
          ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)'
          : 'Hemsaýa Muz Gazlama & Olgunlaşdyryş';
      } else {
        targetDestination = isNonStandard
          ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)'
          : 'Datly Miwe Merkez Sowuk Depo';
      }

      return {
        subLotId: `${selectedRefId || ''}-${subLotLetter}`,
        variety: customVariety,
        qualityGrade: qc.key,
        quantityKg: allocated,
        caseCount: Math.round(allocated / 20),
        palletCount: Math.round(allocated / 360),
        destination: targetDestination,
        notes: `${qc.nameTm} (${qc.nameTr}) standart sınıfı ayrıştırıldı.`,
        timestamp: new Date().toISOString()
      };
    });

    setSplitLots(newLots);
  };

  const handleApplyFreshVsFreezeDryPreset = () => {
    const total = safeTotalKg > 0 ? safeTotalKg : 4500;
    const freshKg = Number((total * 0.85).toFixed(3));
    const freezeDryKg = Number((total * 0.15).toFixed(3));

    const newLots: SplitLotItem[] = [
      {
        subLotId: `${selectedRefId || ''}-A`,
        variety: customVariety,
        qualityGrade: 'I (V-22) EXC',
        quantityKg: freshKg,
        caseCount: Math.round(freshKg / 20),
        palletCount: Math.round(freshKg / 360),
        destination: fruitCategory === 'MUZ' ? 'Hemsaýa Muz Gazlama & Olgunlaşdyryş' : 'Datly Miwe Merkez Sowuk Depo',
        notes: '1. Sınıf Taze Ticari Satış / Soğuk Depo',
        timestamp: new Date().toISOString()
      },
      {
        subLotId: `${selectedRefId || ''}-B`,
        variety: customVariety,
        qualityGrade: 'Standart Däl / Standart Dışı',
        quantityKg: freezeDryKg,
        caseCount: Math.round(freezeDryKg / 20),
        palletCount: Math.round(freezeDryKg / 360),
        destination: 'Erem Freeze-Dry Tesisi (-40°C Şoklama)',
        notes: 'Standart Dışı / Liyofilizasyon & Freeze-Dry Ayrımı',
        timestamp: new Date().toISOString()
      }
    ];

    setSplitLots(newLots);
  };

  const handleDistributeEvenly = () => {
    if (splitLots.length === 0) return;
    const total = safeTotalKg > 0 ? safeTotalKg : 4200;
    const count = splitLots.length;
    const perLot = Number((total / count).toFixed(3));

    const updated = splitLots.map(item => ({
      ...item,
      quantityKg: perLot,
      caseCount: Math.round(perLot / 20)
    }));
    setSplitLots(updated);
  };

  // Distribute remaining kg to the last lot (NaN-safe)
  const handleAssignRemainingToLast = () => {
    if (splitLots.length === 0) return;
    const lastIdx = splitLots.length - 1;
    const updated = [...splitLots];
    const currentLastKg = Number(updated[lastIdx].quantityKg) || 0;
    const newLastKg = Number((currentLastKg + remainingSplitKg).toFixed(3));

    updated[lastIdx] = {
      ...updated[lastIdx],
      quantityKg: newLastKg,
      caseCount: Math.round(newLastKg / 20)
    };
    setSplitLots(updated);
  };

  // Sync Form weightKg from allocated split lots
  const handleSyncFormWeightFromSplit = () => {
    if (allocatedSplitKg > 0) {
      setWeightKg(Number(allocatedSplitKg.toFixed(3)));
    }
  };

  // Add a single custom split row
  const handleAddSplitRow = () => {
    const nextIdx = splitLots.length + 1;
    const subLotLetter = String.fromCharCode(64 + nextIdx);
    const subLotId = `${selectedRefId || ''}-${subLotLetter}`;

    const newLot: SplitLotItem = {
      subLotId,
      variety: customVariety,
      qualityGrade: 'EXTRA (V-20)',
      quantityKg: remainingSplitKg > 0 ? remainingSplitKg : 0,
      caseCount: remainingSplitKg > 0 ? Math.round(remainingSplitKg / 20) : 0,
      palletCount: 1,
      destination: destination,
      notes: '',
      timestamp: new Date().toISOString()
    };

    setSplitLots([...splitLots, newLot]);
  };

  // Update split row
  const handleUpdateSplitRow = (index: number, field: keyof SplitLotItem, val: any) => {
    const updated = [...splitLots];
    let sanitizedVal = val;
    if (field === 'quantityKg') {
      const num = Number(val);
      sanitizedVal = Number.isFinite(num) ? Math.max(0, num) : 0;
    }

    updated[index] = {
      ...updated[index],
      [field]: sanitizedVal
    };

    // Auto-update caseCount if quantity changed
    if (field === 'quantityKg' && (!updated[index].caseCount || updated[index].caseCount === 0)) {
      updated[index].caseCount = Math.round(Number(sanitizedVal) / 20);
    }

    setSplitLots(updated);
  };

  const handleDeleteSplitRow = (index: number) => {
    setSplitLots(splitLots.filter((_, i) => i !== index));
  };

  // ----------------------------------------------------
  // Delilnama Handlers & Row Manipulation
  // ----------------------------------------------------
  const handleUpdateDelilnamaRow = (index: number, field: keyof DelilnamaGradeRow, val: any) => {
    const updatedGrades = [...delilnamaPassport.grades];
    const num = Number(val);
    const sanitizedVal = Number.isFinite(num) ? Math.max(0, num) : 0;

    updatedGrades[index] = {
      ...updatedGrades[index],
      [field]: sanitizedVal
    };

    // Auto-calculate case count if hasylNetKg changed
    if (field === 'hasylNetKg' && (!updatedGrades[index].gapSany || updatedGrades[index].gapSany === 0)) {
      updatedGrades[index].gapSany = Math.round(sanitizedVal / 20);
    }

    setDelilnamaPassport(prev => ({
      ...prev,
      grades: updatedGrades
    }));
  };

  const handleDeleteDelilnamaRow = (index: number) => {
    setDelilnamaPassport(prev => ({
      ...prev,
      grades: prev.grades.filter((_, i) => i !== index)
    }));
  };

  const handleAddDelilnamaRow = () => {
    const matchClass = STANDARD_QUALITY_CLASSES.find(c => c.key === newGradeKey);
    const newRow: DelilnamaGradeRow = {
      gradeKey: newGradeKey,
      gradeLabelTr: matchClass?.nameTr || newGradeKey,
      yassikliKg: 0,
      hasylNetKg: 0,
      satysaBerlenKg: 0,
      gapSany: 0
    };

    setDelilnamaPassport(prev => ({
      ...prev,
      grades: [...prev.grades, newRow]
    }));
  };

  // Transfer Delilnama net kg into Form weight and split lots
  const handleTransferDelilnamaToFormAndSplit = () => {
    if (delilnamaSums.totalNet > 0) {
      setWeightKg(delilnamaSums.totalNet);
      setCaseCount(delilnamaSums.totalGap);

      // Also transfer to split lots
      const newLots: SplitLotItem[] = delilnamaPassport.grades.map((g, i) => {
        const subLotLetter = String.fromCharCode(65 + i);
        const isNonStandard = g.gradeKey.includes('Standart Däl') || g.gradeKey.includes('Mix');
        return {
          subLotId: `${selectedRefId || ''}-${subLotLetter}`,
          variety: customVariety,
          qualityGrade: g.gradeKey,
          quantityKg: g.hasylNetKg,
          caseCount: g.gapSany || Math.round(g.hasylNetKg / 20),
          palletCount: Math.round(g.hasylNetKg / 360) || 1,
          destination: isNonStandard ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)' : destination,
          notes: `Delilnama pasaportundan aktarıldı (${g.gradeKey}).`,
          timestamp: new Date().toISOString()
        };
      });

      setSplitLots(newLots);
    }
  };

  // Datalogger Yönetim İşleyicileri
  const handleOpenAddLogger = () => {
    setEditingLoggerId(null);
    setLogBrand('Copeland');
    setLogDeviceId('');
    setLogPlacement('PALET_ICI');
    setLogSourceTz('UTC');
    setLogDateFormat('AUTO');
    setLogUpperLimit(currentProductSpec.transportTempMaxC !== null ? currentProductSpec.transportTempMaxC : '');
    setLogLowerLimit(currentProductSpec.transportTempMinC !== null ? currentProductSpec.transportTempMinC : '');
    setCsvRawText('');
    setCsvFileName('');
    setCsvPreview(null);
    setManualMinC('');
    setManualMaxC('');
    setManualAvgC('');
    setManualMktC('');
    setManualStartAt(loadingDate || '');
    setManualStopAt(arrivalDate || '');
    setManualMinutesAbove('');
    setManualMinutesBelow('');
    setManualViolations('');
    setLoggerModalTab('CSV');
    setShowLoggerModal(true);
  };

  const handleEditLogger = (logger: DataloggerRecord) => {
    setEditingLoggerId(logger.id);
    setLogBrand(logger.brand || 'Copeland');
    setLogDeviceId(logger.deviceId);
    setLogPlacement(logger.placement || 'PALET_ICI');
    setLogSourceTz(logger.sourceTimezone || 'UTC');
    setLogUpperLimit(logger.upperLimitC !== undefined ? logger.upperLimitC : '');
    setLogLowerLimit(logger.lowerLimitC !== undefined ? logger.lowerLimitC : '');
    setCsvRawText('');
    setCsvFileName(logger.fileName || '');
    setCsvPreview(null);

    const stats = logger.tripStats || logger.fullStats;
    setManualMinC(stats?.minC !== undefined ? stats.minC : '');
    setManualMaxC(stats?.maxC !== undefined ? stats.maxC : '');
    setManualAvgC(stats?.avgC !== undefined ? stats.avgC : '');
    setManualMktC(stats?.mktC !== undefined ? stats.mktC : '');
    setManualStartAt(stats?.startAt || '');
    setManualStopAt(stats?.stopAt || '');
    setManualMinutesAbove(stats?.minutesAboveUpper !== undefined ? stats.minutesAboveUpper : '');
    setManualMinutesBelow(stats?.minutesBelowLower !== undefined ? stats.minutesBelowLower : '');
    setManualViolations(stats?.violationCount !== undefined ? stats.violationCount : '');

    setLoggerModalTab(logger.source === 'CSV' ? 'CSV' : 'MANUEL');
    setShowLoggerModal(true);
  };

  const handleDeleteLogger = (id: string) => {
    setDataloggers(prev => prev.filter(l => l.id !== id));
  };

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setCsvRawText(content);
        const parsed = parseLoggerCsv(content, { dateFormat: logDateFormat, sourceTimezone: logSourceTz });
        setCsvPreview({ headers: parsed.headers, rows: parsed.previewRows });
        if (!logDeviceId && file.name) {
          const match = file.name.match(/[A-Z0-9_-]{4,}/i);
          if (match) setLogDeviceId(match[0].toUpperCase());
        }
      }
    };
    reader.readAsText(file);
  };

  const handleSaveLogger = () => {
    if (!logDeviceId.trim()) {
      alert('Lütfen cihaz kimliği (Device ID) girin.');
      return;
    }

    const upperNum = logUpperLimit !== '' ? Number(logUpperLimit) : undefined;
    const lowerNum = logLowerLimit !== '' ? Number(logLowerLimit) : undefined;

    if (loggerModalTab === 'CSV') {
      if (!csvRawText && !editingLoggerId) {
        alert('Lütfen bir CSV / TSV dosyası yükleyin.');
        return;
      }

      let parsedReadings: DataloggerReading[] = [];
      if (csvRawText) {
        const parsed = parseLoggerCsv(csvRawText, { dateFormat: logDateFormat, sourceTimezone: logSourceTz });
        parsedReadings = parsed.readings;
      } else if (editingLoggerId) {
        const existing = dataloggers.find(l => l.id === editingLoggerId);
        parsedReadings = existing?.series || [];
      }

      const fullStats = computeStats(parsedReadings, { upper: upperNum, lower: lowerNum });
      const tripStats = (loadingDate || arrivalDate)
        ? computeStats(parsedReadings, {
            upper: upperNum,
            lower: lowerNum,
            from: loadingDate ? new Date(loadingDate).toISOString() : null,
            to: arrivalDate ? new Date(arrivalDate).toISOString() : null
          })
        : fullStats;

      const downsampledSeries = downsample(parsedReadings, 500);
      const existingLogger = editingLoggerId ? dataloggers.find(l => l.id === editingLoggerId) : null;
      const isEditedAfter = existingLogger?.source === 'CSV' ? true : false;

      const newRecord: DataloggerRecord = {
        id: editingLoggerId || `dlg-${Date.now()}`,
        brand: logBrand.trim() || undefined,
        deviceId: logDeviceId.trim().toUpperCase(),
        placement: logPlacement,
        sourceTimezone: logSourceTz,
        upperLimitC: upperNum,
        lowerLimitC: lowerNum,
        fullStats,
        tripStats,
        series: downsampledSeries,
        source: 'CSV',
        fileName: csvFileName || existingLogger?.fileName,
        editedAfterImport: isEditedAfter
      };

      setDataloggers(prev => {
        const idx = prev.findIndex(l => l.id === newRecord.id);
        if (idx !== -1) {
          const updated = [...prev];
          updated[idx] = newRecord;
          return updated;
        }
        return [...prev, newRecord];
      });
    } else {
      // MANUEL MODE
      const statsObj: DataloggerStats = {
        minC: manualMinC !== '' ? Number(manualMinC) : undefined,
        maxC: manualMaxC !== '' ? Number(manualMaxC) : undefined,
        avgC: manualAvgC !== '' ? Number(manualAvgC) : undefined,
        mktC: manualMktC !== '' ? Number(manualMktC) : undefined,
        startAt: manualStartAt || undefined,
        stopAt: manualStopAt || undefined,
        minutesAboveUpper: manualMinutesAbove !== '' ? Number(manualMinutesAbove) : undefined,
        minutesBelowLower: manualMinutesBelow !== '' ? Number(manualMinutesBelow) : undefined,
        violationCount: manualViolations !== '' ? Number(manualViolations) : undefined
      };

      const existingLogger = editingLoggerId ? dataloggers.find(l => l.id === editingLoggerId) : null;
      const isEditedAfter = existingLogger?.source === 'CSV' ? true : false;

      const newRecord: DataloggerRecord = {
        id: editingLoggerId || `dlg-${Date.now()}`,
        brand: logBrand.trim() || undefined,
        deviceId: logDeviceId.trim().toUpperCase(),
        placement: logPlacement,
        sourceTimezone: logSourceTz,
        upperLimitC: upperNum,
        lowerLimitC: lowerNum,
        fullStats: statsObj,
        tripStats: statsObj,
        source: existingLogger?.source === 'CSV' ? 'CSV' : 'MANUEL',
        fileName: existingLogger?.fileName,
        editedAfterImport: isEditedAfter
      };

      setDataloggers(prev => {
        const idx = prev.findIndex(l => l.id === newRecord.id);
        if (idx !== -1) {
          const updated = [...prev];
          updated[idx] = newRecord;
          return updated;
        }
        return [...prev, newRecord];
      });
    }

    setShowLoggerModal(false);
  };

  // Form Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let finalRefId = selectedRefId.trim() || initialRecord?.refId || '';
    if (!finalRefId) {
      // v2.8: bir parti = bir numara. Lojistik yeni numara açmaz (yalnızca yönetici, istisna olarak)
      if (getCurrentUser()?.role !== 'ADMIN') {
        window.alert('Bu adım yeni parti numarası açmaz. Listeden işlem yapılacak partiyi seçin (hasat veya depo kabulde açılan numara).');
        return;
      }
      if (!window.confirm('Seçili parti yok. Yönetici olarak yeni bir lojistik numarası açılsın mı? (Aynı meyve iki numara alabilir.)')) return;
      finalRefId = generateRefId('LOJISTIK', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || getCurrentUser()?.fullName || ''; // v2.8: unvan değil kişi

    const lojistikRecord: LojistikRecord = {
      id: initialRecord?.id || `l-${Date.now()}`,
      refId: finalRefId,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      shipmentDate,
      source: source.trim() || 'Merkez Soğuk Hava Deposu',
      destination: destination.trim() || 'Aşgabat / İhracat',
      vehiclePlate: fruitCategory === 'BADEM' && bademPassport.ulagBelgisi ? bademPassport.ulagBelgisi : (vehiclePlate.trim() || 'AG 7721 AH'),
      driver: driver.trim() || 'Merdan Orazow',
      driverPhone,
      delilnamaNo: fruitCategory === 'BADEM' ? bademPassport.depderceNo : (delilnamaNo.trim() || ''),
      transportType: transportType.trim() || 'Frigorifik Tır (Reefer)',
      palletCount: Math.max(1, palletCount),
      caseCount: Math.max(1, caseCount),
      weightKg: fruitCategory === 'BADEM' && bademSums.totalKg > 0 ? bademSums.totalKg : safeTotalKg,
      departureTemperature: (departureTemperature ?? undefined) as any,
      transitTemperature: (transitTemperature ?? undefined) as any,
      kaliteSinifi,
      fruitCategory,
      product: fruitCategory === 'BADEM' ? 'Badem' : (fruitCategory === 'MUZ' ? 'Muz' : (customFruit.trim() || 'Belirtilmedi')),
      variety: customVariety.trim() || undefined,
      delilnama: fruitCategory === 'BADEM' ? undefined : (enableDelilnama ? delilnamaPassport : undefined),
      bademDelilnama: fruitCategory === 'BADEM' ? bademPassport : undefined,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      status,
      notes,
      photos: photos.length > 0 ? photos : undefined,

      // Konteyner, Reefer & Datalogger
      containerNo: containerNo.trim() || undefined,
      sealNo: sealNo.trim() || undefined,
      transportMode: transportMode || undefined,
      portOfDeparture: portOfDeparture.trim() || undefined,
      portOfArrival: portOfArrival.trim() || undefined,
      loadingDate: loadingDate || undefined,
      arrivalDate: arrivalDate || undefined,
      transitDays: transitDays !== undefined ? transitDays : undefined,
      reeferSetpointC: reeferSetpointC !== '' ? Number(reeferSetpointC) : undefined,
      reeferSupplyC: reeferSupplyC !== '' ? Number(reeferSupplyC) : undefined,
      dataloggers: dataloggers.length > 0 ? dataloggers : undefined
    };

    onSave(lojistikRecord, finalRefId);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
      {/* Top Header */}
      <div className="bg-white text-slate-900 px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 shadow-xs">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 ">
              <span>Lojistik ve sevkiyat</span>
            </h2>
            <p className="text-xs text-slate-500">
              Kalite pasaportu, sınıflara bölme, parçalı yük ve soğuk zincir
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {enableDelilnama && (
            <button
              type="button"
              onClick={() => setShowPrintModal(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-slate-900 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg transition shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Baskılı Koçan Önizle</span>
            </button>
          )}

          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white px-3 py-1.5 rounded-lg transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* 1. DİNAMİK MEYVE SEÇİMİ (Muz vs Diğer Meyveler) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-blue-200/60">
            <div>
              <span className="text-xs font-bold text-blue-900 block ">
                1. Dinamik Meyve ve Standart Seçimi
              </span>
              <p className="text-xs text-slate-600">
                Meyve tipine göre kalite klasları, koçan şablonları ve hedef sevkiyat sıcaklıkları otomatik uyarlanır.
              </p>
            </div>

            {/* Toggle Buttons */}
            <div className="flex items-center bg-white p-1 rounded-xl border border-blue-300 shadow-xs flex-wrap gap-1">
              <button
                type="button"
                onClick={() => handleFruitCategoryChange('MUZ')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                  fruitCategory === 'MUZ'
                    ? 'bg-amber-400 text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Muz (Cavendish / Sera)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFruitCategoryChange('DIGER')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                  fruitCategory === 'DIGER'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Diğer Meyveler (Bahçe / Meyve)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFruitCategoryChange('BADEM')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                  fruitCategory === 'BADEM'
                    ? 'bg-amber-700 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Badem (Miweli Atyz / Depderçe)</span>
              </button>
            </div>
          </div>

          {/* Fruit Category Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                {fruitCategory === 'MUZ' ? 'Meyve Adı' : fruitCategory === 'BADEM' ? 'Ürün / Tesis Standardı' : 'Meyve Türü Seçin / Yazın *'}
              </label>
              {fruitCategory === 'MUZ' ? (
                <div className="w-full text-xs font-bold bg-amber-50 border border-amber-300 text-amber-950 rounded-lg px-3 py-2 flex items-center justify-between">
                  <span>Muz (Hemsaýa Sera Muz)</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded tabular-nums">STANDART</span>
                </div>
              ) : fruitCategory === 'BADEM' ? (
                <div className="w-full text-xs font-bold bg-amber-50 border border-amber-300 text-amber-950 rounded-lg px-3 py-2 flex items-center justify-between">
                  <span>Badem (Miweli Atyz Badam Zawod)</span>
                  <span className="text-[10px] bg-amber-700 text-white px-2 py-0.5 rounded tabular-nums font-bold">Resmi depderçe</span>
                </div>
              ) : (
                <>
                  {/* v2.8: liste kayıtlardaki ürünlerden + yaygın meyvelerden oluşur; "Diğer" ile serbest yazılır */}
                  <input
                    list="lojistik-fruit-options"
                    value={customFruit}
                    onChange={(e) => setCustomFruit(e.target.value)}
                    placeholder="Ürün seçin veya yazın (örn. Hurma)"
                    className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
                  />
                  <datalist id="lojistik-fruit-options">
                    {Array.from(new Set([
                      ...existingRefs.map(r => r.product).filter(p => p && !/muz|badem/i.test(p)),
                      'Elma', 'Hurma', 'Şeftali', 'Nektarin', 'Kiraz', 'Erik', 'Kayısı', 'Armut', 'Üzüm', 'Nar', 'Çilek', 'İncir'
                    ])).map(p => <option key={p} value={p} />)}
                  </datalist>
                </>
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                {fruitCategory === 'BADEM' ? 'Badamyň Sorty (Çeşit) *' : 'Çeşit / Sort (Görnüşi) *'}
              </label>
              {fruitCategory === 'BADEM' ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customVariety}
                    onChange={(e) => setCustomVariety(e.target.value)}
                    className="w-full text-xs font-bold bg-white border border-amber-300 rounded-lg px-3 py-2 tabular-nums text-slate-900"
                    placeholder="Laurenne, Nonpareil, Ferragnes..."
                   
                  />
                  <select
                    onChange={(e) => setCustomVariety(e.target.value)}
                    className="text-xs bg-amber-50 border border-amber-300 rounded-lg px-2 font-bold text-amber-900 cursor-pointer"
                    value={customVariety}
                  >
                    <option value="Laurenne">Laurenne</option>
                    <option value="Nonpareil">Nonpareil</option>
                    <option value="Ferragnes">Ferragnes</option>
                    <option value="Guara">Guara</option>
                  </select>
                </div>
              ) : (
                <input
                  type="text"
                  value={customVariety}
                  onChange={(e) => setCustomVariety(e.target.value)}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-800"
                  placeholder="Örn: Cavendish, Extreme 314, Lapins..."
                 
                />
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Hedef Taşıma Sıcaklığı Tavsiyesi
              </label>
              <div className="w-full text-xs font-bold bg-white border border-blue-200 rounded-lg px-3 py-2 flex items-center justify-between text-blue-900">
                <span>
                  {fruitCategory === 'MUZ'
                    ? '🍌 Muz İdeal: 13.5°C'
                    : fruitCategory === 'BADEM'
                    ? '🥜 Badem İdeal: 15°C - 18°C (Kuru)'
                    : '🍎 Soğuk Depo: 1°C - 4°C'}
                </span>
                <span className="text-[10px] bg-blue-100 px-2 py-0.5 rounded text-blue-800 tabular-nums font-bold">TERMO</span>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Reference Badge / Selector */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] font-bold text-slate-800 block mb-1">
              Sevkiyat Yapılacak Parti / Referans (RefID Seçin veya Yazın)
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                list="lojistik-ref-list"
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                placeholder="Örn: REF-101 veya listeden seçin..."
                className="w-full md:w-96 text-xs tabular-nums font-bold bg-white border border-blue-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-blue-500"
              />
              <datalist id="lojistik-ref-list">
                {existingRefs.map(r => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} — {r.product} ({r.quantity} {r.unit}) [{r.status}]
                  </option>
                ))}
              </datalist>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs flex-wrap">
            <div className="bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 block font-semibold">Seçili Referans Ürünü</span>
              <strong className="text-slate-900 font-bold">{selectedRef?.product || (fruitCategory === 'MUZ' ? 'Muz' : customFruit)}</strong>
            </div>
            <div className="bg-emerald-50 text-slate-900 px-3.5 py-2 rounded-xl border border-emerald-200 shadow-sm flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
              <div>
                <span className="text-[9px] font-bold text-emerald-700 block">
                  Tamamlanmış Hasat Miktarı (Salt Okunur)
                </span>
                <strong className="tabular-nums text-emerald-700 text-sm block">
                  {selectedRef?.quantity ? `${Number(selectedRef.quantity).toLocaleString('tr-TR')} kg` : '0 kg'}
                  <span className="text-[10px] text-slate-500 ml-1">
                    ({selectedRef?.quantity ? (Number(selectedRef.quantity) / 1000).toFixed(2) : '0.00'} Ton)
                  </span>
                </strong>
              </div>
            </div>
          </div>
        </div>

        {/* Dispatch & Driver Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Operatör / Sevkiyat Sorumlusu *
            </label>
            <input
              type="text"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Resmi Delilnama No (Baskılı Koçan №) (Opsiyonel)
            </label>
            <div className="relative">
              <input
                type="text"
                value={delilnamaNo}
                onChange={(e) => setDelilnamaNo(e.target.value)}
                placeholder="Örn: 0005421 (İsteğe bağlı)"
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-blue-900"
              />
              <FileText className="w-3.5 h-3.5 text-blue-500 absolute right-2.5 top-2.5" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat Tarihi (Sene)
            </label>
            <input
              type="date"
              value={shipmentDate}
              onChange={(e) => setShipmentDate(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Taşıma Tipi / Araç Standardı
            </label>
            <select
              value={transportType}
              onChange={(e) => setTransportType(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-semibold"
            >
              {AUTOCOMPLETE_LISTS.transportTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Çıkış Yeri (Kaynak / Ýeri)
            </label>
            <input
              type="text"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <SmartCreatableSelect
              label="Varış Yeri / Hedef Tesis (Opsiyonel)"
              categoryKey="destinations"
              options={[]}
              value={destination}
              onChange={setDestination}
              placeholder="Hedef tesis seçin veya yeni ekleyin..."
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Araç Plakası *
            </label>
            <input
              type="text"
              value={vehiclePlate}
              onChange={(e) => setVehiclePlate(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold"
              placeholder="74 AG 912"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sürücü Adı & Telefon
            </label>
            <div className="flex gap-1">
              <input
                type="text"
                value={driver}
                onChange={(e) => setDriver(e.target.value)}
                className="w-1/2 text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                placeholder="Ad Soyad"
              />
              <input
                type="text"
                value={driverPhone}
                onChange={(e) => setDriverPhone(e.target.value)}
                className="w-1/2 text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 tabular-nums"
                placeholder="+993..."
              />
            </div>
          </div>
        </div>

        {/* Quantity & Temperature Monitoring (NaN-Safe) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Toplam Net Ağırlık (kg) *
            </label>
            <input
              type="number"
              value={weightKg}
              onChange={(e) => {
                const val = Number(e.target.value);
                setWeightKg(Number.isFinite(val) ? Math.max(0, val) : 0);
              }}
              className="w-full text-xs bg-white border border-blue-300 rounded-lg px-3 py-2 tabular-nums font-bold text-slate-900 shadow-xs"
             
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Palet Adedi
            </label>
            <input
              type="number"
              value={palletCount}
              onChange={(e) => setPalletCount(Number(e.target.value))}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Kasa / Kutu Adedi (Gap Sany)
            </label>
            <input
              type="number"
              value={caseCount}
              onChange={(e) => setCaseCount(Number(e.target.value))}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 block">
                Çıkış Yükleme Isısı (°C)
              </label>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="number"
                step="0.1"
                value={departureTemperature ?? ''}
                placeholder="ölçülmedi"
                onChange={(e) => setDepartureTemperature(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-blue-700"
              />
              <Thermometer className="w-4 h-4 text-blue-500" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Taşıma sıcaklığı — ölçülen (°C)
            </label>
            <div className="flex items-center gap-1">
              <input
                type="number"
                step="0.1"
                value={transitTemperature ?? ''}
                placeholder="ölçülmedi"
                onChange={(e) => setTransitTemperature(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-blue-700"
              />
              <Thermometer className="w-4 h-4 text-blue-500" />
            </div>
          </div>
        </div>

        {/* Ana Kalite Sınıfı (Hil Derejesi) Seçimi */}
        <div className="bg-blue-50/50 border border-blue-200 rounded-2xl p-4">
          <QualityGradeSelect
            value={kaliteSinifi}
            onChange={setKaliteSinifi}
            label={`Sevkiyat Ana Kalite Sınıfı (${fruitCategory === 'MUZ' ? 'Muz Hil Derejesi' : 'Hil Derejesi'})`}
            subLabel="Araca yüklenen ürünlerin ana kalite klasmanı ve sevk irsaliyesi başlığı"
           
          />
        </div>

        {/* BÖLÜM: Konteyner & Reefer */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-blue-600 text-white rounded-xl shadow-xs">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Konteyner &amp; Reefer</h3>
                <p className="text-[11px] text-slate-500">Konteyner mühür, seyahat modu ve soğutucu reefer ayarları</p>
              </div>
            </div>
            {transitDays !== undefined && (
              <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 tabular-nums text-xs font-bold border border-blue-200">
                Transit: {transitDays} Gün
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Konteyner Numarası</label>
              <input
                type="text"
                value={containerNo}
                onChange={(e) => setContainerNo(e.target.value.toUpperCase())}
                placeholder="Örn: MSKU 149 668 5"
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Mühür No (Seal No)</label>
              <input
                type="text"
                value={sealNo}
                onChange={(e) => setSealNo(e.target.value.toUpperCase())}
                placeholder="Örn: ML-TR 778974"
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Taşıma Modu</label>
              <select
                value={transportMode}
                onChange={(e) => setTransportMode(e.target.value as any)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-800"
              >
                <option value="DENIZ">DENİZ (Sea Freight / Reefer Container)</option>
                <option value="KARA">KARA (Road Transport / Frigo Tır)</option>
                <option value="HAVA">HAVA (Air Cargo / Express)</option>
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Çıkış Limanı / Yeri (Port of Departure)</label>
              <input
                type="text"
                value={portOfDeparture}
                onChange={(e) => setPortOfDeparture(e.target.value)}
                placeholder="Örn: Mersin / Türkmenbaşy Limanı"
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Varış Limanı / Yeri (Port of Arrival)</label>
              <input
                type="text"
                value={portOfArrival}
                onChange={(e) => setPortOfArrival(e.target.value)}
                placeholder="Örn: Rotterdam / Saint Petersburg"
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Transit Süre (Salt Okunur)</label>
              <input
                type="text"
                readOnly
                value={transitDays !== undefined ? `${transitDays} Gün` : '—'}
                className="w-full bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 tabular-nums font-bold text-slate-600 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Yükleme Tarihi (Loading Date)</label>
              <input
                type="date"
                value={loadingDate}
                onChange={(e) => setLoadingDate(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-900"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Varış Tarihi (Arrival Date)</label>
              <input
                type="date"
                value={arrivalDate}
                onChange={(e) => setArrivalDate(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-900"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="font-bold text-slate-700 block mb-1 text-[11px]">Reefer Set (°C)</label>
                <input
                  type="number"
                  step="0.1"
                  value={reeferSetpointC}
                  onChange={(e) => setReeferSetpointC(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Örn: 5.0"
                  className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-2 tabular-nums font-bold text-blue-700"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1 text-[11px]">Reefer Supply (°C)</label>
                <input
                  type="number"
                  step="0.1"
                  value={reeferSupplyC}
                  onChange={(e) => setReeferSupplyC(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Örn: 4.3"
                  className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-2 tabular-nums font-bold text-blue-700"
                />
              </div>
            </div>
          </div>
        </div>

        {/* BÖLÜM: Datalogger Sıcaklık Takibi */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-xs">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Datalogger Sıcaklık Takip Cihazları</h3>
                <p className="text-[11px] text-slate-500">Sefer boyunca sıcaklık eğrisi, MKT ve eşik aşımları</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleOpenAddLogger}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Logger Ekle</span>
            </button>
          </div>

          {/* İki logger arası çelişki uyarısı */}
          {loggerConflictWarning && (
            <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-950 text-xs flex items-center gap-2.5 font-bold animate-in fade-in">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <span>{loggerConflictWarning}</span>
            </div>
          )}

          {/* Bilgi Kutusu */}
          <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-[11px] text-blue-900 flex flex-col sm:flex-row gap-2 justify-between items-start sm:items-center">
            <div className="flex items-center gap-1.5 font-medium">
              <Info className="w-4 h-4 text-blue-600 shrink-0" />
              <span>Excel dosyasını CSV olarak kaydedip yükleyin.</span>
            </div>
            <div className="text-slate-600 font-medium">
              PDF'in ilk sayfasını fotoğraf olarak <strong className="text-blue-900 tabular-nums">DATALOGGER</strong> etiketiyle ekleyin.
            </div>
          </div>

          {/* Kayıtlı Loggerlar Listesi */}
          {dataloggers.length === 0 ? (
            <div className="p-6 bg-white rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-400">
              Henüz datalogger kaydı eklenmedi. "Logger Ekle" butonuna basarak CSV yükleyebilir veya elle değer girebilirsiniz.
            </div>
          ) : (
            <div className="space-y-4">
              {dataloggers.map((logger) => {
                const stats = logger.tripStats || logger.fullStats;
                return (
                  <div key={logger.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="tabular-nums font-bold text-slate-900 text-sm">{logger.deviceId}</span>
                        {logger.brand && (
                          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                            {logger.brand}
                          </span>
                        )}
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                          {logger.placement === 'PALET_ICI' ? 'Palet İçi' :
                           logger.placement === 'HAVA_CIKISI' ? 'Hava Çıkışı' :
                           logger.placement === 'HAVA_DONUSU' ? 'Hava Dönüşü' :
                           logger.placement === 'KAPI_TARAFI' ? 'Kapı Tarafı' : 'Diğer Konum'}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 tabular-nums text-slate-600 text-[10px]">
                          {logger.sourceTimezone || 'UTC'}
                        </span>
                        <span className="text-[10px] font-bold text-slate-500">
                          [{logger.source === 'CSV' ? 'CSV İçe Aktarım' : 'Manuel Giriş'}]
                        </span>
                        {logger.editedAfterImport && (
                          <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-bold">
                            Elle Düzenlendi
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleEditLogger(logger)}
                          className="p-1 hover:bg-slate-100 rounded text-slate-600 transition cursor-pointer"
                          title="Düzenle"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLogger(logger.id)}
                          className="p-1 hover:bg-rose-50 rounded text-rose-600 transition cursor-pointer"
                          title="Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 text-xs">
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-500 block">Min Sıcaklık</span>
                        <span className="tabular-nums font-bold text-blue-700">{stats?.minC !== undefined ? `${stats.minC} °C` : '—'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-500 block">Maks Sıcaklık</span>
                        <span className="tabular-nums font-bold text-rose-700">{stats?.maxC !== undefined ? `${stats.maxC} °C` : '—'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-500 block">Ortalama</span>
                        <span className="tabular-nums font-bold text-slate-800">{stats?.avgC !== undefined ? `${stats.avgC} °C` : '—'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-100">
                        <span className="text-[10px] text-emerald-700 block font-bold">MKT (Kinetik)</span>
                        <span className="tabular-nums font-bold text-emerald-800">{stats?.mktC !== undefined ? `${stats.mktC} °C` : '—'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-500 block">Eşik Üstü Süre</span>
                        <span className="tabular-nums font-bold text-amber-700">{stats?.minutesAboveUpper !== undefined ? `${stats.minutesAboveUpper} dk` : '—'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-500 block">İhlal Sayısı</span>
                        <span className="tabular-nums font-bold text-slate-800">{stats?.violationCount !== undefined ? stats.violationCount : '0'}</span>
                      </div>
                    </div>

                    {/* Chart (Recharts) */}
                    {logger.series && logger.series.length > 0 && (
                      <div className="pt-2">
                        <div className="text-[10px] font-bold text-slate-500 mb-1 flex items-center justify-between">
                          <span>Sıcaklık Seyri ({logger.series.length} Seyreltilmiş Nokta)</span>
                          <span className="tabular-nums">
                            {logger.upperLimitC !== undefined && `Üst Eşik: ${logger.upperLimitC}°C `}
                            {logger.lowerLimitC !== undefined && `Alt Eşik: ${logger.lowerLimitC}°C`}
                          </span>
                        </div>
                        <div className="w-full h-44 bg-slate-50 rounded-xl p-2 border border-slate-100">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={logger.series}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                              <XAxis dataKey="t" tick={{ fontSize: 9 }} tickFormatter={(v) => v.slice(5, 16).replace('T', ' ')} />
                              <YAxis tick={{ fontSize: 9 }} domain={['auto', 'auto']} unit="°C" />
                              <RechartsTooltip
                                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.5rem', color: '#fff', fontSize: '11px' }}
                                labelFormatter={(v) => `Zaman (UTC): ${String(v).replace('T', ' ').slice(0, 19)}`}
                                formatter={(val: any) => [`${val} °C`, 'Sıcaklık']}
                              />
                              {logger.upperLimitC !== undefined && (
                                <ReferenceLine y={logger.upperLimitC} stroke="#ef4444" strokeDasharray="4 4" label={{ value: `Max ${logger.upperLimitC}°C`, fill: '#ef4444', fontSize: 10 }} />
                              )}
                              {logger.lowerLimitC !== undefined && (
                                <ReferenceLine y={logger.lowerLimitC} stroke="#3b82f6" strokeDasharray="4 4" label={{ value: `Min ${logger.lowerLimitC}°C`, fill: '#3b82f6', fontSize: 10 }} />
                              )}
                              <Line type="monotone" dataKey="c" stroke="#4f46e5" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* 2. DELILNAMA VEYA BADAM DEPDERÇESİ (Resmi Baskılı Standart) */}
        {fruitCategory === 'BADEM' ? (
          /* BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI (№ 0000417) */
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-300">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-800 text-white shadow-xs">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 ">
                    <span>Badam çykyş we gırış depderçesı</span>
                    <span className="text-[10px] font-sans font-bold bg-amber-200 text-amber-950 border border-amber-400 px-2 py-0.5 rounded-md">
                      "MIWE" AGPJ Resmi Koçany
                    </span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    Miweli Atyz senagat badam zawodyndan çykyş, arassalanan maňyz, sortlama & gaplama depderçesi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowPrintModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Resmi Badam Depderçesi Yazdır</span>
                </button>
              </div>
            </div>

            {/* Badem Booklet Meta Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-amber-300 text-xs shadow-xs">
              <div>
                <span className="text-slate-500 font-bold block mb-1">Depderçe № (Koçan No):</span>
                <input
                  type="text"
                  value={bademPassport.depderceNo}
                  onChange={(e) => setBademPassport(p => ({ ...p, depderceNo: e.target.value }))}
                  className="w-full tabular-nums font-bold text-amber-950 bg-amber-50 px-2.5 py-1.5 rounded border border-amber-300 text-xs"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Sene (Tarih):</span>
                <input
                  type="date"
                  value={bademPassport.sene}
                  onChange={(e) => setBademPassport(p => ({ ...p, sene: e.target.value }))}
                  className="w-full tabular-nums font-bold text-slate-800 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200 text-xs"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Ulagyň Belgisi (Plaka):</span>
                <input
                  type="text"
                  value={bademPassport.ulagBelgisi}
                  onChange={(e) => {
                    setBademPassport(p => ({ ...p, ulagBelgisi: e.target.value }));
                    setVehiclePlate(e.target.value);
                  }}
                  className="w-full tabular-nums font-bold text-blue-900 bg-blue-50 px-2.5 py-1.5 rounded border border-blue-200 text-xs"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Bellik (Açıklama / Not):</span>
                <input
                  type="text"
                  value={bademPassport.bellik}
                  onChange={(e) => setBademPassport(p => ({ ...p, bellik: e.target.value }))}
                  placeholder="Big Bag gaplanan täze hasyl..."
                  className="w-full font-bold text-slate-800 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200 text-xs"
                />
              </div>
            </div>

            {/* TABLISA 1: Arassalanan Görnüşi & Esasy Maňyz (Premium Çykyş) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white font-bold text-xs flex items-center justify-center">
                    1
                  </span>
                  <span className="text-xs font-bold text-amber-950 ">
                    Tablisa 1: Arassalanan Görnüşi & Esasy Maňyz (Premium Çykyş)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs tabular-nums font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded">
                    Jemi: {bademSums.totalPremium} kg
                  </span>
                  <button
                    type="button"
                    onClick={handleAddBademPremiumRow}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold transition cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Satyr Goş</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto border border-amber-300 rounded-xl shadow-xs bg-white">
                <table className="w-full text-xs text-left">
                  <thead className="bg-amber-50 text-slate-900 text-[10px]">
                    <tr>
                      <th className="py-2 px-2 text-center w-8">№</th>
                      <th className="py-2 px-3">Çykyş Ýeri</th>
                      <th className="py-2 px-3">Giriş Ýeri</th>
                      <th className="py-2 px-3">Badamyň Sorty</th>
                      <th className="py-2 px-3">Meýdany / Kalibr</th>
                      <th className="py-2 px-3">Arassalanan Görnüşi</th>
                      <th className="py-2 px-3 text-right">Agramy (kg)</th>
                      <th className="py-2 px-3">Halta / Gap</th>
                      <th className="py-2 px-2 text-center w-10">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-100">
                    {bademPassport.premiumItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-amber-50/40 transition">
                        <td className="py-2 px-2 text-center tabular-nums font-bold text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.cykysYeri}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'cykysYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.girisYeri}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'girisYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.badamSorty}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'badamSorty', e.target.value)}
                            className="w-24 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.meydany}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'meydany', e.target.value)}
                            placeholder="21/22 Premium"
                            className="w-28 text-xs font-bold bg-white border border-amber-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.arassalananGornusi || ''}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'arassalananGornusi', e.target.value)}
                            placeholder="Elde / Garyşyk maňyz / Şänik..."
                            className="w-36 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="number"
                            step="0.1"
                            value={item.agramyKg}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'agramyKg', Number(e.target.value))}
                            className="w-24 text-right tabular-nums font-bold text-amber-950 bg-amber-50 border border-amber-300 rounded px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.haltaSany}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'haltaSany', e.target.value)}
                            placeholder="Big Bag 1 sany"
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteBademPremiumRow(idx)}
                            className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* TABLISA 2: Sortlama & Gaplama (Classic, Mix, Döwük, Pak we heňli) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-white font-bold text-xs flex items-center justify-center">
                    2
                  </span>
                  <span className="text-xs font-bold text-slate-900 ">
                    Tablisa 2: Sortlama & Gaplama (Classic, Mix, Döwük, Pak we heňli)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs tabular-nums font-bold text-slate-800 bg-slate-200 border border-slate-300 px-2.5 py-0.5 rounded">
                    Jemi: {bademSums.totalSortlama} kg
                  </span>
                  <button
                    type="button"
                    onClick={handleAddBademSortlamaRow}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Satyr Goş</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-xs bg-white">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-800 text-white text-[10px]">
                    <tr>
                      <th className="py-2 px-2 text-center w-8">№</th>
                      <th className="py-2 px-3">Çykyş Ýeri</th>
                      <th className="py-2 px-3">Giriş Ýeri</th>
                      <th className="py-2 px-3">Badamyň Sorty</th>
                      <th className="py-2 px-3">Meýdany / Sınıf</th>
                      <th className="py-2 px-3">Sortlama Gaplama</th>
                      <th className="py-2 px-3 text-right">Agramy (kg)</th>
                      <th className="py-2 px-3">Halta / Gap</th>
                      <th className="py-2 px-2 text-center w-10">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {bademPassport.sortlamaItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-slate-50 transition">
                        <td className="py-2 px-2 text-center tabular-nums font-bold text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.cykysYeri}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'cykysYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.girisYeri}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'girisYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.badamSorty}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'badamSorty', e.target.value)}
                            className="w-24 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.meydany}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'meydany', e.target.value)}
                            placeholder="33-35 Classic / Mix"
                            className="w-28 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <select
                            value={item.sortlamaGaplama || ''}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'sortlamaGaplama', e.target.value)}
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1 font-bold"
                          >
                            <option value="I sort">I sort</option>
                            <option value="II sort">II sort</option>
                            <option value="III sort">III sort</option>
                            <option value="Pak we heňli">Pak we heňli</option>
                          </select>
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="number"
                            step="0.1"
                            value={item.agramyKg}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'agramyKg', Number(e.target.value))}
                            className="w-24 text-right tabular-nums font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.haltaSany}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'haltaSany', e.target.value)}
                            placeholder="Halta 1 sany"
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteBademSortlamaRow(idx)}
                            className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Grand Totals Bar */}
            <div className="bg-white p-4 rounded-xl border border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-6 flex-wrap">
                <div>
                  <span className="text-[10px] font-bold text-slate-600 block">Tablisa 1 (Esasy Maňyz):</span>
                  <span className="tabular-nums font-bold text-sm text-amber-950">{bademSums.totalPremium} kg</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-600 block">Tablisa 2 (Sortlama/Gaplama):</span>
                  <span className="tabular-nums font-bold text-sm text-slate-900">{bademSums.totalSortlama} kg</span>
                </div>
                <div className="border-l-2 border-amber-400 pl-4">
                  <span className="text-[10px] font-bold text-amber-900 block">Jemı resmi net agram:</span>
                  <span className="tabular-nums font-bold text-lg text-amber-950">{bademSums.totalKg} kg</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleTransferBademToSplitLots}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold shadow-sm transition active:scale-95 cursor-pointer"
              >
                <Split className="w-4 h-4" />
                <span>Depderçeden Parçalı Yüke (Split Lots) Aktar</span>
              </button>
            </div>

            {/* 3 Signatures */}
            <div className="pt-3 border-t border-amber-300">
              <span className="text-xs font-bold text-slate-800 block mb-2 ">
                Resmi 3 Yetkili İmza Koçanı (Badam Zawod - Sowuk Depo - Hil)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    1. Çykyş Eden (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.cykysEden}
                    onChange={(e) => setBademPassport(p => ({ ...p, cykysEden: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Badam zawod (Amanow B.)"
                  />
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    2. Giriş Eden (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.girisEden}
                    onChange={(e) => setBademPassport(p => ({ ...p, girisEden: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Sowuk depo (Myradow G.)"
                  />
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    3. Tassyklan (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.tassyklan}
                    onChange={(e) => setBademPassport(p => ({ ...p, tassyklan: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Hil hünärmen (Kadyrow D.)"
                  />
                </div>
              </div>
            </div>

          </div>
        ) : (
        /* 2. DELILNAMA / RESMİ KALİTE PASAPORTU (Baskılı Koçan Standardı) */
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-300/80">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-700 text-white shadow-xs">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 ">
                  <span>Delılnama / resmi kalite pasaportu</span>
                  <span className="text-[10px] font-sans font-bold bg-emerald-200 text-emerald-950 border border-emerald-400 px-2 py-0.5 rounded-md">
                    Baskılı Koçan Standardı
                  </span>
                </h3>
                <p className="text-xs text-slate-600">
                  Resmi hasat ve kalite sınıfları dağılım tablosu, net kilo hesabı ve 3 yetkili imza koçanı
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowPrintModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Resmi Koçan Yazdır</span>
              </button>
            </div>
          </div>

          {/* Delilnama Header Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-emerald-200 text-xs">
            <div>
              <span className="text-slate-500 font-bold block mb-1">Delilnama № (Koçan No):</span>
              <span className="tabular-nums font-bold text-emerald-900 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 block">
                {delilnamaPassport.delilnamaNo}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Sene (Tarih):</span>
              <span className="tabular-nums font-bold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 block">
                {delilnamaPassport.sene}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Ýeri (Sera / Bahçe Lokasyonu):</span>
              <span className="font-bold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 block truncate">
                {delilnamaPassport.yeri}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Miwe & Görnüşi:</span>
              <span className="font-bold text-emerald-950 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 block truncate">
                {delilnamaPassport.miwe} ({delilnamaPassport.miweGornusi})
              </span>
            </div>
          </div>

          {/* Delilnama Grades Distribution Table */}
          <div className="overflow-x-auto border border-emerald-300/80 rounded-xl shadow-xs bg-white">
            <table className="w-full text-xs text-left">
              <thead className="bg-emerald-50 text-slate-900 text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Kalite Sınıfı (Hil Derejesi)</th>
                  <th className="py-2.5 px-3 text-right">Ýaşşikli Ýygylan (kg)</th>
                  <th className="py-2.5 px-3 text-right">Hasyl Net (kg)</th>
                  <th className="py-2.5 px-3 text-right">Satyşa Berlen (kg)</th>
                  <th className="py-2.5 px-3 text-right">Gap Sany (san)</th>
                  <th className="py-2.5 px-3 text-center">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {delilnamaPassport.grades.map((g, idx) => {
                  return (
                    <tr key={idx} className="hover:bg-emerald-50/40 transition">
                      <td className="py-2 px-3">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span className="tabular-nums font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[11px]">
                            {g.gradeKey}
                          </span>
                          {g.gradeLabelTr && (
                            <span className="text-slate-500 text-[10px]">({g.gradeLabelTr})</span>
                          )}
                        </div>
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.yassikliKg ?? 0}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'yassikliKg', e.target.value)}
                          className="w-24 text-right tabular-nums font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.hasylNetKg}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'hasylNetKg', e.target.value)}
                          className="w-24 text-right tabular-nums font-bold text-emerald-900 bg-emerald-50 border border-emerald-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.satysaBerlenKg ?? g.hasylNetKg}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'satysaBerlenKg', e.target.value)}
                          className="w-24 text-right tabular-nums font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          value={g.gapSany ?? 0}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'gapSany', e.target.value)}
                          className="w-20 text-right tabular-nums font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteDelilnamaRow(idx)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          title="Sınıfı Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {/* Delilnama JEMI (Total) Row */}
                <tr className="bg-emerald-100/70 font-bold text-slate-900 border-t-2 border-emerald-400">
                  <td className="py-2.5 px-3 text-emerald-950 ">
                    Jemı (toplam resmi hasat)
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-slate-800">
                    {delilnamaSums.totalYassikli} kg
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-emerald-900 text-sm">
                    {delilnamaSums.totalNet} kg
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-slate-900">
                    {delilnamaSums.totalSatysa} kg
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-slate-900">
                    {delilnamaSums.totalGap} gap
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="text-[10px] bg-emerald-700 text-white px-1.5 py-0.5 rounded tabular-nums">
                      100%
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Add New Class to Delilnama Row & Action */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-slate-700">+ Täze Klas Goş:</span>
              <select
                value={newGradeKey}
                onChange={(e) => setNewGradeKey(e.target.value)}
                className="text-xs font-bold bg-white border border-emerald-300 rounded-lg px-2.5 py-1.5 text-slate-800"
              >
                {STANDARD_QUALITY_CLASSES.map(c => (
                  <option key={c.key} value={c.key}>
                    {c.key} — {c.nameTr}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={handleAddDelilnamaRow}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Listeye Ekle</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleTransferDelilnamaToFormAndSplit}
              className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm transition hover:opacity-95 cursor-pointer"
            >
              <Scale className="w-4 h-4" />
              <span>Delilnama Netini Form Tonajına & Parçalı Yüke Aktar ({delilnamaSums.totalNet} kg)</span>
            </button>
          </div>

          {/* 3 Yetkili İmza Bölümü */}
          <div className="pt-3 border-t border-emerald-200">
            <span className="text-xs font-bold text-slate-800 block mb-2 ">
              Resmi 3 Yetkili İmza Koçanı (Baskı Onayı)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 block">
                  1. Öndüriji (Üretici / Çavuş)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.onduriji || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, onduriji: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Orazow R. (Çavuş)"
                />
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 block">
                  2. Hilçi Hünärmen (Kalite Uzmanı)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.hilciHunarmen || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, hilciHunarmen: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Saparow M. (Kalite Uzmanı)"
                />
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 block">
                  3. Satuw Hünärmen (Satış Uzmanı)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.satuwHunarmen || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, satuwHunarmen: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Mämmetgulyýew M."
                />
              </div>
            </div>
          </div>

        </div>
        )}

        {/* 3. PARÇALI YÜK & KALİTE SORTLARI DAĞITIMI (SPLIT LOGISTICS) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-blue-200/60">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-700 text-white shadow-xs">
                <Split className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 ">
                  <span>Parçalı Yük & Kalite Sortları Dağıtımı (Split Logistics)</span>
                  <span className="text-[10px] font-sans font-bold bg-blue-100 text-blue-900 border border-blue-300 px-2 py-0.5 rounded-full">
                    Otomatik Kilo Ayrıştırma
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  {fruitCategory === 'MUZ'
                    ? 'Muz için 6 standart kalite sınıfı şablonu (Extra, I-Exc, II-Prm, III-Cls, Mix, Sanayi)'
                    : 'Meyve çeşitleri için 6 standart sınıf dağılımı ve otomatik alt-parti kodlaması'}
                </p>
              </div>
            </div>

            {/* Quick Template Distribution Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleApplySixClassesPreset}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{fruitCategory === 'MUZ' ? '🍌 6 Standart Muz Sınıfına Dağıt' : '🍎 6 Standart Sınıfa Dağıt'}</span>
              </button>

              <button
                type="button"
                onClick={handleApplyFreshVsFreezeDryPreset}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-700 hover:bg-cyan-800 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Snowflake className="w-3.5 h-3.5" />
                <span>Taze (%85) vs Freeze-Dry (%15)</span>
              </button>

              <button
                type="button"
                onClick={handleDistributeEvenly}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <span>Eşit Böl (1/N)</span>
              </button>
            </div>
          </div>

          {/* Allocation & Remaining Balance Stats (NaNsız Tekilleştirilmiş Stok Hesabı) */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-white p-3 rounded-xl border border-blue-200 text-xs">
            <div>
              <span className="text-slate-500 font-bold block">Toplam Sevkiyat Tonajı:</span>
              <span className="text-sm font-bold tabular-nums text-slate-900">{safeTotalKg} kg</span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block">Ayrıştırılan Kilo:</span>
              <span className="text-sm font-bold tabular-nums text-blue-800">{allocatedSplitKg} kg</span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block">Kalan Dağıtılmamış Kilo:</span>
              <span className={`text-sm font-bold tabular-nums ${remainingSplitKg > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                {remainingSplitKg} kg
              </span>
            </div>
            <div className="flex items-center justify-end gap-1">
              {remainingSplitKg > 0 && splitLots.length > 0 && (
                <button
                  type="button"
                  onClick={handleAssignRemainingToLast}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition cursor-pointer"
                >
                  Kalanı Son Sınıfa Aktar
                </button>
              )}
              {isOverAllocated && (
                <button
                  type="button"
                  onClick={handleSyncFormWeightFromSplit}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 border border-rose-300 transition cursor-pointer"
                >
                  Tonajı Eşitle
                </button>
              )}
            </div>
          </div>

          {/* Over-allocation warning */}
          {isOverAllocated && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Aşırı Dağıtım:</strong> Ayrıştırılan kilo ({allocatedSplitKg} kg), toplam tonajdan ({safeTotalKg} kg) fazladır.
                </span>
              </div>
              <button
                type="button"
                onClick={handleSyncFormWeightFromSplit}
                className="px-3 py-1 bg-rose-600 text-white rounded-lg font-bold text-xs hover:bg-rose-700 cursor-pointer"
              >
                Toplamı {allocatedSplitKg} kg Yap
              </button>
            </div>
          )}

          {/* Split Lots Table */}
          {splitLots.length === 0 ? (
            <div className="p-6 text-center bg-white rounded-xl border border-dashed border-slate-300 text-slate-500 space-y-2">
              <p className="text-xs font-semibold">
                Henüz parçalı kalite ayrıştırması yapılmadı.
              </p>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleApplySixClassesPreset}
                  className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  {fruitCategory === 'MUZ' ? '🍌 6 Standart Muz Sınıfı Şablonunu Yükle' : '🍎 6 Standart Sınıf Şablonunu Yükle'}
                </button>
                <button
                  type="button"
                  onClick={handleAddSplitRow}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-300 transition cursor-pointer"
                >
                  + Manuel Sınıf Satırı Ekle
                </button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto border border-blue-200 rounded-xl shadow-xs bg-white">
              <table className="w-full text-xs text-left">
                <thead className="bg-white text-slate-900 text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Alt-Parti No (Sub-Lot)</th>
                    <th className="py-2.5 px-3">Kalite Sınıfı (Klas)</th>
                    <th className="py-2.5 px-3">Çeşit / Sort</th>
                    <th className="py-2.5 px-3 text-right">Ağırlık (kg)</th>
                    <th className="py-2.5 px-3 text-right">Kasa Sany</th>
                    <th className="py-2.5 px-3">Hedef Tesis / Lokasyon</th>
                    <th className="py-2.5 px-3 text-center">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {splitLots.map((lot, idx) => (
                    <tr key={idx} className="hover:bg-blue-50/30 transition">
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.subLotId}
                          onChange={(e) => handleUpdateSplitRow(idx, 'subLotId', e.target.value)}
                          className="w-24 tabular-nums font-bold text-xs bg-slate-50 border border-slate-300 rounded px-2 py-1"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <select
                          value={lot.qualityGrade || ''}
                          onChange={(e) => handleUpdateSplitRow(idx, 'qualityGrade', e.target.value)}
                          className="font-bold text-xs bg-white border border-slate-300 rounded px-2 py-1"
                        >
                          {STANDARD_QUALITY_CLASSES.map(c => (
                            <option key={c.key} value={c.key}>{c.key}</option>
                          ))}
                        </select>
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.variety || ''}
                          onChange={(e) => handleUpdateSplitRow(idx, 'variety', e.target.value)}
                          className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          placeholder="Sort"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={lot.quantityKg}
                          onChange={(e) => handleUpdateSplitRow(idx, 'quantityKg', e.target.value)}
                          className="w-24 text-right tabular-nums font-bold text-blue-900 bg-white border border-blue-300 rounded px-2 py-1 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          value={lot.caseCount ?? 0}
                          onChange={(e) => handleUpdateSplitRow(idx, 'caseCount', Number(e.target.value))}
                          className="w-16 text-right tabular-nums font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.destination}
                          onChange={(e) => handleUpdateSplitRow(idx, 'destination', e.target.value)}
                          className="w-full text-xs bg-white border border-slate-300 rounded px-2 py-1"
                        />
                      </td>

                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteSplitRow(idx)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          title="Satırı Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Add Split Lot Row Button */}
          {splitLots.length > 0 && (
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleAddSplitRow}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 text-xs font-bold transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Yeni Alt-Parti (Sub-Lot) Satırı Ekle</span>
              </button>

              <span className="text-xs text-slate-500">
                Toplam <strong>{splitLots.length}</strong> kalite sortu ve alt-parti tanımlandı.
              </span>
            </div>
          )}

        </div>

        {/* 4. SAHA GALERİ & YÜKLEME KANIT FOTOĞRAFLARI (FIELD & SHIPMENT VERIFICATION) */}
        <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-slate-800 text-white shadow-xs">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 ">
                  <span>Saha Galeri & Sevkiyat Kanıt Fotoğrafları</span>
                  <span className="text-[10px] tabular-nums font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                    {photos.length + relatedBatchPhotos.length} Görsel
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Partiye ait hasat/bahçe fotoğrafları ve araca yükleme, paletleme, termo sensör ve mühür kanıtları
                </p>
              </div>
            </div>

            {onOpenGallery && (
              <button
                type="button"
                onClick={onOpenGallery}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold transition shadow-xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Saha Galerisine Git</span>
              </button>
            )}
          </div>

          {/* Related Batch Photos (from Harvest / Field Quality) */}
          {relatedBatchPhotos.length > 0 && (
            <div className="space-y-2 bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-200/80">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Seçili Referansa ({selectedRefId}) Ait Saha & Hasat Fotoğrafları ({relatedBatchPhotos.length})</span>
                </span>
                <span className="text-[10px] text-emerald-700 tabular-nums">Otomatik İlişkilendirildi</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-1">
                {relatedBatchPhotos.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => setPreviewPhotoUrl(item.url)}
                    className="group relative aspect-square rounded-lg overflow-hidden border border-emerald-300 bg-white shadow-2xs hover:shadow-md transition cursor-pointer"
                  >
                    <img
                      src={item.url}
                      alt={item.label}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition p-1.5 flex flex-col justify-end">
                      <span className="text-[10px] text-white font-bold truncate">{item.label}</span>
                      {item.date && <span className="text-[9px] text-emerald-200 tabular-nums">{item.date}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload New Shipment Verification Photos */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <UploadCloud className="w-4 h-4 text-blue-600" />
                <span>Bu Sevkiyata Özel Kanıt Fotoğrafları (Tır Yükleme, Frigorifik Mühür, Palet Kontrolü)</span>
              </label>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer bg-blue-600 hover:bg-blue-700 text-white disabled:bg-slate-200 disabled:text-slate-500"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{isCompressingPhoto ? 'İşleniyor...' : 'Fotoğraf Çek'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 disabled:bg-slate-100"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Galeriden Seç</span>
                </button>

                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={isCompressingPhoto}
                />

                <input
                  ref={galleryInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={isCompressingPhoto}
                />
              </div>
            </div>

            {/* Uploaded Photos Grid */}
            {photos.length === 0 ? (
              <div className="border border-dashed border-slate-300 rounded-xl p-4 text-center bg-white/60 text-xs text-slate-400">
                Henüz sevkiyat doğrulama fotoğrafı yüklenmedi. Yukarıdaki butona tıklayarak kamera veya galeriden ekleyebilirsiniz.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                {photos.map((url, idx) => (
                  <div
                    key={idx}
                    className="group relative aspect-square rounded-lg overflow-hidden border border-blue-200 bg-white shadow-2xs"
                  >
                    <img
                      src={url}
                      alt={`Sevkiyat Foto #${idx + 1}`}
                      className="w-full h-full object-cover cursor-pointer"
                      onClick={() => setPreviewPhotoUrl(url)}
                    />
                    <div className="absolute top-1 right-1 flex items-center gap-1 opacity-90 group-hover:opacity-100 transition">
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="p-1 rounded-md bg-rose-600/90 text-white hover:bg-rose-700 transition cursor-pointer shadow-xs"
                        title="Fotoğrafı Kaldır"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="absolute bottom-1 left-1 text-[9px] tabular-nums bg-slate-900/80 text-white px-1.5 py-0.5 rounded">
                      #{idx + 1}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Photo Preview Modal (Lightbox) */}
        {previewPhotoUrl && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
            onClick={() => setPreviewPhotoUrl(null)}
          >
            <div className="relative max-w-4xl max-h-[90vh] bg-slate-900 rounded-2xl overflow-hidden border border-slate-700 shadow-2xl p-2" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between pb-2 px-2 text-white text-xs">
                <span className="tabular-nums">Fotoğraf Detayı / Önizleme</span>
                <button
                  type="button"
                  onClick={() => setPreviewPhotoUrl(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <img
                src={previewPhotoUrl}
                alt="Büyük Önizleme"
                className="max-h-[80vh] w-auto mx-auto rounded-lg object-contain"
              />
            </div>
          </div>
        )}

        {/* Status & Notes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat Durumu *
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-800"
            >
              <option value="SHIPPED">SHIPPED (Yola Çıktı / Sevk Edildi)</option>
              <option value="IN_TRANSIT">IN_TRANSIT (Yolda / Transit)</option>
              <option value="DELIVERED">DELIVERED (Varış Noktasına Ulaştı)</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat / Delilnama Notları
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
              placeholder="Soğutma sensörleri, mühür numarası, rota talimatları..."
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition cursor-pointer"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-blue-700 hover:bg-blue-800 text-white shadow-md'} text-xs font-bold transition active:scale-95 cursor-pointer`}
          >
            <Save className="w-4 h-4" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'Delilnamayı Onayla & Sevkiyatı Başlat'}</span>
          </button>
        </div>
        </fieldset>

      </form>

      {/* PRINTABLE DELILNAMA PASSPORT MODAL (Baskılı Koçan Standardı) */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border-4 border-emerald-800 overflow-hidden my-8">
            
            {/* Modal Header */}
            <div className="bg-emerald-50 text-slate-900 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <span className="font-bold text-sm">
                  Türkmenistan agrosenagat resmi hasat delilnama koçanı
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-slate-900 text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Yazdır / PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="p-1 rounded-lg hover:bg-white/20 text-slate-900 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Body */}
            <div className="p-8 space-y-6 text-slate-900 bg-white" id="printable-delilnama-certificate">
              
              {/* Certificate Title Banner */}
              <div className="text-center border-b-2 border-emerald-800 pb-4 space-y-1">
                <p className="text-[11px] text-emerald-900 font-bold">
                  Türkmenistanyň oba hojalyk we daşky gurşawy goramak mınıstrlıgı
                </p>
                <h1 className="text-2xl font-bold text-emerald-950">
                  Hasyl delilnama / hil pasporty
                </h1>
                <p className="text-xs tabular-nums font-bold text-emerald-800">
                  Resmi Baskılı Koçan №: <strong>{delilnamaPassport.delilnamaNo}</strong>
                </p>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl border border-emerald-300 bg-emerald-50/40 text-xs">
                <div>
                  <span className="text-slate-500 font-bold block">Sene (Tarih):</span>
                  <span className="tabular-nums font-bold text-slate-900">{delilnamaPassport.sene}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Ýeri (Lokasyon):</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.yeri}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Miwe (Meyve):</span>
                  <span className="font-bold text-emerald-900">{delilnamaPassport.miwe}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Miwe Görnüşi (Çeşit):</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.miweGornusi}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Agaç Sany:</span>
                  <span className="tabular-nums font-bold text-slate-900">{delilnamaPassport.agacSany} düyp</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Gabyň Görnüşi:</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.gabynGornusi}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Ulag Belkisi (Plaka):</span>
                  <span className="tabular-nums font-bold text-blue-900">{vehiclePlate}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Sürüji (Şoför):</span>
                  <span className="font-bold text-slate-900">{driver}</span>
                </div>
              </div>

              {/* Grades Table */}
              <div className="border border-emerald-800 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-emerald-50 text-slate-900 text-[11px]">
                    <tr>
                      <th className="py-2 px-3 border-r border-emerald-800">T/B</th>
                      <th className="py-2 px-3 border-r border-emerald-800">Hil Derejesi (Kalite Sınıfı)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Ýaşşikli Ýygylan (kg)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Hasyl Net (kg)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Satyşa Berlen (kg)</th>
                      <th className="py-2 px-3 text-right">Gap Sany (san)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-200">
                    {delilnamaPassport.grades.map((g, i) => (
                      <tr key={i} className="odd:bg-white even:bg-emerald-50/30">
                        <td className="py-2 px-3 border-r border-emerald-200 tabular-nums text-center font-bold text-slate-600">
                          {i + 1}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 font-bold text-slate-900">
                          {g.gradeKey} {g.gradeLabelTr ? `(${g.gradeLabelTr})` : ''}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right tabular-nums">
                          {g.yassikliKg ?? 0}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right tabular-nums font-bold text-emerald-950">
                          {g.hasylNetKg}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right tabular-nums">
                          {g.satysaBerlenKg ?? g.hasylNetKg}
                        </td>
                        <td className="py-2 px-3 text-right tabular-nums font-bold">
                          {g.gapSany ?? 0}
                        </td>
                      </tr>
                    ))}
                    {/* JEMI */}
                    <tr className="bg-emerald-100 font-bold text-emerald-950 border-t-2 border-emerald-800">
                      <td colSpan={2} className="py-2 px-3 border-r border-emerald-800 ">
                        Jemı (jemi hasat net):
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right tabular-nums">
                        {delilnamaSums.totalYassikli} kg
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right tabular-nums text-sm font-bold">
                        {delilnamaSums.totalNet} kg
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right tabular-nums">
                        {delilnamaSums.totalSatysa} kg
                      </td>
                      <td className="py-2 px-3 text-right tabular-nums">
                        {delilnamaSums.totalGap} gap
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Signatures Section */}
              <div className="pt-6 border-t-2 border-emerald-800 grid grid-cols-3 gap-6 text-xs text-center">
                <div className="space-y-3">
                  <span className="font-bold text-slate-800 block">
                    Öndüriji (üretici)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="tabular-nums font-bold text-emerald-950">{delilnamaPassport.onduriji || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Möhür</span>
                </div>

                <div className="space-y-3">
                  <span className="font-bold text-slate-800 block">
                    Hilçi hünärmen (kalite)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="tabular-nums font-bold text-emerald-950">{delilnamaPassport.hilciHunarmen || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Hil Barlag Möhür</span>
                </div>

                <div className="space-y-3">
                  <span className="font-bold text-slate-800 block">
                    Satuw hünärmen (satış)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="tabular-nums font-bold text-emerald-950">{delilnamaPassport.satuwHunarmen || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Kabul Möhür</span>
                </div>
              </div>

              {/* Official Seal Mockup */}
              <div className="text-center pt-2 text-[10px] text-slate-400 tabular-nums">
                Agrosenagat Hil Gözegçiligi Standardy • ISO 22000 & HACCP Protokoly • Şahadatnama № 0002952
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowPrintModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition cursor-pointer"
              >
                Kapat
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DATALOGGER EKLE / DÜZENLE MODALI */}
      {showLoggerModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="bg-white text-slate-900 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-indigo-700" />
                <h3 className="font-bold text-sm">
                  {editingLoggerId ? 'Datalogger Cihazını Düzenle' : 'Yeni Datalogger Cihazı Ekle'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowLoggerModal(false)}
                className="p-1 rounded-lg hover:bg-white/20 text-slate-900 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-3 gap-2">
              <button
                type="button"
                onClick={() => setLoggerModalTab('CSV')}
                className={`px-4 py-2 text-xs font-bold rounded-t-xl transition cursor-pointer border-t border-x ${
                  loggerModalTab === 'CSV'
                    ? 'bg-white text-indigo-700 border-slate-200 border-b-transparent -mb-px'
                    : 'text-slate-600 hover:text-slate-900 border-transparent'
                }`}
              >
                CSV / TSV Yükle (.csv, .txt, .tsv)
              </button>
              <button
                type="button"
                onClick={() => setLoggerModalTab('MANUEL')}
                className={`px-4 py-2 text-xs font-bold rounded-t-xl transition cursor-pointer border-t border-x ${
                  loggerModalTab === 'MANUEL'
                    ? 'bg-white text-indigo-700 border-slate-200 border-b-transparent -mb-px'
                    : 'text-slate-600 hover:text-slate-900 border-transparent'
                }`}
              >
                Elle Gir (MANUEL)
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              {/* Ortak Cihaz Bilgileri */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Cihaz Kimliği / Seri No (Device ID) *</label>
                  <input
                    type="text"
                    value={logDeviceId}
                    onChange={(e) => setLogDeviceId(e.target.value.toUpperCase())}
                    placeholder="Örn: ZYG-6519 veya TZ2606002230"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Cihaz Markası / Modeli</label>
                  <input
                    type="text"
                    value={logBrand}
                    onChange={(e) => setLogBrand(e.target.value)}
                    placeholder="Örn: Copeland, TZONE, TempSen"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Konteyner İçi Yerleşim (Placement)</label>
                  <select
                    value={logPlacement}
                    onChange={(e) => setLogPlacement(e.target.value as any)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-800"
                  >
                    <option value="PALET_ICI">PALET_ICI (Palet / Koli İçi)</option>
                    <option value="HAVA_CIKISI">HAVA_CIKISI (Soğuk Hava Çıkışı / Üfleme)</option>
                    <option value="HAVA_DONUSU">HAVA_DONUSU (Hava Dönüşü / Emiş)</option>
                    <option value="KAPI_TARAFI">KAPI_TARAFI (Arka Kapı Tarafı)</option>
                    <option value="DIGER">DIGER (Diğer Nokta)</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Kaynak Saat Dilimi (Source Timezone)</label>
                  <select
                    value={logSourceTz}
                    onChange={(e) => setLogSourceTz(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-800"
                  >
                    <option value="UTC">UTC (Evrensel Zaman - GMT+0)</option>
                    <option value="UTC+3">UTC+3 (Türkiye / Moskova)</option>
                    <option value="UTC+5">UTC+5 (Türkmenistan)</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Üst Sıcaklık Eşiği (°C) (Upper Limit)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={logUpperLimit}
                    onChange={(e) => setLogUpperLimit(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="Tanımsız (productSpecs)"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-900"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Alt Sıcaklık Eşiği (°C) (Lower Limit)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={logLowerLimit}
                    onChange={(e) => setLogLowerLimit(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="Tanımsız (productSpecs)"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-900"
                  />
                </div>
              </div>

              {/* Sekme 1: CSV İçe Aktarma */}
              {loggerModalTab === 'CSV' && (
                <div className="space-y-3 pt-3 border-t border-slate-200">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Tarih Biçimi (Date Format)</label>
                      <select
                        value={logDateFormat}
                        onChange={(e) => setLogDateFormat(e.target.value as any)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 tabular-nums text-slate-800"
                      >
                        <option value="AUTO">AUTO (Otomatik Tespit)</option>
                        <option value="MDY">MDY (Ay/Gün/Yıl - Örn: 10/23/26)</option>
                        <option value="YMD">YMD (Yıl/Ay/Gün - Örn: 2026/10/22)</option>
                        <option value="DMY">DMY (Gün/Ay/Yıl - Örn: 23/10/2026)</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">CSV / TSV / TXT Dosyası Seç</label>
                      <input
                        type="file"
                        accept=".csv,.txt,.tsv"
                        onChange={handleCsvFileUpload}
                        className="w-full text-xs text-slate-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* CSV Önizleme */}
                  {csvPreview && (
                    <div className="space-y-1.5">
                      <div className="text-[11px] font-bold text-slate-700 flex items-center justify-between">
                        <span>İlk 5 Satır Önizleme (Sütunlar: {csvPreview.headers.join(' | ')})</span>
                        <span className="tabular-nums text-indigo-600">{csvFileName}</span>
                      </div>
                      <div className="overflow-x-auto border border-slate-200 rounded-lg bg-slate-50 p-2 tabular-nums text-[10px]">
                        <table className="w-full text-left">
                          <tbody>
                            {csvPreview.rows.slice(0, 5).map((row, rIdx) => (
                              <tr key={rIdx} className="border-b border-slate-200/50 last:border-0">
                                {row.map((cell, cIdx) => (
                                  <td key={cIdx} className="p-1 whitespace-nowrap text-slate-700">
                                    {cell}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-relaxed">
                    <strong>Not:</strong> Excel (.xlsx) dosyasını doğrudan yüklemek yerine Excel'den <strong>"Farklı Kaydet → CSV (Virgülle ayrılmış)"</strong> olarak kaydedip yükleyin.
                  </div>
                </div>
              )}

              {/* Sekme 2: Manuel Değer Girişi */}
              {loggerModalTab === 'MANUEL' && (
                <div className="space-y-3 pt-3 border-t border-slate-200">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Min Sıcaklık (°C)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={manualMinC}
                        onChange={(e) => setManualMinC(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Maks Sıcaklık (°C)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={manualMaxC}
                        onChange={(e) => setManualMaxC(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Ortalama (°C)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={manualAvgC}
                        onChange={(e) => setManualAvgC(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">MKT Kinetik (°C)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={manualMktC}
                        onChange={(e) => setManualMktC(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Kayıt Başlangıç</label>
                      <input
                        type="text"
                        value={manualStartAt}
                        onChange={(e) => setManualStartAt(e.target.value)}
                        placeholder="YYYY-MM-DDTHH:mm:ssZ"
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums text-[10px]"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Kayıt Bitiş</label>
                      <input
                        type="text"
                        value={manualStopAt}
                        onChange={(e) => setManualStopAt(e.target.value)}
                        placeholder="YYYY-MM-DDTHH:mm:ssZ"
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums text-[10px]"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Eşik Üstü (dk)</label>
                      <input
                        type="number"
                        value={manualMinutesAbove}
                        onChange={(e) => setManualMinutesAbove(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">İhlal Sayısı</label>
                      <input
                        type="number"
                        value={manualViolations}
                        onChange={(e) => setManualViolations(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 tabular-nums"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLoggerModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleSaveLogger}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition cursor-pointer shadow-xs"
              >
                {loggerModalTab === 'CSV' ? 'Ayrıştır & Logger Kaydet' : 'Manuel Logger Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
