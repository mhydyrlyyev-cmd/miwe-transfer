/** v2.8 — %5 inspeksiyon sınıfları (tüm ürünlerde aynı). Sıra = raporlardaki sıra. */
export const INSPECTION_CLASSES = ['Extra', 'Exclusive', 'Premium', 'Classic', 'Mix', 'Standart dışı'] as const;

/** Sınıf kg'larından yüzde (3 ondalık). Toplam 0 ise null. */
export function inspectionPercents(rows: { cls: string; kg?: number }[]): { cls: string; kg: number; pct: number | null }[] {
  const total = rows.reduce((s, r) => s + (r.kg && r.kg > 0 ? r.kg : 0), 0);
  return rows.map(r => ({ cls: r.cls, kg: r.kg && r.kg > 0 ? r.kg : 0, pct: total > 0 ? Number((((r.kg && r.kg > 0 ? r.kg : 0) / total) * 100).toFixed(3)) : null }));
}

/** v3.0 — Görünüş (kalite sınıfı) seçenekleri: inspeksiyon sınıfları + sınıflanmamış. Tüm bahçeler ve ürünler için ortak. */
export const UNCLASSIFIED = 'Sınıflanmamış';
export const APPEARANCE_OPTIONS: string[] = [...INSPECTION_CLASSES, UNCLASSIFIED];

/** v3.0 — Soğuk depodaki mevcut durum */
export const STORAGE_STATUS_LABEL: Record<'PRECOOLING' | 'SHOCK' | 'WAITING' | 'READY', string> = {
  PRECOOLING: 'Ön soğutmada',
  SHOCK: 'Şoklamada',
  WAITING: 'Depoda bekliyor',
  READY: 'Sevke hazır'
};

/**
 * v47b — MIWE sınıflarının rolü (kabul kartı).
 * Extra / Exclusive / Premium: ihracat uyumlu (UNECE Ekstra / I. sınıf şartını karşılamalı).
 * Classic / Mix: iç pazar, tonaja girer (UNECE II. sınıf şartı yeterli).
 * Standart dışı: tonaja girmez, göstergede ayrı gösterilir.
 * Eşleşme MIWE iç kararıdır ("İç hedef"); toleranslar ürünün UNECE broşüründen gelir.
 */
export type ClassRole = 'EXPORT' | 'TONNAGE' | 'OUT';
export const CLASS_ROLE: Record<(typeof INSPECTION_CLASSES)[number], { role: ClassRole; unece: string }> = {
  'Extra': { role: 'EXPORT', unece: 'UNECE Ekstra' },
  'Exclusive': { role: 'EXPORT', unece: 'UNECE Ekstra / I' },
  'Premium': { role: 'EXPORT', unece: 'UNECE I. sınıf' },
  'Classic': { role: 'TONNAGE', unece: 'UNECE II. sınıf' },
  'Mix': { role: 'TONNAGE', unece: 'UNECE II. sınıf (karışık boy)' },
  'Standart dışı': { role: 'OUT', unece: 'Asgari şart karşılanmıyor' },
};
export const CLASS_ROLE_LABEL: Record<ClassRole, string> = { EXPORT: 'İhracat', TONNAGE: 'Tonaja girer', OUT: 'Tonaja girmez' };
/** UNECE FFV genel kalite toleransı (ürün broşüründe farklıysa o geçerli). */
export const UNECE_GENERAL_TOLERANCE = 'Kalite toleransı (UNECE genel): Ekstra %5, I. sınıf %10, II. sınıf %10 — ürün broşüründe farklı değer varsa o geçerli.';
