import React, { useMemo, useState } from 'react';
import { Printer, ChevronDown, AlertTriangle, Download } from 'lucide-react';
import { computePeriodReport, computeOrchardRows, computeColdStatus, toCsv, periodRange, baseProduct, type PeriodKey, type Item, type ReportInput } from '../../utils/periodReport';
import { INSPECTION_CLASSES } from '../../config/inspection';
import { Badge, Button, Card, PageHeader, Tabs } from '../ui';

/**
 * v2.9 — Haftalık / aylık durum: hareketler, depo durumu, kalite, eksik kayıtlar.
 * Her sayının altında onu oluşturan kayıtlar açılabilir; RefID'ye dokununca parti zinciri açılır.
 * Fiyat / gelir bu raporda yoktur.
 */
interface Props extends ReportInput {
  onOpenRef: (refId: string) => void;
  onBack: () => void;
}

const fmtKg = (v?: number | null) => (v == null ? '—' : `${Math.round(v).toLocaleString('tr-TR')} kg`);
const fmtNum = (v?: number | null, d = 1) => (v == null ? '—' : v.toLocaleString('tr-TR', { maximumFractionDigits: d }));
const delta = (cur: number, prev: number) => {
  if (!prev && !cur) return null;
  if (!prev) return 'önceki dönemde yok';
  const p = ((cur - prev) / prev) * 100;
  return `önceki: ${Math.round(prev).toLocaleString('tr-TR')} (${p >= 0 ? '+' : ''}${p.toFixed(0)}%)`;
};

function ItemList({ items, onOpenRef }: { items: Item[]; onOpenRef: (id: string) => void }) {
  if (!items.length) return <p className="text-xs text-slate-500">Kayıt yok.</p>;
  return (
    <ul className="divide-y divide-slate-100 dark:divide-slate-800">
      {items.slice(0, 50).map((it, k) => (
        <li key={k} className="py-1.5 flex items-center justify-between gap-2 text-xs">
          <button type="button" onClick={() => onOpenRef(it.refId)} className="font-mono font-semibold text-teal-800 dark:text-teal-300 underline-offset-2 hover:underline min-h-[32px] text-left">{it.refId}</button>
          <span className="text-slate-600 dark:text-slate-400 text-right">{it.date}{it.kg != null ? ` · ${fmtKg(it.kg)}` : ''}{it.note ? ` · ${it.note}` : ''}</span>
        </li>
      ))}
      {items.length > 50 && <li className="py-1.5 text-xs text-slate-500">+{items.length - 50} kayıt daha</li>}
    </ul>
  );
}

function Stat({ label, value, sub, items, onOpenRef }: { label: string; value: string; sub?: string | null; items: Item[]; onOpenRef: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-3">
      <div className="text-xs text-slate-600 dark:text-slate-400">{label}</div>
      <div className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open}
        className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-teal-800 dark:text-teal-300 min-h-[32px] print:hidden">
        {items.length} kayıt <ChevronDown className={`w-3 h-3 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="mt-1"><ItemList items={items} onOpenRef={onOpenRef} /></div>}
    </div>
  );
}

export default function PeriodStatusView({ onOpenRef, onBack, ...input }: Props) {
  const [period, setPeriod] = useState<PeriodKey>('THIS_WEEK');
  const [product, setProduct] = useState('ALL');
  const ranges = useMemo(() => periodRange(period), [period]);
  const products = useMemo(() => {
    const s = new Set<string>();
    input.references.forEach(r => { const b = baseProduct(r.product); if (b) s.add(b); });
    input.fieldRecords.forEach(f => { const b = baseProduct(f.product); if (b) s.add(b); });
    return [...s].sort((a, b) => a.localeCompare(b, 'tr'));
  }, [input.references, input.fieldRecords]);
  const cur = useMemo(() => computePeriodReport(input, ranges.current, product), [input, ranges, product]);
  const prev = useMemo(() => computePeriodReport(input, ranges.previous, product), [input, ranges, product]);
  // v3.0: bahçe bazında satırlar (dönem) ve soğuk depo durumu (şu an)
  const orchards = useMemo(() => computeOrchardRows(input, ranges.current, product), [input, ranges, product]);
  const cold = useMemo(() => computeColdStatus(input, product), [input, product]);
  const [openOrchard, setOpenOrchard] = useState<string | null>(null);
  const [openCold, setOpenCold] = useState<number | null>(null);
  const hasBanana = orchards.some(o => o.ribbons.length > 0) || cold.some(c => c.banana);
  const pct = (v: number | null) => (v == null ? '—' : v.toLocaleString('tr-TR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }));

  const exportExcel = () => {
    const rows: (string | number | null)[][] = [];
    rows.push([`Miwe Hil — Haftalık / Aylık Durum`, ranges.current.label, product === 'ALL' ? 'Tüm ürünler' : product]);
    rows.push([]);
    rows.push(['HAREKETLER', 'kg', 'açıklama']);
    rows.push(['Hasat', Math.round(cur.harvest.kg), `${cur.harvest.days} gün · ${cur.harvest.workers} kişi-gün · ${cur.harvest.unweighedDays} gün tartılmadı`]);
    rows.push(['Şoklanan', Math.round(cur.precooling.netKg), `${cur.precooling.slips} fiş`]);
    rows.push(['Depoya giriş', Math.round(cur.depotIn.kg), `dış alım ${Math.round(cur.depotIn.externalKg)} kg`]);
    rows.push(['Çıkış (sevk + satış)', Math.round(cur.out.kg), `sevk ${Math.round(cur.out.shipKg)} · satış ${Math.round(cur.out.saleKg)}`]);
    rows.push(['Fire hasat → şoklama %', cur.fire ? cur.fire.pct : null, cur.fire ? `${Math.round(cur.fire.lossKg)} kg` : '']);
    rows.push([]);
    rows.push(['BAHÇE BAZINDA', 'Ürün', 'Hasat kg', 'Kişi-gün', 'Şoklanan kg', 'Fire %', ...INSPECTION_CLASSES.map(c => `${c} %`), 'Depoda kg', 'Kurdele', 'Hasat haftası']);
    orchards.forEach(o => rows.push([o.orchard, o.products.join(', '), Math.round(o.harvestKg), o.workers, Math.round(o.shockKg), o.firePct, ...o.quality.map(q => q.pct), Math.round(o.stockKg), o.ribbons.join(', '), o.weeks.join(', ')]));
    rows.push([]);
    rows.push(['SOĞUK DEPO DURUMU (şu an)', 'Bahçe', 'Ürün', 'Görünüş', 'Durum', 'Miktar kg', 'Partiler', 'Muz: sera · kurdele · hafta']);
    cold.forEach(c => rows.push([c.room, c.orchard, c.product, c.appearance, c.status, Math.round(c.kg), c.refIds.join(', '), c.banana || '']));
    const blob = new Blob([toCsv(rows)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `miwe-durum-${ranges.current.start}_${ranges.current.end}${product === 'ALL' ? '' : '-' + product}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader
        onBack={onBack}
        title="Haftalık / Aylık Durum"
        subtitle={ranges.current.label}
        actions={<div className="flex gap-2 print:hidden">
          <Button variant="soft" tone="emerald" size="sm" icon={<Download />} onClick={exportExcel}>Excel'e aktar</Button>
          <Button variant="soft" tone="slate" size="sm" icon={<Printer />} onClick={() => window.print()}>Yazdır</Button>
        </div>}
      />

      <div className="space-y-2 print:hidden">
        <Tabs ariaLabel="Dönem" fullWidth value={period} onChange={(k) => setPeriod(k as PeriodKey)}
          items={[{ key: 'THIS_WEEK', label: 'Bu hafta' }, { key: 'LAST_WEEK', label: 'Geçen hafta' }, { key: 'THIS_MONTH', label: 'Bu ay' }, { key: 'LAST_MONTH', label: 'Geçen ay' }]} />
        <select value={product} onChange={e => setProduct(e.target.value)} aria-label="Ürün"
          className="w-full sm:w-72 min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100">
          <option value="ALL">Tüm ürünler</option>
          {products.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {cur.warnings.length > 0 && (
        <Card title="Eksik kayıtlar" subtitle="Bugün itibarıyla tamamlanması gerekenler" actions={<AlertTriangle className="w-4 h-4 text-amber-600" />}>
          <div className="space-y-3">
            {cur.warnings.map(w => (
              <details key={w.key} className="group">
                <summary className="cursor-pointer text-sm text-slate-800 dark:text-slate-200 min-h-[36px] flex items-center justify-between gap-2">
                  <span>{w.text}</span><Badge tone="warn">{w.items.length}</Badge>
                </summary>
                <div className="mt-1"><ItemList items={w.items} onOpenRef={onOpenRef} /></div>
              </details>
            ))}
          </div>
        </Card>
      )}

      <Card title="Hareketler" subtitle={`${ranges.current.start} – ${ranges.current.end}`}>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5">
          <Stat label="Hasat" value={fmtKg(cur.harvest.kg)}
            sub={`${cur.harvest.days} gün · ${cur.harvest.lots} parti · ${cur.harvest.workers} kişi-gün${cur.harvest.unweighedDays ? ` · ${cur.harvest.unweighedDays} gün tartılmadı` : ''}`}
            items={cur.harvest.items} onOpenRef={onOpenRef} />
          <Stat label="Şoklanan (ön soğutma)" value={fmtKg(cur.precooling.netKg)}
            sub={`${cur.precooling.slips} fiş · %5 inspeksiyon ${cur.precooling.fivePercent} · sorting ${cur.precooling.sorting}${delta(cur.precooling.netKg, prev.precooling.netKg) ? ` · ${delta(cur.precooling.netKg, prev.precooling.netKg)}` : ''}`}
            items={cur.precooling.items} onOpenRef={onOpenRef} />
          <Stat label="Depoya giriş" value={fmtKg(cur.depotIn.kg)}
            sub={`${cur.depotIn.records} kabul${cur.depotIn.externalKg ? ` · dış alım ${fmtKg(cur.depotIn.externalKg)}` : ''}`}
            items={cur.depotIn.items} onOpenRef={onOpenRef} />
          <Stat label="Çıkış (sevk + satış)" value={fmtKg(cur.out.kg)}
            sub={`sevk ${fmtKg(cur.out.shipKg)} · satış ${fmtKg(cur.out.saleKg)}${delta(cur.out.kg, prev.out.kg) ? ` · ${delta(cur.out.kg, prev.out.kg)}` : ''}`}
            items={cur.out.items} onOpenRef={onOpenRef} />
          <Stat label="Fire (hasat → şoklama)" value={cur.fire ? `%${fmtNum(cur.fire.pct, 2)}` : '—'}
            sub={cur.fire ? `${fmtKg(cur.fire.lossKg)} · yalnızca hasatta ayrıca tartılan günler` : 'Hasatta ayrıca tartılmış gün yok'}
            items={cur.fire?.items || []} onOpenRef={onOpenRef} />
        </div>
        <p className="text-[11px] text-slate-500 mt-2">Hasat sayısında "önceki dönem" karşılaştırması: {delta(cur.harvest.kg, prev.harvest.kg) || '—'}</p>
      </Card>

      <Card title="Bahçe bazında" subtitle={product === 'ALL' ? 'Her bahçe ayrı; kalite yüzdeleri o bahçenin %5 inspeksiyonlarından' : `Yalnızca ${product} yetişen bahçeler; yüzdeler yalnızca ${product} için`}>
        {orchards.length ? (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[760px]">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <th className="py-1.5 px-1">Bahçe</th><th className="py-1.5 px-1">Ürün</th><th className="py-1.5 px-1 text-right">Hasat kg</th>
                  <th className="py-1.5 px-1 text-right">Kişi-gün</th><th className="py-1.5 px-1 text-right">Şoklanan kg</th><th className="py-1.5 px-1 text-right">Fire %</th>
                  {INSPECTION_CLASSES.map(c => <th key={c} className="py-1.5 px-1 text-right">{c} %</th>)}
                  <th className="py-1.5 px-1 text-right">Depoda kg</th>
                  {hasBanana && <th className="py-1.5 px-1">Kurdele / hafta</th>}
                </tr>
              </thead>
              <tbody>
                {orchards.map(o => (
                  <React.Fragment key={o.orchard}>
                    <tr className="border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50" onClick={() => setOpenOrchard(v => v === o.orchard ? null : o.orchard)} aria-expanded={openOrchard === o.orchard}>
                      <td className="py-1.5 px-1 font-semibold">{o.orchard}</td>
                      <td className="py-1.5 px-1">{o.products.join(', ')}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.harvestKg ? Math.round(o.harvestKg).toLocaleString('tr-TR') : (o.unweighedDays ? 'tartılmadı' : '—')}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.workers || '—'}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.shockKg ? Math.round(o.shockKg).toLocaleString('tr-TR') : '—'}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{pct(o.firePct)}</td>
                      {o.quality.map(q => <td key={q.cls} className="py-1.5 px-1 text-right tabular-nums">{q.kg ? pct(q.pct) : '—'}</td>)}
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.stockKg ? Math.round(o.stockKg).toLocaleString('tr-TR') : '—'}</td>
                      {hasBanana && <td className="py-1.5 px-1">{[o.ribbons.join(', '), o.weeks.length ? `${o.weeks.join(', ')}. hafta` : ''].filter(Boolean).join(' · ') || '—'}</td>}
                    </tr>
                    {openOrchard === o.orchard && (
                      <tr><td colSpan={8 + INSPECTION_CLASSES.length + (hasBanana ? 1 : 0)} className="py-1.5 px-1">
                        <div className="flex flex-wrap gap-1.5">{o.refIds.map(id => (
                          <button key={id} type="button" onClick={() => onOpenRef(id)} className="font-mono text-[11px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 rounded-full px-2 min-h-[28px]">{id}</button>
                        ))}</div>
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="text-sm text-slate-500">Bu dönemde bahçe kaydı yok.</p>}
        <p className="text-[11px] text-slate-500 mt-2">Kişi-gün: günlük hasat kayıtlarındaki kişi sayılarının toplamı. Satıra dokununca partiler açılır.</p>
      </Card>

      <Card title="Soğuk Depo Durumu" subtitle="Şu an: hangi bahçenin ürünü hangi odada, hangi görünüşte, ne durumda">
        {cold.length ? (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[640px]">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <th className="py-1.5 px-1">Oda</th><th className="py-1.5 px-1">Bahçe</th><th className="py-1.5 px-1">Ürün</th><th className="py-1.5 px-1">Görünüş</th>
                  <th className="py-1.5 px-1">Durum</th><th className="py-1.5 px-1 text-right">Miktar kg</th>{hasBanana && <th className="py-1.5 px-1">Sera / kurdele / hafta</th>}
                </tr>
              </thead>
              <tbody>
                {cold.map((c, k) => (
                  <React.Fragment key={k}>
                    <tr className="border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50" onClick={() => setOpenCold(v => v === k ? null : k)} aria-expanded={openCold === k}>
                      <td className="py-1.5 px-1 font-semibold">{c.room}</td><td className="py-1.5 px-1">{c.orchard}</td><td className="py-1.5 px-1">{c.product}</td>
                      <td className="py-1.5 px-1">{c.appearance}</td>
                      <td className="py-1.5 px-1"><Badge tone={/Sevke hazır/.test(c.status) ? 'ok' : /soğut|Şokla/i.test(c.status) ? 'info' : 'neutral'}>{c.status}</Badge></td>
                      <td className="py-1.5 px-1 text-right tabular-nums font-semibold">{Math.round(c.kg).toLocaleString('tr-TR')}</td>
                      {hasBanana && <td className="py-1.5 px-1">{c.banana || '—'}</td>}
                    </tr>
                    {openCold === k && (
                      <tr><td colSpan={hasBanana ? 7 : 6} className="py-1.5 px-1">
                        <div className="flex flex-wrap gap-1.5">{c.refIds.map(id => (
                          <button key={id} type="button" onClick={() => onOpenRef(id)} className="font-mono text-[11px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 rounded-full px-2 min-h-[28px]">{id}</button>
                        ))}</div>
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
                <tr><td colSpan={5} className="py-1.5 px-1 font-semibold">Toplam</td><td className="py-1.5 px-1 text-right tabular-nums font-bold">{Math.round(cold.reduce((a, c) => a + c.kg, 0)).toLocaleString('tr-TR')}</td>{hasBanana && <td />}</tr>
              </tbody>
            </table>
          </div>
        ) : <p className="text-sm text-slate-500">Şu an depoda veya ön soğutmada parti yok.</p>}
        <p className="text-[11px] text-slate-500 mt-2">Durum, Soğuk Depo ekranından her parti için seçilir. Görünüş, depo kabulde seçilir; aynı parti farklı görünüşte farklı odalara ayrı kabul kaydıyla konabilir.</p>
      </Card>

      <Card title="Depo durumu" subtitle={`${ranges.current.end} sonu itibarıyla depoda kalan`}>
        <div className="text-2xl font-bold tabular-nums">{fmtKg(cur.stock.totalKg)}</div>
        {cur.stock.byProduct.length > 0 ? (
          <div className="grid sm:grid-cols-2 gap-3 mt-3">
            <div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Ürüne göre</p>
              <ul className="text-sm space-y-0.5">{cur.stock.byProduct.map(p => <li key={p.product} className="flex justify-between"><span>{p.product}</span><span className="tabular-nums font-semibold">{fmtKg(p.kg)}</span></li>)}</ul>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Depo / oda</p>
              <ul className="text-sm space-y-0.5">{cur.stock.byRoom.map(r => <li key={r.place} className="flex justify-between gap-2"><span className="truncate">{r.place}</span><span className="tabular-nums font-semibold whitespace-nowrap">{fmtKg(r.kg)} · {r.lots} parti</span></li>)}</ul>
            </div>
          </div>
        ) : <p className="text-sm text-slate-500 mt-1">Depoda kayıtlı parti yok.</p>}
        <details className="mt-2 print:hidden"><summary className="cursor-pointer text-xs font-semibold text-teal-800 dark:text-teal-300 min-h-[32px]">{cur.stock.items.length} parti</summary><ItemList items={cur.stock.items} onOpenRef={onOpenRef} /></details>
      </Card>

      <Card title="Kalite">
        <div className="space-y-4">
          <section>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">%5 inspeksiyon sınıf dağılımı (kg ağırlıklı)</p>
            {cur.inspectionSampleKg > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-xs text-slate-500 border-b border-slate-200 dark:border-slate-700"><th className="py-1 pr-2">Sınıf</th><th className="py-1 pr-2">Numune kg</th><th className="py-1">%</th></tr></thead>
                  <tbody>{cur.inspection.map(r => <tr key={r.cls} className="border-b border-slate-100 dark:border-slate-800"><td className="py-1 pr-2">{r.cls}</td><td className="py-1 pr-2 tabular-nums">{r.kg ? fmtNum(r.kg, 3) : '—'}</td><td className="py-1 tabular-nums">{r.pct != null && r.kg ? r.pct.toLocaleString('tr-TR', { minimumFractionDigits: 3, maximumFractionDigits: 3 }) : '—'}</td></tr>)}</tbody>
                </table>
              </div>
            ) : <p className="text-xs text-slate-500">Bu dönemde %5 inspeksiyon yok.</p>}
          </section>
          <section>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Testler (ürün bazında)</p>
            {cur.tests.length ? (
              <ul className="text-sm space-y-0.5">{cur.tests.map(t => <li key={t.product} className="flex justify-between gap-2"><span>{t.product} · {t.n} test</span><span className="tabular-nums text-slate-700 dark:text-slate-300">Brix {fmtNum(t.avgBrix, 2)} · sertlik {fmtNum(t.avgHardness, 2)}</span></li>)}</ul>
            ) : <p className="text-xs text-slate-500">Bu dönemde test yok.</p>}
          </section>
          <div className="grid grid-cols-2 gap-2.5">
            <Stat label="Depo kontrolleri" value={String(cur.checks.n)} items={cur.checks.items} onOpenRef={onOpenRef} />
            <Stat label="DÖF" value={`${cur.incidents.opened} yeni`} sub={`açık toplam: ${cur.incidents.openNow}`} items={cur.incidents.items} onOpenRef={onOpenRef} />
          </div>
        </div>
      </Card>

      <p className="text-[11px] text-slate-500">
        Hesaplar kayıtlardan yapılır: çıkış = depo girişinden sonraki sevkler + satışlar; depo durumu = giriş − çıkış.
        Fiyat ve gelir bu raporda yer almaz.
      </p>
    </div>
  );
}
