import type { AmbarRecord, FieldRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../types';
import { INSPECTION_CLASSES, STORAGE_STATUS_LABEL, UNCLASSIFIED } from '../config/inspection';

/**
 * v2.9 — Haftalık / aylık durum raporu hesapları (saf fonksiyonlar; ekran yok).
 * Her sayı, onu oluşturan kayıtlarla (items) birlikte döner; ekranda "kayıtları göster" ile kontrol edilebilir.
 */

export type PeriodKey = 'THIS_WEEK' | 'LAST_WEEK' | 'THIS_MONTH' | 'LAST_MONTH';
export interface Range { start: string; end: string; label: string }
export interface Item { refId: string; date: string; kg?: number; note?: string }

const pad = (n: number) => String(n).padStart(2, '0');
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
/** Yerel gün (YYYY-MM-DD). Saf tarih aynen; ISO zaman damgası yerel güne çevrilir. */
export const localDay = (v?: string | null): string => {
  if (!v) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v).slice(0, 10) : ymd(d);
};
const inRange = (day: string, r: Range) => !!day && day >= r.start && day <= r.end;
const MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

/** Hafta pazartesi başlar. Önceki dönem aynı uzunlukta hemen öncesidir. */
export function periodRange(key: PeriodKey, now = new Date()): { current: Range; previous: Range } {
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = (x: Date) => { const s = new Date(x); s.setDate(s.getDate() - ((s.getDay() + 6) % 7)); return s; };
  const fmt = (a: Date, b: Date) => a.getMonth() === b.getMonth()
    ? `${a.getDate()}–${b.getDate()} ${MONTHS[a.getMonth()]} ${a.getFullYear()}`
    : `${a.getDate()} ${MONTHS[a.getMonth()]} – ${b.getDate()} ${MONTHS[b.getMonth()]} ${b.getFullYear()}`;
  const week = (s: Date): Range => { const e = new Date(s); e.setDate(e.getDate() + 6); return { start: ymd(s), end: ymd(e), label: fmt(s, e) }; };
  const month = (y: number, m: number): Range => { const s = new Date(y, m, 1); const e = new Date(y, m + 1, 0); return { start: ymd(s), end: ymd(e), label: `${MONTHS[s.getMonth()]} ${s.getFullYear()}` }; };
  if (key === 'THIS_WEEK' || key === 'LAST_WEEK') {
    const s = weekStart(d); if (key === 'LAST_WEEK') s.setDate(s.getDate() - 7);
    const p = new Date(s); p.setDate(p.getDate() - 7);
    return { current: week(s), previous: week(p) };
  }
  const m = key === 'THIS_MONTH' ? d.getMonth() : d.getMonth() - 1;
  const cur = month(d.getFullYear(), m);
  const prev = month(d.getFullYear(), m - 1);
  return { current: cur, previous: prev };
}

export const baseProduct = (p?: string) => (p || '').replace(/\s*\(.*\)\s*$/, '').trim();

export interface ReportInput {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  fieldRecords: FieldRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  incidentRecords: any[];
  /** v3.0: muz için sera, kurdele rengi ve hafta */
  muzRecords?: any[];
}

export interface PeriodReport {
  harvest: { kg: number; days: number; lots: number; workers: number; unweighedDays: number; items: Item[] };
  precooling: { slips: number; netKg: number; fivePercent: number; sorting: number; items: Item[] };
  depotIn: { records: number; kg: number; externalKg: number; items: Item[] };
  out: { kg: number; shipKg: number; saleKg: number; items: Item[] };
  fire: { harvestKg: number; shockKg: number; lossKg: number; pct: number; items: Item[] } | null;
  stock: { totalKg: number; byProduct: { product: string; kg: number }[]; byRoom: { place: string; kg: number; lots: number }[]; items: Item[] };
  inspection: { cls: string; kg: number; pct: number | null }[];
  inspectionSampleKg: number;
  tests: { product: string; n: number; avgBrix: number | null; avgHardness: number | null }[];
  checks: { n: number; items: Item[] };
  incidents: { opened: number; openNow: number; items: Item[] };
  warnings: { key: string; text: string; items: Item[] }[];
}

const isClosed = (s: any) => /CLOSED|RESOLVED|COMPLETED|KAPAT|ÇÖZÜLD/i.test(String(s || ''));
const avg = (xs: number[]) => (xs.length ? Number((xs.reduce((a, b) => a + b, 0) / xs.length).toFixed(2)) : null);

export function computePeriodReport(input: ReportInput, r: Range, product: string = 'ALL', today = new Date()): PeriodReport {
  const refMap = new Map(input.references.map(x => [x.refId, x]));
  const prodOf = (refId?: string, own?: string) => baseProduct(own || refMap.get(refId || '')?.product);
  const match = (refId?: string, own?: string) => product === 'ALL' || prodOf(refId, own).toLocaleLowerCase('tr') === product.toLocaleLowerCase('tr');
  const kgOf = (v: any) => Number(v) || 0;

  // --- Hasat
  const harvests = input.harvestRecords.filter(h => inRange(localDay(h.recordDate || h.timestamp), r) && match(h.refId, h.product));
  const harvest = {
    kg: harvests.reduce((s, h) => s + kgOf(h.dailyTotalKg), 0),
    days: harvests.length,
    lots: new Set(harvests.map(h => h.refId)).size,
    workers: harvests.reduce((s, h) => s + kgOf(h.workerCount), 0),
    unweighedDays: harvests.filter(h => !(kgOf(h.dailyTotalKg) > 0)).length,
    items: harvests.map(h => ({ refId: h.refId, date: localDay(h.recordDate || h.timestamp), kg: kgOf(h.dailyTotalKg) || undefined, note: kgOf(h.dailyTotalKg) > 0 ? (h.weighedAt === 'PRECOOLING' ? 'ön soğutmada tartıldı' : undefined) : 'tartılmadı' }))
  };

  // --- Ön soğutma (+ %5 inspeksiyon)
  const slips = input.references.filter(x => match(x.refId, x.product)).flatMap(x => (x.precoolingSlips || []).map(s => ({ ref: x, s }))).filter(({ s }) => inRange(localDay(s.date), r));
  const precooling = {
    slips: slips.length,
    netKg: slips.reduce((a, { s }) => a + kgOf(s.netKg), 0),
    fivePercent: slips.filter(({ s }) => s.inspectionMode === 'FIVE_PERCENT' || (!s.inspectionMode && (s.inspection?.length || 0) > 0)).length,
    sorting: slips.filter(({ s }) => s.inspectionMode === 'SORTING').length,
    items: slips.map(({ ref, s }) => ({ refId: ref.refId, date: localDay(s.date), kg: kgOf(s.netKg) || undefined, note: s.slipNo }))
  };
  const clsKg = new Map<string, number>(INSPECTION_CLASSES.map(c => [c as string, 0]));
  slips.forEach(({ s }) => (s.inspection || []).forEach(row => clsKg.set(row.cls, (clsKg.get(row.cls) || 0) + kgOf(row.kg))));
  const sampleKg = [...clsKg.values()].reduce((a, b) => a + b, 0);
  const inspection = [...clsKg.entries()].map(([cls, kg]) => ({ cls, kg, pct: sampleKg > 0 ? Number(((kg / sampleKg) * 100).toFixed(3)) : null }));

  // --- Fire (hasat → şoklama): yalnızca hasatta ayrıca tartılmış günler
  const hById = new Map(input.harvestRecords.map(h => [h.id, h]));
  const firePairs = slips.map(({ ref, s }) => ({ ref, s, h: s.harvestRecordId ? hById.get(s.harvestRecordId) : undefined }))
    .filter(x => x.h && x.h.weighedAt !== 'PRECOOLING' && !x.s.writtenToHarvest && kgOf(x.h.dailyTotalKg) > 0 && kgOf(x.s.netKg) > 0);
  const fHarvest = firePairs.reduce((a, x) => a + kgOf(x.h!.dailyTotalKg), 0);
  const fShock = firePairs.reduce((a, x) => a + kgOf(x.s.netKg), 0);
  const fire = firePairs.length ? {
    harvestKg: fHarvest, shockKg: fShock, lossKg: fHarvest - fShock, pct: Number((((fHarvest - fShock) / fHarvest) * 100).toFixed(2)),
    items: firePairs.map(x => ({ refId: x.ref.refId, date: localDay(x.s.date), kg: kgOf(x.h!.dailyTotalKg) - kgOf(x.s.netKg), note: `${kgOf(x.h!.dailyTotalKg)} → ${kgOf(x.s.netKg)} kg` }))
  } : null;

  // --- Depoya giriş
  const firstEntry = new Map<string, string>();
  input.ambarRecords.forEach(a => { const d = localDay(a.acceptanceDate || a.timestamp); if (d && (!firstEntry.has(a.refId) || d < firstEntry.get(a.refId)!)) firstEntry.set(a.refId, d); });
  const ambars = input.ambarRecords.filter(a => inRange(localDay(a.acceptanceDate || a.timestamp), r) && match(a.refId, a.product));
  const depotIn = {
    records: ambars.length,
    kg: ambars.reduce((s, a) => s + kgOf(a.acceptedWeightKg), 0),
    externalKg: ambars.filter(a => a.incomingSource === 'EXTERNAL').reduce((s, a) => s + kgOf(a.acceptedWeightKg), 0),
    items: ambars.map(a => ({ refId: a.refId, date: localDay(a.acceptanceDate || a.timestamp), kg: kgOf(a.acceptedWeightKg), note: [a.incomingSource === 'EXTERNAL' ? 'dış alım' : '', a.warehouse, a.roomNo].filter(Boolean).join(' · ') }))
  };

  // --- Çıkış: depo girişinden sonraki sevkler + satışlar
  const isOutShip = (l: LojistikRecord) => { const e = firstEntry.get(l.refId); const d = localDay(l.shipmentDate); return !!e && d >= e; };
  const ships = input.lojistikRecords.filter(l => inRange(localDay(l.shipmentDate), r) && isOutShip(l) && match(l.refId, (l as any).product));
  const sales = input.salesRecords.filter(s => inRange(localDay(s.salesDate), r) && match(s.refId));
  const out = {
    shipKg: ships.reduce((a, l) => a + kgOf(l.weightKg), 0),
    saleKg: sales.reduce((a, s) => a + kgOf(s.totalQuantityKg), 0),
    kg: 0,
    items: [
      ...ships.map(l => ({ refId: l.refId, date: localDay(l.shipmentDate), kg: kgOf(l.weightKg), note: 'sevk' })),
      ...sales.map(s => ({ refId: s.refId, date: localDay(s.salesDate), kg: kgOf(s.totalQuantityKg), note: 'satış' }))
    ].sort((a, b) => a.date.localeCompare(b.date))
  };
  out.kg = out.shipKg + out.saleKg;

  // --- Depo durumu (dönem sonu): giriş − çıkış, oda bazında
  const outUntil = (refId: string, entry: string) =>
    input.lojistikRecords.filter(l => l.refId === refId && localDay(l.shipmentDate) >= entry && localDay(l.shipmentDate) <= r.end).reduce((a, l) => a + kgOf(l.weightKg), 0) +
    input.salesRecords.filter(s => s.refId === refId && localDay(s.salesDate) >= entry && localDay(s.salesDate) <= r.end).reduce((a, s) => a + kgOf(s.totalQuantityKg), 0);
  const byRef = new Map<string, { a: AmbarRecord[]; entry: string }>();
  input.ambarRecords.filter(a => { const d = localDay(a.acceptanceDate || a.timestamp); return d && d <= r.end && match(a.refId, a.product); })
    .forEach(a => { const e = firstEntry.get(a.refId) || ''; const cur = byRef.get(a.refId) || { a: [], entry: e }; cur.a.push(a); byRef.set(a.refId, cur); });
  const prodKg = new Map<string, number>(); const roomKg = new Map<string, { kg: number; lots: Set<string> }>(); const stockItems: Item[] = [];
  byRef.forEach(({ a, entry }, refId) => {
    const inKg = a.reduce((s, x) => s + kgOf(x.acceptedWeightKg), 0);
    let left = Math.max(0, inKg - outUntil(refId, entry));
    if (left <= 0) return;
    stockItems.push({ refId, date: entry, kg: left, note: a.map(x => [x.warehouse, x.roomNo].filter(Boolean).join(' / ')).join(', ') });
    const p = prodOf(refId, a[0].product) || 'Belirtilmedi';
    prodKg.set(p, (prodKg.get(p) || 0) + left);
    // kalan miktar, giriş miktarlarına oranla odalara dağıtılır
    a.forEach(x => {
      const share = inKg > 0 ? (kgOf(x.acceptedWeightKg) / inKg) * left : 0;
      const place = [x.warehouse || 'Depo belirtilmedi', x.roomNo || 'Oda belirtilmedi'].join(' / ');
      const cur = roomKg.get(place) || { kg: 0, lots: new Set<string>() };
      cur.kg += share; cur.lots.add(refId); roomKg.set(place, cur);
    });
  });
  const stock = {
    totalKg: [...prodKg.values()].reduce((a, b) => a + b, 0),
    byProduct: [...prodKg.entries()].map(([product, kg]) => ({ product, kg })).sort((a, b) => b.kg - a.kg),
    byRoom: [...roomKg.entries()].map(([place, v]) => ({ place, kg: v.kg, lots: v.lots.size })).sort((a, b) => a.place.localeCompare(b.place, 'tr')),
    items: stockItems
  };

  // --- Testler (ürün bazında; ürünler karışmaz)
  const tests = input.fieldRecords.filter(f => inRange(localDay(f.harvestDate || f.timestamp), r) && match(f.refId, f.product));
  const tMap = new Map<string, FieldRecord[]>();
  tests.forEach(t => { const p = prodOf(t.refId, t.product) || 'Belirtilmedi'; tMap.set(p, [...(tMap.get(p) || []), t]); });
  const testRows = [...tMap.entries()].map(([p, xs]) => ({
    product: p, n: xs.length,
    avgBrix: avg(xs.map(x => Number(x.avgBrix)).filter(v => v > 0)),
    avgHardness: avg(xs.map(x => Number(x.avgHardness)).filter(v => v > 0))
  }));

  // --- Depo kontrolleri
  const checkItems: Item[] = [];
  input.ambarRecords.filter(a => match(a.refId, a.product)).forEach(a => (a.storageChecks || []).forEach(c => {
    const d = localDay(c.at); if (inRange(d, r)) checkItems.push({ refId: a.refId, date: d, note: [c.roomTemperatureC != null ? `oda ${c.roomTemperatureC} °C` : '', c.firmness != null ? `sertlik ${c.firmness}` : '', c.brix != null ? `Brix ${c.brix}` : ''].filter(Boolean).join(' · ') });
  }));

  // --- DÖF
  const incs = input.incidentRecords.filter((i: any) => match(i.refId));
  const opened = incs.filter((i: any) => inRange(localDay(i.incidentDate || i.recordDate || i.timestamp), r));
  const incidents = { opened: opened.length, openNow: incs.filter((i: any) => !isClosed(i.status)).length, items: opened.map((i: any) => ({ refId: i.refId, date: localDay(i.incidentDate || i.recordDate || i.timestamp), note: i.title || i.category || '' })) };

  // --- Eksik kayıtlar (bugün itibarıyla)
  const todayDay = ymd(today);
  const lots = input.references.filter(x => x.refKind !== 'TEST' && x.moduleKey === 'HARVEST' && !x.archived && match(x.refId, x.product));
  const unweighedLots = lots.filter(x => !(kgOf(x.quantity) > 0) && !(x.precoolingSlips || []).some(s => kgOf(s.netKg) > 0) && !input.ambarRecords.some(a => a.refId === x.refId));
  const harvestedNoSlip = lots.filter(x => !(x.precoolingSlips?.length) && !input.ambarRecords.some(a => a.refId === x.refId) && kgOf(x.quantity) > 0);
  const staleChecks = stock.items.filter(it => {
    const recs = input.ambarRecords.filter(a => a.refId === it.refId);
    const last = recs.flatMap(a => (a.storageChecks || []).map(c => localDay(c.at))).sort().pop() || it.date;
    return !!last && (new Date(todayDay).getTime() - new Date(last).getTime()) / 86400000 >= 7;
  });
  const warnings = [
    { key: 'unweighed', text: 'Tartılmamış parti (tonaj henüz yok)', items: unweighedLots.map(x => ({ refId: x.refId, date: localDay(x.createdAt) })) },
    { key: 'noslip', text: 'Hasat edildi, ön soğutma veya depo kaydı yok', items: harvestedNoSlip.map(x => ({ refId: x.refId, date: localDay(x.createdAt), kg: kgOf(x.quantity) })) },
    { key: 'stale', text: 'Depoda, 7 gündür kontrol yapılmamış', items: staleChecks }
  ].filter(w => w.items.length > 0);

  return {
    harvest, precooling, depotIn, out, fire, stock,
    inspection, inspectionSampleKg: sampleKg,
    tests: testRows,
    checks: { n: checkItems.length, items: checkItems },
    incidents, warnings
  };
}


// ============================================================================
// v3.0 — Bahçe bazında rapor ve Soğuk Depo Durumu
// Bahçe = veriyi ayıran ana anahtar (muzda sera). Ürün ve görünüş (kalite sınıfı) tüm bahçelerde ortak listeden.
// ============================================================================

/** ISO hafta numarası */
export function isoWeek(day: string): number | null {
  if (!day) return null;
  const d = new Date(`${day}T12:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}

interface Ctx {
  refMap: Map<string, ReferenceItem>;
  prodOf: (refId?: string, own?: string) => string;
  orchardOf: (refId?: string, own?: string) => string;
  match: (refId?: string, own?: string) => boolean;
  muzByRef: Map<string, any[]>;
}

function makeCtx(input: ReportInput, product: string): Ctx {
  const refMap = new Map(input.references.map(x => [x.refId, x]));
  const prodOf = (refId?: string, own?: string) => baseProduct(own || refMap.get(refId || '')?.product);
  const match = (refId?: string, own?: string) => product === 'ALL' || prodOf(refId, own).toLocaleLowerCase('tr') === product.toLocaleLowerCase('tr');
  const harvestByRef = new Map<string, HarvestRecord[]>();
  input.harvestRecords.forEach(h => harvestByRef.set(h.refId, [...(harvestByRef.get(h.refId) || []), h]));
  const muzByRef = new Map<string, any[]>();
  (input.muzRecords || []).forEach((m: any) => muzByRef.set(m.refId, [...(muzByRef.get(m.refId) || []), m]));
  // Bahçe adı önceliği: parti kaydı → günlük hasat → muz serası → kaydın kendi yazdığı ad (yazım farkları gruplamayı bozmaz)
  const orchardOf = (refId?: string, own?: string) => {
    const ref = refMap.get(refId || '');
    const h = harvestByRef.get(refId || '')?.[0] as any;
    const m = muzByRef.get(refId || '')?.[0];
    const isBanana = /muz/i.test(prodOf(refId));
    const external = ref?.moduleKey === 'AMBAR' && ref?.source ? `Dış alım: ${ref.source}` : '';
    const name = (isBanana ? (m?.greenhouseNo || ref?.greenhouse || h?.greenhouse) : '')
      || ref?.orchard || h?.orchard || ref?.greenhouse || h?.greenhouse || m?.greenhouseNo || ref?.parcel || external || (own && own.trim()) || ref?.location || 'Belirtilmedi';
    return String(name).trim();
  };
  return { refMap, prodOf, orchardOf, match, muzByRef };
}
const keyOf = (s: string) => s.toLocaleLowerCase('tr').replace(/\s+/g, ' ').trim();

export interface OrchardRow {
  orchard: string;
  products: string[];
  harvestKg: number;
  workers: number;          // kişi-gün (günlük hasatlardaki kişi sayılarının toplamı)
  days: number;
  unweighedDays: number;
  shockKg: number;
  fireKg: number | null;
  firePct: number | null;
  quality: { cls: string; kg: number; pct: number | null }[];
  sampleKg: number;
  stockKg: number;
  ribbons: string[];        // muz: kurdele renkleri
  weeks: number[];          // hasat haftaları (ISO)
  refIds: string[];
}

/** Bahçe bazında satırlar (dönem içi). Ürün filtresi seçiliyse yalnızca o ürünün bahçeleri ve o ürünün yüzdeleri. */
export function computeOrchardRows(input: ReportInput, r: Range, product: string = 'ALL'): OrchardRow[] {
  const c = makeCtx(input, product);
  const rows = new Map<string, OrchardRow & { cls: Map<string, number>; fireH: number; fireS: number }>();
  const row = (name: string) => {
    const k = keyOf(name);
    if (!rows.has(k)) rows.set(k, { orchard: name, products: [], harvestKg: 0, workers: 0, days: 0, unweighedDays: 0, shockKg: 0, fireKg: null, firePct: null, quality: [], sampleKg: 0, stockKg: 0, ribbons: [], weeks: [], refIds: [], cls: new Map(), fireH: 0, fireS: 0 });
    return rows.get(k)!;
  };
  const addProduct = (x: OrchardRow, p: string) => { if (p && !x.products.includes(p)) x.products.push(p); };
  const addRef = (x: OrchardRow, id: string) => { if (id && !x.refIds.includes(id)) x.refIds.push(id); };
  const num = (v: any) => Number(v) || 0;

  // Hasat: kg, kişi-gün, gün, hafta
  input.harvestRecords.forEach(h => {
    const day = localDay(h.recordDate || h.timestamp);
    if (!inRange(day, r) || !c.match(h.refId, h.product)) return;
    const x = row(c.orchardOf(h.refId, (h as any).orchard || (h as any).greenhouse));
    x.harvestKg += num(h.dailyTotalKg); x.workers += num(h.workerCount); x.days += 1;
    if (!(num(h.dailyTotalKg) > 0)) x.unweighedDays += 1;
    const w = isoWeek(day); if (w && !x.weeks.includes(w)) x.weeks.push(w);
    addProduct(x, c.prodOf(h.refId, h.product)); addRef(x, h.refId);
  });
  // Muz: sera, kurdele, hafta
  (input.muzRecords || []).forEach((m: any) => {
    const day = localDay(m.recordDate || m.timestamp);
    if (!inRange(day, r) || !c.match(m.refId, 'Muz')) return;
    const x = row(c.orchardOf(m.refId, m.greenhouseNo));
    if (m.ribbonColor && !x.ribbons.includes(m.ribbonColor)) x.ribbons.push(m.ribbonColor);
    const w = isoWeek(day); if (w && !x.weeks.includes(w)) x.weeks.push(w);
    addProduct(x, 'Muz'); addRef(x, m.refId);
  });
  // Ön soğutma, %5 inspeksiyon ve fire
  const hById = new Map(input.harvestRecords.map(h => [h.id, h]));
  input.references.forEach(ref => (ref.precoolingSlips || []).forEach(sl => {
    if (!inRange(localDay(sl.date), r) || !c.match(ref.refId, ref.product)) return;
    const x = row(c.orchardOf(ref.refId));
    x.shockKg += num(sl.netKg);
    (sl.inspection || []).forEach(ir => x.cls.set(ir.cls, (x.cls.get(ir.cls) || 0) + num(ir.kg)));
    const h = sl.harvestRecordId ? hById.get(sl.harvestRecordId) : undefined;
    if (h && h.weighedAt !== 'PRECOOLING' && !sl.writtenToHarvest && num(h.dailyTotalKg) > 0 && num(sl.netKg) > 0) { x.fireH += num(h.dailyTotalKg); x.fireS += num(sl.netKg); }
    addProduct(x, c.prodOf(ref.refId)); addRef(x, ref.refId);
  }));
  // Depoda kalan (dönem sonu)
  const rep = computePeriodReport(input, r, product);
  rep.stock.items.forEach(it => { const x = row(c.orchardOf(it.refId)); x.stockKg += num(it.kg); addProduct(x, c.prodOf(it.refId)); addRef(x, it.refId); });

  return [...rows.values()].map(x => {
    const sample = [...x.cls.values()].reduce((a, b) => a + b, 0);
    const quality = INSPECTION_CLASSES.map(cls => ({ cls: cls as string, kg: x.cls.get(cls) || 0, pct: sample > 0 ? Number((((x.cls.get(cls) || 0) / sample) * 100).toFixed(3)) : null }));
    const fireKg = x.fireH > 0 ? x.fireH - x.fireS : null;
    const { cls, fireH, fireS, ...rest } = x;
    return { ...rest, quality, sampleKg: sample, fireKg, firePct: x.fireH > 0 ? Number((((x.fireH - x.fireS) / x.fireH) * 100).toFixed(2)) : null, weeks: [...x.weeks].sort((a, b) => a - b) };
  }).sort((a, b) => a.orchard.localeCompare(b.orchard, 'tr'));
}

export interface ColdRow {
  room: string;
  orchard: string;
  product: string;
  appearance: string;
  status: string;
  kg: number;
  refIds: string[];
  banana?: string;          // muz: sera · kurdele · hafta
}

/** Soğuk Depo Durumu — şu an (bugün itibarıyla): hangi bahçenin ürünü hangi odada, hangi görünüşte, ne durumda. */
export function computeColdStatus(input: ReportInput, product: string = 'ALL', today = new Date()): ColdRow[] {
  const c = makeCtx(input, product);
  const todayDay = localDay(today.toISOString());
  const num = (v: any) => Number(v) || 0;
  const groups = new Map<string, ColdRow>();
  const add = (row: Omit<ColdRow, 'refIds' | 'kg'>, kg: number, refId: string) => {
    if (kg <= 0) return;
    const k = [row.room, keyOf(row.orchard), row.product, row.appearance, row.status].join('|');
    const g = groups.get(k) || { ...row, kg: 0, refIds: [] };
    g.kg += kg; if (!g.refIds.includes(refId)) g.refIds.push(refId);
    groups.set(k, g);
  };
  const bananaInfo = (refId: string) => {
    const ms = c.muzByRef.get(refId); if (!ms?.length) return undefined;
    const m = [...ms].sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')))[0];
    const w = isoWeek(localDay(m.recordDate || m.timestamp));
    return [m.greenhouseNo, m.ribbonColor ? `kurdele ${m.ribbonColor}` : '', w ? `${w}. hafta` : ''].filter(Boolean).join(' · ');
  };

  // 1) Depodaki partiler: giriş − çıkış, kayıt başına orantılı
  const byRef = new Map<string, AmbarRecord[]>();
  input.ambarRecords.forEach(a => { const d = localDay(a.acceptanceDate || a.timestamp); if (d && d <= todayDay && c.match(a.refId, a.product)) byRef.set(a.refId, [...(byRef.get(a.refId) || []), a]); });
  byRef.forEach((list, refId) => {
    const entry = list.map(a => localDay(a.acceptanceDate || a.timestamp)).sort()[0];
    const inKg = list.reduce((s, a) => s + num(a.acceptedWeightKg), 0);
    const outKg = input.lojistikRecords.filter(l => l.refId === refId && localDay(l.shipmentDate) >= entry && localDay(l.shipmentDate) <= todayDay).reduce((s, l) => s + num(l.weightKg), 0)
      + input.salesRecords.filter(s => s.refId === refId && localDay(s.salesDate) >= entry && localDay(s.salesDate) <= todayDay).reduce((s, x) => s + num(x.totalQuantityKg), 0);
    const left = Math.max(0, inKg - outKg);
    if (left <= 0) return;
    const product = c.prodOf(refId, list[0].product) || 'Belirtilmedi';
    list.forEach(a => {
      const share = inKg > 0 ? (num(a.acceptedWeightKg) / inKg) * left : 0;
      add({
        room: [a.warehouse || 'Depo belirtilmedi', a.roomNo || 'Oda belirtilmedi'].join(' / ') + (a.stackRow ? ` / ${a.stackRow}` : ''),
        orchard: c.orchardOf(refId), product,
        appearance: a.appearance || UNCLASSIFIED,
        status: STORAGE_STATUS_LABEL[a.storageStatus || 'WAITING'],
        banana: /muz/i.test(product) ? bananaInfo(refId) : undefined
      }, share, refId);
    });
  });

  // 2) Henüz depoya girmemiş, ön soğutmadaki / ön soğutulmuş partiler (bahçenin tesisinde veya merkezde)
  input.references.forEach(ref => {
    if (byRef.has(ref.refId) || !(ref.precoolingSlips?.length) || !c.match(ref.refId, ref.product) || ref.archived) return;
    const product = c.prodOf(ref.refId) || 'Belirtilmedi';
    ref.precoolingSlips!.forEach(sl => {
      if (localDay(sl.date) > todayDay) return;
      add({
        room: sl.tunnel || (sl.site === 'ORCHARD' ? 'Bahçe ön soğutma' : 'Ön soğutma'),
        orchard: c.orchardOf(ref.refId), product,
        appearance: UNCLASSIFIED,
        status: sl.endAt ? `Ön soğutuldu — ${sl.site === 'ORCHARD' ? 'merkeze sevk bekliyor' : 'depoya giriş bekliyor'}` : (sl.site === 'ORCHARD' ? 'Bahçede ön soğutmada' : 'Ön soğutmada'),
        banana: /muz/i.test(product) ? bananaInfo(ref.refId) : undefined
      }, num(sl.netKg), ref.refId);
    });
  });

  return [...groups.values()].sort((a, b) => a.room.localeCompare(b.room, 'tr') || a.orchard.localeCompare(b.orchard, 'tr') || a.product.localeCompare(b.product, 'tr') || a.appearance.localeCompare(b.appearance, 'tr'));
}

/** Excel'de açılan CSV (Türkçe Excel: ; ayırıcı, UTF-8 BOM) */
export function toCsv(rows: (string | number | null | undefined)[][]): string {
  const esc = (v: any) => { const s = v == null ? '' : typeof v === 'number' ? String(v).replace('.', ',') : String(v); return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return '\uFEFF' + rows.map(r => r.map(esc).join(';')).join('\r\n');
}
