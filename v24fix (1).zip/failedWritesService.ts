/**
 * Başarısız yazma kuyruğu ve yazma sonucu yardımcıları (v2.4)
 * ------------------------------------------------------------------
 * getWriteResult ve testStorageUpload artık kayıt servisinin (firestoreService)
 * GERÇEK sonuçlarını okur; debug log ayrıştırması kaldırıldı.
 * Dışa açılan adlar ve dönüş biçimleri önceki sürümle aynıdır (App.tsx ve
 * SystemDiagnosticsView değişmeden çalışır).
 */
import {
  getWriteResult as fsGetWriteResult,
  testStorageUpload as fsTestStorageUpload
} from '../lib/firestoreService';

export interface WriteResult {
  success: boolean;
  error?: string;
  warning?: string;
}

export interface FailedWriteItem {
  id: string;
  moduleKey: string;
  record: any;
  reference?: any;
  timestamp: string;
  error: string;
}

export const FAILED_WRITES_KEY = 'miwe_failed_writes';

/** Bir kaydın son yazma sonucu (hata/uyarı metniyle), kayıt servisinden. */
export function getWriteResult(idOrRefId: string): WriteResult | undefined {
  if (!idOrRefId) return undefined;
  const r = fsGetWriteResult(String(idOrRefId));
  if (!r) return undefined;
  return { success: r.ok, error: r.error, warning: r.warning };
}

/** Firebase Storage'a küçük bir test görseli yükler. */
export async function testStorageUpload(): Promise<{ success: boolean; message: string; url?: string }> {
  const r = await fsTestStorageUpload();
  return r.ok
    ? { success: true, message: 'Fotoğraf yükleme testi başarılı: Firebase Storage çalışıyor.' }
    : { success: false, message: `Fotoğraf yükleme testi başarısız: ${r.error || 'bilinmeyen hata'}` };
}

function approxBytes(obj: any): number {
  try {
    return new Blob([JSON.stringify(obj)]).size;
  } catch {
    return 0;
  }
}

/** 'miwe_failed_writes' listesini localStorage'dan okur. */
export function getFailedWrites(): FailedWriteItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem(FAILED_WRITES_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

/** Başarısız yazmayı kaydeder (2 MB aşılırsa fotoğraflar çıkarılır). */
export function saveFailedWrite(item: FailedWriteItem): void {
  if (typeof window === 'undefined') return;
  const list = getFailedWrites().filter(i => i.id !== item.id);

  let cleanItem = { ...item };
  if (approxBytes(cleanItem) > 2000000) {
    if (cleanItem.record && Array.isArray(cleanItem.record.photos)) {
      cleanItem.record = { ...cleanItem.record, photos: [] };
    }
  }

  const updated = [cleanItem, ...list];
  try {
    localStorage.setItem(FAILED_WRITES_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save failed write item to localStorage', e);
  }
}

/** Sunucuya aktarılan kaydı 'miwe_failed_writes' listesinden çıkarır. */
export function removeFailedWrite(id: string): void {
  if (typeof window === 'undefined') return;
  const updated = getFailedWrites().filter(i => i.id !== id);
  try {
    localStorage.setItem(FAILED_WRITES_KEY, JSON.stringify(updated));
  } catch {}
}
