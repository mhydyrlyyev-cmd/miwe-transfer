import {
  collection,
  doc,
  getDocs,
  getDocsFromServer,
  getDocsFromCache,
  getDoc,
  getDocFromServer,
  setDoc,
  deleteDoc,
  writeBatch,
  onSnapshot,
  query,
  where,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { ref as storageRef, uploadString, getDownloadURL } from 'firebase/storage';
import { db, auth, storage, handleFirestoreError, OperationType } from './firebase';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  SalesRecord,
  IncidentRecord,
  ExportSampleRecord,
  FreezeDryRecord,
  FeedbackRecord,
  CustomFieldDefinition
} from '../types';
import { AppUser } from '../types/auth';
import { CentralAppData } from '../utils/syncService';
import { addDebugLog } from '../utils/debugLogger';

export const MODULE_TO_COLLECTION_MAP: Record<string, string> = {
  REFERENCE: 'references',
  REFERENCES: 'references',
  references: 'references',
  HARVEST: 'harvestRecords',
  harvestRecords: 'harvestRecords',
  FIELD: 'fieldRecords',
  fieldRecords: 'fieldRecords',
  MUZ: 'muzRecords',
  muzRecords: 'muzRecords',
  BADEM: 'bademRecords',
  bademRecords: 'bademRecords',
  LOJISTIK: 'lojistikRecords',
  lojistikRecords: 'lojistikRecords',
  AMBAR: 'ambarRecords',
  ambarRecords: 'ambarRecords',
  SALES: 'salesRecords',
  salesRecords: 'salesRecords',
  INCIDENT: 'incidentRecords',
  incidentRecords: 'incidentRecords',
  EXPORT_SAMPLE: 'exportSampleRecords',
  exportSampleRecords: 'exportSampleRecords',
  FREEZE_DRY: 'freezeDryRecords',
  freezeDryRecords: 'freezeDryRecords',
  FEEDBACK: 'feedbacks',
  feedbacks: 'feedbacks',
  CUSTOM_FIELD: 'customFields',
  customFields: 'customFields',
  GANTT: 'ganttParcels',
  ganttParcels: 'ganttParcels',
  MONTHLY_REPORT: 'monthlyQualityReports',
  monthlyQualityReports: 'monthlyQualityReports'
};

const ALL_DATA_COLLECTIONS = [
  'references',
  'harvestRecords',
  'fieldRecords',
  'muzRecords',
  'bademRecords',
  'lojistikRecords',
  'ambarRecords',
  'salesRecords',
  'incidentRecords',
  'exportSampleRecords',
  'freezeDryRecords',
  'feedbacks',
  'customFields',
  'ganttParcels',
  'monthlyQualityReports'
] as const;

// -------------------------------------------------------------
// İZLENEBİLİRLİK DAMGASI (_audit) — kim, ne zaman oluşturdu/değiştirdi
// firestore.rules: _audit.updatedBy.uid === oturum sahibi olmak ZORUNDA
// -------------------------------------------------------------
function actor() {
  const u = auth.currentUser;
  let name = '';
  try {
    const raw = localStorage.getItem('miwe_current_user');
    name = raw ? (JSON.parse(raw)?.fullName || '') : '';
  } catch {}
  return { uid: u?.uid || '', email: u?.email || '', name: name || u?.email || '' };
}

export function withAudit<T extends Record<string, any>>(record: T): T & { _audit: any } {
  const me = actor();
  const nowIso = new Date().toISOString();
  const prev = (record as any)._audit || {};
  const { _audit: _ignored, ...rest } = record as any;
  return {
    ...rest,
    updatedAt: nowIso,
    _audit: {
      createdBy: prev.createdBy || me,
      createdAt: prev.createdAt || (record as any).createdAt || nowIso,
      updatedBy: me,
      updatedAtIso: nowIso,
      serverUpdatedAt: serverTimestamp(),
      revision: (typeof prev.revision === 'number' ? prev.revision : 0) + 1
    }
  } as any;
}

// -------------------------------------------------------------
// FOTOĞRAFLAR — Firestore belgesi 1 MB sınırlıdır; base64 fotoğraflar
// Firebase Storage'a yüklenir, kayıtta sadece bağlantı (URL) tutulur.
// -------------------------------------------------------------
const FIRESTORE_SAFE_BYTES = 900 * 1024;

async function externalizePhotos(collectionName: string, recordId: string, record: any): Promise<any> {
  if (!Array.isArray(record?.photos) || !record.photos.some((p: any) => typeof p === 'string' && p.startsWith('data:'))) {
    return record;
  }
  const photos: string[] = [];
  for (let i = 0; i < record.photos.length; i++) {
    const p = record.photos[i];
    if (typeof p === 'string' && p.startsWith('data:')) {
      try {
        const r = storageRef(storage, `photos/${collectionName}/${recordId}/${i}-${Date.now()}.jpg`);
        await uploadString(r, p, 'data_url');
        photos.push(await getDownloadURL(r));
      } catch (err) {
        addDebugLog('STORAGE', 'WARN', '[Storage] Fotoğraf yüklenemedi, kayıt içinde tutulacak', { err: (err as any)?.code || String(err) });
        photos.push(p);
      }
    } else {
      photos.push(p);
    }
  }
  return { ...record, photos };
}

function approxBytes(obj: unknown): number {
  try { return new Blob([JSON.stringify(obj)]).size; } catch { return 0; }
}

// -------------------------------------------------------------
// YAZMA SONUCU — arayüz başarısız yazmayı kullanıcıya gösterebilsin
// (v2.3: "sessiz başarısızlık" kaldırıldı)
// -------------------------------------------------------------
export interface WriteResult { ok: boolean; error?: string; warning?: string; at: string }
const writeResults = new Map<string, WriteResult>();
let lastWriteResult: WriteResult | null = null;

function setResult(recordId: string, r: Omit<WriteResult, 'at'>): WriteResult {
  const full = { ...r, at: new Date().toISOString() };
  writeResults.set(recordId, full);
  lastWriteResult = full;
  return full;
}

/** Bir kaydın son yazma sonucu (hata/uyarı metniyle). */
export function getWriteResult(recordId: string): WriteResult | null {
  return writeResults.get(String(recordId)) || null;
}
/** En son yazma işleminin sonucu. */
export function getLastWriteResult(): WriteResult | null {
  return lastWriteResult;
}

function translateWriteError(err: any): string {
  const code = String(err?.code || '');
  if (code.includes('permission-denied')) return 'Yetki reddedildi: hesabınızın bu modüle yazma izni yok ya da kayıt güvenlik kurallarına uymuyor.';
  if (code.includes('unauthenticated')) return 'Oturum doğrulanmadı; çıkış yapıp tekrar giriş yapın.';
  if (code.includes('invalid-argument')) return 'Geçersiz veri: kayıt çok büyük ya da desteklenmeyen bir alan içeriyor.';
  if (code.includes('resource-exhausted')) return 'Firebase kotası aşıldı.';
  if (code.includes('unavailable') || code.includes('deadline-exceeded')) return 'Sunucuya ulaşılamadı.';
  return String(err?.message || err || 'Bilinmeyen hata');
}

/** data URL görselini tarayıcıda küçültür (Storage kullanılamazsa kayda sığdırmak için). */
function shrinkDataUrl(dataUrl: string, maxDim: number, quality: number): Promise<string> {
  return new Promise(resolve => {
    try {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(dataUrl);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    } catch {
      resolve(dataUrl);
    }
  });
}

/**
 * Kaydı 1 MB sınırına sığdırır. Öncelik ÖLÇÜM VERİSİDİR: fotoğraflar yüzünden kayıt asla kaybolmaz.
 * 1) Gömülü fotoğrafları kademeli küçült  2) Yine sığmazsa gömülü fotoğrafları çıkar (galeride kalır).
 */
export async function fitWithinLimit(record: any): Promise<{ record: any; warning?: string }> {
  if (approxBytes(record) <= FIRESTORE_SAFE_BYTES) return { record };
  const photos: any[] = Array.isArray(record?.photos) ? record.photos : [];
  const hasInline = photos.some(p => typeof p === 'string' && p.startsWith('data:'));
  if (hasInline && typeof document !== 'undefined') {
    for (const [dim, q] of [[1280, 0.7], [1024, 0.6], [800, 0.5], [640, 0.45]] as Array<[number, number]>) {
      const shrunk = await Promise.all(photos.map(p => (typeof p === 'string' && p.startsWith('data:') ? shrinkDataUrl(p, dim, q) : p)));
      const candidate = { ...record, photos: shrunk };
      if (approxBytes(candidate) <= FIRESTORE_SAFE_BYTES) {
        return { record: candidate, warning: 'Fotoğraflar buluta (Storage) yüklenemedi; küçültülerek kayda eklendi.' };
      }
    }
  }
  if (hasInline) {
    const kept = photos.filter(p => !(typeof p === 'string' && p.startsWith('data:')));
    const removed = photos.length - kept.length;
    const candidate = { ...record, photos: kept, photosLocalOnly: removed };
    if (approxBytes(candidate) <= FIRESTORE_SAFE_BYTES) {
      return { record: candidate, warning: `${removed} fotoğraf buluta yüklenemedi; ölçümler kaydedildi, fotoğraflar yalnızca bu cihazın galerisinde.` };
    }
  }
  throw new Error('Kayıt verisi (fotoğraflar hariç) 1 MB sınırını aşıyor.');
}

/** Sunucu onayı bu süreden uzun sürerse kayıt cihazda kuyrukta kabul edilir (SDK bağlantı gelince gönderir). */
const COMMIT_ACK_TIMEOUT_MS = 12000;

/**
 * 1. Tekil kaydı Firestore'a yazar (TEK DOĞRULUK KAYNAĞI).
 * Dönüş: true/false. Ayrıntı (hata/uyarı metni) için getWriteResult(recordId).
 */
export async function saveRecordToFirestore(
  moduleKey: string,
  record: any,
  reference?: any
): Promise<boolean> {
  const collectionName = MODULE_TO_COLLECTION_MAP[moduleKey] || moduleKey;
  const recordId = String(record?.id || record?.refId || '').trim();

  if (!recordId) {
    lastWriteResult = { ok: false, error: 'Kayıt kimliği (id/refId) yok.', at: new Date().toISOString() };
    console.error('[Firestore] Kayıt kimliği (id/refId) bulunamadı.');
    return false;
  }
  if (!auth.currentUser) {
    setResult(recordId, { ok: false, error: 'Oturum yok: kayıt sunucuya yazılmadı. Tekrar giriş yapıp kaydedin.' });
    addDebugLog('STORAGE', 'ERROR', '[Firestore] Oturum yok — kayıt yazılmadı', { collectionName, recordId });
    return false;
  }

  try {
    // Form kaydı _audit olmadan yeniden kurduysa, mevcut belgedeki "ilk oluşturan" bilgisini koru
    // (kurallar createdBy'nin değiştirilmesini reddeder)
    let base = record;
    if (!record?._audit) {
      try {
        const existing = await getDoc(doc(db, collectionName, recordId));
        const prevAudit = existing.exists() ? (existing.data() as any)?._audit : null;
        if (prevAudit) base = { ...record, _audit: prevAudit };
      } catch { /* çevrimdışı ve önbellekte yok: yeni kayıt kabul edilir */ }
    }
    const externalized = await externalizePhotos(collectionName, recordId, base);
    const fitted = await fitWithinLimit(externalized);
    const clean = withAudit(fitted.record);

    // Aynı kayıt için yazma sırası korunur (batch = atomik)
    const batch = writeBatch(db);
    batch.set(doc(db, collectionName, recordId), clean, { merge: true });
    if (reference && reference.refId && collectionName !== 'references') {
      batch.set(doc(db, 'references', String(reference.refId)), withAudit(reference), { merge: true });
    }

    let queued = false;
    await Promise.race([
      batch.commit(),
      new Promise<void>(resolve => setTimeout(() => { queued = true; resolve(); }, COMMIT_ACK_TIMEOUT_MS))
    ]);

    const warnings = [fitted.warning, queued ? 'Sunucu onayı gecikti: kayıt cihazda kuyrukta, bağlantı gelince gönderilecek.' : undefined].filter(Boolean);
    setResult(recordId, { ok: true, warning: warnings.length ? warnings.join(' ') : undefined });
    addDebugLog('STORAGE', queued ? 'WARN' : 'INFO', `[Firestore] Kayıt ${queued ? 'kuyruğa alındı' : 'kaydedildi'}: ${collectionName}/${recordId}`, fitted.warning ? { warning: fitted.warning } : undefined);
    return true;
  } catch (error) {
    const msg = translateWriteError(error);
    setResult(recordId, { ok: false, error: msg });
    addDebugLog('STORAGE', 'ERROR', `[Firestore] Kayıt yazma hatası: ${collectionName}/${recordId}`, { error: msg, code: (error as any)?.code });
    handleFirestoreError(error, OperationType.WRITE, `${collectionName}/${recordId}`);
    return false;
  }
}

/** Teşhis: Storage'a küçük bir test görseli yükler. Fotoğrafların buluta gidip gitmediğini gösterir. */
export async function testStorageUpload(): Promise<{ ok: boolean; error?: string }> {
  if (!auth.currentUser) return { ok: false, error: 'Oturum yok.' };
  const tinyPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  try {
    const r = storageRef(storage, `photos/_diag/${auth.currentUser.uid}-${Date.now()}.png`);
    await uploadString(r, tinyPng, 'data_url');
    await getDownloadURL(r);
    return { ok: true };
  } catch (err: any) {
    const code = String(err?.code || '');
    if (code.includes('unauthorized')) return { ok: false, error: 'Storage kuralları yüklemeye izin vermiyor (storage.rules yayınlanmamış olabilir).' };
    if (code.includes('bucket') || code.includes('project-not-found') || code.includes('no-default-bucket')) return { ok: false, error: 'Firebase Storage bu projede etkin değil.' };
    if (code.includes('retry-limit') || code.includes('network')) return { ok: false, error: 'Ağ hatası: Storage’a ulaşılamadı.' };
    return { ok: false, error: `${code || 'Hata'}: ${err?.message || err}` };
  }
}

/** Fotoğrafı Storage'a yükler ve bağlantısını döner (galeri yedeği için). */
export async function uploadPhotoToStorage(id: string, dataUrl: string): Promise<string | null> {
  if (!auth.currentUser || !dataUrl?.startsWith('data:')) return null;
  try {
    const r = storageRef(storage, `photos/gallery/${id}.jpg`);
    await uploadString(r, dataUrl, 'data_url');
    return await getDownloadURL(r);
  } catch {
    return null;
  }
}

// -------------------------------------------------------------
// SİLME KAYITLARI (tombstones) — silinen kaydın başka cihazdan "dirilmesini" engeller
// -------------------------------------------------------------
async function writeTombstone(collectionName: string, id: string) {
  const me = actor();
  await setDoc(doc(db, 'tombstones', `${collectionName}__${id}`), {
    collection: collectionName,
    recordId: id,
    deletedBy: me,
    deletedAt: new Date().toISOString(),
    serverDeletedAt: serverTimestamp()
  });
}

async function fetchTombstoneKeys(): Promise<Set<string>> {
  try {
    const snap = await getDocs(collection(db, 'tombstones'));
    return new Set(snap.docs.map(d => d.id));
  } catch {
    return new Set();
  }
}

/**
 * 2. Kaydı Firestore koleksiyonundan siler.
 */
export async function deleteRecordFromFirestore(
  moduleKey: string,
  id: string
): Promise<boolean> {
  const collectionName = MODULE_TO_COLLECTION_MAP[moduleKey] || moduleKey;
  const cleanId = String(id).trim();

  if (!cleanId) return false;

  try {
    const docRef = doc(db, collectionName, cleanId);
    await deleteDoc(docRef);
    await writeTombstone(collectionName, cleanId).catch(() => {});
    addDebugLog('STORAGE', 'INFO', `[Firestore] Kayıt silindi: ${collectionName}/${cleanId}`);
    return true;
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', `[Firestore] Kayıt silme hatası: ${collectionName}/${cleanId}`, { error });
    handleFirestoreError(error, OperationType.DELETE, `${collectionName}/${cleanId}`);
    return false;
  }
}

/**
 * 3. Referansı ve bağlı tüm modül kayıtlarını Firestore'dan temizler.
 */
export async function deleteReferenceFromFirestore(refId: string): Promise<boolean> {
  const cleanRefId = String(refId).trim();
  if (!cleanRefId) return false;

  try {
    // 1. Ana referans
    await deleteDoc(doc(db, 'references', cleanRefId));
    await writeTombstone('references', cleanRefId).catch(() => {});

    // 2. Bağlı modül kayıtları (yalnızca refId eşleşenler sorgulanır — tüm koleksiyon indirilmez)
    for (const col of ALL_DATA_COLLECTIONS) {
      if (col === 'references' || col === 'customFields' || col === 'ganttParcels' || col === 'feedbacks' || col === 'monthlyQualityReports') continue;
      try {
        const snap = await getDocs(query(collection(db, col), where('refId', '==', cleanRefId)));
        for (const d of snap.docs) {
          await deleteDoc(d.ref);
          await writeTombstone(col, d.id).catch(() => {});
        }
      } catch (err) {
        console.warn(`[Firestore] ${col} temizliği sırasında uyarı:`, err);
      }
    }

    addDebugLog('STORAGE', 'INFO', `[Firestore] Referans ve bağlı kayıtlar silindi: ${cleanRefId}`);
    return true;
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', `[Firestore] Referans silme hatası: ${cleanRefId}`, { error });
    handleFirestoreError(error, OperationType.DELETE, `references/${cleanRefId}`);
    return false;
  }
}

/**
 * 4. Tüm uygulama verilerini Firestore koleksiyonlarından okur.
 */
export async function fetchAllAppDataFromFirestore(): Promise<CentralAppData | null> {
  try {
    const appData: CentralAppData = {};

    await Promise.all(
      ALL_DATA_COLLECTIONS.map(async (colName) => {
        try {
          const colRef = collection(db, colName);
          const snapshot = await getDocs(colRef);
          const docs = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
          (appData as any)[colName] = docs;
        } catch (colErr) {
          console.warn(`[Firestore] ${colName} koleksiyonu okunamadı:`, colErr);
          (appData as any)[colName] = [];
        }
      })
    );

    appData.lastUpdated = new Date().toISOString();
    addDebugLog('STORAGE', 'INFO', '[Firestore] Tüm merkezi uygulama verisi Firestore bulutundan başarıyla yüklendi.');
    return appData;
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', '[Firestore] fetchAllAppDataFromFirestore genel okuma hatası', { error });
    try {
      handleFirestoreError(error, OperationType.GET, 'all_collections');
    } catch {}
    return null;
  }
}

/**
 * 5. Güvenli eşitleme:
 *  - Sunucu (Firestore) her zaman doğrudur; yerel kopya sunucudakini EZMEZ.
 *  - Yalnızca sunucuda HİÇ olmayan ve silinmemiş (tombstone yok) yerel kayıtlar yüklenir
 *    (ör. eski sürümde çevrimdışı girilmiş veriler).
 *  - Ardından sunucunun güncel hali döner.
 */
export async function syncAppDataWithFirestore(clientData: CentralAppData): Promise<CentralAppData | null> {
  if (!auth.currentUser) return null;
  try {
    // Gerçek zamanlı dinleyiciler yerel önbelleği zaten güncel tutar: önbellekten okumak
    // ücretsizdir ve günlük okuma kotasını (paylaşımlı kota: 50.000/gün) tüketmez.
    const current: CentralAppData = {};
    for (const colName of ALL_DATA_COLLECTIONS) {
      try {
        const snap = await getDocsFromCache(collection(db, colName));
        (current as any)[colName] = snap.docs.map(d => ({ ...d.data(), id: d.id }));
      } catch {
        (current as any)[colName] = [];
      }
    }

    // Sunucuda/önbellekte hiç olmayan yerel kayıtlar = aday
    const candidates: Array<{ colName: string; key: string; item: any }> = [];
    for (const colName of ALL_DATA_COLLECTIONS) {
      const clientItems: any[] = (clientData as any)[colName];
      if (!Array.isArray(clientItems) || clientItems.length === 0) continue;
      const known = new Set(((current as any)[colName] || []).map((d: any) => String(d.id)));
      for (const item of clientItems) {
        const key = String(item?.id || item?.refId || '').trim();
        if (key && !known.has(key)) candidates.push({ colName, key, item });
      }
    }
    if (candidates.length === 0) {
      current.lastUpdated = new Date().toISOString();
      return current;
    }

    // Aday varsa: silinmiş olanları ele, kalanları yükle
    const tombstones = await fetchTombstoneKeys();
    let batch = writeBatch(db);
    let ops = 0;
    let pushed = 0;
    for (const { colName, key, item } of candidates) {
      if (tombstones.has(`${colName}__${key}`)) continue;
      if (Array.isArray(item.photos) && item.photos.some((p: any) => typeof p === 'string' && p.startsWith('data:'))) {
        if (await saveRecordToFirestore(colName, item)) pushed++;
        continue;
      }
      batch.set(doc(db, colName, key), withAudit(item), { merge: true });
      ops++; pushed++;
      if (ops >= 400) {
        await batch.commit();
        batch = writeBatch(db); // commit sonrası YENİ batch (eski sürümdeki hata düzeltildi)
        ops = 0;
      }
    }
    if (ops > 0) await batch.commit();
    if (pushed > 0) addDebugLog('STORAGE', 'INFO', `[Firestore] Sunucuda olmayan ${pushed} yerel kayıt yüklendi.`);

    return await fetchAllAppDataFromFirestore();
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', '[Firestore] Eşitleme hatası', { error: String((error as any)?.message || error) });
    handleFirestoreError(error, OperationType.WRITE, 'sync');
    return null;
  }
}

/** Tüm operasyonel kayıtları siler (yalnızca yetkili kullanıcı; kurallar doğrular). */
export async function resetAllAppDataInFirestore(): Promise<boolean> {
  if (!auth.currentUser) return false;
  try {
    for (const colName of ALL_DATA_COLLECTIONS) {
      if (colName === 'customFields' || colName === 'ganttParcels' || colName === 'monthlyQualityReports') continue;
      const snap = await getDocs(collection(db, colName));
      let batch = writeBatch(db);
      let ops = 0;
      for (const d of snap.docs) {
        batch.delete(d.ref);
        batch.set(doc(db, 'tombstones', `${colName}__${d.id}`), {
          collection: colName, recordId: d.id, deletedBy: actor(), deletedAt: new Date().toISOString(), reason: 'RESET_ALL'
        });
        ops += 2;
        if (ops >= 400) { await batch.commit(); batch = writeBatch(db); ops = 0; }
      }
      if (ops > 0) await batch.commit();
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'reset_all');
    return false;
  }
}

// -------------------------------------------------------------
// USER MANAGEMENT & AUTH (FIRESTORE)
// -------------------------------------------------------------

/**
 * 6. Tüm kullanıcıları Firestore 'users' koleksiyonundan okur.
 */
export async function fetchUsersFromFirestore(): Promise<AppUser[] | null> {
  try {
    const usersCol = collection(db, 'users');
    const snapshot = await getDocs(usersCol);
    if (snapshot.empty) {
      return null;
    }
    const users = snapshot.docs.map(docSnap => ({
      ...docSnap.data(),
      id: docSnap.id
    } as AppUser));

    addDebugLog('AUTH', 'INFO', `[Firestore] ${users.length} kullanıcı Firestore'dan başarıyla yüklendi.`);
    return users;
  } catch (error) {
    addDebugLog('AUTH', 'WARN', '[Firestore] fetchUsersFromFirestore hatası, fallback devrede', { error });
    try {
      handleFirestoreError(error, OperationType.LIST, 'users');
    } catch {}
    return null;
  }
}

/**
 * 7. Kullanıcıyı Firestore 'users' koleksiyonuna kaydeder veya günceller.
 */
export async function saveUserToFirestore(user: AppUser): Promise<boolean> {
  if (!user || !user.id) return false;
  try {
    const userDocRef = doc(db, 'users', user.id);
    const cleanUser = {
      ...user,
      updatedAt: user.updatedAt || new Date().toISOString()
    };
    await setDoc(userDocRef, cleanUser, { merge: true });
    addDebugLog('AUTH', 'INFO', `[Firestore] Kullanıcı Firestore'a kaydedildi: ${user.fullName} (${user.id})`);
    return true;
  } catch (error) {
    addDebugLog('AUTH', 'ERROR', `[Firestore] Kullanıcı kaydetme hatası: ${user.id}`, { error });
    handleFirestoreError(error, OperationType.WRITE, `users/${user.id}`);
    return false;
  }
}

/**
 * 8. Kullanıcıyı Firestore'dan siler.
 */
export async function deleteUserFromFirestore(userId: string): Promise<boolean> {
  if (!userId) return false;
  try {
    const userDocRef = doc(db, 'users', userId);
    await deleteDoc(userDocRef);
    addDebugLog('AUTH', 'INFO', `[Firestore] Kullanıcı Firestore'dan silindi: ${userId}`);
    return true;
  } catch (error) {
    addDebugLog('AUTH', 'ERROR', `[Firestore] Kullanıcı silme hatası: ${userId}`, { error });
    handleFirestoreError(error, OperationType.DELETE, `users/${userId}`);
    return false;
  }
}

/**
 * 9. Aktivite denetim kaydını Firestore 'activityLogs' koleksiyonuna işler.
 */
export async function logActivityToFirestore(logItem: any): Promise<boolean> {
  if (!logItem || !logItem.id) return false;
  try {
    const logDocRef = doc(db, 'activityLogs', logItem.id);
    await setDoc(logDocRef, logItem);
    return true;
  } catch (error) {
    console.warn('[Firestore] Aktivite kaydı yazma uyarısı:', error);
    return false;
  }
}

/**
 * 10. Aylık kalite raporu özelleştirmelerini Firestore'a kaydeder.
 */
export async function saveMonthlyReportToFirestore(monthKey: string, reportData: any): Promise<boolean> {
  if (!monthKey) return false;
  try {
    const docRef = doc(db, 'monthlyQualityReports', monthKey);
    const cleanData = withAudit({
      ...reportData,
      id: monthKey,
      monthKey
    });
    await setDoc(docRef, cleanData, { merge: true });
    addDebugLog('STORAGE', 'INFO', `[Firestore] Aylık kalite raporu kaydedildi: ${monthKey}`);
    return true;
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', `[Firestore] Aylık kalite raporu kaydetme hatası: ${monthKey}`, { error });
    return false;
  }
}

/**
 * 11. Tüm veya tekil aylık kalite rapor verilerini Firestore'dan okur.
 */
export async function fetchMonthlyReportsFromFirestore(monthKey?: string): Promise<Record<string, any>> {
  try {
    if (monthKey) {
      const docRef = doc(db, 'monthlyQualityReports', monthKey);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { [monthKey]: docSnap.data() };
      }
      return {};
    }

    const colRef = collection(db, 'monthlyQualityReports');
    const snap = await getDocs(colRef);
    const result: Record<string, any> = {};
    snap.docs.forEach(d => {
      result[d.id] = d.data();
    });
    return result;
  } catch (error) {
    console.warn('[Firestore] fetchMonthlyReportsFromFirestore uyarısı:', error);
    return {};
  }
}

// =============================================================
// GERÇEK ZAMANLI DİNLEYİCİLER (onSnapshot) & SUNUCU ÖNBELLEK YÖNETİMİ
// =============================================================

/**
 * 12. Firestore 'users' koleksiyonu için CANLI (Real-Time) Dinleyici (onSnapshot)
 * Kullanıcı onay durumu (APPROVED / PASIF_READER) veya yetki değiştiğinde anında tetiklenir.
 */
export function subscribeToUsersOnSnapshot(
  onUpdate: (users: AppUser[]) => void,
  onError?: (error: any) => void
): Unsubscribe {
  const usersCol = collection(db, 'users');
  return onSnapshot(
    usersCol,
    (snapshot) => {
      const users = snapshot.docs.map(docSnap => ({
        ...docSnap.data(),
        id: docSnap.id
      } as AppUser));
      addDebugLog('AUTH', 'INFO', `[Firestore Realtime] ${users.length} kullanıcı canlı dinleyiciyle anında güncellendi.`);
      onUpdate(users);
    },
    (error) => {
      console.warn('[Firestore Realtime] users dinleme uyarısı:', error);
      if (onError) onError(error);
      try {
        handleFirestoreError(error, OperationType.LIST, 'users');
      } catch {}
    }
  );
}

/**
 * 13. Tüm operasyonel koleksiyonlar için CANLI (Real-Time) Dinleyici (onSnapshot)
 * Bir kalite testi, hasat kaydı veya stok verisi eklendiğinde/güncellendiğinde/silindiğinde
 * uygulama yenilenmeden anında arayüze yansır.
 */
export function subscribeToAllAppDataOnSnapshot(
  onUpdate: (data: Partial<CentralAppData>) => void,
  onError?: (error: any) => void
): Unsubscribe {
  const unsubscribes: Unsubscribe[] = [];
  const latestData: Partial<CentralAppData> = {};

  ALL_DATA_COLLECTIONS.forEach((colName) => {
    const colRef = collection(db, colName);
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const docs = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
        (latestData as any)[colName] = docs;
        latestData.lastUpdated = new Date().toISOString();
        onUpdate({ ...latestData });
      },
      (error) => {
        console.warn(`[Firestore Realtime] ${colName} dinleme uyarısı:`, error);
        if (onError) onError(error);
        try {
          handleFirestoreError(error, OperationType.LIST, colName);
        } catch {}
      }
    );
    unsubscribes.push(unsub);
  });

  return () => {
    unsubscribes.forEach(unsub => unsub());
  };
}

/**
 * 14. Yerel önbelleği (Cache) atlayıp doğrudan Firestore SUNUCUSUNDAN kullanıcı verilerini çeker.
 * (getDocsFromServer kullanarak silinen veya güncellenen kullanıcıların önbellekte kalmasını engeller, çevrimdışında getDocs'a düşer)
 */
export async function fetchUsersFromServer(): Promise<AppUser[] | null> {
  const usersCol = collection(db, 'users');
  try {
    const snapshot = await getDocsFromServer(usersCol);
    const users = snapshot.docs.map(docSnap => ({
      ...docSnap.data(),
      id: docSnap.id
    } as AppUser));

    addDebugLog('AUTH', 'INFO', `[Firestore Server] ${users.length} kullanıcı doğrudan sunucudan yüklendi.`);
    return users;
  } catch (error) {
    addDebugLog('AUTH', 'WARN', '[Firestore Server] Sunucuya erişilemedi, yerel önbellekten okunuyor...', { error });
    try {
      const cacheSnap = await getDocs(usersCol);
      return cacheSnap.docs.map(docSnap => ({
        ...docSnap.data(),
        id: docSnap.id
      } as AppUser));
    } catch {
      return null;
    }
  }
}

/**
 * 15. Yerel önbelleği (Cache) atlayıp doğrudan Firestore SUNUCUSUNDAN tüm operasyonel verileri çeker.
 * (Çevrimdışı / zaman aşımı durumunda getDocs önbelleğine düşer)
 */
export async function fetchAllAppDataFromServer(): Promise<CentralAppData | null> {
  try {
    const appData: CentralAppData = {};

    await Promise.all(
      ALL_DATA_COLLECTIONS.map(async (colName) => {
        const colRef = collection(db, colName);
        try {
          const snapshot = await getDocsFromServer(colRef);
          const docs = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
          (appData as any)[colName] = docs;
        } catch (colErr) {
          try {
            const cacheSnap = await getDocs(colRef);
            const docs = cacheSnap.docs.map(d => ({ ...d.data(), id: d.id }));
            (appData as any)[colName] = docs;
          } catch {
            (appData as any)[colName] = [];
          }
        }
      })
    );

    appData.lastUpdated = new Date().toISOString();
    addDebugLog('STORAGE', 'INFO', '[Firestore Server] Tüm merkezi veri yüklendi.');
    return appData;
  } catch (error) {
    addDebugLog('STORAGE', 'ERROR', '[Firestore Server] fetchAllAppDataFromServer okuma hatası', { error });
    return null;
  }
}
