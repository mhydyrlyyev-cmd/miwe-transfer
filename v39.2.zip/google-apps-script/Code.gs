/**
 * ============================================================
 * MIWE HIL — Google Sheets Raporlama Aynası (Mimari v2)
 * ------------------------------------------------------------
 * Yön: Firestore  ──►  Google Sheets   (TEK YÖNLÜ, salt okunur)
 *
 *  - Platformun tek doğruluk kaynağı Firestore'dur. Bu betik verileri
 *    oradan OKUR ve tabloları her 15 dakikada bir baştan yazar.
 *  - Tabloya elle yazılan veri platforma geri GİTMEZ (veri bütünlüğü).
 *  - Pivot tablolar için: PIVOT_DATA sayfasını kaynak seçin. Sütunları sabittir.
 *  - Web Uygulaması dağıtımı ve token GEREKMEZ.
 *
 * KURULUM (bir kez):
 *  1) Platformda okuma amaçlı bir hesap açın (Kayıt Ol), yönetici olarak onu
 *     "Pasif Okuyucu" yapın.
 *  2) Aşağıdaki KURULUM alanlarına o hesabın e-posta ve parolasını yazın.
 *  3) Üstteki fonksiyon listesinden  kurulum  seçip Çalıştır'a basın, izin verin.
 *  4) Başarılı olunca KURULUM alanlarını tekrar boşaltıp kaydedin
 *     (bilgiler Komut Dosyası Özellikleri'nde saklı kalır).
 * ============================================================
 */

const KURULUM = {
  BOT_EMAIL: '',   // örn: rapor.miwe@gmail.com
  BOT_SIFRE: ''    // kurulumdan sonra boşaltın
};

const CONFIG = {
  FIREBASE_API_KEY: 'AIzaSyCl33esIad92gCqHpycsN3mz4MAx1reahg',
  PROJECT_ID: 'deft-deployment-wz37z',
  DATABASE_ID: 'ai-studio-miwehil-ab67e39a-5877-4466-8fa5-923f4d888958',
  SPREADSHEET_ID: '',            // Uzantılar > Apps Script ile açtıysanız boş kalabilir
  TIMEZONE: 'Asia/Ashgabat',
  INTERVAL_MINUTES: 15,
  PIVOT_SHEET: 'PIVOT_DATA',
  STATUS_SHEET: '_DURUM',
  // Firestore koleksiyonu  →  [Sayfa adı, Modül anahtarı (PIVOT için)]
  COLLECTIONS: {
    references:          ['REFERENCES', ''],
    harvestRecords:      ['DAILY_HARVEST', 'HARVEST'],
    fieldRecords:        ['FIELD_RESPONSES', 'FIELD'],
    muzRecords:          ['MUZ_RESPONSES', 'MUZ'],
    bademRecords:        ['BADEM_RESPONSES', 'BADEM'],
    lojistikRecords:     ['LOJISTIK_RESPONSES', 'LOJISTIK'],
    ambarRecords:        ['AMBAR_RESPONSES', 'AMBAR'],
    freezeDryRecords:    ['FREEZE_DRY_RESPONSES', 'FREEZE_DRY'],
    exportSampleRecords: ['EXPORT_3G', 'EXPORT_SAMPLE'],
    salesRecords:        ['SALES_RESPONSES', 'SALES'],
    incidentRecords:     ['INCIDENT_RESPONSES', 'INCIDENT'],
    feedbacks:           ['FEEDBACK_SUGGESTIONS', ''],
    // v3.9.2: yeni koleksiyonlar
    locationProfiles:      ['LOKASYON_PROFILLERI', ''],
    monthlyQualityReports: ['AYLIK_KALITE_RAPORLARI', ''],
    ganttParcels:          ['PARSEL_PLANI', '']
  }
};

const PIVOT_HEADERS = [
  'Tarih', 'Yil', 'Ay', 'Hafta', 'Modul_Adi', 'Parti_No', 'Urun', 'Cesit', 'Lokasyon', 'Miktar_Kg',
  'Brix', 'Sertlik_kg_cm2', 'Nisasta_1_10', 'Streif_Indeksi_SI', 'Streif_Yorumu', 'Ozel_Test',
  'Ozel_Test_Deger', 'Ozel_Metrik1_Sayisal', 'Ozel_Metrik2_Sayisal', 'Ozel_Test_Yorum', 'Nitrat_mg_kg',
  'Nitrat_Uygunluk', 'Kusur_Orani_Pct', 'Renklenme_Pct', 'Kalite_Sinifi', 'Durum', 'Nihai_Kanal',
  'FreezeDry_Sevk', 'Risk_Seviyesi', 'Aksiyon', 'Operator', 'Gorsel_Durumu',
  // v2 ek sütunlar (sona eklendi; eski pivot tabloların sütun sırası bozulmaz)
  'Kayit_ID', 'Olusturan', 'Olusturma_Zamani', 'Son_Degistiren', 'Son_Degisiklik', 'Revizyon', 'Foto_Sayisi', 'Foto_URL'
];

const AUDIT_HEADERS = ['Olusturan', 'Olusturma_Zamani', 'Son_Degistiren', 'Son_Degisiklik', 'Revizyon'];
const AY_ADLARI = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const MAX_CELL = 45000;

// ============================================================
// Çalıştırılacak fonksiyonlar
// ============================================================

/** Bir kez çalıştırın: bilgileri kaydeder, bağlantıyı test eder, tabloları yazar, otomatik güncellemeyi açar. */
function kurulum() {
  const props = PropertiesService.getScriptProperties();
  if (KURULUM.BOT_EMAIL && KURULUM.BOT_SIFRE) {
    props.setProperty('BOT_EMAIL', KURULUM.BOT_EMAIL.trim().toLowerCase());
    props.setProperty('BOT_SIFRE', KURULUM.BOT_SIFRE);
  }
  if (!props.getProperty('BOT_EMAIL') || !props.getProperty('BOT_SIFRE')) {
    throw new Error('KURULUM alanlarına okuma hesabının e-posta ve parolasını yazıp tekrar çalıştırın.');
  }
  getSS().setSpreadsheetTimeZone(CONFIG.TIMEZONE);
  baglantiyiTestEt();
  tablolariGuncelle();
  otomatikGuncellemeyiAc();
  Logger.log('✓ Kurulum tamam. Şimdi KURULUM alanlarını boşaltıp kaydedin.');
}

/** Firestore'a erişimi dener ve sonucu günlüğe yazar. */
function baglantiyiTestEt() {
  const token = getIdToken_(true);
  const res = firestoreList_('references', token, 1);
  Logger.log('✓ Bağlantı başarılı. references örnek sayısı: ' + res.length);
  return true;
}

/** Tüm sayfaları Firestore'daki güncel veriyle baştan yazar. Tetikleyici bunu çağırır. */
function tablolariGuncelle() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) { Logger.log('Önceki güncelleme sürüyor, atlandı.'); return; }
  const started = new Date();
  const ss = getSS();
  const counts = [];
  try {
    const token = getIdToken_(false);
    const data = {};
    Object.keys(CONFIG.COLLECTIONS).forEach(function (col) {
      data[col] = firestoreList_(col, token);
    });

    // 1) Modül sayfaları (tüm alanlar, dinamik sütunlar)
    Object.keys(CONFIG.COLLECTIONS).forEach(function (col) {
      const sheetName = CONFIG.COLLECTIONS[col][0];
      const table = buildModuleTable_(data[col]);
      writeTable_(ss, sheetName, table.headers, table.rows);
      counts.push([sheetName, col, data[col].length]);
    });

    // 2) PIVOT_DATA (sabit sütunlar, tüm modüller tek tabloda)
    const refMap = {};
    (data.references || []).forEach(function (r) { if (r.refId) refMap[r.refId] = r; });
    const pivotRows = [];
    Object.keys(CONFIG.COLLECTIONS).forEach(function (col) {
      const moduleKey = CONFIG.COLLECTIONS[col][1];
      if (!moduleKey) return;
      data[col].forEach(function (rec) {
        const flat = flatSchema_(moduleKey, rec, refMap[rec.refId]);
        pivotRows.push(PIVOT_HEADERS.map(function (h) { return cell_(flat[h]); }));
      });
    });
    pivotRows.sort(function (a, b) { return (b[0] instanceof Date ? b[0].getTime() : 0) - (a[0] instanceof Date ? a[0].getTime() : 0); });
    writeTable_(ss, CONFIG.PIVOT_SHEET, PIVOT_HEADERS, pivotRows);
    counts.push([CONFIG.PIVOT_SHEET, 'tüm modüller', pivotRows.length]);

    // 3) v3.9.2: türetilmiş sayfalar (pivot dostu, satır başına bir olay)
    buildDerivedSheets_(ss, data, counts);

    writeStatus_(ss, started, counts, '');
  } catch (err) {
    writeStatus_(ss, started, counts, String(err && err.message ? err.message : err));
    throw err;
  } finally {
    lock.releaseLock();
  }
}

/** Her CONFIG.INTERVAL_MINUTES dakikada bir otomatik güncellemeyi açar (tekrar çalıştırmak güvenlidir). */
function otomatikGuncellemeyiAc() {
  otomatikGuncellemeyiKapat();
  ScriptApp.newTrigger('tablolariGuncelle').timeBased().everyMinutes(CONFIG.INTERVAL_MINUTES).create();
  Logger.log('✓ Otomatik güncelleme açıldı: her ' + CONFIG.INTERVAL_MINUTES + ' dakikada bir.');
}

function otomatikGuncellemeyiKapat() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'tablolariGuncelle') ScriptApp.deleteTrigger(t);
  });
}

/** E-tabloda "MIWE HIL" menüsü (elle güncelleme için). */
function onOpen() {
  try {
    SpreadsheetApp.getUi().createMenu('MIWE HIL')
      .addItem('Şimdi güncelle', 'tablolariGuncelle')
      .addItem('Bağlantıyı test et', 'baglantiyiTestEt')
      .addToUi();
  } catch (e) {}
}

// ============================================================
// Eski uygulama sürümleriyle uyumluluk (yazma YOK)
// ============================================================
function doGet() {
  return json_({ success: true, status: 'ok', mode: 'FIRESTORE_MIRROR', message: 'Tablo Firestore’dan otomatik güncellenir.', lastSync: PropertiesService.getScriptProperties().getProperty('LAST_SYNC') || null });
}
function doPost() {
  // Eski istemcilerin kuyruğu boşalsın diye başarı döner; hiçbir şey yazılmaz.
  return json_({ success: true, ignored: true, message: 'v2: veriler Firestore’dan okunur, POST yok sayıldı.' });
}

// ============================================================
// Firebase erişimi (salt okunur hesap, güvenlik kuralları geçerli)
// ============================================================
function getIdToken_(forceNew) {
  const cache = CacheService.getScriptCache();
  if (!forceNew) {
    const cached = cache.get('ID_TOKEN');
    if (cached) return cached;
  }
  const props = PropertiesService.getScriptProperties();
  const email = props.getProperty('BOT_EMAIL');
  const pass = props.getProperty('BOT_SIFRE');
  if (!email || !pass) throw new Error('Okuma hesabı tanımlı değil. kurulum() fonksiyonunu çalıştırın.');

  const res = UrlFetchApp.fetch(
    'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + CONFIG.FIREBASE_API_KEY,
    { method: 'post', contentType: 'application/json', muteHttpExceptions: true,
      payload: JSON.stringify({ email: email, password: pass, returnSecureToken: true }) }
  );
  const body = JSON.parse(res.getContentText() || '{}');
  if (res.getResponseCode() !== 200 || !body.idToken) {
    const msg = (body.error && body.error.message) || ('HTTP ' + res.getResponseCode());
    if (/INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND/.test(msg)) throw new Error('Okuma hesabının e-postası veya parolası hatalı.');
    if (/REFERER|API_KEY/.test(msg)) throw new Error('Firebase API anahtarı bu isteğe izin vermiyor (anahtar kısıtlaması): ' + msg);
    throw new Error('Firebase girişi başarısız: ' + msg);
  }
  cache.put('ID_TOKEN', body.idToken, 50 * 60); // token 60 dk geçerli
  return body.idToken;
}

function firestoreList_(collection, token, maxDocs) {
  const base = 'https://firestore.googleapis.com/v1/projects/' + CONFIG.PROJECT_ID +
    '/databases/' + encodeURIComponent(CONFIG.DATABASE_ID) + '/documents/' + collection;
  const out = [];
  let pageToken = '';
  do {
    const url = base + '?pageSize=' + (maxDocs || 300) + (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : '');
    const res = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + token }, muteHttpExceptions: true });
    const code = res.getResponseCode();
    const body = JSON.parse(res.getContentText() || '{}');
    if (code === 403) throw new Error('Erişim reddedildi (' + collection + '). Okuma hesabı yönetici tarafından onaylanmış ve "Pasif Okuyucu" olmalı.');
    if (code !== 200) throw new Error('Firestore okuma hatası (' + collection + '): ' + ((body.error && body.error.message) || code));
    (body.documents || []).forEach(function (d) {
      const obj = fsFields_(d.fields || {});
      obj.__docId = d.name.split('/').pop();
      obj.__updateTime = d.updateTime ? new Date(d.updateTime) : '';
      out.push(obj);
    });
    pageToken = body.nextPageToken || '';
    if (maxDocs && out.length >= maxDocs) break;
  } while (pageToken);
  return out;
}

function fsFields_(fields) {
  const o = {};
  Object.keys(fields).forEach(function (k) { o[k] = fsValue_(fields[k]); });
  return o;
}

function fsValue_(v) {
  if (v == null) return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('booleanValue' in v) return v.booleanValue;
  if ('nullValue' in v) return null;
  if ('timestampValue' in v) return new Date(v.timestampValue);
  if ('mapValue' in v) return fsFields_((v.mapValue && v.mapValue.fields) || {});
  if ('arrayValue' in v) return ((v.arrayValue && v.arrayValue.values) || []).map(fsValue_);
  if ('referenceValue' in v) return v.referenceValue;
  if ('geoPointValue' in v) return v.geoPointValue.latitude + ',' + v.geoPointValue.longitude;
  return '';
}

// ============================================================
// Tablo oluşturma
// ============================================================
function auditCols_(rec) {
  const a = rec._audit || {};
  const who = function (p) { return p ? (p.name || p.email || p.uid || '') : ''; };
  return {
    Olusturan: who(a.createdBy),
    Olusturma_Zamani: toDate_(a.createdAt) || '',
    Son_Degistiren: who(a.updatedBy),
    Son_Degisiklik: a.serverUpdatedAt instanceof Date ? a.serverUpdatedAt : (toDate_(a.updatedAtIso) || rec.__updateTime || ''),
    Revizyon: typeof a.revision === 'number' ? a.revision : ''
  };
}

function buildModuleTable_(records) {
  const keySet = {};
  const flats = records.map(function (rec) {
    const f = {};
    flatten_(rec, '', f, 0);
    const audit = auditCols_(rec);
    AUDIT_HEADERS.forEach(function (h) { f[h] = audit[h]; });
    Object.keys(f).forEach(function (k) { keySet[k] = true; });
    return f;
  });
  const first = ['refId', 'id'].filter(function (k) { return keySet[k]; });
  const rest = Object.keys(keySet)
    .filter(function (k) { return first.indexOf(k) < 0 && AUDIT_HEADERS.indexOf(k) < 0; })
    .sort();
  const headers = first.concat(AUDIT_HEADERS, rest);
  const rows = flats.map(function (f) { return headers.map(function (h) { return cell_(f[h]); }); });
  return { headers: headers, rows: rows };
}

function flatten_(obj, prefix, out, depth) {
  Object.keys(obj).forEach(function (key) {
    if (key === '_audit' || key === '__docId' || key === '__updateTime') return;
    const val = obj[key];
    const k = prefix ? prefix + '.' + key : key;
    if (val instanceof Date) { out[k] = val; return; }
    if (Array.isArray(val)) {
      if (key === 'photos') { out[k] = photoUrls_(val).join('\n'); return; }
      const allPrim = val.every(function (x) { return x == null || typeof x !== 'object'; });
      out[k] = allPrim ? val.map(cleanStr_).join(', ') : JSON.stringify(val);
      return;
    }
    if (val && typeof val === 'object') {
      if (depth < 2) flatten_(val, k, out, depth + 1); else out[k] = JSON.stringify(val);
      return;
    }
    out[k] = typeof val === 'string' ? cleanStr_(val) : val;
  });
  if (!prefix && !('id' in out) && obj.__docId) out.id = obj.__docId;
}

function photoUrls_(arr) {
  return (arr || []).filter(function (p) { return typeof p === 'string' && p.indexOf('http') === 0; });
}

function cleanStr_(s) {
  if (typeof s !== 'string') return s;
  if (s.indexOf('data:') === 0) return '[gömülü fotoğraf]';
  return s;
}

function cell_(v) {
  if (v === undefined || v === null) return '';
  if (v instanceof Date) return isNaN(v.getTime()) ? '' : v;
  if (typeof v === 'boolean') return v ? 'EVET' : 'HAYIR';
  if (typeof v === 'object') v = JSON.stringify(v);
  if (typeof v === 'string' && v.length > MAX_CELL) return v.slice(0, MAX_CELL) + '…';
  return v;
}

function toDate_(s) {
  if (!s) return null;
  if (s instanceof Date) return s;
  // Yalnız tarih ('2026-11-02') yerel gün olarak okunur; saat dilimi kayması olmaz
  const m = typeof s === 'string' && s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function isoWeek_(d) {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dayNum = date.getDay() || 7;
  date.setDate(date.getDate() + 4 - dayNum);
  const yearStart = new Date(date.getFullYear(), 0, 1);
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

function num_(v) {
  if (v === undefined || v === null || v === '') return '';
  const n = Number(v);
  return isNaN(n) ? '' : n;
}

/** Platformdaki generateFlatSchema ile aynı mantık (PIVOT_DATA sütunları). */
function flatSchema_(moduleKey, record, ref) {
  ref = ref || {};
  const rawDate = record.timestamp || record.recordDate || record.date || record.processDate || record.shipmentDate ||
    record.acceptanceDate || record.salesDate || record.incidentDate || record.harvestDate || ref.createdAt || record.createdAt || '';
  const date = toDate_(rawDate) || (record.__updateTime instanceof Date ? record.__updateTime : new Date());
  const yyyy = date.getFullYear();
  const mm = ('0' + (date.getMonth() + 1)).slice(-2);
  const product = String(record.product || ref.product || '').split('(')[0].trim() || 'Genel';

  let brix = '', firmness = '', starch = '', streif = '', streifInterp = '', specialTest = '', specialVal = '';
  let m1 = '', m2 = '', specialInterp = '', nitrate = '', nitratePass = '', defect = '', color = '';
  let status = record.decision || record.testStatus || record.status || record.qualityGrade || 'ONAY';
  let risk = 'DÜŞÜK';

  const qtyField = { HARVEST: 'dailyTotalKg', MUZ: 'netWeightKg', AMBAR: 'acceptedWeightKg', SALES: 'totalQuantityKg',
    LOJISTIK: 'weightKg', BADEM: 'totalLoadKg', FREEZE_DRY: 'rawWeightKg', INCIDENT: 'affectedQuantityKg' }[moduleKey];
  const qtyRaw = qtyField ? record[qtyField] : (record.quantity != null ? record.quantity : record.totalWeightKg);
  const qty = Number(qtyRaw != null ? qtyRaw : (ref.quantity || 0)) || 0;

  let channel = '';
  if (moduleKey === 'FIELD' || moduleKey === 'HARVEST') {
    channel = record.finalProductStatus || (record.reroutedToFreezeDry ? 'FREEZE_DRY' : 'TAZE_SATIS');
  } else {
    channel = record.finalProductStatus || record.destination || '';
  }
  const rerouted = (record.reroutedToFreezeDry || channel === 'FREEZE_DRY') ? 'EVET' : 'HAYIR';

  if (moduleKey === 'FIELD' || moduleKey === 'HARVEST') {
    brix = num_(record.avgBrix);
    firmness = record.avgHardness !== undefined ? num_(record.avgHardness) : num_(record.avgFirmness);
    starch = num_(record.starchIndex);
    streif = num_(record.streifIndex);
    streifInterp = record.streifInterpretation || '';
    const sc = record.specialCropTest;
    if (sc) {
      specialTest = sc.cropNameTr || sc.cropType || '';
      specialVal = (sc.metric1Name || '') + ': ' + (sc.metric1Value != null ? sc.metric1Value : '') + ' ' + (sc.metric1Unit || '');
      if (sc.metric2Name) specialVal += ' | ' + sc.metric2Name + ': ' + (sc.metric2Value != null ? sc.metric2Value : '') + ' ' + (sc.metric2Unit || '');
      m1 = num_(sc.metric1Value);
      m2 = num_(sc.metric2Value);
      specialInterp = sc.interpretation || '';
    }
    nitrate = num_(record.nitrateMgKg);
    nitratePass = record.nitratePass === false ? 'LIMIT_USTU' : (record.nitratePass ? 'UYGUN' : '');
    defect = num_(record.defectPercent);
    color = num_(record.colorationPercent);
    risk = (Number(defect) > 5 || record.nitratePass === false || (typeof streif === 'number' && streif < 0.07)) ? 'YÜKSEK' : 'DÜŞÜK';
    if (record.decision && String(record.decision).toLowerCase().indexOf('red') >= 0) status = 'RED';
  } else if (moduleKey === 'MUZ') {
    const b3 = record.banana3PointBrix || {};
    brix = num_(record.avgBrix != null ? record.avgBrix : (record.brix != null ? record.brix : b3.avg3Point));
    firmness = num_(record.pulpFirmness);
    specialTest = 'Muz Kurdele & Olgunluk';
    specialVal = (record.ribbonColor || '') + ' (' + (record.ripenessScale || 1) + '/7)';
    m1 = num_(record.ripenessScale);
    m2 = num_(record.calibrationMm);
    specialInterp = 'Olgunluk: ' + (record.ripenessScale || 1) + '/7, Kalibrasyon: ' + (record.calibrationMm || '-') + ' mm';
    status = record.qualityStatus || record.status || 'ONAY';
  } else if (moduleKey === 'BADEM') {
    specialTest = 'Badem Randıman %';
    m1 = num_(record.kernelYieldPercent);
    m2 = num_(record.moisturePercent);
    specialVal = m1 !== '' ? '%' + m1 : '';
    specialInterp = 'Randıman %' + m1 + ', Nem %' + m2;
    defect = num_(record.totalDefectPercent);
    status = record.testStatus || record.status || 'ONAY';
  } else if (moduleKey === 'INCIDENT') {
    const p = record.priority;
    risk = p === 'CRITICAL' ? 'KRİTİK' : (p === 'HIGH' ? 'YÜKSEK' : (p === 'MEDIUM' ? 'ORTA' : 'DÜŞÜK'));
    status = record.status || 'OPEN';
  } else if (moduleKey === 'EXPORT_SAMPLE') {
    status = record.shelfLifeDecision || record.status || 'COMPLIANT';
    brix = num_(record.avgBrix);
    firmness = num_(record.avgHardness);
  }

  const photos = photoUrls_(record.photos);
  const hasPhoto = (Array.isArray(record.photos) && record.photos.length > 0) || (Array.isArray(record.photoIds) && record.photoIds.length > 0);
  const audit = auditCols_(record);

  return {
    Tarih: new Date(yyyy, date.getMonth(), date.getDate()),
    Yil: yyyy,
    Ay: mm + ' - ' + AY_ADLARI[date.getMonth()],
    Hafta: 'H-' + isoWeek_(date),
    Modul_Adi: moduleKey,
    Parti_No: record.refId || ref.refId || '',
    Urun: product,
    Cesit: record.variety || record.sortVariety || ref.variety || '',
    Lokasyon: record.location || record.orchard || ref.location || '',
    Miktar_Kg: qty,
    Brix: brix,
    Sertlik_kg_cm2: firmness,
    Nisasta_1_10: starch,
    Streif_Indeksi_SI: streif,
    Streif_Yorumu: streifInterp,
    Ozel_Test: specialTest,
    Ozel_Test_Deger: specialVal,
    Ozel_Metrik1_Sayisal: m1,
    Ozel_Metrik2_Sayisal: m2,
    Ozel_Test_Yorum: specialInterp,
    Nitrat_mg_kg: nitrate,
    Nitrat_Uygunluk: nitratePass,
    Kusur_Orani_Pct: defect,
    Renklenme_Pct: color,
    Kalite_Sinifi: record.classification || record.kaliteSinifi || record.qualityGrade || 'Standart',
    Durum: status,
    Nihai_Kanal: channel,
    FreezeDry_Sevk: rerouted,
    Risk_Seviyesi: risk,
    Aksiyon: record.nextStep || record.action || '',
    Operator: record.operator || ref.operator || '',
    Gorsel_Durumu: hasPhoto ? 'Mevcut' : 'Yok',
    Kayit_ID: record.id || record.__docId || '',
    Olusturan: audit.Olusturan,
    Olusturma_Zamani: audit.Olusturma_Zamani,
    Son_Degistiren: audit.Son_Degistiren,
    Son_Degisiklik: audit.Son_Degisiklik,
    Revizyon: audit.Revizyon,
    Foto_Sayisi: Array.isArray(record.photos) ? record.photos.length : 0,
    Foto_URL: photos.join('\n')
  };
}

// ============================================================
// Sayfa yazma
// ============================================================
function getSS() {
  if (CONFIG.SPREADSHEET_ID) return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Betiği E-Tablo içinden (Uzantılar > Apps Script) açın veya CONFIG.SPREADSHEET_ID girin.');
  return ss;
}

function writeTable_(ss, name, headers, rows) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  const nRows = rows.length + 1;
  const nCols = Math.max(headers.length, 1);
  if (sh.getMaxColumns() < nCols) sh.insertColumnsAfter(sh.getMaxColumns(), nCols - sh.getMaxColumns());
  if (sh.getMaxRows() < nRows) sh.insertRowsAfter(sh.getMaxRows(), nRows - sh.getMaxRows());
  sh.clearContents();
  sh.getRange(1, 1, 1, nCols).setValues([headers])
    .setBackground('#0f172a').setFontColor('#38bdf8').setFontWeight('bold');
  if (rows.length) sh.getRange(2, 1, rows.length, nCols).setValues(rows);
  sh.setFrozenRows(1);
}

function writeStatus_(ss, started, counts, error) {
  const finished = new Date();
  const rows = [
    ['Son güncelleme', finished],
    ['Süre (sn)', Math.round((finished - started) / 1000)],
    ['Durum', error ? 'HATA' : 'BAŞARILI'],
    ['Hata', error || '-'],
    ['Kaynak', 'Firestore → ' + CONFIG.DATABASE_ID],
    ['', ''],
    ['Sayfa', 'Kayıt sayısı']
  ].concat(counts.map(function (c) { return [c[0], c[2]]; }));
  let sh = ss.getSheetByName(CONFIG.STATUS_SHEET);
  if (!sh) sh = ss.insertSheet(CONFIG.STATUS_SHEET, 0);
  sh.clearContents();
  sh.getRange(1, 1, rows.length, 2).setValues(rows);
  sh.getRange(1, 1, rows.length, 1).setFontWeight('bold');
  if (!error) PropertiesService.getScriptProperties().setProperty('LAST_SYNC', finished.toISOString());
}

// ============================================================
// v3.9.2 — Türetilmiş sayfalar: ON_SOGUTMA, DEPO_KONTROLLERI, DURUM_GECMISI, TESTLER
// Referansın içindeki listeler tek hücreye sıkışmasın; her olay ayrı satır olur.
// ============================================================
function toDate_(v) {
  if (!v) return '';
  if (v instanceof Date) return v;
  const d = new Date(v);
  return isNaN(d.getTime()) ? String(v) : d;
}
function arr_(v) { return Array.isArray(v) ? v : []; }

function buildDerivedSheets_(ss, data, counts) {
  const refs = data.references || [];
  const refMap = {};
  refs.forEach(function (r) { if (r.refId) refMap[r.refId] = r; });

  // ON_SOGUTMA — her ön soğutma fişi bir satır
  const H1 = ['RefID', 'Urun', 'Cesit', 'Lokasyon', 'Fis_No', 'Tarih', 'Sorumlu', 'Yer', 'Tunel', 'Net_Kg',
    'Hasat_Saati', 'Giris', 'Cikis', 'Sure_Saat', 'Pulp_Once_C', 'Pulp_Sonra_C', 'Hedef_C',
    '1MCP', '1MCP_Plan', '1MCP_Uygulandi', 'Sonra', 'Hedef_Depo', 'Hedef_Oda', 'Paket_Kg', 'Iskarta_Kg', 'Not'];
  const r1 = [];
  refs.forEach(function (r) {
    arr_(r.precoolingSlips).forEach(function (s) {
      const a = toDate_(s.startAt), b = toDate_(s.endAt);
      const hrs = (a instanceof Date && b instanceof Date) ? Math.round((b - a) / 36e5 * 10) / 10 : '';
      r1.push([r.refId, r.product, r.variety, r.location || r.orchard, s.slipNo, toDate_(s.date), s.inspector,
        s.site === 'CENTER' ? 'Merkez' : (s.site === 'ORCHARD' ? 'Bahçe' : ''), s.tunnel, s.netKg,
        toDate_(s.harvestedAt), a, b, hrs, s.pulpBeforeC, s.pulpAfterC, s.setpointC,
        s.mcpDecision === 'YES' ? 'EVET' : (s.mcpDecision === 'NO' ? 'HAYIR' : ''), toDate_(s.mcpPlannedAt), toDate_(s.mcpAppliedAt),
        s.afterPrecool === 'MOVE' ? 'Taşınır' : (s.afterPrecool === 'STAY' ? 'Kalır' : ''), s.targetWarehouse, s.targetRoom,
        s.packedKg, s.culledKg, s.note].map(cell_));
    });
  });
  writeTable_(ss, 'ON_SOGUTMA', H1, r1);
  counts.push(['ON_SOGUTMA', 'references.precoolingSlips', r1.length]);

  // DEPO_KONTROLLERI — her depo kontrolü bir satır
  const H2 = ['RefID', 'Urun', 'Cesit', 'Depo', 'Oda', 'Atmosfer', 'Zaman', 'Kontrol_Eden', 'Oda_C', 'Ayar_C', 'Nem_Pct',
    'Pulp_C', 'Sertlik', 'Brix', 'Curuk_Pct', 'O2_Pct', 'CO2_Pct', 'Havalandirma', 'Zemin_Islatma', 'Not'];
  const r2 = [];
  arr_(data.ambarRecords).forEach(function (a) {
    const ref = refMap[a.refId] || {};
    arr_(a.storageChecks).forEach(function (c) {
      r2.push([a.refId, a.product || ref.product, a.variety || ref.variety, a.warehouse || a.warehouseName, a.room || a.roomNo,
        a.atmosphere, toDate_(c.at), c.inspector, c.roomTemperatureC, c.setpointC, c.humidityPercent, c.pulpTemperatureC,
        c.firmness, c.brix, c.rotPercent, c.o2Percent, c.co2Percent, c.ventilated, c.floorWet, c.note].map(cell_));
    });
  });
  writeTable_(ss, 'DEPO_KONTROLLERI', H2, r2);
  counts.push(['DEPO_KONTROLLERI', 'ambarRecords.storageChecks', r2.length]);

  // DURUM_GECMISI — her durum değişikliği bir satır
  const H3 = ['RefID', 'Urun', 'Zaman', 'Onceki', 'Yeni', 'Islem', 'Kim', 'Not'];
  const r3 = [];
  refs.forEach(function (r) {
    arr_(r.statusHistory).forEach(function (h) {
      r3.push([r.refId, r.product, toDate_(h.at), h.from, h.to, h.module, h.by, h.note].map(cell_));
    });
  });
  r3.sort(function (a, b) { return (b[2] instanceof Date ? b[2].getTime() : 0) - (a[2] instanceof Date ? a[2].getTime() : 0); });
  writeTable_(ss, 'DURUM_GECMISI', H3, r3);
  counts.push(['DURUM_GECMISI', 'references.statusHistory', r3.length]);

  // TESTLER — test numarası ↔ kapsadığı partiler
  const H4 = ['Test_RefID', 'Urun', 'Cesit', 'Lokasyon', 'Tarih', 'Durum', 'Kapsanan_Parti', 'Parti_Urun', 'Parti_Tarih'];
  const r4 = [];
  const covered = {};
  refs.forEach(function (r) {
    arr_(r.linkedTestRefIds).forEach(function (t) { (covered[t] = covered[t] || []).push(r); });
  });
  refs.filter(function (r) { return r.refKind === 'TEST'; }).forEach(function (t) {
    const lots = covered[t.refId] || [];
    if (!lots.length) {
      r4.push([t.refId, t.product, t.variety, t.location || t.orchard, toDate_(t.createdAt), t.status, '', '', ''].map(cell_));
    }
    lots.forEach(function (l) {
      r4.push([t.refId, t.product, t.variety, t.location || t.orchard, toDate_(t.createdAt), t.status,
        l.refId, l.product, toDate_(l.createdAt)].map(cell_));
    });
  });
  writeTable_(ss, 'TESTLER', H4, r4);
  counts.push(['TESTLER', 'references (TEST)', r4.length]);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
