# v39.2 — QR 1. bölüm + Google Sheets aynası güncellemesi

Uygulama sırası: v39 → v39.1 → v39.2. Dosyaları AYNEN (byte-identical) kopyala.
Firestore kuralı DEĞİŞMEDİ (DeployRules GEREKMEZ).

## A) Platform (AI Studio'ya uygulanır)
1. Yeni etiketlerde QR içeriği platform linki: `https://<site>/?ref=<RefID>`. Telefon kamerası okutunca platform açılır.
   QR artık cihazda üretilir (eski dış servis api.qrserver.com kaldırıldı; çevrimdışı da çalışır).
2. Tarayıcı üç biçimi tanır: link · eski JSON etiket · düz RefID. Basılmış eski etiketler çalışmaya devam eder.
   Arama önce birebir RefID eşleşmesine bakar, sonra kısmi aramaya.
3. Personel QR okutunca işlem menüsü açılır: Referans kartı · Ön soğutma · Depo/sevk kabul · Sevk · Test · Akt.
   Kabul, sevk, test ve akt formları RefID dolu açılır.
4. Link giriş yapmadan açılırsa: önce giriş sayfası, girişten ve veriler yüklendikten sonra aynı referansın menüsü açılır.
   Link adres çubuğundan temizlenir.

Dosyalar:
- src/utils/qrRef.ts (YENİ) — link üretimi, tarama çözümleyici, ?ref= yakalama
- src/components/qr/QrActionSheet.tsx (YENİ) — işlem menüsü
- src/components/modals/QrCodeModal.tsx — yerel QR (qrcode paketi, zaten yüklü), link içeriği
- src/components/Header.tsx — tarayıcı sonucu onScanRef'e gider
- src/App.tsx — findRefByText, handleScanRef, handleQrAction, ?ref= bekleyen referans, QrActionSheet render

## B) Google Sheets (AI Studio'ya DEĞİL, Apps Script editörüne yapıştırılır)
- google-apps-script/Code.gs — yeni sayfalar:
  LOKASYON_PROFILLERI, AYLIK_KALITE_RAPORLARI, PARSEL_PLANI (koleksiyon aynası)
  ON_SOGUTMA (her fiş bir satır, süre saat hesaplı), DEPO_KONTROLLERI (her kontrol bir satır: oda °C, nem, O₂/CO₂…),
  DURUM_GECMISI (her durum değişikliği bir satır), TESTLER (test numarası ↔ kapsanan partiler)
- Tek yön (Firestore → Sheets) ve salt okunur hesap aynen korunur. KURULUM alanlarına parola YAZMAYIN
  (bilgiler Komut Dosyası Özellikleri'nde duruyor).

## Kabul testleri
1. Referanslar → bir partinin QR etiketi: QR görünür; telefon kamerasıyla okutunca `…/?ref=RefID` linki çıkar.
2. Üstteki QR tarayıcıyla aynı etiketi okut → işlem menüsü açılır; RefID, ürün, çeşit, yer ve durum doğru.
3. Menüden "Depo / sevk kabul" → Ambar formu bu RefID seçili açılır. "Test" → Saha testi RefID dolu açılır.
4. Düz RefID yazılı eski bir etiket veya elle yazılmış RefID ile de menü açılır.
5. Çıkış yapıp `…/?ref=<var olan RefID>` linkini aç → giriş sayfası; giriş sonrası menü kendiliğinden açılır.
6. Var olmayan RefID → "Referans Bulunamadı" uyarısı.
7. TypeScript derleme hatası yok.
