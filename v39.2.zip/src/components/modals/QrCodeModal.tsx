import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { buildRefQrUrl } from '../../utils/qrRef';
import { X, QrCode, Printer, Download, Warehouse, Package, MapPin, Calendar, CheckCircle2 } from 'lucide-react';
import { ReferenceItem } from '../../types';

interface QrCodeModalProps {
  reference: ReferenceItem | null;
  onClose: () => void;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ reference, onClose }) => {
  // v3.9.2: QR cihazda üretilir (dış servis yok, çevrimdışı çalışır) ve platform linki taşır.
  const [qrUrl, setQrUrl] = useState<string>('');
  const refId = reference?.refId || '';
  useEffect(() => {
    if (!refId) return;
    QRCode.toDataURL(buildRefQrUrl(refId), { width: 500, margin: 1, errorCorrectionLevel: 'M' })
      .then(setQrUrl)
      .catch(() => setQrUrl(''));
  }, [refId]);

  if (!reference) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = `QR_${reference.refId}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden text-slate-900 dark:text-white flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base tracking-tight">
                Ambar Giriş &amp; Stok QR Etiketi
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                {reference.refId}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Content */}
        <div className="p-5 space-y-4 text-center print:p-0">
          
          {/* QR Code Container */}
          <div className="p-4 bg-white border border-slate-200 rounded-2xl inline-block shadow-sm">
            <img
              src={qrUrl}
              alt={`QR Code ${reference.refId}`}
              className="w-48 h-48 mx-auto object-contain"
            />
            <p className="font-mono font-black text-sm text-slate-900 mt-2 tracking-wider">
              {reference.refId}
            </p>
          </div>

          {/* Product Details Grid */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800 text-left space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-800">
              <span className="text-slate-500 flex items-center gap-1">
                <Package className="w-3.5 h-3.5 text-teal-600" /> Ürün &amp; Çeşit:
              </span>
              <strong className="text-slate-900 dark:text-white font-extrabold">
                {reference.product} {reference.variety ? `(${reference.variety})` : ''}
              </strong>
            </div>

            <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-800">
              <span className="text-slate-500 flex items-center gap-1">
                <Warehouse className="w-3.5 h-3.5 text-emerald-600" /> Miktar:
              </span>
              <strong className="text-emerald-700 dark:text-emerald-400 font-extrabold">
                {reference.quantity} {reference.unit}
              </strong>
            </div>

            <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-800">
              <span className="text-slate-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-amber-600" /> Lokasyon &amp; Hedef:
              </span>
              <strong className="text-slate-800 dark:text-slate-200">
                {reference.location} → {reference.destination}
              </strong>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" /> Tarih / Operatör:
              </span>
              <strong className="text-slate-700 dark:text-slate-300">
                {new Date(reference.createdAt).toLocaleDateString('tr-TR')} ({reference.operator})
              </strong>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Depo ambar kabulü için okutulmaya hazır standart QR etiket.
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleDownload}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>İndir</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-600 hover:bg-teal-500 text-white shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Yazdır / Etiket Çıkar</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 text-white hover:bg-slate-700 transition cursor-pointer"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
