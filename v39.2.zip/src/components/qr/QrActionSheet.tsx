import React from 'react';
import { X, FileSearch, Warehouse, Truck, FlaskConical, ShieldAlert, Snowflake, QrCode } from 'lucide-react';
import { ReferenceItem } from '../../types';
import { getStatusConfig } from '../../utils/statusStyles';

/**
 * v3.9.2 — QR okutulunca açılan işlem menüsü (yalnız giriş yapmış personel).
 * Her işlem mevcut formu RefID dolu açar.
 */
export type QrAction = 'CARD' | 'RECEIVE' | 'DISPATCH' | 'TEST' | 'INCIDENT' | 'PRECOOL';

interface Props {
  reference: ReferenceItem;
  onAction: (action: QrAction, ref: ReferenceItem) => void;
  onClose: () => void;
}

const ACTIONS: { key: QrAction; label: string; hint: string; Icon: React.ElementType; tone: string }[] = [
  { key: 'CARD', label: 'Referans kartı', hint: 'Geçmiş, testler, soğuk zincir', Icon: FileSearch, tone: 'text-slate-700 bg-slate-100' },
  { key: 'PRECOOL', label: 'Ön soğutma', hint: 'Fiş ve süre', Icon: Snowflake, tone: 'text-sky-700 bg-sky-50' },
  { key: 'RECEIVE', label: 'Depo / sevk kabul', hint: 'Gelen yükü kabul et', Icon: Warehouse, tone: 'text-indigo-700 bg-indigo-50' },
  { key: 'DISPATCH', label: 'Sevk', hint: 'Araca yükle', Icon: Truck, tone: 'text-amber-800 bg-amber-50' },
  { key: 'TEST', label: 'Test', hint: 'Kalite ölçümü ekle', Icon: FlaskConical, tone: 'text-violet-700 bg-violet-50' },
  { key: 'INCIDENT', label: 'Akt / olay', hint: 'Hasar, sapma, şikâyet', Icon: ShieldAlert, tone: 'text-rose-700 bg-rose-50' },
];

export const QrActionSheet: React.FC<Props> = ({ reference, onAction, onClose }) => {
  const r = reference as any;
  const place = r.location || r.orchard || r.greenhouse || '';
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 pb-7 sm:pb-5"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="QR işlem menüsü"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <span className="shrink-0 w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center"><QrCode className="w-6 h-6" /></span>
            <div className="min-w-0">
              <div className="font-mono text-sm font-bold text-slate-900 dark:text-white break-all">{reference.refId}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {[r.product, r.variety, place].filter(Boolean).join(' · ')}
              </div>
              {r.status && <div className="mt-1 inline-flex px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">{getStatusConfig(r.status).label}</div>}
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Kapat">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5 mt-4">
          {ACTIONS.map(({ key, label, hint, Icon, tone }) => (
            <button
              key={key}
              type="button"
              onClick={() => onAction(key, reference)}
              className="flex items-center gap-3 min-h-[64px] px-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-left hover:border-slate-300 hover:shadow-sm transition cursor-pointer"
            >
              <span className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${tone}`}><Icon className="w-5 h-5" /></span>
              <span className="leading-tight">
                <span className="block text-sm font-bold text-slate-900 dark:text-white">{label}</span>
                <span className="block text-[11px] text-slate-500 dark:text-slate-400">{hint}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QrActionSheet;
