import React, { useMemo } from 'react';
import { BarChart3 } from 'lucide-react';
import { computePeriodReport, computeColdStatus, periodRange, type ReportInput } from '../../utils/periodReport';
import { Button } from '../ui';

/**
 * v3.2 — Ana sayfa kısa özeti: bu haftanın 4 temel sayısı + "Rapor Merkezi".
 * Ayrıntılı analizler yalnızca Rapor Merkezi'nde (aynı hesaplardan) bulunur.
 */
interface Props extends ReportInput {
  onOpenReportCenter: () => void;
}

const kg = (v: number) => `${Math.round(v).toLocaleString('tr-TR')} kg`;

export default function HomeSummary({ onOpenReportCenter, ...input }: Props) {
  const week = useMemo(() => periodRange('THIS_WEEK').current, []);
  const r = useMemo(() => computePeriodReport(input, week), [input, week]);
  const cold = useMemo(() => computeColdStatus(input), [input]);
  const stockKg = cold.reduce((s, c) => s + c.kg, 0);
  const rooms = new Set(cold.map(c => c.room.toLocaleLowerCase('tr'))).size;
  const missing = r.warnings.reduce((s, w) => s + w.items.length, 0);

  const Tile = ({ label, value, sub, warn }: { label: string; value: string; sub?: string; warn?: boolean }) => (
    <button type="button" onClick={onOpenReportCenter}
      className={`text-left rounded-2xl border p-3 min-h-[84px] transition hover:shadow-sm ${warn ? 'border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-900' : 'border-slate-200 bg-white dark:bg-slate-900 dark:border-slate-700'}`}>
      <span className="block text-xs text-slate-600 dark:text-slate-400">{label}</span>
      <span className="block text-lg font-bold tabular-nums text-slate-900 dark:text-white">{value}</span>
      {sub && <span className="block text-[11px] text-slate-500 dark:text-slate-400">{sub}</span>}
    </button>
  );

  return (
    <section aria-label="Bu haftanın özeti" className="space-y-2.5">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">Bu hafta <span className="font-normal text-slate-500">· {week.label}</span></h2>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <Tile label="Hasat" value={r.harvest.kg ? kg(r.harvest.kg) : (r.harvest.days ? 'tartılmadı' : '—')} sub={r.harvest.days ? `${r.harvest.days} gün · ${r.harvest.workers} kişi-gün` : undefined} />
        <Tile label="Şoklanan" value={r.precooling.netKg ? kg(r.precooling.netKg) : '—'} sub={r.precooling.slips ? `${r.precooling.slips} fiş` : undefined} />
        <Tile label="Depoda şu an" value={stockKg ? kg(stockKg) : '—'} sub={rooms ? `${rooms} oda / yer` : undefined} />
        <Tile label="Eksik kayıt" value={String(missing)} sub={missing ? 'tamamlanması gereken' : 'eksik yok'} warn={missing > 0} />
      </div>
      <Button variant="primary" fullWidth icon={<BarChart3 />} onClick={onOpenReportCenter}>Rapor Merkezi</Button>
    </section>
  );
}
