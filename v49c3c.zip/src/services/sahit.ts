import type { ExportSampleRecord } from '../types';

/**
 * v49c4 — Şahit numune planı. Gün, yola çıkıştan (sevk tarihi) sayılır; yoksa ilk ölçüm tarihi.
 * Ölçüm günleri: 3, 5, 7 ve 7'nin katları (14, 21, 28 …). Ölçüm gününden ±1 gün içinde girilen kayıt o günü karşılar.
 */
export const WITNESS_MAX_DAY = 42;
const DAY = 86400000;
const d10 = (s?: string) => String(s || '').slice(0, 10);
const diff = (a: string, b: string) => Math.round((new Date(a).getTime() - new Date(b).getTime()) / DAY);

export function witnessCheckpoints(upTo: number): number[] {
  const out = [3, 5, 7];
  for (let d = 14; d <= Math.max(upTo, 14); d += 7) out.push(d);
  return out;
}

export interface WitnessPlan {
  start: string;            // gün 0 (yola çıkış)
  today: number;            // bugün kaçıncı gün
  points: { day: number; done: boolean }[];
  missed?: number;          // geçen ve girilmemiş en son ölçüm günü
  dueToday?: number;        // bugün yapılacak ölçüm günü
  count: number;
}

export function witnessPlan(rs: ExportSampleRecord[], now = new Date()): WitnessPlan | null {
  if (!rs.length) return null;
  const starts = rs.map(r => d10(r.dispatchDate)).filter(Boolean).sort();
  const tests = rs.map(r => d10(r.testDate || r.timestamp)).filter(Boolean).sort();
  const start = starts[0] || tests[0];
  if (!start) return null;
  const today = diff(now.toISOString().slice(0, 10), start);
  // her ölçümün günü: kayıttaki "yolda gün" varsa o, yoksa test tarihi − yola çıkış
  const measured = rs.map(r => (Number.isFinite(Number(r.transitDays)) && Number(r.transitDays) > 0 ? Number(r.transitDays) : diff(d10(r.testDate || r.timestamp), start)));
  const points = witnessCheckpoints(Math.min(today + 7, WITNESS_MAX_DAY)).filter(d => d <= WITNESS_MAX_DAY)
    .map(day => ({ day, done: measured.some(m => Math.abs(m - day) <= 1) }));
  // sonraki bir ölçüm girildiyse öncekiler artık hatırlatılmaz
  const lastDone = Math.max(-1, ...points.filter(p => p.done).map(p => p.day));
  const passed = points.filter(p => p.day > lastDone && p.day < today - 1 && !p.done);
  const missed = passed.length ? passed[passed.length - 1].day : undefined;
  const dt = points.find(p => Math.abs(p.day - today) <= 1 && !p.done);
  return { start, today, points, missed, dueToday: dt?.day, count: rs.length };
}

export function groupByRef(rs: ExportSampleRecord[] = []): Map<string, ExportSampleRecord[]> {
  const m = new Map<string, ExportSampleRecord[]>();
  for (const r of rs) { if (!r.refId) continue; const a = m.get(r.refId) || []; a.push(r); m.set(r.refId, a); }
  return m;
}
