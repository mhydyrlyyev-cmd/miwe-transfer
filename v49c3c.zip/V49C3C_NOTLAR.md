# v49c3c — şahit numune modülü (v49c3b'nin eksik kalan kısmı)

GitHub'a eski v49c3b.zip yüklendiği için sahit.ts eksik kaldı. Bu paket yalnız 3 dosya içerir:
- src/services/sahit.ts (YENİ): gün yola çıkıştan sayılır; ölçüm günleri 3, 5, 7 ve 7'nin katları (14, 21 … 42); ±1 gün kabul.
- HomeDashboard.tsx: "Şahit numune · N. gün ölçümü" / "… gecikti" hatırlatması.
- LotsView.tsx: parti sayfasında "Şahit numune" kutusu (yeşil girildi · kırmızı kaçtı · sarı bugün).
v49c3b'nin diğer 3 dosyası (App, analytics, ManagementViews) zaten doğru; dokunulmaz.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (3 dosya)
ec01b493ae46e26f977c04985f589f8d19aec5d218cfbd99050785af4f9af80d  src/services/sahit.ts
fd92596daa262d5f0d3440919cc846417f610c9248cad9ebc36c5289f4b0b39d  src/components/dashboard/HomeDashboard.tsx
a5089ce3140535c95844d9e4827b3e4405240e5bb6a75b47c2fa646398f26427  src/components/views/LotsView.tsx
