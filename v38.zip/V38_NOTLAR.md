# v38 — v37 üzerine yama (RefID çakışması + test kartları)

Proje köküne aynı yollarla kopyalayın. Firestore kuralı değişmedi.

1. RefID çakışması düzeltildi (src/utils/calculations.ts → generateRefId)
   - Eski hata: Günlük hasatta yeni parti her seferinde HARV-YYYYMMDD-001 alıyordu;
     iki cihaz çevrimdışıyken aynı numarayı üretebiliyordu.
   - Yeni biçim: PREFIX-YYYYMMDD-NNN-XY  (XY = cihazın kalıcı 2 haneli kodu)
   - Sıra hesabı: verilen liste + cihazdaki tüm referanslar; eski biçimdeki numaralar da sayılır.
   - Eski numaralar aynen geçerli, hiçbir kayıt değişmez.
2. Çakışma tespiti (src/utils/refConflicts.ts) → Uyarılar sayfasının üstünde liste
   - Aynı RefID altında farklı ürün/bahçe veya 3 günden fazla ayrık hasat tarihleri
3. Test kartı (QualityInsightCard)
   - Sağlık puanı halkası (renk puana göre), Türkçe sonuç: Uygun / Koşullu / Standart dışı
   - "X gün kaldı" → "~X gün raf ömrü"; ilerleme çubuğu "Geçen raf ömrü" olarak etiketli
   - İlk neden tek satır, diğerleri "+N neden daha" ile açılır
   - "GENERAL" → "Genel"; iç içe parantezli konum temizlenir; kontrol eden kişi kartta değil, üzerine gelince
4. Yan menüye "Yardım ve yönetim" grubu (v37'de unutulmuştu)
   - Rehber ve sorular (herkes), Denetim izi ve Kullanıcılar ve onaylar (yalnız yönetici)
