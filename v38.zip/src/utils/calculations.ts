import gasCodeRaw from '../../google-apps-script/Code.gs?raw';
import { isTestReference } from './refKind';
import {
  FieldSample,
  FieldRecord,
  MuzRecord,
  ModuleKey,
  ReferenceItem,
  IncidentRecord,
  SystemStats,
  AmbarRecord,
  LojistikRecord,
  SalesRecord,
  BademRecord,
  HarvestRecord,
  ColdRoomStockItem,
  ColdRoomSummary,
  ColdRoomMovement
} from '../types';

function getWeekNumber(d: Date): number {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dayNum = date.getDay() || 7;
  date.setDate(date.getDate() + 4 - dayNum);
  const yearStart = new Date(date.getFullYear(), 0, 1);
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

export function generateFlatSchema(moduleKey: ModuleKey, record: any, refData?: any) {
  // Flat schema for Pivot Tables & Power BI (No merged cells, typed numerical columns)
  const rawDateStr = record.timestamp || record.recordDate || record.date || record.processDate || record.shipmentDate || record.acceptanceDate || record.salesDate || record.incidentDate || record.harvestDate || (refData ? refData.createdAt : '') || '';
  const parsedDate = rawDateStr ? new Date(rawDateStr) : new Date();
  const validDate = isNaN(parsedDate.getTime()) ? new Date() : parsedDate;
  
  const yyyy = validDate.getFullYear();
  const mm = String(validDate.getMonth() + 1).padStart(2, '0');
  const dd = String(validDate.getDate()).padStart(2, '0');
  const dateStr = `${yyyy}-${mm}-${dd}`;
  const year = yyyy;
  const monthNum = mm;
  const monthName = validDate.toLocaleDateString('tr-TR', { month: 'long' });
  const weekNum = `H-${getWeekNumber(validDate)}`;

  const partiNo = record.refId || (refData ? refData.refId : '');
  const rawProduct = record.product || (refData ? refData.product : '');
  const cleanProduct = rawProduct.split('(')[0].trim() || 'Genel';
  const variety = record.variety || record.sortVariety || (refData ? refData.variety : '') || '';
  
  let brix: number | string = '';
  let firmness: number | string = '';
  let starch: number | string = '';
  let streif: number | string = '';
  let streifInterp = '';
  let specialTest = '';
  let specialVal: number | string = '';
  let specialMetric1Num: number | string = '';
  let specialMetric2Num: number | string = '';
  let specialInterpretation = '';
  let nitrateVal: number | string = '';
  let nitratePass = '';
  let defectPct: number | string = '';
  let colorPct: number | string = '';
  let status = record.decision || record.testStatus || record.status || record.qualityGrade || 'ONAY';
  let riskLevel = 'DÜŞÜK';

  // Madde 8: Miktar_Kg modüle göre doğru alandan gelsin
  let quantityKg = 0;
  if (moduleKey === 'HARVEST') {
    quantityKg = Number(record.dailyTotalKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'MUZ') {
    quantityKg = Number(record.netWeightKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'AMBAR') {
    quantityKg = Number(record.acceptedWeightKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'SALES') {
    quantityKg = Number(record.totalQuantityKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'LOJISTIK') {
    quantityKg = Number(record.weightKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'BADEM') {
    quantityKg = Number(record.totalLoadKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'FREEZE_DRY') {
    quantityKg = Number(record.rawWeightKg ?? refData?.quantity ?? 0) || 0;
  } else if (moduleKey === 'INCIDENT') {
    quantityKg = Number(record.affectedQuantityKg ?? refData?.quantity ?? 0) || 0;
  } else {
    quantityKg = Number(record.quantity ?? record.totalWeightKg ?? refData?.quantity ?? 0) || 0;
  }

  // Madde 8: Nihai_Kanal varsayılanı yalnızca FIELD ve HARVEST için olsun
  let finalChannel = '';
  if (moduleKey === 'FIELD' || moduleKey === 'HARVEST') {
    finalChannel = record.finalProductStatus || (record.reroutedToFreezeDry ? 'FREEZE_DRY' : 'TAZE_SATIS');
  } else {
    finalChannel = record.finalProductStatus || record.destination || '';
  }
  const reroutedFd = record.reroutedToFreezeDry || finalChannel === 'FREEZE_DRY' ? 'EVET' : 'HAYIR';

  if (moduleKey === 'FIELD' || moduleKey === 'HARVEST') {
    brix = record.avgBrix !== undefined ? Number(record.avgBrix) : '';
    firmness = record.avgHardness !== undefined ? Number(record.avgHardness) : (record.avgFirmness ? Number(record.avgFirmness) : '');
    starch = record.starchIndex !== undefined ? Number(record.starchIndex) : '';
    streif = record.streifIndex !== undefined ? Number(record.streifIndex) : '';
    streifInterp = record.streifInterpretation || '';
    if (record.specialCropTest) {
      specialTest = record.specialCropTest.cropNameTr || record.specialCropTest.cropType;
      specialVal = `${record.specialCropTest.metric1Name}: ${record.specialCropTest.metric1Value} ${record.specialCropTest.metric1Unit || ''}`;
      if (record.specialCropTest.metric2Name) {
        specialVal += ` | ${record.specialCropTest.metric2Name}: ${record.specialCropTest.metric2Value} ${record.specialCropTest.metric2Unit || ''}`;
      }
      specialMetric1Num = record.specialCropTest.metric1Value !== undefined ? Number(record.specialCropTest.metric1Value) : '';
      specialMetric2Num = record.specialCropTest.metric2Value !== undefined ? Number(record.specialCropTest.metric2Value) : '';
      specialInterpretation = record.specialCropTest.interpretation || '';
    }
    nitrateVal = record.nitrateMgKg !== undefined ? Number(record.nitrateMgKg) : '';
    nitratePass = record.nitratePass === false ? 'LIMIT_USTU' : (record.nitratePass ? 'UYGUN' : '');
    defectPct = record.defectPercent !== undefined ? Number(record.defectPercent) : '';
    colorPct = record.colorationPercent !== undefined ? Number(record.colorationPercent) : '';
    riskLevel = (Number(defectPct) > 5 || record.nitratePass === false || (typeof streif === 'number' && streif < 0.07)) ? 'YÜKSEK' : 'DÜŞÜK';
    if (record.decision && record.decision.toLowerCase().includes('red')) status = 'RED';
  } else if (moduleKey === 'MUZ') {
    // Madde 8: MUZ alanları
    const muzBrix = record.avgBrix ?? record.brix ?? record.banana3PointBrix?.avg3Point;
    brix = muzBrix !== undefined ? Number(muzBrix) : '';
    firmness = record.pulpFirmness !== undefined ? Number(record.pulpFirmness) : '';
    specialTest = 'Muz Kurdele & Olgunluk';
    specialVal = `${record.ribbonColor || ''} (${record.ripenessScale || 1}/7)`;
    specialMetric1Num = record.ripenessScale !== undefined ? Number(record.ripenessScale) : '';
    specialMetric2Num = record.calibrationMm !== undefined ? Number(record.calibrationMm) : '';
    specialInterpretation = `Olgunluk: ${record.ripenessScale || 1}/7, Kalibrasyon: ${record.calibrationMm || '-'} mm`;
    status = record.qualityStatus || record.status || 'ONAY';
  } else if (moduleKey === 'BADEM') {
    // Madde 8: BADEM alanları
    specialTest = 'Badem Randıman %';
    specialMetric1Num = record.kernelYieldPercent !== undefined ? Number(record.kernelYieldPercent) : '';
    specialMetric2Num = record.moisturePercent !== undefined ? Number(record.moisturePercent) : '';
    specialVal = specialMetric1Num !== '' ? `%${specialMetric1Num}` : '';
    specialInterpretation = `Randıman %${specialMetric1Num}, Nem %${specialMetric2Num}`;
    defectPct = record.totalDefectPercent !== undefined ? Number(record.totalDefectPercent) : '';
    status = record.testStatus || record.status || 'ONAY';
  } else if (moduleKey === 'INCIDENT') {
    // Madde 8: INCIDENT alanları
    const prio = record.priority;
    riskLevel = prio === 'CRITICAL' ? 'KRİTİK' : (prio === 'HIGH' ? 'YÜKSEK' : (prio === 'MEDIUM' ? 'ORTA' : 'DÜŞÜK'));
    status = record.status || 'OPEN';
  } else if (moduleKey === 'EXPORT_SAMPLE') {
    // Madde 8: EXPORT_SAMPLE Durum = shelfLifeDecision
    status = record.shelfLifeDecision || record.status || 'COMPLIANT';
    brix = record.avgBrix !== undefined ? Number(record.avgBrix) : '';
    firmness = record.avgHardness !== undefined ? Number(record.avgHardness) : '';
  }

  return {
    Tarih: dateStr,
    Yil: year,
    Ay: `${monthNum} - ${monthName}`,
    Hafta: weekNum,
    Modul_Adi: moduleKey,
    Parti_No: partiNo,
    Urun: cleanProduct,
    Cesit: variety,
    Lokasyon: record.location || record.orchard || (refData ? refData.location : '') || '',
    Miktar_Kg: quantityKg,
    Brix: brix,
    Sertlik_kg_cm2: firmness,
    Nisasta_1_10: starch,
    Streif_Indeksi_SI: streif,
    Streif_Yorumu: streifInterp,
    Ozel_Test: specialTest,
    Ozel_Test_Deger: specialVal,
    Ozel_Metrik1_Sayisal: specialMetric1Num,
    Ozel_Metrik2_Sayisal: specialMetric2Num,
    Ozel_Test_Yorum: specialInterpretation,
    Nitrat_mg_kg: nitrateVal,
    Nitrat_Uygunluk: nitratePass,
    Kusur_Orani_Pct: defectPct,
    Renklenme_Pct: colorPct,
    Kalite_Sinifi: record.classification || record.kaliteSinifi || record.qualityGrade || 'Standart',
    Durum: status,
    Nihai_Kanal: finalChannel,
    FreezeDry_Sevk: reroutedFd,
    Risk_Seviyesi: riskLevel,
    Aksiyon: record.nextStep || record.action || '',
    Operator: record.operator || (refData ? refData.operator : ''),
    Gorsel_Durumu: (record.photos && record.photos.length > 0) || (record.photoIds && record.photoIds.length > 0) ? 'Mevcut' : 'Yok'
  };
}

/**
 * Exports all test records across all modules in an Excel / Pivot / Power BI ready CSV format
 */
export function exportComprehensivePivotDataset(params: {
  references?: ReferenceItem[];
  fieldRecords?: FieldRecord[];
  harvestRecords?: HarvestRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  lojistikRecords?: LojistikRecord[];
  exportSampleRecords?: any[];
  ambarRecords?: AmbarRecord[];
  freezeDryRecords?: any[];
  salesRecords?: SalesRecord[];
  incidentRecords?: IncidentRecord[];
}): void {
  const allFlatRows: ReturnType<typeof generateFlatSchema>[] = [];
  const refMap = new Map<string, ReferenceItem>();
  (params.references || []).forEach(r => refMap.set(r.refId, r));

  (params.fieldRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('FIELD', r, refMap.get(r.refId)));
  });
  (params.harvestRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('HARVEST', r, refMap.get(r.refId)));
  });
  (params.muzRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('MUZ', r, refMap.get(r.refId)));
  });
  (params.bademRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('BADEM', r, refMap.get(r.refId)));
  });
  (params.lojistikRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('LOJISTIK', r, refMap.get(r.refId)));
  });
  (params.exportSampleRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('EXPORT_SAMPLE', r, refMap.get(r.refId)));
  });
  (params.ambarRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('AMBAR', r, refMap.get(r.refId)));
  });
  (params.freezeDryRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('FREEZE_DRY', r, refMap.get(r.refId)));
  });
  (params.salesRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('SALES', r, refMap.get(r.refId)));
  });
  (params.incidentRecords || []).forEach(r => {
    allFlatRows.push(generateFlatSchema('INCIDENT', r, refMap.get(r.refId)));
  });

  // If empty, generate rows from references
  if (allFlatRows.length === 0 && params.references && params.references.length > 0) {
    params.references.forEach(ref => {
      allFlatRows.push(generateFlatSchema(ref.moduleKey, ref, ref));
    });
  }

  if (allFlatRows.length === 0) {
    console.warn('Dışa aktarılacak kayıt bulunamadı.');
    return;
  }

  // Column Headers (Normalized, unmerged, 1-row table headers for Excel Pivot)
  const headers = [
    'Tarih',
    'Yil',
    'Ay',
    'Hafta',
    'Modul_Adi',
    'Parti_No',
    'Urun',
    'Cesit',
    'Lokasyon',
    'Miktar_Kg',
    'Brix',
    'Sertlik_kg_cm2',
    'Nisasta_1_10',
    'Streif_Indeksi_SI',
    'Streif_Yorumu',
    'Ozel_Test',
    'Ozel_Test_Deger',
    'Ozel_Metrik1_Sayisal',
    'Ozel_Metrik2_Sayisal',
    'Ozel_Test_Yorum',
    'Nitrat_mg_kg',
    'Nitrat_Uygunluk',
    'Kusur_Orani_Pct',
    'Renklenme_Pct',
    'Kalite_Sinifi',
    'Durum',
    'Nihai_Kanal',
    'FreezeDry_Sevk',
    'Risk_Seviyesi',
    'Aksiyon',
    'Operator',
    'Gorsel_Durumu'
  ];

  const escapeCsv = (val: any) => {
    if (val === null || val === undefined) return '';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const csvRows: string[] = [];
  // Standard header
  csvRows.push(headers.map(h => escapeCsv(h)).join(';'));

  allFlatRows.forEach(row => {
    const rowValues = [
      row.Tarih,
      row.Yil,
      row.Ay,
      row.Hafta,
      row.Modul_Adi,
      row.Parti_No,
      row.Urun,
      row.Cesit,
      row.Lokasyon,
      row.Miktar_Kg,
      row.Brix,
      row.Sertlik_kg_cm2,
      row.Nisasta_1_10,
      row.Streif_Indeksi_SI,
      row.Streif_Yorumu,
      row.Ozel_Test,
      row.Ozel_Test_Deger,
      row.Ozel_Metrik1_Sayisal,
      row.Ozel_Metrik2_Sayisal,
      row.Ozel_Test_Yorum,
      row.Nitrat_mg_kg,
      row.Nitrat_Uygunluk,
      row.Kusur_Orani_Pct,
      row.Renklenme_Pct,
      row.Kalite_Sinifi,
      row.Durum,
      row.Nihai_Kanal,
      row.FreezeDry_Sevk,
      row.Risk_Seviyesi,
      row.Aksiyon,
      row.Operator,
      row.Gorsel_Durumu
    ];
    csvRows.push(rowValues.map(v => escapeCsv(v)).join(';'));
  });

  const csvContent = '\uFEFF' + csvRows.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `MIWE_Analitik_Pivot_Veri_Seti_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
export function calculateSystemStats(
  references: ReferenceItem[],
  incidents: IncidentRecord[]
): SystemStats {
  // Filter out references where weight/quantity might be 0 or null if applicable
  const validReferences = references.filter(r => (r.quantity ?? 1) > 0 && !isTestReference(r)); // v2.7: test kayıtları stok değildir
  
  const totalReferences = validReferences.length;
  const created = validReferences.filter(r => r.status === 'CREATED').length;
  const shipped = validReferences.filter(r => r.status === 'SHIPPED' || r.status === 'IN_TRANSIT').length;
  const received = validReferences.filter(r => r.status === 'RECEIVED').length;
  const completedCount = validReferences.filter(r => r.status === 'COMPLETED').length;
  const incidentCount = incidents.filter(i => i.status === 'OPEN' || i.status === 'IN_PROGRESS').length;

  const harvestCount = validReferences.filter(r => r.moduleKey === 'HARVEST').length;
  const fieldCount = validReferences.filter(r => r.moduleKey === 'FIELD').length;
  const muzCount = validReferences.filter(r => r.moduleKey === 'MUZ').length;
  const bademCount = validReferences.filter(r => r.moduleKey === 'BADEM').length;
  const freezeDryCount = validReferences.filter(r => r.moduleKey === 'FREEZE_DRY' || r.status === 'IN_FREEZE_DRY').length;
  const exportSampleCount = validReferences.filter(r => r.moduleKey === 'EXPORT_SAMPLE').length;
  const salesCount = validReferences.filter(r => r.moduleKey === 'SALES').length;

  return {
    totalReferences,
    created,
    shipped,
    received,
    completedCount,
    incidents: incidentCount,
    harvestCount,
    fieldCount,
    muzCount,
    bademCount,
    freezeDryCount,
    exportSampleCount,
    salesCount
  };
}

/**
 * Calculates sub-breakdown for "Saha & Hasat Hazır" dashboard card:
 * - Hasat Bekleyen
 * - Freeze & Dry
 * - Ambar
 * - Lojistik
 */
export function calculateFieldBreakdown(
  references: ReferenceItem[],
  harvestRecords: HarvestRecord[] = []
): {
  hasatBekleyen: number;
  freezeDry: number;
  ambar: number;
  lojistik: number;
} {
  let hasatBekleyen = 0;
  let freezeDry = 0;
  let ambar = 0;
  let lojistik = 0;

  // Filter out references with zero/null weight if possible
  const validReferences = references.filter(r => (r.quantity ?? 1) > 0 && !isTestReference(r)); // v2.7: test kayıtları stok değildir

  validReferences.forEach(ref => {
    const dest = (ref.destination || '').toLowerCase();
    const notes = (ref.notes || '').toLowerCase();
    const isHarvestModule = ref.moduleKey === 'HARVEST' || ref.moduleKey === 'FIELD';

    if (dest.includes('freeze') || notes.includes('freeze') || ref.status === 'IN_FREEZE_DRY') {
      freezeDry++;
    } else if (dest.includes('ambar') || dest.includes('depo') || dest.includes('sowuk')) {
      ambar++;
    } else if (dest.includes('lojistik') || dest.includes('sevkiyat') || dest.includes('sevk')) {
      lojistik++;
    } else if (isHarvestModule || ref.status === 'CREATED') {
      hasatBekleyen++;
    } else {
      hasatBekleyen++;
    }
  });

  // If there are no references yet, ensure logical counts
  return {
    hasatBekleyen: Math.max(hasatBekleyen, harvestRecords.length > 0 ? 1 : 0),
    freezeDry,
    ambar,
    lojistik
  };
}

/**
 * Calculates comprehensive Cold Room Storage Analytics:
 * "Hangi soğuk odada hangi ürün ne kadar duruyor?"
 * Returns summary per room, detailed active stock table, and chronological movements.
 */
export function calculateColdRoomStats(
  ambarRecords: AmbarRecord[] = [],
  lojistikRecords: LojistikRecord[] = [],
  salesRecords: SalesRecord[] = [],
  references: ReferenceItem[] = []
): {
  rooms: ColdRoomSummary[];
  stockItems: ColdRoomStockItem[];
  movements: ColdRoomMovement[];
  overallStats: {
    totalStockKg: number;
    totalStockTons: number;
    activeRoomCount: number;
    avgWaitDays: number;
    longestWaiting?: {
      product: string;
      refId: string;
      waitDays: number;
      roomNo: string;
    };
    shortestWaiting?: {
      product: string;
      refId: string;
      waitDays: number;
      roomNo: string;
    };
  };
} {
  const refMap = new Map<string, ReferenceItem>();
  references.forEach(r => refMap.set(r.refId, r));

  // Collect exit dates from lojistik or sales
  const exitDates = new Map<string, string>();
  lojistikRecords.forEach(l => {
    if (l.shipmentDate) exitDates.set(l.refId, l.shipmentDate);
  });
  salesRecords.forEach(s => {
    if (s.salesDate) exitDates.set(s.refId, s.salesDate);
  });

  const now = new Date();

  // Cold-Start Mode: Only process real ambarRecords (no fake sample records)
  const baseRecords: AmbarRecord[] = ambarRecords;

  const stockItems: ColdRoomStockItem[] = [];
  const movements: ColdRoomMovement[] = [];

  baseRecords.forEach(a => {
    const parentRef = refMap.get(a.refId);
    const prod = parentRef?.product || 'Meyve';
    const variety = prod.includes('(') ? prod.split('(')[1].replace(')', '').trim() : '';

    const entryDate = a.acceptanceDate || (a.timestamp ? String(a.timestamp).slice(0, 10) : new Date().toISOString().slice(0, 10));
    const hasExit = exitDates.has(a.refId);
    const exitDate = hasExit ? exitDates.get(a.refId) : undefined;

    const entryD = new Date(entryDate);
    const endD = exitDate ? new Date(exitDate) : now;
    let waitingDays = 0;
    if (!isNaN(entryD.getTime()) && !isNaN(endD.getTime())) {
      if (entryD > endD) {
        waitingDays = 0;
      } else {
        const diffMs = Math.max(0, endD.getTime() - entryD.getTime());
        waitingDays = Math.max(0, Math.round(diffMs / (1000 * 60 * 60 * 24)));
      }
    }
    if (isNaN(waitingDays)) waitingDays = 0;

    const item: ColdRoomStockItem = {
      id: a.id,
      warehouse: a.warehouse || 'Depo belirtilmedi',
      roomNo: a.roomNo || 'Oda belirtilmedi',
      product: prod,
      variety,
      refId: a.refId,
      entryDate,
      exitDate,
      weightKg: a.acceptedWeightKg || 0,
      weightTons: Number(((a.acceptedWeightKg || 0) / 1000).toFixed(2)),
      waitingDays,
      status: hasExit ? 'DISPATCHED' : 'ACTIVE',
      treatmentApplied: a.treatmentApplied,
      roomTemperature: a.roomTemperature,
      humidityPercent: a.humidityPercent
    };

    stockItems.push(item);

    movements.push({
      refId: a.refId,
      product: prod,
      variety,
      warehouse: a.warehouse,
      roomNo: a.roomNo,
      weightKg: a.acceptedWeightKg || 0,
      entryDate,
      exitDate,
      totalWaitDays: waitingDays,
      isCompleted: hasExit
    });
  });

  // Group by Warehouse + Room
  const roomGroups = new Map<string, ColdRoomStockItem[]>();
  stockItems.forEach(item => {
    const key = `${item.warehouse}__${item.roomNo}`;
    if (!roomGroups.has(key)) {
      roomGroups.set(key, []);
    }
    roomGroups.get(key)!.push(item);
  });

  const rooms: ColdRoomSummary[] = [];

  roomGroups.forEach((items, key) => {
    const [warehouse, roomNo] = key.split('__');
    const totalKg = items.reduce((sum, it) => sum + it.weightKg, 0);
    const totalTons = Number((totalKg / 1000).toFixed(2));
    const validWaitDays = items.map(it => it.waitingDays).filter(Number.isFinite);
    const avgWaitDays = validWaitDays.length > 0
      ? Number((validWaitDays.reduce((sum, d) => sum + d, 0) / validWaitDays.length).toFixed(1))
      : 0;

    // Products breakdown in this room
    const prodMap = new Map<string, ColdRoomStockItem[]>();
    items.forEach(it => {
      const pKey = it.product;
      if (!prodMap.has(pKey)) prodMap.set(pKey, []);
      prodMap.get(pKey)!.push(it);
    });

    const products = Array.from(prodMap.entries()).map(([pName, pItems]) => {
      const pKg = pItems.reduce((s, it) => s + it.weightKg, 0);
      const validPWait = pItems.map(it => it.waitingDays).filter(Number.isFinite);
      const pWait = validPWait.length > 0
        ? Number((validPWait.reduce((s, d) => s + d, 0) / validPWait.length).toFixed(1))
        : 0;
      return {
        product: pName,
        variety: pItems[0]?.variety,
        kg: pKg,
        tons: Number((pKg / 1000).toFixed(2)),
        avgWaitDays: pWait,
        refCount: pItems.length
      };
    });

    // Find longest & shortest waiting item
    let longestItem = items[0];
    let shortestItem = items[0];
    items.forEach(it => {
      if (it.waitingDays > longestItem.waitingDays) longestItem = it;
      if (it.waitingDays < shortestItem.waitingDays) shortestItem = it;
    });

    rooms.push({
      warehouse,
      roomNo,
      totalKg,
      totalTons,
      itemCount: items.length,
      avgWaitDays,
      products,
      longestWaiting: {
        product: longestItem.product,
        variety: longestItem.variety,
        refId: longestItem.refId,
        waitDays: longestItem.waitingDays
      },
      shortestWaiting: {
        product: shortestItem.product,
        variety: shortestItem.variety,
        refId: shortestItem.refId,
        waitDays: shortestItem.waitingDays
      }
    });
  });

  // Overall Statistics
  const activeStock = stockItems.filter(s => s.status === 'ACTIVE');
  const activeItemsToCount = activeStock.length > 0 ? activeStock : stockItems;
  const totalStockKg = activeItemsToCount.reduce((s, it) => s + it.weightKg, 0);
  const totalStockTons = Number((totalStockKg / 1000).toFixed(2));
  const avgWaitDays = activeItemsToCount.length > 0
    ? Number((activeItemsToCount.reduce((s, it) => s + it.waitingDays, 0) / activeItemsToCount.length).toFixed(1))
    : 0;

  let globalLongest = activeItemsToCount[0];
  let globalShortest = activeItemsToCount[0];
  activeItemsToCount.forEach(it => {
    if (it.waitingDays > globalLongest.waitingDays) globalLongest = it;
    if (it.waitingDays < globalShortest.waitingDays) globalShortest = it;
  });

  return {
    rooms,
    stockItems,
    movements,
    overallStats: {
      totalStockKg,
      totalStockTons,
      activeRoomCount: rooms.length,
      avgWaitDays,
      longestWaiting: globalLongest ? {
        product: globalLongest.product,
        refId: globalLongest.refId,
        waitDays: globalLongest.waitingDays,
        roomNo: globalLongest.roomNo
      } : undefined,
      shortestWaiting: globalShortest ? {
        product: globalShortest.product,
        refId: globalShortest.refId,
        waitDays: globalShortest.waitingDays,
        roomNo: globalShortest.roomNo
      } : undefined
    }
  };
}

/**
 * Calculates comprehensive Badem (Almond) quality, yield and moisture analytics
 */
export function calculateBademAnalytics(bademRecords: BademRecord[] = []) {
  if (!bademRecords.length) {
    return {
      avgYieldPercent: 0,
      avgMoisturePercent: 0,
      totalLoadKg: 0,
      processedKg: 0,
      remainingKg: 0,
      defectAverages: { seriousPercent: 0, totalPercent: 0 },
      varietyBreakdown: [],
      locationBreakdown: [],
      dateTrends: [],
      gradeDistribution: { Ekstra: 0, Sinif1: 0, Sinif2: 0, Sanayi: 0 }
    };
  }

  const count = bademRecords.length;
  const avgYield = Number((bademRecords.reduce((s, b) => s + b.kernelYieldPercent, 0) / count).toFixed(2));
  const avgMoisture = Number((bademRecords.reduce((s, b) => s + b.moisturePercent, 0) / count).toFixed(2));
  const avgSerious = Number((bademRecords.reduce((s, b) => s + b.seriousDefectPercent, 0) / count).toFixed(2));
  const avgTotalDefects = Number((bademRecords.reduce((s, b) => s + b.totalDefectPercent, 0) / count).toFixed(2));
  const totalLoad = bademRecords.reduce((s, b) => s + (b.totalLoadKg || 0), 0);
  const processed = Math.round(totalLoad * (avgYield / 100));
  const remaining = totalLoad - processed;

  // Group by variety
  const varMap = new Map<string, BademRecord[]>();
  bademRecords.forEach(b => {
    const v = b.variety || 'Genel';
    if (!varMap.has(v)) varMap.set(v, []);
    varMap.get(v)!.push(b);
  });

  const varietyBreakdown = Array.from(varMap.entries()).map(([variety, recs]) => {
    const vYield = Number((recs.reduce((s, r) => s + r.kernelYieldPercent, 0) / recs.length).toFixed(2));
    const vMoist = Number((recs.reduce((s, r) => s + r.moisturePercent, 0) / recs.length).toFixed(2));
    const vKg = recs.reduce((s, r) => s + (r.totalLoadKg || 0), 0);
    return { variety, avgYield: vYield, avgMoisture: vMoist, totalKg: vKg, count: recs.length };
  });

  // Group by location
  const locMap = new Map<string, BademRecord[]>();
  bademRecords.forEach(b => {
    const l = b.location || 'Bilinmeyen Parsel';
    if (!locMap.has(l)) locMap.set(l, []);
    locMap.get(l)!.push(b);
  });

  const locationBreakdown = Array.from(locMap.entries()).map(([location, recs]) => {
    const lYield = Number((recs.reduce((s, r) => s + r.kernelYieldPercent, 0) / recs.length).toFixed(2));
    const lMoist = Number((recs.reduce((s, r) => s + r.moisturePercent, 0) / recs.length).toFixed(2));
    const lKg = recs.reduce((s, r) => s + (r.totalLoadKg || 0), 0);
    return { location, avgYield: lYield, avgMoisture: lMoist, totalKg: lKg, count: recs.length };
  });

  // Group by date
  const dateMap = new Map<string, BademRecord[]>();
  bademRecords.forEach(b => {
    const d = (b.timestamp || '').slice(0, 10);
    if (!dateMap.has(d)) dateMap.set(d, []);
    dateMap.get(d)!.push(b);
  });

  const dateTrends = Array.from(dateMap.entries()).map(([date, recs]) => {
    const dYield = Number((recs.reduce((s, r) => s + r.kernelYieldPercent, 0) / recs.length).toFixed(2));
    const dMoist = Number((recs.reduce((s, r) => s + r.moisturePercent, 0) / recs.length).toFixed(2));
    return { date, avgYield: dYield, avgMoisture: dMoist, count: recs.length };
  }).sort((a, b) => a.date.localeCompare(b.date));

  // Grade Distribution
  const gradeDistribution = {
    Ekstra: bademRecords.filter(b => b.classification === 'Ekstra').length,
    Sinif1: bademRecords.filter(b => b.classification === 'Sınıf 1').length,
    Sinif2: bademRecords.filter(b => b.classification === 'Sınıf 2').length,
    Sanayi: bademRecords.filter(b => b.classification === 'Sanayi / Yağlık').length
  };

  return {
    avgYieldPercent: avgYield,
    avgMoisturePercent: avgMoisture,
    totalLoadKg: totalLoad,
    processedKg: processed,
    remainingKg: remaining,
    defectAverages: { seriousPercent: avgSerious, totalPercent: avgTotalDefects },
    varietyBreakdown,
    locationBreakdown,
    dateTrends,
    gradeDistribution
  };
}

/**
 * Generate standardized RefID with module prefix and zero-padded sequence
 * Format: {PREFIX}-YYYYMMDD-XXX
 */
/**
 * v3.8 — Çakışmasız RefID.
 * Biçim: PREFIX-YYYYMMDD-NNN-XY   (XY = bu cihazın kalıcı 2 haneli kodu)
 *  • NNN: verilen liste + bu cihazdaki tüm referanslar (localStorage) içinde o günün en büyük sırası + 1
 *  • XY : iki cihaz çevrimdışıyken aynı sırayı üretse bile numaralar farklı olur
 * Eski biçimdeki (PREFIX-YYYYMMDD-NNN) numaralar aynen geçerlidir; sıra hesabına onlar da katılır.
 */
const DEVICE_TAG_KEY = 'miwe_device_tag';
const TAG_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // karışan harfler (I, O, 0, 1) yok

export function getDeviceTag(): string {
  try {
    const saved = localStorage.getItem(DEVICE_TAG_KEY);
    if (saved && /^[A-Z2-9]{2}$/.test(saved)) return saved;
    const rnd = () => TAG_ALPHABET[Math.floor(Math.random() * TAG_ALPHABET.length)];
    const tag = rnd() + rnd();
    localStorage.setItem(DEVICE_TAG_KEY, tag);
    return tag;
  } catch {
    return 'ZZ';
  }
}

function localRefIds(): string[] {
  try {
    const raw = localStorage.getItem('miwe_references');
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.map((r: any) => String(r?.refId || '')).filter(Boolean) : [];
  } catch {
    return [];
  }
}

export function generateRefId(moduleKey: ModuleKey, existingRefs: string[] = []): string {
  const prefixMap: Record<ModuleKey, string> = {
    HARVEST: 'HARV',
    FIELD: 'FIELD',
    MUZ: 'MUZ',
    BADEM: 'BADEM',
    LOJISTIK: 'LOJ',
    AMBAR: 'AMB',
    EXPORT_SAMPLE: 'EXP',
    SALES: 'SALE',
    INCIDENT: 'INC',
    FREEZE_DRY: 'FD',
    FEEDBACK: 'FB'
  };

  const prefix = prefixMap[moduleKey] || 'REF';
  const now = new Date();
  const dateStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const tag = getDeviceTag();

  // eski biçim (…-NNN) ve yeni biçim (…-NNN-XY) birlikte sayılır
  const pattern = new RegExp(`^${prefix}-${dateStr}-(\\d+)(?:-[A-Z2-9]{2})?$`);
  const all = new Set<string>([...existingRefs, ...localRefIds()]);
  let maxSeq = 0;
  all.forEach(ref => {
    const m = ref.match(pattern);
    if (m) maxSeq = Math.max(maxSeq, parseInt(m[1], 10));
  });

  let seq = maxSeq + 1;
  let id = `${prefix}-${dateStr}-${String(seq).padStart(3, '0')}-${tag}`;
  while (all.has(id)) { seq++; id = `${prefix}-${dateStr}-${String(seq).padStart(3, '0')}-${tag}`; }
  return id;
}

/**
 * Calculate averages from fruit field samples
 */
export function calculateFieldAverages(samples: FieldSample[]) {
  if (!samples.length) {
    return { avgHardness: 0, avgBrix: 0, avgDiameter: 0, avgStarch: 0, avgWeightG: 0, totalWeightG: 0 };
  }

  const validHardness = samples.filter(s => s.hardness > 0);
  const validBrix = samples.filter(s => s.brix > 0);
  const validDiameter = samples.filter(s => s.diameterMm > 0);
  const validStarch = samples.filter(s => typeof s.starch === 'number' && s.starch > 0);
  const validWeight = samples.filter(s => typeof s.weightG === 'number' && s.weightG > 0);

  const avgHardness = validHardness.length
    ? Number((validHardness.reduce((sum, s) => sum + s.hardness, 0) / validHardness.length).toFixed(2))
    : 0;

  const avgBrix = validBrix.length
    ? Number((validBrix.reduce((sum, s) => sum + s.brix, 0) / validBrix.length).toFixed(2))
    : 0;

  const avgDiameter = validDiameter.length
    ? Number((validDiameter.reduce((sum, s) => sum + s.diameterMm, 0) / validDiameter.length).toFixed(1))
    : 0;

  const avgStarch = validStarch.length
    ? Number((validStarch.reduce((sum, s) => sum + (s.starch || 0), 0) / validStarch.length).toFixed(1))
    : 0;

  const totalWeightG = validWeight.length
    ? Number(validWeight.reduce((sum, s) => sum + (s.weightG || 0), 0).toFixed(1))
    : 0;

  const avgWeightG = validWeight.length
    ? Number((totalWeightG / validWeight.length).toFixed(1))
    : 0;

  return { avgHardness, avgBrix, avgDiameter, avgStarch, avgWeightG, totalWeightG };
}

export interface StreifIndexResult {
  streifIndex: number;
  status: 'LONG_CA_STORAGE' | 'OPTIMUM_STORAGE' | 'SHORT_STORAGE' | 'IMMEDIATE_CONSUMPTION' | 'INVALID';
  interpretation: string;
  badgeClass: string;
  starchStageText: string;
}

/**
 * Calculate Streif Index (SI) & Starch Iodine Conversion
 * Formula: SI = Firmness (kg/cm²) / (Brix (%) * Starch Index (1 - 10))
 *
 * Standard Pomological Thresholds (Elma, Armut vb.):
 * - SI >= 0.18 : Erken Hasat • Uzun Süreli CA / ULO Soğuk Depolama (9-12 Ay)
 * - 0.12 <= SI < 0.18 : Optimum Hasat Penceresi • Standart Soğuk Hava Depolama (4-8 Ay)
 * - 0.07 <= SI < 0.12 : Kısa Süreli Depolama veya Doğrudan Taze Pazara Sevk (1-3 Ay)
 * - SI < 0.07 : Aşırı Olgun • Depoya Uygun Değil • Taze Tüketim / Sanayi / Freeze-Dry
 */
export function calculateStreifIndex(hardness: number, brix: number, starch: number, variety?: string): StreifIndexResult {
  if (hardness <= 0 || brix <= 0 || starch <= 0) {
    return {
      streifIndex: 0,
      status: 'INVALID',
      interpretation: 'Eksik veya Geçersiz Değer',
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
      starchStageText: 'Ölçüm Yapılmadı'
    };
  }

  const denominator = brix * starch;
  const si = Number((hardness / denominator).toFixed(3));

  // WSU / CTIFL Çeşit Odaklı Streif İndeksi & Sertlik-Nişasta Eşikleri
  const normVariety = (variety || '').toLowerCase();
  const isGrannySmith = normVariety.includes('granny');
  const isGolden = normVariety.includes('golden');
  const isRedDelicious = normVariety.includes('red chief') || normVariety.includes('scarlet') || normVariety.includes('delicious') || normVariety.includes('starking');
  const isGala = normVariety.includes('gala');
  const isFuji = normVariety.includes('fuji');

  // Çeşide özgü optimum SI eşikleri
  let longCaThreshold = 0.18;
  let optimumThreshold = 0.12;
  let shortStorageThreshold = 0.07;
  let varietyNote = '';

  if (isGrannySmith) {
    // Granny Smith: Asitliği ve sertliği yüksek, nişasta hidrolizi yavaş (WSU standardı: SI ≥ 0.20 CA için)
    longCaThreshold = 0.20;
    optimumThreshold = 0.14;
    shortStorageThreshold = 0.08;
    varietyNote = ' [Granny Smith: Sertlik ≥ 7.0 kg/cm², Asitlik Koruma]';
  } else if (isGolden) {
    // Golden Delicious: Çabuk sararır ve su kaybeder, optimum SI 0.10 - 0.16
    longCaThreshold = 0.16;
    optimumThreshold = 0.10;
    shortStorageThreshold = 0.06;
    varietyNote = ' [Golden: Erken Sarı Dönüşüm Uyarısı]';
  } else if (isRedDelicious) {
    // Red Chief / Scarlet Spur: Renklenme erkendir fakat iç et sertliği ve nişasta skalası (4-5) beklenmelidir
    longCaThreshold = 0.17;
    optimumThreshold = 0.11;
    shortStorageThreshold = 0.07;
    varietyNote = ' [Scarlet/Red Chief: Renk aldanması riski, nişasta teyitli]';
  } else if (isGala) {
    longCaThreshold = 0.18;
    optimumThreshold = 0.12;
    shortStorageThreshold = 0.07;
    varietyNote = ' [Gala: Çatlama öncesi erken hasat penceresi]';
  } else if (isFuji) {
    longCaThreshold = 0.15;
    optimumThreshold = 0.09;
    shortStorageThreshold = 0.05;
    varietyNote = ' [Fuji: Yüksek Brix & Su Kalbi / Watercore kontrolü]';
  }

  let status: StreifIndexResult['status'] = 'OPTIMUM_STORAGE';
  let interpretation = '';
  let badgeClass = '';

  if (si >= longCaThreshold) {
    status = 'LONG_CA_STORAGE';
    interpretation = `Erken Hasat • Uzun Süreli CA / ULO Depolama (9-12 Ay)${varietyNote}`;
    badgeClass = 'bg-cyan-100 text-cyan-900 border-cyan-300 dark:bg-cyan-950 dark:text-cyan-200 dark:border-cyan-800';
  } else if (si >= optimumThreshold) {
    status = 'OPTIMUM_STORAGE';
    interpretation = `Optimum Hasat Penceresi • Standart Soğuk Depo (4-8 Ay)${varietyNote}`;
    badgeClass = 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-800';
  } else if (si >= shortStorageThreshold) {
    status = 'SHORT_STORAGE';
    interpretation = `Kısa Süreli Depo veya Doğrudan Taze Pazara Sevk (1-3 Ay)${varietyNote}`;
    badgeClass = 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800';
  } else {
    status = 'IMMEDIATE_CONSUMPTION';
    interpretation = `Aşırı Olgun • Depoya Uygun Değil • Taze Tüketim / Sanayi / Freeze-Dry${varietyNote}`;
    badgeClass = 'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950 dark:text-rose-200 dark:border-rose-800';
  }

  // Starch Stage Interpretation (1-10 CTIFL)
  let starchStageText = '';
  if (starch <= 2) {
    starchStageText = 'Aşama 1-2: Tam Nişasta (Ham / Çok Erken)';
  } else if (starch <= 4) {
    starchStageText = 'Aşama 3-4: Başlangıç Dönüşüm (CA / ULO Uzun Depoluk)';
  } else if (starch <= 6) {
    starchStageText = 'Aşama 5-6: Yarı Dönüşüm (Optimum Hasat Penceresi)';
  } else if (starch <= 8) {
    starchStageText = 'Aşama 7-8: İleri Dönüşüm (Taze Tüketim / Kısa Depo)';
  } else {
    starchStageText = 'Aşama 9-10: Tam Şeker Dönüşümü (Aşırı Olgun)';
  }

  return {
    streifIndex: si,
    status,
    interpretation,
    badgeClass,
    starchStageText
  };
}

/**
 * Calculate Almond Kernel Yield (Randıman %)
 * Formula: (Kernel Weight / Gross Sample Weight) * 100
 */
export function calculateAlmondYield(sampleGram: number, kernelGram: number): number {
  if (sampleGram <= 0 || kernelGram <= 0) return 0;
  return Number(((kernelGram / sampleGram) * 100).toFixed(2));
}

/**
 * Calculate Almond Defect Breakdown Percentages
 */
export function calculateAlmondDefects(
  sampleGram: number,
  seriousDefectGram: number,
  totalDefectsGram: number
) {
  if (sampleGram <= 0) return { seriousPercent: 0, totalPercent: 0 };
  const seriousPercent = Number(((seriousDefectGram / sampleGram) * 100).toFixed(2));
  const totalPercent = Number(((totalDefectsGram / sampleGram) * 100).toFixed(2));
  return { seriousPercent, totalPercent };
}

/**
 * Calculate Banana Quality Grade & Chilling Alert based on technical specs
 */
export function evaluateBananaQuality(params: {
  fingerLengthCm: number;
  calibrationMm: number;
  ripenessScale: number;
  pulpFirmness: number;
  pulpTempC?: number;
  hasFlowerEnd: boolean;
  hasLatexStain: boolean;
  hasDamage?: boolean;
}) {
  let grade: 'Ekstra / A Kalite' | 'Sınıf 1 / B Kalite' | 'Sınıf 2 / C Kalite' | 'Sanayi / Fire' = 'Ekstra / A Kalite';
  const warnings: string[] = [];

  // Calibration check (Standard Extra: 39-46mm, Class 1: 36-38mm, Below 35mm: Class 2)
  if (params.calibrationMm < 36 || params.fingerLengthCm < 18) {
    grade = 'Sınıf 2 / C Kalite';
    warnings.push('Parmak boyu (<18cm) veya kalibrasyon (<36mm) asgari pazar standardının altında.');
  } else if (params.calibrationMm < 39 || params.fingerLengthCm < 20) {
    grade = 'Sınıf 1 / B Kalite';
  }

  // Defects impact
  if (params.hasFlowerEnd) {
    grade = 'Sanayi / Fire';
    warnings.push('Çiçek ucu çürüklüğü tespit edildi — paketlemeye uygun değil.');
  } else if (params.hasLatexStain || params.hasDamage) {
    if (grade === 'Ekstra / A Kalite') grade = 'Sınıf 1 / B Kalite';
  }

  // Temperature warning (Chilling injury risk < 13.0°C, Overheating > 16.0°C)
  if (params.pulpTempC !== undefined) {
    if (params.pulpTempC < 13.0) {
      warnings.push(`Kritik Soğuk Zararı (Chilling Injury) Riski! Meyve sıcaklığı (${params.pulpTempC}°C) 13.0°C'nin altında.`);
    } else if (params.pulpTempC > 16.0) {
      warnings.push(`Yüksek Sıcaklık Uyarısı! Meyve sıcaklığı (${params.pulpTempC}°C) erken olgunlaşma ve fire riskine yol açabilir.`);
    }
  }

  return { grade, warnings };
}

export interface AlmondGradeParams {
  sampleGram?: number;
  kernelGram?: number;
  seriousDefectPercent?: number;
  totalDefectPercent?: number;
  moisturePercent: number;
  waterActivityAw?: number;
  defSeriousGram?: number;
  defBrokenGram?: number;
  defDoubleGram?: number;
  defMechanicalGram?: number;
  defForeignGram?: number;
}

/**
 * Evaluates Almond UNECE / Commercial Classification based on lab results
 */
export function evaluateAlmondGrade(
  paramOrSerious: AlmondGradeParams | number,
  totalDefectPercent?: number,
  moisturePercent?: number
): { grade: 'Ekstra' | 'Sınıf 1' | 'Sınıf 2' | 'Sanayi / Yağlık'; safeToStore: boolean; warnings: string[] } {
  const warnings: string[] = [];

  let seriousDef = 0;
  let totalDef = 0;
  let moisture = 5.5;
  let aw = 0.55;

  if (typeof paramOrSerious === 'object') {
    moisture = paramOrSerious.moisturePercent;
    aw = paramOrSerious.waterActivityAw ?? 0.55;
    if (paramOrSerious.seriousDefectPercent !== undefined) {
      seriousDef = paramOrSerious.seriousDefectPercent;
    } else if (paramOrSerious.sampleGram && paramOrSerious.sampleGram > 0 && paramOrSerious.defSeriousGram !== undefined) {
      seriousDef = (paramOrSerious.defSeriousGram / paramOrSerious.sampleGram) * 100;
    }
    if (paramOrSerious.totalDefectPercent !== undefined) {
      totalDef = paramOrSerious.totalDefectPercent;
    } else if (paramOrSerious.sampleGram && paramOrSerious.sampleGram > 0) {
      const sumDefects = (paramOrSerious.defSeriousGram || 0) + (paramOrSerious.defBrokenGram || 0) + (paramOrSerious.defDoubleGram || 0) + (paramOrSerious.defMechanicalGram || 0) + (paramOrSerious.defForeignGram || 0);
      totalDef = (sumDefects / paramOrSerious.sampleGram) * 100;
    }
  } else {
    seriousDef = paramOrSerious;
    totalDef = totalDefectPercent ?? 0;
    moisture = moisturePercent ?? 5.5;
  }

  const safeToStore = moisture <= 6.0 && aw <= 0.65;

  if (moisture > 6.5) {
    warnings.push(`Yüksek Nem Uyarısı (%${moisture.toFixed(1)})! Küf ve aflatoksin gelişimi riski — acil kurutma gerekir.`);
  } else if (moisture > 6.0) {
    warnings.push(`Nem sınırı (%${moisture.toFixed(1)}) 6.0 standardının hafif üzerinde — yakın takip önerilir.`);
  }

  if (aw > 0.65) {
    warnings.push(`Yüksek Su Aktivitesi (aw ${aw.toFixed(2)})! Kritik küf eşiğinin (>0.65) üzerinde.`);
  }

  let grade: 'Ekstra' | 'Sınıf 1' | 'Sınıf 2' | 'Sanayi / Yağlık' = 'Ekstra';

  if (seriousDef > 2.0 || totalDef > 15.0) {
    grade = 'Sanayi / Yağlık';
    warnings.push('Kusur oranı tolerans limitlerini aşıyor — sadece sanayi/yağlık işlemeye uygundur.');
  } else if (seriousDef > 1.0 || totalDef > 10.0) {
    grade = 'Sınıf 2';
  } else if (seriousDef > 0.5 || totalDef > 5.0) {
    grade = 'Sınıf 1';
  }

  return { grade, safeToStore, warnings };
}

/**
 * Calculate Warehouse Weight Difference and Loss / Shrinkage Percentage
 */
export function calculateWarehouseFire(expectedKg: number, acceptedKg: number) {
  const diffKg = Number((acceptedKg - expectedKg).toFixed(2));
  const diffPercent = expectedKg > 0
    ? Number(((diffKg / expectedKg) * 100).toFixed(2))
    : 0;

  return { diffKg, diffPercent };
}

/**
 * Ripeness stages for bananas (1 to 7)
 */
export const BANANA_RIPENESS_STAGES = [
  { stage: 1, label: '1 - Tamamen Yeşil', nameTr: '1 - Tamamen Yeşil', color: '#15803d', colorHex: '#15803d', desc: 'Hasat ve uzun nakliye aşaması', description: 'Hasat ve uzun nakliye aşaması', textColor: '#ffffff' },
  { stage: 2, label: '2 - Açık Yeşil', nameTr: '2 - Açık Yeşil', color: '#22c55e', colorHex: '#22c55e', desc: 'Olgunlaştırma odasına giriş', description: 'Olgunlaştırma odasına giriş', textColor: '#ffffff' },
  { stage: 3, label: '3 - Yeşilden Sarıya Dönüş', nameTr: '3 - Yeşilden Sarıya Dönüş', color: '#84cc16', colorHex: '#84cc16', desc: 'Gazlama sonrası renk kırılması', description: 'Gazlama sonrası renk kırılması', textColor: '#0f172a' },
  { stage: 4, label: '4 - Sarı Yeşil Uçlu', nameTr: '4 - Sarı Yeşil Uçlu', color: '#eab308', colorHex: '#eab308', desc: 'Süpermarket sevkiyat standardı', description: 'Süpermarket sevkiyat standardı', textColor: '#0f172a' },
  { stage: 5, label: '5 - Sarı Yeşil Saplı', nameTr: '5 - Sarı Yeşil Saplı', color: '#facc15', colorHex: '#facc15', desc: 'Raf satışına hazır', description: 'Raf satışına hazır', textColor: '#0f172a' },
  { stage: 6, label: '6 - Tam Sarı', nameTr: '6 - Tam Sarı', color: '#fbbf24', colorHex: '#fbbf24', desc: 'Tüketime hazır ideal lezzet', description: 'Tüketime hazır ideal lezzet', textColor: '#0f172a' },
  { stage: 7, label: '7 - Benekli Sarı (Şekerli)', nameTr: '7 - Benekli Sarı (Şekerli)', color: '#d97706', colorHex: '#d97706', desc: 'Yüksek tatlılık, hızlı tüketim', description: 'Yüksek tatlılık, hızlı tüketim', textColor: '#ffffff' }
];

/**
 * Formats a date string into readable local Turkish format
 */
export function formatDateTime(isoString: string): string {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    return d.toLocaleString('tr-TR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoString;
  }
}

/**
 * Generates the full clean Google Apps Script Code.gs content ready to paste into Google Sheets
 */
export function generateGoogleAppsScriptCode(): string {
  // Tek kaynak: google-apps-script/Code.gs (Firestore → Sheets tek yönlü ayna)
  return gasCodeRaw;
}

/**
 * Sends a feedback or complaint record to the Google Apps Script Web App
 */
export async function submitFeedbackToGas(gasUrl: string, record: any, gasToken?: string): Promise<boolean> {
  if (!gasUrl) return false;
  try {
    const payload = {
      action: 'submitFeedback',
      token: gasToken || 'miwe-sec-token-2026',
      payload: {
        ...record,
        clientRecordId: record.id || `fb-${Date.now()}`
      }
    };
    const res = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload),
      mode: 'cors'
    });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const data = await res.json().catch(() => null);
    if (data && data.success === true) {
      return true;
    }
    if (data && data.success === false) {
      throw new Error(data.error || data.message || 'Google Sheets servisi işlemi reddetti');
    }
    return true;
  } catch (err) {
    console.warn('submitFeedbackToGas error:', err);
    throw err;
  }
}


