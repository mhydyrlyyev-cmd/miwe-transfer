import type { FieldRecord, HarvestRecord, ReferenceItem } from '../types';

/**
 * v3.8 — Olası RefID çakışmaları.
 * Aynı RefID altında FARKLI ürün veya FARKLI bahçe görünen kayıtlar listelenir.
 * (Aynı partiye birden çok test yapılması normaldir: ürün ve bahçe aynıysa çakışma sayılmaz.)
 * Eski sürümde günlük hasat her yeni partiye o günün "-001" numarasını veriyordu;
 * bu liste o dönemden kalan çakışmaları bulmak içindir.
 */
export interface RefConflict {
  refId: string;
  variants: { product: string; orchard: string; source: string; date?: string; count: number }[];
  /** Bu RefID altındaki farklı hasat tarihleri (sıralı) */
  dates: string[];
  reason: 'PRODUCT_OR_ORCHARD' | 'DATE_SPREAD';
}

const norm = (s?: string) => (s || '').trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');
/** "Hurma (Hachiya)" → "hurma"; "Garahan 1200, Kaka • Eksport…" → "garahan 1200, kaka" */
const baseProduct = (s?: string) => norm((s || '').split('(')[0]);
const baseOrchard = (s?: string) => norm((s || '').split('•')[0]);
/** Aynı RefID altındaki hasat tarihleri bu kadar günden fazla ayrıksa ayrı parti sayılır */
const MAX_HARVEST_SPREAD_DAYS = 3;

export function findRefConflicts(
  references: ReferenceItem[],
  harvestRecords: HarvestRecord[],
  fieldRecords: FieldRecord[]
): RefConflict[] {
  const map = new Map<string, Map<string, RefConflict['variants'][number]>>();
  const datesByRef = new Map<string, string[]>();
  const add = (refId: string | undefined, product: string | undefined, orchard: string | undefined, source: string, date?: string) => {
    if (!refId) return;
    const key = `${baseProduct(product)}|${baseOrchard(orchard)}`;
    if (key === '|') return;
    const byRef = map.get(refId) || new Map();
    const cur = byRef.get(key) || { product: (product || '—').trim(), orchard: (orchard || '—').trim(), source, date, count: 0 };
    cur.count++;
    if (date && (!cur.date || date < cur.date)) cur.date = date;
    if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) datesByRef.set(refId, [...(datesByRef.get(refId) || []), date]);
    byRef.set(key, cur);
    map.set(refId, byRef);
  };
  // referans kaydının kendisi tarih kıyasına girmez (oluşturma tarihi ≠ hasat tarihi)
  references.forEach(r => add(r.refId, r.product, r.orchard || r.location, 'Referans'));
  harvestRecords.forEach(h => add(h.refId, h.product, h.orchard, 'Günlük hasat', h.recordDate || (h.timestamp || '').slice(0, 10)));
  fieldRecords.forEach(f => add(f.refId, (f as any).product, (f as any).orchard, 'Saha testi', ((f as any).harvestDate || (f as any).timestamp || '').slice(0, 10)));

  const out: RefConflict[] = [];
  map.forEach((variants, refId) => {
    const list = [...variants.values()];
    const dates = [...(datesByRef.get(refId) || [])].sort();
    const spread = dates.length > 1 ? (Date.parse(dates[dates.length - 1]) - Date.parse(dates[0])) / 86400000 : 0;
    if (variants.size > 1 || spread > MAX_HARVEST_SPREAD_DAYS) {
      out.push({ refId, variants: list, dates: [...new Set(dates)], reason: variants.size > 1 ? 'PRODUCT_OR_ORCHARD' : 'DATE_SPREAD' });
    }
  });
  return out.sort((a, b) => b.variants.length - a.variants.length || a.refId.localeCompare(b.refId));
}
