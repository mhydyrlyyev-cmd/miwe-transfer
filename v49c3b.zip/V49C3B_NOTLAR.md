# v49c3b — v49c3 ekranlarından düzeltmeler

1. Yönetim analizi › Kişiler: aynı kişinin farklı yazılışı tek satır (Hydyrlyýew = Hydyrlyyew; ý, ň, ä, ž, ş, ç, ö, ü ve büyük/küçük harf farkı yok sayılır).
   Kişi yerine görev adı yazılan kayıtlar (Saha personeli, Saha kalite uzmanı, Depo kabul uzmanı, Deneme…) tek satırda: "Ad yazılmamış (görev adı)".
   Yalnız giriş yapıp kayıt girmeyen kişi (0 · 0 · 0) artık listede yok.
2. Bahçe ve depo: adlar kesilmiyor (iki satıra iner). Profili olmayan depolar (Datly Miwe vb.) tek satır: "Profilsiz depo (deneme)".
3. Rapor merkezi › Dikkat / uygun değil: parti sayfasıyla aynı sayım — tüm testler, test tarihine göre, her test bir kez.
4. Rapor merkezi › Durum ve hedefler: üstteki "← Ana sayfa" kaldırıldı; geri ok Rapor merkezine döner.
5. Ana sayfa şahit numune satırı kısaldı: "Şahit numune · 7. gün ölçümü" / altında RefID ve gün.
6. Test kaydı sayfasında ilk kutu "test şu an" yerine "Test · kayıt türü".

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (5 dosya)
f2b9a9d27fba36e842570122789f76da07097a5aa169357d3062b0ee12287bdd  src/App.tsx
b270537d380c4892a42d71fcc527ddf6e5432016d9e4af6d743b1c2bac42bf9a  src/services/analytics.ts
68e8f8cbcd4fac9948f79e553657751e5b0bfef6fa10a6c74480c9db36c1b956  src/components/views/ManagementViews.tsx
12a9fef2d70db11d73ca295f006444adf8f248a89e5069e7fa9665f18f12f926  src/components/dashboard/HomeDashboard.tsx
01197a91d0ac6412b42d878c51e66adbbe8caf2c735d54d150be815a4214bb9c  src/components/views/LotsView.tsx
