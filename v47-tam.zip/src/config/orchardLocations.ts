/**
 * v46 — Bahçe konumları (kullanıcının verdiği Google Haritalar noktaları, 22.11.2026).
 * v49 hasat takviminde hava durumu (Open-Meteo) ve sezon stresi puanı için kullanılır.
 * `aliases`: platform kayıtlarında bahçenin başka yazılışları (eşleştirme için).
 */
export interface OrchardLocation {
  key: string;
  name: string;
  region: string;
  lat: number;
  lon: number;
  note?: string;
  aliases?: string[];
}

export const ORCHARD_LOCATIONS: OrchardLocation[] = [
  { key: 'bagyr', name: 'Bagyr', region: 'Aşgabat', lat: 37.988616, lon: 58.184727, note: 'Nektarin', aliases: ['bagir', 'bagyr'] },
  { key: 'durun', name: 'Durun', region: 'Baherden (Ahal)', lat: 38.383322, lon: 57.432445, aliases: ['durun', 'baherden'] },
  { key: 'saywan-gursak', name: 'Saýwan Gursak', region: 'Balkan', lat: 38.534368, lon: 56.743097, aliases: ['saywan gursak', 'saýwan gursak', 'gursak'] },
  { key: 'saywan-nektarin', name: 'Saýwan Nektarin', region: 'Balkan', lat: 38.537343, lon: 56.720592, note: 'Nektarin', aliases: ['saywan nektarin', 'saýwan nektarin'] },
  { key: 'garahan-1200', name: 'Garahan 1200 ha', region: 'Ahal', lat: 37.211482, lon: 59.813087, note: 'MIWE OJSC merkezi', aliases: ['garahan 1200', '1200 ha'] },
  { key: 'garahan-1600', name: 'Garahan 1600 ha', region: 'Ahal', lat: 37.190531, lon: 59.888403, aliases: ['garahan 1600', '1600 ha'] },
];

/** Bahçe adına göre konum (büyük/küçük harf ve Türkmen harfleri esnek). */
export function findOrchardLocation(name?: string): OrchardLocation | undefined {
  const n = String(name || '').toLocaleLowerCase('tr').replace(/ý/g, 'y');
  if (!n) return undefined;
  return ORCHARD_LOCATIONS.find(o => (o.aliases || []).some(a => n.includes(a.replace(/ý/g, 'y'))) || n.includes(o.name.toLocaleLowerCase('tr').replace(/ý/g, 'y')));
}
