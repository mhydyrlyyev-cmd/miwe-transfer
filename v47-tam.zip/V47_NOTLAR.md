# v47 (a) — Formlar ana sayfa tasarım dilinde

12 form dosyası + SmartField. Hesaplama, kayıt ve alan mantığına dokunulmadı; yalnız görünüm.

## Ne değişti
- Koyu lacivert / koyu yeşil başlıklar ve bilgi kutuları beyaz karta döndü (Hasat, Saha testi, Depo kabul, Lojistik, Satış, Badem, Muz, Freeze-dry, Akt, İhracat numunesi).
- Renk geçişli (gradient) zeminler kaldırıldı; birincil düğmeler tek renk yeşil.
- BÜYÜK HARF başlıklar normal yazıma döndü; emoji başlık/seçeneklerden çıkarıldı (kayıtlı değerler değişmedi).
- Kod yazısı (mono) yerine normal yazı + hizalı rakam.
- Kalın renkli çift kenarlar ince gri kenara döndü.
- Form başlıkları kısaldı: "Günlük hasat", "Saha kalite testi", "Depo kabul ve oda takibi", "Lojistik ve sevkiyat", "Satış ve sevkiyat çıkışı", "Muz kalite ve sarartma testi", "Badem kalite ve hasat testi", "Freeze-dry işleme", "Kalite sapması ve akt", "İhracat numunesi ve raf ömrü testi".
- Telefonda başlık satırı alt alta dizilir (Depo kabul, Lojistik).
- Yanlış kaynak atfı düzeltildi: elma Brix 12 "OECD FFV-01" değil iç hedef.
- "+ + Yeni ekle" çift artı düzeltildi.

## Silinecek
src/components/common/PhotoUpload.tsx (hiçbir yerden import edilmiyor; formlardaki "handlePhotoUpload" ayrı bir fonksiyon)

DeployRules: GEREKMEZ. Yeni paket yok.

## Ek
src/config/orchardLocations.ts bu pakette yeniden veriliyor (projedeki sürümde bahçe adları eski: "1200 ha bahçe"). Yeni: "Garahan 1200 ha", "Garahan 1600 ha".
