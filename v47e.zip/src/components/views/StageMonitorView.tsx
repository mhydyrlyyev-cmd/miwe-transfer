import React, { useMemo, useState } from 'react';
import { Snowflake, Truck, Timer, Search, Thermometer, ArrowRight, Leaf } from 'lucide-react';
import type { AmbarRecord, BalanceAdjustment, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { analyzeColdChain } from '../../utils/coldChainEngine';
import { ALERT_STAGE, STAGE_BY_KEY } from '../../config/processStages';
import ColdChainPanel from '../coldchain/ColdChainPanel';
import { Button, EmptyState, PageHeader, StageRail } from '../ui';

/**
 * v3.6 — Aşama izleme sayfası (yalnızca o aşama):
 *   PRECOOLING → sahadaki partiler, ön soğutmadaki fişler, açık bakiye, 1-MCP
 *   TRANSIT    → yoldaki yükler, gün sayısı, sıcaklık, varış
 * Depo odaları ayrı sayfadadır (Soğuk Depo); veriler karışmaz.
 */
interface Props {
  stage: 'HASAT' | 'ON_SOGUTMA' | 'SEVK';
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onNavigate: (view: string) => void;
  onOpenPrecooling: (ref: ReferenceItem) => void;
  onOpenRecord: (refId: string) => void;
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onBack: () => void;
}

const kgFmt = (v: number) => `${Math.round(v).toLocaleString('tr-TR')} kg`;
const hFmt = (h: number) => (h < 48 ? `${Math.round(h)} sa` : `${Math.round(h / 24)} gün`);

export default function StageMonitorView(p: Props) {
  const [q, setQ] = useState('');
  const summary = useMemo(() => analyzeColdChain({
    references: p.references, harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords,
    lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords,
  }), [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);

  const badges = useMemo(() => {
    const b: Record<string, number> = {};
    for (const a of summary.alerts) if (a.level !== 'info') b[ALERT_STAGE[a.kind]] = (b[ALERT_STAGE[a.kind]] || 0) + 1;
    return b;
  }, [summary.alerts]);

  const match = (r: ReferenceItem) => {
    const s = q.trim().toLocaleLowerCase('tr');
    return !s || [r.refId, r.product, r.variety, r.orchard, r.location].some(x => (x || '').toLocaleLowerCase('tr').includes(s));
  };

  const st = STAGE_BY_KEY[p.stage];
  const isPre = p.stage === 'ON_SOGUTMA';
  const isHarvest = p.stage === 'HASAT';

  // ── Ön soğutma verileri ──
  const fieldLots = summary.lots.filter(l => l.ref.status === 'CREATED' && match(l.ref));
  const openNow = fieldLots.filter(l => l.precoolOpen);
  const waitingKg = fieldLots.reduce((a, l) => a + Math.max(0, l.slipsTracked ? l.openBalanceKg : l.harvestKg), 0);
  const mcpPending = fieldLots.filter(l => l.mcp.required && !l.mcp.decision).length;

  // ── Sevk verileri ──
  const refMap = new Map(p.references.map(r => [r.refId, r]));
  const now = Date.now();
  const shipments = p.lojistikRecords
    .filter(l => l.status !== 'DELIVERED')
    .map(l => ({ l, ref: refMap.get(l.refId) }))
    .filter(x => x.ref && (x.ref.status === 'SHIPPED' || x.ref.status === 'IN_TRANSIT') && match(x.ref))
    .map(x => {
      const start = Date.parse(x.l.loadingDate || x.l.shipmentDate || x.l.timestamp);
      const hrs = Number.isFinite(start) ? Math.max(0, (now - start) / 3600000) : null;
      const limit = Number(x.l.transitDays) > 0 ? Number(x.l.transitDays) : 3;
      return { ...x, hrs, limit, late: hrs !== null && hrs / 24 > limit };
    })
    .sort((a, b) => (b.hrs ?? 0) - (a.hrs ?? 0));
  const transitKg = shipments.reduce((a, s) => a + (Number(s.l.weightKg) || 0), 0);

  // ── Hasat (saha) verileri — v47e ──
  const todayStr = new Date().toISOString().slice(0, 10);
  const harvestToday = p.harvestRecords.filter(h => String(h.recordDate || h.timestamp || '').slice(0, 10) === todayStr);
  const harvestTodayKg = harvestToday.reduce((a, h) => a + (Number(h.dailyTotalKg) || 0), 0);
  const activeDrafts = p.harvestRecords.filter(h => h.status === 'ACTIVE').length;

  const tiles = isHarvest
    ? [
        { label: 'Sahadaki parti', value: fieldLots.length },
        { label: 'Bugün hasat', value: kgFmt(harvestTodayKg) },
        { label: 'Açık (taslak) kayıt', value: activeDrafts },
      ]
    : isPre
    ? [
        { label: 'Sahadaki parti', value: fieldLots.length },
        { label: 'Şu an ön soğutmada', value: openNow.length },
        { label: 'Ön soğutma bekleyen', value: kgFmt(waitingKg) },
        { label: '1-MCP kararı bekleyen', value: mcpPending },
      ]
    : [
        { label: 'Yoldaki sevk', value: shipments.length },
        { label: 'Yoldaki miktar', value: kgFmt(transitKg) },
        { label: 'Geciken', value: shipments.filter(s => s.late).length },
      ];

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader
        onBack={p.onBack}
        title={isHarvest ? 'Hasat' : isPre ? 'Ön soğutma' : 'Yoldaki yükler'}
        subtitle={isHarvest ? 'Sahadaki partiler ve bugünkü hasat. Yeni kayıt için düğmeyi kullanın.' : isPre ? 'Hasattan gelen partiler, şoklama süresi, açık bakiye ve 1-MCP — yalnızca ön soğutma.' : 'Sevk edilmiş, henüz teslim edilmemiş yükler — yalnızca lojistik.'}
        actions={isHarvest && !p.isReadOnly ? <Button size="sm" tone="emerald" icon={<Leaf />} onClick={() => p.onNavigate('HARVEST')}>Yeni hasat</Button> : undefined}
      />
      <StageRail current={p.stage} mode="monitor" onNavigate={p.onNavigate} badges={badges} />

      <div className={`grid gap-2 ${tiles.length === 4 ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-3'}`}>
        {tiles.map(t => (
          <div key={t.label} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2.5">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">{t.label}</div>
            <div className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{t.value}</div>
          </div>
        ))}
      </div>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, ürün, bahçe ara…" aria-label="Ara"
          className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white pl-9 pr-3 text-sm dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100" />
      </div>

      {isHarvest ? (
        <section className="space-y-2">
          {fieldLots.length === 0 && <EmptyState icon={<Leaf className="w-5 h-5" />} title="Sahada parti yok" description="Yeni hasat kaydı açınca parti burada görünür." />}
          {fieldLots.slice(0, 60).map(l => (
            <article key={l.ref.refId} className="relative rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-4 pr-3 py-3 overflow-hidden">
              <span aria-hidden="true" className="absolute left-0 top-0 bottom-0 w-1.5 bg-emerald-600" />
              <div className="flex items-start justify-between gap-2">
                <button type="button" onClick={() => p.onOpenRecord(l.ref.refId)} className="text-left min-w-0">
                  <div className="text-sm font-bold tabular-nums text-emerald-800 dark:text-emerald-300">{l.ref.refId}</div>
                  <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{l.ref.product}{l.ref.orchard ? ` · ${l.ref.orchard}` : ''}</div>
                </button>
                <span className="shrink-0 text-sm font-bold tabular-nums text-slate-900 dark:text-white">{kgFmt(l.harvestKg)}</span>
              </div>
              <div className="mt-1 text-[11px] text-slate-500">
                {l.precooledKg > 0 ? `Ön soğutmaya giren ${kgFmt(l.precooledKg)}` : l.directToStoreKg > 0 ? `Doğrudan depoya ${kgFmt(l.directToStoreKg)} (ön soğutmasız)` : 'Henüz ön soğutmaya girmedi'}
              </div>
              {!p.isReadOnly && (
                <div className="mt-2 flex justify-end gap-2">
                  <Button size="sm" variant="soft" tone="sky" icon={<Snowflake />} onClick={() => p.onOpenPrecooling(l.ref)}>Ön soğutma fişi</Button>
                </div>
              )}
            </article>
          ))}
        </section>
      ) : isPre ? (
        <section className="space-y-2">
          {fieldLots.length === 0 && <EmptyState icon={<Leaf className="w-5 h-5" />} title="Sahada parti yok" description="Günlük hasat kaydı açılınca partiler burada ön soğutma sırası bekler." />}
          {fieldLots.slice(0, 60).map(l => {
            const pct = l.harvestKg > 0 ? Math.min(100, Math.round((l.precooledKg / l.harvestKg) * 100)) : 0;
            const lotAlerts = summary.alerts.filter(a => a.refId === l.ref.refId && ALERT_STAGE[a.kind] === 'ON_SOGUTMA');
            const worst = lotAlerts.find(a => a.level === 'critical') || lotAlerts.find(a => a.level === 'warning');
            const bar = worst?.level === 'critical' ? 'bg-rose-500' : worst?.level === 'warning' ? 'bg-amber-500' : 'bg-sky-500';
            return (
              <article key={l.ref.refId} className="relative rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-4 pr-3 py-3 overflow-hidden">
                <span aria-hidden="true" className={`absolute left-0 top-0 bottom-0 w-1.5 ${bar}`} />
                <div className="flex items-start justify-between gap-2">
                  <button type="button" onClick={() => p.onOpenRecord(l.ref.refId)} className="text-left min-w-0">
                    <div className="text-sm font-bold tabular-nums text-sky-800 dark:text-sky-300">{l.ref.refId}</div>
                    <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{l.ref.product}{l.ref.orchard ? ` · ${l.ref.orchard}` : ''}</div>
                  </button>
                  <div className="flex flex-wrap gap-1 justify-end">
                    {l.precoolOpen && l.precoolH !== null && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-900 dark:bg-sky-900/50 dark:text-sky-100"><Timer className="w-3 h-3" />{hFmt(l.precoolH)} ön soğutmada</span>
                    )}
                    {l.mcp.required && (
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                        1-MCP: {l.mcp.appliedAt ? 'uygulandı' : l.mcp.decision === 'NO' ? 'hayır' : l.mcp.decision === 'YES' ? `evet · ${l.mcp.daysLeft} gün` : `karar yok · ${l.mcp.daysLeft} gün`}
                      </span>
                    )}
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex justify-between text-[11px] text-slate-600 dark:text-slate-300 mb-1">
                    <span>Ön soğutma {kgFmt(l.precooledKg)} / hasat {kgFmt(l.harvestKg)}</span>
                    <span className="font-bold">{l.openBalanceKg > 0 && l.slipsTracked ? `${kgFmt(l.openBalanceKg)} bekliyor` : `%${pct}`}</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-sky-500" style={{ width: `${pct}%` }} /></div>
                </div>
                {worst && <p className={`mt-2 text-xs font-semibold ${worst.level === 'critical' ? 'text-rose-700 dark:text-rose-300' : 'text-amber-700 dark:text-amber-300'}`}>{worst.title} — {worst.actions[0]}</p>}
                {!p.isReadOnly && (
                  <div className="mt-2 flex justify-end">
                    <Button size="sm" variant="soft" tone="sky" icon={<Snowflake />} onClick={() => p.onOpenPrecooling(l.ref)}>{l.precoolOpen ? 'Yeni fiş / kapat' : 'Ön soğutma fişi'}</Button>
                  </div>
                )}
              </article>
            );
          })}
        </section>
      ) : (
        <section className="space-y-2">
          {shipments.length === 0 && <EmptyState icon={<Truck className="w-5 h-5" />} title="Yolda yük yok" description="Sevk kaydı açılan ve teslim edilmeyen yükler burada görünür." />}
          {shipments.slice(0, 60).map(s => (
            <article key={s.l.id} className="relative rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-4 pr-3 py-3 overflow-hidden">
              <span aria-hidden="true" className={`absolute left-0 top-0 bottom-0 w-1.5 ${s.late ? 'bg-rose-500' : 'bg-amber-500'}`} />
              <div className="flex items-start justify-between gap-2">
                <button type="button" onClick={() => p.onOpenRecord(s.l.refId)} className="text-left min-w-0">
                  <div className="text-sm font-bold tabular-nums text-amber-800 dark:text-amber-300">{s.l.refId}</div>
                  <div className="text-xs text-slate-600 dark:text-slate-400 truncate">{s.ref?.product}{s.l.kaliteSinifi ? ` · ${s.l.kaliteSinifi}` : ''}</div>
                </button>
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${s.late ? 'bg-rose-100 text-rose-900' : 'bg-amber-100 text-amber-900'}`}>
                  {s.hrs !== null ? `${hFmt(s.hrs)} yolda` : 'tarih yok'} · beklenen {s.limit} gün
                </span>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-700 dark:text-slate-300">
                <span className="inline-flex items-center gap-1 font-semibold">{s.l.source || '—'} <ArrowRight className="w-3 h-3" /> {s.l.destination || '—'}</span>
                <span>{s.l.vehiclePlate || '—'}{s.l.driver ? ` · ${s.l.driver}` : ''}</span>
                <span>{kgFmt(Number(s.l.weightKg) || 0)}</span>
                {(s.l.departureTemperature !== undefined || s.l.transitTemperature !== undefined) && (
                  <span className="inline-flex items-center gap-1"><Thermometer className="w-3 h-3" />{s.l.departureTemperature ?? '—'} → {s.l.transitTemperature ?? '—'} °C</span>
                )}
                {s.l.splitLots && s.l.splitLots.length > 0 && <span>{s.l.splitLots.length} sınıf</span>}
              </div>
            </article>
          ))}
        </section>
      )}

      {!isHarvest && <div>
        <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">{st.label} uyarıları ve analiz</h2>
        <ColdChainPanel
          stage={p.stage}
          references={p.references} harvestRecords={p.harvestRecords} ambarRecords={p.ambarRecords}
          lojistikRecords={p.lojistikRecords} salesRecords={p.salesRecords}
          currentUserName={p.currentUserName} isReadOnly={p.isReadOnly}
          onAddBalanceAdjustment={p.onAddBalanceAdjustment}
          onOpenPrecooling={isPre ? p.onOpenPrecooling : undefined}
          onOpenRecord={p.onOpenRecord}
        />
      </div>}
    </div>
  );
}
