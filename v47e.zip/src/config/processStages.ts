/**
 * v3.6 — Süreç Aşamaları (tek kaynak)
 *
 * Her aşamanın KENDİ sayfası, KENDİ kaydı, KENDİ kontrolleri ve KENDİ uyarıları vardır.
 * Bir aşamanın verisi başka aşamanın formunda girilmez; aşamalar yalnızca RefID ile bağlanır.
 *
 *   HASAT  →  ÖN SOĞUTMA  →  SOĞUK DEPO  →  SEVK / LOJİSTİK
 *                 (kalite kontrol her aşamada, o aşamanın kendi ölçümleriyle)
 */
import type { AlertKind } from '../utils/coldChainEngine';

export type StageKey = 'HASAT' | 'ON_SOGUTMA' | 'SOGUK_DEPO' | 'SEVK';

export interface StageDef {
  key: StageKey;
  no: number;
  label: string;
  short: string;
  /** Tailwind renk adı — aşamanın her yerdeki vurgu rengi */
  color: 'emerald' | 'sky' | 'indigo' | 'amber';
  /** Kayıt sayfası (form) ve izleme sayfası (liste / uyarılar) — App activeView anahtarları */
  entryView: string;
  monitorView?: string;
  entryLabel: string;
  monitorLabel?: string;
  /** Bu aşamada kaydedilenler */
  records: string[];
  /** Bu aşamada KAYDEDİLMEYENLER (başka aşamanın işi) — karışmayı önler */
  notHere: { what: string; where: StageKey }[];
  /** Bu aşamanın kalite kontrol noktaları */
  quality: string[];
}

export const STAGES: StageDef[] = [
  {
    key: 'HASAT', no: 1, label: 'Günlük Hasat', short: 'Hasat', color: 'emerald',
    entryView: 'HARVEST', entryLabel: 'Hasat kaydı', monitorView: 'HARVEST_STATUS', monitorLabel: 'Sahadaki partiler',
    records: ['Bahçe, parsel, ürün, çeşit', 'Hasat kg (tartıldıysa), işçi, ekip', 'Hasat günü / saati', 'Bağlı hasat öncesi testler'],
    notHere: [
      { what: 'Şoklama, meyve içi sıcaklık, 1-MCP', where: 'ON_SOGUTMA' },
      { what: 'Depo, oda, istif yeri', where: 'SOGUK_DEPO' },
    ],
    quality: ['Hasat öncesi test (sertlik, Brix, nişasta)', 'Görsel kalite / kalite sınıfı', 'Sorting veya %5 inspeksiyon 12 saat içinde'],
  },
  {
    key: 'ON_SOGUTMA', no: 2, label: 'Ön Soğutma', short: 'Ön soğutma', color: 'sky',
    entryView: 'PRECOOLING', monitorView: 'PRECOOLING', entryLabel: 'Ön soğutma fişi', monitorLabel: 'Ön soğutma izleme',
    records: ['Ön soğutma fişi: net kg, başlangıç–bitiş', 'Meyve içi sıcaklık önce / sonra', '%5 inspeksiyon veya sorting, ıskarta kg', '1-MCP kararı ve saati', 'Sonrası: aynı yerde stok / hedef oda'],
    notHere: [
      { what: 'Bahçe, işçi, hasat tonajı', where: 'HASAT' },
      { what: 'Depo içi periyodik kontroller', where: 'SOGUK_DEPO' },
    ],
    quality: ['Hasat → ön soğutma süresi', 'Meyve içi sıcaklık düşüşü', 'Sınıf dağılımı (%5) ve kalibre', '1-MCP süre sınırı'],
  },
  {
    key: 'SOGUK_DEPO', no: 3, label: 'Soğuk Depo', short: 'Depo', color: 'indigo',
    entryView: 'AMBAR', monitorView: 'COLD_STORAGE', entryLabel: 'Depo kabul', monitorLabel: 'Oda izleme',
    records: ['Depo kabul: depo, oda, istif, kabul kg', 'Süre sınıfı (direkt / kısa / orta / uzun)', 'Periyodik oda kontrolü: set, oda, meyve içi, RH%, O₂/CO₂', 'Oda değişikliği (taşıma)'],
    notHere: [
      { what: 'Şoklama ve 1-MCP', where: 'ON_SOGUTMA' },
      { what: 'Araç, şoför, reefer, varış', where: 'SEVK' },
    ],
    quality: ['Kabul numunesi (kutu muayenesi, GOST)', 'Sertlik / Brix / çürük % eğilimi', 'Kontrol sıklığı süre sınıfına göre'],
  },
  {
    key: 'SEVK', no: 4, label: 'Sevk / Lojistik', short: 'Sevk', color: 'amber',
    entryView: 'LOJISTIK', monitorView: 'TRANSIT', entryLabel: 'Sevk kaydı', monitorLabel: 'Yoldaki yükler',
    records: ['Araç, şoför, plaka, konteyner / mühür', 'Kalkış ve yol sıcaklığı, reefer, datalogger', 'Varış (iç pazar / ihracat / numune)', 'Sınıflara göre kg (bir araçta birden çok sınıf)'],
    notHere: [
      { what: 'Oda kontrolleri ve set değerleri', where: 'SOGUK_DEPO' },
      { what: 'Ön soğutma ölçümleri', where: 'ON_SOGUTMA' },
    ],
    quality: ['Yükleme öncesi meyve içi sıcaklık', 'Yol sıcaklığı / datalogger sapması', 'Varışta kabul veya akt (incident)'],
  },
];

export const STAGE_BY_KEY: Record<StageKey, StageDef> = Object.fromEntries(STAGES.map(s => [s.key, s])) as Record<StageKey, StageDef>;

/** Uyarı türü → aşama (uyarılar yalnızca kendi aşamasının sayfasında görünür) */
export const ALERT_STAGE: Record<AlertKind, StageKey> = {
  OPEN_BALANCE: 'ON_SOGUTMA',
  OVER_BALANCE: 'ON_SOGUTMA',
  HARVEST_TO_PRECOOL: 'ON_SOGUTMA',
  PRECOOL_DURATION: 'ON_SOGUTMA',
  TARGET_ROOM_MISSING: 'ON_SOGUTMA',
  MCP_UNDECIDED: 'ON_SOGUTMA',
  MCP_DEADLINE: 'ON_SOGUTMA',
  ROOM_CHECK_DUE: 'SOGUK_DEPO',
  TERM_EXCEEDED: 'SOGUK_DEPO',
  TRANSIT_LONG: 'SEVK',
};

/** Sabit Tailwind sınıfları (dinamik sınıf adı üretmeden) */
export const STAGE_TONE: Record<StageDef['color'], { solid: string; soft: string; text: string; ring: string; dot: string }> = {
  emerald: { solid: 'bg-emerald-600 text-white', soft: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900', text: 'text-emerald-700 dark:text-emerald-300', ring: 'ring-emerald-500', dot: 'bg-emerald-500' },
  sky: { solid: 'bg-sky-600 text-white', soft: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200 dark:border-sky-900', text: 'text-sky-700 dark:text-sky-300', ring: 'ring-sky-500', dot: 'bg-sky-500' },
  indigo: { solid: 'bg-indigo-600 text-white', soft: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900', text: 'text-indigo-700 dark:text-indigo-300', ring: 'ring-indigo-500', dot: 'bg-indigo-500' },
  amber: { solid: 'bg-amber-500 text-white', soft: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900', text: 'text-amber-700 dark:text-amber-300', ring: 'ring-amber-500', dot: 'bg-amber-500' },
};

/** activeView → aşama (şerit hangi aşamayı vurgulasın) */
export function stageForView(view: string): StageKey | null {
  for (const s of STAGES) if (s.entryView === view || s.monitorView === view) return s.key;
  return null;
}
