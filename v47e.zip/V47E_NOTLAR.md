# v47e — Ana sayfa sadeleştirme + Hasat durum sayfası

## Neden
- Ana sayfadaki "Son eklenen kayıtlar" listesi kaldırıldı; yerinde tek satır "Kayıtlar · n parti → Referanslar'da aç". Tam liste Referanslar ekranında.
- Ana menüde "Hasat" kutusu doğrudan boş formu açıyordu. Artık Ön soğutma ve Sevk gibi durum sayfası açılır: sahadaki partiler, bugünkü hasat kg, açık taslaklar, "Yeni hasat" düğmesi. Yeni kayıt "Hızlı kayıt › Yeni hasat" ile de açılır.
- Ön soğutmasız depoya alınan parti hasat sayfasında "Doğrudan depoya (ön soğutmasız)" diye görünür.
- Ana menü başlıkları büyük harften normal yazıya geçti (Süreç, Hızlı kayıt, Adım 1…).

## SHA-256 (4 dosya)
0ca99ae10fc6c1df8436d3ce136a33977ec01d49bdbc8e9a0e46c4f7e9ac251e  src/App.tsx
80e37884dee8ea79fba6876ea127f001cfad48fe82120a94ea0a8307bfb01053  src/components/portal/HomeMenu.tsx
4aaf6e5a4844c476637be35c9f9e972dff553318e49cc534ffc62687dd496945  src/components/views/StageMonitorView.tsx
1a28131f6e2aaa1c1021da1bf8fc623a07331664312d61bcde750a0af5586b2f  src/config/processStages.ts
