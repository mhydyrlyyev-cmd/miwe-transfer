import React, { useState, useEffect } from 'react';
import { Lock, Unlock, Plus, Check } from 'lucide-react';
import { optionsService } from '../../services/optionsService';

interface SmartInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  label: string;
  categoryKey?: string;
  required?: boolean;
  isLocked?: boolean;
  onToggleLock?: () => void;
  helperText?: string;
  onChange?: (e: any) => void;
}

export const SmartInput: React.FC<SmartInputProps> = ({
  label,
  value,
  required = false,
  isLocked = false,
  onToggleLock,
  helperText,
  className = '',
  categoryKey: _categoryKey,
  onChange,
  ...props
}) => {
  const isFilled = value !== undefined && value !== null && String(value).trim().length > 0;
  
  // Unfilled required field style vs normal filled style vs locked style
  const fieldStyle = isLocked
    ? 'bg-slate-100/80 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed font-medium shadow-inner-subtle'
    : required && !isFilled
    ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-400/90 text-amber-950 dark:text-amber-200 placeholder:text-amber-500/60 focus:ring-3 focus:ring-amber-500/20 focus:border-amber-500 shadow-inner-subtle'
    : 'bg-white dark:bg-slate-900/90 border-slate-300/90 dark:border-slate-700/80 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:ring-3 focus:ring-teal-500/20 focus:border-teal-600 shadow-inner-subtle';

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e);
    }
  };

  return (
    <div className="w-full space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
          {label} {required && <span className="text-amber-600 dark:text-amber-400 font-bold">*</span>}
        </label>
        {onToggleLock && (
          <button
            type="button"
            onClick={onToggleLock}
            title={isLocked ? 'Değiştirmek için Kilidi Aç / Unlock' : 'Alanı Kilitle / Lock'}
            className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition-all btn-tactile cursor-pointer"
          >
            {isLocked ? (
              <>
                <Lock className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                <span>Kilitli</span>
              </>
            ) : (
              <>
                <Unlock className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                <span>Açık</span>
              </>
            )}
          </button>
        )}
      </div>

      <input
        {...props}
        value={value}
        disabled={isLocked || props.disabled}
        onChange={handleChange}
        className={`w-full px-3.5 py-2.5 text-sm sm:text-base rounded-xl border transition-all outline-none min-h-[46px] ${fieldStyle} ${className}`}
      />

      {required && !isFilled && !isLocked && (
        <p className="text-[11px] text-amber-700 dark:text-amber-400 font-medium flex items-center gap-1">
          <span>* Doldurulması zorunlu alan</span>
        </p>
      )}
      {helperText && isFilled && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">{helperText}</p>
      )}
    </div>
  );
};

interface SmartCreatableSelectProps {
  label: string;
  categoryKey: string;
  options: string[];
  value: string;
  onChange: (val: string) => void;
  productContext?: string;
  required?: boolean;
  isLocked?: boolean;
  disabled?: boolean;
  onToggleLock?: () => void;
  placeholder?: string;
  helperText?: string;
}

export const SmartCreatableSelect: React.FC<SmartCreatableSelectProps> = ({
  label,
  categoryKey,
  options: initialOptions,
  value,
  onChange,
  productContext,
  required = false,
  isLocked = false,
  disabled = false,
  onToggleLock,
  placeholder = 'Seçiniz veya yeni yazınız...',
  helperText
}) => {
  const [serviceOptions, setServiceOptions] = useState<string[]>(() => {
    return optionsService.getOptions(categoryKey, productContext);
  });

  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newOptionText, setNewOptionText] = useState('');

  useEffect(() => {
    const handleSync = () => {
      setServiceOptions(optionsService.getOptions(categoryKey, productContext));
    };
    handleSync();
    window.addEventListener('miwe_options_updated', handleSync);
    return () => window.removeEventListener('miwe_options_updated', handleSync);
  }, [categoryKey, productContext]);

  const combinedOptions = Array.from(
    new Set([...serviceOptions, ...(initialOptions || [])])
  ).filter(Boolean);

  const handleAddNew = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newOptionText.trim();
    if (!trimmed) return;

    optionsService.addOption(categoryKey, trimmed, undefined, productContext);
    onChange(trimmed);
    setNewOptionText('');
    setIsAddingNew(false);
  };

  const isFilled = Boolean(value && String(value).trim().length > 0);
  const isEffectivelyLocked = isLocked || disabled;

  const selectStyle = isEffectivelyLocked
    ? 'bg-slate-100/80 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed font-medium shadow-inner-subtle'
    : required && !isFilled
    ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-400/90 text-amber-950 dark:text-amber-200 focus:ring-3 focus:ring-amber-500/20 focus:border-amber-500 shadow-inner-subtle'
    : 'bg-white dark:bg-slate-900/90 border-slate-300/90 dark:border-slate-700/80 text-slate-900 dark:text-slate-100 focus:ring-3 focus:ring-teal-500/20 focus:border-teal-600 shadow-inner-subtle';

  return (
    <div className="w-full space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
          {label} {required && <span className="text-amber-600 dark:text-amber-400 font-bold">*</span>}
        </label>
        
        <div className="flex items-center gap-1.5">
          {!isEffectivelyLocked && (
            <button
              type="button"
              onClick={() => setIsAddingNew(!isAddingNew)}
              className="text-[11px] font-semibold text-teal-800 dark:text-teal-300 hover:text-teal-900 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/60 border border-teal-200/80 dark:border-teal-800/60 px-2 py-0.5 rounded-lg transition-all flex items-center gap-1 btn-tactile cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>{isAddingNew ? 'Listeden seç' : 'Yeni ekle'}</span>
            </button>
          )}

          {onToggleLock && (
            <button
              type="button"
              onClick={onToggleLock}
              title={isLocked ? 'Değiştirmek için Kilidi Aç / Unlock' : 'Alanı Kilitle / Lock'}
              className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition-all btn-tactile cursor-pointer"
            >
              {isLocked ? (
                <>
                  <Lock className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                  <span>Kilitli</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                  <span>Açık</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {isAddingNew && !isLocked ? (
        <div className="flex items-center gap-1.5">
          <input
            type="text"
            value={newOptionText}
            onChange={(e) => setNewOptionText(e.target.value)}
            placeholder="Yeni değer yazın (örn: Scarlet Spur, B-Z)"
            className="flex-1 px-3.5 py-2.5 text-sm rounded-xl border border-teal-500 bg-teal-50/40 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-3 focus:ring-teal-500/20 shadow-inner-subtle"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAddNew();
              }
            }}
          />
          <button
            type="button"
            onClick={() => handleAddNew()}
            className="px-3.5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 btn-tactile cursor-pointer shadow-xs"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Ekle</span>
          </button>
          <button
            type="button"
            onClick={() => setIsAddingNew(false)}
            className="px-2.5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold shrink-0 btn-tactile cursor-pointer"
          >
            İptal
          </button>
        </div>
      ) : (
        <div className="relative">
          <select
            value={value}
            disabled={isLocked}
            onChange={(e) => {
              if (e.target.value === '__ADD_NEW__') {
                setIsAddingNew(true);
              } else {
                onChange(e.target.value);
              }
            }}
            className={`w-full px-3.5 py-2.5 text-sm sm:text-base rounded-xl border transition-all outline-none min-h-[46px] ${selectStyle}`}
          >
            <option value="">{placeholder}</option>

            {/* Current value if not in options */}
            {value && value !== '__ADD_NEW__' && !combinedOptions.includes(value) && (
              <option value={value}>
                {value} (Mevcut / Özel)
              </option>
            )}

            {/* Available Options */}
            {combinedOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}

            <option value="__ADD_NEW__" className="font-bold text-teal-700 bg-teal-50">
              ➕ + Yeni Seçenek Ekle (Hafızaya Kaydet)...
            </option>
          </select>
        </div>
      )}

      {required && !isFilled && !isLocked && (
        <p className="text-[11px] text-amber-700 dark:text-amber-400 font-medium flex items-center gap-1">
          <span>* Doldurulması zorunlu alan</span>
        </p>
      )}
      {helperText && isFilled && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">{helperText}</p>
      )}
    </div>
  );
};

