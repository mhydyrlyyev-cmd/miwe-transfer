import React, { useState, useMemo, useRef } from 'react';
import { Banana, ArrowLeft, Camera, Image as ImageIcon, Info, Sparkles, Scale, Box, Wind, Zap, Sliders, ChevronDown } from 'lucide-react';
import { MuzRecord, ReferenceItem, SplitLotItem, STANDARD_QUALITY_CLASSES, BananaScadaChamberData, ActiveFieldContext } from '../../types';
import { BANANA_RIPENESS_STAGES, generateRefId, evaluateBananaQuality } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { SmartCreatableSelect } from '../common/SmartField';
import { compressImageFiles } from '../../utils/imageCompressor';
import { BananaRipeningScadaModal } from './BananaRipeningScadaModal';
import { MuzKurdeleView } from '../portal/MuzKurdeleView';
import { InteractiveBananaQualityTraceabilityWidget } from './InteractiveBananaQualityTraceabilityWidget';
import { getCurrentUser } from '../../utils/authService';
import { Button, Card, Badge, SaveBar } from '../ui';

interface MuzFormProps {
  onSave: (record: MuzRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: MuzRecord;
  activeFieldContext?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

export const MuzForm: React.FC<MuzFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  activeFieldContext,
  isReadOnly = false
}) => {
  const isEditing = Boolean(initialRecord);
  const [activeMuzSubTab, setActiveMuzSubTab] = useState<'QUALITY_FORM' | 'KURDELE_VIEW'>('QUALITY_FORM');
  const [isNewRef, setIsNewRef] = useState(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || '');
  const [customRefInput, setCustomRefInput] = useState(initialRecord?.refId || '');

  // Operator & Origin (Auto-populated from activeFieldContext if selected in Gantt or Header)
  const [operator, setOperator] = useState(initialRecord?.operator || getCurrentUser()?.fullName || '');
  const [product, setProduct] = useState(initialRecord?.product || activeFieldContext?.product || 'Muz (Cavendish)');
  const [greenhouseNo, setGreenhouseNo] = useState(
    initialRecord?.greenhouseNo || activeFieldContext?.greenhouseNo || activeFieldContext?.parcelCode || ''
  );
  const [ribbonColor, setRibbonColor] = useState(
    initialRecord?.ribbonColor || activeFieldContext?.ribbonColor || ''
  );
  const [bloomWeek, setBloomWeek] = useState<number | null>(initialRecord?.bloomWeek ?? null);
  const [harvestAgeWeeks, setHarvestAgeWeeks] = useState<number | null>(initialRecord?.harvestAgeWeeks ?? null);
  const [destination, setDestination] = useState('');
  
  // Physical measurements & Morphometry
  const [fingerLengthCm, setFingerLengthCm] = useState<number | null>(initialRecord?.fingerLengthCm ?? null);
  const [calibrationMm, setCalibrationMm] = useState<number | null>(initialRecord?.calibrationMm ?? null);
  const [fingerCountPerHand, setFingerCountPerHand] = useState<number | null>(initialRecord?.fingerCountPerHand ?? null);
  const [handPosition, setHandPosition] = useState<'1. El (Üst)' | '2. El' | 'Orta El' | 'Alt El'>(initialRecord?.handPosition || '1. El (Üst)');
  const [clusterWeightKg, setClusterWeightKg] = useState<number | null>(initialRecord?.clusterWeightKg ?? null);
  const [angularity, setAngularity] = useState<'Dolu Yuvarlak' | '3/4 Dolu' | 'Köşeli'>(initialRecord?.angularity || 'Dolu Yuvarlak');

  // Physiology & Ripeness Tests
  const [ripenessScale, setRipenessScale] = useState<number | null>(initialRecord?.ripenessScale ?? null);
  const [pulpFirmness, setPulpFirmness] = useState<number | null>(initialRecord?.pulpFirmness ?? null);
  const [pulpTemperatureC, setPulpTemperatureC] = useState<number | null>(initialRecord?.pulpTemperatureC ?? null);
  
  // Brix Multi-Sample Testing & Average (Seçmeli - Madde 10)
  const [hasBrixTest, setHasBrixTest] = useState<boolean>(() => {
    return Boolean(initialRecord?.brix !== undefined && initialRecord.brix > 0);
  });
  const [hasPpmTest, setHasPpmTest] = useState<boolean>(() => {
    return Boolean(initialRecord?.avgPpm !== undefined && initialRecord.avgPpm > 0);
  });

  // Muz Özel 3-Nokta Meyve Ölçümü (Sap/Üst, Orta, Uç/Alt)
  const [banana3PointTop, setBanana3PointTop] = useState<number | null>(initialRecord?.banana3PointBrix?.topPoint ?? null);
  const [banana3PointMiddle, setBanana3PointMiddle] = useState<number | null>(initialRecord?.banana3PointBrix?.middlePoint ?? null);
  const [banana3PointBottom, setBanana3PointBottom] = useState<number | null>(initialRecord?.banana3PointBrix?.bottomPoint ?? null);

  const [brix1, setBrix1] = useState<number | null>(initialRecord?.brixSamples?.[0] ?? null);
  const [brix2, setBrix2] = useState<number | null>(initialRecord?.brixSamples?.[1] ?? null);
  const [brix3, setBrix3] = useState<number | null>(initialRecord?.brixSamples?.[2] ?? null);
  const [brix4, setBrix4] = useState<number | null>(initialRecord?.brixSamples?.[3] ?? null);
  const [brix5, setBrix5] = useState<number | null>(initialRecord?.brixSamples?.[4] ?? null);

  // PPM Multi-Point Testing & Average
  const [ppmTestType, setPpmTestType] = useState<string>(initialRecord?.ppmTestType || 'Etilen Gazlama Seviyesi (ppm)');
  const [ppm1, setPpm1] = useState<number | null>(initialRecord?.ppmSamples?.[0] ?? null);
  const [ppm2, setPpm2] = useState<number | null>(initialRecord?.ppmSamples?.[1] ?? null);
  const [ppm3, setPpm3] = useState<number | null>(initialRecord?.ppmSamples?.[2] ?? null);
  const [ppm4, setPpm4] = useState<number | null>(initialRecord?.ppmSamples?.[3] ?? null);
  const [ppm5, setPpm5] = useState<number | null>(initialRecord?.ppmSamples?.[4] ?? null);

  // Calculated Averages
  const banana3PointAvg = useMemo<number | null>(() => {
    const list = [banana3PointTop, banana3PointMiddle, banana3PointBottom].filter(
      (v): v is number => v !== null && !Number.isNaN(v) && v > 0
    );
    if (!list.length) return null;
    return parseFloat((list.reduce((a, b) => a + b, 0) / list.length).toFixed(1));
  }, [banana3PointTop, banana3PointMiddle, banana3PointBottom]);

  const avgBrix = useMemo<number | null>(() => {
    const list = [brix1, brix2, brix3, brix4, brix5].filter(
      (v): v is number => v !== null && !Number.isNaN(v) && v > 0
    );
    if (!list.length) return banana3PointAvg;
    return parseFloat((list.reduce((a, b) => a + b, 0) / list.length).toFixed(1));
  }, [brix1, brix2, brix3, brix4, brix5, banana3PointAvg]);

  const avgPpm = useMemo<number | null>(() => {
    const list = [ppm1, ppm2, ppm3, ppm4, ppm5].filter(
      (v): v is number => v !== null && !Number.isNaN(v) && v > 0
    );
    if (!list.length) return null;
    return Math.round(list.reduce((a, b) => a + b, 0) / list.length);
  }, [ppm1, ppm2, ppm3, ppm4, ppm5]);

  // Defects Check
  const [flowerEndDefect, setFlowerEndDefect] = useState<boolean>(initialRecord?.flowerEndDefect ?? false);
  const [latexStain, setLatexStain] = useState<boolean>(initialRecord?.latexStain ?? false);
  const [mechanicalDamage, setMechanicalDamage] = useState<boolean>(initialRecord?.mechanicalDamage ?? false);
  const [sunburnOrYellow, setSunburnOrYellow] = useState<boolean>(initialRecord?.sunburnOrYellow ?? false);
  const [pestDamage, setPestDamage] = useState<boolean>(initialRecord?.pestDamage ?? false);

  // Packaging & Storage details
  const [packaging, setPackaging] = useState(initialRecord?.packaging || '');
  const [polybagType, setPolybagType] = useState<'Vakumlu Banavac' | 'Delikli Polietilen' | 'Açık Dökme'>(initialRecord?.polybagType || 'Vakumlu Banavac');
  const [mapPackaging, setMapPackaging] = useState<boolean>(initialRecord?.mapPackaging ?? true); // Modifiye Atmosfer Paketleme
  const [ethyleneAbsorber, setEthyleneAbsorber] = useState<boolean>(initialRecord?.ethyleneAbsorber ?? true); // KMnO4 Etilen Emici Absorber Şase
  const [netWeightKg, setNetWeightKg] = useState<number | null>(initialRecord?.netWeightKg ?? null);
  const [grossWeightKg, setGrossWeightKg] = useState<number | null>(initialRecord?.grossWeightKg ?? null);
  const [roomNo, setRoomNo] = useState(initialRecord?.roomNo || '');
  const [coolingStatus, setCoolingStatus] = useState<'Uygun' | 'Yetersiz' | 'İşlemde'>(initialRecord?.coolingStatus || 'Uygun');
  const [gasStatus, setGasStatus] = useState<'Bekliyor' | 'Gazlandı' | 'Gerek Yok' | 'Gazlanmayacak'>(initialRecord?.gasStatus || 'Bekliyor');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [qualityStatus, setQualityStatus] = useState<'Ekstra / A Kalite' | 'Sınıf 1 / B Kalite' | 'Sınıf 2 / C Kalite' | 'Sanayi / Fire'>(initialRecord?.qualityStatus || 'Ekstra / A Kalite');
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>(initialRecord?.splitLots || []);
  
  // SCADA / PLC Banana Ripening Parameters (Kendall / Siemens)
  const [isScadaModalOpen, setIsScadaModalOpen] = useState<boolean>(false);
  const [ripeningScada, setRipeningScada] = useState<BananaScadaChamberData | undefined>({
    chamberId: 'NR1 Ripening Room',
    chamberType: 'RIPENING',
    ambientTemp1C: 19.1,
    ambientTemp2C: 19.0,
    pulpTemp1C: 17.6,
    pulpTemp2C: 17.6,
    ethylenePpm: 1.3,
    co2Ppm: 2553.1,
    humidityPercent: 82.0,
    activeStageIndex: 1,
    totalRunTimeHours: 151,
    elapsedTimeHours: 42,
    evaporatorFan1State: true,
    evaporatorFan2State: true,
    evapFinTempC: 2.5,
    defrostRemainingMin: 25,
    coolingStatusText: 'Kademeli Sarartma & Gazlama Devam Ediyor'
  });

  // Decision, Status & Next Step
  const [decision, setDecision] = useState(initialRecord?.decision || '');
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>(initialRecord?.testStatus || 'COMPLETED');
  const [nextStep, setNextStep] = useState(initialRecord?.nextStep || '');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);

  const currentStageInfo = ripenessScale !== null
    ? BANANA_RIPENESS_STAGES.find(s => s.stage === ripenessScale)
    : undefined;

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      try {
        const compressedUrls = await compressImageFiles(files, 1200, 0.78);
        setPhotos(prev => [...prev, ...compressedUrls.filter(Boolean)]);
      } catch (err) {
        console.error('Error compressing images:', err);
        files.forEach(file => {
          const reader = new FileReader();
          reader.onload = (event) => {
            if (event.target?.result) {
              setPhotos(prev => [...prev, event.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        });
      }
      e.target.value = '';
    }
  };

  const parseNullableNumber = (val: string): number | null => {
    if (val === '') return null;
    const num = Number(val);
    return Number.isNaN(num) ? null : num;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const missingFields: string[] = [];
    if (harvestAgeWeeks === null || Number.isNaN(harvestAgeWeeks)) missingFields.push('Hasat Yaşı (Hafta)');
    if (calibrationMm === null || Number.isNaN(calibrationMm)) missingFields.push('Parmak Kalibrasyonu (mm)');
    if (fingerLengthCm === null || Number.isNaN(fingerLengthCm)) missingFields.push('Parmak Uzunluğu (cm)');
    if (pulpFirmness === null || Number.isNaN(pulpFirmness)) missingFields.push('Meyve Eti Sertliği (kg/cm²)');
    if (pulpTemperatureC === null || Number.isNaN(pulpTemperatureC)) missingFields.push('Meyve İçi Sıcaklığı (°C)');

    if (missingFields.length > 0) {
      alert(`Ölçümleri girin:\n• ${missingFields.join('\n• ')}`);
      return;
    }

    const finalOperator = operator.trim() || getCurrentUser()?.fullName || '';
    const finalProduct = product.trim() || 'Muz (Cavendish)';
    const finalGreenhouse = greenhouseNo.trim() || 'Belirtilmedi';
    const finalRibbonColor = ribbonColor.trim();

    let finalRefId = '';
    if (isEditing && initialRecord) {
      finalRefId = initialRecord.refId;
    } else if (isNewRef) {
      finalRefId = customRefInput.trim()
        ? customRefInput.trim()
        : generateRefId('MUZ', existingRefs.map(r => r.refId));
    } else {
      finalRefId = selectedRefId.trim() || customRefInput.trim() || generateRefId('MUZ', existingRefs.map(r => r.refId));
    }

    if (!finalRefId) {
      finalRefId = generateRefId('MUZ', []);
    }

    const validBrixSamples = [brix1, brix2, brix3, brix4, brix5].filter(
      (v): v is number => v !== null && !Number.isNaN(v)
    );
    const validPpmSamples = [ppm1, ppm2, ppm3, ppm4, ppm5].filter(
      (v): v is number => v !== null && !Number.isNaN(v)
    );
    const hasAny3PointBrix =
      banana3PointTop !== null || banana3PointMiddle !== null || banana3PointBottom !== null;

    const muzRecord: MuzRecord = {
      id: (isEditing && initialRecord?.id) ? initialRecord.id : `m-${Date.now()}`,
      refId: finalRefId,
      timestamp: initialRecord?.timestamp || new Date().toISOString(),
      operator: finalOperator,
      product: finalProduct,
      greenhouseNo: finalGreenhouse,
      ribbonColor: finalRibbonColor,
      bloomWeek: bloomWeek ?? undefined,
      harvestAgeWeeks: harvestAgeWeeks ?? undefined,
      fingerLengthCm: (fingerLengthCm ?? undefined) as number,
      calibrationMm: (calibrationMm ?? undefined) as number,
      fingerCountPerHand: (fingerCountPerHand ?? undefined) as number,
      handPosition,
      clusterWeightKg: clusterWeightKg ?? undefined,
      ripenessScale: (ripenessScale ?? undefined) as number,
      pulpFirmness: (pulpFirmness ?? undefined) as number,
      pulpTemperatureC: pulpTemperatureC ?? undefined,
      brix: hasBrixTest && avgBrix !== null ? avgBrix : undefined,
      brixSamples: hasBrixTest && validBrixSamples.length > 0 ? validBrixSamples : undefined,
      banana3PointBrix: hasBrixTest && hasAny3PointBrix && banana3PointAvg !== null ? {
        topPoint: (banana3PointTop ?? undefined) as number,
        middlePoint: (banana3PointMiddle ?? undefined) as number,
        bottomPoint: (banana3PointBottom ?? undefined) as number,
        avg3Point: banana3PointAvg
      } : undefined,
      avgBrix: hasBrixTest && avgBrix !== null ? avgBrix : undefined,
      ppmTestType: hasPpmTest ? ppmTestType : undefined,
      ppmSamples: hasPpmTest && validPpmSamples.length > 0 ? validPpmSamples : undefined,
      avgPpm: hasPpmTest && avgPpm !== null ? avgPpm : undefined,
      angularity,
      flowerEndDefect,
      latexStain,
      mechanicalDamage,
      sunburnOrYellow,
      pestDamage,
      packaging,
      polybagType,
      mapPackaging,
      ethyleneAbsorber,
      netWeightKg: (netWeightKg ?? undefined) as number,
      grossWeightKg: grossWeightKg ?? undefined,
      roomNo,
      coolingStatus,
      gasStatus,
      qualityStatus,
      kaliteSinifi,
      ripeningScada,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      decision: decision || 'Kabul & Gazlama Odasına Sevk',
      testStatus,
      nextStep: nextStep || 'Olgunlaştırma & Paketleme',
      notes,
      photos
    };

    const newRefData: Partial<ReferenceItem> | undefined = (isNewRef && !isEditing)
      ? {
          refId: finalRefId,
          moduleKey: 'MUZ',
          product: finalProduct,
          location: finalGreenhouse,
          source: finalGreenhouse,
          destination: destination.trim(),
          quantity: netWeightKg ?? 0,
          unit: 'kg',
          status: testStatus === 'COMPLETED' ? 'CREATED' : 'CREATED',
          createdAt: new Date().toISOString(),
          operator: finalOperator,
          notes: `Muz Kalite Kontrolü. Şerit: ${finalRibbonColor || 'Belirtilmedi'}, Kalibre: ${calibrationMm ?? '—'}mm, MAP: ${mapPackaging ? 'Var' : 'Yok'}, Etilen Absorber: ${ethyleneAbsorber ? 'Var' : 'Yok'}`
        }
      : undefined;

    onSave(muzRecord, isNewRef && !isEditing, newRefData);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-[0_1px_2px_rgba(15,23,42,0.06)] overflow-hidden w-full max-w-full min-w-0">
      {/* Light Minimalist Header */}
      <div className="bg-white dark:bg-slate-900 px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 shrink-0">
            <Banana className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                Muz kalite ve sarartma testi
              </h2>
              <Badge tone="neutral">Hemsaýa • Erem™</Badge>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-400 line-clamp-2 sm:line-clamp-none mt-0.5">
              Brix şeker & PPM testleri, kalibrasyon, MAP & Etilen Absorber ve test ortalamaları takibi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <Button
            variant="secondary"
            size="sm"
            icon={<ArrowLeft />}
            onClick={onCancel}
          >
            Geri Dön
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 w-full max-w-full min-w-0 bg-slate-50/60 dark:bg-slate-950/40">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">

        {/* 1. Parti */}
        <Card title="Parti">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
            <div className="min-w-0">
              <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Referans ID (Mevcut partiye bağlayın veya yeni parti kodu yazın)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label className={`flex items-center gap-2 text-xs font-semibold px-3 py-2 min-h-[44px] rounded-xl border cursor-pointer transition ${isNewRef ? 'bg-teal-50 dark:bg-teal-950/50 border-teal-500 text-teal-900 dark:text-teal-200' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                  <input
                    type="radio"
                    checked={isNewRef}
                    onChange={() => setIsNewRef(true)}
                    className="text-teal-700 focus:ring-teal-500 shrink-0"
                  />
                  <span>Yeni Referans Oluştur</span>
                </label>

                <label className={`flex items-center gap-2 text-xs font-semibold px-3 py-2 min-h-[44px] rounded-xl border cursor-pointer transition ${!isNewRef ? 'bg-teal-50 dark:bg-teal-950/50 border-teal-500 text-teal-900 dark:text-teal-200' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                  <input
                    type="radio"
                    checked={!isNewRef}
                    onChange={() => setIsNewRef(false)}
                    className="text-teal-700 focus:ring-teal-500 shrink-0"
                  />
                  <span>Mevcut Referansa Bağla / Seç</span>
                </label>
              </div>
            </div>

            <div className="min-w-0">
              {isNewRef ? (
                <input
                  type="text"
                  value={customRefInput}
                  onChange={(e) => setCustomRefInput(e.target.value)}
                  placeholder="Otomatik (MUZ-...) veya Özel Kod Yazın"
                  className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 shadow-2xs focus:ring-2 focus:ring-teal-500 focus:outline-none max-w-full"
                />
              ) : (
                <div className="space-y-1 w-full min-w-0">
                  <input
                    type="text"
                    list="existing-refs-list"
                    value={selectedRefId}
                    onChange={(e) => setSelectedRefId(e.target.value)}
                    placeholder="RefID Seçin veya Klavyeden Yazın"
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 shadow-2xs focus:ring-2 focus:ring-teal-500 focus:outline-none max-w-full truncate"
                  />
                  <datalist id="existing-refs-list">
                    {existingRefs.map(r => (
                      <option key={r.refId} value={r.refId}>
                        {r.refId} — {r.product} [{r.quantity} {r.unit}]
                      </option>
                    ))}
                  </datalist>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* 2. Hasat bilgisi */}
        <Card title="Hasat bilgisi">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Operatör Adı *
              </label>
              <input
                type="text"
                list="operators-list"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                placeholder="Adınızı giriniz"
                className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
              <datalist id="operators-list">
                {AUTOCOMPLETE_LISTS.operators.map(op => (
                  <option key={op} value={op} />
                ))}
              </datalist>
            </div>

            <div>
              <SmartCreatableSelect
                label="Sera No / Sektör"
                categoryKey="greenhouses"
                options={[]}
                value={greenhouseNo}
                onChange={setGreenhouseNo}
                placeholder="Sera seçin veya yeni ekleyin..."
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Şerit Rengi (Ribbon / Hafta)
              </label>
              <input
                type="text"
                list="ribbons-list"
                value={ribbonColor}
                onChange={(e) => setRibbonColor(e.target.value)}
                placeholder="Şerit rengi seçin veya girin"
                className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
              <datalist id="ribbons-list">
                {AUTOCOMPLETE_LISTS.ribbons.map(r => (
                  <option key={r} value={r} />
                ))}
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Hasat Yaşı (Hafta)
              </label>
              <input
                type="number"
                value={harvestAgeWeeks ?? ''}
                onChange={(e) => setHarvestAgeWeeks(parseNullableNumber(e.target.value))}
                className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <SmartCreatableSelect
                label="Hedef Tesis / Destination (Opsiyonel)"
                categoryKey="destinations"
                options={[]}
                value={destination}
                onChange={setDestination}
                placeholder="Hedef tesis seçin veya yeni ekleyin..."
              />
            </div>
          </div>
        </Card>

        {/* 3. Fiziksel ölçümler */}
        <Card
          title={
            <span className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Fiziksel ölçümler</span>
            </span>
          }
          subtitle="Fiziksel Kalibrasyon & Olgunluk Testi"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Parmak Kalibrasyonu (mm) [Hedef: 39-44 mm]
                </label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    step="0.1"
                    value={calibrationMm ?? ''}
                    onChange={(e) => setCalibrationMm(parseNullableNumber(e.target.value))}
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-3.5 pr-12 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <span className="pointer-events-none absolute right-3.5 text-xs font-medium text-slate-400 dark:text-slate-500">mm</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Parmak Uzunluğu (cm) [Hedef: &gt;20 cm]
                </label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    step="0.1"
                    value={fingerLengthCm ?? ''}
                    onChange={(e) => setFingerLengthCm(parseNullableNumber(e.target.value))}
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-3.5 pr-12 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <span className="pointer-events-none absolute right-3.5 text-xs font-medium text-slate-400 dark:text-slate-500">cm</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Meyve Eti Sertliği (kg/cm²)
                </label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    step="0.1"
                    value={pulpFirmness ?? ''}
                    onChange={(e) => setPulpFirmness(parseNullableNumber(e.target.value))}
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-3.5 pr-16 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <span className="pointer-events-none absolute right-3.5 text-xs font-medium text-slate-400 dark:text-slate-500">kg/cm²</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Meyve İçi Sıcaklığı (°C) [Hedef: 13.5-14.5°C]
                </label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    step="0.1"
                    value={pulpTemperatureC ?? ''}
                    onChange={(e) => setPulpTemperatureC(parseNullableNumber(e.target.value))}
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-3.5 pr-12 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <span className="pointer-events-none absolute right-3.5 text-xs font-medium text-slate-400 dark:text-slate-500">°C</span>
                </div>
              </div>
            </div>

            {/* Olgunluk Skalası Seçici */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Muz Olgunluk Skalası (1: Sert Yeşil Hasat - 7: Sarı Benekli):
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
                {BANANA_RIPENESS_STAGES.map((s) => (
                  <button
                    key={s.stage}
                    type="button"
                    onClick={() => setRipenessScale(s.stage)}
                    className={`p-2 min-h-[44px] rounded-xl text-center border transition cursor-pointer ${
                      ripenessScale === s.stage
                        ? 'border-teal-600 bg-teal-50 dark:bg-teal-950/60 ring-2 ring-teal-500 shadow-2xs'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div
                      className="w-full h-3 rounded mb-1"
                      style={{ backgroundColor: s.colorHex }}
                    />
                    <div className="text-[11px] font-bold text-slate-900 dark:text-white">{s.stage}</div>
                    <div className="text-[10px] text-slate-600 dark:text-slate-400 truncate">{s.nameTr.split(' ')[0]}</div>
                  </button>
                ))}
              </div>
              <div className="mt-2.5 text-xs font-semibold text-emerald-900 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-2 rounded-xl border border-emerald-200 dark:border-emerald-800">
                {currentStageInfo ? (
                  <>Seçilen Aşama {currentStageInfo.stage}: <strong>{currentStageInfo.nameTr}</strong> — {currentStageInfo.description}</>
                ) : (
                  <span>Seçilen Aşama: —</span>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* 4. Brix / PPM (isteğe bağlı) */}
        <Card
          title={
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Brix / PPM (isteğe bağlı)</span>
            </span>
          }
          subtitle="İhtiyaca göre seçmeli: Refraktometre şeker analizi ve gazlama/oda ortamı PPM ölçümleri (Her partiye yapılmayabilir)"
        >
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="inline-flex items-center bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 gap-1">
                <button
                  type="button"
                  onClick={() => setHasBrixTest(true)}
                  className={`px-3 py-1.5 min-h-[40px] rounded-lg text-xs font-semibold transition cursor-pointer ${
                    hasBrixTest
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Brix Yapıldı
                </button>
                <button
                  type="button"
                  onClick={() => setHasBrixTest(false)}
                  className={`px-3 py-1.5 min-h-[40px] rounded-lg text-xs font-semibold transition cursor-pointer ${
                    !hasBrixTest
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  ○ Yapılmadı
                </button>
              </div>

              <div className="inline-flex items-center bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 gap-1">
                <button
                  type="button"
                  onClick={() => setHasPpmTest(true)}
                  className={`px-3 py-1.5 min-h-[40px] rounded-lg text-xs font-semibold transition cursor-pointer ${
                    hasPpmTest
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  PPM Yapıldı
                </button>
                <button
                  type="button"
                  onClick={() => setHasPpmTest(false)}
                  className={`px-3 py-1.5 min-h-[40px] rounded-lg text-xs font-semibold transition cursor-pointer ${
                    !hasPpmTest
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  ○ Yapılmadı
                </button>
              </div>

              {hasBrixTest && (
                <Badge tone="ok">
                  Ort. Brix: <strong className="tabular-nums">{avgBrix ?? '—'} °Bx</strong>
                </Badge>
              )}
              {hasPpmTest && (
                <Badge tone="info">
                  Ort. PPM: <strong className="tabular-nums">{avgPpm ?? '—'} ppm</strong>
                </Badge>
              )}
            </div>

            {!hasBrixTest && !hasPpmTest && (
              <div className="py-5 px-4 text-center bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  Bu muz partisinde Brix ve PPM ölçümleri pasif durumda (İsteğe bağlı test).
                </p>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1">
                  Refraktometre veya gaz/kimyasal ölçümü yapıldığında yukarıdaki butonlardan ilgili testi aktif edebilirsiniz.
                </p>
              </div>
            )}

            {(hasBrixTest || hasPpmTest) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. BRIX TESTİ (MUZ MEYVESİ 3 NOKTA + 5 NUMUNE TARAMASI) */}
                {hasBrixTest && (
                  <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-4">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-teal-600"></span>
                        Muz Meyvesi 3 Nokta Brix Ölçümü (Sap, Gövde, Uç)
                      </span>
                      <Badge tone="neutral">Muz Standardı: 3 Bölge Ölçümü</Badge>
                    </div>

                    {/* 3-Zone Banana Visual Card */}
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-2.5">
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400 shrink-0" />
                        <span>Tek Muz Meyvesinde 3 Noktadan Refraktometre Şeker Analizi:</span>
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                        {/* Point 1: Sap / Üst */}
                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">1. Sap / Üst Kısım</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold">Proximal</span>
                          </div>
                          <div className="relative flex items-center">
                            <input
                              type="number"
                              step="0.1"
                              value={banana3PointTop ?? ''}
                              onChange={(e) => setBanana3PointTop(parseNullableNumber(e.target.value))}
                              className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg pl-2 pr-8 py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                            />
                            <span className="pointer-events-none absolute right-2.5 text-xs font-medium text-slate-400 dark:text-slate-500">°Bx</span>
                          </div>
                        </div>

                        {/* Point 2: Orta Gövde */}
                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">2. Orta Gövde</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold">Middle</span>
                          </div>
                          <div className="relative flex items-center">
                            <input
                              type="number"
                              step="0.1"
                              value={banana3PointMiddle ?? ''}
                              onChange={(e) => setBanana3PointMiddle(parseNullableNumber(e.target.value))}
                              className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg pl-2 pr-8 py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                            />
                            <span className="pointer-events-none absolute right-2.5 text-xs font-medium text-slate-400 dark:text-slate-500">°Bx</span>
                          </div>
                        </div>

                        {/* Point 3: Alt / Uç */}
                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">3. Uç / Alt Kısım</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold">Distal</span>
                          </div>
                          <div className="relative flex items-center">
                            <input
                              type="number"
                              step="0.1"
                              value={banana3PointBottom ?? ''}
                              onChange={(e) => setBanana3PointBottom(parseNullableNumber(e.target.value))}
                              className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg pl-2 pr-8 py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                            />
                            <span className="pointer-events-none absolute right-2.5 text-xs font-medium text-slate-400 dark:text-slate-500">°Bx</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg p-2.5 flex items-center justify-between text-xs mt-1">
                        <span className="text-emerald-900 dark:text-emerald-200 font-semibold">Tek Meyve 3 Nokta Brix Ortalaması:</span>
                        <span className="tabular-nums font-bold text-emerald-800 dark:text-emerald-300 text-sm">
                          {banana3PointAvg ?? '—'} °Bx
                        </span>
                      </div>
                    </div>

                    {/* 5 Numune Meyve Taraması */}
                    <div className="space-y-2 pt-1 border-t border-slate-200 dark:border-slate-700">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">5 Numune Parti Refraktometre Taraması:</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (banana3PointAvg !== null) setBrix1(banana3PointAvg);
                          }}
                        >
                          3 Nokta Ortalamasını Numune 1'e Aktar
                        </Button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Numune 1</label>
                          <input
                            type="number"
                            step="0.1"
                            value={brix1 ?? ''}
                            onChange={(e) => setBrix1(parseNullableNumber(e.target.value))}
                            className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Numune 2</label>
                          <input
                            type="number"
                            step="0.1"
                            value={brix2 ?? ''}
                            onChange={(e) => setBrix2(parseNullableNumber(e.target.value))}
                            className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Numune 3</label>
                          <input
                            type="number"
                            step="0.1"
                            value={brix3 ?? ''}
                            onChange={(e) => setBrix3(parseNullableNumber(e.target.value))}
                            className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Numune 4</label>
                          <input
                            type="number"
                            step="0.1"
                            value={brix4 ?? ''}
                            onChange={(e) => setBrix4(parseNullableNumber(e.target.value))}
                            className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Numune 5</label>
                          <input
                            type="number"
                            step="0.1"
                            value={brix5 ?? ''}
                            onChange={(e) => setBrix5(parseNullableNumber(e.target.value))}
                            className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 flex items-center justify-between text-xs">
                      <span className="text-slate-600 dark:text-slate-400 font-semibold">Genel Parti Ortalama Brix:</span>
                      <span className="tabular-nums font-bold text-teal-800 dark:text-teal-300 text-sm">
                        {avgBrix ?? '—'} °Bx
                      </span>
                    </div>
                  </div>
                )}

                {/* 2. PPM TESTİ (5 NOKTA/NUMUNE) */}
                {hasPpmTest && (
                  <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-cyan-600"></span>
                        PPM Gaz / Kimyasal Testi — 5 Nokta
                      </span>
                      <select
                        value={ppmTestType}
                        onChange={(e) => setPpmTestType(e.target.value)}
                        className="min-h-[44px] text-xs font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                      >
                        <option value="Etilen Gazlama Seviyesi (ppm)">Etilen Gazlama (ppm)</option>
                        <option value="Oda CO2 / Gaz Seviyesi (ppm)">Oda CO2 Seviyesi (ppm)</option>
                        <option value="Ozon Dezenfeksiyonu (ppm)">Ozon / Gazlama (ppm)</option>
                        <option value="Yıkama Havuzu Klor (ppm)">Yıkama Havuzu Klor (ppm)</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Nokta 1</label>
                        <input
                          type="number"
                          value={ppm1 ?? ''}
                          onChange={(e) => setPpm1(parseNullableNumber(e.target.value))}
                          className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Nokta 2</label>
                        <input
                          type="number"
                          value={ppm2 ?? ''}
                          onChange={(e) => setPpm2(parseNullableNumber(e.target.value))}
                          className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Nokta 3</label>
                        <input
                          type="number"
                          value={ppm3 ?? ''}
                          onChange={(e) => setPpm3(parseNullableNumber(e.target.value))}
                          className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Nokta 4</label>
                        <input
                          type="number"
                          value={ppm4 ?? ''}
                          onChange={(e) => setPpm4(parseNullableNumber(e.target.value))}
                          className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">Nokta 5</label>
                        <input
                          type="number"
                          value={ppm5 ?? ''}
                          onChange={(e) => setPpm5(parseNullableNumber(e.target.value))}
                          className="w-full min-h-[44px] text-sm tabular-nums font-bold text-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl py-1.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 flex items-center justify-between text-xs">
                      <span className="text-slate-600 dark:text-slate-400 font-semibold truncate">Ortalama PPM Değeri:</span>
                      <span className="tabular-nums font-bold text-teal-800 dark:text-teal-300 text-sm">
                        {avgPpm ?? '—'} ppm
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TEST ORTALAMALARI VE ANALİZ ÖZET KARTI (Açık Card) */}
            <Card accent="brand" className="bg-slate-50/70 dark:bg-slate-900">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-teal-800 dark:text-teal-300 block mb-1">
                    Test Ortalamaları & Kalite Analiz Özeti
                  </span>
                  <div className="flex items-center flex-wrap gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <span>Parti: <strong className="text-slate-900 dark:text-white">{isNewRef ? (customRefInput || '') : selectedRefId}</strong></span>
                    <span className="text-slate-400">•</span>
                    <span>Sıcaklık: <strong className="text-slate-900 dark:text-white tabular-nums">{pulpTemperatureC ?? '—'}°C</strong></span>
                    <span className="text-slate-400">•</span>
                    <span>Sertlik: <strong className="text-slate-900 dark:text-white tabular-nums">{pulpFirmness ?? '—'} kg/cm²</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-center">
                    <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 block">Ort. Brix</span>
                    <span className="text-xs tabular-nums font-bold text-slate-900 dark:text-white">{avgBrix ?? '—'} °Bx</span>
                  </div>
                  <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-center">
                    <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 block">Ort. PPM</span>
                    <span className="text-xs tabular-nums font-bold text-slate-900 dark:text-white">{avgPpm ?? '—'} ppm</span>
                  </div>
                  <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-center">
                    <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 block">Kalibrasyon</span>
                    <span className="text-xs tabular-nums font-bold text-slate-900 dark:text-white">{calibrationMm ?? '—'} mm</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </Card>

        {/* 5. Ambalaj ve MAP */}
        <Card
          title={
            <span className="flex items-center gap-2">
              <Box className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Ambalaj ve MAP</span>
            </span>
          }
          subtitle="Paketleme, MAP & Etilen Absorber Standartları"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Ambalaj Tipi
                </label>
                <input
                  type="text"
                  value={packaging}
                  onChange={(e) => setPackaging(e.target.value)}
                  className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Poşet / Torba Tipi
                </label>
                <select
                  value={polybagType}
                  onChange={(e) => setPolybagType(e.target.value as any)}
                  className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="Vakumlu Banavac">Vakumlu Banavac (Tavsiye Edilen)</option>
                  <option value="Delikli Polietilen">Delikli Polietilen</option>
                  <option value="Açık Dökme">Açık Dökme / Poşetsiz</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Net Ağırlık (kg)
                </label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    value={netWeightKg ?? ''}
                    onChange={(e) => setNetWeightKg(parseNullableNumber(e.target.value))}
                    className="w-full min-h-[44px] text-sm tabular-nums font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-3.5 pr-12 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <span className="pointer-events-none absolute right-3.5 text-xs font-medium text-slate-400 dark:text-slate-500">kg</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Hedef Oda / Ön Soğutma
                </label>
                <input
                  type="text"
                  value={roomNo}
                  onChange={(e) => setRoomNo(e.target.value)}
                  className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>
            </div>

            {/* MAP ve Etilen Absorber Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <label className="flex items-center gap-3 p-3 min-h-[44px] rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                <input
                  type="checkbox"
                  checked={mapPackaging}
                  onChange={(e) => setMapPackaging(e.target.checked)}
                  className="w-4 h-4 text-teal-700 rounded focus:ring-teal-500 shrink-0"
                />
                <div>
                  <span className="text-xs font-semibold text-slate-900 dark:text-white block flex items-center gap-1.5">
                    <Wind className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />
                    MAP (Modifiye Atmosfer Paketleme) Uygulandı
                  </span>
                  <span className="text-[11px] text-slate-600 dark:text-slate-400">
                    Oksijen düşürme ve CO2 dengeleme ile yeşil kalma süresini uzatır
                  </span>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 min-h-[44px] rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                <input
                  type="checkbox"
                  checked={ethyleneAbsorber}
                  onChange={(e) => setEthyleneAbsorber(e.target.checked)}
                  className="w-4 h-4 text-teal-700 rounded focus:ring-teal-500 shrink-0"
                />
                <div>
                  <span className="text-xs font-semibold text-slate-900 dark:text-white block flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    KMnO4 Etilen Absorber Şase Eklendi
                  </span>
                  <span className="text-[11px] text-slate-600 dark:text-slate-400">
                    Kutu içi serbest etilen gazını emerek erken sararmayı önler
                  </span>
                </div>
              </label>
            </div>
          </div>
        </Card>

        {/* 6. Karar ve notlar */}
        <Card title="Karar ve notlar">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Kalite Değerlendirme Kararı
                </label>
                <input
                  type="text"
                  list="muz-decisions"
                  value={decision}
                  onChange={(e) => setDecision(e.target.value)}
                  className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
                <datalist id="muz-decisions">
                  <option value="Uygun (Sevkiyata Hazır)" />
                  <option value="Ön Soğutmaya Sevk" />
                  <option value="Gazlama Odasına Alınacak" />
                  <option value="Şartlı Kabul (İç Piyasa)" />
                  <option value="Karantina / İnceleme" />
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Sonraki Adım (Seçiniz veya yazınız)
                </label>
                <input
                  type="text"
                  list="muz-next-steps"
                  value={nextStep}
                  onChange={(e) => setNextStep(e.target.value)}
                  placeholder="Seçiniz veya yazınız"
                  className="w-full min-h-[44px] text-sm font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl px-3.5 py-2 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
                <datalist id="muz-next-steps">
                  <option value="Ön Soğutma & Frigorifik Lojistik Sevk" />
                  <option value="Gazlama Odasına Transfer (Etilen Uygulama)" />
                  <option value="Soğuk Depoda Dinlendirme (13.5°C)" />
                  <option value="İç Piyasa Hızlı Sevk" />
                </datalist>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Referans İşlem Durumu
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTestStatus('ACTIVE')}
                    className={`min-h-[44px] py-2 px-3 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      testStatus === 'ACTIVE'
                        ? 'bg-amber-50 dark:bg-amber-950/60 border-2 border-amber-500 text-amber-900 dark:text-amber-200 shadow-2xs'
                        : 'bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    Aktif (İşlemde)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTestStatus('COMPLETED')}
                    className={`min-h-[44px] py-2 px-3 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      testStatus === 'COMPLETED'
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border border-slate-200 text-emerald-900 dark:text-emerald-200 shadow-2xs'
                        : 'bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    Tamamlandı
                  </button>
                </div>
              </div>
            </div>

            {/* Notlar */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Notlar & Gözlemler
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Sera içi nemi, lateks temizliği, taç kesim kalitesi..."
                className="w-full min-h-[88px] text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl p-3.5 focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            {/* İnteraktif Kalite Standartları, Kasa Tipi & Hedef Pazar (Export / Yerel) İzlenebilirlik Eşleştirmesi */}
            <div className="pt-2">
              <InteractiveBananaQualityTraceabilityWidget
                greenhouseNo={greenhouseNo}
                ribbonColor={ribbonColor}
                harvestAgeWeeks={harvestAgeWeeks ?? 0}
                calibrationMm={calibrationMm ?? 0}
                fingerLengthCm={fingerLengthCm ?? 0}
                ripenessScale={ripenessScale ?? 0}
                pulpTemperatureC={pulpTemperatureC ?? 0}
                mapPackaging={mapPackaging}
                ethyleneAbsorber={ethyleneAbsorber}
                netWeightKg={netWeightKg ?? 0}
                packaging={packaging}
                kaliteSinifi={kaliteSinifi}
                onApplyDecisionToForm={(dec) => {
                  setPackaging(dec.crateType);
                  setKaliteSinifi(dec.kaliteSinifi);
                  setQualityStatus(dec.qualityStatus);
                  setMapPackaging(dec.mapPackaging);
                  setEthyleneAbsorber(dec.ethyleneAbsorber);
                  setPolybagType(dec.polybagType);
                  setDestination(dec.destination);
                  if (dec.calibrationMm !== undefined) setCalibrationMm(dec.calibrationMm);
                  if (dec.fingerLengthCm !== undefined) setFingerLengthCm(dec.fingerLengthCm);
                  if (dec.harvestAgeWeeks !== undefined) setHarvestAgeWeeks(dec.harvestAgeWeeks);
                }}
              />
            </div>

            {/* Fotoğraf Ekle */}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Fotoğraf / Numune Dosyası Ekle
              </label>
              <div className="flex items-center gap-2.5 flex-wrap">
                <Button
                  variant="secondary"
                  size="md"
                  icon={<Camera />}
                  onClick={() => cameraInputRef.current?.click()}
                >
                  Fotoğraf Çek
                </Button>

                <Button
                  variant="secondary"
                  size="md"
                  icon={<ImageIcon />}
                  onClick={() => galleryInputRef.current?.click()}
                >
                  Galeriden Seç
                </Button>

                {/* Gizli Kamera Girişi */}
                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleAddPhoto}
                  className="hidden"
                />

                {/* Gizli Galeri Girişi (multiple destekli) */}
                <input
                  ref={galleryInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleAddPhoto}
                  className="hidden"
                />

                {photos.filter(p => p && p.length > 20).map((p, idx) => (
                  <div key={idx} className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-300 dark:border-slate-700 shadow-sm group">
                    <img src={p} alt="Muz Foto" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotos(prev => prev.filter((_, i) => i !== idx))}
                      className="absolute inset-0 bg-red-900/70 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center text-[10px] font-bold transition cursor-pointer"
                    >
                      Sil
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* SIEMENS & KENDALL SCADA SARARTMA ODASI & SOĞUK ZİNCİR ENTEGRASYONU (Formun en altında, kapalı başlayan details içinde) */}
        <details className="group">
          <summary className="flex items-center justify-between gap-3 px-4 py-3.5 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-[0_1px_2px_rgba(15,23,42,0.06)] cursor-pointer list-none select-none">
            <div className="flex items-center gap-2.5 min-w-0 flex-wrap">
              <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                Siemens & Kendall SCADA • Sarartma Odası & Soğuk Hava Telemetrisi
              </span>
              <Badge tone="demo">DEMO — bağlı değil</Badge>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-500 dark:text-slate-400 transition-transform group-open:rotate-180 shrink-0" />
          </summary>

          <Card
            className="mt-2"
            title={
              <span className="flex items-center gap-2 flex-wrap">
                <span>Siemens & Kendall SCADA • Sarartma Odası & Soğuk Hava Telemetrisi</span>
                <Badge tone="demo">DEMO — bağlı değil</Badge>
              </span>
            }
            subtitle="Sarartma odası meyve eti sıcaklığı, C2H4 etilen dozajı, CO2 seviyesi ve 7-Aşama eğrisi"
            actions={
              <Button
                variant="secondary"
                size="sm"
                icon={<Sliders />}
                onClick={() => setIsScadaModalOpen(true)}
              >
                SCADA Parametrelerini Aç & Düzenle
              </Button>
            }
          >
            {ripeningScada && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 tabular-nums text-xs">
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">Oda & Modül</div>
                  <div className="font-bold text-slate-900 dark:text-white truncate mt-0.5">{ripeningScada.chamberId}</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">Meyve Eti (Pulp)</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">{ripeningScada.pulpTemp1C} °C</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">Oda Sıcaklığı</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">{ripeningScada.ambientTemp1C} °C</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">Etilen C2H4</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">{ripeningScada.ethylenePpm} ppm</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">CO2 & Nem</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">{ripeningScada.humidityPercent}% • {ripeningScada.co2Ppm}ppm</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">Aşama Programı</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">{ripeningScada.activeStageIndex}. Aşama / {ripeningScada.totalRunTimeHours}h</div>
                </div>
              </div>
            )}
          </Card>
        </details>

        </fieldset>

        {/* Submit / Cancel Bar */}
        <SaveBar
          onCancel={onCancel}
          saveType="submit"
          saveLabel={isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'Kaydet ve ilerlet'}
          cancelLabel="İptal"
          disabled={isReadOnly}
          className="rounded-xl border border-slate-200 dark:border-slate-800"
        />

      </form>

      {/* Siemens & Kendall SCADA Ripening Modal */}
      <BananaRipeningScadaModal
        isOpen={isScadaModalOpen}
        onClose={() => setIsScadaModalOpen(false)}
        initialData={ripeningScada}
        onApplyScadaData={(data) => {
          setRipeningScada(data);
          if (data.pulpTemp1C) setPulpTemperatureC(data.pulpTemp1C);
          if (data.chamberId) setRoomNo(data.chamberId);
        }}
      />
    </div>
  );
};
