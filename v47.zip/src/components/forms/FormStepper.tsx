import React, { useEffect } from 'react';
import { CheckCircle2, ChevronLeft, ChevronRight, Save, X, Sparkles } from 'lucide-react';
import { FormStepDefinition } from '../../hooks/useFormSteps';

export interface FormStepperProps {
  steps: FormStepDefinition[];
  currentStepIndex: number;
  onStepClick?: (index: number) => void;
  children: React.ReactNode;
  
  // Sticky Bottom Action Bar Props
  onCancel?: () => void;
  onNext?: () => void;
  onPrev?: () => void;
  onSubmit?: () => void;
  onSaveDraft?: () => void;
  
  isSubmitting?: boolean;
  submitLabel?: string;
  submitDisabled?: boolean;
  isDraftDisabled?: boolean;
  cancelLabel?: string;
  nextLabel?: string;
  prevLabel?: string;
  isReadOnly?: boolean;
  customActions?: React.ReactNode;
}

export const FormStepper: React.FC<FormStepperProps> = ({
  steps,
  currentStepIndex,
  onStepClick,
  children,
  onCancel,
  onNext,
  onPrev,
  onSubmit,
  onSaveDraft,
  isSubmitting = false,
  submitLabel = 'Kaydı Tamamla & Kaydet',
  submitDisabled = false,
  isDraftDisabled = false,
  cancelLabel = 'İptal / Cancel',
  nextLabel = 'İleri / Next',
  prevLabel = 'Geri / Back',
  isReadOnly = false,
  customActions
}) => {
  const totalSteps = steps.length;
  const isFirstStep = currentStepIndex === 0;
  const isLastStep = currentStepIndex === totalSteps - 1;
  const currentStep = steps[currentStepIndex] || steps[0];

  // Optional keyboard shortcuts: Alt+ArrowRight for Next, Alt+ArrowLeft for Prev, Ctrl+Enter for Submit
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key === 'ArrowRight' && !isLastStep && onNext) {
        e.preventDefault();
        onNext();
      } else if (e.altKey && e.key === 'ArrowLeft' && !isFirstStep && onPrev) {
        e.preventDefault();
        onPrev();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && onSubmit && !submitDisabled && !isReadOnly) {
        e.preventDefault();
        onSubmit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFirstStep, isLastStep, onNext, onPrev, onSubmit, submitDisabled, isReadOnly]);

  // Convert children to array
  const childArray = React.Children.toArray(children);

  return (
    <div className="w-full flex flex-col space-y-5">
      
      {/* 1. ÜST STEPPER İLERLEME ÇUBUĞU (RESPONSIVE STEPPER BAR) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 sm:p-4 shadow-xs">
        
        {/* Horizontal Steps (Desktop) */}
        <div className="hidden md:flex items-center justify-between relative">
          {/* Background progress bar line */}
          <div className="absolute left-6 right-6 top-4 h-0.5 bg-slate-200 dark:bg-slate-800 -z-0" />
          <div 
            className="absolute left-6 top-4 h-0.5 bg-teal-500 transition-all duration-300 -z-0"
            style={{ width: `${(currentStepIndex / Math.max(1, totalSteps - 1)) * 90}%` }}
          />

          {steps.map((step, idx) => {
            const isActive = currentStepIndex === idx;
            const isCompleted = currentStepIndex > idx;
            const StepIcon = step.icon;

            return (
              <button
                key={step.id || idx}
                type="button"
                onClick={() => onStepClick && onStepClick(idx)}
                disabled={isReadOnly}
                className={`flex flex-col items-center group relative z-10 focus:outline-none transition-all ${
                  isReadOnly ? 'cursor-default' : 'cursor-pointer'
                }`}
              >
                {/* Step Circle Pin */}
                <div 
                  className={`w-8 h-8 rounded-full flex items-center justify-center tabular-nums text-xs font-bold transition-all shadow-xs ${
                    isActive
                      ? 'bg-teal-600 text-white ring-4 ring-teal-500/20 scale-110 shadow-md'
                      : isCompleted
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : StepIcon ? (
                    <StepIcon className="w-4 h-4" />
                  ) : (
                    <span>{idx + 1}</span>
                  )}
                </div>

                {/* Step Label & Subtext */}
                <div className="mt-2 text-center max-w-[120px]">
                  <span 
                    className={`text-xs block leading-tight font-bold transition-colors ${
                      isActive 
                        ? 'text-teal-700 dark:text-teal-300' 
                        : isCompleted
                        ? 'text-slate-800 dark:text-slate-200'
                        : 'text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    {step.label}
                  </span>
                  {step.description && (
                    <span className="text-[10px] text-slate-400 hidden lg:block mt-0.5 truncate">
                      {step.description}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Mobile Stepper Header */}
        <div className="md:hidden flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-teal-600 text-white tabular-nums font-bold text-xs flex items-center justify-center shrink-0">
              {currentStepIndex + 1}
            </div>
            <div className="min-w-0">
              <span className="text-[10px] text-slate-400 font-bold block">
                Adım {currentStepIndex + 1} / {totalSteps}
              </span>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {currentStep?.label}
              </h4>
            </div>
          </div>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1 shrink-0">
            {steps.map((_, idx) => (
              <span
                key={idx}
                className={`h-1.5 rounded-full transition-all ${
                  currentStepIndex === idx 
                    ? 'w-4 bg-teal-500' 
                    : currentStepIndex > idx
                    ? 'w-1.5 bg-emerald-500'
                    : 'w-1.5 bg-slate-300 dark:bg-slate-700'
                }`}
              />
            ))}
          </div>
        </div>

      </div>

      {/* 2. ADIM İÇERİĞİ (DOM KORUMA - PASSIVE STEPS REMAIN HIDDEN) */}
      {/* Her bir adım DOM'da kalır (hidden sınıfı ile gizlenir), veri kaybı sıfırdır */}
      <div className="w-full">
        {childArray.map((child, idx) => (
          <div
            key={steps[idx]?.id || `step-${idx}`}
            className={currentStepIndex === idx ? 'block space-y-4 animate-in fade-in duration-150' : 'hidden'}
            aria-hidden={currentStepIndex !== idx}
          >
            {child}
          </div>
        ))}
      </div>

      {/* 3. STICKY BOTTOM ACTION BAR (YAPIŞKAN ALT AKSİYON ÇUBUĞU - TOP & BOTTOM GERİ DÖN ERGONOMİSİ) */}
      <div className="sticky bottom-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 p-3 sm:p-4 rounded-2xl shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3 transition-all">
        
        {/* Left Side: Cancel / Geri Dön Button */}
        <div className="w-full sm:w-auto flex items-center justify-between sm:justify-start gap-2">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2.5 min-h-[44px] text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl transition cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <ChevronLeft className="w-4 h-4 text-slate-500" />
              <span>← Geri Dön / İptal</span>
            </button>
          )}

          {/* Stepper info badge */}
          <span className="text-[11px] tabular-nums font-semibold text-slate-500 dark:text-slate-400">
            Adım <strong className="text-teal-600 dark:text-teal-400 font-bold">{currentStepIndex + 1}</strong> / {totalSteps}
          </span>
        </div>

        {/* Center / Custom Actions */}
        {customActions && (
          <div className="flex items-center gap-2">
            {customActions}
          </div>
        )}

        {/* Right Side: Back, Draft & Next/Finish Buttons */}
        <div className="w-full sm:w-auto flex items-center justify-end gap-2 flex-wrap">
          
          {/* Back Button (Previous Step) */}
          {!isFirstStep && onPrev && (
            <button
              type="button"
              onClick={onPrev}
              className="flex items-center justify-center gap-1 px-4 py-2.5 min-h-[44px] rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition cursor-pointer active:scale-95"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Önceki Adım</span>
            </button>
          )}

          {/* Optional Draft Save Button */}
          {onSaveDraft && !isReadOnly && (
            <button
              type="button"
              disabled={isDraftDisabled}
              onClick={onSaveDraft}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[44px] rounded-xl text-xs font-bold bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 transition cursor-pointer shadow-xs active:scale-95"
              title="Formu tamamlamadan işlemde olarak kaydet"
            >
              <Save className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span className="hidden xs:inline">Taslak Kaydet</span>
            </button>
          )}

          {/* Next Button (if not on last step) */}
          {!isLastStep && onNext && (
            <button
              type="button"
              onClick={onNext}
              className="flex items-center justify-center gap-1.5 px-5 py-2.5 min-h-[44px] rounded-xl text-xs sm:text-sm font-bold bg-teal-600 hover:bg-teal-500 text-white shadow-md transition active:scale-95 cursor-pointer"
            >
              <span>{nextLabel}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}

          {/* Final Submit Button (on last step, or if permitted) */}
          {isLastStep && onSubmit && (
            <button
              type="button"
              disabled={submitDisabled || isReadOnly || isSubmitting}
              onClick={onSubmit}
              className={`flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] rounded-xl text-xs sm:text-sm font-bold shadow-lg transition active:scale-95 cursor-pointer ${
                isReadOnly || submitDisabled
                  ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-300 dark:border-slate-700'
                  : 'bg-emerald-700 hover:bg-emerald-800 text-white'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Kaydediliyor...' : submitLabel}</span>
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
