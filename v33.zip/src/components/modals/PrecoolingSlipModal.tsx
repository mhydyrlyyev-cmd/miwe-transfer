import React, { useMemo, useState } from 'react';
import { X, Snowflake } from 'lucide-react';
import type { PrecoolingSlip, ReferenceItem } from '../../types';
import { INSPECTION_CLASSES, inspectionPercents } from '../../config/inspection';
import { nextSequence } from '../../utils/docNumbers';
import { Button, Tabs } from '../ui';

/**
 * v2.8 — Ön Soğutma Fişi (ayrı adım): %5 inspeksiyon (sınıf başına kg → % otomatik, kalibre)
 * ve şoklama verileri. Fiş partinin (RefID) kaydına eklenir; yeni koleksiyon yok.
 */
interface Props {
  reference: ReferenceItem;
  existingSlipNos: string[];
  /** Aynı üründe son fişte %5 inspeksiyon yapıldıysa true (varsayılan akış) */
  defaultInspection?: boolean;
  /** v2.8: bu partinin hasat günleri (tonaj ön soğutmada belli olur) */
  harvestDays?: { id: string; date: string; kg: number; dayNo?: number }[];
  currentUserName: string;
  onSave: (slip: PrecoolingSlip) => Promise<boolean | void>;
  onClose: () => void;
}

const num = (v: string): number | undefined => (v.trim() === '' ? undefined : Number(v.replace(',', '.')));

export default function PrecoolingSlipModal({ reference, existingSlipNos, defaultInspection = false, harvestDays = [], currentUserName, onSave, onClose }: Props) {
  const today = new Date();
  const ymd = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const prefix = `OSF-${String(today.getFullYear()).slice(2)}${String(today.getMonth() + 1).padStart(2, '0')}-`;
  const slipNo = useMemo(() => nextSequence(existingSlipNos, prefix), [existingSlipNos, prefix]);

  const [date, setDate] = useState(ymd);
  // v2.8: sezonluk meyveler doğrudan sortinge gider; %5 inspeksiyon yalnızca seçilince açılır
  const [mode, setMode] = useState<'SORTING' | 'FIVE_PERCENT'>(defaultInspection ? 'FIVE_PERCENT' : 'SORTING');
  const [people, setPeople] = useState('');
  const [rows, setRows] = useState(INSPECTION_CLASSES.map(c => ({ cls: c as string, kg: '', cal: '' })));
  const [netKg, setNetKg] = useState('');
  const [startAt, setStartAt] = useState('');
  const [endAt, setEndAt] = useState('');
  const [pulpBefore, setPulpBefore] = useState('');
  const [pulpAfter, setPulpAfter] = useState('');
  const [tunnel, setTunnel] = useState('');
  const [site, setSite] = useState<'ORCHARD' | 'CENTER'>('CENTER'); // v3.0: ön soğutma yeri
  const [packedKg, setPackedKg] = useState(''); // v3.3: pack-out
  const [culledKg, setCulledKg] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  // v2.8: tartılmamış en son hasat günü varsayılan; şoklanan kg o günün tonajı olarak yazılır
  const days = [...harvestDays].sort((a, b) => b.date.localeCompare(a.date));
  const firstUnweighed = days.find(d => !(d.kg > 0));
  const [harvestDayId, setHarvestDayId] = useState<string>(firstUnweighed?.id || days[0]?.id || '');
  const selectedDay = days.find(d => d.id === harvestDayId);
  const [writeToHarvest, setWriteToHarvest] = useState<boolean>(!!firstUnweighed);

  const pct = inspectionPercents(rows.map(r => ({ cls: r.cls, kg: num(r.kg) })));
  const sampleKg = pct.reduce((s, r) => s + r.kg, 0);

  const save = async () => {
    const parsed = [num(netKg), num(people), num(pulpBefore), num(pulpAfter), num(packedKg), num(culledKg), ...rows.flatMap(r => [num(r.kg), num(r.cal)])];
    if (parsed.some(v => v !== undefined && Number.isNaN(v))) { setError('Sayı alanlarına yalnızca sayı girin.'); return; }
    const inspecting = mode === 'FIVE_PERCENT';
    if (!inspecting && !(num(netKg) && num(netKg)! > 0)) { setError('Şoklanan net kg girin.'); return; }
    if (inspecting && !(num(netKg) && num(netKg)! > 0) && sampleKg <= 0) { setError('Şoklanan net kg veya inspeksiyon sonuçlarından en az birini girin.'); return; }
    const slip: PrecoolingSlip = {
      id: `osf-${Date.now()}`,
      slipNo,
      date,
      inspector: currentUserName || '—',
      inspectionMode: inspecting ? 'FIVE_PERCENT' : 'SORTING',
      // Doğrudan sortingde inspeksiyon verisi kaydedilmez (kapalı bölüm = kayıt yok)
      inspectionPeople: inspecting ? num(people) : undefined,
      inspection: inspecting
        ? rows.filter(r => num(r.kg) !== undefined || num(r.cal) !== undefined).map(r => ({ cls: r.cls, kg: num(r.kg), caliperMm: num(r.cal) }))
        : [],
      netKg: num(netKg),
      startAt: startAt || undefined,
      endAt: endAt || undefined,
      pulpBeforeC: num(pulpBefore),
      pulpAfterC: num(pulpAfter),
      tunnel: tunnel.trim() || undefined,
      site,
      packedKg: num(packedKg),
      culledKg: num(culledKg),
      note: note.trim() || undefined,
      harvestRecordId: harvestDayId || undefined,
      writtenToHarvest: !!(harvestDayId && writeToHarvest && num(netKg) && num(netKg)! > 0)
    };
    setSaving(true);
    const ok = await onSave(slip);
    setSaving(false);
    if (ok !== false) onClose();
  };

  const input = 'w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100';
  const label = 'block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label="Ön soğutma fişi" className="bg-white dark:bg-slate-900 w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2"><Snowflake className="w-4 h-4 text-sky-600" />Ön soğutma fişi</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400"><span className="font-mono">{slipNo}</span> · {reference.refId} · {reference.product}{reference.variety ? ` (${reference.variety})` : ''}</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Kapat" className="p-2 rounded-lg text-slate-500 min-h-[40px] min-w-[40px] flex items-center justify-center"><X className="w-5 h-5" /></button>
        </div>

        <div className="overflow-y-auto p-4 space-y-4">
          <div><label className={label}>Tarih</label><input type="date" className={input} value={date} onChange={e => setDate(e.target.value)} /></div>

          <div>
            <span className={label}>Akış</span>
            <Tabs
              ariaLabel="Akış"
              fullWidth
              value={mode}
              onChange={(k) => setMode(k as 'SORTING' | 'FIVE_PERCENT')}
              items={[{ key: 'SORTING', label: 'Doğrudan sorting' }, { key: 'FIVE_PERCENT', label: '%5 inspeksiyon' }]}
            />
            <p className="text-xs text-slate-500 mt-1">
              {mode === 'SORTING' ? 'Meyve inspeksiyonsuz doğrudan sortinge gidiyor; yalnızca şoklama bilgileri kaydedilir.' : 'Numunede sınıf ağırlıklarını girin; yüzde otomatik hesaplanır.'}
            </p>
          </div>

          {mode === 'FIVE_PERCENT' && (
          <section>
            <div className="mb-2"><label className={label}>İnspeksiyon ekibi (kişi)</label><input inputMode="numeric" className={input} value={people} onChange={e => setPeople(e.target.value)} /></div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">%5 inspeksiyon</h3>
            <p className="text-xs text-slate-500 mb-2">Her sınıfın numunedeki ağırlığını (kg) girin; yüzde otomatik hesaplanır. Kalibre isteğe bağlı.</p>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="grid grid-cols-[1fr_88px_72px_72px] gap-2 px-3 py-2 bg-slate-50 dark:bg-slate-800/60 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                <span>Sınıf</span><span>kg</span><span>Kalibre mm</span><span className="text-right">%</span>
              </div>
              {rows.map((r, i) => (
                <div key={r.cls} className="grid grid-cols-[1fr_88px_72px_72px] gap-2 px-3 py-1.5 items-center border-t border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-medium text-slate-800 dark:text-slate-200">{r.cls}</span>
                  <input aria-label={`${r.cls} kg`} inputMode="decimal" className={input + ' min-h-[40px]'} value={r.kg} onChange={e => setRows(rows.map((x, k) => k === i ? { ...x, kg: e.target.value } : x))} />
                  <input aria-label={`${r.cls} kalibre`} inputMode="decimal" className={input + ' min-h-[40px]'} value={r.cal} onChange={e => setRows(rows.map((x, k) => k === i ? { ...x, cal: e.target.value } : x))} />
                  <span className="text-right text-sm font-semibold tabular-nums text-slate-900 dark:text-white">{pct[i].pct === null ? '—' : pct[i].pct!.toLocaleString('tr-TR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })}</span>
                </div>
              ))}
              <div className="grid grid-cols-[1fr_88px_72px_72px] gap-2 px-3 py-2 border-t border-slate-200 dark:border-slate-700 text-xs font-semibold">
                <span>Numune toplamı</span><span className="tabular-nums">{sampleKg ? sampleKg.toLocaleString('tr-TR') : '—'}</span><span /><span className="text-right">{sampleKg ? '100' : '—'}</span>
              </div>
            </div>
          </section>
          )}

          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Şoklama (ön soğutma)</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2"><label className={label}>Şoklanan net (kg)</label><input inputMode="decimal" className={input} value={netKg} onChange={e => setNetKg(e.target.value)} /></div>
              {days.length > 0 && (
                <div className="col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 p-3 space-y-2">
                  <label className={label} htmlFor="osf-day">Hasat günü</label>
                  <select id="osf-day" className={input} value={harvestDayId} onChange={e => { setHarvestDayId(e.target.value); const d = days.find(x => x.id === e.target.value); setWriteToHarvest(!!d && !(d.kg > 0)); }}>
                    {days.map(d => <option key={d.id} value={d.id}>{d.date}{d.dayNo ? ` · ${d.dayNo}. gün` : ''} · {d.kg > 0 ? `${d.kg.toLocaleString('tr-TR')} kg` : 'tartılmadı'}</option>)}
                  </select>
                  <label className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <input type="checkbox" className="w-4 h-4 mt-0.5" checked={writeToHarvest} onChange={e => setWriteToHarvest(e.target.checked)} />
                    <span>Şoklanan net kg bu günün <strong>hasat tonajı</strong> olarak yazılsın{selectedDay && selectedDay.kg > 0 ? ` (şu an ${selectedDay.kg.toLocaleString('tr-TR')} kg; üzerine yazılır)` : ''}. Parti numarası değişmez; fire bu tartımdan sonra hesaplanır.</span>
                  </label>
                </div>
              )}
              <div><label className={label}>Başlangıç</label><input type="datetime-local" className={input} value={startAt} onChange={e => setStartAt(e.target.value)} /></div>
              <div><label className={label}>Bitiş</label><input type="datetime-local" className={input} value={endAt} onChange={e => setEndAt(e.target.value)} /></div>
              <div><label className={label}>Meyve içi önce (°C)</label><input inputMode="decimal" className={input} value={pulpBefore} onChange={e => setPulpBefore(e.target.value)} /></div>
              <div><label className={label}>Meyve içi sonra (°C)</label><input inputMode="decimal" className={input} value={pulpAfter} onChange={e => setPulpAfter(e.target.value)} /></div>
              <div className="col-span-2">
                <span className={label}>Ön soğutma yeri</span>
                <Tabs ariaLabel="Ön soğutma yeri" fullWidth value={site} onChange={(k) => setSite(k as 'ORCHARD' | 'CENTER')}
                  items={[{ key: 'CENTER', label: 'Merkez depoda' }, { key: 'ORCHARD', label: 'Bahçenin tesisinde' }]} />
              </div>
              <div className="col-span-2"><label className={label}>Tünel / oda</label><input className={input} value={tunnel} onChange={e => setTunnel(e.target.value)} /></div>
              <div className="col-span-2 pt-1">
                <span className={label}>Sorting sonucu (pack-out için, isteğe bağlı)</span>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className={label}>Paketlenen kg</label><input inputMode="decimal" className={input} value={packedKg} onChange={e => setPackedKg(e.target.value)} /></div>
                  <div><label className={label}>Iskarta kg</label><input inputMode="decimal" className={input} value={culledKg} onChange={e => setCulledKg(e.target.value)} /></div>
                </div>
              </div>
              <div className="col-span-2"><label className={label}>Not</label><input className={input} value={note} onChange={e => setNote(e.target.value)} /></div>
            </div>
          </section>
          {error && <p className="text-xs text-rose-700" role="alert">{error}</p>}
        </div>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))]">
          <Button variant="soft" tone="slate" onClick={onClose} disabled={saving}>Vazgeç</Button>
          <Button variant="primary" loading={saving} onClick={save}>Fişi kaydet</Button>
        </div>
      </div>
    </div>
  );
}
