/**
 * MIWE HIL — Ürün Kalite Spesifikasyonları & Kabul Toleransları
 * ------------------------------------------------------------------
 * Kural: Eşik / tolerans uydurulmaz; yalnızca bu dosyadaki değerler esas alınır.
 * Değer null ise = tanımsız (kullanıcı veya kalite departmanı belirleyene kadar).
 */

export interface ProductSpec {
  class1MinPct: number | null;
  mechanicalMaxPct: number | null;
  rottenMaxPct: number | null;
  softMaxPct: number | null;
  internalMaxPct: number | null;
  moldMaxPct: number | null;
  coldDamageMaxPct: number | null;
  firmnessMin: number | null;
  firmnessMax: number | null;
  transportTempMinC: number | null;
  transportTempMaxC: number | null;
  /** v3.3 Soğuk zincir hedefleri (null = tanımsız; kalite departmanı belirler) */
  storageTempMinC?: number | null;
  storageTempMaxC?: number | null;
  storageHumidityMinPct?: number | null;
  storageHumidityMaxPct?: number | null;
  /** Ön soğutma sonunda meyve içi sıcaklık üst sınırı */
  precoolPulpMaxC?: number | null;
  /** Ön soğutmanın en uzun süresi (saat) */
  precoolMaxHours?: number | null;
}

/** İki logger ortalaması arasındaki uyarı farkı (°C) */
export const LOGGER_CONFLICT_WARN_C = 2;

export const PRODUCT_SPECS: Record<string, ProductSpec> = {
  Avokado: {
    class1MinPct: 90, // UNECE FFV-42 / Codex CXS 197-1995 — Sınıf I kalite toleransı: sayıca veya ağırlıkça %10
    mechanicalMaxPct: null,
    rottenMaxPct: null,
    softMaxPct: null,
    internalMaxPct: null,
    moldMaxPct: null,
    coldDamageMaxPct: null,
    firmnessMin: null,
    firmnessMax: null,
    transportTempMinC: null,
    transportTempMaxC: null,
  },
  Varsayilan: {
    class1MinPct: null,
    mechanicalMaxPct: null,
    rottenMaxPct: null,
    softMaxPct: null,
    internalMaxPct: null,
    moldMaxPct: null,
    coldDamageMaxPct: null,
    firmnessMin: null,
    firmnessMax: null,
    transportTempMinC: null,
    transportTempMaxC: null,
  },
};

export function getProductSpec(productName?: string): ProductSpec {
  if (!productName) return PRODUCT_SPECS.Varsayilan;
  const match = Object.keys(PRODUCT_SPECS).find(
    k => k.toLowerCase() === productName.trim().toLowerCase()
  );
  return match ? PRODUCT_SPECS[match] : PRODUCT_SPECS.Varsayilan;
}


/**
 * v3.3 — Oda sıcaklığının, kontrolde girilen AYAR sıcaklığından izin verilen sapması (°C).
 * Bu bir standart değil, işletme toleransıdır; kalite departmanı değiştirebilir.
 */
export const SETPOINT_TOLERANCE_C = 1.0;

/** v3.3 — Ürün adına göre spesifikasyon (çeşit parantezi yok sayılır; tanım yoksa Varsayilan = hepsi boş) */
export function specForProduct(product?: string): ProductSpec {
  const base = (product || '').replace(/\s*\(.*\)\s*$/, '').trim();
  return getProductSpec(base);
}
