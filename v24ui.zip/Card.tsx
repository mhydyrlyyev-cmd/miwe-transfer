import React from 'react';
import { cx } from './cx';

export interface CardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  /** Başlık satırının sağındaki öğeler (ör. ikincil düğme) */
  actions?: React.ReactNode;
  /** İç boşluk: varsayılan 16px */
  padding?: 'none' | 'sm' | 'md';
  /** Sol kenarda ince vurgu çizgisi (marka rengi veya durum) */
  accent?: 'brand' | 'ok' | 'warn' | 'error' | null;
}

const PAD = { none: '', sm: 'p-3', md: 'p-4' };
const ACCENT = {
  brand: 'before:bg-brand-primary',
  ok: 'before:bg-emerald-500',
  warn: 'before:bg-amber-500',
  error: 'before:bg-rose-500'
};

/** Beyaz zemin, 1px çizgi, 12px köşe, hafif gölge. */
export function Card({ title, subtitle, actions, padding = 'md', accent = null, className, children, ...rest }: CardProps) {
  return (
    <div
      className={cx(
        'relative bg-white border border-slate-200 rounded-xl shadow-[0_1px_2px_rgba(15,23,42,0.06)] overflow-hidden',
        'dark:bg-slate-900 dark:border-slate-800',
        accent && cx("before:content-[''] before:absolute before:left-0 before:top-0 before:bottom-0 before:w-1", ACCENT[accent]),
        PAD[padding],
        className
      )}
      {...rest}
    >
      {(title || actions) && (
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            {title && <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{subtitle}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

export default Card;
