import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { cx } from './cx';

export interface PageHeaderProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  onBack?: () => void;
  backLabel?: string;
  /** Sağ taraf: en fazla bir birincil düğme */
  actions?: React.ReactNode;
  className?: string;
}

export function PageHeader({ title, subtitle, onBack, backLabel = 'Geri', actions, className }: PageHeaderProps) {
  return (
    <div className={cx('flex items-start gap-3', className)}>
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          aria-label={backLabel}
          className="shrink-0 w-11 h-11 rounded-xl border border-slate-200 bg-white text-slate-700 flex items-center justify-center hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      )}
      <div className="flex-1 min-w-0">
        <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-tight">{title}</h1>
        {subtitle && <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}

export default PageHeader;
