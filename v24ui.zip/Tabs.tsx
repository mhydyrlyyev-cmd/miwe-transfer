import React, { useRef } from 'react';
import { cx } from './cx';

export interface TabItem<K extends string = string> {
  key: K;
  label: React.ReactNode;
  icon?: React.ReactNode;
  count?: number;
  disabled?: boolean;
}

export interface TabsProps<K extends string = string> {
  items: TabItem<K>[];
  value: K;
  onChange: (key: K) => void;
  /** segment: dolgu arka planlı grup; underline: alt çizgili sekmeler */
  variant?: 'segment' | 'underline';
  ariaLabel?: string;
  className?: string;
  fullWidth?: boolean;
}

/** Erişilebilir sekmeler: ok tuşlarıyla gezinme, yatayda kendi içinde kayar (sayfa kaymaz). */
export function Tabs<K extends string = string>({ items, value, onChange, variant = 'segment', ariaLabel, className, fullWidth = false }: TabsProps<K>) {
  const refs = useRef<Array<HTMLButtonElement | null>>([]);

  const onKey = (e: React.KeyboardEvent, idx: number) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    const dir = e.key === 'ArrowRight' ? 1 : -1;
    for (let i = 1; i <= items.length; i++) {
      const next = (idx + dir * i + items.length) % items.length;
      if (!items[next].disabled) {
        refs.current[next]?.focus();
        onChange(items[next].key);
        break;
      }
    }
  };

  const isSeg = variant === 'segment';
  return (
    <div className={cx('max-w-full overflow-x-auto', className)}>
      <div
        role="tablist"
        aria-label={ariaLabel}
        className={cx(
          'inline-flex min-w-full',
          isSeg ? 'gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:border-slate-700' : 'gap-4 border-b border-slate-200 dark:border-slate-800',
          fullWidth && 'w-full'
        )}
      >
        {items.map((it, idx) => {
          const active = it.key === value;
          return (
            <button
              key={it.key}
              ref={el => { refs.current[idx] = el; }}
              type="button"
              role="tab"
              aria-selected={active}
              tabIndex={active ? 0 : -1}
              disabled={it.disabled}
              onClick={() => onChange(it.key)}
              onKeyDown={e => onKey(e, idx)}
              className={cx(
                'inline-flex items-center justify-center gap-1.5 whitespace-nowrap text-xs font-semibold min-h-[40px] transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 disabled:opacity-40',
                fullWidth && 'flex-1',
                isSeg
                  ? cx('px-3 rounded-lg', active
                      ? 'bg-white text-slate-900 shadow-sm border border-slate-200 dark:bg-slate-900 dark:text-white dark:border-slate-700'
                      : 'text-slate-600 hover:text-slate-900 border border-transparent dark:text-slate-400 dark:hover:text-white')
                  : cx('px-1 -mb-px border-b-2', active
                      ? 'border-brand-primary text-slate-900 dark:border-teal-400 dark:text-white'
                      : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white')
              )}
            >
              {it.icon && <span aria-hidden="true" className="inline-flex [&>svg]:w-4 [&>svg]:h-4">{it.icon}</span>}
              {it.label}
              {typeof it.count === 'number' && (
                <span className={cx('ml-0.5 px-1.5 rounded-md text-[10px] font-bold', active ? 'bg-teal-50 text-teal-800 dark:bg-teal-950 dark:text-teal-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200')}>
                  {it.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default Tabs;
