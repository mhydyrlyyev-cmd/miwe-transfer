import React from 'react';
import { FlaskConical } from 'lucide-react';
import { cx } from './cx';

export type BadgeTone = 'ok' | 'warn' | 'error' | 'nodata' | 'demo' | 'info' | 'neutral';

/** Renkler Özet ekranındaki durum çipleriyle aynı aileden (emerald / amber / rose / slate). */
const TONES: Record<BadgeTone, string> = {
  ok: 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-900',
  warn: 'bg-amber-50 text-amber-900 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-900',
  error: 'bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-900',
  nodata: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
  demo: 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950/60 dark:text-amber-200 dark:border-amber-700',
  info: 'bg-sky-50 text-sky-800 border-sky-200 dark:bg-sky-950/50 dark:text-sky-300 dark:border-sky-900',
  neutral: 'bg-white text-slate-700 border-slate-300 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-700'
};

const DEFAULT_LABEL: Partial<Record<BadgeTone, string>> = {
  ok: 'OK', warn: 'UYARI', error: 'HATA', nodata: 'VERİ YOK', demo: 'DEMO'
};

export interface BadgeProps {
  tone?: BadgeTone;
  children?: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
  title?: string;
}

export function Badge({ tone = 'neutral', children, icon, className, title }: BadgeProps) {
  const content = children ?? DEFAULT_LABEL[tone] ?? '';
  const showIcon = icon ?? (tone === 'demo' ? <FlaskConical className="w-3 h-3" /> : null);
  return (
    <span
      title={title}
      className={cx('inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[11px] font-bold leading-4 whitespace-nowrap', TONES[tone], className)}
    >
      {showIcon && <span aria-hidden="true" className="inline-flex">{showIcon}</span>}
      {content}
    </span>
  );
}

export default Badge;
