import React from 'react';
import { Loader2 } from 'lucide-react';
import { cx } from './cx';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Sol ikon (lucide, 16px önerilir) */
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  loading?: boolean;
  fullWidth?: boolean;
}

const VARIANTS: Record<ButtonVariant, string> = {
  // Ekran başına TEK birincil düğme kullanın
  primary: 'bg-brand-primary text-white hover:bg-teal-800 active:bg-teal-900 border border-transparent shadow-sm dark:bg-teal-600 dark:hover:bg-teal-500',
  secondary: 'bg-white text-slate-800 border border-slate-300 hover:bg-slate-50 hover:border-slate-400 dark:bg-slate-900 dark:text-slate-100 dark:border-slate-700 dark:hover:bg-slate-800',
  ghost: 'bg-transparent text-slate-700 border border-transparent hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800',
  danger: 'bg-white text-rose-700 border border-rose-300 hover:bg-rose-50 dark:bg-slate-900 dark:text-rose-300 dark:border-rose-800 dark:hover:bg-rose-950/40'
};

const SIZES: Record<ButtonSize, string> = {
  sm: 'min-h-[40px] px-3 text-xs gap-1.5',
  md: 'min-h-[44px] px-4 text-sm gap-2'
};

/**
 * Ortak düğme. Varsayılan type="button" — form gönderen düğmelerde type="submit" verin.
 */
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'secondary', size = 'md', icon, iconRight, loading = false, fullWidth = false, className, children, disabled, type, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      type={type ?? 'button'}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx(
        'inline-flex items-center justify-center rounded-xl font-semibold whitespace-nowrap select-none',
        'transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        VARIANTS[variant],
        SIZES[size],
        fullWidth && 'w-full',
        className
      )}
      {...rest}
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : icon ? <span className="inline-flex shrink-0 [&>svg]:w-4 [&>svg]:h-4" aria-hidden="true">{icon}</span> : null}
      {children != null && <span className="truncate">{children}</span>}
      {iconRight && !loading && <span className="inline-flex shrink-0 [&>svg]:w-4 [&>svg]:h-4" aria-hidden="true">{iconRight}</span>}
    </button>
  );
});

export default Button;
