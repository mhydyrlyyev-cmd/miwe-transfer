import React from 'react';
import { Inbox } from 'lucide-react';
import { cx } from './cx';

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}

/** Veri yokken gösterilir. Asla sahte değer üretmeyin; bunu kullanın. */
export function EmptyState({ icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div className={cx('flex flex-col items-center justify-center text-center px-4 py-8 rounded-xl border border-dashed border-slate-300 bg-slate-50 dark:bg-slate-900/50 dark:border-slate-700', className)}>
      <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500 mb-3 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400" aria-hidden="true">
        {icon ?? <Inbox className="w-5 h-5" />}
      </div>
      <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{title}</p>
      {description && <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export default EmptyState;
