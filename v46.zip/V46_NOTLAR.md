# v46 — Temizlik + 4 ekran ana sayfa tasarım dilinde + bahçe konumları

Önce v45 doğrulanır (tsc + build). Sonra bu paket uygulanır.

## Silinecek 15 dosya (hiçbir yerden kullanılmıyor, ~7.900 satır)
src/components/DashboardStats.tsx
src/components/EnterprisesModal.tsx
src/components/SystemLogViewer.tsx
src/components/views/PwaInstallModal.tsx
src/components/views/AnalyticsView.tsx
src/components/views/HarvestCrateQrModal.tsx
src/components/views/ParcelVarianceModal.tsx
src/components/common/SplitLotsQualityManager.tsx
src/components/common/PhotoUpload.tsx
src/components/dashboard/IoTSensorTelemetryPanel.tsx   (rastgele sayı üreten sahte IoT paneli)
src/components/dashboard/CompactPlatformSelector.tsx
src/components/analytics/FaoSustainabilityPanel.tsx
src/components/portal/PlatformNavigationModal.tsx
src/components/portal/HarvestCalendarNotificationsBar.tsx
src/components/portal/ReportingPresentationPortal.tsx

## Yeni ortak parçalar (src/components/ui)
Stat (sayı kutusu), Segmented (gri zemin seçici), ListRow (renkli nokta + satır), Meter (etiketli çubuk).

## Yeni tasarıma geçen ekranlar
- Kalite (QualityInsightCard): 3 sayı → "Bekleyen karar" listesi → ürüne göre sonuç (kaynak etiketiyle). Freeze-Dry yalnız iki adımlı onayla.
- Uyarılar (AlertsView + ColdChainPanel): renkli kutular yerine "Şimdi bakılmalı / Bugün içinde / Bilgi" grupları; aşama rozeti; RefID çakışmaları "Kayıt düzeltmesi" kartında.
- Soğuk zincir (ColdChainReport): 2 sayı, "Ürün nerede?" aşama çubukları, "Düzeltilmesi gereken" listesi (satıra dokununca parti açılır); tek değerli grafikler cümleye döner.
- Parti pasaportu (PdfColdChainSection): dikey yolculuk; eksik adım turuncu "kayıt yok"; kütle dengesi tek cümle + "Açıkta" kg.

## Bahçe konumları (src/config/orchardLocations.ts)
Bagyr, Durun, Saýwan Gursak, Saýwan Nektarin, 1200 ha (MIWE OJSC), 1600 ha. v49 hava durumu için.

DeployRules: GEREKMEZ. Yeni paket yok.
