# v49a2 — Takvim sadeleştirme, sortlamaya alma, pasaport düzeltmeleri

- Hasat takvimi: 2026 artık arşiv görünümü (canlı kartlar, "kaydı eksik", "sıradaki 14 gün" yalnız 2027 sezonunda). "Tablodaki veri sorunları" listesi kaldırıldı. Bahçesi boş ve "bakılacak / belirsiz" not satırları takvimde yok. Filtreler başlığın altına alındı (başlık sıkışmıyor). Lejanta "Pencereden geç" (sarı) eklendi. Geçmiş farkı yalnız ≥7 günse ve açık cümleyle yazılır.
- Profiller: var olan bahçe profiline (ör. "Garahan 1200, Kaka") tohum verisi yalnız BOŞ alanlara ve eksik diğer adlara eklenir; senin girdiğin değer değişmez. Hava ve hasat eşleşmesi diğer adlarla çalışır.
- Sortlama sayfası: "Sortlamaya alınabilir" listesi; "Sortlamaya al" ön soğutma fişini açar (Doğrudan sorting).
- Pasaport (PDF): durum Türkçe (RECEIVED → Depoda); test yoksa "Sınıf 1" yerine "Sınıf testi yok"; depo/hedef gerçek depo ve oda; "Parti yolculuğu" başlığı; "Kayıtlı miktar"; telefonda alt yazı düğmelerin altında kalmıyor; yalnız tarih girilen kayıtta 00:00 saati gösterilmez.
- Giriş ekranı: "Admin Portalı" → "Yönetici girişi"; seçili sekmede beyaz yazı (okunurluk).

## SHA-256 (7 dosya)
3edc2a27be7370261d299cab6cc0867d2bd87de374129e7bc7eaeded5aa4c6cb  src/components/auth/LoginView.tsx
03fc2a83a717fb1a2bf2e7128c88d8393d9e107a6140fba7d658d3e56413166f  src/components/reports/PdfColdChainSection.tsx
dd4196e53192c6038e51bbfcf5daf53839de7f300071fcd641b93439d4c5ebe8  src/components/views/HarvestCalendarView.tsx
8be6b3dab94ca92c3578b4e51ade4afa7788aca16158333205c4b27c457f7d58  src/components/views/MultiPagePdfReportModal.tsx
cea8876653a23cb88b4e0244c11274eb624b60285495e73e87783d6e3b99e9f6  src/components/views/StageMonitorView.tsx
e36d40bd462345fed9269381eba0c43664dc7ae32a786549695c243652dce2dc  src/services/harvestCalendar.ts
627f17703615bcf276a0ec6aa2803ac89c8df5d68260952202b2234af329a020  src/services/locationProfiles.ts
