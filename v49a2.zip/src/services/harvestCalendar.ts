/**
 * v49a — Hasat takvimi motoru.
 * Kaynaklar: tohum tablosu (Miwe_2026) + kullanıcı düzeltmeleri (BBCH gözlemi, elle tarih, rewiz, işçi)
 * + günlük hasat kayıtları (gerçek kg ve işçi). Hesap her açılışta yeniden yapılır; kopya tutulmaz.
 *
 * Kurallar (sizin tablodaki yöntem):
 *  - Pencere = BBCH 65 tarihi + min/max gün. BBCH 65 yoksa geçmiş yılların ortalama hasat günü ± 5 gün.
 *  - Elle girilen başlangıç/bitiş tarihi her zaman otomatik tahminin önüne geçer.
 *  - Tahmini bitiş = kalan ton ÷ (işçi × kg/işçi/gün). Pencere sonunu aşarsa risk + ek işçi önerisi.
 * Kayıt: Firestore 'ganttParcels' koleksiyonu (calV: 49 alanlı belgeler) + yerel önbellek.
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import { CAL_SEED_ROWS, type CalSeedRow } from '../config/harvestCalendarSeed';
import { canonicalOrchard } from './locationProfiles';
import type { HarvestRecord } from '../types';

export type BbchStage = '65' | '71' | '81' | '85';
export const BBCH_LABEL: Record<BbchStage, string> = { '65': 'Çiçek %75', '71': 'Meyve tutumu', '81': 'Olgunlaşma', '85': 'Hasat olgunluğu' };

export interface CalOverride {
  id: string;
  calV: 49;
  season: number;
  orchard: string;
  variety: string;
  bbch?: Partial<Record<BbchStage, string>>;
  diameterMm?: number;
  manualStart?: string;
  manualEnd?: string;
  rewizTon?: number;
  workers?: number;
  kgPerWorker?: number;
  minDays?: number;
  maxDays?: number;
  completedAt?: string;
  note?: string;
  updatedAt: string;
  updatedBy?: string;
}

const LS_KEY = 'miwe_harvest_cal_v49';
let overrides: CalOverride[] = (() => { try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS_KEY, JSON.stringify(overrides)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let remoteLoaded = false;
async function loadRemote() {
  if (remoteLoaded) return; remoteLoaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: CalOverride[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v && v.calV === 49) remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const map = new Map(overrides.map(o => [o.id, o]));
    for (const r of remote) { const l = map.get(r.id); if (!l || r.updatedAt > l.updatedAt) map.set(r.id, r); }
    overrides = [...map.values()];
    emit();
  } catch { /* çevrimdışı: yerel kullanılır */ }
}
export function useCalOverrides(): CalOverride[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); loadRemote(); return () => { listeners.delete(l); }; }, []);
  return overrides;
}
const slug = (s: string) => s.toLocaleLowerCase('tr').replace(/[^a-z0-9çğıöşüý]+/gi, '-').replace(/^-|-$/g, '').slice(0, 60);
export const calId = (season: number, orchard: string, variety: string) => `cal-${season}-${slug(orchard)}-${slug(variety)}`;

export async function saveCalOverride(season: number, orchard: string, variety: string, patch: Partial<CalOverride>, by?: string): Promise<boolean> {
  const id = calId(season, orchard, variety);
  const cur = overrides.find(o => o.id === id);
  const next: CalOverride = { ...(cur || { id, calV: 49, season, orchard, variety }), ...patch, bbch: { ...(cur?.bbch || {}), ...(patch.bbch || {}) }, id, calV: 49, season, orchard, variety, updatedAt: new Date().toISOString(), updatedBy: by };
  overrides = cur ? overrides.map(o => (o.id === id ? next : o)) : [...overrides, next];
  emit();
  try { return await saveRecordToFirestore('GANTT', next); } catch { return false; }
}

// ── tarih yardımcıları ──
const DAY = 86400000;
export const parseD = (s?: string | null) => (s ? Date.parse(`${s}T00:00:00`) : NaN);
export const fmtD = (t: number) => { if (!Number.isFinite(t)) return '—'; const d = new Date(t); return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`; };
export const isoD = (t: number) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const doy = (t: number) => { const d = new Date(t); return Math.round((t - new Date(d.getFullYear(), 0, 1).getTime()) / DAY); };
const onYear = (dayOfYear: number, year: number) => new Date(year, 0, 1).getTime() + dayOfYear * DAY;
const norm = (s?: string) => String(s || '').toLocaleLowerCase('tr').replace(/ý/g, 'y').replace(/[^a-z0-9çğıöşü]+/g, '');

export type CalStatus = 'NOT_STARTED' | 'ACTIVE' | 'DONE';
export type CalRisk = 'OK' | 'RISK' | 'LATE' | 'NONE';

export interface CalItem {
  key: string;
  seed: CalSeedRow;
  ov?: CalOverride;
  season: number;
  orchard: string;
  fruit: string;
  variety: string;
  bbch65?: number;
  windowStart?: number;
  windowEnd?: number;
  windowSource: string;
  histAvg?: number;          // geçmiş yılların ortalama başlangıcı (bu sezona taşınmış)
  histYears: number;
  start?: number;            // gerçek başlangıç
  end?: number;              // gerçek bitiş
  targetTon?: number;
  targetSource: string;
  doneTon: number;
  offgradeTon?: number;
  workers?: number;
  kgPerWorker?: number;
  ratePerDay?: number;       // t/gün
  finishEst?: number;
  status: CalStatus;
  risk: CalRisk;
  advice?: string;
  histGapDays?: number;      // pencere başlangıcı − geçmiş ortalama (gün)
  hasProgress: boolean;
}

function harvestFor(records: HarvestRecord[], orchard: string, variety: string, season: number) {
  const v = norm(variety.split('(')[0]);
  if (v.length < 3) return [] as HarvestRecord[];
  return records.filter(h => {
    const y = String(h.recordDate || h.timestamp || '').slice(0, 4);
    if (y !== String(season)) return false;
    if (canonicalOrchard(h.orchard) !== canonicalOrchard(orchard)) return false;
    const hv = norm(`${(h as any).variety || ''} ${h.product || ''}`);
    return hv.includes(v);
  });
}

export function buildCalendar(season: number, ovs: CalOverride[], harvestRecords: HarvestRecord[], today = Date.now()): CalItem[] {
  // v49b: bahçesi boş ve 'bakılacak / belirsiz' not satırları takvime alınmaz
  return CAL_SEED_ROWS.filter(r => r.orchard && r.orchard !== '—' && !/bakıla|bakila|belirsiz/i.test(r.variety)).map(seed => {
    const orchard = seed.orchard;
    const ov = ovs.find(o => o.id === calId(season, orchard, seed.variety));
    const minD = ov?.minDays ?? seed.minDays ?? undefined;
    const maxD = ov?.maxDays ?? seed.maxDays ?? undefined;
    const b65 = season === 2026 ? parseD(seed.bbch65) : parseD(ov?.bbch?.['65']);
    // geçmiş: 2024, 2025 (+2026 gerçek, 2027 için)
    const hist = [seed.h2024, seed.h2025, season > 2026 ? seed.start2026 : null].map(parseD).filter(Number.isFinite);
    const histAvg = hist.length ? onYear(Math.round(hist.reduce((a, t) => a + doy(t), 0) / hist.length), season) : undefined;

    let ws: number | undefined; let we: number | undefined; let src = '';
    if (Number.isFinite(b65) && minD != null && maxD != null) { ws = b65 + Math.min(minD, maxD) * DAY; we = b65 + Math.max(minD, maxD) * DAY; src = `BBCH 65 + ${Math.min(minD, maxD)}–${Math.max(minD, maxD)} gün`; }
    else if (histAvg) { ws = histAvg - 5 * DAY; we = histAvg + 5 * DAY; src = `${hist.length} yıl ortalaması ± 5 gün`; }
    if (ov?.manualStart) { ws = parseD(ov.manualStart); src = 'elle girilen tarih'; }
    if (ov?.manualEnd) { we = parseD(ov.manualEnd); }
    if (ws && we && we < ws) we = ws;

    // gerçek
    const recs = harvestFor(harvestRecords, orchard, seed.variety, season);
    let start: number | undefined; let end: number | undefined; let doneTon = 0; let workers = ov?.workers;
    if (season === 2026) {
      start = parseD(seed.start2026) || undefined; end = parseD(seed.end2026) || undefined;
      doneTon = seed.soldTon ?? 0;
      workers = workers ?? seed.workers ?? undefined;
    }
    if (recs.length) {
      const ts = recs.map(h => parseD(String(h.recordDate || h.timestamp).slice(0, 10))).filter(Number.isFinite).sort((a, b) => a - b);
      start = start ?? ts[0];
      const kg = recs.reduce((a, h) => a + (Number(h.dailyTotalKg) || 0), 0);
      if (season !== 2026) doneTon = kg / 1000;
      const last = [...recs].sort((a, b) => String(b.recordDate || b.timestamp).localeCompare(String(a.recordDate || a.timestamp)))[0];
      if (!ov?.workers && Number(last?.workerCount) > 0) workers = Number(last.workerCount);
      if (season !== 2026 && ov?.completedAt) end = parseD(ov.completedAt);
    }
    const kgPerWorker = ov?.kgPerWorker ?? seed.kgPerWorker ?? undefined;
    const targetTon = ov?.rewizTon ?? (season === 2026 ? (seed.rewizTon ?? seed.planTon ?? undefined) : (seed.plan2027Ton ?? undefined));
    const targetSource = ov?.rewizTon != null ? 'rewiz (elle)' : season === 2026 ? (seed.rewizTon != null ? 'rewiz (agronom)' : 'plan (bütçe)') : 'plan 2027 (tonaj Excel)';

    let status: CalStatus = 'NOT_STARTED';
    const pastSeason = season < new Date(today).getFullYear();
    if (season === 2026) status = /tamam/.test(seed.status || '') || end || (pastSeason && start) ? 'DONE' : start ? 'ACTIVE' : 'NOT_STARTED';
    else status = ov?.completedAt ? 'DONE' : doneTon > 0 ? (targetTon && doneTon >= targetTon * 0.98 ? 'DONE' : 'ACTIVE') : 'NOT_STARTED';

    const rate = workers && kgPerWorker ? (workers * kgPerWorker) / 1000 : undefined;
    let finishEst: number | undefined; let risk: CalRisk = 'NONE'; let advice: string | undefined;
    const hasProgress = recs.length > 0 || doneTon > 0;
    if (status === 'ACTIVE' && !hasProgress) { risk = 'NONE'; advice = 'Hasat başlamış görünüyor ama kg kaydı veya bitiş tarihi yok'; }
    else if (status === 'ACTIVE' && targetTon && rate) {
      const remain = Math.max(0, targetTon - doneTon);
      const days = Math.ceil(remain / rate);
      finishEst = Math.max(today, start || today) + days * DAY;
      if (we && finishEst > we) {
        risk = 'RISK';
        const daysLeft = Math.max(1, Math.round((we - today) / DAY));
        const need = Math.ceil((remain * 1000) / (kgPerWorker! * daysLeft));
        advice = need > (workers || 0) ? `+${need - (workers || 0)} işçi (${need}) ile pencere içinde biter · ya da mesai · kalan için 1-MCP` : 'Mesai ile pencere içinde biter';
      } else risk = 'OK';
    } else if (status === 'DONE' && we && end) risk = end > we + DAY ? 'LATE' : 'OK';
    else if (status === 'NOT_STARTED' && we && today > we && !pastSeason) risk = 'LATE';

    return {
      key: `${orchard}|${seed.variety}|${seed.row}`, seed, ov, season, orchard, fruit: seed.fruit, variety: seed.variety,
      bbch65: Number.isFinite(b65) ? b65 : undefined, windowStart: ws, windowEnd: we, windowSource: src || 'veri yok',
      histAvg, histYears: hist.length, start, end, targetTon, targetSource, doneTon, offgradeTon: season === 2026 ? (seed.offgradeTon ?? undefined) : undefined,
      workers, kgPerWorker, ratePerDay: rate, finishEst, status, risk, advice,
      hasProgress,
      histGapDays: histAvg && ws ? Math.round((ws - histAvg) / DAY) : undefined,
    };
  });
}

/** BBCH beklenen tarih: geçen sezon aynı aşamanın günü bu sezona taşınır (yoksa yok). */
export function expectedBbch(item: CalItem, stage: BbchStage): number | undefined {
  const prev = (item.seed as any)[`bbch${stage}`] as string | null;
  if (!prev) return undefined;
  const t = parseD(prev);
  return Number.isFinite(t) ? onYear(doy(t), item.season) : undefined;
}
export function bbchVerdict(observed?: string, expected?: number): { label: string; tone: 'ok' | 'late' | 'early' } | undefined {
  const o = parseD(observed);
  if (!Number.isFinite(o) || !expected) return undefined;
  const diff = Math.round((o - expected) / DAY);
  if (Math.abs(diff) <= 3) return { label: 'uyuştu', tone: 'ok' };
  return diff > 0 ? { label: `${diff} gün geç`, tone: 'late' } : { label: `${-diff} gün erken`, tone: 'early' };
}
