# V65 NOTLAR — aynı bahçenin ayrı görünmesi (kesin çözüm: Birleştir düğmesi) + bahçe sırası düzeltmesi · v64 dahil

Taban: v63 (220). v64 uygulandıysa da uygulanmadıysa da bu paket yeter (v64'ün 11 dosyası içinde). Sonuç: 224 dosya. Silinecek yok. Firestore kuralı değişmedi.

## Dosyalar (SHA-256)
fa9ed5bac9cd71bb829e31d3c737f0b638b36dcb24b846968d05ec290c00b225  src/services/locationProfiles.ts
af580d0ac4e0cf354fabef5ca0f9fab3587d6faa8dc45a4a1d9a56c6ecce8530  src/components/views/OrchardCardsView.tsx
819a72f99b156fdeef34d3c951d69cd66d713d9853f1942f1a5e11709123cc55  src/config/fireNormative.ts
4043ba61cc3e25b7d082d02f7166fdb8e22ea5a6a82724931452d3fa46b07b4e  src/config/bbchCodes.ts
82e86a148513e1836d772953230b1abad2a6737c676cc56d59f9a46e84d17af3  src/services/mzLog.ts
9893cdad9922f381b8ab551ad5951ee81f54461ad55c006ccfa93bd91ca6d047  src/components/views/MzLogPanel.tsx
3e617ff3a68d54c187f0923a2e6ff08b7ee2e1cef52fe2dd065e51d0958ca931  src/components/forms/QuickTestForm.tsx
f14c82dadbce7e4131742f0ee8ddfe863729415003cd9985a2e8908d6258519a  src/types.ts
d73f42a0815a0b967c8dcc445dccdff40ca62693c2ca14027c773bca0af1ab24  src/components/views/TestDetailSheet.tsx
6a181dea6d9e26644989a31f937cdfee541e19e11e28ac97b9be99e543ecbb3e  src/components/views/TestHubView.tsx
c3055b4722895fee954c1d8bd0a5b7f1086ac38603a15cb287567dca0a283ae7  src/components/views/DepotsView.tsx
8985b38dcf230993930f48f5ad59b7931159cc1833ee65ef39a9aee54a9bdfbc  src/components/views/BademFlowView.tsx

## Ne değişti (v65)
- Yer adı eşleştirme: bahçe adından sonra gelen herhangi bir işaret (farklı virgül türleri, nokta, tire, parantez) ve bir depo adı ("Garahan 1200 Kaka") bahçeye bağlanır. Koruma: kendisi bir bahçe adı olan ("Saýwan Gursak") veya devamı başka bir bahçe adı olan ("Saýwan, Gursak") yazımlar birleşmez.
- Kesin çözüm: içi boş (çeşit, parsel, plan yok) bir yer kartının Özet'inde "… ayrı bir bahçe gibi görünüyor — Birleştir": hedef bahçe seçilir, yer profiline "mergedInto" yazılır; o yer listeden kalkar, o addaki bütün kayıt ve testler hedef bahçede görünür. Ad nasıl yazılmış olursa olsun çalışır; herkes görür (salt okuma kullanıcı hariç).
- Bahçe sırası: plan değeri boş gelen satır sırayı bozuyordu (Kaka en başa çıkıyordu); artık 2027 planına göre doğru sıralanır.
- (v64) BBCH kartları + testte BBCH, depo tabii fire, MZ işletme fişi.
