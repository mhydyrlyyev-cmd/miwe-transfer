import React, { useMemo, useState } from 'react';
import { bbchFor } from '../../config/bbchCodes';
import { ArrowLeft, Camera, Check, Delete, Plus, X } from 'lucide-react';
import type { ActiveFieldContext, FieldRecord, FieldSample, ReferenceItem } from '../../types';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { detectSpecialCropType, CROP_PRESETS } from '../../utils/specialCropTests';
import { CROP_QUALITY_SPECS, resolveStandardSpecForOrg, getCropParameterConfig } from '../../utils/qualityStandards';
import { calculateStreifIndex, generateRefId } from '../../utils/calculations';
import { getCurrentUser } from '../../utils/authService';

/**
 * v52 — Saha testi (yeni, düğmeli). Görsel 29–30: her ölçüm bir düğme; dokununca meyve meyve sayı klavyesi.
 * Eşikler mevcut standart kataloğundan (qualityStandards) gelir; burada yeni eşik yazılmaz.
 * Kayıt eski formla aynı FieldRecord'dur → parti sayfası, testler raporu, bahçe rasatları aynen çalışır.
 */
type Stage = 'PRE' | 'HARVEST' | 'STORE' | 'SHIP';
const STAGES: { k: Stage; label: string; testType: string }[] = [
  { k: 'PRE', label: 'Hasat öncesi', testType: 'Hasattan Önce (Ön Hasat Olgunluk Testi)' },
  { k: 'HARVEST', label: 'Hasat günü', testType: 'Hasat Testi (Ana Hasat Kontrolü)' },
  { k: 'STORE', label: 'Depo', testType: 'Depo Kontrol Testi' },
  { k: 'SHIP', label: 'Sevk', testType: 'Sevkiyattan Önce (Soğuk Depo / Çıkış Kalite Testi)' },
];
type MKey = 'hardness' | 'brix' | 'diameter' | 'starch' | 'weight' | 'hue' | 'nitrate' | 'defect' | 'color' | 'sp1' | 'sp2';
/** Sık kullanılan ürünler — dokununca o ürünün kendi test seti gelir */
const PRODUCTS = ['Elma', 'Armut', 'Şeftali', 'Nektarin', 'Erik', 'Kiraz', 'Hurma', 'Nar', 'Üzüm', 'Soğan', 'Patates', 'Havuç', 'Mısır', 'Kavun', 'Karpuz', 'Domates'];
const short = (s: string) => s.replace(/\s*\(.*\)\s*$/, '').trim();
interface MDef { key: MKey; label: string; unit: string; perFruit: boolean; min?: number; max?: number; optional?: boolean; dec: number }

const f1 = (x: number, d = 1) => x.toLocaleString('tr-TR', { maximumFractionDigits: d, minimumFractionDigits: d ? Math.min(1, d) : 0 });
const num = (s: string) => { const v = Number(s.replace(',', '.')); return Number.isFinite(v) ? v : undefined; };
const mean = (a: (number | undefined)[]) => { const v = a.filter((x): x is number => x !== undefined); return v.length ? v.reduce((s, x) => s + x, 0) / v.length : undefined; };
const inRange = (v: number, d: MDef) => (d.min === undefined || v >= d.min) && (d.max === undefined || v <= d.max);
const rangeText = (d: MDef) => d.min !== undefined && d.max !== undefined ? `${f1(d.min)}–${f1(d.max)}` : d.min !== undefined ? `≥ ${f1(d.min)}` : d.max !== undefined ? `≤ ${f1(d.max)}` : '';

interface Props {
  onSave: (record: FieldRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void | Promise<void>;
  onCancel: () => void;
  onOpenFullForm: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  ctx?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

export default function QuickTestForm({ onSave, onCancel, onOpenFullForm, existingRefs, initialRefId, ctx, isReadOnly }: Props) {
  const [stage, setStage] = useState<Stage>('PRE');
  const [orchard, setOrchard] = useState(ctx?.orchard || '');
  const [product, setProduct] = useState(ctx?.product || '');
  const [variety, setVariety] = useState(ctx?.variety || '');
  const [parcel, setParcel] = useState(ctx?.parcelCode || ctx?.location || '');
  const [n, setN] = useState(10);
  const [vals, setVals] = useState<Partial<Record<MKey, (number | undefined)[]>>>({});
  const [avgOnly, setAvgOnly] = useState<Partial<Record<MKey, boolean>>>({});
  const [extra, setExtra] = useState<MKey[]>([]);
  const [open, setOpen] = useState<MKey | null>(null);
  const [cell, setCell] = useState(0);
  const [buf, setBuf] = useState('');
  const [note, setNote] = useState('');
  const [bbch, setBbch] = useState('');
  const [saving, setSaving] = useState(false);

  const crop = detectSpecialCropType(`${product} ${variety}`);
  const pome = crop === 'APPLE_PEAR';
  const cherry = /kiraz|çeri|ceri|cherry|wişne|vişne/i.test(product);
  const stdOrg = CROP_QUALITY_SPECS[crop]?.defaultStandard || 'GENERAL';
  const spec = resolveStandardSpecForOrg(crop, stdOrg as any);
  const stdLabel = crop === 'NONE' ? 'genel değer' : String(stdOrg);

  const cfg = getCropParameterConfig(crop, product);
  const preset = crop !== 'APPLE_PEAR' ? CROP_PRESETS[crop] : null;
  const defs: MDef[] = useMemo(() => {
    const d: MDef[] = [];
    if (cfg.showHardness) d.push({ key: 'hardness', label: short(cfg.hardnessLabel) || 'Sertlik', unit: cfg.hardnessUnit || 'kg/cm²', perFruit: true, min: spec.minHardnessKgCm2, max: spec.maxHardnessKgCm2, dec: 1 });
    if (cfg.showBrix) d.push({ key: 'brix', label: short(cfg.brixLabel) || 'Brix', unit: cfg.brixUnit || '°Bx', perFruit: true, min: spec.minBrix, dec: 1 });
    if (pome || cfg.showStarch) d.push({ key: 'starch', label: 'Nişasta (1–10)', unit: '', perFruit: true, dec: 1 });
    if (cfg.showDiameter) d.push({ key: 'diameter', label: short(cfg.diameterLabel) || 'Çap', unit: cfg.diameterUnit || 'mm', perFruit: true, dec: 0 });
    d.push({ key: 'weight', label: 'Ağırlık', unit: 'g', perFruit: true, dec: 0 });
    // ürüne özel iki ölçüm (eski formdaki özel ürün testi): soğanda boyun kuruluğu + kuru madde, patateste kuru madde … 
    if (preset) {
      d.push({ key: 'sp1', label: short(preset.metric1Label), unit: preset.metric1Unit, perFruit: false, dec: preset.metric1Step < 1 ? 1 : 0 });
      if (preset.metric2Label) d.push({ key: 'sp2', label: short(preset.metric2Label), unit: preset.metric2Unit || '', perFruit: false, dec: (preset.metric2Step ?? 1) < 1 ? 1 : 0 });
    }
    const opt: MDef[] = [
      { key: 'hue', label: 'Renk / hue', unit: '°', perFruit: false, max: cherry ? 10 : undefined, optional: true, dec: 0 },
      ...(cfg.showColoration ? [{ key: 'color' as MKey, label: short(cfg.colorationLabel) || 'Renklenme', unit: '%', perFruit: false, min: spec.minColorationPercent || undefined, optional: true, dec: 0 }] : []),
      ...(cfg.showDefects ? [{ key: 'defect' as MKey, label: short(cfg.defectsLabel) || 'Kusur', unit: '%', perFruit: false, max: spec.maxDefectPercent, optional: true, dec: 1 }] : []),
      ...(cfg.showNitrate ? [{ key: 'nitrate' as MKey, label: 'Nitrat', unit: 'mg/kg', perFruit: false, max: spec.maxNitrateMgKg, optional: true, dec: 0 }] : []),
    ];
    return [...d, ...opt];
  }, [spec, pome, cherry, cfg, preset]);
  const shown = defs.filter(d => !d.optional || extra.includes(d.key));
  const hidden = defs.filter(d => d.optional && !extra.includes(d.key));

  const avgOf = (k: MKey) => mean(vals[k] || []);
  const countOf = (k: MKey) => (vals[k] || []).filter(x => x !== undefined).length;
  const verdict = (d: MDef) => { const a = avgOf(d.key); if (a === undefined || (d.min === undefined && d.max === undefined)) return 'none'; return inRange(a, d) ? 'ok' : 'bad'; };

  const sp1 = avgOf('sp1'), sp2 = avgOf('sp2');
  const spRes = preset && sp1 !== undefined && (!preset.metric2Label || sp2 !== undefined) ? preset.calculate(sp1, sp2) : undefined;
  const spBad = !!spRes && /rose/.test(spRes.statusBadge);
  const st = pome ? calculateStreifIndex(avgOf('hardness') || 0, avgOf('brix') || 0, avgOf('starch') || 0, variety) : undefined;
  const judged = shown.filter(d => verdict(d) !== 'none');
  const okN = judged.filter(d => verdict(d) === 'ok').length;
  const badN = judged.length - okN + (spBad ? 1 : 0);
  const measured = shown.filter(d => avgOf(d.key) !== undefined).length;

  // ── Klavye ──
  const def = defs.find(d => d.key === open);
  const len = def?.perFruit && !avgOnly[def.key] ? n : 1;
  const openSheet = (k: MKey) => { setOpen(k); const arr = vals[k] || []; const first = arr.findIndex(x => x === undefined); setCell(first < 0 ? 0 : first); setBuf(''); };
  const commit = (i = cell) => {
    if (!def) return;
    const v = num(buf);
    if (buf !== '' && v !== undefined) setVals(s => { const arr = [...(s[def.key] || [])]; arr.length = Math.max(arr.length, len); arr[i] = v; return { ...s, [def.key]: arr.slice(0, len) }; });
    setBuf('');
  };
  const press = (c: string) => {
    if (c === 'del') { if (buf) setBuf(buf.slice(0, -1)); else setVals(s => { const arr = [...(s[def!.key] || [])]; arr[cell] = undefined; return { ...s, [def!.key]: arr }; }); return; }
    if (c === 'next') { commit(); setCell(i => Math.min(len - 1, i + 1)); return; }
    if (c === ',' && buf.includes(',')) return;
    setBuf(b => (b + c).slice(0, 6));
  };
  const close = () => { commit(); setOpen(null); };
  const sheetArr = open ? (vals[open] || []) : [];
  const sheetLive = open ? sheetArr.map((x, i) => (i === cell && buf ? num(buf) : x)) : [];
  const sheetVals = sheetLive.slice(0, len).filter((x): x is number => x !== undefined);
  const outN = def ? sheetVals.filter(x => !inRange(x, def)).length : 0;

  const save = async () => {
    if (saving || isReadOnly) return;
    setSaving(true);
    const isNew = !initialRefId;
    const refId = initialRefId || generateRefId('FIELD', existingRefs.map(r => r.refId));
    const per = (k: MKey) => (avgOnly[k] ? [] : vals[k] || []);
    const samples: FieldSample[] = Array.from({ length: n }, (_, i) => ({
      sample: i + 1, hardness: per('hardness')[i] ?? 0, brix: per('brix')[i] ?? 0, diameterMm: per('diameter')[i] ?? 0,
      weightG: per('weight')[i], starch: pome ? per('starch')[i] : undefined, defects: '',
    })).filter(s => s.hardness || s.brix || s.diameterMm || s.weightG || s.starch);
    const nitr = avgOf('nitrate'), hue = avgOf('hue');
    const v: FieldRecord['qualityStandardVerdict'] = !judged.length ? undefined : badN === 0 ? 'PASS' : badN === 1 && verdict(defs.find(d => d.key === 'nitrate')!) !== 'bad' ? 'CONDITIONAL' : 'FAIL';
    const stageDef = STAGES.find(s => s.k === stage)!;
    const decision = stage === 'PRE' ? (badN === 0 ? 'Hasada Uygun' : 'Tekrar Test Edilecek') : badN === 0 ? 'Uygun' : 'Kontrol gerekli';
    const w = avgOf('weight');
    const rec: FieldRecord = {
      id: `field-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      refId, timestamp: new Date().toISOString(), operator: getCurrentUser()?.fullName || 'Belirtilmedi',
      product: product.trim() || 'Meyve', sortVariety: variety.trim(), orchard: orchard.trim() || 'Saha / Bahçe (Genel)', location: parcel.trim(),
      testType: stageDef.testType, sampleCount: samples.length || n, samples,
      avgHardness: Number((avgOf('hardness') || 0).toFixed(2)), avgBrix: Number((avgOf('brix') || 0).toFixed(2)), avgDiameter: Number((avgOf('diameter') || 0).toFixed(1)),
      avgFruitWeightG: w ? Number(w.toFixed(1)) : undefined, fruitCountSampled: countOf('weight') || undefined,
      testSampleWeightG: w && countOf('weight') ? Number((w * countOf('weight')).toFixed(0)) : undefined,
      hasStarchTest: pome && avgOf('starch') !== undefined, starchIndex: pome ? avgOf('starch') : undefined,
      streifIndex: st && st.streifIndex > 0 ? st.streifIndex : undefined, streifInterpretation: st && st.streifIndex > 0 ? st.interpretation : undefined,
      qualityStandardOrg: stdOrg, qualityStandardVerdict: v,
      hasNitrateTest: nitr !== undefined, nitrateMgKg: nitr, nitrateLimitMgKg: nitr !== undefined ? spec.maxNitrateMgKg : undefined, nitratePass: nitr !== undefined ? nitr <= spec.maxNitrateMgKg : undefined,
      hasHueAngleTest: hue !== undefined, hueAngle: hue, hueAngleVerdict: hue !== undefined && cherry ? (hue <= 10 ? 'OPTIMAL' : 'WARNING') : undefined,
      specialCropTest: preset && spRes ? { cropType: crop, cropNameTr: preset.cropNameTr, metric1Name: preset.metric1Label, metric1Value: sp1, metric1Unit: preset.metric1Unit, metric2Name: preset.metric2Label, metric2Value: sp2, metric2Unit: preset.metric2Unit, statusBadge: spRes!.statusBadge, interpretation: spRes!.interpretation } as any : undefined,
      colorationPercent: avgOf('color'), hasDefectTest: avgOf('defect') !== undefined, defectPercent: avgOf('defect'),
      harvestDate: new Date().toISOString().slice(0, 10), decision, testStatus: 'COMPLETED', nextStep: '', notes: note, bbch: bbch || undefined,
    };
    const refData: Partial<ReferenceItem> | undefined = isNew ? {
      refId, moduleKey: 'FIELD', product: `${rec.product}${rec.sortVariety ? ` (${rec.sortVariety})` : ''}`, orchard: rec.orchard, location: rec.location,
      source: rec.orchard || rec.location, destination: 'Zirai Kalite Laboratuvarı / Numune Arşivi', finalDestination: 'Zirai Kalite Laboratuvarı / Numune Arşivi',
    } : undefined;
    try { await onSave(rec, isNew, refData); } finally { setSaving(false); }
  };

  const card = ORCHARD_CARDS[orchard];
  const varChips = card ? card.varieties.filter(v => !/belirsiz/i.test(v.cesit)) : [];
  const canSave = !!orchard.trim() && !!product.trim() && measured > 0 && !isReadOnly;
  const inp = 'w-full min-h-[38px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 text-sm';

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-40 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={onCancel} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Saha testi</h1>
          <p className="text-xs text-slate-500 truncate">{initialRefId || 'yeni RefID'}{orchard ? ` · ${orchard}` : ''}{variety ? ` · ${variety}` : ''}</p></div>
      </div>

      <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1">{STAGES.map(s => (
        <button key={s.k} type="button" onClick={() => setStage(s.k)} className={`shrink-0 px-3 min-h-[34px] rounded-full text-xs border cursor-pointer ${stage === s.k ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'border-slate-300 text-slate-700 dark:text-slate-300'}`}>{s.label}</button>))}</div>

      {/* Nereden */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <label className="text-[11px] text-slate-500">Bahçe<input list="qt-orchards" value={orchard} onChange={e => setOrchard(e.target.value)} className={inp} placeholder="seçin / yazın" /></label>
          <label className="text-[11px] text-slate-500">Parsel / sıra<input value={parcel} onChange={e => setParcel(e.target.value)} className={inp} placeholder="B-4 · 12–18" /></label>
          <label className="text-[11px] text-slate-500">Ürün<input value={product} onChange={e => setProduct(e.target.value)} className={inp} placeholder="Elma" /></label>
          <label className="text-[11px] text-slate-500">Çeşit<input value={variety} onChange={e => setVariety(e.target.value)} className={inp} placeholder="Fuji" /></label>
        </div>
        {!varChips.length && (
          <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{PRODUCTS.map(x => (
            <button key={x} type="button" onClick={() => { setProduct(x); setVals({}); setExtra([]); }} className={`shrink-0 px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${product === x ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{x}</button>))}</div>
        )}
        <datalist id="qt-orchards">{Object.keys(ORCHARD_CARDS).map(o => <option key={o} value={o} />)}</datalist>
        {varChips.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{varChips.map(v => (
            <button key={v.tur + v.cesit} type="button" onClick={() => { setProduct(v.tur); setVariety(v.cesit); }} className={`shrink-0 px-2.5 min-h-[30px] rounded-full border text-[11px] cursor-pointer ${variety === v.cesit ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{v.tur} · {v.cesit}</button>))}</div>
        )}
        <div className="flex items-center justify-between text-[11px] text-slate-500">
          <span>Numune sayısı (meyve / baş / yumru)</span>
          <span className="flex items-center gap-2">
            <button type="button" onClick={() => setN(x => Math.max(1, x - 1))} className="w-8 h-8 rounded-lg border border-slate-300 cursor-pointer">−</button>
            <b className="text-sm text-slate-900 dark:text-white tabular-nums w-6 text-center">{n}</b>
            <button type="button" onClick={() => setN(x => Math.min(40, x + 1))} className="w-8 h-8 rounded-lg border border-slate-300 cursor-pointer">+</button>
          </span>
        </div>
      </section>

      <p className="text-[11px] text-slate-500 px-1">Dokun → gir. Boş bırakılan ölçüm sonuca girmez. Ürünün kendi test seti ve eşikleri: {product ? `${cfg.cropName || product} · ${stdLabel}` : 'ürün seçince gelir'}.</p>

      {/* Ölçüm düğmeleri */}
      <div className="grid grid-cols-2 gap-2">
        {shown.map(d => {
          const a = avgOf(d.key), c = countOf(d.key), v = verdict(d);
          const tone = v === 'ok' ? 'border-emerald-300' : v === 'bad' ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/30' : a !== undefined ? 'border-teal-300' : 'border-dashed border-slate-300';
          return (
            <button key={d.key} type="button" disabled={isReadOnly} onClick={() => openSheet(d.key)} className={`text-left rounded-2xl border bg-white dark:bg-slate-900 p-3 min-h-[88px] cursor-pointer ${tone}`}>
              <div className="flex items-center justify-between text-[11px]"><b className="text-slate-700 dark:text-slate-300">{d.label}</b><span className="text-slate-400">{d.perFruit && !avgOnly[d.key] ? `${c} / ${n} meyve` : a !== undefined ? 'ortalama' : ''}</span></div>
              {a !== undefined ? <div className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{f1(a, d.dec)} <span className="text-xs font-normal text-slate-500">{d.unit}</span></div>
                : <div className="text-sm font-semibold text-teal-700 mt-1">+ ölç</div>}
              <div className={`text-[10px] ${v === 'bad' ? 'text-amber-800 font-semibold' : 'text-slate-500'}`}>{rangeText(d) ? `${rangeText(d)} ${v === 'ok' ? 'uygun' : v === 'bad' ? 'dikkat' : ''}` : d.optional ? 'isteğe bağlı' : 'eşik yok'}</div>
            </button>
          );
        })}
      </div>
      {hidden.length > 0 && !isReadOnly && (
        <div className="flex flex-wrap gap-1.5">{hidden.map(d => (
          <button key={d.key} type="button" onClick={() => { setExtra(x => [...x, d.key]); openSheet(d.key); }} className="px-3 min-h-[34px] rounded-lg border border-slate-300 text-xs cursor-pointer inline-flex items-center gap-1"><Plus className="w-3.5 h-3.5" />{d.label}</button>))}</div>
      )}

      {/* Hesaplananlar */}
      {(st?.streifIndex || 0) > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="text-[11px] text-slate-500">Streif indeksi = sertlik ÷ (Brix × nişasta)</div>
          <div className="text-lg font-bold tabular-nums">{st!.streifIndex.toLocaleString('tr-TR', { maximumFractionDigits: 3 })}</div>
          <div className="text-[11px] text-slate-600 dark:text-slate-400">{st!.interpretation}</div>
        </section>
      )}

      {spRes && (
        <section className={`rounded-2xl border px-4 py-3 ${spBad ? 'border-rose-200 bg-rose-50' : /amber/.test(spRes.statusBadge) ? 'border-amber-200 bg-amber-50' : 'border-emerald-200 bg-emerald-50'}`}>
          <div className="text-[11px] text-slate-600">{preset!.cropNameTr}</div>
          <div className="text-sm font-semibold text-slate-900">{spRes.interpretation}</div>
        </section>
      )}
      {bbchFor(product).length > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
          <div className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">Ağaçtaki aşama (BBCH) · isteğe bağlı</div>
          <div className="flex gap-1.5 overflow-x-auto -mx-1 px-1 pb-0.5">{bbchFor(product).filter(x => x.group >= 7).map(x => (
            <button key={x.code} type="button" onClick={() => setBbch(bbch === x.code ? '' : x.code)} title={x.name}
              className={`shrink-0 px-2.5 min-h-[36px] rounded-full border text-[11px] cursor-pointer ${bbch === x.code ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 dark:border-slate-700'}`}><b>{x.code}</b> {x.name}</button>))}
          </div>
        </section>
      )}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-2">
        <textarea rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder="Not (gözlem, kusur, hava…)" className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-sm" />
        <button type="button" onClick={onOpenFullForm} className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 inline-flex items-center gap-1 cursor-pointer"><Camera className="w-3.5 h-3.5" />Fotoğraf, standart karşılaştırma, özel ürün testi → ayrıntılı form</button>
      </section>

      {/* Sonuç çubuğu */}
      <div className="fixed left-0 right-0 bottom-[68px] sm:bottom-4 z-30 px-3">
        <div className="max-w-xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-lg px-4 py-2.5 flex items-center gap-3">
          <div className="min-w-0 flex-1">
            <div className="text-[10px] text-slate-500">Sonuç</div>
            <div className={`text-sm font-bold truncate ${!judged.length ? 'text-slate-500' : badN ? 'text-amber-700' : 'text-emerald-700'}`}>
              {!measured ? 'Ölçüm girilmedi' : !judged.length ? `${measured} ölçüm · eşik yok` : `${badN ? (stage === 'PRE' ? 'Tekrar test' : 'Kontrol gerekli') : stage === 'PRE' ? 'Hasada uygun' : 'Uygun'} · ${okN} / ${judged.length} uygun`}
            </div>
          </div>
          <button type="button" disabled={!canSave || saving} onClick={save} className="min-h-[44px] px-6 rounded-xl bg-teal-700 text-white font-semibold disabled:opacity-40 cursor-pointer">{saving ? '…' : 'Kaydet'}</button>
        </div>
      </div>

      {/* Sayı klavyesi */}
      {def && (
        <div className="fixed inset-0 z-50 flex items-end bg-slate-900/40" onClick={close}>
          <div className="w-full max-w-xl mx-auto rounded-t-3xl bg-white dark:bg-slate-900 p-4 space-y-3" onClick={e => e.stopPropagation()} style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
            <div className="flex items-center justify-between">
              <div><div className="text-base font-bold">{def.label}</div><div className="text-[11px] text-slate-500">{def.unit}{rangeText(def) ? ` · ${rangeText(def)} (${stdLabel})` : ''}</div></div>
              <button type="button" onClick={close} aria-label="Kapat" className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center cursor-pointer"><X className="w-4 h-4" /></button>
            </div>
            {def.perFruit && (
              <div className="flex gap-1.5">{[false, true].map(m => (
                <button key={String(m)} type="button" onClick={() => { commit(); setAvgOnly(s => ({ ...s, [def.key]: m })); setVals(s => ({ ...s, [def.key]: [] })); setCell(0); }} className={`px-3 min-h-[32px] rounded-full text-xs border cursor-pointer ${!!avgOnly[def.key] === m ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{m ? 'Sadece ortalama' : 'Meyve meyve'}</button>))}</div>
            )}
            <div className="grid grid-cols-5 gap-1.5">{Array.from({ length: len }, (_, i) => {
              const x = sheetLive[i]; const bad = x !== undefined && !inRange(x, def);
              return (
                <button key={i} type="button" onClick={() => { commit(); setCell(i); }} className={`rounded-lg border min-h-[42px] text-center cursor-pointer ${i === cell ? 'border-teal-600 ring-2 ring-teal-200' : bad ? 'border-amber-400 bg-amber-50' : x !== undefined ? 'border-slate-300' : 'border-dashed border-slate-300'}`}>
                  <div className="text-[9px] text-slate-400">{len > 1 ? i + 1 : 'ort.'}</div>
                  <div className="text-sm font-semibold tabular-nums">{i === cell && buf ? buf : x !== undefined ? f1(x, def.dec) : '·'}</div>
                </button>);
            })}</div>
            {sheetVals.length > 1 && (
              <div className="grid grid-cols-4 gap-1.5 text-center">
                {[['Ort.', mean(sheetVals)!], ['En düşük', Math.min(...sheetVals)], ['En yüksek', Math.max(...sheetVals)], ['Sapma', Math.sqrt(sheetVals.reduce((s, x) => s + (x - mean(sheetVals)!) ** 2, 0) / sheetVals.length)]].map(([l, v]) => (
                  <div key={String(l)} className="rounded-lg bg-slate-50 dark:bg-slate-800 py-1"><div className="text-[9px] text-slate-500">{l}</div><div className="text-sm font-semibold tabular-nums">{f1(Number(v), 2)}</div></div>))}
              </div>
            )}
            {outN > 0 && <p className="rounded-lg bg-amber-50 text-amber-900 text-[11px] px-2.5 py-1.5">{outN} meyve sınırın dışında. {mean(sheetVals) !== undefined && inRange(mean(sheetVals)!, def) ? 'Ortalama uygun.' : 'Ortalama da dışında.'}</p>}
            <div className="grid grid-cols-3 gap-1.5">{['7', '8', '9', '4', '5', '6', '1', '2', '3', ',', '0', 'del'].map(c => (
              <button key={c} type="button" onClick={() => press(c)} className="min-h-[48px] rounded-xl bg-slate-100 dark:bg-slate-800 text-lg font-semibold cursor-pointer active:scale-95 flex items-center justify-center">{c === 'del' ? <Delete className="w-5 h-5" /> : c}</button>))}</div>
            <div className="grid grid-cols-2 gap-1.5">
              <button type="button" onClick={() => press('next')} disabled={cell >= len - 1 && !buf} className="min-h-[46px] rounded-xl border border-teal-600 text-teal-800 font-semibold disabled:opacity-40 cursor-pointer">Sonraki →</button>
              <button type="button" onClick={close} className="min-h-[46px] rounded-xl bg-teal-700 text-white font-semibold cursor-pointer inline-flex items-center justify-center gap-1"><Check className="w-4 h-4" />Tamam</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
