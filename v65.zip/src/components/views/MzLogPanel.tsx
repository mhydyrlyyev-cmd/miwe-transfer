import React, { useState } from 'react';
import { Factory, Trash2 } from 'lucide-react';
import { useMzDocs, addMzDoc, removeMzDoc, mzCalc, mzSummary, MZ_STAGE_LABEL, MZ_LINE_CAPACITY, MZ_SOURCE, type MzStage } from '../../services/mzLog';

/** v64 — Badem akışı › MZ işletme fişi: ön temizleme ve Borrell kırma; özet + kayıt formu + son fişler */
const n0 = (x: number) => Math.round(x).toLocaleString('tr-TR');
const p1 = (x: number) => x.toLocaleString('tr-TR', { maximumFractionDigits: 1 });
const num = (s: string) => { const v = Number(String(s).replace(',', '.')); return Number.isFinite(v) && v > 0 ? v : undefined; };

export default function MzLogPanel({ by, readOnly }: { by?: string; readOnly?: boolean }) {
  const docs = useMzDocs();
  const [open, setOpen] = useState(false);
  const [stage, setStage] = useState<MzStage>('PRECLEAN');
  const [f, setF] = useState({ date: new Date().toISOString().slice(0, 10), ticket: '', source: '', firm: '', variety: '', form: '', destination: '', inKg: '', inRh: '', outKg: '', outRh: '', hours: '', note: '' });
  const [err, setErr] = useState('');
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => { setF({ ...f, [k]: e.target.value }); setErr(''); };
  const inKg = num(f.inKg), outKg = num(f.outKg), hours = num(f.hours);
  const calc = inKg && outKg ? mzCalc({ inKg, outKg, hours }) : null;
  const save = async () => {
    if (!inKg || !outKg) { setErr('Giriş ve çıkış kg girin.'); return; }
    if (outKg > inKg) { setErr('Çıkış kg girişten büyük olamaz.'); return; }
    await addMzDoc({ stage, date: f.date, ticket: f.ticket || undefined, source: f.source || undefined, firm: f.firm || undefined, variety: f.variety || undefined, form: f.form || undefined, destination: f.destination || undefined,
      inKg, inRh: num(f.inRh), outKg, outRh: num(f.outRh), hours, note: f.note || undefined }, by);
    setF({ ...f, ticket: '', inKg: '', inRh: '', outKg: '', outRh: '', hours: '', note: '' }); setOpen(false);
  };
  const inp = 'min-h-[40px] w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm';
  const lab = (t: string, el: React.ReactNode) => <label className="block text-[11px] text-slate-600 dark:text-slate-400">{t}{el}</label>;
  const outLabel = stage === 'PRECLEAN' ? 'Kabuklu (şänikli)' : 'İç (maňyz)';
  const inLabel = stage === 'PRECLEAN' ? 'Kabul edilen' : 'Kabuklu giriş';

  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2">
      <h2 className="text-sm font-bold flex items-center gap-1.5"><Factory className="w-4 h-4 text-teal-700" />MZ işletme fişi</h2>
      <div className="grid grid-cols-2 gap-2">{(['PRECLEAN', 'SHELL'] as MzStage[]).map(s => { const m = mzSummary(docs, s); return (
        <div key={s} className="rounded-xl bg-slate-50 dark:bg-slate-800/60 px-3 py-2">
          <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">{MZ_STAGE_LABEL[s]} · {m.n} fiş</div>
          <div className="text-sm font-bold tabular-nums">{m.n ? `%${p1(m.yieldPct)}` : '—'} <span className="text-[10px] font-normal text-slate-500">{s === 'PRECLEAN' ? 'kabuklu' : 'iç'} verimi</span></div>
          <div className="text-[10px] text-slate-500 tabular-nums">{m.n ? `${n0(m.inKg)} → ${n0(m.outKg)} kg` : ''}{m.kgPerH ? ` · ${n0(m.kgPerH)} kg/sa (kapasite ${n0(MZ_LINE_CAPACITY[s])})` : ''}</div>
        </div>); })}
      </div>

      {!readOnly && !open && <button type="button" onClick={() => setOpen(true)} className="w-full min-h-[40px] rounded-xl border border-dashed border-teal-400 text-sm font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">+ Fiş ekle</button>}
      {open && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-700 p-3 space-y-2">
          <div className="flex gap-1.5">{(['PRECLEAN', 'SHELL'] as MzStage[]).map(s => <button key={s} type="button" onClick={() => setStage(s)} className={`flex-1 min-h-[36px] rounded-lg border text-xs font-semibold cursor-pointer ${stage === s ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{MZ_STAGE_LABEL[s]}</button>)}</div>
          <div className="grid grid-cols-2 gap-2">
            {lab('Tarih', <input type="date" value={f.date} onChange={set('date')} className={inp} />)}
            {lab('Fiş / faktura no', <input value={f.ticket} onChange={set('ticket')} className={inp} />)}
            {lab('Alındığı yer', <input value={f.source} onChange={set('source')} placeholder="1600 / soğuk depo" className={inp} />)}
            {lab('Çeşit', <input value={f.variety} onChange={set('variety')} placeholder="Laurenne" className={inp} />)}
            {stage === 'PRECLEAN' && lab('Firma', <input value={f.firm} onChange={set('firm')} className={inp} />)}
            {stage === 'PRECLEAN' && lab('Biçim', <input value={f.form} onChange={set('form')} placeholder="gabykly / elde / garyşyk" className={inp} />)}
            {lab(`${inLabel} kg`, <input inputMode="decimal" value={f.inKg} onChange={set('inKg')} className={inp} />)}
            {lab(`${inLabel} nem %`, <input inputMode="decimal" value={f.inRh} onChange={set('inRh')} className={inp} />)}
            {lab(`${outLabel} kg`, <input inputMode="decimal" value={f.outKg} onChange={set('outKg')} className={inp} />)}
            {lab(`${outLabel} nem %`, <input inputMode="decimal" value={f.outRh} onChange={set('outRh')} className={inp} />)}
            {lab('Çalışılan saat', <input inputMode="decimal" value={f.hours} onChange={set('hours')} className={inp} />)}
            {lab('Gideceği yer', <input value={f.destination} onChange={set('destination')} placeholder={stage === 'PRECLEAN' ? 'Borrell / depo' : 'söwda bölümi / depo'} className={inp} />)}
          </div>
          {lab('Not', <input value={f.note} onChange={set('note')} className={inp} />)}
          {calc && <p className="text-[11px] text-slate-700 dark:text-slate-300 tabular-nums">Verim <b>%{p1(calc.yieldPct)}</b> · fark {n0(calc.diffKg)} kg ({stage === 'PRECLEAN' ? 'kabuk ve kir' : 'kabuk'}){calc.kgPerH ? ` · ${n0(calc.kgPerH)} kg/saat` : ''}</p>}
          {err && <p className="text-[12px] text-rose-700">{err}</p>}
          <div className="flex gap-2"><button type="button" onClick={() => setOpen(false)} className="flex-1 min-h-[40px] rounded-xl border border-slate-300 text-sm cursor-pointer">Vazgeç</button><button type="button" onClick={save} className="flex-1 min-h-[40px] rounded-xl bg-teal-700 text-white text-sm font-semibold cursor-pointer">Kaydet</button></div>
        </div>)}

      {docs.length > 0 && (
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{docs.slice(0, 12).map(d => { const c = mzCalc(d); return (
          <li key={d.id} className="py-1.5 flex items-start justify-between gap-2 text-xs">
            <span className="min-w-0"><b>{d.date.slice(8, 10)}.{d.date.slice(5, 7)}</b> · {MZ_STAGE_LABEL[d.stage]}{d.variety ? ` · ${d.variety}` : ''}{d.source ? ` · ${d.source}` : ''}{d.ticket ? ` · ${d.ticket}` : ''}
              <span className="block text-[11px] text-slate-500 tabular-nums">{n0(d.inKg)}{d.inRh ? ` (%${p1(d.inRh)})` : ''} → {n0(d.outKg)}{d.outRh ? ` (%${p1(d.outRh)})` : ''} kg · %{p1(c.yieldPct)}{c.kgPerH ? ` · ${n0(c.kgPerH)} kg/sa` : ''}</span></span>
            {!readOnly && <button type="button" aria-label="Sil" onClick={() => removeMzDoc(d, by)} className="w-8 h-8 shrink-0 flex items-center justify-center text-slate-400 cursor-pointer"><Trash2 className="w-4 h-4" /></button>}
          </li>); })}</ul>)}
      <p className="text-[10px] text-slate-400">Defter düzeni: {MZ_SOURCE}. Verim = çıkış / giriş; hat hızı = giriş / saat.</p>
    </section>
  );
}
