import React, { useMemo, useState } from 'react';
import MzLogPanel from './MzLogPanel';
import { getCurrentUser } from '../../utils/authService';
import { ArrowLeft, Droplets, Warehouse, FlaskConical, ListChecks } from 'lucide-react';
import type { AmbarRecord, BademRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { storedLots, summarizeDepots, useRoomChecks, roomCode } from '../../services/depots';
import { useLocationProfiles, canonicalOrchard } from '../../services/locationProfiles';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { ALMOND, ALMOND_SITES, ALMOND_STEPS, hullVerdict, HULL_TEXT, moistVerdict, MOIST_TEXT } from '../../config/almond';

/**
 * v55 — Badem akışı (görsel 18): hasat → yerde kurutma (iç nem) → depo (hasat yılı, kabuklu / iç) → satış.
 * v56: sezon adımları ve nem sınırları config/almond.ts (defter 25.11.26): MZ işleme %8–9, depo ≈ %6 (en az %4). Kabuklu / iç: depo kaydındaki ürün adında "iç" geçiyorsa iç.
 * Hasat yılı: partinin ilk hasat / kabul tarihinin yılı.
 */
interface Props {
  references: ReferenceItem[]; bademRecords: BademRecord[]; ambarRecords: AmbarRecord[]; harvestRecords: HarvestRecord[];
  lojistikRecords: LojistikRecord[]; salesRecords: SalesRecord[];
  onBack: () => void; onNewTest: () => void; onOpenLot: (refId: string) => void; onOpenSteps: () => void;
}
const isBadem = (s?: string) => /badem|almond|mindal/i.test(s || '');
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const dm = (iso?: string) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}` : '—');

export default function BademFlowView(p: Props) {
  useLocationProfiles();
  const checks = useRoomChecks();
  const [year, setYear] = useState<'ALL' | string>('ALL');
  const refs = useMemo(() => p.references.filter(r => isBadem(r.product)), [p.references]);
  const ids = useMemo(() => new Set(refs.map(r => r.refId)), [refs]);
  const lots = useMemo(() => storedLots(p).filter(l => ids.has(l.a.refId) || isBadem(l.a.product) || isBadem(l.ref?.product)), [p.ambarRecords, p.references, p.lojistikRecords, p.salesRecords, ids]);
  const inDepot = new Set(lots.map(l => l.a.refId));
  const yearOf = (refId: string, fallback?: string) => {
    const h = p.harvestRecords.filter(x => x.refId === refId).map(x => x.recordDate || x.timestamp).sort()[0];
    return String(h || fallback || p.references.find(r => r.refId === refId)?.createdAt || '').slice(0, 4) || '—';
  };

  const harvestKg = p.harvestRecords.filter(h => isBadem(h.product) || ids.has(h.refId)).reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0);
  const depotKg = lots.filter(l => !l.exited).reduce((s, l) => s + l.remainingKg, 0);
  const soldKg = p.salesRecords.filter(x => ids.has(x.refId)).reduce((s, x) => s + (Number(x.totalQuantityKg) || 0), 0);

  // Yerde kurutma: depoya girmemiş, kurutma ölçümü olan partiler — son ölçüm
  const drying = useMemo(() => {
    const by = new Map<string, BademRecord[]>();
    for (const b of p.bademRecords) if (b.kernelMoisturePercent !== undefined && b.kernelMoisturePercent !== null && !inDepot.has(b.refId)) by.set(b.refId, [...(by.get(b.refId) || []), b]);
    return [...by.entries()].map(([refId, rs]) => {
      const s = [...rs].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
      const last = s[s.length - 1];
      const m = Number(last.kernelMoisturePercent);
      const day = Math.max(1, Math.round((Date.now() - Date.parse(s[0].timestamp)) / 864e5) + 1);
      const v = moistVerdict(m)!;
      return { refId, loc: last.location, variety: last.variety, m, day, v, ready: v === 'depo' || v === 'işleme', at: last.timestamp };
    }).sort((a, b) => Number(a.ready) - Number(b.ready) || b.m - a.m);
  }, [p.bademRecords, lots]);
  const dryingKg = drying.reduce((s, d) => s + (Number(p.references.find(r => r.refId === d.refId)?.quantity) || 0), 0);

  // Depo: depo → hasat yılı × kabuklu / iç
  const years = [...new Set(lots.filter(l => !l.exited).map(l => yearOf(l.a.refId, l.a.acceptanceDate)))].sort().reverse();
  const shown = lots.filter(l => !l.exited && (year === 'ALL' || yearOf(l.a.refId, l.a.acceptanceDate) === year));
  const depots = useMemo(() => {
    const m = new Map<string, { name: string; cells: Map<string, { kg: number; rooms: Set<string>; moist?: number }> }>();
    for (const l of shown) {
      const dn = String(l.depot?.fields?.shortName || l.depot?.name || l.a.warehouse || '—');
      const kind = /iç|ic\b|kernel/i.test(`${l.a.product || ''} ${l.a.variety || ''} ${l.ref?.product || ''}`) ? 'iç badem' : 'kabuklu';
      const key = `${yearOf(l.a.refId, l.a.acceptanceDate)} ${kind}`;
      const d = m.get(dn) || { name: dn, cells: new Map() };
      const c = d.cells.get(key) || { kg: 0, rooms: new Set<string>() };
      c.kg += l.remainingKg; c.rooms.add(l.room ? roomCode(l.room) : l.a.roomNo || '—');
      const lab = p.bademRecords.filter(b => b.refId === l.a.refId && b.moisturePercent).sort((a, b) => b.timestamp.localeCompare(a.timestamp))[0];
      if (lab) c.moist = Math.max(c.moist ?? 0, Number(lab.moisturePercent));
      d.cells.set(key, c); m.set(dn, d);
    }
    return [...m.values()];
  }, [shown, p.bademRecords]);
  const offRooms = useMemo(() => {
    const roomIds = new Set(shown.map(l => l.room?.id).filter(Boolean));
    return summarizeDepots(storedLots(p), checks).flatMap(d => d.rooms).filter(r => roomIds.has(r.room.id) && (r.status === 'bad' || r.status === 'warn')).map(r => roomCode(r.room));
  }, [shown, checks]);

  // Sezon adımları — bahçe başına son durum
  const season = useMemo(() => {
    const names = new Set<string>(Object.entries(ORCHARD_CARDS).filter(([, c]) => c.varieties.some(v => isBadem(v.tur))).map(([n]) => n));
    for (const b of p.bademRecords) if (b.location) names.add(canonicalOrchard(b.location));
    return [...names].map(name => {
      const recs = p.bademRecords.filter(b => canonicalOrchard(b.location) === name).sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      const pre = recs.find(b => b.hullSplitPercent !== undefined && b.hullSplitPercent !== null);
      const cut = recs.find(b => b.waterCutOffDate)?.waterCutOffDate;
      const hd = recs.find(b => b.plannedHarvestDate)?.plannedHarvestDate;
      const loss = recs.find(b => b.treeLossPercent !== undefined)?.treeLossPercent;
      const harvested = p.harvestRecords.some(h => isBadem(h.product) && canonicalOrchard(h.orchard) === name && (h.recordDate || '') >= `${new Date().getFullYear()}-01-01`);
      const dry = recs.find(b => b.kernelMoisturePercent !== undefined && b.kernelMoisturePercent !== null);
      const mv = dry ? moistVerdict(Number(dry.kernelMoisturePercent)) : undefined;
      const stored = lots.some(l => !l.exited && canonicalOrchard(l.ref?.orchard || l.a.supplier || '') === name);
      const step = stored ? 6 : mv === 'depo' ? 6 : mv === 'kurutmada' ? 5 : mv ? 4 : harvested ? 3 : hd ? 2 : cut ? 1 : pre ? 0 : -1;
      return { name, pre, hv: hullVerdict(pre?.hullSplitPercent), cut, hd, loss, step, mv };
    }).sort((a, b) => b.step - a.step);
  }, [p.bademRecords, p.harvestRecords, lots]);

  const tile = (v: string, l: string, cls: string) => <div className={`rounded-xl border px-2 py-2 text-center ${cls}`}><div className="text-sm font-bold tabular-nums">{v}</div><div className="text-[10px] text-slate-500">{l}</div></div>;
  const sec = 'rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3';

  return (
    <div className="max-w-xl mx-auto px-3 py-4 pb-28 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Badem akışı</h1><p className="text-xs text-slate-500">{refs.length} parti · hasat → kurutma → depo → satış</p></div>
      </div>
      <div className="grid grid-cols-4 gap-1.5">
        {tile(harvestKg ? `${t1(harvestKg)} t` : '—', 'Hasat', 'border-emerald-200 bg-emerald-50 dark:bg-emerald-950/30')}
        {tile(drying.length ? `${drying.length} parti${dryingKg ? ` · ${t1(dryingKg)} t` : ''}` : '—', 'Kurutmada', 'border-amber-200 bg-amber-50 dark:bg-amber-950/30')}
        {tile(depotKg ? `${t1(depotKg)} t` : '—', 'Depoda', 'border-indigo-200 bg-indigo-50 dark:bg-indigo-950/30')}
        {tile(soldKg ? `${t1(soldKg)} t` : '—', 'Satış', 'border-slate-200')}
      </div>

      <section className={sec}>
        <h2 className="text-sm font-bold mb-1">Sezon adımları · bahçe</h2>
        <div className="grid grid-cols-8 gap-0.5 text-[8px] text-slate-500 text-center leading-tight mb-1">{ALMOND_STEPS.map(x => <span key={x.k}>{x.l.split(' · ')[0]}</span>)}</div>
        {season.length === 0 ? <p className="text-[11px] text-slate-500">Badem bahçesi bulunamadı.</p> : season.map(o => (
          <div key={o.name} className="py-1.5 border-t border-slate-100 dark:border-slate-800">
            <div className="grid grid-cols-8 gap-0.5">{ALMOND_STEPS.map((x, i) => <div key={x.k} className={`h-2 rounded-sm ${i < o.step ? 'bg-teal-600' : i === o.step ? 'bg-amber-400' : 'bg-slate-200 dark:bg-slate-700'}`} title={x.l} />)}</div>
            <div className="flex items-center justify-between gap-2 mt-1"><b className="text-xs truncate">{o.name}</b><span className="text-[10px] text-slate-500 shrink-0">{o.step >= 0 ? ALMOND_STEPS[o.step].l : 'test yok'}</span></div>
            <div className="text-[10px] text-slate-600 dark:text-slate-400">
              {o.pre ? <>açılma %{o.pre.hullSplitPercent}{o.hv ? <b className={o.hv === 'hasat' ? 'text-emerald-700' : o.hv === 'geç' ? 'text-rose-700' : 'text-amber-700'}> · {HULL_TEXT[o.hv]}</b> : null}{o.pre.fruitMoisturePercent !== undefined ? ` · meyve nemi %${o.pre.fruitMoisturePercent}` : ''}</> : 'hasat öncesi test yok'}
              {o.cut ? ` · su kesme ${dm(o.cut)}` : o.hv === 'yaklaşıyor' || o.hv === 'hasat' ? <b className="text-amber-700"> · su kesme günü yok</b> : ''}
              {o.hd ? ` · hasat ${dm(o.hd)}` : o.hv === 'hasat' ? <b className="text-amber-700"> · hasat günü yok</b> : ''}
              {o.loss !== undefined ? ` · ağaçta fire %${o.loss}` : ''}{o.mv ? ` · ${MOIST_TEXT[o.mv]}` : ''}
            </div>
          </div>))}
        <p className="text-[10px] text-slate-500 mt-1.5">Kurallar: açılma %{ALMOND.hullWarn}–{ALMOND.hullStart} uyarı · %{ALMOND.hullStart}–{ALMOND.hullMax} hasat · meyve nemi ≥ %{ALMOND.harvestMoistMin}. Sezon öncesi: nem ölçer kalibrasyonu haftalık, ekip ve kombayn hazırlığı.</p>
      </section>

      <section className={sec}>
        <div className="flex items-center justify-between mb-1"><h2 className="text-sm font-bold flex items-center gap-1.5"><Droplets className="w-4 h-4 text-amber-600" />İşleme · kurutma · nem</h2><span className="text-[11px] text-slate-500">MZ %{ALMOND.processMin}–{ALMOND.processMax} · depo ≈ %{ALMOND.dryTarget}</span></div>
        {drying.length === 0 ? <p className="text-[11px] text-slate-500">Kurutmada parti yok. Badem testi › Kurutma ile iç nem girilince burada görünür.</p> : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{drying.map(d => (
            <li key={d.refId}><button type="button" onClick={() => p.onOpenLot(d.refId)} className="w-full flex items-center justify-between gap-2 py-1.5 text-left cursor-pointer">
              <span className="min-w-0"><b className="text-sm">{d.refId}</b><span className="text-xs text-slate-500"> · {d.variety || '—'}</span><br /><span className="text-[11px] text-slate-500">{d.loc || '—'} · {d.day}. gün · son ölçüm {dm(d.at)}</span></span>
              <span className="flex items-center gap-2 shrink-0"><b className="tabular-nums text-sm">%{d.m.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}</b>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border max-w-[140px] truncate ${d.ready ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-amber-300 bg-amber-50 text-amber-800'}`}>{MOIST_TEXT[d.v]}</span></span>
            </button></li>))}</ul>
        )}
      </section>

      <section className={sec}>
        <div className="flex items-center justify-between mb-1"><h2 className="text-sm font-bold flex items-center gap-1.5"><Warehouse className="w-4 h-4 text-indigo-600" />Depoda · hasat yılı</h2>
          {years.length > 1 && <div className="flex gap-1">{['ALL', ...years].map(y => <button key={y} type="button" onClick={() => setYear(y)} className={`px-2 min-h-[26px] rounded-full border text-[11px] cursor-pointer ${year === y ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300'}`}>{y === 'ALL' ? 'Tümü' : y}</button>)}</div>}</div>
        {depots.length === 0 ? <p className="text-[11px] text-slate-500">Depoda badem yok.</p> : depots.map(d => (
          <div key={d.name} className="mt-1.5">
            <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300">{d.name} · {t1([...d.cells.values()].reduce((s, c) => s + c.kg, 0))} t</div>
            <div className="grid grid-cols-2 gap-1.5 mt-1">{[...d.cells.entries()].sort((a, b) => b[0].localeCompare(a[0])).map(([k, c]) => (
              <div key={k} className="rounded-xl border border-slate-200 dark:border-slate-700 px-2.5 py-1.5">
                <div className="text-[10px] text-slate-500">{k}</div><div className="text-sm font-bold tabular-nums">{t1(c.kg)} t</div>
                <div className="text-[10px] text-slate-500 truncate">{[...c.rooms].join(', ')}{c.moist ? ` · nem %${c.moist.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}` : ''}</div>
              </div>))}</div>
          </div>))}
        {offRooms.length > 0 && <p className="mt-2 rounded-lg bg-rose-50 text-rose-800 text-[11px] px-2.5 py-1.5">{offRooms.length} oda set dışında: {offRooms.join(', ')}</p>}
      </section>

      <section className={sec}>
        <h2 className="text-sm font-bold mb-1">Mindal zawody (MZ) · alanlar</h2>
        <div className="grid grid-cols-3 gap-1.5">{ALMOND_SITES.map(x => <div key={x.name} className="rounded-xl border border-slate-200 dark:border-slate-700 px-2 py-1.5"><div className="text-sm font-bold tabular-nums">{x.m2} m²</div><div className="text-[10px] text-slate-500 leading-tight">{x.name}</div></div>)}</div>
      </section>

      <MzLogPanel by={getCurrentUser()?.fullName} />

      <section className={sec}>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
          <li><button type="button" onClick={p.onNewTest} className="w-full flex items-center gap-2 py-2 text-left cursor-pointer"><FlaskConical className="w-4 h-4 text-teal-700" /><span className="flex-1"><b className="text-sm">Badem testi</b><br /><span className="text-[11px] text-slate-500">hasat öncesi (açılma, nem) · kurutma (iç nem) · laboratuvar (randıman, kusur, aflatoksin)</span></span>›</button></li>
          <li><button type="button" onClick={p.onOpenSteps} className="w-full flex items-center gap-2 py-2 text-left cursor-pointer"><ListChecks className="w-4 h-4 text-teal-700" /><span className="flex-1"><b className="text-sm">Adım adım akış (parti)</b><br /><span className="text-[11px] text-slate-500">sulama kesildi, kombayn, kabuk temizleme, serme…</span></span>›</button></li>
        </ul>
      </section>
    </div>
  );
}
