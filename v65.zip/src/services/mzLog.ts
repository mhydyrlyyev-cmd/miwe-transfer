/**
 * v64 — Mindal zawody (MZ) işletme fişi. "MINDAL_ZAWOD_ISP_2026" defterinin iki aşaması:
 *  · Ön temizleme (pre-cleaning): kabul edilen kg + nem → kabuklu (şänikli) kg + nem; fark = yeşil kabuk ve kir
 *  · Borrell kırma (shelling): kabuklu kg + nem → iç (maňyz) kg + nem
 * Hesap (defterdeki gibi): verim % = çıkış / giriş · fark kg · hat hızı kg/saat = giriş / çalışılan saat.
 * Kayıt: Firestore 'ganttParcels' (calV: 'MZ'; kural değişmez) + yerel önbellek. Sınır uydurulmaz.
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';

export type MzStage = 'PRECLEAN' | 'SHELL';
export const MZ_STAGE_LABEL: Record<MzStage, string> = { PRECLEAN: 'Ön temizleme', SHELL: 'Borrell kırma' };
/** defterin başındaki hat kapasiteleri (kg/saat) — yalnız karşılaştırma için */
export const MZ_LINE_CAPACITY: Record<MzStage, number> = { PRECLEAN: 7000, SHELL: 2000 };
export const MZ_SOURCE = 'MINDAL_ZAWOD_ISP_2026 (Pre-cleaning · Borrell shelling)';

export interface MzDoc {
  id: string; calV: 'MZ'; stage: MzStage; date: string; ticket?: string; source?: string; firm?: string; variety?: string;
  form?: string; destination?: string; inKg: number; inRh?: number; outKg: number; outRh?: number; hours?: number; note?: string;
  removed?: boolean; at: string; by?: string;
}

const LS = 'miwe_mz_v1';
let store: MzDoc[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: MzDoc[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'MZ') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || String(r.at) > String(l.at)) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useMzDocs(): MzDoc[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store.filter(d => !d.removed).sort((a, b) => b.date.localeCompare(a.date));
}
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
async function put(doc: MzDoc) {
  store = [...store.filter(s => s.id !== doc.id), doc]; emit();
  try { return await saveRecordToFirestore('GANTT', doc as any); } catch { return false; }
}
export const addMzDoc = (d: Omit<MzDoc, 'id' | 'calV' | 'at'>, by?: string) => put({ ...d, id: `mz-${uid()}`, calV: 'MZ', at: new Date().toISOString(), by });
export const removeMzDoc = (d: MzDoc, by?: string) => put({ ...d, removed: true, at: new Date().toISOString(), by });

export const mzCalc = (d: Pick<MzDoc, 'inKg' | 'outKg' | 'hours'>) => ({
  yieldPct: d.inKg > 0 ? (d.outKg / d.inKg) * 100 : 0,
  diffKg: d.inKg - d.outKg,
  kgPerH: d.hours && d.hours > 0 ? d.inKg / d.hours : 0,
});
export function mzSummary(docs: MzDoc[], stage: MzStage) {
  const xs = docs.filter(d => d.stage === stage);
  const inKg = xs.reduce((s, d) => s + d.inKg, 0), outKg = xs.reduce((s, d) => s + d.outKg, 0), hours = xs.reduce((s, d) => s + (d.hours || 0), 0);
  const hIn = xs.filter(d => d.hours).reduce((s, d) => s + d.inKg, 0);
  return { n: xs.length, inKg, outKg, yieldPct: inKg ? (outKg / inKg) * 100 : 0, kgPerH: hours ? hIn / hours : 0, hours };
}
