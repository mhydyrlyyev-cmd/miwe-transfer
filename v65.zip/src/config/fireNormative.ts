/**
 * v64 — Tabii ağırlık kaybı (fire) normatifi. Kaynak: "FIRE_dolduruldu.xlsx" › Sheet1 (Normatiw sahypasından;
 * uzun süreli normatif varsa o, yoksa kısa süreli "sowadylan"). Değerler AYLIK oran (0,012 = %1,2), o ay depoda
 * duran miktara uygulanır, birikimli değildir. Çürük, şikest, taşıma kaybı dahil değil.
 * Muz: her hasat partisine bir kez %4 (günde %0,5 × en çok 8 gün sarartma). 1-MCP uygulanan partide toplam −%15 (not 5).
 * Patates (ýeralma) için normatif yok → hesap yapılmaz; freeze-dry ürün su kaybetmez → 0.
 */
export const FIRE_SOURCE = 'FIRE tablosu (Normatiw: tebigy suw ýitgisi, 3. iklim grubu)';

/** Oca … Ara (12 değer, kesir) */
export const FIRE_MONTHLY: Record<string, number[]> = {
  Alma: [0.005, 0.004, 0.004, 0.004, 0.004, 0.006, 0.006, 0.006, 0.012, 0.008, 0.006, 0.005],
  Nektarin: [0, 0, 0.006, 0.006, 0.006, 0.012, 0.012, 0.012, 0.011, 0.011, 0.011, 0.006],
  Erik: [0, 0, 0.007, 0.007, 0.007, 0.016, 0.016, 0.016, 0, 0, 0, 0],
  Armut: [0.005, 0.004, 0.004, 0.005, 0, 0.006, 0.006, 0.006, 0.01, 0.008, 0.006, 0.006],
  'Asya armudu': [0.005, 0.004, 0.004, 0.004, 0.005, 0.006, 0.006, 0.006, 0.01, 0.008, 0.006, 0.006],
  Badem: [0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008, 0.0008],
  Hurma: [0.002, 0.002, 0.002, 0.002, 0.002, 0.006, 0.006, 0.006, 0.005, 0.005, 0.005, 0.002],
  Kiraz: [0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004],
  Şeftali: [0.006, 0.006, 0.006, 0.006, 0.006, 0.012, 0.012, 0.012, 0.011, 0.011, 0.011, 0.006],
  Soğan: [0.005, 0.005, 0.01, 0.013, 0.016, 0.016, 0.018, 0.018, 0.008, 0.007, 0.006, 0.005],
};
export const FIRE_BANANA_PER_LOT = 0.04;
export const FIRE_MCP_FACTOR = 0.85;

/** Ürün adını normatif satırına eşler (Türkçe / Türkmence yazımlar). Bulunamazsa null → "normatif yok". */
export function fireKey(product?: string): string | 'BANAN' | 'ZERO' | null {
  const p = (product || '').toLocaleLowerCase('tr');
  if (/muz|banan/.test(p)) return 'BANAN';
  if (/freeze|erem|kurutul|guradyl/.test(p)) return 'ZERO';
  if (/nashi|asya|aziýa|aziya/.test(p)) return 'Asya armudu';
  if (/elma|alma|apple/.test(p)) return 'Alma';
  if (/nektarin|nectarin/.test(p)) return 'Nektarin';
  if (/şeftali|seftali|şetdaly|setdaly|peach/.test(p)) return 'Şeftali';
  if (/erik|garaly|plum/.test(p)) return 'Erik';
  if (/armut|armyt|pear/.test(p)) return 'Armut';
  if (/badem|mindal|almond/.test(p)) return 'Badem';
  if (/hurma|persimmon/.test(p)) return 'Hurma';
  if (/kiraz|çereş|cerez|çerşn|cherry/.test(p)) return 'Kiraz';
  if (/soğan|sogan|onion/.test(p)) return 'Soğan';
  return null;
}

/**
 * Beklenen tabii fire (kg): her gün, o ayın oranının günlük payı × depodaki kg.
 * fromIso: depoya giriş; toIso: çıkış (yoksa bugün). mcp: 1-MCP uygulandıysa ×0,85.
 */
export function expectedFire(product: string | undefined, kg: number, fromIso: string | undefined, toIso?: string, mcp = false): { kg: number; pct: number; key: string | null; note?: string } {
  const key = fireKey(product);
  if (!kg || !fromIso) return { kg: 0, pct: 0, key: typeof key === 'string' ? key : null };
  if (key === null) return { kg: 0, pct: 0, key: null, note: 'normatif yok' };
  if (key === 'ZERO') return { kg: 0, pct: 0, key: 'Freeze-dry', note: 'kuru ürün, su kaybı yok' };
  if (key === 'BANAN') { const l = kg * FIRE_BANANA_PER_LOT * (mcp ? FIRE_MCP_FACTOR : 1); return { kg: l, pct: (l / kg) * 100, key: 'Muz', note: 'parti başına %4' }; }
  const rates = FIRE_MONTHLY[key];
  const start = new Date(fromIso.slice(0, 10) + 'T00:00:00');
  const end = toIso ? new Date(toIso.slice(0, 10) + 'T00:00:00') : new Date();
  let loss = 0;
  for (let d = new Date(start); d < end; d.setDate(d.getDate() + 1)) {
    const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    loss += kg * (rates[d.getMonth()] / dim);
  }
  if (mcp) loss *= FIRE_MCP_FACTOR;
  return { kg: loss, pct: (loss / kg) * 100, key };
}
