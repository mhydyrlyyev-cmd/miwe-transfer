/**
 * v64 — BBCH fenolojik aşamaları (meyve ağaçları). Kod + Baggiolini harfi + Türkçe ad.
 * Kaynak: Agroscope (A.-L. Fabre, B. Bloesch, O. Viret) aşama kartları — kayısı, armut, erik, şeftali;
 * Bayer "Fruits d'excellence" kartları — elma, kiraz. Temel: Baggiolini 1952; Lancashire ve ark. 1991 (BBCH).
 * Ana gruplar: 0 kış dinlenmesi · 5 çiçek salkımı görünür · 6 çiçeklenme · 7 meyve gelişimi · 8 olgunlaşma.
 */
export interface BbchStage { code: string; letter?: string; name: string; group: 0 | 5 | 6 | 7 | 8 }
export const BBCH_SOURCE = 'Agroscope ve Bayer BBCH aşama kartları (Baggiolini 1952, Lancashire 1991)';
export const BBCH_GROUPS: Record<number, string> = { 0: 'Kış dinlenmesi', 5: 'Çiçek salkımı görünür', 6: 'Çiçeklenme', 7: 'Meyve gelişimi', 8: 'Olgunlaşma' };

const POME: BbchStage[] = [
  { code: '00', letter: 'A', name: 'Kış tomurcuğu (dinlenme)', group: 0 },
  { code: '51', letter: 'B', name: 'Tomurcuk kabarması', group: 5 },
  { code: '53', letter: 'C', name: 'Tomurcuk patlaması', group: 5 },
  { code: '54', letter: 'C3', name: 'Fare kulağı', group: 5 },
  { code: '56', letter: 'D', name: 'Yeşil tomurcuk', group: 5 },
  { code: '57', letter: 'E', name: 'Pembe tomurcuk', group: 5 },
  { code: '59', letter: 'E2', name: 'Balon', group: 5 },
  { code: '61', letter: 'F', name: 'Çiçeklenme başı', group: 6 },
  { code: '65', letter: 'F2', name: 'Tam çiçeklenme', group: 6 },
  { code: '67', letter: 'G', name: 'Çiçeklenme azalıyor', group: 6 },
  { code: '69', letter: 'H', name: 'Çiçeklenme sonu', group: 6 },
  { code: '71', letter: 'I', name: 'Meyve tutumu', group: 7 },
  { code: '72', letter: 'J', name: 'Fındık iriliği', group: 7 },
  { code: '74', name: 'T evresi', group: 7 },
  { code: '77', name: 'Meyve büyümesi', group: 7 },
  { code: '81', name: 'Olgunlaşma başı', group: 8 },
  { code: '85', name: 'İleri olgunluk', group: 8 },
  { code: '87-89', name: 'Hasat, tam yeme olgunluğu', group: 8 },
];
const STONE: BbchStage[] = [
  { code: '00', letter: 'A', name: 'Kış tomurcuğu (dinlenme)', group: 0 },
  { code: '51', letter: 'B', name: 'Tomurcuk kabarması', group: 5 },
  { code: '53', letter: 'C', name: 'Tomurcuk patlaması', group: 5 },
  { code: '57', letter: 'D', name: 'Çanak yaprak açılması', group: 5 },
  { code: '59', letter: 'E', name: 'Balon', group: 5 },
  { code: '61', name: 'Çiçeklenme başı', group: 6 },
  { code: '65', letter: 'F', name: 'Tam çiçeklenme', group: 6 },
  { code: '67', letter: 'G', name: 'Çiçeklenme azalıyor', group: 6 },
  { code: '69', name: 'Çiçeklenme sonu', group: 6 },
  { code: '71', letter: 'H', name: 'Meyve tutumu', group: 7 },
  { code: '73', letter: 'I–J', name: 'Genç meyve', group: 7 },
  { code: '75', name: 'Meyve son iriliğin %50’si', group: 7 },
  { code: '77', name: 'Meyve son iriliğin %70’i', group: 7 },
  { code: '81', name: 'Renklenme başı', group: 8 },
  { code: '85', name: 'İleri renklenme', group: 8 },
  { code: '87-89', name: 'Hasat, yeme olgunluğu', group: 8 },
];
const CHERRY: BbchStage[] = [
  { code: '00', letter: 'A', name: 'Kış tomurcuğu (dinlenme)', group: 0 },
  { code: '51', letter: 'B', name: 'Tomurcuk kabarması', group: 5 },
  { code: '53', letter: 'C', name: 'Tomurcuk patlaması', group: 5 },
  { code: '57', letter: 'D', name: 'Çanak yaprak açılması · beyaz tomurcuk', group: 5 },
  { code: '59', letter: 'E', name: 'Balon · çiçeklenme başı, erkek organlar görünür', group: 5 },
  { code: '65', letter: 'F', name: 'Tam çiçeklenme', group: 6 },
  { code: '67', letter: 'G', name: 'Taç yaprak dökümü başı', group: 6 },
  { code: '68', name: 'Taç yaprak dökümü sonu', group: 6 },
  { code: '69', name: 'Çiçeklenme sonu', group: 6 },
  { code: '71', letter: 'H', name: 'Meyve tutumu · çiçek sonrası döküm', group: 7 },
  { code: '73', letter: 'I–J', name: 'İkinci meyve dökümü', group: 7 },
  { code: '75', name: 'Meyve son iriliğin %50’si', group: 7 },
  { code: '79', name: 'Meyve son iriliğin %90’ı', group: 7 },
  { code: '81', name: 'Renk dönümü başı', group: 8 },
  { code: '83', name: 'Renk dönümü', group: 8 },
  { code: '85', name: 'Renk dönümü ortası · %50 olgunluk', group: 8 },
  { code: '89', name: 'Tüketim için en iyi olgunluk', group: 8 },
];

/** Ürün adı → aşama listesi (Nashi armut kartını, nektarin şeftali kartını kullanır). Badem / muz için kart yok → []. */
export function bbchFor(product?: string): BbchStage[] {
  const p = (product || '').toLocaleLowerCase('tr');
  if (/kiraz|çereş|cherry/.test(p)) return CHERRY;
  if (/elma|apple|armut|pear|nashi|ayva/.test(p)) return POME;
  if (/şeftali|seftali|nektarin|kayısı|kayisi|erik|apricot|plum|peach/.test(p)) return STONE;
  return [];
}
export const bbchLabel = (product: string | undefined, code?: string) => {
  if (!code) return '';
  const s = bbchFor(product).find(x => x.code === code);
  return s ? `BBCH ${s.code} · ${s.name}` : `BBCH ${code}`;
};
