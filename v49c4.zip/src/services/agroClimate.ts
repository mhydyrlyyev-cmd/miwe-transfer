/**
 * v49c4 — Bahçe iklimi (Open-Meteo geçmiş + tahmin; ücretsiz, anahtar gerekmez).
 *  · Gün-derece (GDD): çiçeklenmeden bugüne Σ max(0, (Tmax+Tmin)/2 − taban). Taban profilden (varsayılan 10 °C).
 *  · Soğuklama saati: 1 Kasım'dan bugüne 0 < T ≤ 7,2 °C saat sayısı.
 *  · Çiçek donu: çiçeklenme −10 … +25 gün penceresinde tahmin Tmin ≤ 0 °C uyarı, ≤ −2 °C kritik (iç hedef).
 *  · Geçen yıl: aynı takvim aralığı.
 * Veriler bahçe başına 12 saat yerel önbellekte tutulur.
 */
import { useEffect, useState } from 'react';

export const CLIMATE_LIMITS = { chillLowC: 0, chillHighC: 7.2, bloomWarnC: 0, bloomCritC: -2, defaultBaseC: 10, bloomBefore: 10, bloomAfter: 25 };

export interface ClimDay { date: string; tMax: number; tMin: number; chill: number; forecast?: boolean }

const DAY = 86400000;
const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => iso(new Date(new Date(`${s}T00:00:00Z`).getTime() + n * DAY));
const shiftYear = (s: string, n: number) => `${Number(s.slice(0, 4)) + n}${s.slice(4)}`.replace(/-02-29$/, '-02-28');
const KEY = 'miwe_climate_v1';
const TZ = 'Asia%2FAshgabat';

function toDays(j: any, forecastFrom?: string): ClimDay[] {
  const d = j?.daily || {}, h = j?.hourly || {};
  const chill: Record<string, number> = {};
  (h.time || []).forEach((t: string, i: number) => {
    const v = h.temperature_2m?.[i];
    if (typeof v === 'number' && v > CLIMATE_LIMITS.chillLowC && v <= CLIMATE_LIMITS.chillHighC) chill[t.slice(0, 10)] = (chill[t.slice(0, 10)] || 0) + 1;
  });
  return (d.time || []).map((t: string, i: number) => ({
    date: t, tMax: d.temperature_2m_max?.[i], tMin: d.temperature_2m_min?.[i], chill: chill[t] || 0,
    forecast: forecastFrom ? t > forecastFrom : undefined,
  })).filter((x: ClimDay) => typeof x.tMax === 'number' && typeof x.tMin === 'number');
}

async function getJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`İklim servisi ${r.status}`);
  return r.json();
}

/** start → bugün (+7 gün tahmin). Geçmiş için arşiv, son 7 gün ve tahmin için tahmin servisi. */
export async function fetchClimate(lat: number, lon: number, start: string, withForecast: boolean, end?: string): Promise<ClimDay[]> {
  const today = iso(new Date());
  const stop = end || today;
  const ck = `${lat.toFixed(3)},${lon.toFixed(3)},${start},${stop},${withForecast ? 'f' : 'a'}`;
  let cache: Record<string, { at: number; days: ClimDay[] }> = {};
  try { cache = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { cache = {}; }
  if (cache[ck] && Date.now() - cache[ck].at < 12 * 3600000) return cache[ck].days;
  const q = `latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min&hourly=temperature_2m&timezone=${TZ}`;
  const archEnd = withForecast ? addDays(today, -7) : stop;
  const out = new Map<string, ClimDay>();
  if (start <= archEnd) {
    const a = await getJson(`https://archive-api.open-meteo.com/v1/archive?${q}&start_date=${start}&end_date=${archEnd}`);
    for (const x of toDays(a)) out.set(x.date, x);
  }
  if (withForecast) {
    const f = await getJson(`https://api.open-meteo.com/v1/forecast?${q}&past_days=7&forecast_days=7`);
    for (const x of toDays(f, today)) if (x.date >= start) out.set(x.date, x);
  }
  const days = [...out.values()].sort((a, b) => a.date.localeCompare(b.date));
  try {
    const keep = Object.fromEntries(Object.entries(cache).filter(([, v]) => Date.now() - v.at < 2 * DAY));
    localStorage.setItem(KEY, JSON.stringify({ ...keep, [ck]: { at: Date.now(), days } }));
  } catch { /* yer yoksa önbelleksiz devam */ }
  return days;
}

/** "03-25" (AA-GG) ya da "25.03" (GG.AA) → AA-GG */
export function parseMonthDay(v: unknown): string | null {
  const s = String(v ?? '').trim();
  const m = s.match(/^(\d{1,2})\s*([.\-/])\s*(\d{1,2})/);
  if (!m) return null;
  let [mo, da] = m[2] === '.' ? [Number(m[3]), Number(m[1])] : [Number(m[1]), Number(m[3])];
  if (mo > 12 && da <= 12) [mo, da] = [da, mo];
  if (mo < 1 || mo > 12 || da < 1 || da > 31) return null;
  return `${String(mo).padStart(2, '0')}-${String(da).padStart(2, '0')}`;
}

export interface OrchardClimate {
  name: string;
  baseC: number;
  bloom?: string;                 // bu sezonun çiçeklenme tarihi
  nextBloom?: string;
  gdd?: number; gddLast?: number;
  harvestGdd?: number; harvestEta?: string; harvestReached?: string;
  chill: number; chillLast: number; chillStart: string;
  frost: { level: 'none' | 'warn' | 'crit' | 'off'; text: string };
  forecast: ClimDay[];
  error?: string;
  missing: string[];
}

const sumGdd = (days: ClimDay[], base: number) => days.reduce((s, d) => s + Math.max(0, (d.tMax + d.tMin) / 2 - base), 0);

export function computeClimate(name: string, fields: Record<string, unknown>, now: ClimDay[], last: ClimDay[], todayIso = iso(new Date())): OrchardClimate {
  const missing: string[] = [];
  const baseC = Number(fields.gddBaseC) > -10 && fields.gddBaseC !== '' && fields.gddBaseC != null ? Number(fields.gddBaseC) : CLIMATE_LIMITS.defaultBaseC;
  const md = parseMonthDay(fields.bloomDate);
  if (!md) missing.push('Çiçeklenme tarihi');
  const y = Number(todayIso.slice(0, 4));
  const chillStart = todayIso.slice(5) >= '11-01' ? `${y}-11-01` : `${y - 1}-11-01`;
  const past = now.filter(d => d.date <= todayIso);
  const chill = past.filter(d => d.date >= chillStart).reduce((s, d) => s + d.chill, 0);
  const lastToday = shiftYear(todayIso, -1);
  const chillLast = last.filter(d => d.date >= shiftYear(chillStart, -1) && d.date <= lastToday).reduce((s, d) => s + d.chill, 0);
  const forecast = now.filter(d => d.date > todayIso);
  const res: OrchardClimate = { name, baseC, chill, chillLast, chillStart, frost: { level: 'off', text: 'Çiçeklenme tarihi girilmemiş' }, forecast, missing };
  if (!md) return res;

  const thisBloom = `${y}-${md}`;
  const bloom = thisBloom <= todayIso ? thisBloom : `${y - 1}-${md}`;
  const nextBloom = thisBloom > todayIso ? thisBloom : `${y + 1}-${md}`;
  res.bloom = bloom; res.nextBloom = nextBloom;
  const since = past.filter(d => d.date >= bloom);
  res.gdd = Math.round(sumGdd(since, baseC));
  const lb = shiftYear(bloom, -1);
  res.gddLast = Math.round(sumGdd(last.filter(d => d.date >= lb && d.date <= lastToday), baseC));

  const target = Number(fields.harvestGdd);
  if (target > 0) {
    res.harvestGdd = target;
    let acc = 0;
    for (const d of since) { acc += Math.max(0, (d.tMax + d.tMin) / 2 - baseC); if (acc >= target) { res.harvestReached = d.date; break; } }
    if (!res.harvestReached) {
      const recent = [...past.slice(-14), ...forecast];
      const rate = recent.length ? sumGdd(recent, baseC) / recent.length : 0;
      if (rate > 0.5) res.harvestEta = addDays(todayIso, Math.ceil((target - (res.gdd || 0)) / rate));
    }
  }

  // çiçek donu penceresi: en yakın çiçeklenme (geçmiş ya da gelecek)
  const near = [bloom, nextBloom].find(b => todayIso >= addDays(b, -CLIMATE_LIMITS.bloomBefore - 7) && todayIso <= addDays(b, CLIMATE_LIMITS.bloomAfter));
  if (!near) {
    const days = Math.round((new Date(nextBloom).getTime() - new Date(todayIso).getTime()) / DAY);
    res.frost = { level: 'off', text: `Çiçeklenme dönemi dışında · sıradaki ≈ ${nextBloom.split('-').reverse().slice(0, 2).join('.')} (${days} gün)` };
  } else {
    const win = forecast.filter(d => d.date >= addDays(near, -CLIMATE_LIMITS.bloomBefore) && d.date <= addDays(near, CLIMATE_LIMITS.bloomAfter));
    const min = win.reduce((m, d) => Math.min(m, d.tMin), Infinity);
    const at = win.find(d => d.tMin === min);
    if (min <= CLIMATE_LIMITS.bloomCritC) res.frost = { level: 'crit', text: `Çiçek donu riski: ${at?.date.split('-').reverse().slice(0, 2).join('.')} ${min.toFixed(1)} °C` };
    else if (min <= CLIMATE_LIMITS.bloomWarnC) res.frost = { level: 'warn', text: `Hafif don: ${at?.date.split('-').reverse().slice(0, 2).join('.')} ${min.toFixed(1)} °C` };
    else res.frost = { level: 'none', text: win.length ? `Çiçeklenme döneminde · 7 gün içinde don yok (en düşük ${min.toFixed(1)} °C)` : 'Çiçeklenme döneminde · tahmin bekleniyor' };
  }
  if (target <= 0 || !fields.harvestGdd) missing.push('Hasat GDD hedefi');
  return res;
}

export interface ClimatePoint { name: string; lat?: number; lon?: number; fields: Record<string, unknown> }

export function useOrchardClimate(points: ClimatePoint[]) {
  const [data, setData] = useState<Record<string, OrchardClimate>>({});
  const [loading, setLoading] = useState(false);
  const sig = points.map(p => `${p.name}:${p.lat},${p.lon}:${p.fields.bloomDate}:${p.fields.gddBaseC}:${p.fields.harvestGdd}`).join('|');
  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      const today = iso(new Date());
      const y = Number(today.slice(0, 4));
      for (const p of points) {
        if (typeof p.lat !== 'number' || typeof p.lon !== 'number') continue;
        // en eski gerekli gün: geçen yılın 1 Kasım'ı ya da son çiçeklenme
        const md = parseMonthDay(p.fields.bloomDate);
        const chillStart = today.slice(5) >= '11-01' ? `${y}-11-01` : `${y - 1}-11-01`;
        const bloom = md ? (`${y}-${md}` <= today ? `${y}-${md}` : `${y - 1}-${md}`) : chillStart;
        const start = bloom < chillStart ? bloom : chillStart;
        try {
          const [now, last] = await Promise.all([
            fetchClimate(p.lat, p.lon, start, true),
            fetchClimate(p.lat, p.lon, shiftYear(start, -1), false, shiftYear(today, -1)),
          ]);
          if (alive) setData(d => ({ ...d, [p.name]: computeClimate(p.name, p.fields, now, last, today) }));
        } catch (e: any) {
          if (alive) setData(d => ({ ...d, [p.name]: { name: p.name, baseC: CLIMATE_LIMITS.defaultBaseC, chill: 0, chillLast: 0, chillStart, frost: { level: 'off', text: '' }, forecast: [], missing: [], error: 'İklim verisi alınamadı (bağlantı)' } }));
        }
      }
      if (alive) setLoading(false);
    })();
    return () => { alive = false; };
  }, [sig]);
  return { data, loading };
}
