/**
 * MIWE HIL — Kimlik ve Yetki Servisi (Mimari v2)
 * ------------------------------------------------------------------
 * Kimlik:  Firebase Authentication (e-posta + parola)
 * Profil:  Firestore  users/{uid}   (rol, durum, modül yetkileri)
 * Güvenlik: firestore.rules — yetki kontrolü SUNUCUDA (Google) yapılır,
 *           istemcideki kontroller sadece arayüz kolaylığıdır.
 *
 * Eski sürümle aynı fonksiyon adları ve dönüş tipleri korunmuştur;
 * bileşenler (LoginView, App, AdminUserManagementModal ...) değişmeden çalışır.
 * localStorage artık YETKİ kaynağı değildir; sadece çevrimdışı açılış için önbellektir.
 */
import {
  onAuthStateChanged,
  onIdTokenChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendEmailVerification,
  sendPasswordResetEmail,
  reauthenticateWithCredential,
  EmailAuthProvider,
  updatePassword,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  User as FirebaseUser
} from 'firebase/auth';
import {
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { auth, db, OWNER_EMAIL } from '../lib/firebase';
import { AppUser, ActivityLogItem, ActivityActionType, UserPermissions, UserStatus } from '../types/auth';
import { addDebugLog } from './debugLogger';
import { syncNotificationsWithServer, startNotificationsListener, stopNotificationsListener } from './notificationService';

const STORAGE_USERS_KEY = 'miwe_platform_users';
const STORAGE_CURRENT_USER_KEY = 'miwe_current_user';
const STORAGE_ACTIVITY_LOGS_KEY = 'miwe_activity_logs';
const LEGACY_KEYS = ['miwe_admin_auth', 'miwe_session_token'];

const NO_PERMISSIONS: UserPermissions = { canEdit: false, canDelete: false, canClearDemo: false, canExport: false, canViewAll: false };
const FULL_PERMISSIONS: UserPermissions = { canEdit: true, canDelete: true, canClearDemo: true, canExport: true, canViewAll: true };

// Eski sürümden kalan, istemci tarafında "admin" yetkisi veren bayrakları temizle
if (typeof window !== 'undefined') {
  LEGACY_KEYS.forEach(k => { try { localStorage.removeItem(k); } catch {} });
}

// -------------------------------------------------------------
// Yerel önbellek (yalnızca arayüz/çevrimdışı için)
// -------------------------------------------------------------
let cachedIdToken: string | null = null;

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

function profileFromDoc(id: string, data: any): AppUser {
  return {
    id,
    fullName: data?.fullName || '',
    phone: data?.phone || '',
    email: data?.email || '',
    company: data?.company || '',
    jobTitle: data?.jobTitle || '',
    role: data?.role || 'VIEWER',
    status: data?.status || 'PENDING',
    allowedModules: Array.isArray(data?.allowedModules) ? data.allowedModules : [],
    permissions: { ...NO_PERMISSIONS, ...(data?.permissions || {}) },
    requiresPasswordChange: !!data?.requiresPasswordChange,
    createdAt: data?.createdAt || '',
    updatedAt: data?.updatedAt,
    lastLoginAt: data?.lastLoginAt,
    approvedBy: data?.approvedBy,
    approvedAt: data?.approvedAt
  };
}

function isActiveStatus(status?: UserStatus): boolean {
  return status === 'APPROVED' || status === 'PASIF_READER';
}

function statusMessage(status: UserStatus): string {
  switch (status) {
    case 'PENDING': return 'Hesabınız yönetici onayı bekliyor. Onaylandığında giriş yapabilirsiniz.';
    case 'REJECTED': return 'Kayıt başvurunuz reddedildi. Lütfen sistem yöneticisiyle iletişime geçin.';
    case 'DEACTIVATED': return 'Hesabınız pasife alınmış. Lütfen sistem yöneticisiyle iletişime geçin.';
    default: return 'Hesabınız aktif değil.';
  }
}

function translateAuthError(err: any): string {
  const code: string = err?.code || '';
  if (code.includes('invalid-credential') || code.includes('wrong-password') || code.includes('user-not-found')) {
    return 'E-posta veya parola hatalı. Hesabınızı Google ile açtıysanız parolanız yoktur: "Google ile giriş"i kullanın ya da "Şifremi unuttum" ile parola belirleyin.';
  }
  if (code.includes('too-many-requests')) return 'Çok fazla deneme yapıldı. Birkaç dakika sonra tekrar deneyin.';
  if (code.includes('network-request-failed')) return 'İnternet bağlantısı yok. Bağlantınızı kontrol edin.';
  if (code.includes('email-already-in-use')) return 'Bu e-posta adresiyle zaten bir hesap var. Giriş yapın veya parolanızı sıfırlayın.';
  if (code.includes('weak-password')) return 'Parola çok zayıf (en az 8 karakter kullanın).';
  if (code.includes('invalid-email')) return 'Geçersiz e-posta adresi.';
  if (code.includes('operation-not-allowed')) return 'E-posta/parola girişi Firebase projesinde etkin değil (yönetici: Authentication → Sign-in method).';
  if (code.includes('requires-recent-login')) return 'Güvenlik için tekrar giriş yapmanız gerekiyor.';
  if (code.includes('permission-denied')) return 'Bu işlem için yetkiniz yok.';
  return err?.message || 'Beklenmeyen bir hata oluştu.';
}

// -------------------------------------------------------------
// Oturum durumu (eski API ile uyumlu)
// -------------------------------------------------------------

/** Firebase ID token (sunucu çağrıları için). Eski "session token" yerine geçer. */
export function getSessionToken(): string | null {
  return cachedIdToken;
}

/** Eski sürüm uyumluluğu: token artık Firebase tarafından yönetilir. */
export function setSessionToken(_token: string | null): void {}

/** Yönetici mi? Yalnızca Firestore profilindeki role bakılır (kurallar da bunu doğrular). */
export function isAdminAuthenticated(): boolean {
  const cur = getCurrentUser();
  return !!cur && cur.role === 'ADMIN' && cur.status === 'APPROVED' && !!auth.currentUser;
}

/** Eski sürüm uyumluluğu: istemci tarafında admin bayrağı KALDIRILDI. */
export function setAdminAuthenticated(_isAuth: boolean): void {}

export function getCurrentUser(): AppUser | null {
  return readJson<AppUser | null>(STORAGE_CURRENT_USER_KEY, null);
}

export function setCurrentUser(user: AppUser | null): void {
  if (user) writeJson(STORAGE_CURRENT_USER_KEY, user);
  else { try { localStorage.removeItem(STORAGE_CURRENT_USER_KEY); } catch {} }
}

export interface SessionAuditResult {
  checkedAt: string;
  adminAuthRaw: string | null;
  sessionTokenRaw: string | null;
  isAdminFlag: boolean;
  userIsAdmin: boolean;
  isTokenPresent: boolean;
  isTokenMalformed: boolean;
  isTokenValid: boolean;
  tokenLength: number;
  status: 'VALID' | 'WARNING' | 'ERROR';
  statusMessage: string;
  user: AppUser | null;
}

export function performSessionAudit(): SessionAuditResult {
  const user = getCurrentUser();
  const fbUser = auth.currentUser;
  const token = cachedIdToken;
  const userIsAdmin = user?.role === 'ADMIN';
  let status: SessionAuditResult['status'] = 'VALID';
  let msg = 'Firebase oturumu aktif ve profil doğrulandı.';
  if (!fbUser) {
    status = user ? 'WARNING' : 'ERROR';
    msg = user
      ? 'Önbellekte kullanıcı var ancak Firebase oturumu henüz doğrulanmadı (çevrimdışı olabilir).'
      : 'Aktif oturum yok.';
  } else if (user && fbUser.uid !== user.id) {
    status = 'ERROR';
    msg = 'Önbellekteki profil ile Firebase oturumu uyuşmuyor. Lütfen tekrar giriş yapın.';
  }
  return {
    checkedAt: new Date().toISOString(),
    adminAuthRaw: null,
    sessionTokenRaw: token ? `${token.slice(0, 8)}…` : null,
    isAdminFlag: userIsAdmin,
    userIsAdmin,
    isTokenPresent: !!token,
    isTokenMalformed: false,
    isTokenValid: !!fbUser,
    tokenLength: token?.length || 0,
    status,
    statusMessage: msg,
    user
  };
}

// -------------------------------------------------------------
// Dinleyiciler
// -------------------------------------------------------------
let logoutListeners: Array<() => void> = [];
export function onAuthFailure(callback: () => void): () => void {
  logoutListeners.push(callback);
  return () => { logoutListeners = logoutListeners.filter(cb => cb !== callback); };
}

export function triggerGlobalLogout(): void {
  setCurrentUser(null);
  LEGACY_KEYS.forEach(k => { try { localStorage.removeItem(k); } catch {} });
  logoutListeners.forEach(cb => { try { cb(); } catch (e) { console.warn(e); } });
}

let userSyncListeners: Array<(users: AppUser[]) => void> = [];
export function subscribeToUsersSync(cb: (users: AppUser[]) => void): () => void {
  userSyncListeners.push(cb);
  return () => { userSyncListeners = userSyncListeners.filter(l => l !== cb); };
}
function emitUsers(users: AppUser[]) {
  userSyncListeners.forEach(cb => { try { cb(users); } catch {} });
}

// -------------------------------------------------------------
// Firebase oturum köprüsü — uygulama açılır açılmaz çalışır
// -------------------------------------------------------------
let ownProfileUnsub: Unsubscribe | null = null;
let rosterUnsub: Unsubscribe | null = null;
let authReadyResolve: (() => void) | null = null;
const authReady = new Promise<void>(resolve => { authReadyResolve = resolve; });

function stopProfileListeners() {
  ownProfileUnsub?.(); ownProfileUnsub = null;
  rosterUnsub?.(); rosterUnsub = null;
  stopNotificationsListener();
}

function startRosterListener() {
  if (rosterUnsub) return;
  rosterUnsub = onSnapshot(
    collection(db, 'users'),
    snap => {
      const users = snap.docs.map(d => profileFromDoc(d.id, d.data()));
      writeJson(STORAGE_USERS_KEY, users);
      emitUsers(users);
    },
    err => console.warn('[Auth] Kullanıcı listesi dinlenemedi:', err?.code || err)
  );
}

function startOwnProfileListener(uid: string) {
  ownProfileUnsub?.();
  ownProfileUnsub = onSnapshot(
    doc(db, 'users', uid),
    snap => {
      if (!snap.exists()) return;
      const profile = profileFromDoc(uid, snap.data());
      setCurrentUser(profile);
      if (isActiveStatus(profile.status) || profile.role === 'ADMIN') startNotificationsListener(uid);
      if (profile.role === 'ADMIN' && profile.status === 'APPROVED') {
        startRosterListener();
      } else {
        rosterUnsub?.(); rosterUnsub = null;
        writeJson(STORAGE_USERS_KEY, [profile]);
        emitUsers([profile]);
      }
    },
    err => console.warn('[Auth] Profil dinlenemedi:', err?.code || err)
  );
}

if (typeof window !== 'undefined') {
  onIdTokenChanged(auth, async (fbUser) => {
    cachedIdToken = fbUser ? await fbUser.getIdToken().catch(() => null) : null;
  });

  onAuthStateChanged(auth, (fbUser) => {
    authReadyResolve?.();
    if (!fbUser) {
      stopProfileListeners();
      if (getCurrentUser()) triggerGlobalLogout();
      return;
    }
    const cached = getCurrentUser();
    if (cached && cached.id !== fbUser.uid) setCurrentUser(null);
    startOwnProfileListener(fbUser.uid);
  });
}

/** Sunucu (Express) çağrıları için Firebase ID token ekler. */
export async function authFetch(input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers || {});
  const token = auth.currentUser ? await auth.currentUser.getIdToken().catch(() => null) : null;
  if (token && !headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
  return fetch(input, { ...init, headers });
}

// -------------------------------------------------------------
// Giriş / Kayıt / Çıkış
// -------------------------------------------------------------

/** Sistem sahibi doğrulanmış e-postayla girdiğinde profili ADMIN'e yükseltir (tek seferlik). */
async function ensureOwnerBootstrap(fbUser: FirebaseUser, profile: AppUser | null): Promise<AppUser | null> {
  const email = (fbUser.email || '').toLowerCase();
  if (email !== OWNER_EMAIL || !fbUser.emailVerified) return profile;
  if (profile && profile.role === 'ADMIN' && profile.status === 'APPROVED') return profile;
  await fbUser.getIdToken(true); // email_verified bilgisini token'a yansıt
  const now = new Date().toISOString();
  const data = {
    fullName: profile?.fullName || fbUser.displayName || 'Sistem Yöneticisi',
    email,
    phone: profile?.phone || '',
    company: profile?.company || 'Miwe AGPJ Merkez',
    jobTitle: profile?.jobTitle || 'Sistem Yöneticisi',
    role: 'ADMIN',
    status: 'APPROVED',
    allowedModules: ['ALL'],
    permissions: FULL_PERMISSIONS,
    requiresPasswordChange: false,
    createdAt: profile?.createdAt || now,
    updatedAt: now,
    approvedBy: 'OWNER_BOOTSTRAP',
    approvedAt: now
  };
  await setDoc(doc(db, 'users', fbUser.uid), data, { merge: true });
  return profileFromDoc(fbUser.uid, data);
}

export async function loginUser(
  identifier: string,
  password: string
): Promise<{ success: boolean; message: string; user?: AppUser; token?: string; status?: UserStatus }> {
  const cleanId = (identifier || '').trim().toLowerCase();
  const cleanPass = (password || '').trim();
  if (!cleanId || !cleanPass) return { success: false, message: 'Lütfen e-posta ve parolanızı girin.' };
  if (!cleanId.includes('@')) {
    return { success: false, message: 'Giriş için kayıtlı e-posta adresinizi kullanın (telefonla giriş yeni sistemde kapalı).' };
  }

  try {
    const cred = await signInWithEmailAndPassword(auth, cleanId, cleanPass);
    const snap = await getDoc(doc(db, 'users', cred.user.uid));
    let profile = snap.exists() ? profileFromDoc(cred.user.uid, snap.data()) : null;
    profile = await ensureOwnerBootstrap(cred.user, profile);

    if (!profile) {
      await signOut(auth);
      return { success: false, message: 'Profil bulunamadı. Lütfen "Kayıt Ol" sekmesinden başvurunuzu tamamlayın.' };
    }
    if (!isActiveStatus(profile.status) && profile.role !== 'ADMIN') {
      await signOut(auth);
      return { success: false, message: statusMessage(profile.status), status: profile.status };
    }

    updateDoc(doc(db, 'users', cred.user.uid), { lastLoginAt: new Date().toISOString() }).catch(() => {});
    setCurrentUser(profile);
    logActivity('LOGIN', 'Sisteme giriş yapıldı', 'AUTH');
    return { success: true, message: 'Giriş başarılı.', user: profile, token: await cred.user.getIdToken() };
  } catch (err: any) {
    addDebugLog('AUTH', 'WARN', '[Auth] Giriş başarısız', { code: err?.code });
    return { success: false, message: translateAuthError(err) };
  }
}

/**
 * Google ile giriş (AI Studio'nun Firebase entegrasyonu Google Sign-In'i varsayılan olarak açar).
 * İlk girişte profil otomatik PENDING olarak oluşturulur; yönetici onaylayınca erişim açılır.
 * Google hesapları doğrulanmış e-postaya sahip olduğu için sistem sahibi doğrudan ADMIN olur.
 */
type GoogleLoginResult = { success: boolean; message: string; user?: AppUser; status?: UserStatus; openInNewTab?: boolean; redirecting?: boolean };

/** v45: uygulama bir iframe içinde mi (AI Studio önizlemesi)? Google açılır penceresi iframe'de çoğu zaman çalışmaz. */
export function isInIframe(): boolean {
  try { return window.self !== window.top; } catch { return true; }
}

async function finishGoogleLogin(fbUser: FirebaseUser): Promise<GoogleLoginResult> {
  const ref = doc(db, 'users', fbUser.uid);
  const snap = await getDoc(ref);
  let profile = snap.exists() ? profileFromDoc(fbUser.uid, snap.data()) : null;

  if (!profile && (fbUser.email || '').toLowerCase() !== OWNER_EMAIL) {
    const now = new Date().toISOString();
    const data = {
      fullName: fbUser.displayName || fbUser.email || '',
      email: (fbUser.email || '').toLowerCase(),
      phone: fbUser.phoneNumber || '',
      company: '',
      jobTitle: '',
      role: 'OPERATOR',
      status: 'PENDING',
      allowedModules: [],
      permissions: NO_PERMISSIONS,
      requiresPasswordChange: false,
      createdAt: now,
      updatedAt: now
    };
    await setDoc(ref, data);
    profile = profileFromDoc(fbUser.uid, data);
  }
  profile = await ensureOwnerBootstrap(fbUser, profile);

  if (!profile || (!isActiveStatus(profile.status) && profile.role !== 'ADMIN')) {
    const status = profile?.status || 'PENDING';
    await signOut(auth);
    return { success: false, message: statusMessage(status), status };
  }
  updateDoc(ref, { lastLoginAt: new Date().toISOString() }).catch(() => {});
  setCurrentUser(profile);
  logActivity('LOGIN', 'Google ile giriş yapıldı', 'AUTH');
  return { success: true, message: 'Giriş başarılı.', user: profile };
}

function googleErrorResult(err: any): GoogleLoginResult {
  const code = String(err?.code || '');
  const msg = String(err?.message || err);
  if (code === 'auth/unauthorized-domain') {
    return { success: false, message: `Bu adres (${window.location.hostname}) Firebase'de yetkili değil. Firebase Console › Authentication › Settings › Authorized domains listesine ekleyin; o zamana kadar e-posta ve şifreyle girin.` };
  }
  const popupProblem = msg.includes('INTERNAL ASSERTION FAILED') || code === 'auth/popup-blocked' || code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request' || code === 'auth/operation-not-supported-in-this-environment' || code === 'auth/web-storage-unsupported';
  if (popupProblem && isInIframe()) {
    return { success: false, openInNewTab: true, message: 'Önizleme penceresi Google girişine izin vermiyor. Uygulamayı yeni sekmede açıp orada Google ile girin ya da burada e-posta ve şifreyle girin.' };
  }
  if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
    return { success: false, message: 'Google penceresi kapatıldı. Tekrar deneyin.' };
  }
  return { success: false, message: translateAuthError(err) };
}

/**
 * Google ile giriş. Önce açılır pencere denenir; pencere engellenirse ve uygulama iframe içinde DEĞİLSE
 * yönlendirmeli girişe geçilir (sayfa Google'a gider, dönüşte completeGoogleRedirect sonucu alır).
 * İlk girişte profil PENDING oluşturulur; sistem sahibi doğrudan ADMIN olur.
 */
export async function loginWithGoogle(): Promise<GoogleLoginResult> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  try {
    const cred = await signInWithPopup(auth, provider);
    return await finishGoogleLogin(cred.user);
  } catch (err: any) {
    const code = String(err?.code || '');
    if (!isInIframe() && (code === 'auth/popup-blocked' || code === 'auth/operation-not-supported-in-this-environment')) {
      try {
        await signInWithRedirect(auth, provider);
        return { success: false, redirecting: true, message: 'Google sayfasına yönlendiriliyor…' };
      } catch (e2: any) {
        return googleErrorResult(e2);
      }
    }
    return googleErrorResult(err);
  }
}

/** v45: yönlendirmeli Google girişinden dönüşte çağrılır; sonuç yoksa null döner. */
export async function completeGoogleRedirect(): Promise<GoogleLoginResult | null> {
  try {
    const res = await getRedirectResult(auth);
    if (!res?.user) return null;
    return await finishGoogleLogin(res.user);
  } catch (err: any) {
    return googleErrorResult(err);
  }
}

export async function loginAdmin(
  identifier: string,
  password: string
): Promise<{ success: boolean; message: string; user?: AppUser; token?: string }> {
  const res = await loginUser(identifier, password);
  if (!res.success || !res.user) return { success: false, message: res.message || 'Giriş başarısız.' };
  if (res.user.role !== 'ADMIN') {
    await logoutUser();
    return { success: false, message: 'Bu portal yalnızca sistem yöneticisi (Admin) erişimine açıktır.' };
  }
  return { success: true, message: 'Yönetici girişi başarılı.', user: res.user, token: res.token };
}

/** Yönetici portalı için parolayı yeniden doğrular (eski sabit parola listesinin yerine). */
export async function verifyAdminPassword(password: string): Promise<{ success: boolean; message: string }> {
  const fbUser = auth.currentUser;
  const cur = getCurrentUser();
  if (!fbUser || !fbUser.email || !cur || cur.role !== 'ADMIN') {
    return { success: false, message: 'Bu alan yalnızca yönetici hesabıyla açılabilir.' };
  }
  try {
    await reauthenticateWithCredential(fbUser, EmailAuthProvider.credential(fbUser.email, password));
    return { success: true, message: 'Yönetici doğrulandı.' };
  } catch (err) {
    return { success: false, message: translateAuthError(err) };
  }
}

export async function registerUser(formData: {
  fullName: string;
  password: string;
  phone: string;
  email: string;
  company: string;
  jobTitle: string;
}): Promise<{ success: boolean; message: string; user?: AppUser }> {
  const email = (formData.email || '').trim().toLowerCase();
  if (!formData.fullName?.trim() || !email || !formData.password || !formData.phone?.trim()) {
    return { success: false, message: 'Lütfen zorunlu alanları doldurun.' };
  }
  if (formData.password.length < 8) return { success: false, message: 'Parola en az 8 karakter olmalıdır.' };

  try {
    const cred = await createUserWithEmailAndPassword(auth, email, formData.password);
    const now = new Date().toISOString();
    const data = {
      fullName: formData.fullName.trim(),
      email,
      phone: formData.phone.trim(),
      company: formData.company || '',
      jobTitle: formData.jobTitle || '',
      role: 'OPERATOR',
      status: 'PENDING',
      allowedModules: [],
      permissions: NO_PERMISSIONS,
      requiresPasswordChange: false,
      createdAt: now,
      updatedAt: now
    };
    await setDoc(doc(db, 'users', cred.user.uid), data);
    await sendEmailVerification(cred.user).catch(() => {});
    await signOut(auth);
    const isOwner = email === OWNER_EMAIL;
    return {
      success: true,
      message: isOwner
        ? 'Hesap oluşturuldu. E-postanıza gelen doğrulama bağlantısına tıklayın, ardından giriş yapın; yönetici yetkisi otomatik tanımlanır.'
        : 'Kayıt başvurunuz alındı. Yönetici onayından sonra giriş yapabilirsiniz. E-postanıza doğrulama bağlantısı da gönderildi.',
      user: profileFromDoc(cred.user.uid, data)
    };
  } catch (err) {
    return { success: false, message: translateAuthError(err) };
  }
}

export async function logoutUser(): Promise<void> {
  try { await signOut(auth); } catch {}
  triggerGlobalLogout();
}

export async function checkSessionMe(): Promise<AppUser | null> {
  await authReady;
  const fbUser = auth.currentUser;
  if (!fbUser) return null;
  try {
    const snap = await getDoc(doc(db, 'users', fbUser.uid));
    if (snap.exists()) {
      const profile = profileFromDoc(fbUser.uid, snap.data());
      setCurrentUser(profile);
      // v49c4: kalıcı oturumla açılışta da "son açılış" güncellenir (12 saatte bir; kural değişmez: lastLoginAt)
      const last = profile.lastLoginAt ? Date.parse(profile.lastLoginAt) : 0;
      if (!last || Date.now() - last > 12 * 3600000) updateDoc(doc(db, 'users', fbUser.uid), { lastLoginAt: new Date().toISOString() }).catch(() => {});
      return profile;
    }
  } catch {}
  return getCurrentUser();
}

export async function syncWithServer(): Promise<AppUser | null> {
  return checkSessionMe();
}

// -------------------------------------------------------------
// Parola işlemleri
// -------------------------------------------------------------
export async function changeUserPassword(
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; message: string; user?: AppUser }> {
  const fbUser = auth.currentUser;
  if (!fbUser || !fbUser.email) return { success: false, message: 'Oturum bulunamadı. Tekrar giriş yapın.' };
  if (!newPassword || newPassword.length < 8) return { success: false, message: 'Yeni parola en az 8 karakter olmalıdır.' };
  try {
    await reauthenticateWithCredential(fbUser, EmailAuthProvider.credential(fbUser.email, currentPassword));
    await updatePassword(fbUser, newPassword);
    await updateDoc(doc(db, 'users', fbUser.uid), { requiresPasswordChange: false, updatedAt: new Date().toISOString() }).catch(() => {});
    const cur = getCurrentUser();
    const user = cur ? { ...cur, requiresPasswordChange: false } : undefined;
    if (user) setCurrentUser(user);
    return { success: true, message: 'Parola güncellendi.', user };
  } catch (err) {
    return { success: false, message: translateAuthError(err) };
  }
}

export async function requestPasswordReset(email: string): Promise<{ success: boolean; message: string }> {
  const clean = (email || '').trim().toLowerCase();
  try {
    await sendPasswordResetEmail(auth, clean);
  } catch (err: any) {
    if (err?.code?.includes('invalid-email')) return { success: false, message: 'Geçersiz e-posta adresi.' };
    if (err?.code?.includes('network')) return { success: false, message: translateAuthError(err) };
  }
  // Hesabın var olup olmadığını açık etmemek için her durumda aynı mesaj
  return { success: true, message: 'Bu e-posta kayıtlıysa parola sıfırlama bağlantısı gönderildi. Gelen kutunuzu (ve spam klasörünü) kontrol edin.' };
}

/** Firebase'de sıfırlama e-postadaki bağlantıyla yapılır; kod girişi artık gerekmez. */
export async function resetPasswordWithCode(_email: string, _code: string, _newPassword: string): Promise<{ success: boolean; message: string }> {
  return { success: false, message: 'Parola sıfırlama, e-postanıza gönderilen bağlantı üzerinden yapılır.' };
}

async function sendResetForUser(userId: string): Promise<{ success: boolean; message: string }> {
  const target = getUsers().find(u => u.id === userId);
  if (!target?.email) return { success: false, message: 'Kullanıcının e-posta adresi bulunamadı.' };
  try {
    await sendPasswordResetEmail(auth, target.email);
    return { success: true, message: `${target.fullName} kullanıcısına (${target.email}) parola sıfırlama bağlantısı gönderildi.` };
  } catch (err) {
    return { success: false, message: translateAuthError(err) };
  }
}

/** Güvenlik: yönetici başkasının parolasını göremez/belirleyemez; kullanıcıya sıfırlama bağlantısı gider. */
export async function adminGenerateTempPassword(
  userId: string
): Promise<{ success: boolean; message: string; tempPassword?: string }> {
  return sendResetForUser(userId);
}

export async function adminResetUserPassword(userId: string, _newPassword?: string): Promise<{ success: boolean; message: string }> {
  return sendResetForUser(userId);
}

// -------------------------------------------------------------
// Kullanıcı yönetimi (Admin) — tümü Firestore üzerinden
// -------------------------------------------------------------
export function mergeUsers(serverUsers: AppUser[] = [], _localUsers: AppUser[] = []): AppUser[] {
  // Yeni mimaride sunucu (Firestore) tek kaynaktır; yerel kopyalar "dirilmez".
  return Array.isArray(serverUsers) ? serverUsers : [];
}

export async function fetchUsersList(): Promise<AppUser[]> {
  await authReady;
  const cur = getCurrentUser();
  try {
    if (cur?.role === 'ADMIN') {
      const snap = await getDocs(collection(db, 'users'));
      const users = snap.docs.map(d => profileFromDoc(d.id, d.data()));
      writeJson(STORAGE_USERS_KEY, users);
      return users;
    }
    return cur ? [cur] : [];
  } catch (err) {
    console.warn('[Auth] Kullanıcı listesi okunamadı:', (err as any)?.code || err);
    return getUsers();
  }
}

export async function restoreUsersFromServer(): Promise<AppUser[]> {
  return fetchUsersList();
}

export function getUsers(): AppUser[] {
  return readJson<AppUser[]>(STORAGE_USERS_KEY, []);
}

/** Eski sürüm uyumluluğu: yalnızca yerel önbelleği günceller. */
export function saveUsers(users: AppUser[]): void {
  writeJson(STORAGE_USERS_KEY, users);
}

async function adminUpdateUser(userId: string, patch: Record<string, any>): Promise<boolean> {
  try {
    const admin = getCurrentUser();
    await updateDoc(doc(db, 'users', userId), {
      ...patch,
      updatedAt: new Date().toISOString(),
      updatedBy: admin?.id || null
    });
    const roster = getUsers().map(u => (u.id === userId ? { ...u, ...patch } : u));
    saveUsers(roster);
    return true;
  } catch (err) {
    console.warn('[Auth] Kullanıcı güncellenemedi:', (err as any)?.code || err);
    return false;
  }
}

export async function updateUserPermissions(
  userId: string,
  allowedModules: string[],
  permissions: UserPermissions,
  _adminUser?: AppUser,
  newStatus?: UserStatus
): Promise<boolean> {
  const patch: Record<string, any> = { allowedModules, permissions };
  if (newStatus) {
    patch.status = newStatus;
    if (newStatus === 'APPROVED') {
      patch.approvedBy = getCurrentUser()?.id || null;
      patch.approvedAt = new Date().toISOString();
    }
  }
  const ok = await adminUpdateUser(userId, patch);
  if (ok) logActivity('USER_PERMISSIONS_UPDATED', `Kullanıcı yetkileri güncellendi: ${userId}${newStatus ? ` → ${newStatus}` : ''}`, 'ADMIN');
  return ok;
}

/** Rol değişikliği (yalnızca ADMIN; kurallar doğrular). Sahibin ADMIN rolü kurallar gereği alınamaz. */
export async function updateUserRole(userId: string, role: AppUser['role'], permissions?: UserPermissions): Promise<boolean> {
  const patch: Record<string, any> = { role };
  if (permissions) patch.permissions = permissions;
  const ok = await adminUpdateUser(userId, patch);
  if (ok) logActivity('USER_PERMISSIONS_UPDATED', `Kullanıcı rolü güncellendi: ${userId} → ${role}`, 'ADMIN');
  return ok;
}

export async function approveUser(
  userId: string,
  allowedModules: string[],
  permissions: UserPermissions,
  _adminUser?: AppUser
): Promise<boolean> {
  return updateUserPermissions(userId, allowedModules, permissions, undefined, 'APPROVED');
}

export async function makeUserPasifReader(userId: string, _adminUser?: AppUser): Promise<boolean> {
  return updateUserPermissions(
    userId,
    ['HARVEST', 'FIELD', 'MUZ', 'BADEM', 'LOJISTIK', 'AMBAR', 'FREEZE_DRY', 'EXPORT_SAMPLE', 'SALES', 'INCIDENT', 'GALLERY', 'ANALYTICS', 'MONTHLY_REPORT', 'REFERENCES'],
    { canEdit: false, canDelete: false, canClearDemo: false, canExport: true, canViewAll: true },
    undefined,
    'PASIF_READER'
  );
}

export async function revokeUserApproval(userId: string, _adminUser?: AppUser): Promise<boolean> {
  return updateUserPermissions(userId, ['HARVEST', 'FIELD'], { canEdit: false, canDelete: false, canClearDemo: false, canExport: true, canViewAll: true }, undefined, 'PASIF_READER');
}

export async function rejectUser(userId: string, _adminUser?: AppUser): Promise<boolean> {
  return updateUserPermissions(userId, [], NO_PERMISSIONS, undefined, 'DEACTIVATED');
}

export async function toggleUserActiveStatus(userId: string, currentStatus: UserStatus): Promise<boolean> {
  return adminUpdateUser(userId, { status: currentStatus === 'APPROVED' ? 'DEACTIVATED' : 'APPROVED' });
}

/**
 * Profili siler. Firebase Auth hesabı istemciden silinemez; ancak profili olmayan
 * hesap kurallar gereği hiçbir veriye erişemez. (Tam silme: Firebase Console → Authentication)
 */
export async function deleteUser(userId: string): Promise<boolean> {
  try {
    await deleteDoc(doc(db, 'users', userId));
    saveUsers(getUsers().filter(u => u.id !== userId));
    logActivity('USER_REJECTED', `Kullanıcı profili silindi: ${userId}`, 'ADMIN');
    return true;
  } catch (err) {
    console.warn('[Auth] Kullanıcı silinemedi:', (err as any)?.code || err);
    return false;
  }
}

export async function updateUserProfile(userId: string, fullName: string, phone: string): Promise<AppUser | null> {
  try {
    const patch = { fullName: fullName.trim(), phone: phone.trim(), updatedAt: new Date().toISOString() };
    await updateDoc(doc(db, 'users', userId), patch);
    const cur = getCurrentUser();
    if (cur && cur.id === userId) {
      const updated = { ...cur, ...patch };
      setCurrentUser(updated);
      return updated;
    }
    const target = getUsers().find(u => u.id === userId);
    return target ? { ...target, ...patch } : null;
  } catch {
    return null;
  }
}

// -------------------------------------------------------------
// Denetim izi (Audit trail) — Firestore 'activityLogs' (yalnızca ekleme)
// -------------------------------------------------------------
export async function fetchActivityLogs(): Promise<ActivityLogItem[]> {
  try {
    const snap = await getDocs(query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'), limit(500)));
    const logs = snap.docs.map(d => ({ ...(d.data() as ActivityLogItem), id: d.id }));
    writeJson(STORAGE_ACTIVITY_LOGS_KEY, logs);
    return logs;
  } catch {
    return getActivityLogs();
  }
}

export function getActivityLogs(): ActivityLogItem[] {
  return readJson<ActivityLogItem[]>(STORAGE_ACTIVITY_LOGS_KEY, []);
}

/** Yalnızca yerel önbelleği temizler; merkezi denetim izi silinemez (izlenebilirlik gereği). */
export function clearActivityLogs(): void {
  writeJson(STORAGE_ACTIVITY_LOGS_KEY, []);
}

export function logActivity(arg1: any, arg2?: any, arg3?: any, arg4?: any, arg5?: any): void {
  try {
    let action: ActivityActionType = 'UPDATE_RECORD';
    let details = '';
    let module: string | undefined;
    let refId: string | undefined;

    if (typeof arg1 === 'object' && arg1 !== null && ('id' in arg1 || 'fullName' in arg1)) {
      action = arg2 as ActivityActionType;
      module = arg3;
      details = typeof arg4 === 'string' ? arg4 : JSON.stringify(arg4 || '');
      refId = arg5;
    } else {
      action = arg1 as ActivityActionType;
      details = typeof arg2 === 'string' ? arg2 : JSON.stringify(arg2 || '');
      module = arg3;
      refId = arg4;
    }

    const fbUser = auth.currentUser;
    if (!fbUser) return; // Oturumsuz log yazılmaz (kurallar zaten reddeder)
    const user = getCurrentUser();
    const id = `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const logItem: ActivityLogItem = {
      id,
      timestamp: new Date().toISOString(),
      userId: fbUser.uid,
      userName: user?.fullName || fbUser.email || '',
      userEmail: fbUser.email || '',
      company: user?.company || '',
      jobTitle: user?.jobTitle || '',
      action,
      module,
      refId,
      details
    };

    setDoc(doc(db, 'activityLogs', id), { ...logItem, serverTime: serverTimestamp() }).catch(() => {});
    writeJson(STORAGE_ACTIVITY_LOGS_KEY, [logItem, ...getActivityLogs()].slice(0, 500));
  } catch (e) {
    console.warn('logActivity guarded error:', e);
  }
}

// -------------------------------------------------------------
// Yetki yardımcıları (arayüz için; asıl kontrol firestore.rules'ta)
// -------------------------------------------------------------
export function isUserAuthorizedForModule(user: AppUser | null, moduleKey: string): boolean {
  if (!user) return false;
  if (user.role === 'ADMIN') return true;
  if (user.status === 'DEACTIVATED' || user.status === 'REJECTED') return false;
  if (user.status === 'PASIF_READER') return true;
  if (user.status !== 'APPROVED') return false;
  const allowed = user.allowedModules || [];
  if (allowed.includes('ALL')) return true;
  const norm = moduleKey === 'HASAT' ? 'HARVEST' : moduleKey === 'SAHA_TEST' ? 'FIELD' : moduleKey;
  return allowed.includes(norm);
}

export function canUserPerform(user: AppUser | null, action: 'edit' | 'delete' | 'clearDemo' | 'export'): boolean {
  if (!user) return false;
  if (user.role === 'ADMIN') return true;
  if (user.status === 'PASIF_READER') return action === 'export' ? (user.permissions?.canExport ?? true) : false;
  if (user.status !== 'APPROVED') return false;
  if (action === 'edit') return !!user.permissions?.canEdit;
  if (action === 'delete') return !!user.permissions?.canDelete;
  if (action === 'clearDemo') return !!user.permissions?.canClearDemo;
  if (action === 'export') return user.permissions?.canExport ?? true;
  return false;
}

// -------------------------------------------------------------
// Otomatik eşitleme — artık gerçek zamanlı dinleyiciler (polling yok)
// -------------------------------------------------------------
export async function triggerManualUserAndNotifSync(): Promise<void> {
  try {
    const users = await fetchUsersList();
    emitUsers(users);
    const cur = getCurrentUser();
    if (cur) await syncNotificationsWithServer(cur.id);
  } catch {}
}

export function startAutoSync(): void {
  const cur = getCurrentUser();
  if (cur) startNotificationsListener(cur.id);
}

export function stopAutoSync(): void {
  stopNotificationsListener();
}
