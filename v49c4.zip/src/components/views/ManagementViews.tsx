import React, { useEffect, useMemo, useState } from 'react';
import { ChevronRight, FileText, Thermometer, Layers, BarChart3, FileSpreadsheet, CalendarRange, ShieldAlert, Users, MapPin, ScrollText, Download, AlertTriangle, Snowflake } from 'lucide-react';
import { PageHeader } from '../ui';
import type { AmbarRecord, BademRecord, ExportSampleRecord, FieldRecord, FreezeDryRecord, HarvestRecord, IncidentRecord, LojistikRecord, MuzRecord, ReferenceItem, SalesRecord } from '../../types';
import type { ActivityLogItem, AppUser } from '../../types/auth';
import { KNOWN_COMPANIES } from '../../types/auth';
import { fetchActivityLogs, getActivityLogs, getUsers, fetchUsersList } from '../../utils/authService';
import { useLocationProfiles, getProfiles } from '../../services/locationProfiles';
import { calibrationStatus } from '../../config/calibrationRules';
import { storedLots, summarizeDepots, unknownDepots, useRoomChecks, tons, fmtC } from '../../services/depots';
import { analyze, NO_NAME } from '../../services/analytics';
import { buildLot } from '../../services/lotTests';

/** v49c3 — Rapor merkezi · Yönetici masası · Yönetim analizi (ortak veri girişi) */
export interface MgmtData {
  references: ReferenceItem[]; harvestRecords: HarvestRecord[]; fieldRecords: FieldRecord[]; muzRecords: MuzRecord[]; bademRecords: BademRecord[];
  ambarRecords: AmbarRecord[]; lojistikRecords: LojistikRecord[]; salesRecords: SalesRecord[]; exportSampleRecords: ExportSampleRecord[];
  freezeDryRecords: FreezeDryRecord[]; incidentRecords: IncidentRecord[];
}
type Period = 'WEEK' | 'MONTH' | 'SEASON';
const fromOf = (p: Period) => {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  if (p === 'WEEK') d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  else if (p === 'MONTH') d.setDate(1);
  else { d.setMonth(0); d.setDate(1); }
  return d.toISOString().slice(0, 10);
};
const inR = (iso: string | undefined, from: string) => !!iso && iso.slice(0, 10) >= from;
const Seg = ({ v, set }: { v: Period; set: (p: Period) => void }) => (
  <div className="flex gap-1.5">{([['WEEK', 'Bu hafta'], ['MONTH', 'Bu ay'], ['SEASON', 'Bu yıl']] as const).map(([k, l]) => (
    <button key={k} type="button" onClick={() => set(k)} className={`px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${v === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{l}</button>
  ))}</div>
);
const Row = ({ icon, title, sub, onClick, right }: { icon: React.ReactNode; title: string; sub?: string; onClick?: () => void; right?: React.ReactNode }) => (
  <li><button type="button" onClick={onClick} className="w-full flex items-center justify-between gap-3 min-h-[52px] py-2 text-left cursor-pointer">
    <span className="flex items-center gap-3 min-w-0"><span className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0">{icon}</span>
      <span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white truncate">{title}</span>{sub && <span className="block text-xs text-slate-500 truncate">{sub}</span>}</span></span>
    {right ?? <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
  </button></li>
);
const Box = ({ children, title, right }: { children: React.ReactNode; title?: string; right?: React.ReactNode }) => (
  <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
    {title && <div className="flex items-center justify-between mb-1"><h2 className="text-sm font-bold text-slate-900 dark:text-white">{title}</h2>{right}</div>}
    {children}
  </section>
);
function downloadCsv(name: string, rows: (string | number | undefined)[][]) {
  const csv = '﻿' + rows.map(r => r.map(c => { const s = String(c ?? ''); return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(';')).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/* ───────────── Rapor merkezi ───────────── */
export function ReportsHome(p: MgmtData & { onOpen: (view: string, tab?: string) => void; onOpenDepots: () => void; onExportExcel: () => void; onBack: () => void }) {
  const [period, setPeriod] = useState<Period>('WEEK');
  const from = fromOf(period);
  useLocationProfiles();
  const checks = useRoomChecks();
  const k = useMemo(() => {
    const harvest = p.harvestRecords.filter(h => inR(h.recordDate || h.timestamp, from)).reduce((s, h) => s + (Number(h.dailyTotalKg) || 0), 0);
    const ship = p.lojistikRecords.filter(l => inR(l.shipmentDate, from)).reduce((s, l) => s + (Number(l.weightKg) || 0), 0);
    // testler: tüm partilerin testleri, test tarihine göre, her test bir kez (parti sayfasıyla aynı sonuç)
    const seen = new Map<string, string>();
    for (const r of p.references) { if (r.archived) continue; const L = buildLot(r.refId, p); if (!L) continue;
      for (const t of L.tests) if (inR(t.date, from) && t.verdict !== 'none' && !seen.has(t.key)) seen.set(t.key, t.verdict); }
    const tests = seen.size, bad = [...seen.values()].filter(v => v === 'bad' || v === 'warn').length;
    const depots = summarizeDepots(storedLots(p), checks);
    const setOut = depots.reduce((s, d) => s + d.bad, 0);
    const akts = p.incidentRecords.filter(i => inR(i.incidentDate || i.timestamp, from)).length;
    return { harvest, ship, tests, bad, setOut, akts };
  }, [p, from, checks]);
  const roomCsv = () => downloadCsv(`oda_turlari_${from}.csv`, [['Tarih', 'Depo', 'Oda', 'Set alt', 'Set üst', 'Monitör °C', 'Cihaz °C', 'Meyve °C', 'Nem %', 'Durum', '1-MCP', 'Not', 'Kontrol eden'],
    ...checks.filter(c => inR(c.at, from)).flatMap(c => c.entries.map(e => [c.at.slice(0, 16).replace('T', ' '), c.warehouse, e.roomName, e.setMinC, e.setMaxC, e.monitorC, e.deviceC, e.fruitC, e.rhPercent, e.state, e.mcp, e.note, c.by]))]);
  const tiles: [string, string, string, string, () => void][] = [
    ['Hasat', tons(k.harvest), 'kayıtlı hasat', 'e', () => p.onOpen('REPORT_CENTER', 'orchards')],
    ['Sevk', tons(k.ship), 'lojistik kaydı', 's', () => p.onOpen('REPORT_CENTER', 'cold')],
    ['Dikkat / uygun değil', k.tests ? `%${Math.round((k.bad / k.tests) * 100)}` : '—', `${k.bad} / ${k.tests} test`, k.bad ? 'a' : 's', () => p.onOpen('REPORT_CENTER', 'quality')],
    ['Set dışı oda', String(k.setOut), `${k.akts} akt açıldı`, k.setOut ? 'r' : 's', p.onOpenDepots],
  ];
  const tone: Record<string, string> = { e: 'border-slate-200', s: 'border-slate-200', a: 'border-amber-300', r: 'border-rose-300' };
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={p.onBack} title="Rapor merkezi" subtitle="Göstergeye dokun → raporu aç" />
      <Seg v={period} set={setPeriod} />
      <div className="grid grid-cols-2 gap-2">{tiles.map(([a, b, c, t, f]) => (
        <button key={a} type="button" onClick={f} className={`text-left rounded-2xl border bg-white dark:bg-slate-900 p-3 cursor-pointer ${tone[t]}`}>
          <div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div>
        </button>))}
      </div>
      <Box title="Hazır raporlar">
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
          <Row icon={<BarChart3 className="w-4 h-4" />} title="Durum ve hedefler" sub="Aşamalar, plan · gerçekleşen" onClick={() => p.onOpen('REPORT_CENTER', 'status')} />
          <Row icon={<MapPin className="w-4 h-4" />} title="Bahçeler" sub="Bahçe ve çeşit bazında hasat, test" onClick={() => p.onOpen('REPORT_CENTER', 'orchards')} />
          <Row icon={<Snowflake className="w-4 h-4" />} title="Soğuk zincir" sub="Ön soğutma, depo, sevk sıcaklıkları" onClick={() => p.onOpen('REPORT_CENTER', 'cold')} />
          <Row icon={<FileText className="w-4 h-4" />} title="Kalite" sub="Test sonuçları ve sınıflar" onClick={() => p.onOpen('REPORT_CENTER', 'quality')} />
          <Row icon={<Layers className="w-4 h-4" />} title="Parti izlenebilirlik" sub="Bir RefID: hasattan sevke" onClick={() => p.onOpen('LOTS')} />
          <Row icon={<CalendarRange className="w-4 h-4" />} title="Aylık rapor (PDF)" sub="Aylık kalite raporu" onClick={() => p.onOpen('MONTHLY_REPORT')} />
          <Row icon={<Thermometer className="w-4 h-4" />} title="Oda turları (Excel)" sub={`${checks.filter(c => inR(c.at, from)).length} tur · seçili dönem`} onClick={roomCsv} right={<Download className="w-4 h-4 text-slate-500" />} />
          <Row icon={<FileSpreadsheet className="w-4 h-4" />} title="Partiler (Excel)" sub="Tüm partiler ve testleri" onClick={p.onExportExcel} right={<Download className="w-4 h-4 text-slate-500" />} />
        </ul>
      </Box>
    </div>
  );
}

/* ───────────── Yönetici masası ───────────── */
const BACKUP_KEY = 'miwe_last_backup';
/** v49c4: tüm kayıtlar tek JSON dosyası (geri yükleme için saklanır) */
function downloadBackup(p: MgmtData, users: AppUser[], roomChecks: unknown[]) {
  const data = { app: 'MIWE HIL', version: 'v49c4', at: new Date().toISOString(), ...p, roomChecks, profiles: getProfiles(),
    users: users.map(u => ({ id: u.id, fullName: u.fullName, email: u.email, role: u.role, status: u.status, company: u.company, lastLoginAt: u.lastLoginAt })) };
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
  a.download = `miwe_yedek_${data.at.slice(0, 10)}.json`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
export function AdminDesk(p: MgmtData & { currentUser: AppUser | null; onOpenUsers: () => void; onOpenProfiles: () => void; onOpen: (view: string) => void; onBack: () => void }) {
  const [users, setUsers] = useState<AppUser[]>(() => getUsers());
  useEffect(() => { fetchUsersList().then(u => u.length && setUsers(u)).catch(() => {}); }, []);
  useLocationProfiles();
  const devices = useLocationProfiles('DEVICE');
  const checks = useRoomChecks();
  const [lastBackup, setLastBackup] = useState<string | null>(() => { try { return localStorage.getItem(BACKUP_KEY); } catch { return null; } });
  const [showAllLogins, setShowAllLogins] = useState(false);
  if (p.currentUser?.role !== 'ADMIN') return <div className="max-w-3xl mx-auto px-3 py-6"><PageHeader onBack={p.onBack} title="Yönetici masası" /><p className="text-sm text-slate-600 mt-3">Bu sayfa yalnız yöneticiye açıktır.</p></div>;
  const pending = users.filter(u => u.status === 'PENDING');
  const roles: [string, number][] = [['Yönetici', users.filter(u => u.role === 'ADMIN').length], ['Müdür', users.filter(u => u.role === 'MANAGER').length], ['Kalite kontrolcü', users.filter(u => u.role === 'QUALITY_INSPECTOR').length], ['Operatör', users.filter(u => u.role === 'OPERATOR').length], ['Görüntüleme', users.filter(u => u.role === 'VIEWER').length]];
  const noDept = users.filter(u => u.status === 'APPROVED' && !(KNOWN_COMPANIES as readonly string[]).includes(u.company)).length;
  const demo = unknownDepots(storedLots(p));
  const testJunk = p.references.filter(r => /^(sdf|test|deneme|asd)/i.test(String(r.orchard || r.product || ''))).length;
  const lateDev = devices.filter(d => { const s = calibrationStatus(d.fields); return s.overdue || s.failed; }).length;
  const health: [string, number, string][] = [
    ['Bölümü yeni listede olmayan kullanıcı', noDept, 'Kullanıcılar ekranından bölüm seçin'],
    ['Profili olmayan depo adındaki parti', demo.reduce((s, d) => s + d.lots.length, 0), demo.map(d => d.name.slice(0, 24)).join(', ')],
    ['Deneme görünümlü kayıt', testJunk, 'sdf, test, deneme ile başlayan'],
    ['Kalibrasyonu geçen cihaz', lateDev, 'Profiller › cihaz'],
    ['Bugün oda turu girilmemiş depo', 0, ''],
  ];
  health[4][1] = summarizeDepots(storedLots(p), checks).filter(d => d.rooms.length >= 3 && d.checkedToday === 0).length;
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={p.onBack} title="Yönetici masası" subtitle="Onay, kişiler, veri sağlığı" />
      <Box title={`Onay bekleyen kullanıcı · ${pending.length}`}>
        {pending.length === 0 ? <p className="text-sm text-slate-500 py-1">Bekleyen yok.</p> : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{pending.slice(0, 6).map(u => <Row key={u.id} icon={<Users className="w-4 h-4" />} title={u.fullName} sub={`${u.company || 'bölüm yok'} · ${u.email}`} onClick={p.onOpenUsers} right={<span className="text-xs font-semibold text-teal-700">Onayla ›</span>} />)}</ul>)}
      </Box>
      <Box title="Kişiler ve roller" right={<button type="button" onClick={p.onOpenUsers} className="text-xs font-semibold text-teal-700 cursor-pointer">Yönet ›</button>}>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{roles.map(([a, b]) => <li key={a} className="flex justify-between py-2 text-sm"><span>{a}</span><span className="font-semibold tabular-nums">{b}</span></li>)}</ul>
      </Box>
      <Box title="Giriş durumu" right={<span className="text-[11px] text-slate-500">son açılış</span>}>
        {(() => {
          const act = users.filter(u => u.status !== 'PENDING' && u.status !== 'REJECTED');
          const ago = (iso?: string) => iso ? Math.floor((Date.now() - Date.parse(iso)) / 86400000) : null;
          const rows = [...act].sort((a, b) => (Date.parse(b.lastLoginAt || '') || 0) - (Date.parse(a.lastLoginAt || '') || 0));
          const never = rows.filter(u => !u.lastLoginAt).length, week = rows.filter(u => { const d = ago(u.lastLoginAt); return d !== null && d <= 7; }).length;
          return (<>
            <div className="grid grid-cols-3 gap-2 py-1">{([['Son 7 gün', week, 'text-emerald-700'], ['7 günden eski', rows.length - week - never, 'text-amber-700'], ['Hiç açmadı', never, 'text-rose-700']] as const).map(([l, v, c]) => (
              <div key={l} className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2 text-center"><div className={`text-lg font-bold tabular-nums ${c}`}>{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>))}</div>
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">{rows.slice(0, showAllLogins ? 99 : 5).map(u => { const d = ago(u.lastLoginAt); return (
              <li key={u.id} className="flex items-center justify-between gap-3 py-2"><span className="min-w-0"><span className="block text-sm truncate">{u.fullName}</span><span className="block text-[11px] text-slate-500 truncate">{u.company || '—'}</span></span>
                <span className={`text-xs tabular-nums shrink-0 ${d === null ? 'text-rose-700 font-semibold' : d > 7 ? 'text-amber-700' : 'text-slate-600'}`}>{d === null ? 'hiç' : d === 0 ? 'bugün' : `${d} gün önce`}</span></li>); })}</ul>
            {rows.length > 5 && <button type="button" onClick={() => setShowAllLogins(v => !v)} className="text-xs font-semibold text-teal-700 py-1 cursor-pointer">{showAllLogins ? 'Daha az' : `Tümü (${rows.length})`}</button>}
          </>);
        })()}
      </Box>
      <Box title="Yedek">
        <div className="flex items-center justify-between gap-3 py-1">
          <span className="min-w-0"><span className="block text-sm">Tüm kayıtlar tek dosya</span><span className={`block text-[11px] ${!lastBackup || Date.now() - Date.parse(lastBackup) > 7 * 86400000 ? 'text-amber-700' : 'text-slate-500'}`}>{lastBackup ? `Son yedek ${new Date(lastBackup).toLocaleDateString('tr-TR')} · haftada bir önerilir` : 'Henüz yedek alınmadı · haftada bir önerilir'}</span></span>
          <button type="button" onClick={() => { downloadBackup(p, users, checks); const now = new Date().toISOString(); try { localStorage.setItem(BACKUP_KEY, now); } catch { /* yoksay */ } setLastBackup(now); }}
            className="shrink-0 inline-flex items-center gap-1.5 px-3 min-h-[40px] rounded-xl bg-teal-700 text-white text-sm font-semibold cursor-pointer"><Download className="w-4 h-4" />İndir</button>
        </div>
      </Box>
      <Box title="Veri sağlığı">
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{health.map(([a, n, h]) => (
          <li key={a} className="flex items-center justify-between gap-3 py-2"><span className="min-w-0"><span className="block text-sm">{a}</span>{h && n > 0 && <span className="block text-[11px] text-slate-500 truncate">{h}</span>}</span>
            <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${n ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-emerald-50 text-emerald-800 border-emerald-200'}`}>{n}</span></li>))}</ul>
      </Box>
      <Box>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
          <Row icon={<BarChart3 className="w-4 h-4" />} title="Yönetim analizi" sub="Bölüm, bahçe ve kişi bazında" onClick={() => p.onOpen('MGMT_ANALYSIS')} />
          <Row icon={<ScrollText className="w-4 h-4" />} title="Denetim izi" sub="Kim, neyi, ne zaman yaptı" onClick={() => p.onOpen('AUDIT_TRAIL')} />
          <Row icon={<MapPin className="w-4 h-4" />} title="Profiller" sub="Bahçe, sera, depo, oda, cihaz" onClick={p.onOpenProfiles} />
        </ul>
      </Box>
    </div>
  );
}

/* ───────────── Yönetim analizi ───────────── */
export function MgmtAnalysis(p: MgmtData & { currentUser: AppUser | null; onBack: () => void }) {
  const [period, setPeriod] = useState<Period>('MONTH');
  const [tab, setTab] = useState<'PLACE' | 'PEOPLE' | 'CRIT'>('PLACE');
  const [logs, setLogs] = useState<ActivityLogItem[]>(() => getActivityLogs());
  const [users, setUsers] = useState<AppUser[]>(() => getUsers());
  useEffect(() => { fetchActivityLogs().then(l => l.length && setLogs(l)).catch(() => {}); fetchUsersList().then(u => u.length && setUsers(u)).catch(() => {}); }, []);
  useLocationProfiles();
  const roomChecks = useRoomChecks();
  const from = fromOf(period);
  const a = useMemo(() => analyze({ ...p, logs, users, roomChecks }, from), [p, logs, users, roomChecks, from]);
  if (p.currentUser?.role !== 'ADMIN') return <div className="max-w-3xl mx-auto px-3 py-6"><PageHeader onBack={p.onBack} title="Yönetim analizi" /><p className="text-sm text-slate-600 mt-3">Bu sayfa yalnız yöneticiye açıktır.</p></div>;
  const pill = (n: number) => n >= 85 ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : n >= 65 ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-rose-50 text-rose-800 border-rose-200';
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={p.onBack} title="Yönetim analizi" subtitle="Yalnız yönetici görür" />
      <Seg v={period} set={setPeriod} />
      <div className="flex gap-1.5">{([['PLACE', 'Bahçe ve depo'], ['PEOPLE', 'Kişiler'], ['CRIT', 'Kritik noktalar']] as const).map(([k, l]) => (
        <button key={k} type="button" onClick={() => setTab(k)} className={`px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${tab === k ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900'}`}>{l}</button>))}</div>
      {tab === 'PLACE' && (
        <Box>
          <div className="grid grid-cols-[minmax(0,1fr)_48px_36px_52px_46px] gap-1 text-[10px] font-semibold text-slate-500 py-1.5 border-b border-slate-100 dark:border-slate-800"><span>Yer</span><span className="text-right">Hareket</span><span className="text-right">Akt</span><span className="text-right">Ton</span><span className="text-right">Puan</span></div>
          {a.places.length === 0 && <p className="text-sm text-slate-500 py-3">Bu dönemde kayıt yok.</p>}
          {a.places.map(r => (
            <div key={r.kind + r.name} className="grid grid-cols-[minmax(0,1fr)_48px_36px_52px_46px] gap-1 items-center py-2 border-b border-slate-100 dark:border-slate-800 last:border-0 tabular-nums">
              <span className="min-w-0"><span className="block text-sm font-semibold leading-snug break-words line-clamp-2">{r.name}</span><span className="block text-[10px] text-slate-500">{r.kind}{r.tests ? ` · ${r.ok}/${r.tests} test uygun` : ''}</span></span>
              <span className="text-right text-sm">{r.moves}</span><span className={`text-right text-sm ${r.akts ? 'text-rose-700 font-bold' : ''}`}>{r.akts}</span>
              <span className="text-right text-sm">{r.kg ? (r.kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—'}</span>
              <span className="text-right">{r.kind === 'Depo' ? <span className="text-[11px] text-slate-400">—</span> : <span className={`text-[11px] font-semibold px-1.5 py-0.5 rounded-full border ${pill(r.score)}`}>{r.score}</span>}</span>
            </div>))}
          <p className="text-[11px] text-slate-500 mt-2">Puan (100) = test uygunluğu 55 · testli parti oranı 25 · akt sıklığı 20. Depolar için hareket sayılır, puan verilmez.</p>
        </Box>
      )}
      {tab === 'PEOPLE' && (
        <Box>
          <div className="grid grid-cols-[minmax(0,1fr)_44px_44px_44px] gap-1 text-[10px] font-semibold text-slate-500 py-1.5 border-b border-slate-100 dark:border-slate-800"><span>Kişi · bölüm</span><span className="text-right">Kayıt</span><span className="text-right">Düzelt.</span><span className="text-right">Silme</span></div>
          {a.people.length === 0 && <p className="text-sm text-slate-500 py-3">Bu dönemde kayıt yok.</p>}
          {a.people.map(r => (
            <div key={r.name} className="py-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
              <div className="grid grid-cols-[minmax(0,1fr)_44px_44px_44px] gap-1 items-center tabular-nums">
                <span className="min-w-0"><span className={`block text-sm font-semibold leading-snug break-words ${r.name === NO_NAME ? 'text-amber-800' : ''}`}>{r.name}</span><span className="block text-[10px] text-slate-500 break-words">{r.dept}</span></span>
                <span className="text-right text-sm">{r.records}</span><span className="text-right text-sm">{r.edits}</span><span className={`text-right text-sm ${r.deletes ? 'text-rose-700 font-bold' : ''}`}>{r.deletes}</span>
              </div>
              {r.last && <div className="text-[11px] text-slate-400 truncate">son: {new Date(r.last).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}{r.lastWhat ? ` · ${r.lastWhat}` : ''}</div>}
            </div>))}
          <p className="text-[11px] text-slate-500 mt-2">Amaç ceza değil: hangi bölümün desteğe ihtiyacı olduğunu görmek. "Ad yazılmamış" satırı, kişi yerine görev adı (Saha personeli, Depo kabul uzmanı…) yazılan kayıtlardır.</p>
        </Box>
      )}
      {tab === 'CRIT' && (
        <Box title="Tekrarlanan kritik noktalar">
          {a.critical.length === 0 && <p className="text-sm text-slate-500 py-2">Bu dönemde tekrarlanan sorun yok.</p>}
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{a.critical.map((c, i) => (
            <li key={i} className="flex items-center justify-between gap-3 py-2.5">
              <span className="flex items-center gap-3 min-w-0"><span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${c.level === 'high' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-800'}`}>{c.label.startsWith('Akt') ? <ShieldAlert className="w-4 h-4" /> : c.label.startsWith('Oda') || c.label.startsWith('Monitör') ? <Thermometer className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}</span>
                <span className="min-w-0"><span className="block text-sm font-semibold truncate">{c.label}</span>{c.where && <span className="block text-xs text-slate-500 truncate">{c.where}</span>}</span></span>
              <span className="text-sm font-bold tabular-nums">{c.count}×</span>
            </li>))}</ul>
        </Box>
      )}
    </div>
  );
}

export { fmtC };
