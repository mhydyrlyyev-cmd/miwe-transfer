import React, { useMemo } from 'react';
import { Snowflake, Sprout, Flower2, MapPin, RefreshCw } from 'lucide-react';
import { PageHeader } from '../ui';
import { useLocationProfiles } from '../../services/locationProfiles';
import { useOrchardClimate, CLIMATE_LIMITS, type OrchardClimate } from '../../services/agroClimate';

/** v49c4 — Bahçe iklimi: gün-derece, soğuklama saati, çiçek donu, geçen yılla karşılaştırma */
const dm = (s?: string) => (s ? s.split('-').reverse().slice(0, 2).join('.') : '—');
const n0 = (v?: number) => (v === undefined ? '—' : Math.round(v).toLocaleString('tr-TR'));
const delta = (a?: number, b?: number) => {
  if (a === undefined || !b) return null;
  const p = Math.round(((a - b) / b) * 100);
  return <span className={`text-[11px] font-semibold ${p >= 0 ? 'text-emerald-700' : 'text-amber-700'}`}>{p >= 0 ? '+' : ''}{p}%</span>;
};

function Bars({ now, last, max }: { now: number; last: number; max: number }) {
  const w = (v: number) => `${Math.max(2, Math.min(100, (v / (max || 1)) * 100))}%`;
  return (
    <div className="space-y-1 mt-1.5" aria-hidden>
      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-2 rounded-full bg-teal-600" style={{ width: w(now) }} /></div>
      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-2 rounded-full bg-slate-400" style={{ width: w(last) }} /></div>
    </div>
  );
}

function Card({ c, onOpenProfiles }: { c: OrchardClimate; onOpenProfiles: () => void }) {
  const fr = { crit: 'bg-rose-50 text-rose-800 border-rose-200', warn: 'bg-amber-50 text-amber-800 border-amber-200', none: 'bg-emerald-50 text-emerald-800 border-emerald-200', off: 'bg-slate-50 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700' }[c.frost.level];
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 min-w-0"><MapPin className="w-4 h-4 text-teal-700 shrink-0" /><span className="truncate">{c.name}</span></h2>
        {c.bloom && <span className="text-[11px] text-slate-500 shrink-0">çiçeklenme {dm(c.bloom)}</span>}
      </div>
      {c.error ? <p className="text-sm text-amber-800">{c.error}</p> : (<>
        {c.gdd !== undefined && (
          <div>
            <div className="flex items-baseline justify-between"><span className="text-xs text-slate-500 flex items-center gap-1"><Sprout className="w-3.5 h-3.5" />Gün-derece (taban {c.baseC} °C)</span>{delta(c.gdd, c.gddLast)}</div>
            <div className="flex items-baseline gap-2"><span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{n0(c.gdd)}</span><span className="text-xs text-slate-500">geçen yıl {n0(c.gddLast)}</span></div>
            <Bars now={c.gdd} last={c.gddLast || 0} max={Math.max(c.gdd, c.gddLast || 0, c.harvestGdd || 0)} />
            {c.harvestGdd && <p className="text-xs mt-1.5 text-slate-700 dark:text-slate-300">Hasat hedefi {n0(c.harvestGdd)} · {c.harvestReached ? <b>hedefe {dm(c.harvestReached)} ulaştı</b> : c.harvestEta ? <b>tahmini {dm(c.harvestEta)}</b> : 'tahmin için veri az'}</p>}
          </div>
        )}
        <div>
          <div className="flex items-baseline justify-between"><span className="text-xs text-slate-500 flex items-center gap-1"><Snowflake className="w-3.5 h-3.5" />Soğuklama saati ({dm(c.chillStart)}'den beri)</span>{delta(c.chill, c.chillLast)}</div>
          <div className="flex items-baseline gap-2"><span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{n0(c.chill)}</span><span className="text-xs text-slate-500">geçen yıl aynı gün {n0(c.chillLast)}</span></div>
          <Bars now={c.chill} last={c.chillLast} max={Math.max(c.chill, c.chillLast)} />
        </div>
        <div className={`text-xs rounded-xl border px-3 py-2 flex items-center gap-2 ${fr}`}><Flower2 className="w-4 h-4 shrink-0" />{c.frost.text}</div>
        {c.forecast.length > 0 && (
          <div className="grid grid-cols-7 gap-1 text-center">{c.forecast.slice(0, 7).map(d => (
            <div key={d.date} className="rounded-lg bg-slate-50 dark:bg-slate-800 py-1">
              <div className="text-[10px] text-slate-500">{new Date(`${d.date}T00:00:00`).toLocaleDateString('tr-TR', { weekday: 'short' })}</div>
              <div className="text-[11px] font-semibold tabular-nums">{Math.round(d.tMax)}°</div>
              <div className={`text-[11px] tabular-nums ${d.tMin <= 0 ? 'text-rose-700 font-bold' : 'text-slate-500'}`}>{Math.round(d.tMin)}°</div>
            </div>))}
          </div>
        )}
      </>)}
      {c.missing.length > 0 && (
        <button type="button" onClick={onOpenProfiles} className="w-full text-left text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 cursor-pointer">
          Eksik: {c.missing.join(', ')} → Profiller › Bahçe
        </button>
      )}
    </section>
  );
}

export default function ClimateView({ onBack, onOpenProfiles }: { onBack: () => void; onOpenProfiles: () => void }) {
  const orchards = useLocationProfiles('ORCHARD');
  const points = useMemo(() => orchards.map(o => ({ name: o.name, lat: Number(o.fields?.lat) || undefined, lon: Number(o.fields?.lon) || undefined, fields: o.fields || {} })), [orchards]);
  const { data, loading } = useOrchardClimate(points);
  const noCoord = points.filter(p => p.lat === undefined || p.lon === undefined);
  const list = points.map(p => data[p.name]).filter(Boolean) as OrchardClimate[];
  const crit = list.filter(c => c.frost.level === 'crit' || c.frost.level === 'warn');
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={onBack} title="Bahçe iklimi" subtitle="Gün-derece · soğuklama · çiçek donu" />
      {crit.length > 0 && <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 font-semibold">{crit.length} bahçede çiçek donu uyarısı</div>}
      {loading && list.length === 0 && <p className="text-sm text-slate-500 flex items-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />İklim verisi yükleniyor…</p>}
      {list.map(c => <Card key={c.name} c={c} onOpenProfiles={onOpenProfiles} />)}
      {noCoord.length > 0 && (
        <button type="button" onClick={onOpenProfiles} className="w-full text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 cursor-pointer">
          <span className="block text-sm font-semibold">Koordinatı olmayan {noCoord.length} bahçe</span>
          <span className="block text-xs text-slate-500">{noCoord.slice(0, 6).map(p => p.name).join(', ')} — Profiller'de enlem / boylam girin</span>
        </button>
      )}
      <p className="text-[11px] text-slate-500 px-1">Kaynak: Open-Meteo (geçmiş ölçüm + 7 gün tahmin). Soğuklama: {CLIMATE_LIMITS.chillLowC}–{CLIMATE_LIMITS.chillHighC} °C arası saat. Çiçek donu: çiçeklenme −{CLIMATE_LIMITS.bloomBefore} / +{CLIMATE_LIMITS.bloomAfter} gün içinde Tmin ≤ {CLIMATE_LIMITS.bloomWarnC} °C uyarı, ≤ {CLIMATE_LIMITS.bloomCritC} °C kritik (iç hedef). Mavi çubuk bu yıl, gri geçen yıl.</p>
    </div>
  );
}
