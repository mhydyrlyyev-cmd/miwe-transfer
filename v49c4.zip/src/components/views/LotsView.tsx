import React, { useMemo, useState } from 'react';
import { Search, QrCode, MoreHorizontal, ChevronRight, FileDown, Pencil, Plus, FlaskConical, Truck, Warehouse, ShieldAlert, Snowflake, X, FileSpreadsheet, ListChecks, Archive, Camera } from 'lucide-react';
import type { ReferenceItem } from '../../types';
import { Button, EmptyState, PageHeader } from '../ui';
import { lifecycleStage } from '../../utils/refLifecycle';
import { isTestReference } from '../../utils/refKind';
import { depotOf } from '../../services/depots';
import { useLocationProfiles } from '../../services/locationProfiles';
import { witnessPlan } from '../../services/sahit';
import LotReport, { lotPhotos } from './LotReport';
import { buildLot, STAGE_LABEL, TEST_KINDS, type LotSources, type LotTest, type Verdict } from '../../services/lotTests';

/**
 * v49c2 — Partiler (eski "Tüm kayıtlar & izlenebilirlik" yerine) ve parti sayfası.
 *  Liste: arama + aşama seçici + sade satır. Kısayollar ⋯ menüsünde.
 *  Parti sayfası: aşama şeridi · miktar/yer/gün · testler (düzenlenebilir satır) · zaman çizelgesi · tek ana düğme.
 */
interface Props extends LotSources {
  onOpenEdit: (moduleKey: string, record: unknown, refId: string) => void;
  onAddTest: (moduleKey: string, refId: string) => void;
  onNextStep: (ref: ReferenceItem, stage: string) => void;
  onOpenPdf: (ref: ReferenceItem) => void;
  onOpenScan: () => void;
  onOpenLegacy: () => void;
  onExportExcel: (refs: ReferenceItem[]) => void;
  onOpenStandards: () => void;
  onBack: () => void;
  initialRefId?: string | null;
}

type Tab = 'AKTIF' | 'HASAT' | 'DEPO' | 'YOLDA' | 'TEST' | 'BITTI';
const STAGE_PILL: Record<string, { label: string; cls: string }> = {
  SAHADA: { label: 'Hasat', cls: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
  ON_SOG: { label: 'Ön soğutma', cls: 'bg-sky-50 text-sky-800 border-sky-200' },
  SORT: { label: 'Sortlama', cls: 'bg-violet-50 text-violet-800 border-violet-200' },
  DEPODA: { label: 'Depo', cls: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
  YOLDA: { label: 'Sevk', cls: 'bg-amber-50 text-amber-800 border-amber-200' },
  INCIDENT: { label: 'Akt', cls: 'bg-rose-50 text-rose-800 border-rose-200' },
  TAMAMLANDI: { label: 'Bitti', cls: 'bg-slate-100 text-slate-700 border-slate-200' },
  TEST: { label: 'Test', cls: 'bg-slate-100 text-slate-700 border-slate-200' },
};
const V: Record<Verdict, string> = {
  ok: 'bg-emerald-50 text-emerald-800 border-emerald-200', warn: 'bg-amber-50 text-amber-800 border-amber-200',
  bad: 'bg-rose-50 text-rose-800 border-rose-200', none: 'bg-slate-100 text-slate-600 border-slate-200',
};
const fmtD = (iso?: string) => { if (!iso) return '—'; const d = new Date(iso.length === 10 ? `${iso}T00:00:00` : iso); return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }); };
const fmtDT = (iso?: string) => { if (!iso) return '—'; const d = new Date(iso.length === 10 ? `${iso}T00:00:00` : iso); return Number.isNaN(d.getTime()) ? iso : (iso.length === 10 ? d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }) : d.toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })); };
const kgT = (v: number) => (v >= 10000 ? `${(v / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t` : `${Math.round(v).toLocaleString('tr-TR')} kg`);

function stageKey(r: ReferenceItem): string {
  const st = lifecycleStage(r);
  if (st === 'SAHADA') {
    const slips = (r.precoolingSlips || []) as any[];
    if (slips.some(s => s.inspectionMode === 'SORTING' || s.packedKg || s.culledKg)) return 'SORT';
    if (slips.length) return 'ON_SOG';
  }
  return st;
}

export default function LotsView(p: Props) {
  useLocationProfiles();
  const [q, setQ] = useState('');
  const [tab, setTab] = useState<Tab>('AKTIF');
  const [menu, setMenu] = useState(false);
  const [openId, setOpenId] = useState<string | null>(p.initialRefId || null);

  const rows = useMemo(() => p.references.filter(r => !r.archived).map(r => {
    const a = p.ambarRecords.filter(x => x.refId === r.refId).sort((x, y) => (y.acceptanceDate || '').localeCompare(x.acceptanceDate || ''))[0];
    const demo = !!a && !depotOf(a.warehouse);
    return { r, sk: stageKey(r), test: isTestReference(r), demo, place: a ? `${a.warehouse || ''} · ${a.roomNo || ''}` : r.orchard || r.location || '' };
  }).sort((x, y) => (y.r.createdAt || '').localeCompare(x.r.createdAt || '')), [p.references, p.ambarRecords]);

  const count = (t: Tab) => rows.filter(x => match(x, t)).length;
  function match(x: typeof rows[number], t: Tab) {
    if (t === 'TEST') return x.test;
    if (x.test) return false;
    if (t === 'AKTIF') return !['TAMAMLANDI'].includes(x.sk);
    if (t === 'HASAT') return ['SAHADA', 'ON_SOG', 'SORT'].includes(x.sk);
    if (t === 'DEPO') return x.sk === 'DEPODA';
    if (t === 'YOLDA') return x.sk === 'YOLDA';
    return x.sk === 'TAMAMLANDI';
  }
  const term = q.trim().toLocaleLowerCase('tr');
  const shown = rows.filter(x => match(x, tab) && (!term || [x.r.refId, x.r.product, x.r.variety, x.r.orchard, x.place].some(v => String(v || '').toLocaleLowerCase('tr').includes(term))));

  if (openId) {
    const lot = buildLot(openId, p);
    if (lot) return <LotPage {...p} lot={lot} onClose={() => setOpenId(null)} />;
  }

  const TABS: [Tab, string][] = [['AKTIF', 'Aktif'], ['HASAT', 'Hasat'], ['DEPO', 'Depo'], ['YOLDA', 'Sevk'], ['BITTI', 'Bitti'], ['TEST', 'Testler']];
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={p.onBack} title="Partiler" subtitle={`${count('AKTIF')} aktif parti`}
        actions={<div className="flex gap-2 relative">
          <button type="button" aria-label="QR okut" onClick={p.onOpenScan} className="w-10 h-10 rounded-xl border border-slate-200 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><QrCode className="w-5 h-5" /></button>
          <button type="button" aria-label="Diğer" onClick={() => setMenu(m => !m)} className="w-10 h-10 rounded-xl border border-slate-200 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer"><MoreHorizontal className="w-5 h-5" /></button>
          {menu && (
            <div className="absolute left-0 top-12 z-40 w-64 rounded-2xl border border-slate-200 bg-white dark:bg-slate-900 shadow-lg p-1.5">
              {[[FileSpreadsheet, 'Excel\'e aktar (bu liste)', () => p.onExportExcel(shown.map(x => x.r))], [ListChecks, 'Kriterler ve standartlar', p.onOpenStandards], [Archive, 'Ayrıntılı liste (eski görünüm)', p.onOpenLegacy]].map(([I, l, f]: any) => (
                <button key={l} type="button" onClick={() => { setMenu(false); f(); }} className="w-full flex items-center gap-2.5 min-h-[44px] px-3 rounded-xl text-sm text-left hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"><I className="w-4 h-4 text-slate-500" />{l}</button>
              ))}
            </div>
          )}
        </div>} />
      <label className="flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 min-h-[44px]">
        <Search className="w-4 h-4 text-slate-400" />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, ürün, bahçe, oda" className="flex-1 bg-transparent text-sm outline-none" />
        {q && <button type="button" aria-label="Temizle" onClick={() => setQ('')}><X className="w-4 h-4 text-slate-400" /></button>}
      </label>
      <div className="flex gap-1.5 overflow-x-auto pb-0.5">
        {TABS.map(([k, l]) => (
          <button key={k} type="button" onClick={() => setTab(k)} className={`shrink-0 px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${tab === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{l} {count(k)}</button>
        ))}
      </div>
      {shown.length === 0 && <EmptyState icon={<ListChecks className="w-5 h-5" />} title="Kayıt yok" description={term ? 'Aramayla eşleşen parti yok.' : 'Bu aşamada parti yok.'} />}
      {shown.length > 0 && (
        <ul className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 divide-y divide-slate-100 dark:divide-slate-800">
          {shown.slice(0, 200).map(x => {
            const pill = STAGE_PILL[x.sk] || STAGE_PILL.SAHADA;
            const qty = Number(x.r.quantity) || 0;
            return (
              <li key={x.r.refId}>
                <button type="button" onClick={() => setOpenId(x.r.refId)} className="w-full flex items-center justify-between gap-3 py-3 text-left cursor-pointer">
                  <span className="min-w-0">
                    <span className="block text-sm font-bold text-slate-900 dark:text-white font-ref truncate">{x.r.refId}</span>
                    <span className="block text-xs text-slate-600 dark:text-slate-400 truncate">{[x.r.product, x.r.variety].filter(Boolean).join(' · ').replace(/\s*\(\s*\)/g, '')}{x.place ? ` · ${x.place}` : ''}</span>
                    <span className="block text-[11px] text-slate-400 tabular-nums">{x.test ? 'test' : qty ? kgT(qty) : '—'} · {fmtD(x.r.createdAt)}{x.demo ? ' · deneme' : ''}</span>
                  </span>
                  <span className={`shrink-0 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${pill.cls}`}>{pill.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

const NEXT: Record<string, { label: string; icon: React.ReactNode }> = {
  SAHADA: { label: 'Ön soğutma fişi', icon: <Snowflake className="w-4 h-4" /> },
  ON_SOG: { label: 'Depo kabul', icon: <Warehouse className="w-4 h-4" /> },
  SORT: { label: 'Depo kabul', icon: <Warehouse className="w-4 h-4" /> },
  DEPODA: { label: 'Sevk kaydı', icon: <Truck className="w-4 h-4" /> },
  YOLDA: { label: 'Varış / kabul', icon: <Warehouse className="w-4 h-4" /> },
  INCIDENT: { label: 'Aktı aç', icon: <ShieldAlert className="w-4 h-4" /> },
};

function LotPage(p: Props & { lot: NonNullable<ReturnType<typeof buildLot>>; onClose: () => void }) {
  const { lot } = p;
  const r = lot.ref;
  const sk = stageKey(r);
  const [adding, setAdding] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [report, setReport] = useState(false);
  const [zoom, setZoom] = useState<string | null>(null);
  const rail = ['Hasat', 'Ön soğ.', 'Sortlama', 'Depo', 'Sevk'];
  const at = { SAHADA: 0, ON_SOG: 1, SORT: 2, DEPODA: 3, YOLDA: 4, TAMAMLANDI: 5, INCIDENT: 3, TEST: 0 }[sk] ?? 0;
  const counts = lot.tests.reduce((m, t) => ({ ...m, [t.verdict]: (m[t.verdict] || 0) + 1 }), {} as Record<string, number>);
  const lc = lifecycleStage(r);
  const kinds = TEST_KINDS.filter(k => !k.products || k.products.test(String(r.product || '')))
    .map(k => ({ ...k, suggested: k.stages.includes(lc) })).sort((a, b) => Number(b.suggested) - Number(a.suggested));
  const next = NEXT[sk];

  if (adding) {
    return (
      <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
        <PageHeader onBack={() => setAdding(false)} title="Test ekle" subtitle={`${r.refId} · ${r.product || ''}`} />
        <ul className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 divide-y divide-slate-100 dark:divide-slate-800">
          {kinds.map(k => (
            <li key={k.moduleKey + k.label}>
              <button type="button" onClick={() => p.onAddTest(k.moduleKey, r.refId)} className="w-full flex items-center justify-between gap-3 py-3 text-left cursor-pointer">
                <span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white">{k.label}</span><span className="block text-xs text-slate-500">{k.hint}</span></span>
                {k.suggested ? <span className="shrink-0 text-[11px] font-semibold px-2 py-0.5 rounded-full border bg-emerald-50 text-emerald-800 border-emerald-200">önerilen</span> : <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
              </button>
            </li>
          ))}
        </ul>
        <p className="text-xs text-slate-500 text-center">Form açılınca RefID hazır gelir; kaydedilen test bu partinin listesine eklenir.</p>
      </div>
    );
  }

  const tests = showAll ? lot.tests : lot.tests.slice(-8);
  const photos = lotPhotos(r.refId, p);
  if (report) return <LotReport lot={lot} sources={p} onClose={() => setReport(false)} onOpenPassport={() => { setReport(false); p.onOpenPdf(r); }} />;
  const witness = witnessPlan((p.exportSampleRecords || []).filter(x => x.refId === r.refId));
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3 pb-28">
      <PageHeader onBack={p.onClose} title={r.refId} subtitle={[r.product, r.variety, r.orchard].filter(Boolean).join(' · ').replace(/\s*\(\s*\)/g, '')} />
      <div className="flex items-start gap-1" aria-label="Aşama">
        {rail.map((n, i) => (
          <div key={n} className="flex-1 min-w-0">
            <div className={`h-1.5 rounded-full ${i < at ? 'bg-emerald-600' : i === at ? 'bg-emerald-400' : 'bg-slate-200 dark:bg-slate-700'}`} />
            <div className={`text-[10px] mt-1 text-center truncate ${i === at ? 'font-bold text-slate-900 dark:text-white' : 'text-slate-500'}`}>{n}</div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[[isTestReference(r) ? 'Test' : kgT(lot.currentKg), isTestReference(r) ? 'kayıt türü' : 'şu an'], [lot.place, 'yer'], [lot.daysInStage !== undefined ? `${lot.daysInStage}. gün` : '—', 'bu aşamada']].map(([v, l]) => (
          <div key={l} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5 min-w-0"><div className="text-sm font-bold tabular-nums truncate text-slate-900 dark:text-white">{v}</div><div className="text-[11px] text-slate-500">{l}</div></div>
        ))}
      </div>

      {witness && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="flex items-center justify-between"><h2 className="text-sm font-bold text-slate-900 dark:text-white">Şahit numune</h2><span className="text-xs text-slate-500 tabular-nums">yolda {witness.today}. gün</span></div>
          <div className="flex flex-wrap gap-1.5 mt-2">{witness.points.map(pt => {
            const cls = pt.done ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : pt.day < witness.today - 1 ? 'bg-rose-50 text-rose-700 border-rose-200' : Math.abs(pt.day - witness.today) <= 1 ? 'bg-amber-50 text-amber-800 border-amber-300' : 'bg-white text-slate-500 border-slate-200 dark:bg-slate-900';
            return <span key={pt.day} className={`text-xs font-semibold tabular-nums px-2.5 py-1 rounded-full border ${cls}`}>{pt.day}. gün{pt.done ? ' ✓' : ''}</span>;
          })}</div>
          <p className="text-[11px] text-slate-500 mt-2">Gün yola çıkıştan sayılır · 3, 5, 7 ve 7'nin katları · yeşil: girildi, kırmızı: kaçtı, sarı: bugün.</p>
        </section>
      )}

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><FlaskConical className="w-4 h-4 text-emerald-700" />Testler · {lot.tests.length}</h2>
          <button type="button" onClick={() => setAdding(true)} className="text-xs font-semibold text-teal-700 dark:text-teal-300 flex items-center gap-1 cursor-pointer min-h-[36px]"><Plus className="w-3.5 h-3.5" />Test ekle</button>
        </div>
        {lot.tests.length > 0 && (
          <div className="flex gap-1.5 mb-1 text-[11px]">
            {counts.ok ? <span className={`px-2 py-0.5 rounded-full border ${V.ok}`}>{counts.ok} uygun</span> : null}
            {counts.warn ? <span className={`px-2 py-0.5 rounded-full border ${V.warn}`}>{counts.warn} dikkat</span> : null}
            {counts.bad ? <span className={`px-2 py-0.5 rounded-full border ${V.bad}`}>{counts.bad} uygun değil</span> : null}
          </div>
        )}
        {lot.tests.length === 0 && <p className="py-3 text-sm text-slate-500">Bu partiye bağlı test yok. "Test ekle" ile başlayın.</p>}
        {lot.tests.length > tests.length && <button type="button" onClick={() => setShowAll(true)} className="text-xs font-semibold text-teal-700 py-1 cursor-pointer">Önceki {lot.tests.length - tests.length} testi göster</button>}
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
          {tests.map((t: LotTest) => (
            <li key={t.key} className="py-2.5 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-[11px] text-slate-400 tabular-nums">{STAGE_LABEL[t.stage]} · {fmtDT(t.date)}{t.by ? ` · ${t.by}` : ''}</div>
                <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">{t.title}</div>
                <div className="text-xs text-slate-500 truncate">{t.summary || '—'}</div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${V[t.verdict]}`}>{t.verdictLabel}</span>
                {t.moduleKey && t.record ? (
                  <button type="button" aria-label="Aç / düzenle" onClick={() => p.onOpenEdit(t.moduleKey!, t.record, r.refId)} className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"><Pencil className="w-4 h-4" /></button>
                ) : <span className="w-9" />}
              </div>
            </li>
          ))}
        </ul>
        {lot.tests.length > 0 && <p className="text-[11px] text-slate-500 mt-1">Kalem: kaydı açar; değişiklik kim · ne zaman olarak denetim izine düşer.</p>}
      </section>

      {photos.length > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5"><Camera className="w-4 h-4 text-teal-700" />Fotoğraflar · {photos.length}</h2>
          <div className="grid grid-cols-3 gap-1.5">{photos.slice(0, 9).map((ph, i) => (
            <button key={i} type="button" onClick={() => setZoom(ph.src)} className="relative rounded-lg overflow-hidden aspect-[4/3] bg-slate-100 cursor-pointer">
              <img src={ph.src} alt="" loading="lazy" className="w-full h-full object-cover" />
              <span className="absolute left-0 right-0 bottom-0 bg-black/45 text-white text-[10px] px-1.5 py-0.5 truncate text-left">{ph.label} · {fmtD(ph.date)}</span>
            </button>))}</div>
          {photos.length > 9 && <p className="text-[11px] text-slate-500 mt-1.5">+{photos.length - 9} fotoğraf · tümü raporda</p>}
        </section>
      )}
      {zoom && (
        <button type="button" onClick={() => setZoom(null)} className="fixed inset-0 z-[140] bg-black/85 flex items-center justify-center p-3 cursor-pointer" aria-label="Kapat">
          <img src={zoom} alt="" className="max-w-full max-h-full rounded-lg" />
        </button>
      )}

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Zaman çizelgesi</h2>
        {lot.events.length === 0 && <p className="text-sm text-slate-500">Henüz hareket yok.</p>}
        <ul className="space-y-2">
          {lot.events.slice(0, 15).map((e, i) => (
            <li key={i} className="flex gap-3"><span className="text-[11px] text-slate-500 tabular-nums w-24 shrink-0 pt-0.5">{fmtDT(e.date)}</span><span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white">{e.title}</span><span className="block text-xs text-slate-500 truncate">{e.detail}</span></span></li>
          ))}
        </ul>
      </section>

      <div className="fixed left-0 right-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] sm:bottom-4 px-3 z-30">
        <div className="max-w-3xl mx-auto grid grid-cols-[1fr_auto] gap-2">
          {next && !isTestReference(r)
            ? <Button variant="primary" fullWidth icon={next.icon} onClick={() => p.onNextStep(r, sk)}>Sonraki adım: {next.label}</Button>
            : <Button variant="primary" fullWidth icon={<Plus className="w-4 h-4" />} onClick={() => setAdding(true)}>Test ekle</Button>}
          <Button icon={<FileDown className="w-4 h-4" />} onClick={() => setReport(true)}>Rapor</Button>
        </div>
      </div>
    </div>
  );
}
