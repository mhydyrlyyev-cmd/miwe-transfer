import React, { useEffect } from 'react';
import { Printer, X, FileText } from 'lucide-react';
import type { LotData, LotSources } from '../../services/lotTests';
import { STAGE_LABEL } from '../../services/lotTests';
import { witnessPlan } from '../../services/sahit';

/** v49c4 — Parti raporu: beyaz A4, yazdır / PDF olarak kaydet. Başlık: Kalite kontrol bölümü. */

export interface LotPhoto { src: string; label: string; date?: string }

/** Partiye bağlı tüm kayıtların fotoğrafları (hasat, test, depo, sevk, akt …) */
export function lotPhotos(refId: string, src: Partial<LotSources> & { incidentRecords?: unknown[] }): LotPhoto[] {
  const groups: [string, unknown[] | undefined][] = [
    ['Hasat', src.harvestRecords], ['Saha testi', src.fieldRecords], ['Muz', src.muzRecords], ['Badem', src.bademRecords],
    ['Depo', src.ambarRecords], ['Sevk', src.lojistikRecords], ['Satış', src.salesRecords], ['Şahit numune', src.exportSampleRecords],
    ['Freeze-dry', src.freezeDryRecords], ['Akt', src.incidentRecords],
  ];
  const out: LotPhoto[] = []; const seen = new Set<string>();
  for (const [label, arr] of groups) for (const r of (arr || []) as any[]) {
    if (!r || r.refId !== refId || !Array.isArray(r.photos)) continue;
    for (const ph of r.photos) {
      const s = typeof ph === 'string' ? ph : ph?.url || ph?.dataUrl;
      if (!s || seen.has(s)) continue;
      seen.add(s); out.push({ src: s, label, date: r.testDate || r.recordDate || r.acceptanceDate || r.shipmentDate || r.timestamp });
    }
  }
  return out;
}

const d = (iso?: string) => { if (!iso) return '—'; const x = new Date(iso.length === 10 ? `${iso}T00:00:00` : iso); return Number.isNaN(x.getTime()) ? iso : x.toLocaleDateString('tr-TR'); };
const VERDICT_TXT: Record<string, string> = { ok: 'Uygun', warn: 'Dikkat', bad: 'Uygun değil', none: '—' };

export default function LotReport({ lot, sources, onClose, onOpenPassport }: { lot: LotData; sources: LotSources & { incidentRecords?: unknown[] }; onClose: () => void; onOpenPassport?: () => void }) {
  const r = lot.ref;
  const photos = lotPhotos(r.refId, sources);
  const w = witnessPlan((sources.exportSampleRecords || []).filter(x => x.refId === r.refId));
  const ok = lot.tests.filter(t => t.verdict === 'ok').length, warn = lot.tests.filter(t => t.verdict === 'warn').length, bad = lot.tests.filter(t => t.verdict === 'bad').length;
  useEffect(() => { document.documentElement.classList.add('lot-report-open'); return () => document.documentElement.classList.remove('lot-report-open'); }, []);
  const info: [string, string][] = [
    ['Ürün / çeşit', [r.product, r.variety].filter(Boolean).join(' · ') || '—'], ['Bahçe / yer', r.orchard || '—'],
    ['Şu an', lot.place || '—'], ['Miktar', lot.currentKg ? `${Math.round(lot.currentKg).toLocaleString('tr-TR')} kg` : '—'],
    ['Açılış', d(r.createdAt)], ['Rapor tarihi', new Date().toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })],
  ];
  return (
    <div className="fixed inset-0 z-[130] bg-slate-200/90 overflow-y-auto" id="lot-report-root">
      <style>{`
        @page { size: A4; margin: 14mm; }
        #lot-report { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #0f172a; }
        #lot-report table { width: 100%; border-collapse: collapse; }
        #lot-report th, #lot-report td { border-bottom: 1px solid #e2e8f0; padding: 5px 6px; text-align: left; vertical-align: top; font-size: 11px; }
        #lot-report th { font-size: 10px; color: #475569; font-weight: 700; background: #f8fafc; }
        #lot-report h2 { font-size: 12px; font-weight: 800; margin: 14px 0 6px; text-transform: uppercase; letter-spacing: .04em; color: #0f766e; }
        @media print {
          html.lot-report-open body * { visibility: hidden !important; }
          html.lot-report-open #lot-report, html.lot-report-open #lot-report * { visibility: visible !important; }
          html.lot-report-open #lot-report { position: absolute; left: 0; top: 0; width: 100%; margin: 0; box-shadow: none !important; padding: 0 !important; }
          #lot-report-bar { display: none !important; }
          #lot-report tr, #lot-report .ph { break-inside: avoid; }
        }
      `}</style>
      <div id="lot-report-bar" className="sticky top-0 z-10 bg-white/95 border-b border-slate-200 px-3 py-2 flex items-center gap-2">
        <button type="button" onClick={onClose} className="inline-flex items-center gap-1.5 px-3 min-h-[40px] rounded-xl border border-slate-300 text-sm cursor-pointer"><X className="w-4 h-4" />Kapat</button>
        <span className="flex-1" />
        {onOpenPassport && <button type="button" onClick={onOpenPassport} className="inline-flex items-center gap-1.5 px-3 min-h-[40px] rounded-xl border border-slate-300 text-sm cursor-pointer"><FileText className="w-4 h-4" />Detaylı pasaport</button>}
        <button type="button" onClick={() => window.print()} className="inline-flex items-center gap-1.5 px-3 min-h-[40px] rounded-xl bg-teal-700 text-white text-sm font-semibold cursor-pointer"><Printer className="w-4 h-4" />Yazdır / PDF</button>
      </div>
      <div id="lot-report" className="bg-white mx-auto my-4 shadow-lg" style={{ width: 'min(210mm, 100%)', minHeight: '297mm', padding: '12mm' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '2px solid #0f766e', paddingBottom: 8 }}>
          <div><div style={{ fontSize: 10, color: '#475569', fontWeight: 700, letterSpacing: '.06em' }}>KALİTE KONTROL BÖLÜMÜ</div><div style={{ fontSize: 20, fontWeight: 800 }}>Parti raporu</div></div>
          <div style={{ textAlign: 'right' }}><div style={{ fontSize: 16, fontWeight: 800 }}>{r.refId}</div><div style={{ fontSize: 10, color: '#475569' }}>MIWE HIL · izlenebilirlik</div></div>
        </div>
        <table style={{ marginTop: 8 }}><tbody>{[0, 2, 4].map(i => (
          <tr key={i}><th style={{ width: '18%' }}>{info[i][0]}</th><td style={{ width: '32%' }}>{info[i][1]}</td><th style={{ width: '18%' }}>{info[i + 1][0]}</th><td>{info[i + 1][1]}</td></tr>))}</tbody></table>

        <h2>Testler · {lot.tests.length} <span style={{ color: '#475569', fontWeight: 600, textTransform: 'none', letterSpacing: 0 }}>— uygun {ok} · dikkat {warn} · uygun değil {bad}</span></h2>
        {lot.tests.length === 0 ? <p style={{ fontSize: 11, color: '#64748b' }}>Bağlı test yok.</p> : (
          <table><thead><tr><th>Tarih</th><th>Aşama</th><th>Test</th><th>Sonuç</th><th>Karar</th><th>Kim</th></tr></thead>
            <tbody>{lot.tests.map(t => (
              <tr key={t.key}><td style={{ whiteSpace: 'nowrap' }}>{d(t.date)}</td><td>{STAGE_LABEL[t.stage]}</td><td>{t.title}</td><td>{t.summary || '—'}</td>
                <td style={{ fontWeight: 700, color: t.verdict === 'bad' ? '#be123c' : t.verdict === 'warn' ? '#b45309' : t.verdict === 'ok' ? '#047857' : '#475569' }}>{t.verdictLabel || VERDICT_TXT[t.verdict]}</td><td>{t.by || '—'}</td></tr>))}</tbody></table>)}

        {w && (<>
          <h2>Şahit numune</h2>
          <p style={{ fontSize: 11 }}>Yola çıkış {d(w.start)} · bugün {w.today}. gün · ölçüm günleri: {w.points.map(pt => `${pt.day}${pt.done ? ' ✓' : pt.day < w.today - 1 ? ' ✗' : ''}`).join(' · ')}</p>
        </>)}

        <h2>Zaman çizelgesi</h2>
        <table><tbody>{lot.events.slice(0, 30).map((e, i) => (
          <tr key={i}><td style={{ width: '16%', whiteSpace: 'nowrap' }}>{d(e.date)}</td><td style={{ width: '28%', fontWeight: 700 }}>{e.title}</td><td>{e.detail}</td></tr>))}</tbody></table>

        {photos.length > 0 && (<>
          <h2>Fotoğraflar · {photos.length}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>{photos.slice(0, 12).map((ph, i) => (
            <figure key={i} className="ph" style={{ margin: 0 }}><img src={ph.src} alt="" style={{ width: '100%', aspectRatio: '4/3', objectFit: 'cover', borderRadius: 4, border: '1px solid #e2e8f0' }} />
              <figcaption style={{ fontSize: 9, color: '#475569' }}>{ph.label} · {d(ph.date)}</figcaption></figure>))}</div>
          {photos.length > 12 && <p style={{ fontSize: 10, color: '#64748b' }}>+{photos.length - 12} fotoğraf daha platformda.</p>}
        </>)}

        <div style={{ marginTop: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, fontSize: 10, color: '#475569' }}>
          <div style={{ borderTop: '1px solid #94a3b8', paddingTop: 4 }}>Hazırlayan · imza</div>
          <div style={{ borderTop: '1px solid #94a3b8', paddingTop: 4 }}>Onaylayan (Kalite kontrol bölümü) · imza</div>
        </div>
      </div>
    </div>
  );
}
