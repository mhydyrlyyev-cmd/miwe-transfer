# v49c4 — Bahçe iklimi · Parti raporu (beyaz A4) · fotoğraflar · giriş durumu · yedek

1. Bahçe iklimi (Menü › Takvim ve akışlar › Bahçe iklimi, görünüm CLIMATE; YENİ services/agroClimate.ts, ClimateView.tsx):
   gün-derece (çiçeklenmeden beri, taban profilden, varsayılan 10 °C) + geçen yılla karşılaştırma + hasat GDD hedefiyle tahmini tarih;
   soğuklama saati (1 Kasım'dan beri, 0–7,2 °C) + geçen yıl; çiçek donu (çiçeklenme −10/+25 gün, Tmin ≤ 0 uyarı, ≤ −2 kritik); 7 gün tahmin.
   Veri: Open-Meteo arşiv (archive-api.open-meteo.com) + tahmin (api.open-meteo.com); anahtar yok; 12 saat önbellek.
   Bahçe profiline 3 alan: Çiçeklenme tarihi (GG.AA), Gün-derece taban sıcaklığı, Hasat için gün-derece hedefi.
2. Parti raporu (YENİ LotReport.tsx): parti sayfasındaki "Rapor" düğmesi beyaz A4 rapor açar — başlık "Kalite kontrol bölümü",
   bilgiler, test tablosu, şahit numune, zaman çizelgesi, fotoğraflar, imza alanları. "Yazdır / PDF" ile kaydedilir. Eski pasaport "Detaylı pasaport" düğmesinde.
3. Parti sayfası › Fotoğraflar: partiye bağlı tüm kayıtların fotoğrafları (hasat, test, depo, sevk, akt…); dokununca büyür.
4. Yönetici masası › Giriş durumu: son 7 gün / 7 günden eski / hiç açmadı + kişi listesi (son açılış).
   Kalıcı oturumla açılışta da "son açılış" 12 saatte bir güncellenir (mevcut lastLoginAt alanı; kural değişmez).
5. Yönetici masası › Yedek: "İndir" ile tüm kayıtlar tek JSON dosyası; son yedek tarihi, 7 günü geçince uyarı rengi.
6. Giriş hatası mesajı: "Google ile açtıysanız parolanız yoktur: Google ile giriş ya da Şifremi unuttum ile parola belirleyin."

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (9 dosya)
f6f5c242619ee23be2bbfe58dbfcb061c65ddcf21294f9287d5d173b90735cf7  src/App.tsx
1963cbccd2b7fc6f688fd01d344836d058ba13be5721de22452b30483a52d1f4  src/services/agroClimate.ts
42ca0e7fe9b9fb713927d90401dc6f85cf92363fae6c066d9ce20309f78a010d  src/services/locationProfiles.ts
3259c79700af73e4d0eea463c1f23c66ee772b782279ce09a69c81df0d4a666b  src/utils/authService.ts
fbfb92bd1f86e2763bf9dc7790b6bd074571b80cf6e05ea651a922f3fd6b14b3  src/components/views/ClimateView.tsx
5514683dce8c888cc8d560b6266d04f39130c21e4cc74d0c67d14d321b8dcfde  src/components/views/LotReport.tsx
e1dc355980da739ec913ae335d4915518a43b50bc1d424ae2ab1396105b2ed11  src/components/views/LotsView.tsx
46a04c2fe56fc66b267e9117c16664597f9ebc45cd9adbd1e8938e09e0bf61a9  src/components/views/ManagementViews.tsx
5a72d16c911df793c2f3017848d28464d7eeb45309dd33d6da55d5d9b4f90aa4  src/components/portal/HomeMenu.tsx
