import React, { useMemo } from 'react';
import { Snowflake, Sprout, Flower2, MapPin, RefreshCw } from 'lucide-react';
import { PageHeader } from '../ui';
import { useLocationProfiles, canonicalOrchard } from '../../services/locationProfiles';
import { ORCHARD_CARDS } from '../../config/orchardCards';
import { useOrchardClimate, useElevations, HOPKINS_DAYS_PER_M, CHILL_NEED, chillVerdict, type OrchardClimate } from '../../services/agroClimate';

/** v50e: bahçedeki meyve türleri (bütçe kartından) → soğuk ihtiyacı */
const FRUIT_N = (f: string) => (/alma|elma/i.test(f) ? 'Elma' : /şeft|seft/i.test(f) ? 'Şeftali' : /nekt/i.test(f) ? 'Nektarin' : /çer|kiraz/i.test(f) ? 'Kiraz' : /armut|nashi/i.test(f) ? 'Armut' : /erik/i.test(f) ? 'Erik' : /kayıs|erik/i.test(f) ? 'Kayısı' : /badem/i.test(f) ? 'Badem' : f);
function fruitsOf(name: string): string[] {
  const card = ORCHARD_CARDS[canonicalOrchard(name)] || ORCHARD_CARDS[name];
  const fs = [...new Set((card?.varieties || []).map(v => FRUIT_N(v.tur)).filter(f => CHILL_NEED[f]))];
  return fs.sort((a, b) => CHILL_NEED[b] - CHILL_NEED[a]);
}
const VCLS = { yeterli: 'text-emerald-700', sınırda: 'text-amber-700', yetersiz: 'text-rose-700 font-semibold' } as const;
function Needs({ chill, fruits, prefix }: { chill: number; fruits: string[]; prefix: string }) {
  if (!fruits.length) return null;
  return (
    <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1">{prefix}{' '}
      {fruits.map((f, i) => { const v = chillVerdict(chill, CHILL_NEED[f]); return <span key={f}>{i ? ' · ' : ''}{f} <span className={prefix.startsWith('Kış') ? VCLS[v.label] : 'font-semibold text-slate-800 dark:text-slate-200'}>%{v.pct}{prefix.startsWith('Kış') ? ` ${v.label}` : ''}</span></span>; })}
    </p>);
}

/** v49c4 — Bahçe iklimi: gün-derece, soğuklama saati, çiçek donu, geçen yılla karşılaştırma */
const dm = (s?: string) => (s ? s.split('-').reverse().slice(0, 2).join('.') : '—');
const n0 = (v?: number) => (v === undefined ? '—' : Math.round(v).toLocaleString('tr-TR'));
const delta = (a?: number, b?: number) => {
  if (a === undefined || !b) return null;
  const p = Math.round(((a - b) / b) * 100);
  return <span className={`text-[11px] font-semibold ${p >= 0 ? 'text-emerald-700' : 'text-amber-700'}`}>{p >= 0 ? '+' : ''}{p}%</span>;
};

function Bars({ now, last, max }: { now: number; last: number; max: number }) {
  const w = (v: number) => `${Math.max(2, Math.min(100, (v / (max || 1)) * 100))}%`;
  return (
    <div className="space-y-1 mt-1.5" aria-hidden>
      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-2 rounded-full bg-teal-600" style={{ width: w(now) }} /></div>
      <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-2 rounded-full bg-slate-400" style={{ width: w(last) }} /></div>
    </div>
  );
}

/** v49c13: mevsime göre tek ana gösterge — Kasım–Şubat soğuklama (çiçeklenme düzeni), Mart–Ekim gün-derece (hasat tarihi);
 *  don kutusu yalnız çiçeklenme döneminde; 7 günlük tahmin yalnız soğuk varsa açık. */
function Card({ c, elev, rel, onOpenProfiles }: { c: OrchardClimate; elev?: number; rel?: string; onOpenProfiles: () => void }) {
  const fr = { crit: 'bg-rose-50 text-rose-800 border-rose-200', warn: 'bg-amber-50 text-amber-800 border-amber-200', none: 'bg-emerald-50 text-emerald-800 border-emerald-200', off: '' }[c.frost.level];
  const mo = new Date().getMonth();
  const winter = mo >= 10 || mo <= 1;
  const showGdd = !winter && c.gdd !== undefined;
  const cold = c.forecast.slice(0, 7).some(d => d.tMin <= 2);
  const mins = c.forecast.slice(0, 7);
  const lo = mins.length ? Math.min(...mins.map(d => d.tMin)) : undefined, hi = mins.length ? Math.max(...mins.map(d => d.tMax)) : undefined;
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 min-w-0"><MapPin className="w-4 h-4 text-teal-700 shrink-0" /><span className="truncate">{c.name}</span></h2>
        <span className="text-[11px] text-slate-500 shrink-0 tabular-nums">{elev !== undefined ? `${n0(elev)} m` : ''}{rel ? ` · ${rel}` : ''}</span>
      </div>
      {c.error ? <p className="text-sm text-amber-800">{c.error}</p> : (<>
        {showGdd ? (
          <div>
            <div className="flex items-baseline justify-between"><span className="text-xs text-slate-500 flex items-center gap-1"><Sprout className="w-3.5 h-3.5" />Isı birikimi → hasat</span>{delta(c.gdd, c.gddLast)}</div>
            <div className="flex items-baseline gap-2"><span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{n0(c.gdd)}</span><span className="text-xs text-slate-500">gün-derece · geçen yıl {n0(c.gddLast)}</span></div>
            <Bars now={c.gdd!} last={c.gddLast || 0} max={Math.max(c.gdd!, c.gddLast || 0, c.harvestGdd || 0)} />
            {c.harvestGdd ? <p className="text-xs mt-1 text-slate-700 dark:text-slate-300">Hasat {c.harvestReached ? <b>{dm(c.harvestReached)}'de başladı</b> : c.harvestEta ? <b>≈ {dm(c.harvestEta)}</b> : 'için veri az'}</p> : null}
          </div>
        ) : (
          <div>
            <div className="flex items-baseline justify-between"><span className="text-xs text-slate-500 flex items-center gap-1"><Snowflake className="w-3.5 h-3.5" />Kış soğuğu (çiçeklenme düzeni)</span>{delta(c.chill, c.chillLast)}</div>
            <div className="flex items-baseline gap-2"><span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{n0(c.chill)}</span><span className="text-xs text-slate-500">saat · {dm(c.chillStart)}'den · geçen yıl {n0(c.chillLast)}</span></div>
            <Bars now={c.chill} last={c.chillLast} max={Math.max(c.chill, c.chillLast)} />
            <Needs chill={c.chill} fruits={fruitsOf(c.name)} prefix="Soğuk ihtiyacının şimdiye kadar:" />
          </div>
        )}
        {!winter && c.winter && (() => { const fs = fruitsOf(c.name); return (
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2">
            <div className="text-[11px] text-slate-500 flex items-center gap-1"><Snowflake className="w-3.5 h-3.5" />Kış sonucu {c.winter.season}: <b className="text-slate-800 dark:text-slate-200">{n0(c.winter.chill)} saat</b> · geçen kış {n0(c.winter.last)}</div>
            <Needs chill={c.winter.chill} fruits={fs} prefix="Kış:" />
          </div>); })()}
        {c.spring && (
          <div className={`rounded-xl px-3 py-2 text-[11px] ${c.spring.critNights ? 'bg-rose-50 text-rose-900' : c.spring.nights ? 'bg-amber-50 text-amber-900' : 'bg-emerald-50 text-emerald-900'}`}>
            <Flower2 className="w-3.5 h-3.5 inline mr-1" />İlkbahar sonucu ({c.spring.from.slice(8, 10)}.{c.spring.from.slice(5, 7)}–{c.spring.to.slice(8, 10)}.{c.spring.to.slice(5, 7)}): {c.spring.nights ? <><b>{c.spring.nights} don gecesi</b>{c.spring.critNights ? ` (${c.spring.critNights}'i −2 °C altı)` : ''} · en düşük {c.spring.min.toFixed(1)} °C ({c.spring.minDate.slice(8, 10)}.{c.spring.minDate.slice(5, 7)}) — meyve sayımında kontrol edin</> : <>çiçek döneminde don olmadı · en düşük {c.spring.min.toFixed(1)} °C</>}
          </div>
        )}
        {c.frost.level !== 'off' && <div className={`text-xs rounded-xl border px-3 py-2 flex items-center gap-2 ${fr}`}><Flower2 className="w-4 h-4 shrink-0" />{c.frost.text}</div>}
        {cold || c.frost.level !== 'off' ? (
          <div className="grid grid-cols-7 gap-1 text-center">{mins.map(d => (
            <div key={d.date} className="rounded-lg bg-slate-50 dark:bg-slate-800 py-1">
              <div className="text-[10px] text-slate-500">{new Date(`${d.date}T00:00:00`).toLocaleDateString('tr-TR', { weekday: 'short' })}</div>
              <div className="text-[11px] font-semibold tabular-nums">{Math.round(d.tMax)}°</div>
              <div className={`text-[11px] tabular-nums ${d.tMin <= 0 ? 'text-rose-700 font-bold' : 'text-slate-500'}`}>{Math.round(d.tMin)}°</div>
            </div>))}
          </div>
        ) : lo !== undefined ? <p className="text-[11px] text-slate-500">7 gün: {Math.round(lo)}° … {Math.round(hi!)}° · don yok</p> : null}
      </>)}
      {(winter ? c.missing.filter(x => !/çiçek/i.test(x)) : c.missing).length > 0 && (
        <button type="button" onClick={onOpenProfiles} className="w-full text-left text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 cursor-pointer">
          Eksik: {(winter ? c.missing.filter(x => !/çiçek/i.test(x)) : c.missing).join(', ')} → Profiller › Bahçe
        </button>
      )}
    </section>
  );
}

export default function ClimateView({ onBack, onOpenProfiles }: { onBack: () => void; onOpenProfiles: () => void }) {
  const orchards = useLocationProfiles('ORCHARD');
  const points = useMemo(() => orchards.map(o => ({ name: o.name, lat: Number(o.fields?.lat) || undefined, lon: Number(o.fields?.lon) || undefined, fields: o.fields || {} })), [orchards]);
  const { data, loading } = useOrchardClimate(points);
  const noCoord = points.filter(p => p.lat === undefined || p.lon === undefined);
  const list = points.map(p => data[p.name]).filter(Boolean) as OrchardClimate[];
  const crit = list.filter(c => c.frost.level === 'crit' || c.frost.level === 'warn');
  const elevs = useElevations(points);
  const known = elevs.filter((e): e is number => e !== undefined);
  const low = known.length ? Math.min(...known) : undefined;
  const lowName = low !== undefined ? points[elevs.indexOf(low)]?.name : '';
  const relOf = (i: number) => { const e = elevs[i]; if (e === undefined || low === undefined || e - low < 50) return ''; return `+${Math.round((e - low) * HOPKINS_DAYS_PER_M)} gün`; };
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={onBack} title="Bahçe iklimi" subtitle={new Date().getMonth() >= 10 || new Date().getMonth() <= 1 ? 'Kış: soğuklama birikimi' : 'Sezon: ısı birikimi → hasat tarihi'} />
      {crit.length > 0 && <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 font-semibold">{crit.length} bahçede çiçek donu uyarısı</div>}
      {loading && list.length === 0 && <p className="text-sm text-slate-500 flex items-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />İklim verisi yükleniyor…</p>}
      {list.map(c => { const i = points.findIndex(p => p.name === c.name); return <Card key={c.name} c={c} elev={elevs[i]} rel={relOf(i)} onOpenProfiles={onOpenProfiles} />; })}
      {noCoord.length > 0 && (
        <button type="button" onClick={onOpenProfiles} className="w-full text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 cursor-pointer">
          <span className="block text-sm font-semibold">Koordinatı olmayan {noCoord.length} bahçe</span>
          <span className="block text-xs text-slate-500">{noCoord.slice(0, 6).map(p => p.name).join(', ')} — Profiller'de enlem / boylam girin</span>
        </button>
      )}
      <p className="text-[11px] text-slate-500 px-1">"+N gün": {lowName}'a göre yükseklik farkından kaba gecikme (Hopkins: ~4 gün / 122 m). Kesin tarih gün-derece ile hesaplanır. Soğuk ihtiyacı (%): meyve türüne göre kaba değer (kiraz 900, elma 1000, şeftali 650 saat…); her yıl kendi sonuçlarımızla düzeltilecek. Kaynak: Open-Meteo.</p>
    </div>
  );
}

/** v52 — Tek bahçenin iklim kartı (Bahçeler › bahçe › İklim sekmesi). Yükseklik farkı tüm bahçelerin en alçağına göre. */
export function OrchardClimateCard({ name, onOpenProfiles }: { name: string; onOpenProfiles: () => void }) {
  const orchards = useLocationProfiles('ORCHARD');
  const points = useMemo(() => orchards.map(o => ({ name: o.name, lat: Number(o.fields?.lat) || undefined, lon: Number(o.fields?.lon) || undefined, fields: o.fields || {} })), [orchards]);
  const me = points.filter(p => p.name === name);
  const { data, loading } = useOrchardClimate(me);
  const elevs = useElevations(points);
  const i = points.findIndex(p => p.name === name);
  const known = elevs.filter((e): e is number => e !== undefined);
  const low = known.length ? Math.min(...known) : undefined;
  const e = i >= 0 ? elevs[i] : undefined;
  const rel = e !== undefined && low !== undefined && e - low >= 50 ? `+${Math.round((e - low) * HOPKINS_DAYS_PER_M)} gün` : '';
  const c = data[name];
  if (!me.length || me[0].lat === undefined || me[0].lon === undefined) return (
    <button type="button" onClick={onOpenProfiles} className="w-full text-left rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900 cursor-pointer">Bu bahçenin konumu girilmemiş — iklim için Profil'den enlem / boylam girin ›</button>
  );
  if (!c) return <p className="text-sm text-slate-500 flex items-center gap-2">{loading ? <><RefreshCw className="w-4 h-4 animate-spin" />İklim verisi yükleniyor…</> : 'İklim verisi alınamadı.'}</p>;
  return <Card c={c} elev={e} rel={rel} onOpenProfiles={onOpenProfiles} />;
}
