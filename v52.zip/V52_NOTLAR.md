# V52 — Alt menü Ana·Bahçeler·+·Depolar·Menü · bahçe içi sekmeler (Özet·Takvim·Testler·İklim·Profil) · yeni saha testi formu

- `src/App.tsx` — `859a0929cf721cb6c13a894dc0909fade058272ee762b6b6694eeb6b491de72c`
- `src/components/common/MobileBottomBar.tsx` — `5d82d4f1776accf1c41d7663f2752f351bfda5e0d60018f007ea42b3a0e525a5`
- `src/components/portal/HomeMenu.tsx` — `3dd29d05f007c00687213a9e3e5851837d9b453dc698acc90a5eeb5c67c13e36`
- `src/components/dashboard/HomeDashboard.tsx` — `60fe0cc5100b3fc886c60f3b160cbf805faead0af5f1006157e9b6a426b08a9f`
- `src/components/views/OrchardCardsView.tsx` — `fb55ea8738aad4884e93ee47926eb16e292c462bafe2e12334a7a8dbe93bd9ef`
- `src/components/views/ClimateView.tsx` — `24c08d07d960df52d6f3140ad2b5b46012bbd9202bb078c839b9bb5e90b360c2`
- `src/components/forms/QuickTestForm.tsx` — `84cf29771f1596a4acd4b5a205082c77e210f8d95f972db94f8a8d937109c984`

Yeni: src/components/forms/QuickTestForm.tsx. Eski FieldForm silinmedi (eski kayıt düzenleme + 'ayrıntılı form'). Firestore kuralı değişmedi. TAM_LISTE: 205.
