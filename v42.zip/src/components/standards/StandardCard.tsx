import React from 'react';
import { BookCheck, ExternalLink } from 'lucide-react';
import { findStandard, STATUS_LABEL, BASE_REQUIREMENTS, StdEntry } from '../../config/standardsCatalog';

/**
 * v4.2 — Seçilen ürünün standart özeti (OECD / UNECE · en sıkı değer geçerli).
 * Test formunda ürünün altında görünür; ölçüm yapılacak sınırları ve kaynağını gösterir.
 */
const TONE: Record<StdEntry['status'], string> = {
  VERIFIED: 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200 dark:border-emerald-900',
  INTERNAL: 'bg-amber-50 text-amber-900 border-amber-200 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-900',
  TO_VERIFY: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700',
  PLATFORM: 'bg-sky-50 text-sky-800 border-sky-200 dark:bg-sky-950/40 dark:text-sky-200 dark:border-sky-900',
};

export const StandardCard: React.FC<{ product?: string; entry?: StdEntry; compact?: boolean }> = ({ product, entry, compact }) => {
  const e = entry || findStandard(product);
  if (!e) return null;
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-sm">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <BookCheck className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-bold text-slate-900 dark:text-white truncate">{e.product}</span>
          <span className="text-xs text-slate-500 truncate">{e.code}</span>
        </div>
        <span className={`shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold border ${TONE[e.status]}`}>{STATUS_LABEL[e.status]}</span>
      </div>
      <dl className="mt-2 space-y-1.5">
        <div>
          <dt className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Uluslararası şart (UNECE = OECD)</dt>
          <dd className="text-slate-800 dark:text-slate-100">{e.maturity}</dd>
        </div>
        {e.internal && (
          <div>
            <dt className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">MIWE hedefi</dt>
            <dd className="text-slate-700 dark:text-slate-300">{e.internal}</dd>
          </div>
        )}
        {!compact && (
          <div>
            <dt className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Taban (tüm sınıflar)</dt>
            <dd className="text-slate-600 dark:text-slate-400 text-xs">{BASE_REQUIREMENTS}</dd>
          </div>
        )}
        {e.note && <dd className="text-xs text-slate-500">{e.note}</dd>}
      </dl>
      {e.source && (
        <a href={e.source.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline">
          Kaynak: {e.source.label} <ExternalLink className="w-3 h-3" />
        </a>
      )}
      <p className="mt-1 text-[11px] text-slate-500">Kural: en sıkı değer geçerli · yerel standart daha sıkıysa yerel uygulanır.</p>
    </div>
  );
};

export default StandardCard;
