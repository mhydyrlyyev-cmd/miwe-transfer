import React, { useMemo, useState } from 'react';
import { X, Search, BookCheck } from 'lucide-react';
import { STANDARDS_CATALOG, STATUS_LABEL, StdStatus, BASE_REQUIREMENTS } from '../../config/standardsCatalog';
import { StandardCard } from './StandardCard';

/** v4.2 — Ana menü › Raporlar › Standart kataloğu */
interface Props { isOpen: boolean; onClose: () => void }

const FILTERS: (StdStatus | 'ALL')[] = ['ALL', 'VERIFIED', 'PLATFORM', 'INTERNAL', 'TO_VERIFY'];

export const StandardsCatalogModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [q, setQ] = useState('');
  const [f, setF] = useState<StdStatus | 'ALL'>('ALL');
  const list = useMemo(() => {
    const qq = q.trim().toLocaleLowerCase('tr');
    return STANDARDS_CATALOG.filter(e => (f === 'ALL' || e.status === f) && (!qq || `${e.product} ${e.code}`.toLocaleLowerCase('tr').includes(qq)));
  }, [q, f]);
  if (!isOpen) return null;
  const count = (s: StdStatus | 'ALL') => (s === 'ALL' ? STANDARDS_CATALOG.length : STANDARDS_CATALOG.filter(e => e.status === s).length);

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full sm:max-w-3xl max-h-[92vh] flex flex-col bg-slate-50 dark:bg-slate-950 rounded-t-3xl sm:rounded-3xl shadow-2xl" onClick={e => e.stopPropagation()} role="dialog" aria-label="Standart kataloğu">
        <div className="flex items-center justify-between gap-3 px-5 py-4 bg-white dark:bg-slate-900 rounded-t-3xl border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center"><BookCheck className="w-5 h-5" /></span>
            <div>
              <div className="font-bold text-slate-900 dark:text-white">Standart kataloğu</div>
              <div className="text-xs text-slate-500">OECD / UNECE · en sıkı değer geçerli</div>
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Kapat"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-5 py-3 space-y-2 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <label className="relative block">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Ürün veya kod ara…" className="w-full min-h-[40px] pl-9 pr-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
          </label>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {FILTERS.map(s => (
              <button key={s} type="button" onClick={() => setF(s)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer ${f === s ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'}`}>
                {s === 'ALL' ? 'Tümü' : STATUS_LABEL[s]} ({count(s)})
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 text-xs text-slate-600 dark:text-slate-400">
            <span className="font-bold text-slate-800 dark:text-slate-200">Taban (tüm ürünler, tüm sınıflar): </span>{BASE_REQUIREMENTS}
          </div>
          {list.map(e => <StandardCard key={e.key} entry={e} compact />)}
          {list.length === 0 && <p className="py-10 text-center text-sm text-slate-500">Eşleşen ürün yok.</p>}
        </div>
      </div>
    </div>
  );
};

export default StandardsCatalogModal;
