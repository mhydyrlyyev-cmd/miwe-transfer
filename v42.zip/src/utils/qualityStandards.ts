import { SpecialCropType, StandardQualityClassKey } from '../types';

export type QualityStandardOrg =
  | 'OECD'
  | 'USDA'
  | 'UNECE'
  | 'TESCO'
  | 'KIPA'
  | 'PAZAR'
  | 'FREEZE_DRY'
  | 'JUICE_CONCENTRATE'
  | 'TM_OBA_HOJALYK'
  | 'GENERAL';

export interface StandardOrgInfo {
  key: QualityStandardOrg;
  name: string;
  shortName: string;
  country: string;
  badgeColor: string;
  description: string;
  referenceCode?: string;
}

export const QUALITY_STANDARDS_ORGS: Record<QualityStandardOrg, StandardOrgInfo> = {
  OECD: {
    key: 'OECD',
    name: 'OECD Meyve & Sebze Uluslararası Şeması',
    shortName: 'OECD Scheme',
    country: 'Uluslararası / International',
    badgeColor: 'bg-blue-900 text-blue-100 border-blue-600',
    description: 'OECD Uluslararası Meyve ve Sebze Kalite Standartları ve İhracat Normları',
    referenceCode: 'OECD Fruit & Vegetables Scheme (2025/2026)'
  },
  UNECE: {
    key: 'UNECE',
    name: 'UNECE FFV Taze Meyve & Sebze Standartları',
    shortName: 'UNECE FFV',
    country: 'Avrupa / Europe',
    badgeColor: 'bg-emerald-900 text-emerald-100 border-emerald-600',
    description: 'BM Avrupa Ekonomik Komisyonu Taze Meyve/Sebze (FFV) ve Kuru Meyve (DDP) Standartları',
    referenceCode: 'UNECE FFV-01..64 / DDP-01..35'
  },
  USDA: {
    key: 'USDA',
    name: 'USDA Tarım Bakanlığı Kalite Standartları',
    shortName: 'USDA Grades',
    country: 'ABD / USA',
    badgeColor: 'bg-indigo-900 text-indigo-100 border-indigo-600',
    description: 'ABD Tarım Bakanlığı (AMS) Taze Meyve ve Sebze Derecelendirme Normları',
    referenceCode: 'USDA AMS Fresh Produce Grades'
  },
  TESCO: {
    key: 'TESCO',
    name: 'Tesco Nurture & Commercial Produce Specs',
    shortName: 'TESCO Specs',
    country: 'Birleşik Krallık / UK Retail',
    badgeColor: 'bg-rose-900 text-rose-100 border-rose-600',
    description: 'Tesco Global Gıda Güvenliği ve Süpermarket Perakende Kalite Şartnamesi',
    referenceCode: 'Tesco Technical & Nurture Spec v11'
  },
  KIPA: {
    key: 'KIPA',
    name: 'Zincir Mağaza & Süpermarket Dağıtım Şartnamesi',
    shortName: 'Market Zinciri',
    country: 'Perakende / Retail Chain',
    badgeColor: 'bg-amber-900 text-amber-100 border-amber-600',
    description: 'Ulusal ve Bölgesel Süpermarket Dağıtım Merkezleri Mal Kabul Şartnamesi',
    referenceCode: 'FSSC 22000 Perakende Mal Kabul'
  },
  PAZAR: {
    key: 'PAZAR',
    name: 'Pazar Kalitesi (İç Pazar & Toptancı Hal Standardı)',
    shortName: 'Pazar Kalitesi',
    country: 'İç Pazar / Hal',
    badgeColor: 'bg-teal-900 text-teal-100 border-teal-600',
    description: 'Günlük taze iç pazar, yerel hal ve hızlı tüketim için esnek kalibre ve olgunluk standardı',
    referenceCode: 'UNECE Sınıf II / TDS İç Pazar Hal Normu'
  },
  FREEZE_DRY: {
    key: 'FREEZE_DRY',
    name: 'Freeze & Dry (Liyofilizasyon Kurutma İşleme Standardı)',
    shortName: 'Freeze & Dry',
    country: 'Endüstriyel Liyofilizasyon',
    badgeColor: 'bg-purple-900 text-purple-100 border-purple-500',
    description: '-40°C şoklama ve vakum süblimasyon için yüksek kuru madde, Brix ve dilim bütünlüğü standardı',
    referenceCode: 'Codex Alimentarius / ISO 22000 Lyophilization Spec'
  },
  JUICE_CONCENTRATE: {
    key: 'JUICE_CONCENTRATE',
    name: 'Konsantre, Püre & Meyve Suyu İşleme Standardı',
    shortName: 'Konsantre / Meyve Suyu',
    country: 'Endüstriyel İçecek',
    badgeColor: 'bg-orange-900 text-orange-100 border-orange-500',
    description: 'Meyve suyu, nektar, püre ve 65-70°Bx konsantre üretimi için Brix/Asitlik ve pres randımanı normu',
    referenceCode: 'AIJN Code of Practice & Codex Stan 247-2005'
  },
  TM_OBA_HOJALYK: {
    key: 'TM_OBA_HOJALYK',
    name: 'Türkmenistan Oba Hojalyk & Milli Zirai Kalite Standardı',
    shortName: 'TM Oba Hojalyk',
    country: 'Türkmenistan / TDS',
    badgeColor: 'bg-green-900 text-green-100 border-green-500',
    description: 'Türkmenistan ikliminde (Garahan, Saywan, Gursak, Bagyr) yetişen çeşitler için ulusal kalite normu',
    referenceCode: 'TDS / Türkmenistan Oba Hojalyk & Kitaphana.net Zirai Külliyatı'
  },
  GENERAL: {
    key: 'GENERAL',
    name: 'Genel Tarımsal Kalite & Depolama Standardı',
    shortName: 'Genel Standart',
    country: 'Genel / Standard',
    badgeColor: 'bg-slate-800 text-slate-100 border-slate-600',
    description: 'Genel ihracat, iç pazar ve soğuk hava depolama asgari kalite standartları',
    referenceCode: 'Genel Agronomik Kabul Normu'
  }
};

export interface CropQualitySpec {
  cropType: SpecialCropType;
  cropNameTr: string;
  cropNameEn: string;
  icon: string;
  defaultStandard: QualityStandardOrg;
  standards: Partial<Record<QualityStandardOrg, {
    minBrix: number;
    optimumBrixRange?: [number, number];
    minHardnessKgCm2?: number;
    maxHardnessKgCm2?: number;
    minSpecialMetric?: number;
    maxSpecialMetric?: number;
    specialMetricLabel?: string;
    specialMetricUnit?: string;
    maxDefectPercent: number; // Max izin verilen kusur toleransı
    minColorationPercent: number; // Min renklenme
    maxNitrateMgKg: number;
    visualCriteria: string;
    notes: string;
  }>>;
}

export const CROP_QUALITY_SPECS: Record<SpecialCropType, CropQualitySpec> = {
  NONE: {
    cropType: 'NONE',
    cropNameTr: 'Standart Meyve / Sebze',
    cropNameEn: 'Standard Fruit / Veg',
    icon: '🌱',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 10.0,
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 9.0,
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 60.0,
        visualCriteria: 'Temiz, sağlam, çürüksüz, zararlı ve hastalık hasarı bulunmayan ürün.',
        notes: 'UNECE Genel Ticari Kalite Standardı'
      }
    }
  },
  MANGO: {
    cropType: 'MANGO',
    cropNameTr: 'Mango',
    cropNameEn: 'Mango (Mangifera indica)',
    icon: '🥭',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 13.0,
        optimumBrixRange: [13.5, 17.0],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 15.0, // Kuru madde %
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'OECD Sınıf I: Omuz dolgunluğu tam, sap temiz kesilmiş (10-20mm), antraknoz lekesiz, latex akıntısız, canlı kabuk rengi.',
        notes: 'OECD Mango Standardı (Ref. FFV-45): Hasatta minimum %15 kuru madde ve 13°Bx aranır.'
      },
      UNECE: {
        minBrix: 12.0,
        optimumBrixRange: [13.0, 16.5],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 8.5,
        minSpecialMetric: 14.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 40,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'UNECE FFV-45 Sınıf I: Meyve şekli karakteristik, sap yarasız, kabuk çatlağı yok.',
        notes: 'Avrupa pazarı minimum gereksinimleri.'
      },
      USDA: {
        minBrix: 12.5,
        optimumBrixRange: [13.0, 16.0],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 14.5,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter)',
        specialMetricUnit: '%',
        maxDefectPercent: 7.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'U.S. Fancy / No. 1: Olgunlaşmış ancak aşırı yumuşamamış, lekesiz.',
        notes: 'USDA Mango Standartları (7 CFR 51).'
      },
      TESCO: {
        minBrix: 13.5,
        optimumBrixRange: [14.0, 18.0],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 16.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter)',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Gold Spec: Üstün yeme kalitesi (Ready-to-Eat), mükemmel sarı-turuncu et rengi, sıfır iç kararma.',
        notes: 'Tesco Premium Tedarik Standardı (Kuru Madde min %16).'
      },
      KIPA: {
        minBrix: 13.0,
        optimumBrixRange: [13.5, 17.0],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 15.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'Kipa Sınıf 1: Homojen kalibre, taze görünüm, raf ömrü min 5 gün.',
        notes: 'Kipa Süpermarket Mal Kabul Kriteri.'
      }
    }
  },
  PINEAPPLE: {
    cropType: 'PINEAPPLE',
    cropNameTr: 'Ananas',
    cropNameEn: 'Pineapple (Ananas comosus)',
    icon: '🍍',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 12.0,
        optimumBrixRange: [12.5, 15.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 1.0, // Camsılaşma Skalası (1-3 Kabul, 4 Red)
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'İç Şeffaflık / Camsılaşma Skalası (1-4)',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'OECD Sınıf I: Taç yaprakları (Crown) tek, dik ve taze (meyve boyunun 1-1.5 katı), kabuk gözleri dolgun, sap 20mm altı.',
        notes: 'OECD Ananas Standardı (FFV-49): Min %12 Brix ve 1-3 translucency.'
      },
      UNECE: {
        minBrix: 12.0,
        optimumBrixRange: [12.0, 14.5],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 1.0,
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'İç Şeffaflık / Camsılaşma Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 40,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'UNECE FFV-49: Meyve tabanından itibaren sararma C1-C3 aşaması, kabuk yanığı ve iç kararma yok.',
        notes: 'UNECE Avrupa Standardı.'
      },
      USDA: {
        minBrix: 11.5,
        optimumBrixRange: [12.0, 14.5],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 1.0,
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'İç Şeffaflık Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 6.0,
        minColorationPercent: 45,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'U.S. Fancy: Simetrik silindirik meyve, canlı yeşil taç, küfsüz dip sap.',
        notes: 'USDA Pineapple Grades (7 CFR 51).'
      },
      TESCO: {
        minBrix: 13.0,
        optimumBrixRange: [13.5, 16.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 6.5,
        minSpecialMetric: 2.0,
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'İç Şeffaflık Skalası (Optimum 2-3)',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 3.0,
        minColorationPercent: 65,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Extra Sweet: MD2 çeşidi, zengin altın sarısı kabuk (C3), tatlı aroma, sıfır siyah kalp (black heart).',
        notes: 'Tesco Kalite Şartnamesi (min 13°Bx).'
      },
      KIPA: {
        minBrix: 12.5,
        optimumBrixRange: [13.0, 15.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 1.0,
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'Camsılaşma Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'Kipa Sınıf 1: Sağlam kabuk yapısı, fermente koku içermeyen taze ürün.',
        notes: 'Kipa Süpermarket Kabul Standardı.'
      }
    }
  },
  AVOCADO: {
    cropType: 'AVOCADO',
    cropNameTr: 'Avokado',
    cropNameEn: 'Avocado (Persea americana)',
    icon: '🥑',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 6.0,
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 21.0, // Kuru madde % (Hass için yasal min %21.0)
        maxSpecialMetric: 32.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter %)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'OECD Sınıf I: Meyve sapı temiz kesilmiş (<10mm), kabuk yanığı ve sürtünme lekesi max %5, iç liflenme (vascular browning) yok.',
        notes: 'OECD Avokado Standardı (FFV-42): Hass çeşidi için zorunlu yasal kuru madde min %21.0 (Fuerte: min %19.0).'
      },
      UNECE: {
        minBrix: 6.0,
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 21.0,
        maxSpecialMetric: 30.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter %)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'UNECE FFV-42: Sağlam, sert, olgunlaşma yeteneğine sahip, mekanik yarasız.',
        notes: 'Avrupa Birliği Ticaret Normu.'
      },
      USDA: {
        minBrix: 6.0,
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 8.5,
        minSpecialMetric: 21.5,
        maxSpecialMetric: 30.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter %)',
        specialMetricUnit: '%',
        maxDefectPercent: 6.0,
        minColorationPercent: 55,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'U.S. No. 1: Şekil bozukluğu olmayan, kabuk pası (scab) <%5 olan homojen ürün.',
        notes: 'USDA Avocados Standards.'
      },
      TESCO: {
        minBrix: 6.5,
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 23.0,
        maxSpecialMetric: 28.0,
        specialMetricLabel: 'Kuru Madde Oranı (Tesco Min %23)',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 35.0,
        visualCriteria: 'Tesco Ripe & Ready: Yağ oranı yüksek (min %23 kuru madde), mükemmel kremsi doku, sıfır iç kararma.',
        notes: 'Tesco Premium Kalite Şartnamesi.'
      },
      KIPA: {
        minBrix: 6.0,
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 8.5,
        minSpecialMetric: 21.5,
        maxSpecialMetric: 30.0,
        specialMetricLabel: 'Kuru Madde Oranı (Dry Matter %)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'Kipa Sınıf 1: Sertlik ve olgunluk seviyesi homojen.',
        notes: 'Kipa Mal Kabul Standardı.'
      }
    }
  },
  POMEGRANATE: {
    cropType: 'POMEGRANATE',
    cropNameTr: 'Nar',
    cropNameEn: 'Pomegranate (Punica granatum)',
    icon: '🔴',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 14.0,
        optimumBrixRange: [14.5, 17.5],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 40.0, // Meyve suyu randımanı %
        specialMetricLabel: 'Meyve Suyu Randımanı (Juice Yield)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'OECD Sınıf I: Taç yaprakları (Calyx) sağlam ve temiz, kabuk yarılması/çatlağı yok, güneş yanığı lekesiz, koyu kırmızı ariller.',
        notes: 'OECD Nar Standardı: Min %14 Brix ve min %40 meyve suyu randımanı.'
      },
      UNECE: {
        minBrix: 14.0,
        optimumBrixRange: [14.0, 17.0],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 38.0,
        specialMetricLabel: 'Meyve Suyu Randımanı',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'UNECE FFV Standardı: Sağlam calyx, homojen büyüklük, kabuk çatlağı bulunmayan meyve.',
        notes: 'UNECE Nar Ticari Normu.'
      },
      USDA: {
        minBrix: 13.5,
        optimumBrixRange: [14.0, 17.0],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 40.0,
        specialMetricLabel: 'Meyve Suyu Randımanı',
        specialMetricUnit: '%',
        maxDefectPercent: 6.0,
        minColorationPercent: 65,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'U.S. No. 1: Dış kabuk lekesiz, çekirdek sertliği çeşide uygun.',
        notes: 'USDA Pomegranate Standards.'
      },
      TESCO: {
        minBrix: 15.0,
        optimumBrixRange: [15.5, 18.0],
        minHardnessKgCm2: 5.5,
        maxHardnessKgCm2: 8.5,
        minSpecialMetric: 45.0,
        specialMetricLabel: 'Meyve Suyu Randımanı (Tesco Min %45)',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Wonderful Spec: Derin yakut kırmızısı ariller, yüksek antioksidan içeriği, min %45 meyve suyu.',
        notes: 'Tesco Süpermarket Tedarik Şartnamesi.'
      },
      KIPA: {
        minBrix: 14.5,
        optimumBrixRange: [14.5, 17.5],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 9.0,
        minSpecialMetric: 42.0,
        specialMetricLabel: 'Meyve Suyu Randımanı',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'Kipa Sınıf 1: Parlak kırmızı kabuk, taze taç yapısı.',
        notes: 'Kipa Nar Kabul Kriteri.'
      }
    }
  },
  PLUM: {
    cropType: 'PLUM',
    cropNameTr: 'Erik',
    cropNameEn: 'Plum (Prunus domestica / salicina)',
    icon: '🟣',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 12.0,
        optimumBrixRange: [12.5, 16.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 6.0,
        minSpecialMetric: 80.0, // Mumsu Pus Örtüsü %
        specialMetricLabel: 'Mumsu Pus Örtüsü (Bloom Wax)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'OECD Sınıf I: Doğal beyaz mumsu pus tabakası bozulmamış (>%80), sap sağlam ve mevcut, çatlak ve dolu yarası yok.',
        notes: 'OECD Erik Standardı (FFV-29): Min 12°Bx ve 3.5-6.0 kg/cm² sertlik.'
      },
      UNECE: {
        minBrix: 12.0,
        optimumBrixRange: [12.0, 15.5],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 6.0,
        minSpecialMetric: 75.0,
        specialMetricLabel: 'Mumsu Pus Örtüsü',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'UNECE FFV-29: Meyve saplı, et dokusu sıkı, çeşidin tipik rengini almış.',
        notes: 'UNECE Avrupa Normu.'
      },
      USDA: {
        minBrix: 11.5,
        optimumBrixRange: [12.0, 15.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 6.5,
        minSpecialMetric: 75.0,
        specialMetricLabel: 'Mumsu Pus Örtüsü',
        specialMetricUnit: '%',
        maxDefectPercent: 6.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'U.S. Fancy: İyi olgunlaşmış ancak aşırı yumuşamamış, lekesiz.',
        notes: 'USDA Plums and Prunes Standards.'
      },
      TESCO: {
        minBrix: 13.0,
        optimumBrixRange: [13.5, 17.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 5.5,
        minSpecialMetric: 85.0,
        specialMetricLabel: 'Mumsu Pus Örtüsü (Tesco >%85)',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 85,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Sweet & Juicy: Kusursuz pus örtüsü, tatlı-asit dengesi mükemmel, basınca dayanıklı.',
        notes: 'Tesco Perakende Kalite Şartnamesi.'
      },
      KIPA: {
        minBrix: 12.5,
        optimumBrixRange: [13.0, 16.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 6.0,
        minSpecialMetric: 80.0,
        specialMetricLabel: 'Mumsu Pus Örtüsü',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'Kipa Sınıf 1: Kalibrasyon homojen, ezik ve çizik içermeyen taze ürün.',
        notes: 'Kipa Mal Kabul Standardı.'
      }
    }
  },
  PISTACHIO: {
    cropType: 'PISTACHIO',
    cropNameTr: 'Antep Fıstığı',
    cropNameEn: 'Pistachio (Pistacia vera)',
    icon: '🥜',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 4.0,
        minHardnessKgCm2: 8.0,
        maxHardnessKgCm2: 25.0,
        minSpecialMetric: 85.0, // Doğal çıtlaklık %
        maxSpecialMetric: 7.0,  // Depo Nemi % Max (Aflatoksin Güvenliği)
        specialMetricLabel: 'Doğal Çıtlaklık Oranı (Split Shell %)',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 30.0,
        visualCriteria: 'UNECE DDP-09: Doğal çıtlaklık >%85, kapalı tane <%5, boş/kör tane <%2, nem <%7 (Aspergillus/Aflatoksin önleme), zümrüt yeşili iç.',
        notes: 'UNECE Sert Kabuklu Meyveler Standardı (DDP-09): Depo nemi <%7.0 olmak zorundadır.'
      },
      OECD: {
        minBrix: 4.0,
        minHardnessKgCm2: 8.0,
        maxHardnessKgCm2: 25.0,
        minSpecialMetric: 85.0,
        maxSpecialMetric: 7.0,
        specialMetricLabel: 'Doğal Çıtlaklık Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 30.0,
        visualCriteria: 'OECD Uluslararası Standardı: Mekanik çatlatma olmayan doğal çıtlak, açık krem kabuk.',
        notes: 'OECD Kuruyemiş Standardı.'
      },
      USDA: {
        minBrix: 4.0,
        minHardnessKgCm2: 8.0,
        maxHardnessKgCm2: 25.0,
        minSpecialMetric: 90.0,
        maxSpecialMetric: 7.0,
        specialMetricLabel: 'Doğal Çıtlaklık (U.S. Fancy min %90)',
        specialMetricUnit: '%',
        maxDefectPercent: 2.5,
        minColorationPercent: 85,
        maxNitrateMgKg: 30.0,
        visualCriteria: 'U.S. Fancy: Kabuk lekesiz, çıtlama aralığı düzgün, iç dolgunluğu >%95.',
        notes: 'USDA Pistachio Nuts Standards.'
      },
      TESCO: {
        minBrix: 4.0,
        minHardnessKgCm2: 8.0,
        maxHardnessKgCm2: 25.0,
        minSpecialMetric: 88.0,
        maxSpecialMetric: 6.5,
        specialMetricLabel: 'Doğal Çıtlaklık (Tesco min %88)',
        specialMetricUnit: '%',
        maxDefectPercent: 2.0,
        minColorationPercent: 90,
        maxNitrateMgKg: 25.0,
        visualCriteria: 'Tesco Premium Nuts: Nem <%6.5, sıfır acılaşma/ransidite, mikrobiyolojik ve Aflatoksin B1/Toplam test onaylı.',
        notes: 'Tesco Sert Kabuklu Kalite Şartnamesi.'
      },
      KIPA: {
        minBrix: 4.0,
        minHardnessKgCm2: 8.0,
        maxHardnessKgCm2: 25.0,
        minSpecialMetric: 85.0,
        maxSpecialMetric: 7.0,
        specialMetricLabel: 'Doğal Çıtlaklık Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 30.0,
        visualCriteria: 'Kipa Sınıf 1: Çıtlaklık oranı yüksek, yabancı madde içermeyen paketli/dökme ürün.',
        notes: 'Kipa Kuruyemiş Kabul Standardı.'
      }
    }
  },
  APPLE_PEAR: {
    cropType: 'APPLE_PEAR',
    cropNameTr: 'Elma / Armut',
    cropNameEn: 'Apple & Pear',
    icon: '🍎',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 12.0,
        optimumBrixRange: [12.5, 15.0],
        minHardnessKgCm2: 5.5,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 3.5, // Nişasta 1-10
        maxSpecialMetric: 6.5,
        specialMetricLabel: 'Nişasta-İyot Skalası (Optimum 3.5-6.5)',
        specialMetricUnit: '1-10',
        maxDefectPercent: 4.0,
        minColorationPercent: 65,
        maxNitrateMgKg: 60.0,
        visualCriteria: 'OECD Sınıf I: Sap sağlam, meyve eti gevreklik ve sertliği yerinde, pas (russeting) tolerans sınırında.',
        notes: 'OECD Elma & Armut Standardı (FFV-01).'
      },
      UNECE: {
        minBrix: 11.5,
        optimumBrixRange: [12.0, 14.5],
        minHardnessKgCm2: 5.0,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 3.0,
        maxSpecialMetric: 7.0,
        specialMetricLabel: 'Nişasta Skalası',
        specialMetricUnit: '1-10',
        maxDefectPercent: 5.0,
        minColorationPercent: 50,
        maxNitrateMgKg: 60.0,
        visualCriteria: 'UNECE FFV-01: Kusursuz kabuk yapısı, homojen kalibrasyon.',
        notes: 'Avrupa Ticari Kalite Standardı.'
      },
      TESCO: {
        minBrix: 13.0,
        optimumBrixRange: [13.5, 16.0],
        minHardnessKgCm2: 6.0,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 4.0,
        maxSpecialMetric: 6.0,
        specialMetricLabel: 'Nişasta Skalası (Tesco 4-6)',
        specialMetricUnit: '1-10',
        maxDefectPercent: 2.5,
        minColorationPercent: 75,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'Tesco Crisp & Sweet: Yüksek çıtırlık, min 6.0 kg/cm² sertlik, yoğun aromatik lezzet.',
        notes: 'Tesco Premium Tedarik Standardı.'
      }
    }
  },
  TOMATO: {
    cropType: 'TOMATO',
    cropNameTr: 'Domates',
    cropNameEn: 'Tomato (Solanum lycopersicum)',
    icon: '🍅',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 4.5,
        optimumBrixRange: [4.8, 6.5],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 2.0, // Renk Skalası 1-6
        maxSpecialMetric: 5.0,
        specialMetricLabel: 'USDA Renk Skalası (1-6)',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 60.0,
        visualCriteria: 'OECD Sınıf I: Çanak yaprakları ve sap taze yeşil, tepe çatlağı (catfacing) yok, parlak pürüzsüz kabuk.',
        notes: 'OECD Domates Standardı (FFV-36).'
      },
      UNECE: {
        minBrix: 4.2,
        optimumBrixRange: [4.5, 6.0],
        minHardnessKgCm2: 3.8,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 2.0,
        maxSpecialMetric: 5.0,
        specialMetricLabel: 'Renk Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 60.0,
        visualCriteria: 'UNECE FFV-36: Salkım veya tekli, basınca dayanıklı sert et dokusu.',
        notes: 'UNECE Standardı.'
      },
      TESCO: {
        minBrix: 5.2,
        optimumBrixRange: [5.5, 7.5],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 3.0,
        maxSpecialMetric: 5.0,
        specialMetricLabel: 'Renk Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 3.0,
        minColorationPercent: 85,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'Tesco Sweet Tomatoes: Yüksek Brix (>5.2°Bx), kusursuz yeşil kaliks, homojen kızarma.',
        notes: 'Tesco Süpermarket Standardı.'
      }
    }
  },
  GRAPE: {
    cropType: 'GRAPE',
    cropNameTr: 'Üzüm',
    cropNameEn: 'Table Grape (Vitis vinifera)',
    icon: '🍇',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 16.0,
        optimumBrixRange: [17.0, 21.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 18.0, // Brix/Asit Oranı
        specialMetricLabel: 'Brix / Asit Oranı (Şeker/Asit Dengesi)',
        specialMetricUnit: 'Oran',
        maxDefectPercent: 4.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'OECD Sınıf I: Salkım sapı taze yeşil ve esnek, tane dökülmesi (shatter) <%3, mumsu pus tabakası mevcut.',
        notes: 'OECD Sofralık Üzüm Standardı (FFV-19).'
      },
      UNECE: {
        minBrix: 15.5,
        optimumBrixRange: [16.0, 20.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 17.0,
        specialMetricLabel: 'Brix/Asit Oranı',
        specialMetricUnit: 'Oran',
        maxDefectPercent: 5.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'UNECE FFV-19: Taneler salkıma sıkı tutunmuş, güneş yanığı ve çatlama yok.',
        notes: 'UNECE Sofralık Üzüm Standardı.'
      },
      TESCO: {
        minBrix: 17.5,
        optimumBrixRange: [18.0, 22.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 6.5,
        minSpecialMetric: 20.0,
        specialMetricLabel: 'Brix/Asit Oranı (Tesco Min 20:1)',
        specialMetricUnit: 'Oran',
        maxDefectPercent: 2.5,
        minColorationPercent: 90,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Extra Sweet Grapes: Çıtır tane yapısı, yüksek şeker, yemyeşil canlı salkım sapı.',
        notes: 'Tesco Premium Üzüm Şartnamesi.'
      }
    }
  },
  POTATO: {
    cropType: 'POTATO',
    cropNameTr: 'Patates',
    cropNameEn: 'Potato (Solanum tuberosum)',
    icon: '🥔',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 4.0,
        minHardnessKgCm2: 6.0,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 1.075, // Özgül ağırlık
        specialMetricLabel: 'Özgül Ağırlık (Specific Gravity SG)',
        specialMetricUnit: 'SG',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 150.0,
        visualCriteria: 'UNECE FFV-52: Kabuk bağlamış (set skin), yeşillenme (solanin) <%2, mekanik yarasız, sürgün vermemiş, kalibre >45mm.',
        notes: 'UNECE Yemeklik ve Sanayilik Patates Standardı (FFV-52).'
      },
      OECD: {
        minBrix: 4.0,
        minHardnessKgCm2: 6.0,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 1.078,
        specialMetricLabel: 'Özgül Ağırlık (SG ≥ 1.078)',
        specialMetricUnit: 'SG',
        maxDefectPercent: 4.0,
        minColorationPercent: 65,
        maxNitrateMgKg: 120.0,
        visualCriteria: 'OECD Sınıf I: Kuru madde ≥%20, toprak kalıntısız, iç boşluk (hollow heart) ve iç kararma bulunmayan yumru.',
        notes: 'OECD Patates İhracat Standardı.'
      },
      TESCO: {
        minBrix: 4.2,
        minHardnessKgCm2: 6.5,
        maxHardnessKgCm2: 11.5,
        minSpecialMetric: 1.080,
        specialMetricLabel: 'Özgül Ağırlık (SG ≥ 1.080)',
        specialMetricUnit: 'SG',
        maxDefectPercent: 3.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 100.0,
        visualCriteria: 'Tesco Washed Potatoes: Yıkanmış parlak kabuk, sıfır yeşillenme ve sıfır uyuz (scab), indirgen şeker <%0.10.',
        notes: 'Tesco Perakende Patates Şartnamesi.'
      }
    }
  },
  ONION: {
    cropType: 'ONION',
    cropNameTr: 'Soğan',
    cropNameEn: 'Onion (Allium cepa)',
    icon: '🧅',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 8.0,
        minHardnessKgCm2: 6.0,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 90.0, // Boyun kuruluğu %
        specialMetricLabel: 'Boyun Kuruluğu & Kapanma Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 4.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 80.0,
        visualCriteria: 'OECD Sınıf I: Boyun tamamen kapalı ve kuru (≥%90), dış kabuklar parlak ve katmerli, kök temiz kesilmiş, çimlenme yok.',
        notes: 'OECD Kuru Soğan Standardı (FFV-25).'
      },
      UNECE: {
        minBrix: 7.5,
        minHardnessKgCm2: 5.5,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 88.0,
        specialMetricLabel: 'Boyun Kuruluğu Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 65,
        maxNitrateMgKg: 80.0,
        visualCriteria: 'UNECE FFV-25: Sıkı baş yapısı, minimum 2 kuru dış zırh gömleği, kalibre 40-80mm.',
        notes: 'UNECE Kuru Soğan Standardı (FFV-25).'
      },
      TESCO: {
        minBrix: 8.5,
        minHardnessKgCm2: 6.5,
        maxHardnessKgCm2: 11.5,
        minSpecialMetric: 95.0,
        specialMetricLabel: 'Boyun Kuruluğu (Tesco ≥ %95)',
        specialMetricUnit: '%',
        maxDefectPercent: 2.5,
        minColorationPercent: 80,
        maxNitrateMgKg: 70.0,
        visualCriteria: 'Tesco Class 1 Onions: Tamamen kürlenmiş kuru boyun, Botrytis boyun çürüğü %0, çift göbek yok.',
        notes: 'Tesco Soğan Tedarik Şartnamesi.'
      }
    }
  },
  CARROT: {
    cropType: 'CARROT',
    cropNameTr: 'Havuç',
    cropNameEn: 'Carrot (Daucus carota)',
    icon: '🥕',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 8.5,
        optimumBrixRange: [8.5, 11.5],
        minHardnessKgCm2: 6.5,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 0.0,
        maxSpecialMetric: 5.0, // Odunlaşma / Çatlak %
        specialMetricLabel: 'Merkez Silindir Odunlaşma / Çatlak Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 200.0,
        visualCriteria: 'UNECE FFV-10: Gevrek (kırılgan), çatallı veya ikincil köklenmemiş, yeşil/mor omuz (green shoulder) <%3, çap 20-40mm.',
        notes: 'UNECE Havuç Standardı (FFV-10): Tatlı, gevrek ve odunlaşmamış kök.'
      },
      OECD: {
        minBrix: 8.5,
        optimumBrixRange: [9.0, 12.0],
        minHardnessKgCm2: 7.0,
        maxHardnessKgCm2: 12.0,
        minSpecialMetric: 0.0,
        maxSpecialMetric: 4.0,
        specialMetricLabel: 'Merkez Odunlaşma Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 4.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 180.0,
        visualCriteria: 'OECD Sınıf I: Pürüzsüz silindirik Nantes tipi kök, canlı turuncu karoten rengi, boyuna çatlak yok.',
        notes: 'OECD Uluslararası Havuç Normu.'
      },
      TESCO: {
        minBrix: 9.2,
        optimumBrixRange: [9.5, 12.5],
        minHardnessKgCm2: 7.5,
        maxHardnessKgCm2: 11.5,
        minSpecialMetric: 0.0,
        maxSpecialMetric: 2.5,
        specialMetricLabel: 'Odunlaşma / Yeşil Omuz (Tesco Maks %2.5)',
        specialMetricUnit: '%',
        maxDefectPercent: 2.5,
        minColorationPercent: 88,
        maxNitrateMgKg: 150.0,
        visualCriteria: 'Tesco Sweet & Crunchy Carrots: Hidro-soğutulmuş (hydro-cooled), yüksek beta-karoten ve ekstra tatlı.',
        notes: 'Tesco Yıkanmış Paketli Havuç Şartnamesi.'
      }
    }
  },
  MELON_WATERMELON: {
    cropType: 'MELON_WATERMELON',
    cropNameTr: 'Kavun / Karpuz',
    cropNameEn: 'Melon & Watermelon',
    icon: '🍉',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 10.5,
        optimumBrixRange: [11.0, 14.0],
        minHardnessKgCm2: 4.0,
        maxHardnessKgCm2: 8.0,
        minSpecialMetric: 2.0, // Sap ayrılma skalası (1-3)
        specialMetricLabel: 'Sap Çatlağı / Sarı Zemin Lekesi Skalası (1-3)',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 60,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'OECD Sınıf I: Kavunda tam/yarım sap ayrılması (slip), karpuzda tereyağı sarısı zemin lekesi, çıtır et dokusu.',
        notes: 'OECD Kavun ve Karpuz Standardı.'
      },
      TESCO: {
        minBrix: 12.0,
        optimumBrixRange: [12.5, 15.0],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 7.5,
        minSpecialMetric: 3.0,
        specialMetricLabel: 'Sap Ayrılması / Olgunluk Skalası',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 3.0,
        minColorationPercent: 75,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Sweet Melons: Min 12°Bx, yoğun bal aroması, camsılaşma veya süngerleşme yok.',
        notes: 'Tesco Perakende Standardı.'
      }
    }
  },
  CORN: {
    cropType: 'CORN',
    cropNameTr: 'Mısır (Tatlı / Tane)',
    cropNameEn: 'Sweet Corn / Maize',
    icon: '🌽',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 12.0,
        optimumBrixRange: [13.0, 18.0],
        minHardnessKgCm2: 3.0,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 68.0, // Nem %
        maxSpecialMetric: 76.0,
        specialMetricLabel: 'Tane Nem Oranı (Tatlı Mısır)',
        specialMetricUnit: '% Nem',
        maxDefectPercent: 4.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'OECD Sınıf I: Koçan kılıfı (husk) taze yeşil ve nemli, püsküller açık kahve, taneler tam sıra ve süt olumunda.',
        notes: 'OECD Tatlı Mısır Standardı.'
      }
    }
  },
  PERSIMMON: {
    cropType: 'PERSIMMON',
    cropNameTr: 'Hurma / Trabzon Hurması',
    cropNameEn: 'Persimmon (Diospyros kaki)',
    icon: '🟠',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 14.0,
        optimumBrixRange: [15.0, 19.0],
        minHardnessKgCm2: 3.5,
        maxHardnessKgCm2: 7.0,
        minSpecialMetric: 1.0, // Tanen Burukluk Skalası (1=Tatlı)
        maxSpecialMetric: 2.0,
        specialMetricLabel: 'Çözünür Tanen / Burukluk Skalası (1-4)',
        specialMetricUnit: 'Skala',
        maxDefectPercent: 5.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 45.0,
        visualCriteria: 'UNECE FFV-63: Çanak yaprakları sağlam ve meyveye yapışık, parlak turuncu-kırmızı renk, burukluk giderilmiş.',
        notes: 'UNECE Trabzon Hurması Standardı.'
      }
    }
  },
  PEACH_NECTARINE: {
    cropType: 'PEACH_NECTARINE',
    cropNameTr: 'Şeftali / Nektarin',
    cropNameEn: 'Peach & Nectarine (Prunus persica)',
    icon: '🍑',
    defaultStandard: 'OECD',
    standards: {
      OECD: {
        minBrix: 10.5,
        optimumBrixRange: [11.5, 14.5],
        minHardnessKgCm2: 4.5,
        maxHardnessKgCm2: 6.5,
        minSpecialMetric: 0.0,
        maxSpecialMetric: 5.0,
        specialMetricLabel: 'Çekirdek Çatlaması Oranı (Split Pit %)',
        specialMetricUnit: '%',
        maxDefectPercent: 5.0,
        minColorationPercent: 70,
        maxNitrateMgKg: 50.0,
        visualCriteria: 'OECD Sınıf I: Meyve sertliği penetrometre ile 4.5-6.5 kg/cm², çekirdek çatlağı <%5, zengin allık rengi.',
        notes: 'OECD Şeftali ve Nektarin Standardı (FFV-26).'
      },
      TESCO: {
        minBrix: 11.5,
        optimumBrixRange: [12.0, 15.0],
        minHardnessKgCm2: 4.8,
        maxHardnessKgCm2: 6.2,
        minSpecialMetric: 0.0,
        maxSpecialMetric: 3.0,
        specialMetricLabel: 'Çekirdek Çatlağı Oranı',
        specialMetricUnit: '%',
        maxDefectPercent: 3.0,
        minColorationPercent: 80,
        maxNitrateMgKg: 40.0,
        visualCriteria: 'Tesco Ripe & Ready: Üstün sululuk ve tatlılık, çekirdek yapışması kusursuz.',
        notes: 'Tesco Taş Çekirdekli Meyve Şartnamesi.'
      }
    }
  },
  KIWI: {
    cropType: 'KIWI',
    cropNameTr: 'Kivi',
    cropNameEn: 'Kiwifruit (Actinidia)',
    icon: '🥝',
    defaultStandard: 'UNECE',
    standards: {
      UNECE: {
        minBrix: 6.2,
        minSpecialMetric: 15.0,
        specialMetricLabel: 'Kuru Madde (ortalama)',
        specialMetricUnit: '%',
        maxDefectPercent: 10.0,
        minColorationPercent: 0,
        maxNitrateMgKg: 0,
        visualCriteria: 'UNECE FFV-46: sağlam, temiz, sert; dağıtıma girişte en az 9,5 °Bx olmalı.',
        notes: 'Kaynak: UNECE FFV-46 (OECD aynı). Paketlemede ≥6,2 °Bx VEYA ortalama KM ≥%15. Kusur toleransı ürün broşüründen doğrulanacak.'
      },
      OECD: {
        minBrix: 6.2,
        minSpecialMetric: 15.0,
        specialMetricLabel: 'Kuru Madde (ortalama)',
        specialMetricUnit: '%',
        maxDefectPercent: 10.0,
        minColorationPercent: 0,
        maxNitrateMgKg: 0,
        visualCriteria: 'OECD kivi broşürü (UNECE FFV-46 yorumu).',
        notes: 'Kaynak: OECD / UNECE FFV-46. Paketlemede ≥6,2 °Bx veya KM ≥%15.'
      }
    }
  }
};

export interface MetricEvaluationItem {
  name: string;
  unit: string;
  measuredValue: number;
  targetDescription: string;
  isPassed: boolean;
  isWarning?: boolean;
  deviationNote?: string;
}

export interface CropEvaluationResult {
  cropType: SpecialCropType;
  standardOrg: QualityStandardOrg;
  standardName: string;
  overallStatus: 'PASS' | 'FAIL' | 'CONDITIONAL';
  statusBadge: string;
  statusTitle: string;
  recommendedGrade: StandardQualityClassKey;
  recommendedDecision: string;
  recommendedNextStep: string;
  shouldRerouteToFreezeDry: boolean;
  metrics: MetricEvaluationItem[];
  summaryText: string;
}

export function resolveStandardSpecForOrg(cropType: SpecialCropType, standardOrg: QualityStandardOrg) {
  const cropSpec = CROP_QUALITY_SPECS[cropType] || CROP_QUALITY_SPECS.NONE;
  const direct = cropSpec.standards[standardOrg];
  if (direct) return direct;

  const base = cropSpec.standards[cropSpec.defaultStandard] || cropSpec.standards.OECD || cropSpec.standards.UNECE || {
    minBrix: 11.0,
    minHardnessKgCm2: 4.0,
    maxHardnessKgCm2: 8.0,
    maxDefectPercent: 5.0,
    minColorationPercent: 60,
    maxNitrateMgKg: 60.0,
    visualCriteria: 'Sağlam, temiz ve kendine has görünümde.',
    notes: 'Genel kalite standardı.'
  };

  if (standardOrg === 'PAZAR') {
    return {
      ...base,
      minBrix: Math.max(8.0, Number((base.minBrix - 1.2).toFixed(1))),
      minHardnessKgCm2: base.minHardnessKgCm2 !== undefined ? Math.max(2.2, Number((base.minHardnessKgCm2 - 1.2).toFixed(1))) : undefined,
      maxHardnessKgCm2: base.maxHardnessKgCm2 !== undefined ? Number((base.maxHardnessKgCm2 + 0.5).toFixed(1)) : undefined,
      maxDefectPercent: 10.0,
      minColorationPercent: Math.max(40, (base.minColorationPercent || 60) - 15),
      visualCriteria: 'İç Pazar & Toptan Hal Standardı (UNECE Sınıf II / TDS): Hafif kabuk ve şekil kusurları kabul edilir, taze tüketime uygun olgunluk.',
      notes: 'Referans: UNECE Class II & TDS İç Pazar Taze Hal Standardı'
    };
  }

  if (standardOrg === 'FREEZE_DRY') {
    return {
      ...base,
      minBrix: Number((base.minBrix + 0.5).toFixed(1)),
      minHardnessKgCm2: base.minHardnessKgCm2 !== undefined ? 3.0 : undefined,
      maxHardnessKgCm2: base.maxHardnessKgCm2 !== undefined ? 7.8 : undefined,
      maxDefectPercent: 12.0,
      minColorationPercent: 50,
      visualCriteria: 'Freeze & Dry (Liyofilizasyon) Standardı: Dilimleme ve -40°C şoklamada hücre yapısı dağılmayacak sıkılıkta, yüksek kuru madde (≥%14) ve yüksek Brix; dış kabuk lekesi soyulmada tolere edilir ancak çürük %0 olmalıdır.',
      notes: 'Referans: Codex Alimentarius / ISO 22000 Lyophilization (Nihai Nem <%2.5)'
    };
  }

  if (standardOrg === 'JUICE_CONCENTRATE') {
    return {
      ...base,
      minBrix: Number((base.minBrix + 1.0).toFixed(1)),
      minHardnessKgCm2: base.minHardnessKgCm2 !== undefined ? 1.5 : undefined,
      maxHardnessKgCm2: base.maxHardnessKgCm2 !== undefined ? 9.5 : undefined,
      maxDefectPercent: 20.0,
      minColorationPercent: 40,
      visualCriteria: 'Konsantre, Püre & Meyve Suyu İşleme Standardı (AIJN / Codex Stan 247): Dış şekil, kalibre veya dolu izi önemsizdir; yüksek şeker (Brix), uygun pH/asitlik ve küfsüz/patulinsiz sağlam iç doku esastır.',
      notes: 'Referans: AIJN (Avrupa Meyve Suyu Birliği) Code of Practice & Codex Stan 247-2005'
    };
  }

  if (standardOrg === 'TM_OBA_HOJALYK') {
    return {
      ...base,
      minBrix: Number((base.minBrix + 0.5).toFixed(1)),
      maxDefectPercent: 6.0,
      visualCriteria: 'Türkmenistan Oba Hojalyk & Milli Zirai Standardı (TDS): Ahal (Bagyr, Garahan, Saywan, Gursak) iklim kuşağında yetişen yüksek aromalı yerel ve adapte çeşit normu.',
      notes: 'Referans: Türkmenistan Oba Hojalyk Ministrligi & Kitaphana.net Zirai Yayınları'
    };
  }

  return base;
}

/**
 * Calculates real-time PASS/FAIL verdict against the active Quality Standard
 */
export function evaluateCropQuality(params: {
  cropType: SpecialCropType;
  standardOrg: QualityStandardOrg;
  avgBrix: number;
  avgHardness: number;
  defectPercent: number;
  colorationPercent: number;
  nitrateMgKg: number;
  nitrateLimitMgKg: number;
  specialMetric1?: number;
  specialMetric2?: number;
}): CropEvaluationResult {
  const {
    cropType,
    standardOrg,
    avgBrix,
    avgHardness,
    defectPercent,
    colorationPercent,
    nitrateMgKg,
    nitrateLimitMgKg,
    specialMetric1,
    specialMetric2
  } = params;

  const standardObj = resolveStandardSpecForOrg(cropType, standardOrg);
  const orgInfo = QUALITY_STANDARDS_ORGS[standardOrg] || QUALITY_STANDARDS_ORGS.GENERAL;

  const metrics: MetricEvaluationItem[] = [];
  let failCount = 0;
  let warnCount = 0;

  // 1. Brix Değerlendirmesi
  if (standardObj && standardObj.minBrix !== undefined) {
    const minBrix = standardObj.minBrix;
    const brixPassed = avgBrix >= minBrix;
    const brixWarning = !brixPassed && avgBrix >= (minBrix - 0.8);
    
    if (!brixPassed) {
      if (brixWarning) warnCount++;
      else failCount++;
    }

    metrics.push({
      name: 'Brix (Şeker Oranı / TSS)',
      unit: '°Bx',
      measuredValue: avgBrix,
      targetDescription: `Min ${minBrix}°Bx ${standardObj.optimumBrixRange ? `(Optimum ${standardObj.optimumBrixRange[0]}-${standardObj.optimumBrixRange[1]}°Bx)` : ''}`,
      isPassed: brixPassed,
      isWarning: brixWarning,
      deviationNote: brixPassed 
        ? 'Standart şeker eşiği sağlandı' 
        : `Minimum sınırın ${(minBrix - avgBrix).toFixed(1)}°Bx altında (Yetersiz tat)`
    });
  }

  // 2. Sertlik (Penetrometre) Değerlendirmesi
  if (standardObj && (standardObj.minHardnessKgCm2 !== undefined || standardObj.maxHardnessKgCm2 !== undefined)) {
    const minH = standardObj.minHardnessKgCm2 ?? 3.5;
    const maxH = standardObj.maxHardnessKgCm2 ?? 9.5;
    const hPassed = avgHardness >= minH && avgHardness <= maxH;
    const hWarning = !hPassed && (avgHardness >= (minH - 0.5) || avgHardness <= (maxH + 0.8));

    if (!hPassed) {
      if (hWarning) warnCount++;
      else failCount++;
    }

    metrics.push({
      name: 'Et Sertliği (Penetrometre)',
      unit: 'kg/cm²',
      measuredValue: avgHardness,
      targetDescription: `${minH} - ${maxH} kg/cm²`,
      isPassed: hPassed,
      isWarning: hWarning,
      deviationNote: hPassed 
        ? 'İhracat ve depoluk sertlik aralığında' 
        : (avgHardness < minH ? `Aşırı yumuşama (-${(minH - avgHardness).toFixed(1)} kg/cm²)` : `Henüz çok sert / ham (+${(avgHardness - maxH).toFixed(1)} kg/cm²)`)
    });
  }

  // 3. Görsel Kusur & Leke Toleransı (%)
  if (standardObj && standardObj.maxDefectPercent !== undefined) {
    const maxDef = standardObj.maxDefectPercent;
    const defPassed = defectPercent <= maxDef;
    const defWarning = !defPassed && defectPercent <= (maxDef + 5.0);

    if (!defPassed) {
      if (defWarning) warnCount++;
      else failCount++;
    }

    metrics.push({
      name: 'Görsel Kusur & Leke Oranı',
      unit: '%',
      measuredValue: defectPercent,
      targetDescription: `Maks %${maxDef}`,
      isPassed: defPassed,
      isWarning: defWarning,
      deviationNote: defPassed 
        ? 'Kusur toleransı sınırları içinde (Sınıf I)' 
        : `Maksimum tolerans %${(defectPercent - maxDef).toFixed(1)} aşıldı`
    });
  }

  // 4. Renklenme / Kaplama Oranı (%)
  if (standardObj && standardObj.minColorationPercent !== undefined) {
    const minColor = standardObj.minColorationPercent;
    const colorPassed = colorationPercent >= minColor;
    const colorWarning = !colorPassed && colorationPercent >= (minColor - 15);

    if (!colorPassed) {
      if (colorWarning) warnCount++;
      else failCount++;
    }

    metrics.push({
      name: 'Meyve Renklenme / Kaplama',
      unit: '%',
      measuredValue: colorationPercent,
      targetDescription: `Min %${minColor}`,
      isPassed: colorPassed,
      isWarning: colorWarning,
      deviationNote: colorPassed ? 'Karakteristik çeşit rengi tam' : `Renk gelişimi eksik (%${colorationPercent} < %${minColor})`
    });
  }

  // 5. Nitrat Seviyesi (mg/kg)
  const nitLimit = standardObj?.maxNitrateMgKg || nitrateLimitMgKg || 60.0;
  const nitPassed = nitrateMgKg <= nitLimit;
  if (!nitPassed) failCount += 2; // Nitrat kimyasal gıda güvenliği sınırıdır, kritik red sebebidir!

  metrics.push({
    name: 'Nitrat Kalıntısı (NO₃⁻)',
    unit: 'mg/kg',
    measuredValue: nitrateMgKg,
    targetDescription: `Maks ${nitLimit} mg/kg`,
    isPassed: nitPassed,
    deviationNote: nitPassed ? 'Gıda güvenliği limitine uygun (Güvenli)' : 'DİKKAT: Yasal kimyasal nitrat limiti aşıldı! İhracat engeli!'
  });

  // 6. Özel Mahsul Metriği (Kuru Madde, Randıman, Çıtlaklık, Camsılaşma, vb.)
  if (specialMetric1 !== undefined && standardObj?.minSpecialMetric !== undefined) {
    const minSpec = standardObj.minSpecialMetric;
    const maxSpec = standardObj.maxSpecialMetric;
    let specPassed = true;
    let specWarning = false;

    if (maxSpec !== undefined && minSpec !== undefined) {
      specPassed = specialMetric1 >= minSpec && specialMetric1 <= maxSpec;
      specWarning = !specPassed && (specialMetric1 >= minSpec - 0.5 && specialMetric1 <= maxSpec + 1.0);
    } else {
      specPassed = specialMetric1 >= minSpec;
      specWarning = !specPassed && specialMetric1 >= (minSpec - 1.5);
    }

    // Antep fıstığı için özel: Depo Nemi %2 kontrolü
    if (cropType === 'PISTACHIO' && specialMetric2 !== undefined && specialMetric2 > 7.0) {
      specPassed = false;
      failCount += 2; // Aflatoksin küf riski kritik
    }

    if (!specPassed) {
      if (specWarning) warnCount++;
      else failCount++;
    }

    metrics.push({
      name: standardObj.specialMetricLabel || 'Özel Kalite Parametresi',
      unit: standardObj.specialMetricUnit || '',
      measuredValue: specialMetric1,
      targetDescription: maxSpec !== undefined ? `${minSpec} - ${maxSpec} ${standardObj.specialMetricUnit || ''}` : `Min ${minSpec} ${standardObj.specialMetricUnit || ''}`,
      isPassed: specPassed,
      isWarning: specWarning,
      deviationNote: specPassed ? 'Özel mahsul standardına uygun' : 'Özel kalite kriteri karşılanamadı'
    });
  }

  // Karar Matrisi
  let overallStatus: 'PASS' | 'FAIL' | 'CONDITIONAL' = 'PASS';
  let statusBadge = 'bg-emerald-100 text-emerald-900 border-emerald-300';
  let statusTitle = `✅ ${orgInfo.shortName} STANDARDA UYGUN (GEÇTİ)`;
  let recommendedGrade: StandardQualityClassKey = 'I (V-22) EXC';
  let recommendedDecision = `${orgInfo.shortName} Standartlarına Uygun — Taze İhracat Sevkine Hazır`;
  let recommendedNextStep = '1. Sınıf Paketleme & Soğuk Zincir Sevkiyat';
  let shouldRerouteToFreezeDry = false;
  let summaryText = `Tüm parametreler ${orgInfo.name} minimum/maksimum kriterlerini tam olarak karşılamaktadır.`;

  if (failCount === 0 && warnCount === 0 && colorationPercent >= 80 && defectPercent <= 2) {
    recommendedGrade = 'EXTRA (V-20)';
    statusTitle = `🌟 ${orgInfo.shortName} EKSTRA KALİTE / EXTRA CLASS (GEÇTİ)`;
    recommendedDecision = `${orgInfo.shortName} Ekstra Sınıf — Premium İhracat Pazarına Sevk`;
  } else if (failCount > 0 || !nitPassed) {
    overallStatus = 'FAIL';
    statusBadge = 'bg-rose-100 text-rose-900 border-rose-300';
    statusTitle = `❌ ${orgInfo.shortName} STANDART ALTI / REJECTED (KALDI)`;
    recommendedGrade = 'Standart Däl / Standart Dışı';
    recommendedDecision = 'Standart Dışı Kalite — Freeze-Dry İşleme Tesisine Yönlendir (-40°C Şoklama)';
    recommendedNextStep = 'Freeze & Dry İşleme Hattına Sevk';
    shouldRerouteToFreezeDry = true;
    summaryText = `Test sonuçları ${orgInfo.shortName} standardının altında kalmıştır (${failCount} kritik sapma). Taze sofralık ihracat yerine Freeze & Dry veya sanayi işleme hattına yönlendirilmelidir.`;
  } else if (warnCount > 0 || defectPercent > 5) {
    overallStatus = 'CONDITIONAL';
    statusBadge = 'bg-amber-100 text-amber-900 border-amber-300';
    statusTitle = `⚠️ ${orgInfo.shortName} KOŞULLU GEÇTİ / 2. SINIF (CONDITIONAL)`;
    recommendedGrade = 'II (V-24) PRM';
    recommendedDecision = `${orgInfo.shortName} 2. Sınıf Toleransında — Bölgesel / Hızlı Tüketim Sevk`;
    recommendedNextStep = '2. Sınıf Ayrıştırma & Hızlı Dağıtım';
    summaryText = `Kısmi tolerans sapmaları mevcut (${warnCount} hafif sapma). 2. Sınıf veya yerel süpermarket kanalında değerlendirilebilir.`;
  }

  return {
    cropType,
    standardOrg,
    standardName: orgInfo.name,
    overallStatus,
    statusBadge,
    statusTitle,
    recommendedGrade,
    recommendedDecision,
    recommendedNextStep,
    shouldRerouteToFreezeDry,
    metrics,
    summaryText
  };
}

export interface MultiStandardCompatibilityItem {
  orgKey: QualityStandardOrg;
  shortName: string;
  fullName: string;
  referenceCode: string;
  status: 'PASS' | 'CONDITIONAL' | 'FAIL';
  minBrixTarget: number;
  hardnessTarget: string;
  maxDefectTarget: number;
  recommendedChannel: string;
}

export function evaluateSampleAcrossAllStandards(params: {
  cropType: SpecialCropType;
  avgBrix: number;
  avgHardness: number;
  defectPercent: number;
  colorationPercent: number;
  nitrateMgKg: number;
  nitrateLimitMgKg: number;
  specialMetric1?: number;
  specialMetric2?: number;
}): MultiStandardCompatibilityItem[] {
  const orderedOrgs: QualityStandardOrg[] = [
    'OECD',
    'UNECE',
    'TESCO',
    'PAZAR',
    'FREEZE_DRY',
    'JUICE_CONCENTRATE',
    'TM_OBA_HOJALYK',
    'USDA',
    'KIPA'
  ];

  return orderedOrgs.map(orgKey => {
    const res = evaluateCropQuality({ ...params, standardOrg: orgKey });
    const spec = resolveStandardSpecForOrg(params.cropType, orgKey);
    const orgInfo = QUALITY_STANDARDS_ORGS[orgKey];

    return {
      orgKey,
      shortName: orgInfo.shortName,
      fullName: orgInfo.name,
      referenceCode: orgInfo.referenceCode || orgInfo.country,
      status: res.overallStatus,
      minBrixTarget: spec.minBrix,
      hardnessTarget: spec.minHardnessKgCm2 !== undefined ? `${spec.minHardnessKgCm2}-${spec.maxHardnessKgCm2 ?? 8.5} kg` : 'Esnek',
      maxDefectTarget: spec.maxDefectPercent,
      recommendedChannel: res.recommendedNextStep
    };
  });
}

// Türkmenistan Oba Hojalyk & Kitaphana.net Zirai Külliyatı Yerel ve Adapte Çeşit Rehberi
export interface TurkmenistanVarietyReference {
  cropTr: string;
  cropTm: string;
  varieties: string[];
  orchards: string;
  brixNorm: string;
  processingSuitability: string;
  referenceSource: string;
}

export const TURKMENISTAN_CROP_VARIETIES_GUIDE: TurkmenistanVarietyReference[] = [
  {
    cropTr: 'Şeftali & Nektarin',
    cropTm: 'Şetdaly / Nektarin',
    varieties: ['Extreme 314', 'Extreme 568', 'Extreme July', 'Extreme 28', 'Extreme Red', 'Big Top', 'Royal Summer', 'UFO-4'],
    orchards: 'Bagyr, Garahan, Saywan, Gursak',
    brixNorm: '12.0 - 15.5 °Bx (Sertlik: 4.5-6.5 kg/cm²)',
    processingSuitability: 'Taze İhracat, Pazar Kalitesi, Freeze & Dry Küp/Dilim, Püre & Nektar Konsantresi',
    referenceSource: 'Türkmenistan Oba Hojalyk / UNECE FFV-26'
  },
  {
    cropTr: 'Kiraz',
    cropTm: 'Ülje',
    varieties: ['Santina', 'Lapins', 'Early Burlat', 'Early Lory', 'Regina', 'Kordia', 'Brooks', 'Premier Giant', 'Skeena'],
    orchards: 'Garahan Teplisa, Gursak, Saywan',
    brixNorm: '15.0 - 19.0 °Bx (Kalibre: 26-30+ mm)',
    processingSuitability: 'Premium İhracat, İç Pazar, Dondurulmuş / Liyofilize (Freeze & Dry) Bütün Meyve',
    referenceSource: 'Türkmenistan Oba Hojalyk / OECD Cherry Scheme'
  },
  {
    cropTr: 'Elma & Armut',
    cropTm: 'Alma / Armyt',
    varieties: ['Early Gold', 'Gala', 'Pink Lady', 'Granny Smith', 'Chojuro (Asya Armudu)', 'Carmen', 'Santa Maria'],
    orchards: 'Saywan, Garahan (1200), Gursak',
    brixNorm: '12.0 - 14.5 °Bx (Streif SI: 0.10-0.18)',
    processingSuitability: 'CA/ULO Depolama, Freeze & Dry Cips, 70°Bx Berrak Elma/Armut Suyu Konsantresi (AIJN)',
    referenceSource: 'Kitaphana.net Zirai Külliyatı / UNECE FFV-01 & AIJN'
  },
  {
    cropTr: 'Badem',
    cropTm: 'Badam',
    varieties: ['Vairo H.S', 'Vairo M.A', 'Vairo D.M', 'Vairo TAE', 'Guara', 'Ferraduel', 'Ferragnes'],
    orchards: 'Garahan (1200 & 1628)',
    brixNorm: 'İç Randıman: %32-38 • Depo Nemi: ≤ %6.5',
    processingSuitability: 'Tenias Kurutma (Gurutma), Kalibrasyonlu İç Badem, Badem Sütü & Ezmesi Sanayi',
    referenceSource: 'UNECE DDP-06 / Türkmenistan Oba Hojalyk'
  },
  {
    cropTr: 'Erik & Hurma & Nar',
    cropTm: 'Garaly / Hurma / Nar',
    varieties: ['Pioneer', 'Black Splendor', 'Stanley (Stenli)', 'Roýal Hurma', 'Hicaz / Sumbar Narı'],
    orchards: 'Garahan (1200), Bagyr, Gursak',
    brixNorm: '13.5 - 17.5 °Bx (Nar Suyu Randımanı ≥ %42)',
    processingSuitability: 'Taze Pazar, Kuru Erik / Freeze & Dry, 65°Bx Nar Ekşisi ve Meyve Suyu Konsantresi',
    referenceSource: 'Kitaphana.net / Codex Stan 247-2005'
  },
  {
    cropTr: 'Türkmen Kavunu & Karpuzu',
    cropTm: 'Gawun / Garpyz',
    varieties: ['Waharman', 'Gurbek', 'Garrygyz', 'Gyzyl Güläbi-498', 'Ak Güläbi', 'Sary Güläbi', 'Jeýhun (Garpyz)'],
    orchards: 'Ahal, Mary, Daşoguz, Lebap',
    brixNorm: 'Waharman / Güläbi: 14.0 - 19.0 °Bx',
    processingSuitability: 'Milli İhracat, Uzun Süreli Askı Depolama, Freeze & Dry Kavun Dilimi & Kavun Kurusu (Kak)',
    referenceSource: 'Kitaphana.net (Türkmen Gawunlary) & TDS Milli Standart'
  },
  {
    cropTr: 'Soğan, Havuç & Patates (Tarla Sebze Bahçeleri)',
    cropTm: 'Sogan / Käşir / Kartoşka',
    varieties: ['Daytona (Soğan)', 'Valenciana', 'Nantes (Havuç)', 'Maestro', 'Agria (Patates)', 'Gala', 'Hermes'],
    orchards: 'Garahan Sebze Alanları, Gursak, Ahal Tarla Bahçeleri',
    brixNorm: 'Havuç: 8.5-11.5 °Bx • Soğan Boyun Kuruluğu: ≥%92 • Patates SG: ≥1.078',
    processingSuitability: 'Taze Hal & Pazar, Uzun Süreli Soğuk/Kuru Depo, Freeze & Dry Küp Sebze Çorbalık, Havuç Suyu Konsantresi',
    referenceSource: 'UNECE FFV-10 / FFV-25 / FFV-52 & Türkmenistan Oba Hojalyk'
  }
];

// ============================================================================
// DİNAMİK TEST PARAMETRELERİ YAPILANDIRMASI (CROP PARAMETER CONFIGURATION)
// Seçilen meyve veya sebze türüne göre sadece ilgili test parametrelerini sunar.
// ============================================================================

export interface CropParameterConfig {
  cropType: SpecialCropType;
  cropName: string;
  badge: string;
  // Hardness / Penetrometer
  showHardness: boolean;
  hardnessLabel: string;
  hardnessUnit: string;
  hardnessHint?: string;
  // Brix / Refractometer
  showBrix: boolean;
  brixLabel: string;
  brixUnit: string;
  brixHint?: string;
  // Diameter / Size / Caliber
  showDiameter: boolean;
  diameterLabel: string;
  diameterUnit: string;
  // Starch & Streif Index
  showStarch: boolean;
  starchLabel: string;
  // Visual & Chemical
  showColoration: boolean;
  colorationLabel: string;
  showNitrate: boolean;
  nitrateDefaultLimit: number;
  showDefects: boolean;
  defectsLabel: string;
  // Special Crop Test Integration
  hasSpecialCropTest: boolean;
  specialMetricTitle?: string;
  primaryActiveList: string[]; // Aktif rozet listesi
}

export function getCropParameterConfig(cropType: SpecialCropType, productName?: string): CropParameterConfig {
  switch (cropType) {
    case 'APPLE_PEAR':
      return {
        cropType: 'APPLE_PEAR',
        cropName: 'Elma / Armut',
        badge: '🍎 Pomolojik Test Suite',
        showHardness: true,
        hardnessLabel: 'Sertlik (Penetrometre 11mm)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'OECD FFV-01 Hedef: 5.5 - 8.5 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 12.0°Bx',
        showDiameter: true,
        diameterLabel: 'Kalibre / Çap (mm)',
        diameterUnit: 'mm',
        showStarch: true,
        starchLabel: 'Nişasta-İyot Skalası (1-10)',
        showColoration: true,
        colorationLabel: 'Kızarma / Zemin Renk Oranı (%)',
        showNitrate: true,
        nitrateDefaultLimit: 60.0,
        showDefects: true,
        defectsLabel: 'Kusur / Leke Oranı (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Nişasta & Streif İndeksi (SI)',
        primaryActiveList: ['Penetrometre Sertlik (11mm)', 'Brix Şeker (°Bx)', 'Nişasta-İyot (SI)', 'Çap (mm)', 'Kusur %']
      };

    case 'PEACH_NECTARINE':
      return {
        cropType: 'PEACH_NECTARINE',
        cropName: 'Şeftali / Nektarin',
        badge: '🍑 Sertlik & Çekirdek Testi',
        showHardness: true,
        hardnessLabel: 'Sertlik (Penetrometre 8mm Uç)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'OECD FFV-26 Hedef: 4.5 - 6.5 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 11.0 - 13.0°Bx',
        showDiameter: true,
        diameterLabel: 'Meyve Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Üst Renk / Kızarma (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Kusur & Yara Oranı (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Çekirdek Çatlağı % (Split Pit)',
        primaryActiveList: ['Penetrometre Sertlik (8mm)', 'Brix Şeker (°Bx)', 'Çekirdek Çatlağı %', 'Çap (mm)', 'Kusur %']
      };

    case 'PLUM':
      return {
        cropType: 'PLUM',
        cropName: 'Erik',
        badge: '🟣 Mumsu Pus & Sertlik',
        showHardness: true,
        hardnessLabel: 'Sertlik (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 3.5 - 6.0 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 12.0°Bx',
        showDiameter: true,
        diameterLabel: 'Çap (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Kabuk Renk Doygunluğu (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Kusur Oranı (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Mumsu Pus Örtüsü % (Bloom)',
        primaryActiveList: ['Sertlik (kg/cm²)', 'Brix Şeker (°Bx)', 'Mumsu Pus Örtüsü %', 'Çap (mm)', 'Kusur %']
      };

    case 'MANGO':
      return {
        cropType: 'MANGO',
        cropName: 'Mango',
        badge: '🥭 Kuru Madde & Yanak Sertliği',
        showHardness: true,
        hardnessLabel: 'Yanak Sertliği (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'OECD FFV-45 Hedef: 4.5 - 8.0 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 13.0°Bx',
        showDiameter: true,
        diameterLabel: 'Meyve Boyu / Kalibre (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Kabuk Zemin Sararma (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Antraknoz / Kusur (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Kuru Madde Oranı (Dry Matter %)',
        primaryActiveList: ['Kuru Madde % (Dry Matter ≥ %15)', 'Brix Şeker (°Bx)', 'Yanak Sertliği', 'Kusur %']
      };

    case 'PINEAPPLE':
      return {
        cropType: 'PINEAPPLE',
        cropName: 'Ananas',
        badge: '🍍 Translucency & Göz Rengi',
        showHardness: true,
        hardnessLabel: 'Et Sertliği (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 4.0 - 7.0 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 12.0°Bx (MD2: 13°Bx)',
        showDiameter: true,
        diameterLabel: 'Kalibre / Gövde Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Kabuk Gözü Sararma (%)',
        showNitrate: true,
        nitrateDefaultLimit: 45.0,
        showDefects: true,
        defectsLabel: 'Siyah Kalp / Kusur (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'İç Şeffaflık / Camsılaşma (1-4)',
        primaryActiveList: ['İç Camsılaşma (Translucency 1-4)', 'Brix Şeker (°Bx)', 'Kabuk Gözü Skalası', 'Kusur %']
      };

    case 'AVOCADO':
      return {
        cropType: 'AVOCADO',
        cropName: 'Avokado',
        badge: '🥑 Kuru Madde & Durofel',
        showHardness: true,
        hardnessLabel: 'Durofel / Sertlik (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 4.0 - 9.0 kg/cm²',
        showBrix: false, // Avokadoda refraktometre Brix aranmaz
        brixLabel: 'Brix (Uygulanmaz)',
        brixUnit: '°Bx',
        showDiameter: true,
        diameterLabel: 'Meyve Kalibre (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Kabuk Kararma / Olgunluk (%)',
        showNitrate: true,
        nitrateDefaultLimit: 45.0,
        showDefects: true,
        defectsLabel: 'Liflenme / Kabuk Kusuru (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Kuru Madde Oranı (Dry Matter %)',
        primaryActiveList: ['Kuru Madde % (Hass ≥ %21.0)', 'Durofel Sertlik', 'Kabuk Kusuru %', 'Çap (mm)']
      };

    case 'POMEGRANATE':
      return {
        cropType: 'POMEGRANATE',
        cropName: 'Nar',
        badge: '🔴 Meyve Suyu & Aril Testi',
        showHardness: false, // Nar dış kabuğu penetrometreyle delinmez
        hardnessLabel: 'Sertlik (Uygulanmaz)',
        hardnessUnit: 'kg/cm²',
        showBrix: true,
        brixLabel: 'Aril Meyve Suyu Brix (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 14.0°Bx (Hicaz)',
        showDiameter: true,
        diameterLabel: 'Meyve Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Kabuk Yakut Kırmızı (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Güneş Yanığı / Çatlak (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Meyve Suyu Randımanı (%)',
        primaryActiveList: ['Meyve Suyu Randımanı (≥ %40)', 'Aril Brix Şeker (°Bx)', 'Aril Rengi', 'Kabuk Kusuru %']
      };

    case 'PISTACHIO':
      return {
        cropType: 'PISTACHIO',
        cropName: 'Antep Fıstığı',
        badge: '🥜 Çıtlaklık & Depo Nemi',
        showHardness: false, // Fıstıkta meyve eti penetrometresi kullanılmaz
        hardnessLabel: 'Sertlik (Uygulanmaz)',
        hardnessUnit: '',
        showBrix: false, // Refraktometre kullanılmaz
        brixLabel: 'Brix (Uygulanmaz)',
        brixUnit: '',
        showDiameter: false, // Kalibre 100g tane adedi ile ölçülür
        diameterLabel: 'Kalibre',
        diameterUnit: '',
        showStarch: false,
        starchLabel: '',
        showColoration: false,
        colorationLabel: '',
        showNitrate: false,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Dış Kabuk Lekesi / Boş Tane (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Doğal Çıtlaklık % & Depo Nemi %',
        primaryActiveList: ['Doğal Çıtlaklık (≥ %85)', 'Depo Nemi (≤ %7.0 Aflatoksin Sınırı)', 'Boş / Fıs Tane %', 'Kusur %']
      };

    case 'TOMATO':
      return {
        cropType: 'TOMATO',
        cropName: 'Domates',
        badge: '🍅 USDA Likopen & Asitlik',
        showHardness: true,
        hardnessLabel: 'Meyve Sıkılığı / Durofel',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 2.5 - 4.5 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Kuru Madde (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 4.5°Bx',
        showDiameter: true,
        diameterLabel: 'Kalibre / Çap (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Likopen Renk Gelişimi (%)',
        showNitrate: true,
        nitrateDefaultLimit: 150.0,
        showDefects: true,
        defectsLabel: 'Çiçek Burnu Çürüğü / Çatlak (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'USDA Likopen Skalası (1-6) & TA',
        primaryActiveList: ['USDA Likopen Skalası (1-6)', 'Titre Edilebilir Asitlik (TA)', 'Brix (°Bx)', 'Meyve Sıkılığı', 'Nitrat']
      };

    case 'GRAPE':
      return {
        cropType: 'GRAPE',
        cropName: 'Sofralık Üzüm',
        badge: '🍇 Brix/Asit & Tutunma',
        showHardness: false, // Tane penetrometresi yapılmaz
        hardnessLabel: 'Sertlik (Uygulanmaz)',
        hardnessUnit: '',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 16.0°Bx',
        showDiameter: true,
        diameterLabel: 'Tane Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Salkım Renk Homojenliği (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Tane Dökülmesi / Botrytis (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Brix/Asit Oranı & Sap Tutunma Kuvveti',
        primaryActiveList: ['Brix Şeker (°Bx)', 'Brix / Asit Olgunluk (≥ 18:1)', 'Sap Tutunma Kuvveti (g)', 'Kusur %']
      };

    case 'POTATO':
      return {
        cropType: 'POTATO',
        cropName: 'Patates',
        badge: '🥔 Özgül Ağırlık & Kuru Madde',
        showHardness: false,
        hardnessLabel: 'Sertlik (Uygulanmaz)',
        hardnessUnit: '',
        showBrix: false,
        brixLabel: 'Brix (Uygulanmaz)',
        brixUnit: '',
        showDiameter: true,
        diameterLabel: 'Yumru Kalibresi (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: false,
        colorationLabel: '',
        showNitrate: true,
        nitrateDefaultLimit: 200.0,
        showDefects: true,
        defectsLabel: 'Yeşillenme / Uyuz / Kesik (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Özgül Ağırlık & Glukoz İndeksi',
        primaryActiveList: ['Özgül Ağırlık (1.075 - 1.095)', 'Kuru Madde %', 'Kızartma / Glukoz İndeksi', 'Kusur %', 'Nitrat']
      };

    case 'ONION':
      return {
        cropType: 'ONION',
        cropName: 'Soğan',
        badge: '🧅 Boyun Kuruluğu & Sıkılık',
        showHardness: true,
        hardnessLabel: 'Baş Sıkılığı / Sertlik',
        hardnessUnit: 'kg/cm²',
        showBrix: true,
        brixLabel: 'Kuru Madde / Brix (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 8.0 - 13.0°Bx',
        showDiameter: true,
        diameterLabel: 'Baş Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Dış Kabuk Parlaklık & Zırh (%)',
        showNitrate: true,
        nitrateDefaultLimit: 80.0,
        showDefects: true,
        defectsLabel: 'Sürme / Çift Baş / Boşluk (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Boyun Kuruluğu % & Katı Madde %',
        primaryActiveList: ['Boyun Kuruluğu (≥ %90-95)', 'Kuru Madde / Brix %', 'Baş Çapı (40-80mm)', 'Baş Sertliği', 'Kusur %']
      };

    case 'CARROT':
      return {
        cropType: 'CARROT',
        cropName: 'Havuç (Käşir)',
        badge: '🥕 Gevreklik, Brix & Odunlaşma',
        showHardness: true,
        hardnessLabel: 'Kök Sıkılığı / Gevreklik (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'UNECE FFV-10 Hedef: 6.5 - 11.5 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Tatlılık (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 8.5°Bx (Optimum 9-12°Bx)',
        showDiameter: true,
        diameterLabel: 'Kök Omuz Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Turuncu Karoten Renk Homojenliği (%)',
        showNitrate: true,
        nitrateDefaultLimit: 200.0,
        showDefects: true,
        defectsLabel: 'Çatallanma / Boyuna Çatlak / Yeşil Omuz (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Merkez Odunlaşma % & Yeşil Omuz %',
        primaryActiveList: ['Brix Tatlılık (≥ 8.5°Bx)', 'Kök Çapı (20-40mm)', 'Merkez Odunlaşma (<%5)', 'Yeşil Omuz %', 'Nitrat (≤200 mg/kg)']
      };

    case 'MELON_WATERMELON':
      return {
        cropType: 'MELON_WATERMELON',
        cropName: 'Kavun / Karpuz',
        badge: '🍉 Sap Çatlağı & Kabuk Kalınlığı',
        showHardness: true,
        hardnessLabel: 'Meyve Eti Sertliği (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 3.5 - 5.5 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 10.5 - 12.0°Bx',
        showDiameter: true,
        diameterLabel: 'Kalibre / Boyut (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Ground Spot & Ağ Rengi (%)',
        showNitrate: true,
        nitrateDefaultLimit: 60.0,
        showDefects: true,
        defectsLabel: 'Güneş Yanığı / Çatlak (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Sap Çatlağı (Full Slip) & Kabuk (mm)',
        primaryActiveList: ['Brix Şeker (°Bx)', 'Sap Çatlağı / Ayrılması', 'Kabuk Kalınlığı (mm)', 'Kusur %']
      };

    case 'CORN':
      return {
        cropType: 'CORN',
        cropName: 'Mısır',
        badge: '🌽 Hasat Nemi & Süt Olumu',
        showHardness: false,
        hardnessLabel: 'Sertlik (Uygulanmaz)',
        hardnessUnit: '',
        showBrix: true,
        brixLabel: 'Tatlı Mısır Brix (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 14.0°Bx',
        showDiameter: false,
        diameterLabel: 'Kalibre',
        diameterUnit: '',
        showStarch: false,
        starchLabel: '',
        showColoration: false,
        colorationLabel: '',
        showNitrate: true,
        nitrateDefaultLimit: 60.0,
        showDefects: true,
        defectsLabel: 'Koçan Boşluğu / Tane Hasarı (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Hasat / Silo Nemi % & Süt Olumu (1-5)',
        primaryActiveList: ['Hasat / Silo Nemi %', 'Süt Olumu Skalası (1-5)', 'Brix (°Bx)', 'Kusur %']
      };

    case 'PERSIMMON':
      return {
        cropType: 'PERSIMMON',
        cropName: 'Trabzon Hurması',
        badge: '🟠 Tanen Burukluğu & Nem',
        showHardness: true,
        hardnessLabel: 'Et Sertliği (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'Hedef: 4.5 - 7.0 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 14.0°Bx',
        showDiameter: true,
        diameterLabel: 'Meyve Çapı (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: '',
        showColoration: true,
        colorationLabel: 'Turuncu-Kırmızı Renk (%)',
        showNitrate: true,
        nitrateDefaultLimit: 50.0,
        showDefects: true,
        defectsLabel: 'Kabuk Lekesi / Çatlak (%)',
        hasSpecialCropTest: true,
        specialMetricTitle: 'Tanen Burukluğu Skalası (1-4)',
        primaryActiveList: ['Tanen Burukluğu Skalası (1-4)', 'Brix Şeker (°Bx)', 'Et Sertliği', 'Nem %']
      };

    case 'NONE':
    default:
      return {
        cropType: 'NONE',
        cropName: productName || 'Standart Meyve / Sebze',
        badge: '🌱 Standart Kalite Parametreleri',
        showHardness: true,
        hardnessLabel: 'Sertlik / Hardness (kg/cm²)',
        hardnessUnit: 'kg/cm²',
        hardnessHint: 'UNECE Genel: 4.0 - 9.0 kg/cm²',
        showBrix: true,
        brixLabel: 'Brix Şeker / Sugar (°Bx)',
        brixUnit: '°Bx',
        brixHint: 'Min 10.0 - 12.0°Bx',
        showDiameter: true,
        diameterLabel: 'Çap / Diameter (mm)',
        diameterUnit: 'mm',
        showStarch: false,
        starchLabel: 'Nişasta',
        showColoration: true,
        colorationLabel: 'Renklenme / Coloration (%)',
        showNitrate: true,
        nitrateDefaultLimit: 60.0,
        showDefects: true,
        defectsLabel: 'Kusur / Defekt Oranı (%)',
        hasSpecialCropTest: false,
        primaryActiveList: ['Penetrometre Sertlik', 'Brix Şeker', 'Çap (mm)', 'Kusur %', 'Nitrat']
      };
  }
}

// ============================================================================
// REAL-TIME 'QUALITY INSIGHT' DEĞERLENDİRME & EŞİK/RAF ÖMRÜ RİSK MOTORU
// OECD / USDA / UNECE kurallarına göre partilerin kalite eşik sınırlarına ve
// raf ömrü bitişine yakınlık derecesini anlık analiz eder.
// ============================================================================

export interface QualityTriggeredRule {
  ruleName: string;
  standard: QualityStandardOrg;
  severity: 'CRITICAL' | 'WARNING';
  description: string;
  currentValue: string;
  thresholdValue: string;
}

export interface BatchQualityRiskAssessment {
  recordId: string;
  refId: string;
  product: string;
  variety: string;
  orchard?: string;
  location?: string;
  operator: string;
  harvestDate: string;
  testDate: string;
  standardOrg: QualityStandardOrg;
  standardVerdict: 'PASS' | 'FAIL' | 'CONDITIONAL';
  // Risk & Health
  riskLevel: 'CRITICAL' | 'WARNING' | 'SAFE'; // 🔴 CRITICAL, 🟡 WARNING, 🟢 SAFE
  healthScore: number; // 0 - 100
  // Shelf Life (Raf Ömrü)
  daysElapsed: number;
  estimatedTotalShelfLifeDays: number;
  estimatedRemainingShelfLifeDays: number;
  shelfLifeProgressPercent: number; // 0 - 100%
  isShelfLifeExpiring: boolean; // <= 3 days or >80% elapsed
  // Triggered Rules
  triggeredRules: QualityTriggeredRule[];
  primaryRiskSummary: string;
  recommendedAction: string;
  actionType: 'FREEZE_DRY' | 'URGENT_DISPATCH' | 'STORE_OPTIMIZE' | 'RETEST' | 'SAFE';
  isReroutedToFreezeDry: boolean;
  // Key Metrics
  avgHardness: number;
  avgBrix: number;
  defectPercent: number;
  nitrateMgKg: number;
  streifIndex?: number;
}

/**
 * Tahmini Maksimum Soğuk Hava ve Raf Ömrü (Gün Cinsinden)
 */
function getEstimatedShelfLifeDays(cropType: SpecialCropType, streifIndex?: number, avgHardness?: number): number {
  switch (cropType) {
    case 'PEACH_NECTARINE':
      // Şeftali/Nektarin: Sertliğe bağlı (4.5 kg altı ise 7-10 gün, üstü 21 gün)
      if (avgHardness && avgHardness < 4.5) return 10;
      return 21;
    case 'PLUM':
      return 28;
    case 'APPLE_PEAR':
      // Elma: Streif indeksine göre CA/ULO (180-240 gün), standart depo (75-90 gün), aşırı olgun (20 gün)
      if (streifIndex && streifIndex > 0.18) return 210; // CA/ULO uzun depo
      if (streifIndex && streifIndex >= 0.12) return 90;  // Standart soğuk depo
      if (streifIndex && streifIndex >= 0.07) return 30;  // Taze pazara hızlı sevk
      return 14; // Aşırı olgun
    case 'GRAPE':
      return 45;
    case 'TOMATO':
      return 14;
    case 'AVOCADO':
      return 25;
    case 'MANGO':
      return 21;
    case 'PINEAPPLE':
      return 18;
    case 'MELON_WATERMELON':
      return 20;
    case 'POMEGRANATE':
      return 90;
    case 'PISTACHIO':
      return 360; // Kuru depo
    case 'POTATO':
      return 150;
    case 'ONION':
      return 180;
    case 'CARROT':
      return 120;
    case 'CORN':
      return 10;
    case 'PERSIMMON':
      return 35;
    default:
      return 21;
  }
}

/**
 * Tek bir parti (FieldRecord) için OECD/USDA kalite eşikleri ve raf ömrü analizi yapar.
 */
export function evaluateBatchQualityRisk(
  fieldRecord: any, // FieldRecord
  reference?: any   // ReferenceItem
): BatchQualityRiskAssessment {
  const cropType: SpecialCropType = fieldRecord.specialCropTest?.cropType || 'NONE';
  const standardOrg: QualityStandardOrg = (fieldRecord.qualityStandardOrg as QualityStandardOrg) || 'OECD';
  const cropSpec = CROP_QUALITY_SPECS[cropType] || CROP_QUALITY_SPECS.NONE;
  const standardSpec = cropSpec.standards[standardOrg] || cropSpec.standards[cropSpec.defaultStandard] || cropSpec.standards.OECD || cropSpec.standards.UNECE;

  // Tarih ve Geçen Gün Hesaplama
  const testDateStr = fieldRecord.harvestDate || (fieldRecord.timestamp ? fieldRecord.timestamp.split('T')[0] : '2026-09-01');
  const testDate = new Date(testDateStr);
  const now = new Date();
  const diffTime = Math.max(0, now.getTime() - testDate.getTime());
  const daysElapsed = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  // Tahmini Toplam Raf Ömrü
  const totalShelfDays = getEstimatedShelfLifeDays(cropType, fieldRecord.streifIndex, fieldRecord.avgHardness);
  const remainingDays = Math.max(0, totalShelfDays - daysElapsed);
  const progressPercent = Math.min(100, Math.round((daysElapsed / totalShelfDays) * 100));
  const isShelfLifeExpiring = remainingDays <= 3 || progressPercent >= 80;

  const triggeredRules: QualityTriggeredRule[] = [];
  let healthPenalty = 0;

  // 1. Brix Eşik Kuralı Kontrolü (OECD / USDA)
  if (standardSpec && standardSpec.minBrix !== undefined) {
    const minBrix = standardSpec.minBrix;
    if (fieldRecord.avgBrix < minBrix) {
      triggeredRules.push({
        ruleName: `${standardOrg} Min Brix Kuralı Aşımı`,
        standard: standardOrg,
        severity: 'CRITICAL',
        description: `Brix şeker oranı standart tabanının altındadır (${fieldRecord.avgBrix.toFixed(1)}°Bx < ${minBrix}°Bx).`,
        currentValue: `${fieldRecord.avgBrix.toFixed(1)}°Bx`,
        thresholdValue: `Min ${minBrix}°Bx`
      });
      healthPenalty += 30;
    } else if (fieldRecord.avgBrix < (minBrix + 0.6)) {
      triggeredRules.push({
        ruleName: `${standardOrg} Brix Kritik Eşik Sınırında`,
        standard: standardOrg,
        severity: 'WARNING',
        description: `Brix seviyesi kabul tabanına çok yakındır (+0.5°Bx tolerans sınırında).`,
        currentValue: `${fieldRecord.avgBrix.toFixed(1)}°Bx`,
        thresholdValue: `Hedef ≥ ${minBrix}°Bx`
      });
      healthPenalty += 12;
    }
  }

  // 2. Sertlik (Penetrometre) Eşik Kuralı
  if (standardSpec && standardSpec.minHardnessKgCm2 !== undefined) {
    const minH = standardSpec.minHardnessKgCm2;
    if (fieldRecord.avgHardness < minH) {
      triggeredRules.push({
        ruleName: `${standardOrg} Penetrometre Sertlik Yetersizliği`,
        standard: standardOrg,
        severity: 'CRITICAL',
        description: `Meyve eti aşırı yumuşamıştır (${fieldRecord.avgHardness.toFixed(2)} kg/cm² < ${minH} kg/cm²). Çürüme ve basınca dayanıksızlık riski!`,
        currentValue: `${fieldRecord.avgHardness.toFixed(2)} kg/cm²`,
        thresholdValue: `Min ${minH} kg/cm²`
      });
      healthPenalty += 35;
    } else if (fieldRecord.avgHardness < (minH + 0.5)) {
      triggeredRules.push({
        ruleName: `${standardOrg} Sertlik Kritik Eşik Sınırında (Yumuşama Riski)`,
        standard: standardOrg,
        severity: 'WARNING',
        description: `Sertlik alt tolerans sınırına çok yakın. Hızlı sevk veya soğuk zincir takviyesi gerekir.`,
        currentValue: `${fieldRecord.avgHardness.toFixed(2)} kg/cm²`,
        thresholdValue: `Hedef ≥ ${minH} kg/cm²`
      });
      healthPenalty += 15;
    }
  }

  // 3. Görsel Kusur & Defekt Toleransı
  if (standardSpec && standardSpec.maxDefectPercent !== undefined) {
    const maxDef = standardSpec.maxDefectPercent;
    if (fieldRecord.defectPercent > maxDef) {
      triggeredRules.push({
        ruleName: `${standardOrg} Kusur Tolerans Aşımı`,
        standard: standardOrg,
        severity: 'CRITICAL',
        description: `Kusurlu meyve oranı 1. Sınıf izin verilen maksimum toleransı aştı (%${fieldRecord.defectPercent.toFixed(1)} > %${maxDef}).`,
        currentValue: `%${fieldRecord.defectPercent.toFixed(1)}`,
        thresholdValue: `Maks %${maxDef}`
      });
      healthPenalty += 25;
    } else if (fieldRecord.defectPercent > (maxDef * 0.75)) {
      triggeredRules.push({
        ruleName: `${standardOrg} Kusur Oranı Eşiğe Yakın`,
        standard: standardOrg,
        severity: 'WARNING',
        description: `Kusur oranı maksimum tolerans sınırına yaklaşmıştır.`,
        currentValue: `%${fieldRecord.defectPercent.toFixed(1)}`,
        thresholdValue: `Maks %${maxDef}`
      });
      healthPenalty += 10;
    }
  }

  // 4. Nitrat Kalıntı Sınırı
  const maxNitrate = standardSpec?.maxNitrateMgKg || fieldRecord.nitrateLimitMgKg || 60.0;
  if (fieldRecord.nitrateMgKg > maxNitrate) {
    triggeredRules.push({
      ruleName: 'Gıda Güvenliği Nitrat Limiti Aşımı',
      standard: 'OECD',
      severity: 'CRITICAL',
      description: `Kimyasal nitrat kalıntısı yasal sınırı aşmıştır (${fieldRecord.nitrateMgKg} mg/kg > ${maxNitrate} mg/kg).`,
      currentValue: `${fieldRecord.nitrateMgKg} mg/kg`,
      thresholdValue: `Maks ${maxNitrate} mg/kg`
    });
    healthPenalty += 40;
  } else if (fieldRecord.nitrateMgKg > (maxNitrate * 0.85)) {
    triggeredRules.push({
      ruleName: 'Nitrat Seviyesi Üst Sınıra Yakın (%85+)',
      standard: 'OECD',
      severity: 'WARNING',
      description: `Nitrat seviyesi izin verilen yasal sınıra yaklaşmaktadır.`,
      currentValue: `${fieldRecord.nitrateMgKg} mg/kg`,
      thresholdValue: `Maks ${maxNitrate} mg/kg`
    });
    healthPenalty += 10;
  }

  // 5. Streif İndeksi Aşırı Olgunlaşma (Elma/Armut)
  if (cropType === 'APPLE_PEAR' && fieldRecord.streifIndex !== undefined && fieldRecord.streifIndex > 0) {
    if (fieldRecord.streifIndex < 0.075) {
      triggeredRules.push({
        ruleName: 'Streif İndeksi: Aşırı Olgun / Depo Bitişi',
        standard: 'OECD',
        severity: 'CRITICAL',
        description: `Streif indeksi ${fieldRecord.streifIndex} seviyesine düşmüştür. Soğuk depolama ömrü dolmuş, taze pazar veya Freeze-Dry gereklidir.`,
        currentValue: `SI: ${fieldRecord.streifIndex}`,
        thresholdValue: 'SI ≥ 0.12'
      });
      healthPenalty += 30;
    } else if (fieldRecord.streifIndex < 0.11) {
      triggeredRules.push({
        ruleName: 'Streif İndeksi: Hızlı Tüketim Sevk Uyarısı',
        standard: 'OECD',
        severity: 'WARNING',
        description: `Nişasta hidrolizi ilerlemiştir. Uzun depolama yerine hızlı tüketime yönlendirilmelidir.`,
        currentValue: `SI: ${fieldRecord.streifIndex}`,
        thresholdValue: 'SI 0.12 - 0.18'
      });
      healthPenalty += 15;
    }
  }

  // 6. Raf Ömrü Bitiş Kuralı
  if (isShelfLifeExpiring) {
    const isPastZero = remainingDays <= 0;
    triggeredRules.push({
      ruleName: isPastZero ? 'Kritik Raf Ömrü Doldu (Acil Müdahale)' : 'Raf Ömrü Bitiş Eşiğinde (≤ 3 Gün)',
      standard: standardOrg,
      severity: 'CRITICAL',
      description: isPastZero 
        ? `Ürünün tahmini soğuk depo / raf ömrü (${totalShelfDays} gün) tamamlanmıştır. Kalite kaybı ve çürüme riski yüksektir!`
        : `Partinin kalan tahmini raf ömrü ${remainingDays} gündür (%${progressPercent} tamamlandı).`,
      currentValue: `${daysElapsed} gün depoda (${remainingDays} gün kaldı)`,
      thresholdValue: `Maks ${totalShelfDays} gün`
    });
    healthPenalty += isPastZero ? 35 : 20;
  }

  // Final Risk Seviyesi ve Sağlık Skoru (0-100)
  const isReroutedToFreezeDry = fieldRecord.finalProductStatus === 'FREEZE_DRY' || Boolean(fieldRecord.reroutedToFreezeDry);
  const healthScore = Math.max(0, Math.min(100, 100 - healthPenalty));

  const hasCritical = triggeredRules.some(r => r.severity === 'CRITICAL') || fieldRecord.qualityStandardVerdict === 'FAIL' || isReroutedToFreezeDry;
  const hasWarning = triggeredRules.some(r => r.severity === 'WARNING') || remainingDays <= 7 || fieldRecord.qualityStandardVerdict === 'CONDITIONAL';

  let riskLevel: 'CRITICAL' | 'WARNING' | 'SAFE' = 'SAFE';
  let actionType: BatchQualityRiskAssessment['actionType'] = 'SAFE';
  let primaryRiskSummary = 'Tüm kalite parametreleri ve raf ömrü standart sınırlar dahilinde, optimum durumda.';
  let recommendedAction = 'Standart soğuk hava depolama ve planlı ihracat sevkiyatı.';

  if (hasCritical) {
    riskLevel = 'CRITICAL';
    if (fieldRecord.avgHardness < 3.8 || fieldRecord.qualityStandardVerdict === 'FAIL' || isReroutedToFreezeDry) {
      actionType = 'FREEZE_DRY';
      primaryRiskSummary = `Parti ${standardOrg} standart limitlerinin altında veya raf ömrü sonundadır (${triggeredRules.length} kritik uyarı).`;
      recommendedAction = 'Freeze & Dry liyofilizasyon hattına yönlendir (-40°C şoklama) veya yerel sanayi satışına aktar.';
    } else {
      actionType = 'URGENT_DISPATCH';
      primaryRiskSummary = `Raf ömrü bitiş eşiğine ulaşıldı (${remainingDays} gün kaldı) veya kalite parametresi sınırda.`;
      recommendedAction = 'Öncelikli hızlı taze sevkiyat başlat veya 1-MCP / modifiye atmosfer takviyesi uygula.';
    }
  } else if (hasWarning) {
    riskLevel = 'WARNING';
    actionType = 'STORE_OPTIMIZE';
    primaryRiskSummary = `Parametreler ${standardOrg} tolerans eşiğine yakındır (${triggeredRules.length} eşik uyarısı, ${remainingDays} gün kalan ömür).`;
    recommendedAction = 'Yakın kalite takibine al, 2 gün sonra tekrar numune testi yap veya süpermarket kanalına sevk et.';
  }

  return {
    recordId: fieldRecord.id,
    refId: fieldRecord.refId,
    product: fieldRecord.product || reference?.product || 'Belirtilmemiş',
    variety: fieldRecord.sortVariety || 'Standart',
    orchard: fieldRecord.orchard || reference?.orchard,
    location: fieldRecord.location || reference?.location,
    operator: fieldRecord.operator || 'Kalite Uzmanı',
    harvestDate: fieldRecord.harvestDate || testDateStr,
    testDate: testDateStr,
    standardOrg,
    standardVerdict: (fieldRecord.qualityStandardVerdict as any) || (riskLevel === 'CRITICAL' ? 'FAIL' : riskLevel === 'WARNING' ? 'CONDITIONAL' : 'PASS'),
    riskLevel,
    healthScore,
    daysElapsed,
    estimatedTotalShelfLifeDays: totalShelfDays,
    estimatedRemainingShelfLifeDays: remainingDays,
    shelfLifeProgressPercent: progressPercent,
    isShelfLifeExpiring,
    triggeredRules,
    primaryRiskSummary,
    recommendedAction,
    actionType,
    isReroutedToFreezeDry,
    avgHardness: fieldRecord.avgHardness || 0,
    avgBrix: fieldRecord.avgBrix || 0,
    defectPercent: fieldRecord.defectPercent || 0,
    nitrateMgKg: fieldRecord.nitrateMgKg || 0,
    streifIndex: fieldRecord.streifIndex
  };
}


// ============================================================================
// v4.2 — Doğrulanmış UNECE / OECD değerleri (MIWE HIL Standart kataloğu)
// Kural: en sıkı değer geçerli. Kaynaklı sayılar burada sabitlenir; diğerleri "iç hedef" olarak kalır.
// ============================================================================
(function applyVerifiedStandards() {
  const set = (t: SpecialCropType, org: 'UNECE' | 'OECD', patch: Record<string, any>) => {
    const spec: any = (CROP_QUALITY_SPECS as any)[t]?.standards?.[org];
    if (spec) Object.assign(spec, patch);
  };
  (['UNECE', 'OECD'] as const).forEach(org => {
    set('GRAPE', org, { minBrix: 16.0, minSpecialMetric: 18.0, notes: 'UNECE FFV-19: ≥16 °Bx; daha düşükse şeker/asit 14–16 °Bx → ≥18:1, 12,5–14 °Bx → ≥20:1.' });
    set('PEACH_NECTARINE', org, { minBrix: 8.0, maxHardnessKgCm2: 6.5, notes: 'UNECE FFV-26: ≥8 °Bx ve sertlik <6,5 kg (8 mm uç, 0,5 cm², ekvatorda 2 nokta). Alt sertlik sınırı iç hedeftir.' });
    set('MELON_WATERMELON', org, { minBrix: 8.0, notes: 'Kavun UNECE FFV-23: Charentais ≥10 °Bx, diğer ≥8 °Bx. Karpuz FFV-37: ≥8 °Bx. Daha yüksek değerler iç hedef / müşteri şartıdır.' });
    set('PISTACHIO', org, { maxSpecialMetric: 6.5, notes: 'UNECE DDP-09: kabuklu fıstık içi nem ≤%6,5. Doğal çıtlak oranı iç hedeftir (kaynak doğrulanacak).' });
    set('AVOCADO', org, { minSpecialMetric: 21.0, notes: 'UNECE FFV-42: KM Hass ≥%21; Fuerte, Pinkerton, Reed, Edranol ≥%20; diğer ≥%19. %23 Avrupa alıcı tercihi (müşteri katmanı).' });
    set('PINEAPPLE', org, { minBrix: 12.0, notes: 'UNECE FFV-49 / Codex CXS 182: meyve etinde ≥12 °Bx.' });
    set('APPLE_PEAR', org, { notes: 'UNECE FFV-50 (elma): genel Brix sınırı yok; yalnız mini çeşitlerde ≥12 °Bx. Buradaki Brix/sertlik/nişasta değerleri iç hedeftir.' });
  });
})();
