# v42 — Standart kataloğu (OECD/UNECE) + kivi şablonu + rehber güncellemesi

Uygulama sırası: v41'den SONRA. Dosyaları AYNEN (byte-identical) kopyala. Firestore kuralı DEĞİŞMEDİ.

## 1) Standart kataloğu (yeni)
- Ana menü › Raporlar › **Standart kataloğu**: 24 ürün; durum filtresi (Doğrulandı · MIWE iç standardı ·
  İç değer · Doğrulanacak), her üründe uluslararası şart (UNECE = OECD), MIWE hedefi ve kaynak linki.
- Kural her kartta yazılı: **en sıkı değer geçerli**; yerel standart daha sıkıysa yerel uygulanır.
- Test (Saha testi) formunda ürün seçilince altında o ürünün **standart kartı** görünür.

## 2) Doğrulanmış değerler kalite hesabına işlendi (UNECE ve OECD sütunları)
- Üzüm ≥16 °Bx, şeker/asit ≥18:1 (12,5–14 °Bx için 20:1 notu) · Şeftali/nektarin ≥8 °Bx, sertlik <6,5 kg/0,5 cm²
- Kavun/karpuz ≥8 °Bx (Charentais 10) · Antep fıstığı nem ≤%6,5 · Avokado KM ≥%21 · Ananas ≥12 °Bx
- Elma: genel Brix sınırı olmadığı not edildi (değerler iç hedef). TESCO / TDS / diğer sütunlara dokunulmadı.

## 3) Kivi şablonu (yeni ürün tipi KIWI)
- Saha testinde "🥝 Kivi" şablonu: Kuru madde % + Brix. UNECE FFV-46: ≥6,2 °Bx VEYA KM ≥%15 → uygun.
- Ürün adında "kivi/kiwi" geçince otomatik tanınır.

## 4) Şablon ipuçları düzeltildi
- "OECD Min …" yazan ama standartta sayısı olmayan ipuçları "İç hedef …" olarak yazıldı (mango, nar, erik,
  domates, soğan, havuç, patates); doğrulananlar kaynak koduyla (FFV-19, FFV-26, FFV-42, FFV-50, DDP-09…).

## 5) Rehber (Yardım › Rehber ve sorular)
- Şeftali/elma ölçüm cevabı standartla uyumlu hale getirildi.
- Yeni konular: QR etiket ve herkese açık kart · Toplu QR tarama · Standart kataloğu ve "en sıkı değer" ·
  Test planı (hasat öncesi 2–3, hasat 3 günde 1, depo duruma bağlı, ihracat yükleme + varış, dış yük) ·
  Muz sarartma (14 °C, 35 ppm, 8 gün, renk 3/7, erken çıkışta akt) · Badem hasat kararı ve akışı.

## Bu yamada YOK (sonraki)
- Yönetici sayfası ve denetim izi yeniden tasarımı · yaban mersini, sarımsak, hindistan cevizi şablonları
  (sayısal standart doğrulanınca) · muz 7 adım akışı ve badem modülü (v43).

## Dosyalar
src/config/standardsCatalog.ts (YENİ) · src/components/standards/StandardCard.tsx (YENİ) ·
src/components/standards/StandardsCatalogModal.tsx (YENİ) · src/types.ts · src/utils/specialCropTests.ts ·
src/utils/qualityStandards.ts · src/components/forms/FieldForm.tsx · src/components/portal/GuidePortal.tsx ·
src/components/portal/HomeMenu.tsx · src/App.tsx

## Kabul testleri
1. Ana menü › Raporlar › "Standart kataloğu" açılıyor; 24 ürün; filtreler sayılarla çalışıyor.
2. Saha testi → ürün "Şeftali" → altında standart kartı (≥8 °Bx, <6,5 kg, kaynak linki).
3. Saha testi şablonlarında "🥝 Kivi" var; KM 16 girilince "olgunluk şartı karşılanıyor" yorumu çıkıyor.
4. Rehber'de "Muz sarartma standardı" ve "Standart kataloğu" konuları görünüyor.
5. Mevcut testler (elma, üzüm, avokado…) açılıp kaydediliyor; hata yok.
6. TypeScript derleme hatası yok.
