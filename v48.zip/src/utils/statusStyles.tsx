import React from 'react';
import {
  Clock,
  Truck,
  ArrowRightLeft,
  CheckCircle2,
  PieChart,
  XCircle,
  Snowflake,
  Award,
  DollarSign,
  AlertTriangle,
  Archive,
  CheckCheck
} from 'lucide-react';
import { ReferenceStatus } from '../types';

export interface StatusStyleConfig {
  status: ReferenceStatus | string;
  label: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  badgeClass: string;
  dotClass: string;
  icon: React.ElementType;
}

export const STATUS_CONFIG_MAP: Record<string, StatusStyleConfig> = {
  CREATED: {
    status: 'CREATED',
    label: 'Oluşturuldu (Saha)',
    bgClass: 'bg-blue-50 dark:bg-blue-950/50',
    textClass: 'text-blue-700 dark:text-blue-300',
    borderClass: 'border-blue-200 dark:border-blue-800',
    badgeClass: 'bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 border-blue-300 dark:border-blue-700',
    dotClass: 'bg-blue-500',
    icon: Clock
  },
  SHIPPED: {
    status: 'SHIPPED',
    label: 'Sevk Edildi',
    bgClass: 'bg-purple-50 dark:bg-purple-950/50',
    textClass: 'text-purple-700 dark:text-purple-300',
    borderClass: 'border-purple-200 dark:border-purple-800',
    badgeClass: 'bg-purple-100 dark:bg-purple-900/60 text-purple-800 dark:text-purple-200 border-purple-300 dark:border-purple-700',
    dotClass: 'bg-purple-500',
    icon: Truck
  },
  IN_TRANSIT: {
    status: 'IN_TRANSIT',
    label: 'Yolda',
    bgClass: 'bg-amber-50 dark:bg-amber-950/50',
    textClass: 'text-amber-700 dark:text-amber-300',
    borderClass: 'border-amber-200 dark:border-amber-800',
    badgeClass: 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 border-amber-300 dark:border-amber-700',
    dotClass: 'bg-amber-500',
    icon: ArrowRightLeft
  },
  RECEIVED: {
    status: 'RECEIVED',
    label: 'Teslim Alındı (Kabul)',
    bgClass: 'bg-emerald-50 dark:bg-emerald-950/50',
    textClass: 'text-emerald-700 dark:text-emerald-300',
    borderClass: 'border-emerald-200 dark:border-emerald-800',
    badgeClass: 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700',
    dotClass: 'bg-emerald-500',
    icon: CheckCircle2
  },
  PARTIAL: {
    status: 'PARTIAL',
    label: 'Kısmi Teslimat',
    bgClass: 'bg-sky-50 dark:bg-sky-950/50',
    textClass: 'text-sky-700 dark:text-sky-300',
    borderClass: 'border-sky-200 dark:border-sky-800',
    badgeClass: 'bg-sky-100 dark:bg-sky-900/60 text-sky-800 dark:text-sky-200 border-sky-300 dark:border-sky-700',
    dotClass: 'bg-sky-500',
    icon: PieChart
  },
  REJECTED: {
    status: 'REJECTED',
    label: 'Reddedildi / İade',
    bgClass: 'bg-rose-50 dark:bg-rose-950/50',
    textClass: 'text-rose-700 dark:text-rose-300',
    borderClass: 'border-rose-200 dark:border-rose-800',
    badgeClass: 'bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 border-rose-300 dark:border-rose-700',
    dotClass: 'bg-rose-500',
    icon: XCircle
  },
  IN_FREEZE_DRY: {
    status: 'IN_FREEZE_DRY',
    label: 'Freeze-Dry Tesisinde',
    bgClass: 'bg-indigo-50 dark:bg-indigo-950/50',
    textClass: 'text-indigo-700 dark:text-indigo-300',
    borderClass: 'border-indigo-200 dark:border-indigo-800',
    badgeClass: 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-700',
    dotClass: 'bg-indigo-500',
    icon: Snowflake
  },
  FREEZE_DRY_COMPLETED: {
    status: 'FREEZE_DRY_COMPLETED',
    label: 'Freeze-Dry Tamamlandı',
    bgClass: 'bg-teal-50 dark:bg-teal-950/50',
    textClass: 'text-teal-700 dark:text-teal-300',
    borderClass: 'border-teal-200 dark:border-teal-800',
    badgeClass: 'bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-200 border-teal-300 dark:border-teal-700',
    dotClass: 'bg-teal-500',
    icon: CheckCheck
  },
  EXPORT_TESTED: {
    status: 'EXPORT_TESTED',
    label: 'İhracat Test Onaylı',
    bgClass: 'bg-cyan-50 dark:bg-cyan-950/50',
    textClass: 'text-cyan-700 dark:text-cyan-300',
    borderClass: 'border-cyan-200 dark:border-cyan-800',
    badgeClass: 'bg-cyan-100 dark:bg-cyan-900/60 text-cyan-800 dark:text-cyan-200 border-cyan-300 dark:border-cyan-700',
    dotClass: 'bg-cyan-500',
    icon: Award
  },
  SOLD: {
    status: 'SOLD',
    label: 'Satışı Yapıldı',
    bgClass: 'bg-emerald-50 dark:bg-emerald-950/50',
    textClass: 'text-emerald-700 dark:text-emerald-300',
    borderClass: 'border-emerald-200 dark:border-emerald-800',
    badgeClass: 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700',
    dotClass: 'bg-emerald-500',
    icon: DollarSign
  },
  INCIDENT: {
    status: 'INCIDENT',
    label: 'Olay / Kalite İhtilafı',
    bgClass: 'bg-red-50 dark:bg-red-950/50',
    textClass: 'text-red-700 dark:text-red-300',
    borderClass: 'border-red-200 dark:border-red-800',
    badgeClass: 'bg-red-100 dark:bg-red-900/60 text-red-800 dark:text-red-200 border-red-300 dark:border-red-700',
    dotClass: 'bg-red-500',
    icon: AlertTriangle
  },
  CLOSED: {
    status: 'CLOSED',
    label: 'Arşivlendi / Kapalı',
    bgClass: 'bg-slate-100 dark:bg-slate-800/60',
    textClass: 'text-slate-700 dark:text-slate-300',
    borderClass: 'border-slate-300 dark:border-slate-700',
    badgeClass: 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700',
    dotClass: 'bg-slate-500',
    icon: Archive
  },
  COMPLETED: {
    status: 'COMPLETED',
    label: 'Tamamlandı',
    bgClass: 'bg-green-50 dark:bg-green-950/50',
    textClass: 'text-green-700 dark:text-green-300',
    borderClass: 'border-green-200 dark:border-green-800',
    badgeClass: 'bg-green-100 dark:bg-green-900/60 text-green-800 dark:text-green-200 border-green-300 dark:border-green-700',
    dotClass: 'bg-green-500',
    icon: CheckCircle2
  }
};

export function getStatusConfig(status?: ReferenceStatus | string): StatusStyleConfig {
  if (!status || !STATUS_CONFIG_MAP[status]) {
    return STATUS_CONFIG_MAP.CREATED;
  }
  return STATUS_CONFIG_MAP[status];
}

export function renderStatusBadge(status?: ReferenceStatus | string, className: string = '') {
  const cfg = getStatusConfig(status);
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border ${cfg.badgeClass} ${className}`}>
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{cfg.label}</span>
    </span>
  );
}
