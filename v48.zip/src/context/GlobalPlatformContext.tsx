import React, { createContext, useContext, ReactNode } from 'react';
import type { PortalDataPayload } from '../types/portal';
import { portalEventBus, PortalEventType } from '../utils/portalEventBus';

interface GlobalPlatformContextValue {
  data: PortalDataPayload;
  lastUpdated: number;
  emitEvent: (event: PortalEventType, eventData?: any, moduleKey?: string, refId?: string) => void;
}

const GlobalPlatformContext = createContext<GlobalPlatformContextValue | null>(null);

export const GlobalPlatformProvider: React.FC<{
  data: PortalDataPayload;
  children: ReactNode;
}> = ({ data, children }) => {
  const emitEvent = (event: PortalEventType, eventData?: any, moduleKey?: string, refId?: string) => {
    portalEventBus.emit(event, eventData, moduleKey, refId);
  };

  const value: GlobalPlatformContextValue = {
    data,
    lastUpdated: Date.now(),
    emitEvent
  };

  return (
    <GlobalPlatformContext.Provider value={value}>
      {children}
    </GlobalPlatformContext.Provider>
  );
};

export function useGlobalPlatform(): GlobalPlatformContextValue {
  const ctx = useContext(GlobalPlatformContext);
  if (!ctx) {
    throw new Error('useGlobalPlatform, GlobalPlatformProvider içinde kullanılmalıdır.');
  }
  return ctx;
}
