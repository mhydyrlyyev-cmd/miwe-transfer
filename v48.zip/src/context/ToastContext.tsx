import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  title?: string;
  message: string;
  duration?: number;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType, title?: string, duration?: number) => void;
  showSuccess: (message: string, title?: string) => void;
  showError: (message: string, title?: string) => void;
  showWarning: (message: string, title?: string) => void;
  showInfo: (message: string, title?: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const showToast = useCallback((message: string, type: ToastType = 'success', title?: string, duration = 3500) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { id, type, title, message, duration };
    
    setToasts(prev => [...prev.slice(-4), newToast]); // keep max 5 toasts

    if (duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, duration);
    }
  }, [removeToast]);

  const showSuccess = useCallback((message: string, title?: string) => {
    showToast(message, 'success', title || 'İşlem Başarılı');
  }, [showToast]);

  const showError = useCallback((message: string, title?: string) => {
    showToast(message, 'error', title || 'Hata Oluştu');
  }, [showToast]);

  const showWarning = useCallback((message: string, title?: string) => {
    showToast(message, 'warning', title || 'Uyarı');
  }, [showToast]);

  const showInfo = useCallback((message: string, title?: string) => {
    showToast(message, 'info', title || 'Bilgilendirme');
  }, [showToast]);

  // v47b: AI Studio önizlemesi (iframe) ve bazı telefon tarayıcıları window.alert'i sessizce engeller.
  // Formların "eksik alan" uyarıları bu yüzden görünmüyordu. Tüm alert'ler ekranda kalıcı bildirim olarak gösterilir.
  useEffect(() => {
    const original = window.alert;
    window.alert = (msg?: any) => {
      const text = String(msg ?? '');
      const ok = /başar|kaydedildi|tamamlandı|oluşturuldu/i.test(text);
      showToast(text, ok ? 'success' : 'warning', ok ? 'Tamam' : 'Kayıt yapılamadı', ok ? 4000 : 9000);
    };
    return () => { window.alert = original; };
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, showSuccess, showError, showWarning, showInfo }}>
      {children}
      {/* Toast Notification Floating Container (Sağ Üst Köşe) */}
      <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2.5 max-w-sm w-full pointer-events-none px-3 sm:px-0">
        {toasts.map(toast => {
          const bgColors = {
            success: 'bg-white border-emerald-300',
            error: 'bg-white border-rose-300',
            warning: 'bg-white border-amber-300',
            info: 'bg-white border-slate-300'
          };

          const icons = {
            success: <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />,
            error: <XCircle className="w-5 h-5 text-rose-600 shrink-0" />,
            warning: <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />,
            info: <Info className="w-5 h-5 text-slate-500 shrink-0" />
          };

          return (
            <div
              key={toast.id}
              className={`pointer-events-auto border rounded-2xl p-3.5 shadow-lg transition-all duration-300 animate-in fade-in slide-in-from-top-4 flex items-start gap-3 ${bgColors[toast.type]}`}
            >
              <div className="mt-0.5">{icons[toast.type]}</div>
              <div className="flex-1 min-w-0">
                {toast.title && (
                  <h4 className="text-sm font-bold text-slate-900 mb-0.5">
                    {toast.title}
                  </h4>
                )}
                <p className="text-sm text-slate-700 leading-snug break-words whitespace-pre-line">
                  {toast.message}
                </p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                aria-label="Kapat" className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 transition shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};
