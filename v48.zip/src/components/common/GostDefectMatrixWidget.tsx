import React, { useRef, useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Info,
  Scale,
  RefreshCw,
  FileText
} from 'lucide-react';
import {
  GostDefectInput,
  GostSpreadsheetMetadata,
  calculateGostDefects,
  exportGostInspectionToCsv,
  generateGostEmptyTemplateCsv,
  parseGostInspectionCsv,
  PRESET_PEACH_GOST_INSPECTION,
  PRESET_APPLE_GOST_INSPECTION,
  getGostProductTolerances
} from '../../utils/gostQualityCalculators';

interface GostDefectMatrixWidgetProps {
  defects: GostDefectInput;
  onChangeDefects: (updated: GostDefectInput) => void;
  metadata?: GostSpreadsheetMetadata;
  onChangeMetadata?: (updated: GostSpreadsheetMetadata) => void;
  productName?: string;
  onCreateIncident?: (incidentDetails: {
    incidentType: string;
    description: string;
    rotPercent: number;
    wastePercent: number;
  }) => void;
  className?: string;
}

export const GostDefectMatrixWidget: React.FC<GostDefectMatrixWidgetProps> = ({
  defects,
  onChangeDefects,
  metadata = {},
  onChangeMetadata,
  productName = 'Şeftali',
  onCreateIncident,
  className = ''
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Live GOST calculation
  const metrics = calculateGostDefects({
    ...defects,
    productName
  });

  const tolerances = getGostProductTolerances(productName);

  const handleNumericChange = (key: keyof GostDefectInput, valStr: string) => {
    const val = valStr === '' ? 0 : parseFloat(valStr);
    onChangeDefects({
      ...defects,
      [key]: isNaN(val) ? 0 : val
    });
  };

  // 1. Download Blank Excel Template
  const handleDownloadBlankTemplate = () => {
    const { content, filename } = generateGostEmptyTemplateCsv(productName);
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Boş Excel şablonu indirildi: ${filename}`);
  };

  // 2. Export Filled Inspection Report as Excel CSV
  const handleExportFilledReport = () => {
    const { content, filename } = exportGostInspectionToCsv(
      metadata,
      defects,
      metrics,
      productName
    );
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Denetim raporu Excel formatında indirildi: ${filename}`);
  };

  // 3. Upload and Parse Filled Excel CSV
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const result = parseGostInspectionCsv(text);
      if (result.success) {
        onChangeDefects({
          ...defects,
          ...result.defects
        });
        if (onChangeMetadata && result.metadata) {
          onChangeMetadata({
            ...metadata,
            ...result.metadata
          });
        }
        showToast(`Excel verisi başarıyla içe aktarıldı (${file.name})!`);
      } else {
        showToast(`Hata: ${result.error || 'Dosya okunamadı'}`);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // 4. Load Presets
  const handleLoadPreset = (type: 'PEACH' | 'APPLE') => {
    const preset = type === 'PEACH' ? PRESET_PEACH_GOST_INSPECTION : PRESET_APPLE_GOST_INSPECTION;
    onChangeDefects({
      ...defects,
      ...preset.defects
    });
    if (onChangeMetadata) {
      onChangeMetadata({
        ...metadata,
        ...preset.metadata
      });
    }
    showToast(`${type === 'PEACH' ? 'Şeftali (06.08.2026)' : 'Kırmızı Elma'} denetim preseti yüklendi.`);
  };

  return (
    <div className={`space-y-4 ${className}`}>
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-[150] animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="bg-slate-900/95 text-white text-xs px-4 py-2.5 rounded-xl border border-teal-500/50 shadow-xl flex items-center gap-2 backdrop-blur-md">
            <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Hidden File Input for Excel Import */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept=".csv,.txt"
        className="hidden"
      />

      {/* Header & Excel Toolbar */}
      <div className="bg-white text-slate-900 rounded-2xl p-4 border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs text-teal-700 tabular-nums">
            <span>🇷🇺 3.5. Rusya & Avrasya (GOST / EAEU)</span>
            <span aria-hidden="true">·</span>
            <span>Fire & Kusur Matrisi</span>
          </div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mt-0.5">
            <FileSpreadsheet className="w-4 h-4 text-teal-700" />
            <span>Kusur, Çürüklük & Yangı Hesaplama Tablosu</span>
          </h3>
          <p className="text-[11px] text-slate-600 mt-0.5">
            Kilogram girildikçe yüzdeler ve GOST tolerans kararı formüllerle canlı hesaplanır.
          </p>
        </div>

        {/* Toolbar Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={handleDownloadBlankTemplate}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition flex items-center gap-1 cursor-pointer"
            title="Excel uyumlu boş şablon indir"
          >
            <Download className="w-3.5 h-3.5 text-teal-700" />
            <span>Boş Şablon</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition flex items-center gap-1 cursor-pointer"
            title="Doldurulmuş Excel CSV yükle"
          >
            <Upload className="w-3.5 h-3.5 text-blue-700" />
            <span>Excel Yükle</span>
          </button>

          <button
            type="button"
            onClick={() => handleLoadPreset('PEACH')}
            className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-50 text-amber-700 text-xs font-bold rounded-lg border border-amber-200 transition flex items-center gap-1 cursor-pointer"
            title="Örnek Şeftali Yükü (06.08.2026)"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>Şeftali Preseti</span>
          </button>

          <button
            type="button"
            onClick={handleExportFilledReport}
            className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-slate-950 text-xs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Mevcut denetimi resmi Excel CSV olarak indir"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-950" />
            <span>Rapor İndir</span>
          </button>
        </div>
      </div>

      {/* Decision Status Banner */}
      <div
        className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
          metrics.decision === 'COMPLIANT'
            ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800/60 text-emerald-950 dark:text-emerald-200'
            : metrics.decision === 'CONDITIONAL_DISCOUNT'
            ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800/60 text-amber-950 dark:text-amber-200'
            : 'bg-rose-50 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800/60 text-rose-950 dark:text-rose-200'
        }`}
      >
        <div className="flex items-start gap-2.5">
          {metrics.decision === 'COMPLIANT' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          ) : metrics.decision === 'CONDITIONAL_DISCOUNT' ? (
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
          )}
          <div>
            <div className="text-xs font-bold">
              {metrics.decisionLabelTr}
            </div>
            <div className="text-[11px] opacity-80 tabular-nums mt-0.5">
              {metrics.decisionLabelRu}
            </div>
            <div className="text-xs font-medium mt-1">
              {metrics.recommendedAction}
            </div>
          </div>
        </div>

        {/* Right side stats & dispute trigger button */}
        <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
          <div className="text-right">
            <span className="text-[10px] block opacity-75">Toplam Atık / Fire:</span>
            <span className="tabular-nums font-bold text-sm tabular-nums">
              %{metrics.wastePercent} ({metrics.wasteKg} kg)
            </span>
          </div>

          {metrics.decision === 'REJECTED_INCIDENT' && onCreateIncident && (
            <button
              type="button"
              onClick={() => onCreateIncident({
                incidentType: 'Yüksek Fire / Avrasya GOST Tolerans Aşımı',
                description: `Yurtdışı gelen yükte GOST toleransı aşıldı. Çürüklük: %${metrics.rotPercent}, Toplam Kusur/Fire: %${metrics.wastePercent}. Net Atık: ${metrics.wasteKg} kg.`,
                rotPercent: metrics.rotPercent,
                wastePercent: metrics.wastePercent
              })}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-xs active:scale-95"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Barlag Akty Aç</span>
            </button>
          )}
        </div>
      </div>

      {/* Sampling Box & Net Weight Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
        <div>
          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
            Numune Koli Sayısı (Кол-во коробок):
          </label>
          <input
            type="number"
            min="1"
            value={defects.sampleBoxCount || ''}
            onChange={(e) => handleNumericChange('sampleBoxCount', e.target.value)}
            placeholder="örn. 16"
            className="w-full px-3 py-1.5 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-teal-500 tabular-nums"
          />
          <span className="text-[10px] text-slate-400 mt-0.5 block">Seçilen koli adedi</span>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
            Net Numune Ağırlığı (Вес пробы, кг) *:
          </label>
          <input
            type="number"
            step="0.01"
            min="0.1"
            value={defects.sampleWeightKg || ''}
            onChange={(e) => handleNumericChange('sampleWeightKg', e.target.value)}
            placeholder="örn. 58.28"
            className="w-full px-3 py-1.5 text-xs tabular-nums font-bold text-teal-700 dark:text-teal-400 bg-white dark:bg-slate-800 border border-teal-500/50 rounded-lg focus:ring-1 focus:ring-teal-500 tabular-nums"
          />
          <span className="text-[10px] text-slate-400 mt-0.5 block">Yüzdelerin paydasıdır</span>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
            Sağlam / Standart Ürün (Выход стандартной):
          </label>
          <div className="px-3 py-1.5 text-xs tabular-nums font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800/60 rounded-lg flex items-center justify-between">
            <span>{metrics.standardSoundKg} kg</span>
            <span>%{metrics.standardSoundPercent}</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Kusursuz net ürün</span>
        </div>
      </div>

      {/* High-Density Defect Breakdown Grid */}
      <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-800">
                <th className="py-2.5 px-3">Kusur Kategorisi / Defekty</th>
                <th className="py-2.5 px-3 w-32">Kusurlu Miktar (Kg)</th>
                <th className="py-2.5 px-3 w-28 text-right">Oran (%)</th>
                <th className="py-2.5 px-3 w-36 text-right">Tolerans Sınırı</th>
                <th className="py-2.5 px-3 w-28 text-center">Durum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              
              {/* 1. Rot Group Header */}
              <tr className="bg-rose-50/50 dark:bg-rose-950/20 font-bold">
                <td colSpan={5} className="py-1.5 px-3 text-rose-800 dark:text-rose-300 flex items-center justify-between">
                  <span>1. Çürüklük (гниль / rot)</span>
                  <span className="tabular-nums tabular-nums text-[11px]">
                    Toplam: {metrics.rotKg} kg (%{metrics.rotPercent})
                  </span>
                </td>
              </tr>

              {/* Internal Rot / Necrosis */}
              <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="py-2 px-3 pl-6">
                  <div className="font-semibold text-rose-700 dark:text-rose-400">İç Çürüklük &amp; Nekroz</div>
                  <div className="text-[10px] text-slate-400 tabular-nums">Внутренняя гниль / некроз плода</div>
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={defects.internalRotNecrosisKg || ''}
                    onChange={(e) => handleNumericChange('internalRotNecrosisKg', e.target.value)}
                    placeholder="0.00"
                    className="w-full px-2 py-1 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded focus:ring-1 focus:ring-rose-500 tabular-nums"
                  />
                </td>
                <td className="py-2 px-3 text-right tabular-nums font-bold tabular-nums">
                  %{metrics.internalRotNecrosisPercent}
                </td>
                <td className="py-2 px-3 text-right text-[11px] tabular-nums text-rose-600 dark:text-rose-400">
                  %0.0 (Sıfır Tolerans)
                </td>
                <td className="py-2 px-3 text-center">
                  {metrics.internalRotNecrosisKg > 0 ? (
                    <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">İHLAL</span>
                  ) : (
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400">UYGUN</span>
                  )}
                </td>
              </tr>

              {/* Obvious Surface Rot */}
              <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="py-2 px-3 pl-6">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">Bariz Dış Çürük</div>
                  <div className="text-[10px] text-slate-400 tabular-nums">Явная гниль на поверхности</div>
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={defects.obviousRotTheRotIsObviousKg || ''}
                    onChange={(e) => handleNumericChange('obviousRotTheRotIsObviousKg', e.target.value)}
                    placeholder="0.00"
                    className="w-full px-2 py-1 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded focus:ring-1 focus:ring-teal-500 tabular-nums"
                  />
                </td>
                <td className="py-2 px-3 text-right tabular-nums font-bold tabular-nums">
                  %{metrics.obviousRotTheRotIsObviousPercent}
                </td>
                <td className="py-2 px-3 text-right text-[11px] tabular-nums text-slate-500">
                  Max %{tolerances.maxRotPercent}
                </td>
                <td className="py-2 px-3 text-center">
                  {metrics.obviousRotTheRotIsObviousPercent > tolerances.maxRotPercent ? (
                    <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">AŞILDI</span>
                  ) : (
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400">UYGUN</span>
                  )}
                </td>
              </tr>

              {/* 2. Non-Standard Group Header */}
              <tr className="bg-amber-50/50 dark:bg-amber-950/20 font-bold">
                <td colSpan={5} className="py-1.5 px-3 text-amber-800 dark:text-amber-300 flex items-center justify-between">
                  <span>2. Standart dışı kusurlar (нестандарт)</span>
                  <span className="tabular-nums tabular-nums text-[11px]">
                    Toplam: {metrics.nonStandardKg} kg (%{metrics.nonStandardPercent})
                  </span>
                </td>
              </tr>

              {/* Mechanics / Bruising */}
              <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="py-2 px-3 pl-6">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">Mekanik Hasar &amp; Ezilme</div>
                  <div className="text-[10px] text-slate-400 tabular-nums">Механические повреждения</div>
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={defects.mechanicsKg || ''}
                    onChange={(e) => handleNumericChange('mechanicsKg', e.target.value)}
                    placeholder="0.00"
                    className="w-full px-2 py-1 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded focus:ring-1 focus:ring-teal-500 tabular-nums"
                  />
                </td>
                <td className="py-2 px-3 text-right tabular-nums font-bold tabular-nums">
                  %{metrics.mechanicsPercent}
                </td>
                <td className="py-2 px-3 text-right text-[11px] tabular-nums text-slate-500">
                  Max %3.0 - %4.0
                </td>
                <td className="py-2 px-3 text-center">
                  {metrics.mechanicsPercent > 4.0 ? (
                    <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">YÜKSEK</span>
                  ) : (
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400">UYGUN</span>
                  )}
                </td>
              </tr>

              {/* Dilution Top / Softening */}
              <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="py-2 px-3 pl-6">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">Üst Sıra Gevşeme &amp; Yumuşama</div>
                  <div className="text-[10px] text-slate-400 tabular-nums">Размятые плоды в верхних слоях</div>
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={defects.dilutionTopKg || ''}
                    onChange={(e) => handleNumericChange('dilutionTopKg', e.target.value)}
                    placeholder="0.00"
                    className="w-full px-2 py-1 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded focus:ring-1 focus:ring-teal-500 tabular-nums"
                  />
                </td>
                <td className="py-2 px-3 text-right tabular-nums font-bold tabular-nums">
                  %{metrics.dilutionTopPercent}
                </td>
                <td className="py-2 px-3 text-right text-[11px] tabular-nums text-slate-500">
                  Max %3.0
                </td>
                <td className="py-2 px-3 text-center">
                  {metrics.dilutionTopPercent > 3.0 ? (
                    <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">YÜKSEK</span>
                  ) : (
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400">UYGUN</span>
                  )}
                </td>
              </tr>

              {/* 3. Easy Deformation */}
              <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="py-2 px-3 pl-6">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">Hafif Şekil Deformasyonu</div>
                  <div className="text-[10px] text-slate-400 tabular-nums">Легкая деформация плодов</div>
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={defects.easyDeformationKg || ''}
                    onChange={(e) => handleNumericChange('easyDeformationKg', e.target.value)}
                    placeholder="0.00"
                    className="w-full px-2 py-1 text-xs tabular-nums font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded focus:ring-1 focus:ring-teal-500 tabular-nums"
                  />
                </td>
                <td className="py-2 px-3 text-right tabular-nums font-bold tabular-nums">
                  %{metrics.easyDeformationPercent}
                </td>
                <td className="py-2 px-3 text-right text-[11px] tabular-nums text-slate-500">
                  Max %4.0
                </td>
                <td className="py-2 px-3 text-center">
                  <span className="text-[10px] text-slate-500">TOLERANS</span>
                </td>
              </tr>

              {/* Total Waste Summary Row */}
              <tr className="bg-white text-slate-900 font-bold border-t-2 border-slate-200">
                <td className="py-3 px-3">
                  <div className="text-sm font-bold text-amber-700">TOPLAM ATIK &amp; FİRE (ОБЩИЙ ОТХОД)</div>
                  <div className="text-[10px] text-slate-600 tabular-nums">Çürük + Standart Dışı + Deformasyon</div>
                </td>
                <td className="py-3 px-3 tabular-nums font-bold text-sm text-amber-700 tabular-nums">
                  {metrics.wasteKg} kg
                </td>
                <td className="py-3 px-3 text-right tabular-nums font-bold text-sm text-amber-700 tabular-nums">
                  %{metrics.wastePercent}
                </td>
                <td className="py-3 px-3 text-right text-xs tabular-nums text-slate-600">
                  1. Sınıf Max %{tolerances.maxWastePercent}
                </td>
                <td className="py-3 px-3 text-center">
                  {metrics.decision === 'COMPLIANT' ? (
                    <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                      UYGUN
                    </span>
                  ) : metrics.decision === 'CONDITIONAL_DISCOUNT' ? (
                    <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-700 text-[10px] font-bold border border-amber-200">
                      İSKONTO
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 text-[10px] font-bold border border-rose-200">
                      Ret / AKT
                    </span>
                  )}
                </td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
