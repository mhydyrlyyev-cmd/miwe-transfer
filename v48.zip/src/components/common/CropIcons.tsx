import React from 'react';

/** v39.1 — lucide tarzı ürün simgeleri (açık ekin): soğan ve patates. */
type P = { className?: string; 'aria-label'?: string };
const base = {
  viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2,
  strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const,
};

export const OnionIcon: React.FC<P> = ({ className = 'w-5 h-5', ...r }) => (
  <svg {...base} className={className} role="img" {...r}>
    <path d="M12 2.5c.3 1.6-.2 3-1 4.5" />
    <path d="M12 7c-4.2 1.2-7 4.6-7 8.2 0 3.2 3.1 5.3 7 5.3s7-2.1 7-5.3C19 11.6 16.2 8.2 12 7z" />
    <path d="M12 7c-2 2.2-2.9 5.4-2.7 9" />
    <path d="M12 7c2 2.2 2.9 5.4 2.7 9" />
    <path d="M10.5 20.5 10 22.5M12 20.6v1.9M13.5 20.5l.5 2" />
  </svg>
);

export const PotatoIcon: React.FC<P> = ({ className = 'w-5 h-5', ...r }) => (
  <svg {...base} className={className} role="img" {...r}>
    <path d="M6.2 7.4c2.6-3.6 8.6-4.3 11.6-1 3 3.2 1.8 9.6-2.4 12.2-4.2 2.6-10.2 2-11.8-1.6-1.2-2.8.4-6.6 2.6-9.6z" />
    <circle cx="10" cy="9.5" r=".7" fill="currentColor" />
    <circle cx="14.6" cy="11.4" r=".7" fill="currentColor" />
    <circle cx="10.6" cy="15" r=".7" fill="currentColor" />
  </svg>
);
