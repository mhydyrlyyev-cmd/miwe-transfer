import React, { useState, useEffect } from 'react';
import { X, Trash2, ZoomIn, ZoomOut, RotateCcw, ChevronLeft, ChevronRight, Download, Eye } from 'lucide-react';

interface PhotoLightboxModalProps {
  isOpen: boolean;
  photoUrl: string | null;
  photoIndex?: number;
  totalPhotos?: number;
  title?: string;
  onClose: () => void;
  onDelete?: (index: number) => void;
  onPrev?: () => void;
  onNext?: () => void;
}

export const PhotoLightboxModal: React.FC<PhotoLightboxModalProps> = ({
  isOpen,
  photoUrl,
  photoIndex = 0,
  totalPhotos = 1,
  title = 'Fotoğraf Önizleme',
  onClose,
  onDelete,
  onPrev,
  onNext,
}) => {
  const [scale, setScale] = useState(1);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    setScale(1);
    setShowDeleteConfirm(false);
  }, [photoUrl, photoIndex, isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft' && onPrev) onPrev();
      if (e.key === 'ArrowRight' && onNext) onNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onPrev, onNext, onClose]);

  if (!isOpen || !photoUrl) return null;

  const handleZoomIn = () => setScale(prev => Math.min(prev + 0.3, 3));
  const handleZoomOut = () => setScale(prev => Math.max(prev - 0.3, 0.6));
  const handleResetZoom = () => setScale(1);

  const handleDownload = () => {
    try {
      const link = document.createElement('a');
      link.href = photoUrl;
      link.download = `miwe_foto_${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error('Download error:', e);
    }
  };

  const handleConfirmDelete = () => {
    if (onDelete) {
      onDelete(photoIndex);
    }
    setShowDeleteConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/95 backdrop-blur-md flex flex-col justify-between animate-in fade-in duration-150 select-none">
      
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-3 sm:px-6 py-3 bg-slate-900/80 border-b border-slate-800 text-white z-10">
        <div className="flex items-center gap-2 min-w-0">
          <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Eye className="w-4 h-4" />
          </div>
          <div className="truncate">
            <h4 className="text-xs sm:text-sm font-bold text-slate-100 truncate">{title}</h4>
            <span className="text-[10px] text-slate-400 tabular-nums">
              {totalPhotos > 1 ? `${photoIndex + 1} / ${totalPhotos}` : 'Tekil Fotoğraf'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Zoom controls */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-800/80 rounded-xl p-0.5 border border-slate-700">
            <button
              type="button"
              onClick={handleZoomOut}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition"
              title="Uzaklaştır"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] tabular-nums px-1 text-slate-300 font-bold">{Math.round(scale * 100)}%</span>
            <button
              type="button"
              onClick={handleZoomIn}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition"
              title="Yakınlaştır"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            {scale !== 1 && (
              <button
                type="button"
                onClick={handleResetZoom}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition"
                title="Sıfırla"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Download */}
          <button
            type="button"
            onClick={handleDownload}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl border border-slate-700 transition cursor-pointer"
            title="Fotoğrafı İndir"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Delete Button */}
          {onDelete && (
            <button
              type="button"
              onClick={() => setShowDeleteConfirm(true)}
              className="p-2 bg-rose-950/50 hover:bg-rose-900/70 text-rose-300 hover:text-white rounded-xl border border-rose-800/60 transition cursor-pointer"
              title="Fotoğrafı Sil"
            >
              <Trash2 className="w-4 h-4 text-rose-400" />
            </button>
          )}

          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="p-2 bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white rounded-xl border border-slate-700 hover:border-rose-500 transition cursor-pointer ml-1"
            title="Kapat (ESC)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        
        {/* Navigation Left */}
        {onPrev && totalPhotos > 1 && (
          <button
            type="button"
            onClick={onPrev}
            className="absolute left-2 sm:left-4 z-20 p-2 sm:p-3 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 shadow-xl transition cursor-pointer hover:scale-110 active:scale-95"
            title="Önceki Fotoğraf"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        )}

        {/* The Image */}
        <div className="w-full h-full flex items-center justify-center overflow-auto max-h-[80vh]">
          <img
            src={photoUrl}
            alt={title}
            style={{ transform: `scale(${scale})` }}
            className="max-h-[75vh] max-w-[95vw] sm:max-w-[85vw] object-contain rounded-xl shadow-2xl transition-transform duration-200"
          />
        </div>

        {/* Navigation Right */}
        {onNext && totalPhotos > 1 && (
          <button
            type="button"
            onClick={onNext}
            className="absolute right-2 sm:right-4 z-20 p-2 sm:p-3 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 shadow-xl transition cursor-pointer hover:scale-110 active:scale-95"
            title="Sonraki Fotoğraf"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        )}

        {/* Delete Confirmation Overlay Dialog */}
        {showDeleteConfirm && (
          <div className="absolute inset-0 z-30 bg-black/80 flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-rose-800/80 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4 text-center animate-in zoom-in-95 duration-150">
              <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Bu fotoğrafı silmek istiyor musunuz?</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Fotoğraf form ve yerel depolamadan kaldırılacaktır.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  Vazgeç
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  Evet, Sil
                </button>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Bottom Status Bar */}
      <div className="px-4 py-2 bg-slate-900/80 border-t border-slate-800 text-center text-[11px] text-slate-400 flex items-center justify-between z-10">
        <span className="tabular-nums text-emerald-400">MIWE HIL Photo Vault</span>
        <span>Dokunarak veya büyütme butonlarıyla yakınlaştırabilirsiniz</span>
        <button
          type="button"
          onClick={onClose}
          className="text-xs text-slate-300 hover:text-white font-bold underline cursor-pointer"
        >
          Kapat
        </button>
      </div>

    </div>
  );
};
