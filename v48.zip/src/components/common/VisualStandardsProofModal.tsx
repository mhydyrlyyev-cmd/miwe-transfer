import React, { useState } from 'react';
import {
  X,
  Award,
  Globe2,
  Apple,
  Banana,
  Layers,
  FlaskConical,
  Scale,
  Thermometer,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Camera,
  Cpu,
  Boxes,
  FileSpreadsheet,
  FileText,
  Activity,
  ArrowRight,
  TrendingUp,
  Percent,
  ChevronRight,
  Sliders,
  Maximize2
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { LANGUAGES, TRANSLATIONS, Language } from '../../i18n/translations';

interface VisualStandardsProofModalProps {
  onClose: () => void;
  onOpenLedger?: () => void;
}

export const VisualStandardsProofModal: React.FC<VisualStandardsProofModalProps> = ({
  onClose,
  onOpenLedger
}) => {
  const { language, setLanguage } = useLanguage();
  const [activeTab, setActiveTab] = useState<'SCALES' | 'BANANA_ALMOND'>('SCALES');

  // Interactive Scales State
  const [selectedWsuStage, setSelectedWsuStage] = useState<number>(3);
  const [selectedAppleColor, setSelectedAppleColor] = useState<number>(75);
  const [appleBrix, setAppleBrix] = useState<number>(14.2);
  const [appleFirmness, setAppleFirmness] = useState<number>(7.8);

  // Banana & Almond Interactive Lab State
  const [bananaStage, setBananaStage] = useState<number>(2);
  const [sampleAlmondGram, setSampleAlmondGram] = useState<number>(1000);
  const [kernelAlmondGram, setKernelAlmondGram] = useState<number>(345);
  const [almondMoisture, setAlmondMoisture] = useState<number>(5.2);



  // Streif Index calculation
  const calculatedStreif = (appleFirmness / (appleBrix * selectedWsuStage)).toFixed(3);
  const streifAdvice =
    Number(calculatedStreif) > 0.20
      ? 'Erken Hasat / Çok Uzun Süreli CA (Kontrollü Atmosfer) Depolama'
      : Number(calculatedStreif) >= 0.12
      ? 'Optimum Hasat Penceresi / Standart Soğuk Hava Depolama'
      : 'Geç Hasat / Doğrudan Taze Pazar veya Hızlı Satış Sevk';

  // Almond Yield calculation
  const almondYieldPercent = ((kernelAlmondGram / sampleAlmondGram) * 100).toFixed(1);

  const BANANA_STAGES = [
    { stage: 1, name: 'Evre 1: Tam Yeşil', color: 'bg-emerald-800 text-white', desc: 'Hasat & MAP poşetine giriş. Gazlama yapılmamış, solunum bazal seviyede.' },
    { stage: 2, name: 'Evre 2: Açık Yeşil', color: 'bg-emerald-600 text-white', desc: 'Etilen odasına giriş aşaması. Yeşil kırılmaya başlamış.' },
    { stage: 3, name: 'Evre 3: Yeşil-Sarı Dönüşüm', color: 'bg-lime-600 text-white', desc: 'Dönüşüm başlangıcı. Pulp ısısı kontrol altında tutulmalı.' },
    { stage: 4, name: 'Evre 4: Sarı-Uç Yeşil (İhracat)', color: 'bg-yellow-500 text-slate-950', desc: 'Süpermarket sevk standardı. Raf ömrü en dengeli aşama.' },
    { stage: 5, name: 'Evre 5: Sarı / Yeşil Boyun', color: 'bg-amber-400 text-slate-950', desc: 'Perakende reyon sergileme. Tatlılık ve aroma yükselişte.' },
    { stage: 6, name: 'Evre 6: Tam Sarı (Tüketime Hazır)', color: 'bg-yellow-300 text-slate-950', desc: 'Tüketime hazır, nişasta şekere dönüşmüş, tam aroma.' },
    { stage: 7, name: 'Evre 7: Şeker Benekli', color: 'bg-amber-300 text-slate-950', desc: 'Yüksek brix, bal benekleri oluşmuş, aromatik tat.' }
  ];

  const WSU_STAGES = [
    { stage: 1, name: 'Skala 1', pattern: 'Tamamen Siyah', advice: 'Çok Ham (Nişasta %100)', color: '#0f172a' },
    { stage: 2, name: 'Skala 2', pattern: 'Çekirdek Çevresi Lekeli', advice: 'Erken Hasat (Uzun CA)', color: '#1e293b' },
    { stage: 3, name: 'Skala 3', pattern: 'Yarı Alan Boyalı', advice: 'Optimum CA / ULO Deposu', color: '#0d9488' },
    { stage: 4, name: 'Skala 4', pattern: 'Yarıdan Fazlası Açık', advice: 'Standart Soğuk Hava', color: '#10b981' },
    { stage: 5, name: 'Skala 5', pattern: 'Az Lekeli / Beyaz Ağırlıklı', advice: 'Hemen Taze Pazar Sevk', color: '#f59e0b' },
    { stage: 6, name: 'Skala 6', pattern: 'Tam Beyaz (Nişasta Yok)', advice: 'Aşırı Olgun / Meyve Suyu & Pazar', color: '#ef4444' }
  ];

  // WSU Stages definition

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden text-slate-900 my-auto">
        
        {/* HEADER */}
        <div className="p-4 sm:p-5 bg-white border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">Görsel standartlar</h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Elma nişasta (WSU 1–8) ve renk skalası · muz ve badem ölçüm rehberi
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TAB BUTTONS */}
        <div className="flex border-b border-slate-200 bg-slate-50/50 px-3 pt-2 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('SCALES')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-xl transition flex items-center gap-2 cursor-pointer shrink-0 ${
              activeTab === 'SCALES'
                ? 'bg-white text-emerald-700 border-t-2 border-emerald-500'
                : 'text-slate-500 hover:text-slate-200'
            }`}
          >
            <Apple className="w-4 h-4 text-rose-700" />
            <span>Elma nişasta ve renk</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('BANANA_ALMOND')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-xl transition flex items-center gap-2 cursor-pointer shrink-0 ${
              activeTab === 'BANANA_ALMOND'
                ? 'bg-white text-emerald-700 border-t-2 border-emerald-500'
                : 'text-slate-500 hover:text-slate-200'
            }`}
          >
            <Banana className="w-4 h-4 text-yellow-700" />
            <span>Muz ve badem</span>
          </button>

        </div>

        {/* MODAL BODY */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* TAB 1: ELMA WSU & STREIF İNDEKSİ */}
          {activeTab === 'SCALES' && (
            <div className="space-y-5">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Apple className="w-4 h-4 text-rose-500" />
                  <span>WSU 1-8 Nişasta-İyot Dönüşüm Diyagramı &amp; Streif İndeksi Formülü</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Operatörler ezbere tahmin yapmaz; elmanın ekvatoral kesitine sürülen Lugol iyot çözeltisinin boyanma desenine göre WSU skalasını seçer. Sistem arka planda Streif İndeksi formülünü (SI = Sertlik / [Brix × Nişasta]) anlık hesaplayarak optimum soğuk depo rejimini belirler.
                </p>
              </div>

              {/* Interactive WSU Buttons */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-600 block">
                  İyot Boyanma Desenini Seçin (WSU Skalası):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                  {WSU_STAGES.map(item => {
                    const isSelected = selectedWsuStage === item.stage;
                    return (
                      <button
                        key={item.stage}
                        type="button"
                        onClick={() => setSelectedWsuStage(item.stage)}
                        className={`p-3 rounded-xl text-center border transition cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/50'
                            : 'bg-slate-50 hover:bg-slate-50 border-slate-200'
                        }`}
                      >
                        {/* Visual SVG Apple Slice Cross-Section */}
                        <div className="w-14 h-14 mx-auto mb-2 relative flex items-center justify-center">
                          <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow">
                            <circle cx="50" cy="50" r="44" fill="#fef08a" stroke="#ca8a04" strokeWidth="3" />
                            {/* Inner iodine staining pattern */}
                            {item.stage === 1 && <circle cx="50" cy="50" r="38" fill="#1e1b4b" opacity="0.9" />}
                            {item.stage === 2 && <circle cx="50" cy="50" r="28" fill="#1e1b4b" opacity="0.85" />}
                            {item.stage === 3 && <circle cx="50" cy="50" r="20" fill="#1e1b4b" opacity="0.8" />}
                            {item.stage === 4 && <circle cx="50" cy="50" r="14" fill="#1e1b4b" opacity="0.7" />}
                            {item.stage === 5 && <circle cx="50" cy="50" r="8" fill="#1e1b4b" opacity="0.6" />}
                            {item.stage === 6 && <circle cx="50" cy="50" r="2" fill="#1e1b4b" opacity="0.4" />}
                            {/* Core seed pocket */}
                            <circle cx="50" cy="50" r="5" fill="#451a03" />
                          </svg>
                        </div>
                        <div className="tabular-nums font-bold text-xs text-slate-900">{item.name}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{item.pattern}</div>
                        <div className="text-[9px] font-bold text-emerald-700 mt-1">{item.advice}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Streif Formula Live Output */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 block">Sertlik (kg/cm²)</label>
                  <input
                    type="range"
                    min="5"
                    max="10"
                    step="0.1"
                    value={appleFirmness}
                    onChange={(e) => setAppleFirmness(Number(e.target.value))}
                    className="w-full accent-emerald-500 mt-1"
                  />
                  <div className="tabular-nums text-sm font-bold text-slate-900 mt-0.5">{appleFirmness} kg/cm²</div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-500 block">Brix Şeker (°Bx)</label>
                  <input
                    type="range"
                    min="10"
                    max="18"
                    step="0.1"
                    value={appleBrix}
                    onChange={(e) => setAppleBrix(Number(e.target.value))}
                    className="w-full accent-emerald-500 mt-1"
                  />
                  <div className="tabular-nums text-sm font-bold text-slate-900 mt-0.5">{appleBrix} °Bx</div>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center flex flex-col justify-center">
                  <span className="text-[10px] font-bold text-slate-500">Hesaplanan Streif İndeksi</span>
                  <div className="text-xl tabular-nums font-bold text-emerald-700 mt-0.5">{calculatedStreif}</div>
                  <span className="text-[10px] text-slate-600 font-semibold mt-0.5">{streifAdvice}</span>
                </div>
              </div>

              {/* Apple Color Scale (0-100%) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">Elma Üst Renk / Zemin Renk Baremi (%):</span>
                  <span className="tabular-nums font-bold text-xs text-rose-700">%{selectedAppleColor} Kırmızı Renklenme</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={selectedAppleColor}
                  onChange={(e) => setSelectedAppleColor(Number(e.target.value))}
                  className="w-full accent-rose-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 tabular-nums">
                  <span>%20 (Zemin Yeşil / Alaca)</span>
                  <span>%50 (1. Sınıf Ticari Minimum)</span>
                  <span>%75 (Ekstra Sınıf İhracat)</span>
                  <span>%100 (Tam Kırmızı)</span>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: MUZ MAP & BADEM LABORATUVARI */}
          {activeTab === 'BANANA_ALMOND' && (
            <div className="space-y-6">
              
              {/* BANANA 7-STAGE RIPENESS */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Banana className="w-4 h-4 text-yellow-700" />
                    <span>Muz 7-Aşamalı Renk Skalası &amp; MAP Gaz Toleransları</span>
                  </h3>
                  <span className="text-xs tabular-nums text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-800/60">
                    Aktif: Evre {bananaStage}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                  {BANANA_STAGES.map(s => {
                    const isSelected = bananaStage === s.stage;
                    return (
                      <button
                        key={s.stage}
                        type="button"
                        onClick={() => setBananaStage(s.stage)}
                        className={`p-3 rounded-xl text-left border transition cursor-pointer ${
                          isSelected
                            ? 'bg-white border-yellow-400 ring-2 ring-yellow-400/40'
                            : 'bg-slate-50 hover:bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-xs text-slate-900">{s.name}</span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${s.color}`}>
                            Renk {s.stage}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 leading-snug">{s.desc}</p>
                      </button>
                    );
                  })}
                </div>

                {/* MAP Gas specs */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500">MAP O₂ Toleransı</span>
                    <div className="text-base font-bold text-slate-900 tabular-nums mt-0.5">%2 - %5 O₂</div>
                    <span className="text-[10px] text-slate-500">Solunum kırıcı tepe boşluğu</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500">MAP CO₂ Toleransı</span>
                    <div className="text-base font-bold text-slate-900 tabular-nums mt-0.5">%3 - %5 CO₂</div>
                    <span className="text-[10px] text-slate-500">Kararma yapmayan güvenli sınır</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500">Etilen Absorber Şase</span>
                    <div className="text-base font-bold text-emerald-700 tabular-nums mt-0.5">KMnO₄ Aktif</div>
                    <span className="text-[10px] text-slate-500">&lt;0.05 ppm dinlendirme koruması</span>
                  </div>
                </div>
              </div>

              {/* ALMOND LAB & YIELD CALCULATOR */}
              <div className="space-y-3 pt-4 border-t border-slate-200">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Scale className="w-4 h-4 text-amber-500" />
                  <span>Badem Laboratuvarı: İç Randıman (%) &amp; Denge Nem Kılavuzu</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block">Numune Ağırlığı (g)</label>
                    <input
                      type="number"
                      value={sampleAlmondGram}
                      onChange={(e) => setSampleAlmondGram(Number(e.target.value) || 1)}
                      className="w-full bg-white text-slate-900 tabular-nums text-sm px-2.5 py-1.5 rounded border border-slate-200 mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block">Kırılmış İç Badem (g)</label>
                    <input
                      type="number"
                      value={kernelAlmondGram}
                      onChange={(e) => setKernelAlmondGram(Number(e.target.value) || 0)}
                      className="w-full bg-white text-slate-900 tabular-nums text-sm px-2.5 py-1.5 rounded border border-slate-200 mt-1"
                    />
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center flex flex-col justify-center">
                    <span className="text-[10px] font-bold text-slate-500">Hesaplanan İç Randımanı</span>
                    <div className="text-xl tabular-nums font-bold text-amber-700 mt-0.5">%{almondYieldPercent}</div>
                    <span className="text-[10px] text-slate-500">Hedef: %28 - %40 Ticari Standart</span>
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">Denge Nemi &amp; Su Aktivitesi Kuralı:</span>
                    <span className="text-slate-500 text-[11px]">
                      Depolama için iç badem nemi %4.5 - %6.0 arasında olmalı, su aktivitesi Aw &le; 0.55 kalmalıdır (Aflatoksin küf riskini sıfırlar).
                    </span>
                  </div>
                  <div className="tabular-nums text-emerald-700 font-bold bg-white px-3 py-1.5 rounded-lg border border-slate-200 shrink-0">
                    Ölçülen Nem: %{almondMoisture} (UYGUN)
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* MODAL FOOTER */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 text-xs">
          <span className="text-slate-500 text-[11px]">Skalalar ölçümde referans içindir; karar ürünün kabul kartına göre verilir.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-white hover:bg-slate-50 text-slate-900 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
