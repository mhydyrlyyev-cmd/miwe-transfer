import React, { useState } from 'react';
import { Camera, CheckCircle2, Clock, XCircle, ShieldCheck, Trash2, Upload, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { AppUser } from '../../types/auth';

export interface EvidenceRecord {
  id: string;
  refId: string;
  moduleKey: string;
  title: string;
  photoUrl: string;
  uploaderName: string;
  createdAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  adminNote?: string;
}

interface ModuleEvidenceSectionProps {
  moduleKey: string;
  refId: string;
  currentUser?: AppUser | null;
  evidences?: EvidenceRecord[];
  onAddEvidence: (record: EvidenceRecord) => void;
  onUpdateStatus: (evidenceId: string, status: 'APPROVED' | 'REJECTED', adminNote?: string) => void;
  onDeleteEvidence: (evidenceId: string) => void;
}

export const ModuleEvidenceSection: React.FC<ModuleEvidenceSectionProps> = ({
  moduleKey,
  refId,
  currentUser,
  evidences = [],
  onAddEvidence,
  onUpdateStatus,
  onDeleteEvidence
}) => {
  const [title, setTitle] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');

  const filteredEvidences = evidences.filter(e => e.moduleKey === moduleKey && (!refId || e.refId === refId));

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setPhotoUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoUrl) return;

    const newRec: EvidenceRecord = {
      id: `ev-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      refId: refId || 'REF-GENEL',
      moduleKey,
      title: title.trim() || 'Modül Kanıt Dosyası',
      photoUrl,
      uploaderName: currentUser?.fullName || 'Saha Personeli',
      createdAt: new Date().toISOString(),
      status: 'PENDING'
    };

    onAddEvidence(newRec);
    setTitle('');
    setPhotoUrl('');
  };

  const isAdmin = currentUser?.role === 'ADMIN';

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4 shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
              {moduleKey} Modülü • Kanıtlar &amp; Doğrulama Sekmesi
            </h4>
            <p className="text-[11px] text-slate-500">
              Bu modüle özel yüklenen kanıt fotoğrafları ve laboratuvar raporları (RefID: {refId || 'Genel'})
            </p>
          </div>
        </div>
        <span className="px-2.5 py-1 rounded-full text-[10px] tabular-nums font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
          {filteredEvidences.length} Kanıt Kaydı
        </span>
      </div>

      {/* Upload Form */}
      <form onSubmit={handleSubmit} className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
              Kanıt Başlığı / Açıklaması *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Örn: Nişasta İyot Test Rengi / Laboratuvar Sonucu"
              className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              required
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
              Fotoğraf / Belge Dosyası *
            </label>
            <div className="flex items-center gap-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100 cursor-pointer"
                required={!photoUrl}
              />
            </div>
          </div>
        </div>

        {photoUrl && (
          <div className="flex items-center gap-3 pt-2">
            <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-300 bg-slate-200">
              <img src={photoUrl} alt="Önizleme" className="w-full h-full object-cover" />
            </div>
            <span className="text-xs text-teal-600 font-bold"> Fotoğraf yüklendi, kaydetmeye hazır.</span>
          </div>
        )}

        <div className="flex justify-end pt-1">
          <button
            type="submit"
            disabled={!photoUrl}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
          >
            + Modül Kanıtını Kaydet
          </button>
        </div>
      </form>

      {/* Evidences List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {filteredEvidences.length === 0 ? (
          <div className="col-span-full p-6 text-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-300 dark:border-slate-800">
            <p className="text-xs text-slate-400 font-medium">Bu modül için henüz kanıt dosyası yüklenmemiştir.</p>
          </div>
        ) : (
          filteredEvidences.map((ev) => (
            <div key={ev.id} className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50 dark:bg-slate-950 flex flex-col justify-between shadow-xs">
              <div className="relative aspect-video bg-slate-200 dark:bg-slate-900">
                <img src={ev.photoUrl} alt={ev.title} className="w-full h-full object-cover" />
                <div className="absolute top-2 left-2">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold tabular-nums shadow-md ${
                    ev.status === 'APPROVED' ? 'bg-emerald-600 text-white' :
                    ev.status === 'REJECTED' ? 'bg-rose-600 text-white' :
                    'bg-amber-500 text-slate-950'
                  }`}>
                    {ev.status === 'APPROVED' ? '✓ Onaylı' : ev.status === 'REJECTED' ? '✗ Reddedildi' : '⏳ Bekliyor'}
                  </span>
                </div>
              </div>

              <div className="p-3 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h5 className="font-bold text-slate-900 dark:text-white text-xs truncate" title={ev.title}>
                    {ev.title}
                  </h5>
                  <div className="text-[10px] text-slate-500 flex items-center justify-between mt-1">
                    <span>Yükleyen: {ev.uploaderName}</span>
                    <span className="tabular-nums">{ev.createdAt?.slice(0, 10)}</span>
                  </div>
                </div>

                {/* Admin Verification Actions */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-1">
                  {isAdmin ? (
                    <div className="flex items-center gap-1 w-full">
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(ev.id, 'APPROVED')}
                        className="flex-1 py-1 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition cursor-pointer text-center"
                      >
                        Onayla
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(ev.id, 'REJECTED')}
                        className="flex-1 py-1 px-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-[10px] font-bold transition cursor-pointer text-center"
                      >
                        Reddet
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteEvidence(ev.id)}
                        className="p-1 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-300 rounded-lg transition cursor-pointer"
                        title="Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] text-slate-400 tabular-nums">RefID: {ev.refId}</span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
