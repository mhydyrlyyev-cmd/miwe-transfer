import React, { useState, useEffect } from 'react';
import { ChevronUp } from 'lucide-react';

export const ScrollToTopButton: React.FC = () => {
  const [isVisible, setIsVisible] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollPos > 240) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    // Also run once initially
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      type="button"
      onClick={scrollToTop}
      aria-label="Sayfanın En Üstüne Çık"
      title="Yukarı Çık"
      className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-50 w-12 h-12 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-2xl shadow-teal-950/60 border border-teal-300/40 flex items-center justify-center cursor-pointer active:scale-90 hover:scale-105 transition-all duration-300 group backdrop-blur-md animate-in fade-in zoom-in-75"
    >
      <ChevronUp className="w-6 h-6 stroke-[3] group-hover:-translate-y-0.5 transition-transform drop-shadow" />
      <span className="sr-only">Yukarı Çık</span>
    </button>
  );
};
