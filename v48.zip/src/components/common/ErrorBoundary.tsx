import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RefreshCw, ClipboardCopy, Terminal } from 'lucide-react';
import { logSystemError, generateDeveloperReport } from '../../utils/debugLogger';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
  copied: boolean;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public override state: State = {
    hasError: false,
    error: null,
    copied: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, copied: false };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    logSystemError('RUNTIME_ERROR', `React Bileşen Hatası: ${error.message}`, {
      componentStack: errorInfo.componentStack,
      name: error.name,
      stack: error.stack
    });
  }

  private handleCopyReport = () => {
    const report = generateDeveloperReport();
    const onDone = () => {
      this.setState({ copied: true });
      setTimeout(() => this.setState({ copied: false }), 3000);
    };

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(report).then(onDone).catch(() => {
        try {
          const textarea = document.createElement('textarea');
          textarea.value = report;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          onDone();
        } catch (e) {
          console.warn('ErrorBoundary copy failed:', e);
        }
      });
    } else {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = report;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        onDone();
      } catch (e) {
        console.warn('ErrorBoundary execCommand failed:', e);
      }
    }
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[400px] flex items-center justify-center p-6 bg-slate-50 dark:bg-slate-950">
          <div className="max-w-lg w-full bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 rounded-2xl p-6 shadow-xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-200 dark:border-rose-800">
              <AlertOctagon className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {this.props.fallbackTitle || 'Arayüzde Bir Hata Tespit Edildi'}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                Bu hata sistem tarafından otomatik olarak <strong>Hata Defteri</strong>'ne kaydedildi. Verileriniz korunmaktadır.
              </p>
            </div>

            {this.state.error && (
              <div className="bg-slate-100 dark:bg-slate-950 rounded-xl p-3 text-left tabular-nums text-[11px] text-rose-600 dark:text-rose-400 border border-slate-200 dark:border-slate-800 max-h-32 overflow-y-auto">
                <span className="font-bold">{this.state.error.name}: </span>
                {this.state.error.message}
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold flex items-center justify-center gap-2 transition hover:opacity-90 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Sayfayı Yenile</span>
              </button>

              <button
                type="button"
                onClick={this.handleCopyReport}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <ClipboardCopy className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>{this.state.copied ? '✓ Rapor Panoya Kopyalandı!' : 'Hata Raporunu Kopyala'}</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
