import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Sparkles, 
  Plus, 
  Check, 
  X, 
  Tag, 
  Info, 
  Layers, 
  Trash2,
  ChevronDown,
  Save
} from 'lucide-react';
import { StandardQualityClassKey, STANDARD_QUALITY_CLASSES, QualityClassDefinition } from '../../types';

const CUSTOM_CLASSES_STORAGE_KEY = 'agri_custom_quality_classes';

// Helper to get all quality classes (built-in + user added)
export const getAllQualityClasses = (): QualityClassDefinition[] => {
  try {
    const customStored = localStorage.getItem(CUSTOM_CLASSES_STORAGE_KEY);
    if (customStored) {
      const parsed: QualityClassDefinition[] = JSON.parse(customStored);
      return [...STANDARD_QUALITY_CLASSES, ...parsed];
    }
  } catch (e) {
    console.error('Error loading custom quality classes:', e);
  }
  return STANDARD_QUALITY_CLASSES;
};

// Helper to save a new custom quality class
export const saveCustomQualityClass = (newClass: QualityClassDefinition): QualityClassDefinition[] => {
  try {
    const customStored = localStorage.getItem(CUSTOM_CLASSES_STORAGE_KEY);
    const existing: QualityClassDefinition[] = customStored ? JSON.parse(customStored) : [];
    
    // Check if key already exists
    const filtered = existing.filter(c => c.key.toLowerCase() !== newClass.key.toLowerCase());
    const updated = [...filtered, newClass];
    localStorage.setItem(CUSTOM_CLASSES_STORAGE_KEY, JSON.stringify(updated));
    
    // Dispatch a storage event so all components update
    window.dispatchEvent(new Event('custom-quality-classes-updated'));
    return [...STANDARD_QUALITY_CLASSES, ...updated];
  } catch (e) {
    console.error('Error saving custom quality class:', e);
    return STANDARD_QUALITY_CLASSES;
  }
};

// Helper to remove custom quality class
export const removeCustomQualityClass = (key: string): QualityClassDefinition[] => {
  try {
    const customStored = localStorage.getItem(CUSTOM_CLASSES_STORAGE_KEY);
    if (customStored) {
      const existing: QualityClassDefinition[] = JSON.parse(customStored);
      const filtered = existing.filter(c => c.key !== key);
      localStorage.setItem(CUSTOM_CLASSES_STORAGE_KEY, JSON.stringify(filtered));
      window.dispatchEvent(new Event('custom-quality-classes-updated'));
      return [...STANDARD_QUALITY_CLASSES, ...filtered];
    }
  } catch (e) {
    console.error('Error removing custom quality class:', e);
  }
  return STANDARD_QUALITY_CLASSES;
};

interface QualityGradeSelectProps {
  value?: StandardQualityClassKey | string;
  onChange: (value: StandardQualityClassKey | string) => void;
  label?: string;
  subLabel?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  showBadge?: boolean;
  compact?: boolean;
  id?: string;
}

export const QualityGradeSelect: React.FC<QualityGradeSelectProps> = ({
  value = 'EXTRA (V-20)',
  onChange,
  label = 'Kalite Sınıfı (Hil Derejesi)',
  subLabel = 'Standart görünüş, kalibre ve kalite klasmanı',
  required = false,
  disabled = false,
  className = '',
  showBadge = true,
  compact = false,
  id
}) => {
  const [classList, setClassList] = useState<QualityClassDefinition[]>(getAllQualityClasses);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newKey, setNewKey] = useState<string>('');
  const [newNameTr, setNewNameTr] = useState<string>('');
  const [newNameTm, setNewNameTm] = useState<string>('');
  const [newDesc, setNewDesc] = useState<string>('');
  const [newColor, setNewColor] = useState<string>('purple');

  const elementId = id || `quality-select-${Math.random().toString(36).substring(2, 7)}`;

  // Listen to custom quality class updates across tabs / components
  useEffect(() => {
    const handleUpdate = () => {
      setClassList(getAllQualityClasses());
    };
    window.addEventListener('custom-quality-classes-updated', handleUpdate);
    return () => {
      window.removeEventListener('custom-quality-classes-updated', handleUpdate);
    };
  }, []);

  // Find currently selected definition
  const selectedDef = classList.find(c => c.key === value) || {
    key: value || 'EXTRA (V-20)',
    nameTr: value || 'Ekstra Kalite',
    nameTm: value || 'Ekstra Hil',
    nameEn: value || 'Custom Grade',
    description: 'Seçili Kalite Sınıfı',
    badgeClass: 'bg-emerald-100 text-emerald-900 border-emerald-300'
  };

  const handleAddNewClass = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    if (!newKey.trim()) return;

    let badgeClass = 'bg-purple-100 text-purple-900 border-purple-300';
    if (newColor === 'emerald') badgeClass = 'bg-emerald-100 text-emerald-900 border-emerald-300';
    if (newColor === 'teal') badgeClass = 'bg-teal-100 text-teal-900 border-teal-300';
    if (newColor === 'blue') badgeClass = 'bg-blue-100 text-blue-900 border-blue-300';
    if (newColor === 'amber') badgeClass = 'bg-amber-100 text-amber-900 border-amber-300';
    if (newColor === 'orange') badgeClass = 'bg-orange-100 text-orange-900 border-orange-300';
    if (newColor === 'rose') badgeClass = 'bg-rose-100 text-rose-900 border-rose-300';

    const customDef: QualityClassDefinition = {
      key: newKey.trim(),
      nameTr: newNameTr.trim() || newKey.trim(),
      nameTm: newNameTm.trim() || newKey.trim(),
      nameEn: newKey.trim(),
      description: newDesc.trim() || 'Kullanıcı tanımlı özel kalite sınıfı',
      badgeClass
    };

    saveCustomQualityClass(customDef);
    setClassList(getAllQualityClasses());
    onChange(customDef.key);

    // Reset & close
    setNewKey('');
    setNewNameTr('');
    setNewNameTm('');
    setNewDesc('');
    setShowAddModal(false);
  };

  const isCustomKey = (key: string) => {
    return !STANDARD_QUALITY_CLASSES.some(sc => sc.key === key);
  };

  const handleDeleteCustom = (keyToDelete: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (window.confirm(`"${keyToDelete}" kalite sınıfını silmek istediğinize emin misiniz?`)) {
      const updated = removeCustomQualityClass(keyToDelete);
      setClassList(updated);
      if (value === keyToDelete) {
        onChange('EXTRA (V-20)');
      }
    }
  };

  return (
    <div className={`space-y-1.5 ${className}`} id={`container-${elementId}`}>
      {/* Label and Add Button */}
      <div className="flex items-center justify-between gap-2">
        <label htmlFor={elementId} className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
          <Award className="w-3.5 h-3.5 text-emerald-600" />
          <span>{label}</span>
          {required && <span className="text-rose-500 font-bold">*</span>}
        </label>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1 transition cursor-pointer"
          title="Täze Kalite Sınıfı Ekle"
        >
          <Plus className="w-3 h-3 text-emerald-600" />
          <span>+ Täze Klas Goş (Yeni Ekle)</span>
        </button>
      </div>

      {/* Main Select Input */}
      <div className="relative">
        <select
          id={elementId}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
          className={`w-full text-xs font-bold rounded-lg border bg-white px-3 py-2.5 shadow-2xs focus:ring-2 focus:ring-emerald-500 focus:outline-none transition appearance-none cursor-pointer ${
            selectedDef.isProcessingOrNonStandard 
              ? 'border-rose-300 text-rose-900 bg-rose-50/20' 
              : 'border-slate-300 text-slate-900'
          }`}
        >
          <optgroup label="📋 Sistem Örnek Kalite Sınıfları">
            {STANDARD_QUALITY_CLASSES.map((cls) => (
              <option key={cls.key} value={cls.key}>
                {cls.key === 'EXTRA (V-20)' && '✨ '}
                {cls.key === 'I (V-22) EXC' && '🟢 '}
                {cls.key === 'II (V-24) PRM' && '🔵 '}
                {cls.key === 'III (V26-28) CLS' && '🟡 '}
                {cls.key === 'Mix' && '🔀 '}
                {cls.key.includes('Standart Däl') && '⚙️ '}
                {cls.key} — {cls.nameTr} (Örn)
              </option>
            ))}
          </optgroup>

          {/* User Custom Classes */}
          {classList.some(c => isCustomKey(c.key)) && (
            <optgroup label="⭐ Kaydedilen / Eklenen Kalite Sınıfları">
              {classList.filter(c => isCustomKey(c.key)).map((cls) => (
                <option key={cls.key} value={cls.key}>
                  ⭐ {cls.key} — {cls.nameTr}
                </option>
              ))}
            </optgroup>
          )}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-slate-500">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>

      {/* Selected Grade Badge & Description */}
      {showBadge && selectedDef && !compact && (
        <div className={`p-2 rounded-lg border text-xs flex items-start justify-between gap-2 transition ${selectedDef.badgeClass}`}>
          <div className="flex flex-col gap-0.5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="tabular-nums font-bold text-xs">{selectedDef.key}</span>
              <span className="font-semibold text-slate-700">• {selectedDef.nameTr}</span>
              <span className="text-[10px] text-slate-500 italic">({selectedDef.nameTm})</span>
            </div>
            {selectedDef.description && (
              <p className="text-[11px] text-slate-600 leading-tight">
                {selectedDef.description}
              </p>
            )}
          </div>

          {/* If custom, allow deleting */}
          {isCustomKey(selectedDef.key) && (
            <button
              type="button"
              onClick={(e) => handleDeleteCustom(selectedDef.key, e)}
              className="p-1 text-rose-600 hover:text-rose-800 hover:bg-rose-100 rounded transition shrink-0"
              title="Bu özel kalite sınıfını sil"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Quick Add Custom Quality Class Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Täze Kalite Sınıfı Ekle</h3>
                  <p className="text-xs text-slate-500">Tüm form ve modüllerde geçerli yeni kalite klası tanımlayın</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Kalite Sınıf Kodu / Kısa Adı * (Örn: EXTRA PLUS, IV-V, ÖZEL-01)
                </label>
                <input
                  type="text"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddNewClass(e);
                    }
                  }}
                  placeholder="Örn: EXTRA PLUS (V-18)"
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  required
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Türkçe Açıklama Adı
                  </label>
                  <input
                    type="text"
                    value={newNameTr}
                    onChange={(e) => setNewNameTr(e.target.value)}
                    placeholder="Örn: Süper Seçkin İhracat"
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Türkmence Adı (Türkmençe)
                  </label>
                  <input
                    type="text"
                    value={newNameTm}
                    onChange={(e) => setNewNameTm(e.target.value)}
                    placeholder="Örn: Ýokary Hil Eksport"
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Kalite Kriteri & Açıklaması
                </label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Örn: 80mm+ ekstra kalibre, sıfır leke toleranslı birinci ihracat seçimleri."
                  rows={2}
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 resize-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Rozet Rengi & Teması
                </label>
                <div className="flex items-center gap-2">
                  {[
                    { id: 'emerald', bg: 'bg-emerald-500', name: 'Yeşil' },
                    { id: 'teal', bg: 'bg-teal-500', name: 'Teal' },
                    { id: 'blue', bg: 'bg-blue-500', name: 'Mavi' },
                    { id: 'amber', bg: 'bg-amber-500', name: 'Sarı' },
                    { id: 'orange', bg: 'bg-orange-500', name: 'Turuncu' },
                    { id: 'purple', bg: 'bg-purple-500', name: 'Mor' },
                    { id: 'rose', bg: 'bg-rose-500', name: 'Kırmızı' },
                  ].map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setNewColor(c.id)}
                      className={`w-7 h-7 rounded-full ${c.bg} transition flex items-center justify-center cursor-pointer ${
                        newColor === c.id ? 'ring-2 ring-offset-2 ring-slate-800 scale-110' : 'opacity-70 hover:opacity-100'
                      }`}
                      title={c.name}
                    >
                      {newColor === c.id && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  İptal
                </button>
                <button
                  type="button"
                  onClick={handleAddNewClass}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Kalite Sınıfını Kaydet & Seç</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
