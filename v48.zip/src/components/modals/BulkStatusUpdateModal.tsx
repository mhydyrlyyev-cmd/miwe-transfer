import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Truck,
  Warehouse,
  AlertTriangle,
  Lock,
  Unlock,
  Layers,
  X,
  ShieldCheck,
  FileCheck,
  AlertCircle
} from 'lucide-react';
import { ReferenceItem, ReferenceStatus } from '../../types';

interface BulkStatusUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRefs: ReferenceItem[];
  onConfirmBulkUpdate: (
    refIds: string[],
    newStatus: ReferenceStatus,
    options: {
      notes?: string;
      isLocked?: boolean;
      operator?: string;
    }
  ) => void;
  currentUserId?: string;
}

const STATUS_OPTIONS: Array<{
  value: ReferenceStatus;
  label: string;
  sublabel: string;
  badgeClass: string;
  icon: React.ReactNode;
  defaultLock?: boolean;
}> = [
  {
    value: 'COMPLETED',
    label: 'Tamamlandı',
    sublabel: 'İşlem bitti, kalite onaylandı ve kayıt arşivlendi',
    badgeClass: 'bg-emerald-950 text-emerald-300 border-emerald-600',
    icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
    defaultLock: true
  },
  {
    value: 'CREATED',
    label: 'Sahada (CREATED)',
    sublabel: 'Parti açıldı, saha/hasat aşamasında işleme hazır',
    badgeClass: 'bg-blue-100 text-blue-900 border-blue-300',
    icon: <Clock className="w-4 h-4 text-blue-600" />,
    defaultLock: false
  },
  {
    value: 'SHIPPED',
    label: 'Yolda / Sevk Edildi (SHIPPED)',
    sublabel: 'Lojistik araca yüklendi ve transit transferde',
    badgeClass: 'bg-amber-100 text-amber-900 border-amber-300',
    icon: <Truck className="w-4 h-4 text-amber-600" />,
    defaultLock: false
  },
  {
    value: 'RECEIVED',
    label: 'Depoda / Kabul Edildi (RECEIVED)',
    sublabel: 'Merkez soğuk hava deposuna kabul edildi ve stoklandı',
    badgeClass: 'bg-teal-100 text-teal-900 border-teal-300',
    icon: <Warehouse className="w-4 h-4 text-teal-600" />,
    defaultLock: false
  },
  {
    value: 'INCIDENT',
    label: 'Incident / Tutanak (INCIDENT)',
    sublabel: 'Kalite sapması veya kaza tutanağı incelemesinde',
    badgeClass: 'bg-rose-100 text-rose-900 border-rose-300',
    icon: <AlertTriangle className="w-4 h-4 text-rose-600" />,
    defaultLock: false
  }
];

export const BulkStatusUpdateModal: React.FC<BulkStatusUpdateModalProps> = ({
  isOpen,
  onClose,
  selectedRefs,
  onConfirmBulkUpdate,
  currentUserId
}) => {
  const [targetStatus, setTargetStatus] = useState<ReferenceStatus>('COMPLETED');
  const [bulkNotes, setBulkNotes] = useState<string>('');
  const [isLocked, setIsLocked] = useState<boolean>(true);
  const [operator, setOperator] = useState<string>(currentUserId || 'Kalite Kontrol');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen || selectedRefs.length === 0) return null;

  const handleStatusChange = (status: ReferenceStatus) => {
    setTargetStatus(status);
    const option = STATUS_OPTIONS.find(o => o.value === status);
    if (option?.defaultLock !== undefined) {
      setIsLocked(option.defaultLock);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const refIds = selectedRefs.map(r => r.refId);
      onConfirmBulkUpdate(refIds, targetStatus, {
        notes: bulkNotes.trim() || undefined,
        isLocked,
        operator: operator.trim() || undefined
      });
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        
        {/* Header */}
        <div className="bg-[#0f4a33] text-white px-5 py-4 flex items-center justify-between border-b border-emerald-950 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  Toplu Durum Güncelleme / Bulk Status Update
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                  {selectedRefs.length} Parti Seçili
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Seçilen tüm referans kayıtlarının durumunu ve kilit ayarını tek işlemle güncelleyin.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-900/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {/* 1. Hedef Durum Seçici */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-200">
              1. Yeni Durum Seçiniz / Select New Status *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {STATUS_OPTIONS.map(opt => {
                const isSelected = targetStatus === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => handleStatusChange(opt.value)}
                    className={`p-3 rounded-xl border text-left transition flex items-start gap-2.5 cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 ring-2 ring-emerald-500/30 text-slate-900 dark:text-white shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="p-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shrink-0 mt-0.5">
                      {opt.icon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold text-xs">{opt.label}</span>
                        {isSelected && (
                          <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                             Seçili
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                        {opt.sublabel}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Kilit & Güvenlik Ayarları */}
          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3.5 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isLocked ? (
                  <Lock className="w-4 h-4 text-amber-600" />
                ) : (
                  <Unlock className="w-4 h-4 text-slate-500" />
                )}
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    Kayıtları Kilitle (Salt Okunur Yap)
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {isLocked 
                      ? 'Kayıtlar salt okunur yapılacak, sonradan yetkisiz düzenleme engellenecek.' 
                      : 'Kayıtlar düzenlemeye açık kalacak.'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsLocked(!isLocked)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  isLocked
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 font-bold'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300'
                }`}
              >
                {isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                <span>{isLocked ? 'Kilitli' : 'Kilitsiz'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Onaylayan Sorumlu / Operatör:
                </label>
                <input
                  type="text"
                  value={operator}
                  onChange={(e) => setOperator(e.target.value)}
                  placeholder="Operatör veya Yönetici adı..."
                  className="w-full text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Toplu İşlem Notu / Gerekçe (Opsiyonel):
                </label>
                <input
                  type="text"
                  value={bulkNotes}
                  onChange={(e) => setBulkNotes(e.target.value)}
                  placeholder="Örn: Saha testi tamamlandı, toplu onaylandı."
                  className="w-full text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
                />
              </div>
            </div>
          </div>

          {/* 3. Etkilenecek Kayıtlar Listesi */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span>Etkilenecek Partiler ({selectedRefs.length}):</span>
              <span className="text-slate-500">Mevcut Durum → Yeni Durum</span>
            </div>

            <div className="max-h-40 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-xl divide-y divide-slate-100 dark:divide-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
              {selectedRefs.map((ref) => (
                <div key={ref.refId} className="px-3 py-2 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="tabular-nums font-bold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                      <span>{ref.refId}</span>
                      <span className="text-slate-400 font-normal">•</span>
                      <span className="text-slate-700 dark:text-slate-300 truncate font-semibold">
                        {ref.product}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {ref.orchard || ref.location || ref.source || '-'} • {(ref.quantity ?? 0).toLocaleString('tr-TR')} {ref.unit}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 text-[10px] tabular-nums">
                    <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {ref.status}
                    </span>
                    <span className="text-emerald-500 font-bold">→</span>
                    <span className="px-1.5 py-0.5 rounded font-bold bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700">
                      {targetStatus}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              Vazgeç
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-98 rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <FileCheck className="w-4 h-4 text-emerald-200" />
              <span>{selectedRefs.length} Kaydı Toplu Güncelle</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
