import React, { useState } from 'react';
import { X, ShieldAlert, AlertTriangle, CheckCircle2, MessageSquare } from 'lucide-react';

interface BulkRejectModalProps {
  isOpen: boolean;
  selectedCount: number;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

const PRESET_REASONS = [
  'Soğuk Hasarı & Isı Zinciri İhlali',
  'Brix / Şeker Oranı Mükemmellik Sınırı Altında',
  'Mekanik Ezilme, Darbe & Ağır Kusur',
  'Mikrobiyolojik Çürüklük / Küf Tespiti',
  'Standart Dışı Kalibre & GOST Uyumsuzluğu'
];

export const BulkRejectModal: React.FC<BulkRejectModalProps> = ({
  isOpen,
  selectedCount,
  onClose,
  onConfirm
}) => {
  const [reason, setReason] = useState(PRESET_REASONS[0]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    onConfirm(reason.trim());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden text-slate-900 dark:text-white flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-rose-950 text-white flex items-center justify-between gap-3 border-b border-rose-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base tracking-tight text-rose-100">
                Toplu Reddet (REJECTED) &amp; Ret Bayrağı Koy
              </h3>
              <p className="text-xs text-rose-300 tabular-nums">
                {selectedCount} Adet Seçili Parti Etkileniyor
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-rose-300 hover:text-white rounded-lg bg-rose-900/50 hover:bg-rose-900 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200 space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>DİKKAT: Yönetici Ret Protokolü</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Seçilen <strong>{selectedCount}</strong> adet parti durumu 'REJECTED' olarak güncellenecek, partiler kilitlenecek ve tüm sistem yöneticilerine otomatik bildirim iletilecektir.
            </p>
          </div>

          {/* Preset Reasons */}
          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
              Hızlı Ret Gerekçesi Seçin:
            </label>
            <div className="space-y-1.5">
              {PRESET_REASONS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setReason(preset)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition border cursor-pointer ${
                    reason === preset
                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  • {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Reason Textarea */}
          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1 flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5 text-rose-600" />
              <span>Veya Özel Ret / İade Nedeni Yazın:</span>
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ret nedeni, inceleme bulguları veya müşteri şikayeti..."
              className="w-full p-2.5 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white tabular-nums focus:ring-2 focus:ring-rose-500"
              required
            />
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700 transition cursor-pointer"
            >
              Vazgeç / İptal
            </button>

            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{selectedCount} Partiyi Reddet</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
