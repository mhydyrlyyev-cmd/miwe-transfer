import React, { useState, useEffect } from 'react';
import {
  StickyNote,
  X,
  Send,
  AlertCircle,
  Clock,
  User,
  Tag,
  CheckCircle2,
  Sparkles,
  ShieldAlert,
  Info,
  CornerDownRight,
  History
} from 'lucide-react';
import { ReferenceItem } from '../../types';

export interface QuickAdminNoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  reference: ReferenceItem | null;
  onSaveNote: (
    refId: string,
    noteText: string,
    options: {
      category?: string;
      priority?: 'NORMAL' | 'WARNING' | 'CRITICAL';
      operator?: string;
      append?: boolean;
    }
  ) => void;
  currentOperator?: string;
}

const PRESET_CATEGORIES = [
  { id: 'GENEL', label: '📋 Genel İdari Not', color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' },
  { id: 'KALITE', label: '🔍 Kalite & Analiz Onayı', color: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300' },
  { id: 'SOGUK_DEPO', label: '❄️ Soğuk Depo & MAP Kontrolü', color: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' },
  { id: 'LOJISTIK', label: '🚚 Sevk & Lojistik Talimatı', color: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300' },
  { id: 'KARANTINA', label: '⚠️ Karantina / Askıya Alma', color: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' },
  { id: 'MUSTERI', label: '🏷️ İhracat / Müşteri Şartı', color: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' },
  { id: 'FIRE', label: '⚖️ Kantar / Fire Açıklaması', color: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300' }
];

export const QuickAdminNoteModal: React.FC<QuickAdminNoteModalProps> = ({
  isOpen,
  onClose,
  reference,
  onSaveNote,
  currentOperator = 'Sistem Yöneticisi'
}) => {
  const [noteText, setNoteText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('GENEL');
  const [priority, setPriority] = useState<'NORMAL' | 'WARNING' | 'CRITICAL'>('NORMAL');
  const [operator, setOperator] = useState(currentOperator);
  const [appendMode, setAppendMode] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showHistory, setShowHistory] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setNoteText('');
      setOperator(currentOperator || 'Sistem Yöneticisi');
      setSelectedCategory('GENEL');
      setPriority('NORMAL');
      setAppendMode(true);
    }
  }, [isOpen, reference, currentOperator]);

  if (!isOpen || !reference) return null;

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!noteText.trim()) return;

    setIsSubmitting(true);
    try {
      const categoryObj = PRESET_CATEGORIES.find(c => c.id === selectedCategory);
      onSaveNote(reference.refId, noteText.trim(), {
        category: categoryObj ? categoryObj.label : selectedCategory,
        priority,
        operator: operator.trim() || currentOperator,
        append: appendMode
      });
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Ctrl+Enter or Cmd+Enter to submit
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  };

  const hasExistingNotes = Boolean(reference.notes && reference.notes.trim().length > 0);

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="quick-note-modal-title"
      >
        {/* Header with amber/teal badge */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-amber-500/10 via-teal-500/5 to-transparent flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-slate-950 flex items-center justify-center shadow-md font-bold">
              <StickyNote className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h2 id="quick-note-modal-title" className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <span>Hızlı Yönetici Notu Ekle</span>
                <span className="text-[10px] tabular-nums px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold border border-amber-300 dark:border-amber-800">
                  Quick Note
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Formu açmadan bu referans partisine anında idari not ve talimat kaydedin.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Kapat (ESC)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Reference Summary Strip */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="tabular-nums font-bold text-sm text-teal-700 dark:text-teal-400">
                  {reference.refId}
                </span>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {reference.product} {reference.variety || reference.sortVariety ? `(${reference.variety || reference.sortVariety})` : ''}
                </span>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                {reference.status}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-slate-600 dark:text-slate-400">
              <div>
                <span className="text-slate-400 dark:text-slate-500 block">Miktar:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">
                  {(reference.quantity ?? 0).toLocaleString('tr-TR')} {reference.unit || 'kg'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 dark:text-slate-500 block">Lokasyon / Bahçe:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100 truncate block">
                  {reference.orchard || reference.location || reference.source || '-'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 dark:text-slate-500 block">Tarih:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">
                  {reference.createdAt ? reference.createdAt.slice(0, 10) : '-'}
                </span>
              </div>
            </div>
          </div>

          {/* Existing Notes History (if any) */}
          {hasExistingNotes && (
            <div className="rounded-xl border border-amber-200/80 dark:border-amber-900/60 bg-amber-50/50 dark:bg-amber-950/20 overflow-hidden">
              <button
                type="button"
                onClick={() => setShowHistory(prev => !prev)}
                className="w-full px-3.5 py-2 flex items-center justify-between text-left text-xs font-bold text-amber-900 dark:text-amber-200 hover:bg-amber-100/50 transition cursor-pointer"
              >
                <div className="flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-amber-600" />
                  <span>Kayıttaki Mevcut Notlar / Geçmiş</span>
                </div>
                <span className="text-[10px] text-amber-700 dark:text-amber-400">
                  {showHistory ? 'Gizle ▲' : 'Göster ▼'}
                </span>
              </button>
              {showHistory && (
                <div className="p-3 pt-0 max-h-36 overflow-y-auto">
                  <div className="bg-white/80 dark:bg-slate-900/80 p-2.5 rounded-lg border border-amber-200 dark:border-amber-900/50 text-xs tabular-nums whitespace-pre-wrap text-slate-700 dark:text-slate-300 leading-relaxed selection:bg-amber-200">
                    {reference.notes}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Preset Category Pills */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              <span>Not Kategorisi / Şablonu:</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_CATEGORIES.map(cat => {
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`text-xs px-2.5 py-1 rounded-lg font-medium transition cursor-pointer border ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-600 font-bold shadow-xs scale-102'
                        : `${cat.color} border-transparent hover:border-slate-300 dark:hover:border-slate-700`
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Priority & Operator Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
                <span>Önem Derecesi:</span>
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => setPriority('NORMAL')}
                  className={`py-1.5 px-2 text-xs rounded-lg font-semibold transition cursor-pointer border text-center ${
                    priority === 'NORMAL'
                      ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-transparent hover:border-slate-300'
                  }`}
                >
                   Normal
                </button>
                <button
                  type="button"
                  onClick={() => setPriority('WARNING')}
                  className={`py-1.5 px-2 text-xs rounded-lg font-semibold transition cursor-pointer border text-center ${
                    priority === 'WARNING'
                      ? 'bg-amber-500 text-slate-950 border-amber-600 font-bold shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-transparent hover:border-slate-300'
                  }`}
                >
                   Dikkat
                </button>
                <button
                  type="button"
                  onClick={() => setPriority('CRITICAL')}
                  className={`py-1.5 px-2 text-xs rounded-lg font-semibold transition cursor-pointer border text-center ${
                    priority === 'CRITICAL'
                      ? 'bg-rose-600 text-white border-rose-700 font-bold shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-transparent hover:border-slate-300'
                  }`}
                >
                   Acil
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>Yönetici / Operatör:</span>
              </label>
              <input
                type="text"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                placeholder="Örn: Admin / Baş Denetmen"
                className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Note Textarea Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <StickyNote className="w-3.5 h-3.5 text-amber-600" />
                <span>İdari Not & Talimat:</span>
                <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-slate-400">
                {noteText.length} karakter • <kbd className="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded tabular-nums text-[9px]">Ctrl+Enter</kbd>
              </span>
            </div>
            <textarea
              autoFocus
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={4}
              placeholder="Partiyle ilgili idari karar, kalite notu, özel müşteri sevkiyat talimatı veya laboratuvar analiz sonucunu giriniz..."
              className="w-full px-3 py-2.5 text-sm bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition resize-y"
            />
          </div>

          {/* Append Mode Toggle (if existing notes) */}
          {hasExistingNotes && (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="appendModeCheckbox"
                checked={appendMode}
                onChange={(e) => setAppendMode(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500 cursor-pointer"
              />
              <label htmlFor="appendModeCheckbox" className="text-xs text-slate-600 dark:text-slate-400 cursor-pointer select-none">
                Mevcut notları koru ve altına zaman damgasıyla yeni not ekle (Önerilen)
              </label>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            <CornerDownRight className="w-3.5 h-3.5 text-slate-400" />
            <span>Form açılmadan anında kaydedilir</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition cursor-pointer"
            >
              Vazgeç
            </button>
            <button
              type="button"
              disabled={!noteText.trim() || isSubmitting}
              onClick={() => handleSubmit()}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Kaydediliyor...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Notu Kaydet</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
