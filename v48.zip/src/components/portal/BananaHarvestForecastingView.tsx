import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import {
  TrendingUp,
  BarChart3,
  Calendar,
  Scale,
  CheckCircle2,
  AlertTriangle,
  Filter
} from 'lucide-react';
import { MUZ_TOPLAM_EXACT_ROWS } from '../../data/bananaRibbonData';
import {
  BANANA_GREENHOUSES_2027,
  BANANA_12_MONTH_COLORS_2027,
  normalizeBananaGreenhouseName
} from '../../data/banana2027Data';
import {
  resolveToplamPeriodNetDates,
  getRibbonColorMeta
} from '../../data/bananaToplamCalendarAdapter';
import { DELILNAMA_2026_BY_TOPLAM_PERIOD_ID } from '../../data/delilnamaBanan2026Data';
import type { BananaContinuityRow } from './BananaRibbonCalendarHub';

export interface BananaHarvestForecastingViewProps {
  calendarRows: BananaContinuityRow[];
  selectedGreenhouse?: string;
  onSelectGreenhouse?: (gh: string) => void;
  onUpdateRowCell?: (rowId: string, field: keyof BananaContinuityRow, value: any) => void;
}

type ForecastChartGrouping = 'COLOR_SEGMENTS' | 'TOPLAM_PERIODS' | 'GREENHOUSE_SUMMARY';

interface ForecastSegmentItem {
  key: string;
  segmentLabel: string;
  shortLabel: string;
  ribbonColorName: string;
  ribbonHex: string;
  isOctNovSegment: boolean;
  seasonBadge: string;
  boundBunches: number;
  expectedKg: number;
  realizedKg: number;
  expectedTon: number;
  realizedTon: number;
  varianceKg: number;
  realizationPct: number;
  periodCount: number;
  dateRangeText: string;
}

export const BananaHarvestForecastingView: React.FC<BananaHarvestForecastingViewProps> = ({
  calendarRows,
  selectedGreenhouse = 'ALL',
  onSelectGreenhouse
}) => {
  const [chartGrouping, setChartGrouping] = useState<ForecastChartGrouping>('COLOR_SEGMENTS');
  const [unitMode, setUnitMode] = useState<'TON' | 'KG'>('TON');
  const [octNovFilter, setOctNovFilter] = useState<'ALL' | 'OCT_NOV_ONLY' | '2026_REALIZED'>('ALL');
  const [localGhFilter, setLocalGhFilter] = useState<string>(selectedGreenhouse || 'ALL');
  const [octNovColorOverrides, setOctNovColorOverrides] = useState<Record<string, string>>({});

  const effectiveGhFilter =
    selectedGreenhouse && selectedGreenhouse !== 'ALL' ? selectedGreenhouse : localGhFilter;

  const handleGhChange = (gh: string) => {
    setLocalGhFilter(gh);
    if (onSelectGreenhouse) {
      onSelectGreenhouse(gh);
    }
  };

  // Build unified dataset from Google Sheets "Toplam" structure + calendarRows + Delilnama 2026 realized kg
  const unifiedToplamForecastRows = useMemo(() => {
    const ghDefs: Array<{
      key: 'gb56' | 'gb78' | 'maksat910' | 'miweli34' | 'miweli12' | 'hem1112' | 'hem5';
      canonicalName: string;
    }> = [
      { key: 'gb56', canonicalName: 'GB-5-6' },
      { key: 'gb78', canonicalName: 'GB-7-8' },
      { key: 'maksat910', canonicalName: 'Maksat 9-10' },
      { key: 'miweli34', canonicalName: 'Miweli 3-4' },
      { key: 'miweli12', canonicalName: 'Miweli 1-2' },
      { key: 'hem1112', canonicalName: 'Hem-11-12' },
      { key: 'hem5', canonicalName: 'Hem-5' }
    ];

    const expanded: Array<{
      id: string;
      periodId: string;
      canonicalGh: string;
      hasatDonemi: string;
      ribbonColor: string;
      ribbonHex: string;
      taggingDate: string;
      expectedHarvestDate: string;
      boundBunches: number;
      expectedKg: number;
      realizedKg: number;
      expectedTon: number;
      realizedTon: number;
      varianceKg: number;
      realizationPct: number;
      isOctNovSegment: boolean;
      statusNot: string;
    }> = [];

    MUZ_TOPLAM_EXACT_ROWS.filter(r => r.rowType === 'PERIOD' && (r.toplam || 0) > 0).forEach(pRow => {
      const dates = resolveToplamPeriodNetDates(pRow.month, pRow.sene, pRow.rawTahmHasat);
      const delilnamaMatch = DELILNAMA_2026_BY_TOPLAM_PERIOD_ID[pRow.id];
      const periodTotalBound = Math.max(1, Number(pRow.toplam || 0));
      const periodActualKg = Math.max(0, Number(pRow.gercekKilo || 0));

      const rawColor = octNovColorOverrides[pRow.id] || pRow.rawColor || 'Mavi';
      const colorMeta = getRibbonColorMeta(rawColor);

      const harvestMonth = dates.expectedHarvestIso
        ? Number(dates.expectedHarvestIso.slice(5, 7))
        : 0;
      const tagMonth = dates.taggingStartIso ? Number(dates.taggingStartIso.slice(5, 7)) : 0;
      const lowerDonem = `${pRow.month || ''} ${pRow.sene || ''}`.toLowerCase();
      const lowerColor = rawColor.toLowerCase();

      const isOctNovSegment =
        harvestMonth === 10 ||
        harvestMonth === 11 ||
        tagMonth === 10 ||
        tagMonth === 11 ||
        lowerDonem.includes('ekim') ||
        lowerDonem.includes('kasım') ||
        lowerDonem.includes('kasim') ||
        lowerDonem.includes('okt') ||
        lowerDonem.includes('noy') ||
        lowerColor.includes('ekim') ||
        lowerColor.includes('kasım') ||
        Boolean(octNovColorOverrides[pRow.id]);

      ghDefs.forEach(gh => {
        const boundInGh = Number(pRow[gh.key] || 0);
        if (boundInGh <= 0) return;

        const share = boundInGh / periodTotalBound;
        const rowId = `TOPLAM-${pRow.id}-${gh.key.toUpperCase()}`;
        const matchingCalRow = calendarRows.find(cr => cr.id === rowId);
        const rowOverrideColor = octNovColorOverrides[rowId] || octNovColorOverrides[pRow.id];
        const rowColorMeta = rowOverrideColor ? getRibbonColorMeta(rowOverrideColor) : colorMeta;

        const expectedKg =
          matchingCalRow?.plannedTonnageKg !== undefined && matchingCalRow.plannedTonnageKg > 0
            ? matchingCalRow.plannedTonnageKg
            : Math.round(boundInGh * 32);

        const delilnamaGhKg = delilnamaMatch ? Number(delilnamaMatch.byGhKg[gh.key] || 0) : 0;
        const realizedKg =
          matchingCalRow?.harvestedNetKg !== undefined && matchingCalRow.harvestedNetKg > 0
            ? matchingCalRow.harvestedNetKg
            : periodActualKg > 0
              ? Math.round(periodActualKg * share)
              : delilnamaGhKg > 0
                ? Math.round(delilnamaGhKg)
                : 0;

        const realizationPct =
          expectedKg > 0 ? Math.round((realizedKg / expectedKg) * 100) : 0;

        expanded.push({
          id: rowId,
          periodId: pRow.id,
          canonicalGh: gh.canonicalName,
          hasatDonemi: `${pRow.month} ${pRow.sene}`.trim(),
          ribbonColor: rowOverrideColor ? rowColorMeta.fullLabel : (matchingCalRow?.ribbonColor || colorMeta.fullLabel),
          ribbonHex: rowOverrideColor ? rowColorMeta.hex : (matchingCalRow?.ribbonHex || colorMeta.hex),
          taggingDate: matchingCalRow?.taggingDate || dates.taggingStartIso,
          expectedHarvestDate: matchingCalRow?.expectedHarvestDate || dates.expectedHarvestIso,
          boundBunches: matchingCalRow?.boundBunchCount ?? boundInGh,
          expectedKg,
          realizedKg,
          expectedTon: Number((expectedKg / 1000).toFixed(2)),
          realizedTon: Number((realizedKg / 1000).toFixed(2)),
          varianceKg: realizedKg - expectedKg,
          realizationPct,
          isOctNovSegment: isOctNovSegment || Boolean(rowOverrideColor),
          statusNot: realizedKg > 0 ? '2026 Hasat Edildi' : 'Hasat Bekleniyor'
        });
      });
    });

    return expanded;
  }, [calendarRows, octNovColorOverrides]);

  // Apply greenhouse and Oct-Nov filters
  const filteredForecastRows = useMemo(() => {
    return unifiedToplamForecastRows.filter(r => {
      if (effectiveGhFilter !== 'ALL' && r.canonicalGh !== effectiveGhFilter) return false;
      if (octNovFilter === 'OCT_NOV_ONLY' && !r.isOctNovSegment) return false;
      if (octNovFilter === '2026_REALIZED' && r.realizedKg <= 0) return false;
      return true;
    });
  }, [unifiedToplamForecastRows, effectiveGhFilter, octNovFilter]);

  // Build Recharts comparative bar chart data according to selected grouping
  const chartSegments = useMemo<ForecastSegmentItem[]>(() => {
    if (chartGrouping === 'COLOR_SEGMENTS') {
      const byColor = new Map<
        string,
        {
          ribbonColorName: string;
          ribbonHex: string;
          isOctNovSegment: boolean;
          boundBunches: number;
          expectedKg: number;
          realizedKg: number;
          periodCount: number;
          minDate: string;
          maxDate: string;
        }
      >();

      filteredForecastRows.forEach(r => {
        const key = r.ribbonColor || 'Standart';
        const existing = byColor.get(key);
        if (!existing) {
          byColor.set(key, {
            ribbonColorName: key,
            ribbonHex: r.ribbonHex,
            isOctNovSegment: r.isOctNovSegment,
            boundBunches: r.boundBunches,
            expectedKg: r.expectedKg,
            realizedKg: r.realizedKg,
            periodCount: 1,
            minDate: r.taggingDate,
            maxDate: r.expectedHarvestDate
          });
        } else {
          existing.boundBunches += r.boundBunches;
          existing.expectedKg += r.expectedKg;
          existing.realizedKg += r.realizedKg;
          existing.periodCount += 1;
          existing.isOctNovSegment = existing.isOctNovSegment || r.isOctNovSegment;
          if (r.taggingDate < existing.minDate) existing.minDate = r.taggingDate;
          if (r.expectedHarvestDate > existing.maxDate) existing.maxDate = r.expectedHarvestDate;
        }
      });

      // Also include explicit Oct-Nov color indicator segments from calendarRows if present
      calendarRows
        .filter(cr => cr.cycleYear === '2027' || cr.taggingDate.includes('-10-') || cr.taggingDate.includes('-11-'))
        .forEach(cr => {
          if (effectiveGhFilter !== 'ALL' && normalizeBananaGreenhouseName(cr.greenhouseName) !== effectiveGhFilter) {
            return;
          }
          const isOctNov =
            cr.ribbonColor.includes('Ekim') ||
            cr.ribbonColor.includes('Kasım') ||
            cr.taggingDate.includes('-10-') ||
            cr.taggingDate.includes('-11-') ||
            cr.expectedHarvestDate.includes('-10-') ||
            cr.expectedHarvestDate.includes('-11-');
          if (octNovFilter === 'OCT_NOV_ONLY' && !isOctNov) return;
          if (octNovFilter === '2026_REALIZED' && cr.harvestedNetKg <= 0) return;

          const key = isOctNov ? `🍂 ${cr.ribbonColor}` : cr.ribbonColor;
          const existing = byColor.get(key);
          if (!existing) {
            byColor.set(key, {
              ribbonColorName: key,
              ribbonHex: cr.ribbonHex,
              isOctNovSegment: isOctNov,
              boundBunches: cr.boundBunchCount,
              expectedKg: cr.plannedTonnageKg,
              realizedKg: cr.harvestedNetKg,
              periodCount: 1,
              minDate: cr.taggingDate,
              maxDate: cr.expectedHarvestDate
            });
          } else {
            existing.boundBunches += cr.boundBunchCount;
            existing.expectedKg += cr.plannedTonnageKg;
            existing.realizedKg += cr.harvestedNetKg;
            existing.periodCount += 1;
          }
        });

      return Array.from(byColor.entries()).map(([key, item]) => {
        const realizationPct =
          item.expectedKg > 0 ? Math.round((item.realizedKg / item.expectedKg) * 100) : 0;
        return {
          key,
          segmentLabel: item.isOctNovSegment
            ? `${item.ribbonColorName} (Ekim-Kasım Segmenti)`
            : item.ribbonColorName,
          shortLabel: item.ribbonColorName.replace('Kurdele', '').trim(),
          ribbonColorName: item.ribbonColorName,
          ribbonHex: item.ribbonHex,
          isOctNovSegment: item.isOctNovSegment,
          seasonBadge: item.isOctNovSegment ? 'Ekim–Kasım Renk Göstergesi' : '2026 Aktif Kurdele',
          boundBunches: item.boundBunches,
          expectedKg: item.expectedKg,
          realizedKg: item.realizedKg,
          expectedTon: Number((item.expectedKg / 1000).toFixed(1)),
          realizedTon: Number((item.realizedKg / 1000).toFixed(1)),
          varianceKg: item.realizedKg - item.expectedKg,
          realizationPct,
          periodCount: item.periodCount,
          dateRangeText: `${item.minDate} → ${item.maxDate}`
        };
      });
    }

    if (chartGrouping === 'TOPLAM_PERIODS') {
      const byPeriod = new Map<
        string,
        {
          hasatDonemi: string;
          ribbonColor: string;
          ribbonHex: string;
          isOctNovSegment: boolean;
          boundBunches: number;
          expectedKg: number;
          realizedKg: number;
          ghCount: number;
          taggingDate: string;
          expectedHarvestDate: string;
        }
      >();

      filteredForecastRows.forEach(r => {
        if (r.expectedKg <= 0 && r.realizedKg <= 0) return;
        const existing = byPeriod.get(r.periodId);
        if (!existing) {
          byPeriod.set(r.periodId, {
            hasatDonemi: r.hasatDonemi,
            ribbonColor: r.ribbonColor,
            ribbonHex: r.ribbonHex,
            isOctNovSegment: r.isOctNovSegment,
            boundBunches: r.boundBunches,
            expectedKg: r.expectedKg,
            realizedKg: r.realizedKg,
            ghCount: 1,
            taggingDate: r.taggingDate,
            expectedHarvestDate: r.expectedHarvestDate
          });
        } else {
          existing.boundBunches += r.boundBunches;
          existing.expectedKg += r.expectedKg;
          existing.realizedKg += r.realizedKg;
          existing.ghCount += 1;
          existing.isOctNovSegment = existing.isOctNovSegment || r.isOctNovSegment;
        }
      });

      return Array.from(byPeriod.entries()).map(([pId, p]) => {
        const realizationPct =
          p.expectedKg > 0 ? Math.round((p.realizedKg / p.expectedKg) * 100) : 0;
        return {
          key: pId,
          segmentLabel: `${p.hasatDonemi} — ${p.ribbonColor}`,
          shortLabel: `${p.hasatDonemi} (${p.ribbonColor.split(' ')[0]})`,
          ribbonColorName: p.ribbonColor,
          ribbonHex: p.ribbonHex,
          isOctNovSegment: p.isOctNovSegment,
          seasonBadge: p.isOctNovSegment ? 'Ekim–Kasım Dönemi' : `${p.ghCount} Sera`,
          boundBunches: p.boundBunches,
          expectedKg: p.expectedKg,
          realizedKg: p.realizedKg,
          expectedTon: Number((p.expectedKg / 1000).toFixed(1)),
          realizedTon: Number((p.realizedKg / 1000).toFixed(1)),
          varianceKg: p.realizedKg - p.expectedKg,
          realizationPct,
          periodCount: p.ghCount,
          dateRangeText: `${p.taggingDate} → ${p.expectedHarvestDate}`
        };
      });
    }

    // GREENHOUSE_SUMMARY
    return BANANA_GREENHOUSES_2027.map(gh => {
      const ghRows = filteredForecastRows.filter(r => r.canonicalGh === gh.name);
      const boundBunches = ghRows.reduce((s, r) => s + r.boundBunches, 0);
      const expectedKg = ghRows.reduce((s, r) => s + r.expectedKg, 0);
      const realizedKg = ghRows.reduce((s, r) => s + r.realizedKg, 0);
      const dominantRow = ghRows.find(r => r.expectedKg > 0) || ghRows[0];
      const realizationPct =
        expectedKg > 0 ? Math.round((realizedKg / expectedKg) * 100) : 0;

      return {
        key: gh.name,
        segmentLabel: `${gh.name} (${gh.sheetTab || gh.shortCode})`,
        shortLabel: gh.name,
        ribbonColorName: dominantRow?.ribbonColor || 'Çoklu Kurdele',
        ribbonHex: dominantRow?.ribbonHex || '#10b981',
        isOctNovSegment: ghRows.some(r => r.isOctNovSegment),
        seasonBadge: `${ghRows.length} Dönem`,
        boundBunches,
        expectedKg,
        realizedKg,
        expectedTon: Number((expectedKg / 1000).toFixed(1)),
        realizedTon: Number((realizedKg / 1000).toFixed(1)),
        varianceKg: realizedKg - expectedKg,
        realizationPct,
        periodCount: ghRows.length,
        dateRangeText: '2026 → 2027 Toplam'
      };
    }).filter(item => effectiveGhFilter === 'ALL' || item.key === effectiveGhFilter);
  }, [chartGrouping, filteredForecastRows, calendarRows, effectiveGhFilter, octNovFilter]);

  // Summary Totals
  const totals = useMemo(() => {
    const totalExpectedKg = filteredForecastRows.reduce((s, r) => s + r.expectedKg, 0);
    const totalRealizedKg = filteredForecastRows.reduce((s, r) => s + r.realizedKg, 0);
    const totalBoundBunches = filteredForecastRows.reduce((s, r) => s + r.boundBunches, 0);
    const octNovExpectedKg = filteredForecastRows
      .filter(r => r.isOctNovSegment)
      .reduce((s, r) => s + r.expectedKg, 0);
    const octNovRealizedKg = filteredForecastRows
      .filter(r => r.isOctNovSegment)
      .reduce((s, r) => s + r.realizedKg, 0);
    const realizationPct =
      totalExpectedKg > 0 ? Number(((totalRealizedKg / totalExpectedKg) * 100).toFixed(1)) : 0;

    return {
      totalExpectedKg,
      totalRealizedKg,
      totalExpectedTon: Number((totalExpectedKg / 1000).toFixed(1)),
      totalRealizedTon: Number((totalRealizedKg / 1000).toFixed(1)),
      varianceKg: totalRealizedKg - totalExpectedKg,
      varianceTon: Number(((totalRealizedKg - totalExpectedKg) / 1000).toFixed(1)),
      totalBoundBunches,
      octNovExpectedTon: Number((octNovExpectedKg / 1000).toFixed(1)),
      octNovRealizedTon: Number((octNovRealizedKg / 1000).toFixed(1)),
      realizationPct
    };
  }, [filteredForecastRows]);

  const expectedDataKey = unitMode === 'TON' ? 'expectedTon' : 'expectedKg';
  const realizedDataKey = unitMode === 'TON' ? 'realizedTon' : 'realizedKg';
  const unitSuffix = unitMode === 'TON' ? ' Ton' : ' kg';

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
      {/* HEADER & SEGMENT CONTROLS */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-semibold">
              <span>Harvest Forecasting</span>
              <span aria-hidden="true">·</span>
              <span>Google Sheets "Toplam" Yapısı</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-bold">
                Ekim–Kasım (Oct–Nov) Renk Segment Göstergeli
              </span>
            </div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 mt-0.5">
              Hasat Tahmini & Beklenen vs. Gerçekleşen Hasat Analizi (Expected vs. Realized)
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Google Sheets "Toplam" sayfasındaki kurdele renk segmentlerine göre Beklenen Hasat (Expected) ile 2026 Delilnama Gerçekleşen Hasat (Realized) karşılaştırması
            </p>
          </div>
        </div>

        {/* INTERACTIVE SEGMENTATION & UNIT CONTROLS */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Grouping Mode Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setChartGrouping('COLOR_SEGMENTS')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                chartGrouping === 'COLOR_SEGMENTS'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
               Renk Segmentleri (Oct–Nov)
            </button>
            <button
              type="button"
              onClick={() => setChartGrouping('TOPLAM_PERIODS')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                chartGrouping === 'TOPLAM_PERIODS'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
               "Toplam" Dönemleri
            </button>
            <button
              type="button"
              onClick={() => setChartGrouping('GREENHOUSE_SUMMARY')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                chartGrouping === 'GREENHOUSE_SUMMARY'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
               7 Sera Karşılaştırması
            </button>
          </div>

          {/* Greenhouse Filter */}
          <select
            value={effectiveGhFilter}
            onChange={e => handleGhChange(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
          >
            <option value="ALL">Tüm Seralar (7 Sera)</option>
            {BANANA_GREENHOUSES_2027.map(gh => (
              <option key={gh.name} value={gh.name}>
                {gh.name} ({gh.sheetTab || gh.shortCode})
              </option>
            ))}
          </select>

          {/* Oct-Nov / Realized Filter */}
          <select
            value={octNovFilter}
            onChange={e => setOctNovFilter(e.target.value as any)}
            className="bg-amber-50 border border-amber-300 rounded-xl px-3 py-1.5 text-xs font-bold text-amber-950 cursor-pointer"
          >
            <option value="ALL">Tüm Dönemler (2026 + Ekim/Kasım)</option>
            <option value="OCT_NOV_ONLY"> Sadece Ekim–Kasım (Oct–Nov) Segmentleri</option>
            <option value="2026_REALIZED"> Sadece Gerçekleşen Hasatlar</option>
          </select>

          {/* Unit Toggle (Ton / Kg) */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setUnitMode('TON')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                unitMode === 'TON' ? 'bg-emerald-600 text-white' : 'text-slate-600'
              }`}
            >
              Ton
            </button>
            <button
              type="button"
              onClick={() => setUnitMode('KG')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                unitMode === 'KG' ? 'bg-emerald-600 text-white' : 'text-slate-600'
              }`}
            >
              Kg
            </button>
          </div>
        </div>
      </div>

      {/* KPI SUMMARY STRIP */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200">
          <div className="text-[11px] font-semibold text-amber-900">
            Beklenen Hasat (Expected — G.Sheet Toplam)
          </div>
          <div className="text-lg font-bold tabular-nums text-amber-950 mt-0.5">
            {unitMode === 'TON'
              ? `${totals.totalExpectedTon.toLocaleString('tr-TR')} Ton`
              : `${totals.totalExpectedKg.toLocaleString('tr-TR')} kg`}
          </div>
          <div className="text-[10px] text-amber-800 mt-0.5">
            Bağlanan: {totals.totalBoundBunches.toLocaleString('tr-TR')} ağaç/hevenk
          </div>
        </div>

        <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
          <div className="text-[11px] font-semibold text-emerald-900">
            Gerçekleşen Hasat (Realized — 2026 Kantar)
          </div>
          <div className="text-lg font-bold tabular-nums text-emerald-950 mt-0.5">
            {unitMode === 'TON'
              ? `${totals.totalRealizedTon.toLocaleString('tr-TR')} Ton`
              : `${totals.totalRealizedKg.toLocaleString('tr-TR')} kg`}
          </div>
          <div className="text-[10px] text-emerald-800 mt-0.5">
            Delilnama Banan 2 + Canlı Hasat
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
          <div className="text-[11px] font-semibold text-slate-700">
            Gerçekleşme Oranı (Realization %)
          </div>
          <div className="text-lg font-bold tabular-nums text-slate-900 mt-0.5">
            %{totals.realizationPct}
          </div>
          <div className="text-[10px] text-slate-600 mt-0.5">
            Fark:{' '}
            <strong className={totals.varianceKg >= 0 ? 'text-emerald-700' : 'text-amber-700'}>
              {totals.varianceTon >= 0 ? `+${totals.varianceTon}` : totals.varianceTon} Ton
            </strong>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-orange-50/70 border border-orange-200">
          <div className="text-[11px] font-semibold text-orange-900">
            Ekim–Kasım (Oct–Nov) Beklenen Segment
          </div>
          <div className="text-lg font-bold tabular-nums text-orange-950 mt-0.5">
            {totals.octNovExpectedTon.toLocaleString('tr-TR')} Ton
          </div>
          <div className="text-[10px] text-orange-800 mt-0.5">
            Gerçekleşen: {totals.octNovRealizedTon.toLocaleString('tr-TR')} Ton
          </div>
        </div>

        <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200">
          <div className="text-[11px] font-semibold text-sky-900">
            Aktif Renk / Dönem Segment Sayısı
          </div>
          <div className="text-lg font-bold tabular-nums text-sky-950 mt-0.5">
            {chartSegments.length} Segment
          </div>
          <div className="text-[10px] text-sky-800 mt-0.5">
            Renk kodlu hasat karşılaştırması
          </div>
        </div>
      </div>

      {/* RECHARTS COMPARATIVE BAR CHART: EXPECTED VS. REALIZED HARVEST AMOUNTS */}
      <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-700" />
            <span className="text-xs sm:text-sm font-bold text-slate-900">
              Beklenen Hasat (Expected) vs. Gerçekleşen Hasat (Realized) — Renk Kodlu Karşılaştırma Grafiği
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-600">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-amber-400 inline-block border border-amber-600" />
              <span>Çubuk Sol: Beklenen Hasat (Renk Kodlu Kurdele Segmenti)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-emerald-600 inline-block" />
              <span>Çubuk Sağ: Gerçekleşen Hasat (2026 Kantar)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-sky-600 inline-block" />
              <span>Çizgi: Gerçekleşme Oranı (%)</span>
            </span>
          </div>
        </div>

        <div className="w-full h-80 min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartSegments}
              margin={{ top: 12, right: 20, left: 4, bottom: 28 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="shortLabel"
                tick={{ fill: '#1e293b', fontSize: 11, fontWeight: 700 }}
                interval={0}
                angle={-18}
                textAnchor="end"
                height={54}
              />
              <YAxis
                yAxisId="left"
                tick={{ fill: '#475569', fontSize: 11 }}
                unit={unitSuffix}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tick={{ fill: '#0284c7', fontSize: 11 }}
                unit="%"
                domain={[0, 140]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#cbd5e1',
                  borderRadius: '12px',
                  fontSize: '12px',
                  color: '#0f172a'
                }}
                formatter={(value: any, name: string) => {
                  if (name.includes('%')) return [`%${value}`, name];
                  return [
                    `${Number(value).toLocaleString('tr-TR')}${unitSuffix}`,
                    name
                  ];
                }}
                labelFormatter={(label, payload) => {
                  const row = payload?.[0]?.payload as ForecastSegmentItem | undefined;
                  if (!row) return label;
                  return `${row.segmentLabel} · ${row.seasonBadge} (${row.dateRangeText})`;
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
              <ReferenceLine yAxisId="right" y={100} stroke="#94a3b8" strokeDasharray="4 4" />
              <Bar
                yAxisId="left"
                dataKey={expectedDataKey}
                name={`Beklenen Hasat — Expected (${unitMode === 'TON' ? 'Ton' : 'Kg'})`}
                fill="#f59e0b"
                radius={[6, 6, 0, 0]}
              >
                {chartSegments.map((entry, idx) => (
                  <Cell
                    key={`exp-cell-${idx}`}
                    fill={entry.ribbonHex || '#f59e0b'}
                    fillOpacity={0.82}
                    stroke={entry.isOctNovSegment ? '#ea580c' : '#475569'}
                    strokeWidth={entry.isOctNovSegment ? 2 : 1}
                  />
                ))}
              </Bar>
              <Bar
                yAxisId="left"
                dataKey={realizedDataKey}
                name={`Gerçekleşen Hasat — Realized (${unitMode === 'TON' ? 'Ton' : 'Kg'})`}
                fill="#10b981"
                radius={[6, 6, 0, 0]}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="realizationPct"
                name="Gerçekleşme Oranı (%)"
                stroke="#0284c7"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#0284c7' }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* COLOR-CODED HARVEST SEGMENTS & OCT-NOV INDICATOR CARDS */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-amber-600" />
            <h4 className="text-xs font-bold text-slate-800">
              Renk Kodlu Hasat Segmentleri & Ekim–Kasım (Oct–Nov) Renk Göstergeleri
            </h4>
          </div>
          <span className="text-[11px] text-slate-500">
            Ekim ve Kasım dönemlerindeki hasatlara kurdele rengi atayarak beklenen vs. gerçekleşen segment analizini güncelleyebilirsiniz
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {chartSegments.slice(0, 8).map(seg => {
            const isMet = seg.realizedKg >= seg.expectedKg && seg.expectedKg > 0;
            return (
              <div
                key={seg.key}
                className={`p-3 rounded-xl border transition flex flex-col justify-between ${
                  seg.isOctNovSegment
                    ? 'bg-orange-50/50 border-orange-300'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-slate-400 shrink-0"
                        style={{ backgroundColor: seg.ribbonHex }}
                      />
                      <span className="text-xs font-bold text-slate-900 truncate">
                        {seg.shortLabel}
                      </span>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-500 shrink-0">
                      {seg.isOctNovSegment ? '🍂 Oct–Nov' : `${seg.periodCount} dönem`}
                    </span>
                  </div>

                  <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] tabular-nums">
                    <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-200/80">
                      <div className="text-[9px] text-slate-500 font-sans">Beklenen (Expected)</div>
                      <div className="font-bold text-amber-900">
                        {seg.expectedTon.toLocaleString('tr-TR')} T
                      </div>
                    </div>
                    <div className="p-1.5 rounded-lg bg-emerald-50/60 border border-emerald-200/80">
                      <div className="text-[9px] text-emerald-800 font-sans">Gerçekleşen (Realized)</div>
                      <div className="font-bold text-emerald-800">
                        {seg.realizedTon.toLocaleString('tr-TR')} T
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center justify-between text-[10px]">
                  <span className="text-slate-600 tabular-nums">
                    Bağ: {seg.boundBunches.toLocaleString('tr-TR')} dal
                  </span>
                  <span
                    className={`font-bold flex items-center gap-1 ${
                      isMet
                        ? 'text-emerald-700'
                        : seg.realizedKg > 0
                          ? 'text-amber-700'
                          : 'text-slate-500'
                    }`}
                  >
                    {isMet ? (
                      <CheckCircle2 className="w-3 h-3" />
                    ) : (
                      <AlertTriangle className="w-3 h-3" />
                    )}
                    <span>%{seg.realizationPct} Gerçekleşme</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* OCT-NOV (EKİM-KASIM) COLOR INDICATOR QUICK ASSIGNER FOR UPCOMING PERIODS */}
      <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3 flex flex-col lg:flex-row lg:items-center justify-between gap-2.5 text-xs">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-amber-700 shrink-0" />
          <span className="font-bold text-slate-800">
            Ekim–Kasım (Oct–Nov) Dönemi Renk Göstergesi Simülasyonu:
          </span>
          <span className="text-slate-600 text-[11px]">
            Sonbahar hasat dönemlerine renk atayarak grafikteki segment dağılımını anlık test edin
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {unifiedToplamForecastRows
            .filter(r => r.isOctNovSegment || r.realizedKg === 0)
            .slice(0, 3)
            .map(row => (
              <div
                key={row.id}
                className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-amber-300"
              >
                <span className="text-[11px] font-bold text-slate-800">
                  {row.canonicalGh} ({row.hasatDonemi}):
                </span>
                <select
                  value={octNovColorOverrides[row.id] || row.ribbonColor}
                  onChange={e =>
                    setOctNovColorOverrides(prev => ({
                      ...prev,
                      [row.id]: e.target.value
                    }))
                  }
                  className="bg-amber-50 border border-amber-300 rounded px-1.5 py-0.5 text-[11px] font-bold text-amber-950 cursor-pointer"
                >
                  <option value={row.ribbonColor}>{row.ribbonColor}</option>
                  {BANANA_12_MONTH_COLORS_2027.map(c => (
                    <option key={c.monthIndex} value={c.ribbonName}>
                      {c.monthNameTr} — {c.ribbonName}
                    </option>
                  ))}
                </select>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};
