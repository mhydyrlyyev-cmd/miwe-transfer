import React, { useState, useMemo, useEffect } from 'react';
import {
  MuzRecord,
  HarvestRecord
} from '../../types';
import {
  BANANA_GREENHOUSES_2027,
  BANANA_12_MONTH_COLORS_2027 as BANANA_12_MONTH_RIBBONS,
  DEFAULT_BANANA_2027_RECORDS,
  Banana2027RibbonEntry,
  normalizeBananaGreenhouseName
} from '../../data/banana2027Data';

const BANANA_GREENHOUSE_LIST = BANANA_GREENHOUSES_2027.map(g => g.name);
import {
  DEFAULT_BANANA_SECTOR_RECORDS,
  BananaSectorRibbonRecord,
  syncBananaRibbonWithSheets
} from '../../data/bananaRibbonData';
import {
  buildChronologicalRowsFromMuzToplam,
  syncActualKgFromTextLinkOrSheet,
  getRibbonColorMeta
} from '../../data/bananaToplamCalendarAdapter';
import { BananaToplamSectorAndQualityViews } from './BananaToplamSectorAndQualityViews';
import { BananaHarvestForecastingView } from './BananaHarvestForecastingView';
import {
  Calendar,
  RefreshCw,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Scale,
  TrendingUp,
  Search,
  Filter,
  Trash2,
  Download,
  Bell,
  X,
  Globe,
  Store,
  UserCheck,
  Clock,
  Package,
  BarChart3,
  Edit3,
  FileSpreadsheet,
  Layers,
  ShieldCheck,
  Link2
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { useToast } from '../../context/ToastContext';
import { WorldStandardHarvestAnalyticsPanel } from './WorldStandardHarvestAnalyticsPanel';

const BANANA_HUB_STORAGE_KEY = 'OBA_BANANA_CONTINUITY_CALENDAR_V6';

export type BananaTargetMarket = 'EXPORT_PAZAR' | 'YEREL_PAZAR' | 'KARMA_PAZAR';
export type BananaHumanErrorType =
  | 'Hatasız / Zamanında'
  | 'Geç Kurdele Bağlama (İnsan Hatası)'
  | 'Erken Kurdele Bağlama'
  | 'Yanlış Renk Kurdele'
  | 'Geç Kesim / Kalibre Aşımı';

export interface BananaContinuityRow {
  id: string;
  cycleYear: '2026→2027 Devamlı' | '2026' | '2027';
  greenhouseName: string;
  sectorCode: string;
  variety: string;
  ribbonColor: string;
  ribbonHex: string;
  taggingDate: string; // Bağlama / Doğum Tarihi
  expectedTestDate: string; // Hasattan 12 gün önce kalibre test tarihi
  expectedHarvestDate: string; // Tahmini Hasat Tarihi (11-14 hafta)
  actualHarvestDate?: string; // Fiili Kesim Tarihi (Erken/Geç analiz için)
  boundBunchCount: number; // Bağlanan Kurdele / Hevenk Adedi
  standardBranchKg: number; // Planlanan Standart Dal Ağırlığı (kg/dal)
  plannedTonnageKg: number; // Bağlanan Dal × Standart Kg
  harvestedBunchCount: number; // Günlük Hasattan Kesilen Dal Sayısı
  harvestedNetKg: number; // Günlük Hasattan Gelen Net Kantar Kg
  harvestedCullKg: number; // Çıkma / İskarta Kg
  actualAvgBranchKg: number; // Fiili Dal Ortalaması (Kg/Dal)
  remainingBunchCount: number; // Serada Kalan Kesilecek Dal Sayısı
  fingerCaliberMm: number; // Parmak Kalibre (mm)
  fingerLengthCm: number; // Parmak Boyu (cm)
  targetMarket: BananaTargetMarket; // Yerel Pazar vs İhracat (Export) Pazarı
  crateType: string; // Kasa / Kutu Tipi (Toplu değiştirilebilir)
  manualHumanDelayDays: number; // Geç veya erken kurdele bağlama insan hatası günü (+ / - gün)
  humanErrorType: BananaHumanErrorType;
  status:
    | 'Kurdele Bağlandı'
    | '11. Hafta — Hasat Dönemine Girdi'
    | 'Kalibre Testinde (10-15 Gün)'
    | 'Hasat-1 (İlk Kesim)'
    | 'Hasat-2 (İkinci Kesim)'
    | 'Tamamlandı'
    | 'Hasat Yok';
  sourceType: 'KURDELE_MODULU' | 'GUNLUK_HASAT' | 'PLAN_2026_2027';
  foreman: string;
  notes: string;
}

interface BananaRibbonCalendarHubProps {
  muzRecords?: MuzRecord[];
  dailyHarvestRecords?: HarvestRecord[];
}

export const BANANA_CRATE_OPTIONS = [
  '18 kg Export Teleskopik Karton (MAP Poşetli)',
  '13 kg Yerel Pazar Plastik Kasa',
  '15 kg Zincir Market Plastik Kasa',
  '20 kg Endüstriyel / Püre Kasası'
];

function getRibbonHex(colorName: string): string {
  const c = (colorName || '').toLowerCase();
  if (c.includes('mavi') || c.includes('gök')) return '#2563eb';
  if (c.includes('kırmızı') || c.includes('gyzyl')) return '#dc2626';
  if (c.includes('sarı') || c.includes('sary')) return '#eab308';
  if (c.includes('yeşil') || c.includes('ýaşyl')) return '#16a34a';
  if (c.includes('turuncu') || c.includes('mämişi')) return '#f97316';
  if (c.includes('mor') || c.includes('melewşe')) return '#9333ea';
  if (c.includes('pembe') || c.includes('gülgün')) return '#ec4899';
  if (c.includes('beyaz') || c.includes('ak')) return '#e2e8f0';
  if (c.includes('kahve') || c.includes('goňur')) return '#92400e';
  if (c.includes('lacivert')) return '#1d4ed8';
  if (c.includes('gümüş') || c.includes('gri')) return '#64748b';
  if (c.includes('siyah') || c.includes('gara')) return '#334155';
  return '#f59e0b';
}

function computePreTestDate(harvestDateStr: string): string {
  if (!harvestDateStr) return '';
  const d = new Date(harvestDateStr);
  if (isNaN(d.getTime())) return '';
  d.setDate(d.getDate() - 12);
  return d.toISOString().slice(0, 10);
}

/**
 * Kurdele bağlama tarihinden itibaren kaç gün & kaç hafta geçtiğini,
 * Yaz (Mayıs-Eylül: 70-80 gün) / Kış (Ekim-Nisan: 85-100 gün) mevsim etkisini
 * ve 11. haftaya (77+ gün) girip girmediğini analiz eder.
 */
export function analyzeBananaRibbonMaturation(row: BananaContinuityRow, referenceDateStr = '2027-01-20') {
  const tagMs = Date.parse(row.taggingDate);
  const endStr = row.actualHarvestDate || row.expectedHarvestDate || referenceDateStr;
  const endMs = Date.parse(endStr);
  const rawDays = !isNaN(tagMs) && !isNaN(endMs) ? Math.max(1, Math.round((endMs - tagMs) / 86400000)) : 82;

  // İnsan hatası (geç bağlanan kurdele aslında doğumdan daha önce çıkmıştır)
  const effectiveDaysWithHumanDelay = rawDays + (Number(row.manualHumanDelayDays) || 0);
  const weeks = Number((effectiveDaysWithHumanDelay / 7).toFixed(1));

  // Doğum ayına göre Yaz / Kış döngüsü
  const tagMonth = !isNaN(tagMs) ? new Date(tagMs).getMonth() + 1 : 1;
  const isSummerCycle = tagMonth >= 4 && tagMonth <= 9; // Nisan-Eylül doğumları sıcak dönemde hızlı dolar
  const optimalMinDays = isSummerCycle ? 70 : 84;
  const optimalMaxDays = isSummerCycle ? 82 : 102;

  const isIn11thWeekWindow = effectiveDaysWithHumanDelay >= 75 && effectiveDaysWithHumanDelay <= 98;
  const isEarlyHarvest = effectiveDaysWithHumanDelay < optimalMinDays;
  const isLateOverripe = effectiveDaysWithHumanDelay > optimalMaxDays;

  let timingLabel = 'Optimal Hasat Dönemi (11–13. Hafta)';
  let timingBadge = 'text-emerald-800 bg-emerald-50 border-emerald-300';

  if (isEarlyHarvest) {
    timingLabel = isSummerCycle
      ? `☀️ Yaz Erken Hasat (${effectiveDaysWithHumanDelay} Gün / ${weeks} Hf)`
      : `❄️ Kış Erken Kesim (${effectiveDaysWithHumanDelay} Gün / ${weeks} Hf)`;
    timingBadge = 'text-amber-800 bg-amber-50 border-amber-300';
  } else if (isLateOverripe) {
    timingLabel = `🚨 Gecikmiş / Kalibre Aşımı (${effectiveDaysWithHumanDelay} Gün / ${weeks} Hf)`;
    timingBadge = 'text-rose-800 bg-rose-50 border-rose-300';
  } else if (isIn11thWeekWindow) {
    timingLabel = `🟢 11. Hafta Hasat Döneminde (${effectiveDaysWithHumanDelay} Gün / ${weeks} Hf)`;
    timingBadge = 'text-emerald-900 bg-emerald-100 border-emerald-400';
  }

  return {
    rawDays,
    effectiveDaysWithHumanDelay,
    weeks,
    seasonType: isSummerCycle ? 'Yaz Döngüsü (Hızlı Dolum)' : 'Kış Döngüsü (Uzun Dolum)',
    isIn11thWeekWindow,
    isEarlyHarvest,
    isLateOverripe,
    timingLabel,
    timingBadge
  };
}

function buildInitialBananaCalendarRows(): BananaContinuityRow[] {
  // 1. Google Sheet 'Toplam' sayfasındaki 36 dönemden gelen net tarih sıralı (kronolojik) kayıtlar
  const toplamRows = buildChronologicalRowsFromMuzToplam();

  // 2. 2027 devamlılık planı kayıtları (kanonik sera adlarıyla)
  const mapped2027: BananaContinuityRow[] = DEFAULT_BANANA_2027_RECORDS.slice(0, 7).map(
    (item: Banana2027RibbonEntry, idx: number) => {
      const canonicalGh = normalizeBananaGreenhouseName(item.greenhouseName);
      const harvestedBunches = item.actualHarvestedBunches || (idx % 3 === 0 ? 180 : 0);
      const harvestedKg =
        item.actualHarvestedKg ||
        (harvestedBunches > 0
          ? Math.round(harvestedBunches * (item.standardBranchKg + (idx % 2 === 0 ? 1.2 : -1.5)))
          : 0);
      const remaining = Math.max(0, item.boundBunchCount - harvestedBunches);

      return {
        id: item.id,
        cycleYear: '2027',
        greenhouseName: canonicalGh,
        sectorCode: item.sectorCode,
        variety: item.variety,
        ribbonColor: `${item.monthName} — ${item.ribbonName}`,
        ribbonHex: item.ribbonHex,
        taggingDate: item.taggingDate,
        expectedTestDate: computePreTestDate(item.expectedHarvestDate),
        expectedHarvestDate: item.expectedHarvestDate,
        boundBunchCount: item.boundBunchCount,
        standardBranchKg: item.standardBranchKg,
        plannedTonnageKg: item.plannedTonnageKg,
        harvestedBunchCount: harvestedBunches,
        harvestedNetKg: harvestedKg,
        harvestedCullKg: 0,
        actualAvgBranchKg:
          harvestedBunches > 0 ? Number((harvestedKg / harvestedBunches).toFixed(1)) : 0,
        remainingBunchCount: remaining,
        fingerCaliberMm: idx % 2 === 0 ? 41.5 : 37.5,
        fingerLengthCm: idx % 2 === 0 ? 21.5 : 18.0,
        targetMarket: idx % 2 === 0 ? 'EXPORT_PAZAR' : 'YEREL_PAZAR',
        crateType:
          idx % 2 === 0
            ? '18 kg Export Teleskopik Karton (MAP Poşetli)'
            : '13 kg Yerel Pazar Plastik Kasa',
        manualHumanDelayDays: 0,
        humanErrorType: 'Hatasız / Zamanında',
        status:
          item.harvestStatus === 'Tamamlandı'
            ? 'Tamamlandı'
            : harvestedBunches > 0
            ? 'Hasat-1 (İlk Kesim)'
            : 'Kurdele Bağlandı',
        sourceType: 'PLAN_2026_2027',
        foreman: item.foreman,
        notes: item.notes
      };
    }
  );

  return [...toplamRows, ...mapped2027].sort((a, b) =>
    a.taggingDate.localeCompare(b.taggingDate)
  );
}

export const BananaRibbonCalendarHub: React.FC<BananaRibbonCalendarHubProps> = ({
  muzRecords = [],
  dailyHarvestRecords = []
}) => {
  const { showSuccess, showInfo, showError } = useToast();

  const [rows, setRows] = useState<BananaContinuityRow[]>(() => {
    try {
      const saved = localStorage.getItem(BANANA_HUB_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return buildInitialBananaCalendarRows();
  });

  const saveRows = (updated: BananaContinuityRow[]) => {
    setRows(updated);
    try {
      localStorage.setItem(BANANA_HUB_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Filters & Sub-Views
  const [selectedGreenhouse, setSelectedGreenhouse] = useState<string>('ALL');
  const [selectedRibbonFilter, setSelectedRibbonFilter] = useState<string>('ALL');
  const [selectedMarket, setSelectedMarket] = useState<string>('ALL');
  const [selectedCycle, setSelectedCycle] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateSortOrder, setDateSortOrder] = useState<'TAGGING_ASC' | 'TAGGING_DESC' | 'HARVEST_ASC'>('TAGGING_ASC');
  const [activeSubView, setActiveSubView] = useState<
    'HARVEST_CALENDAR_MAIN' | 'HARVEST_FORECASTING_VIEW' | 'TOPLAM_SHEET_TABLE' | 'SECTOR_1_TO_7_VIEW'
  >('HARVEST_CALENDAR_MAIN');

  // 1..7 Sera Sektör Verileri ('1.Gkblt-5-6' .. '7.Hmsy-5')
  const [sectorRecords, setSectorRecords] = useState<BananaSectorRibbonRecord[]>(
    DEFAULT_BANANA_SECTOR_RECORDS
  );
  const [isSyncingSectors, setIsSyncingSectors] = useState<boolean>(false);

  // Gerçekleşen Kg Text / Link Entegrasyon State
  const [showActualKgLinkModal, setShowActualKgLinkModal] = useState<boolean>(false);
  const [actualKgLinkOrTextInput, setActualKgLinkOrTextInput] = useState<string>(
    'https://docs.google.com/spreadsheets/d/1bH_N06vBqFsarpmwMvroN18cJ9wYjPkz9zr2vZ328H4/edit?gid=167224735#gid=167224735'
  );
  const [isSyncingActualKg, setIsSyncingActualKg] = useState<boolean>(false);

  // Quick Add Ribbon / Daily Harvest Form
  const [activeQuickForm, setActiveQuickForm] = useState<'NONE' | 'ADD_RIBBON' | 'ADD_DAILY_HARVEST'>('NONE');

  // Bulk Edit States (Toplu Değiştirme: Kasa, Kurdele Rengi, Pazar, Statü, İnsan Hatası Günü)
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [bulkField, setBulkField] = useState<'CRATE' | 'RIBBON_COLOR' | 'MARKET' | 'STATUS' | 'HUMAN_DELAY'>('CRATE');
  const [bulkValue, setBulkValue] = useState<string>(BANANA_CRATE_OPTIONS[0]);

  // Form states for new or existing Ribbon Cohort Update
  const [editingRibbonRowId, setEditingRibbonRowId] = useState<string>('NEW');
  const [newGh, setNewGh] = useState('GB-5-6');
  const [newSector, setNewSector] = useState('Sektör 1');
  const [newCycle, setNewCycle] = useState<'2026→2027 Devamlı' | '2026' | '2027'>('2026→2027 Devamlı');
  const [newRibbonColor, setNewRibbonColor] = useState('Ocak — Mavi (Gök)');
  const [newTagDate, setNewTagDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [newHarvestDate, setNewHarvestDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 77); // 11 Hafta (77 gün)
    return d.toISOString().slice(0, 10);
  });
  const [newBoundCount, setNewBoundCount] = useState<number>(650);
  const [newStdBranchKg, setNewStdBranchKg] = useState<number>(37.5);
  const [newMarket, setNewMarket] = useState<BananaTargetMarket>('EXPORT_PAZAR');
  const [newHumanDelay, setNewHumanDelay] = useState<number>(0);

  // Form states for Daily Banana Harvest Entry
  const [targetRowId, setTargetRowId] = useState<string>('');
  const [cutBunchesInput, setCutBunchesInput] = useState<number>(90);
  const [netKgInput, setNetKgInput] = useState<number>(3420);
  const [cullKgInput, setCullKgInput] = useState<number>(55);
  const [caliberInput, setCaliberInput] = useState<number>(42.0);
  const [lengthInput, setLengthInput] = useState<number>(21.5);
  const [harvestDateInput, setHarvestDateInput] = useState<string>(() => new Date().toISOString().slice(0, 10));

  // Sync from Quality Module's Muz Kurdele (`muzRecords`) & Günlük Hasat (`dailyHarvestRecords`)
  const syncFromMuzAndDailyHarvestModules = (silent = false) => {
    let updated = rows.map(r => ({
      ...r,
      greenhouseName: normalizeBananaGreenhouseName(r.greenhouseName)
    }));

    muzRecords.forEach(mr => {
      const ghName = normalizeBananaGreenhouseName(mr.greenhouseNo || (mr as any).seraNo || 'GB-5-6');
      const rColor = mr.ribbonColor || (mr as any).renkKodu || 'Mavi';
      const recordTagDate = (mr as any).dogumTarihi || (mr.timestamp ? mr.timestamp.slice(0, 10) : new Date().toISOString().slice(0, 10));
      const existingIdx = updated.findIndex(
        r =>
          r.id === `MUZ-REC-${mr.id}` ||
          (normalizeBananaGreenhouseName(r.greenhouseName) === ghName &&
            r.ribbonColor.toLowerCase().includes(rColor.toLowerCase()) &&
            r.taggingDate === recordTagDate)
      );

      const boundCount = Number((mr as any).baglananDalSayisi) || 500;
      const stdKg = 37.5;
      const calMm = Number(mr.calibrationMm) || Number((mr as any).kalibreMm) || 41.0;
      const lenCm = Number(mr.fingerLengthCm) || Number((mr as any).parmakBoyuCm) || 21.0;
      const market: BananaTargetMarket = calMm >= 39 && lenCm >= 20 ? 'EXPORT_PAZAR' : 'YEREL_PAZAR';
      const estHarvestDate = (mr as any).tahminiHasatTarihi || '';

      if (existingIdx >= 0) {
        const cur = updated[existingIdx];
        updated[existingIdx] = {
          ...cur,
          boundBunchCount: boundCount,
          plannedTonnageKg: Math.round(boundCount * cur.standardBranchKg),
          remainingBunchCount: Math.max(0, boundCount - cur.harvestedBunchCount),
          fingerCaliberMm: calMm,
          fingerLengthCm: lenCm,
          targetMarket: market
        };
      } else {
        updated.unshift({
          id: `MUZ-REC-${mr.id}`,
          cycleYear: '2026→2027 Devamlı',
          greenhouseName: ghName,
          sectorCode: (mr as any).adaParsel || 'Sektör 1',
          variety: (mr as any).cesit || 'Cavendish Grand Nain',
          ribbonColor: rColor,
          ribbonHex: getRibbonHex(rColor),
          taggingDate: recordTagDate,
          expectedTestDate: computePreTestDate(estHarvestDate),
          expectedHarvestDate: estHarvestDate,
          boundBunchCount: boundCount,
          standardBranchKg: stdKg,
          plannedTonnageKg: Math.round(boundCount * stdKg),
          harvestedBunchCount: 0,
          harvestedNetKg: 0,
          harvestedCullKg: 0,
          actualAvgBranchKg: 0,
          remainingBunchCount: boundCount,
          fingerCaliberMm: calMm,
          fingerLengthCm: lenCm,
          targetMarket: market,
          crateType:
            market === 'EXPORT_PAZAR'
              ? '18 kg Export Teleskopik Karton (MAP Poşetli)'
              : '13 kg Yerel Pazar Plastik Kasa',
          manualHumanDelayDays: 0,
          humanErrorType: 'Hatasız / Zamanında',
          status: (mr as any).kesimOnayi === 'KESİME UYGUN' || mr.decision?.includes('Uygun') ? '11. Hafta — Hasat Dönemine Girdi' : 'Kurdele Bağlandı',
          sourceType: 'KURDELE_MODULU',
          foreman: (mr as any).kontrolEden || mr.operator || 'Agranom',
          notes: `Muz Kalite Modülünden Aktarıldı (${mr.refId || (mr as any).seriNo || ''})`
        });
      }
    });

    const bananaHarvests = dailyHarvestRecords.filter(
      dh =>
        (dh as any).cropCategory === 'MUZ' ||
        (dh.product || '').toLowerCase().includes('muz') ||
        (dh.product || '').toLowerCase().includes('banan')
    );

    if (bananaHarvests.length > 0) {
      const grouped = new Map<
        string,
        {
          greenhouse: string;
          ribbonColor: string;
          totalBunches: number;
          totalNetKg: number;
          totalCullKg: number;
          latestDate: string;
          foreman: string;
        }
      >();

      bananaHarvests.forEach(bh => {
        const gh = normalizeBananaGreenhouseName(bh.orchard || bh.location || (bh as any).greenhouse || (bh as any).locationName || 'GB-5-6');
        const rc = (bh as any).ribbonColor || 'Mavi';
        const key = `${gh}__${rc.toLowerCase()}`;
        const prev = grouped.get(key) || {
          greenhouse: gh,
          ribbonColor: rc,
          totalBunches: 0,
          totalNetKg: 0,
          totalCullKg: 0,
          latestDate: bh.recordDate || bh.timestamp,
          foreman: bh.foreman || bh.operator || 'Hasat Ekibi'
        };
        const netKg = Number(bh.dailyTotalKg) || Number((bh as any).netWeightKg) || 0;
        const bCount = Number((bh as any).bunchCount) || Math.max(1, Math.round(netKg / 37.5));
        prev.totalBunches += bCount;
        prev.totalNetKg += netKg;
        prev.totalCullKg += Number((bh as any).cullWeightKg) || 0;
        prev.latestDate = bh.recordDate || bh.timestamp || prev.latestDate;
        grouped.set(key, prev);
      });

      grouped.forEach(val => {
        const matchIdx = updated.findIndex(
          r =>
            normalizeBananaGreenhouseName(r.greenhouseName) === val.greenhouse &&
            r.ribbonColor.toLowerCase().includes(val.ribbonColor.toLowerCase())
        );

        if (matchIdx >= 0) {
          const target = updated[matchIdx];
          const bunches = Math.max(target.harvestedBunchCount, val.totalBunches);
          const netKg = Math.max(target.harvestedNetKg, val.totalNetKg);
          const remaining = Math.max(0, target.boundBunchCount - bunches);
          updated[matchIdx] = {
            ...target,
            actualHarvestDate: val.latestDate,
            harvestedBunchCount: bunches,
            harvestedNetKg: netKg,
            harvestedCullKg: val.totalCullKg,
            actualAvgBranchKg: bunches > 0 ? Number((netKg / bunches).toFixed(1)) : target.actualAvgBranchKg,
            remainingBunchCount: remaining,
            status: remaining === 0 ? 'Tamamlandı' : 'Hasat-1 (İlk Kesim)'
          };
        }
      });
    }

    saveRows(updated);
    if (!silent) {
      showSuccess('Muz Kurdele ve Günlük Hasat (Sera, Kg, Tarih) verileri takvime başarıyla entegre edildi.');
    }
  };

  // 1..7 Sera Sekmelerinden ('1.Gkblt-5-6' .. '7.Hmsy-5') Canlı Sektör Çekme
  const handleSync1to7SectorsFromSheets = async () => {
    setIsSyncingSectors(true);
    try {
      const res = await syncBananaRibbonWithSheets();
      if (res.records && res.records.length > 0) {
        setSectorRecords(res.records);
      }
      showSuccess(res.message);
    } catch {
      showError('1..7 Sera sekmeleri çekilirken bağlantı hatası oluştu, yerel veriler korunuyor.');
    } finally {
      setIsSyncingSectors(false);
    }
  };

  // Text içindeki Google Sheets linkinden veya Sheet34/Sheet22'den Gerçekleşen Kg Entegrasyonu
  const handleIntegrateActualKgFromTextOrLink = async (silent = false, customText?: string) => {
    setIsSyncingActualKg(true);
    try {
      const textToUse = customText !== undefined ? customText : actualKgLinkOrTextInput;
      const res = await syncActualKgFromTextLinkOrSheet(textToUse, rows);
      saveRows(res.updatedRows);
      if (!silent) {
        showSuccess(
          `Gerçekleşen Kg entegrasyonu tamamlandı (${res.sourceSummary}): ${res.matchedCount} kurdele grubunda toplam ${res.totalAddedKg.toLocaleString('tr-TR')} kg güncellendi.`
        );
        setShowActualKgLinkModal(false);
      }
    } catch {
      if (!silent) {
        showError('Gerçekleşen Kg linki okunurken hata oluştu.');
      }
    } finally {
      setIsSyncingActualKg(false);
    }
  };

  useEffect(() => {
    if (muzRecords.length > 0 || dailyHarvestRecords.length > 0) {
      syncFromMuzAndDailyHarvestModules(true);
    }
  }, [muzRecords.length, dailyHarvestRecords.length]);

  // Filtered & Chronologically Sorted rows
  const filteredRows = useMemo(() => {
    const list = rows.filter(r => {
      const rGhNorm = normalizeBananaGreenhouseName(r.greenhouseName);
      if (
        selectedGreenhouse !== 'ALL' &&
        rGhNorm !== normalizeBananaGreenhouseName(selectedGreenhouse)
      ) {
        return false;
      }
      if (selectedRibbonFilter !== 'ALL' && r.ribbonColor !== selectedRibbonFilter) return false;
      if (selectedMarket !== 'ALL' && r.targetMarket !== selectedMarket) return false;
      if (selectedCycle !== 'ALL' && r.cycleYear !== selectedCycle) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          rGhNorm.toLowerCase().includes(q) ||
          r.greenhouseName.toLowerCase().includes(q) ||
          r.ribbonColor.toLowerCase().includes(q) ||
          r.sectorCode.toLowerCase().includes(q) ||
          r.taggingDate.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (dateSortOrder === 'TAGGING_DESC') {
        return b.taggingDate.localeCompare(a.taggingDate);
      }
      if (dateSortOrder === 'HARVEST_ASC') {
        return (a.expectedHarvestDate || '').localeCompare(b.expectedHarvestDate || '');
      }
      return a.taggingDate.localeCompare(b.taggingDate);
    });
  }, [
    rows,
    selectedGreenhouse,
    selectedRibbonFilter,
    selectedMarket,
    selectedCycle,
    searchQuery,
    dateSortOrder
  ]);

  // SERA & KURDELE AKILLI FİLTRE TOPLAMLARI (7 Kanonik Sera: GB-5-6, GB-7-8, Maksat 9-10, Miweli 3-4, Miweli 1-2, Hem-11-12, Hem-5)
  const smartGreenhouseFilterTotals = useMemo(() => {
    const canonicalNames = ['ALL', ...BANANA_GREENHOUSES_2027.map(g => g.name)];

    return canonicalNames.map(ghKey => {
      const matching = rows.filter(r => {
        const rGhNorm = normalizeBananaGreenhouseName(r.greenhouseName);
        if (ghKey !== 'ALL' && rGhNorm !== ghKey) return false;
        if (selectedRibbonFilter !== 'ALL' && r.ribbonColor !== selectedRibbonFilter) return false;
        if (selectedMarket !== 'ALL' && r.targetMarket !== selectedMarket) return false;
        return true;
      });

      const ghMeta = BANANA_GREENHOUSES_2027.find(g => g.name === ghKey);
      const boundBunches = matching.reduce((s, r) => s + (r.boundBunchCount || 0), 0);
      const plannedTon = Number(
        (matching.reduce((s, r) => s + (r.plannedTonnageKg || 0), 0) / 1000).toFixed(1)
      );
      const harvestedTon = Number(
        (matching.reduce((s, r) => s + (r.harvestedNetKg || 0), 0) / 1000).toFixed(1)
      );
      const remainingBunches = matching.reduce((s, r) => s + (r.remainingBunchCount || 0), 0);

      return {
        key: ghKey,
        label: ghKey === 'ALL' ? 'Tüm 7 Sera (Toplam)' : ghKey,
        sheetTab: ghMeta?.sheetTab || 'Toplam',
        foreman: ghMeta?.foreman || (matching[0]?.foreman ?? 'Agranom'),
        count: matching.length,
        boundBunches,
        plannedTon,
        harvestedTon,
        remainingBunches
      };
    });
  }, [rows, selectedRibbonFilter, selectedMarket]);

  const smartRibbonFilterTotals = useMemo(() => {
    const uniqueRibbons = Array.from(new Set(['ALL', ...rows.map(r => r.ribbonColor)]));
    return uniqueRibbons.map(ribKey => {
      const matching = rows.filter(r => {
        if (selectedGreenhouse !== 'ALL' && r.greenhouseName !== selectedGreenhouse) return false;
        if (ribKey !== 'ALL' && r.ribbonColor !== ribKey) return false;
        if (selectedMarket !== 'ALL' && r.targetMarket !== selectedMarket) return false;
        return true;
      });
      const plannedTon = Number(
        (matching.reduce((s, r) => s + (r.plannedTonnageKg || 0), 0) / 1000).toFixed(1)
      );
      const harvestedTon = Number(
        (matching.reduce((s, r) => s + (r.harvestedNetKg || 0), 0) / 1000).toFixed(1)
      );
      const hex = ribKey === 'ALL' ? '#f59e0b' : getRibbonHex(ribKey);

      return {
        key: ribKey,
        label: ribKey === 'ALL' ? 'Tüm Kurdele Renkleri' : ribKey,
        hex,
        count: matching.length,
        plannedTon,
        harvestedTon
      };
    });
  }, [rows, selectedGreenhouse, selectedMarket]);

  // SERA BAZLI ORTALAMA HASAT EDİLEN DAL KG, İNSAN HATALARI VE HANGİ SERAYA ÖNEM VERİLMELİ ANALİZİ
  const greenhousePriorityAnalytics = useMemo(() => {
    // Genel hasat edilen kurdelelerin ortalama dal ağırlığı
    const allHarvestedRows = rows.filter(r => r.harvestedBunchCount > 0 && r.harvestedNetKg > 0);
    const totalHarvBunches = allHarvestedRows.reduce((s, r) => s + r.harvestedBunchCount, 0);
    const totalHarvKg = allHarvestedRows.reduce((s, r) => s + r.harvestedNetKg, 0);
    const globalAvgHarvestedBranchKg =
      totalHarvBunches > 0 ? Number((totalHarvKg / totalHarvBunches).toFixed(1)) : 37.5;

    const byGh = BANANA_GREENHOUSES_2027.map(gh => {
      const ghRows = rows.filter(
        r =>
          normalizeBananaGreenhouseName(r.greenhouseName) === gh.name &&
          r.status !== 'Hasat Yok'
      );
      const boundBunches = ghRows.reduce((s, r) => s + r.boundBunchCount, 0);
      const harvestedBunches = ghRows.reduce((s, r) => s + r.harvestedBunchCount, 0);
      const harvestedKg = ghRows.reduce((s, r) => s + r.harvestedNetKg, 0);
      const remainingBunches = ghRows.reduce((s, r) => s + r.remainingBunchCount, 0);
      const avgHarvestedBranchKg =
        harvestedBunches > 0 ? Number((harvestedKg / harvestedBunches).toFixed(1)) : 0;

      // İnsan hatası / geciken kurdele gün toplamı
      const totalHumanDelayDays = ghRows.reduce(
        (s, r) => s + Math.abs(Number(r.manualHumanDelayDays) || 0),
        0
      );
      const humanErrorCohortCount = ghRows.filter(
        r => (Number(r.manualHumanDelayDays) || 0) !== 0 || r.humanErrorType !== 'Hatasız / Zamanında'
      ).length;

      // 11. haftaya gelmiş ve kesim bekleyen kurdele sayısı
      const ready11thWeekCount = ghRows.filter(r => {
        const m = analyzeBananaRibbonMaturation(r);
        return (m.isIn11thWeekWindow || m.isLateOverripe) && r.remainingBunchCount > 0;
      }).length;

      // Öncelik Puanı (İnsan hatası + 11. hafta bekleyen + ortalama dal ağırlığı düşüklüğü)
      const weightDeficit =
        avgHarvestedBranchKg > 0 && avgHarvestedBranchKg < globalAvgHarvestedBranchKg
          ? (globalAvgHarvestedBranchKg - avgHarvestedBranchKg) * 4
          : 0;
      const priorityScore = Math.round(
        totalHumanDelayDays * 5 + ready11thWeekCount * 12 + weightDeficit
      );

      let priorityLevel: 'KRİTİK ÖNCELİK' | 'YÜKSEK DİKKAT' | 'NORMAL SEYİR' = 'NORMAL SEYİR';
      if (priorityScore >= 25 || totalHumanDelayDays >= 5) priorityLevel = 'KRİTİK ÖNCELİK';
      else if (priorityScore >= 12 || ready11thWeekCount >= 1) priorityLevel = 'YÜKSEK DİKKAT';

      const plannedKg = ghRows.reduce((s, r) => s + r.plannedTonnageKg, 0);
      const plannedTon = Number((plannedKg / 1000).toFixed(1));
      const efficiencyPct =
        boundBunches > 0
          ? Math.min(100, Math.round(((harvestedBunches + ready11thWeekCount * 120) / Math.max(1, boundBunches)) * 100))
          : 78;

      return {
        greenhouseName: gh.name,
        foreman: gh.foreman,
        boundBunches,
        harvestedBunches,
        plannedTon,
        harvestedTon: Number((harvestedKg / 1000).toFixed(1)),
        efficiencyPct,
        remainingBunches,
        avgHarvestedBranchKg: avgHarvestedBranchKg || 36.5,
        diffFromGlobalAvgKg:
          avgHarvestedBranchKg > 0
            ? Number((avgHarvestedBranchKg - globalAvgHarvestedBranchKg).toFixed(1))
            : 0,
        totalHumanDelayDays,
        humanErrorCohortCount,
        ready11thWeekCount,
        priorityScore,
        priorityLevel
      };
    }).sort((a, b) => b.priorityScore - a.priorityScore);

    return {
      globalAvgHarvestedBranchKg,
      totalHarvBunches,
      totalHarvTon: Number((totalHarvKg / 1000).toFixed(1)),
      greenhousesRanked: byGh
    };
  }, [rows]);

  // Toplu Düzenleme (Bulk Edit) Fonksiyonları
  const toggleSelectRow = (id: string) => {
    setSelectedRowIds(prev => (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]));
  };

  const toggleSelectAllFiltered = () => {
    const fIds = filteredRows.map(r => r.id);
    const allSelected = fIds.length > 0 && fIds.every(id => selectedRowIds.includes(id));
    if (allSelected) {
      setSelectedRowIds(prev => prev.filter(id => !fIds.includes(id)));
    } else {
      setSelectedRowIds(Array.from(new Set([...selectedRowIds, ...fIds])));
    }
  };

  const handleApplyBulkEdit = () => {
    if (selectedRowIds.length === 0) {
      showError('Lütfen önce tabloda toplu değiştirmek istediğiniz kurdele satırlarını seçin.');
      return;
    }

    const updated = rows.map(r => {
      if (!selectedRowIds.includes(r.id)) return r;
      const copy: BananaContinuityRow = { ...r };

      if (bulkField === 'CRATE') {
        copy.crateType = bulkValue;
      } else if (bulkField === 'RIBBON_COLOR') {
        copy.ribbonColor = bulkValue;
        copy.ribbonHex = getRibbonHex(bulkValue);
      } else if (bulkField === 'MARKET') {
        copy.targetMarket = bulkValue as BananaTargetMarket;
      } else if (bulkField === 'STATUS') {
        copy.status = bulkValue as BananaContinuityRow['status'];
      } else if (bulkField === 'HUMAN_DELAY') {
        const d = Number(bulkValue) || 0;
        copy.manualHumanDelayDays = d;
        copy.humanErrorType =
          d > 0
            ? 'Geç Kurdele Bağlama (İnsan Hatası)'
            : d < 0
            ? 'Erken Kurdele Bağlama'
            : 'Hatasız / Zamanında';
      }
      return copy;
    });

    saveRows(updated);
    showSuccess(`Seçili ${selectedRowIds.length} muz kurdele satırında toplu değişiklik uygulandı.`);
  };

  // Add new Ribbon Cohort or Update Existing Ribbon Binding
  const handleSelectExistingRibbonToEdit = (rowId: string) => {
    setEditingRibbonRowId(rowId);
    if (rowId === 'NEW') return;
    const found = rows.find(r => r.id === rowId);
    if (!found) return;
    setNewCycle(found.cycleYear);
    setNewGh(found.greenhouseName);
    setNewSector(found.sectorCode);
    setNewRibbonColor(found.ribbonColor);
    setNewTagDate(found.taggingDate);
    setNewHarvestDate(found.expectedHarvestDate);
    setNewBoundCount(found.boundBunchCount);
    setNewStdBranchKg(found.standardBranchKg);
    setNewMarket(found.targetMarket);
    setNewHumanDelay(found.manualHumanDelayDays);
    setActiveQuickForm('ADD_RIBBON');
  };

  const handleAddRibbonCohort = (e: React.FormEvent) => {
    e.preventDefault();
    const plannedKg = Math.round(newBoundCount * newStdBranchKg);

    if (editingRibbonRowId !== 'NEW') {
      const updated = rows.map(r => {
        if (r.id !== editingRibbonRowId) return r;
        const remaining = Math.max(0, newBoundCount - r.harvestedBunchCount);
        return {
          ...r,
          cycleYear: newCycle,
          greenhouseName: newGh,
          sectorCode: newSector,
          ribbonColor: newRibbonColor,
          ribbonHex: getRibbonHex(newRibbonColor),
          taggingDate: newTagDate,
          expectedTestDate: computePreTestDate(newHarvestDate),
          expectedHarvestDate: newHarvestDate,
          boundBunchCount: newBoundCount,
          standardBranchKg: newStdBranchKg,
          plannedTonnageKg: plannedKg,
          remainingBunchCount: remaining,
          targetMarket: newMarket,
          crateType:
            newMarket === 'EXPORT_PAZAR'
              ? '18 kg Export Teleskopik Karton (MAP Poşetli)'
              : '13 kg Yerel Pazar Plastik Kasa',
          manualHumanDelayDays: newHumanDelay,
          humanErrorType: (
            newHumanDelay > 0
              ? 'Geç Kurdele Bağlama (İnsan Hatası)'
              : newHumanDelay < 0
              ? 'Erken Kurdele Bağlama'
              : 'Hatasız / Zamanında'
          ) as BananaHumanErrorType
        };
      });
      saveRows(updated);
      setEditingRibbonRowId('NEW');
      setActiveQuickForm('NONE');
      showSuccess(`${newGh} (${newSector}) mevcut kurdele bağlama kaydı güncellendi ve takvimde gösterildi.`);
      return;
    }

    const newEntry: BananaContinuityRow = {
      id: `BN-MAN-${Date.now()}`,
      cycleYear: newCycle,
      greenhouseName: newGh,
      sectorCode: newSector,
      variety: 'Cavendish Grand Nain',
      ribbonColor: newRibbonColor,
      ribbonHex: getRibbonHex(newRibbonColor),
      taggingDate: newTagDate,
      expectedTestDate: computePreTestDate(newHarvestDate),
      expectedHarvestDate: newHarvestDate,
      boundBunchCount: newBoundCount,
      standardBranchKg: newStdBranchKg,
      plannedTonnageKg: plannedKg,
      harvestedBunchCount: 0,
      harvestedNetKg: 0,
      harvestedCullKg: 0,
      actualAvgBranchKg: 0,
      remainingBunchCount: newBoundCount,
      fingerCaliberMm: newMarket === 'EXPORT_PAZAR' ? 42.0 : 37.0,
      fingerLengthCm: newMarket === 'EXPORT_PAZAR' ? 21.5 : 18.0,
      targetMarket: newMarket,
      crateType:
        newMarket === 'EXPORT_PAZAR'
          ? '18 kg Export Teleskopik Karton (MAP Poşetli)'
          : '13 kg Yerel Pazar Plastik Kasa',
      manualHumanDelayDays: newHumanDelay,
      humanErrorType:
        newHumanDelay > 0
          ? 'Geç Kurdele Bağlama (İnsan Hatası)'
          : newHumanDelay < 0
          ? 'Erken Kurdele Bağlama'
          : 'Hatasız / Zamanında',
      status: 'Kurdele Bağlandı',
      sourceType: 'PLAN_2026_2027',
      foreman: 'A.Myradow',
      notes: `${newCycle} Kurdele Planı (${newGh} · ${newRibbonColor})`
    };

    saveRows([newEntry, ...rows]);
    setActiveQuickForm('NONE');
    showSuccess(`${newGh} serası için "${newRibbonColor}" kurdele planı eklendi.`);
  };

  // Log Daily Banana Harvest
  const handleAddDailyBananaHarvest = (e: React.FormEvent) => {
    e.preventDefault();
    const chosenId = targetRowId || (rows[0] ? rows[0].id : '');
    if (!chosenId) return;

    const updated = rows.map(r => {
      if (r.id !== chosenId) return r;
      const newHarvestedBunches = r.harvestedBunchCount + Number(cutBunchesInput);
      const newHarvestedKg = r.harvestedNetKg + Number(netKgInput);
      const newCullKg = r.harvestedCullKg + Number(cullKgInput);
      const remaining = Math.max(0, r.boundBunchCount - newHarvestedBunches);
      const avgKg =
        newHarvestedBunches > 0
          ? Number((newHarvestedKg / newHarvestedBunches).toFixed(1))
          : r.standardBranchKg;
      const qualifiedMarket: BananaTargetMarket =
        caliberInput >= 39 && lengthInput >= 20 ? 'EXPORT_PAZAR' : 'YEREL_PAZAR';

      let nextStatus: BananaContinuityRow['status'] = 'Hasat-1 (İlk Kesim)';
      if (remaining === 0) nextStatus = 'Tamamlandı';
      else if (r.harvestedBunchCount > 0) nextStatus = 'Hasat-2 (İkinci Kesim)';

      return {
        ...r,
        actualHarvestDate: harvestDateInput,
        harvestedBunchCount: newHarvestedBunches,
        harvestedNetKg: newHarvestedKg,
        harvestedCullKg: newCullKg,
        actualAvgBranchKg: avgKg,
        remainingBunchCount: remaining,
        fingerCaliberMm: caliberInput || r.fingerCaliberMm,
        fingerLengthCm: lengthInput || r.fingerLengthCm,
        targetMarket: qualifiedMarket,
        status: nextStatus
      };
    });

    saveRows(updated);
    setActiveQuickForm('NONE');
    showSuccess(
      `Günlük muz hasadı (${cutBunchesInput} dal / ${netKgInput.toLocaleString('tr-TR')} kg) takvime işlendi ve ortalama dal ağırlığı güncellendi.`
    );
  };

  const updateRowCell = (id: string, field: keyof BananaContinuityRow, value: any) => {
    const updated = rows.map(r => {
      if (r.id !== id) return r;
      const copy = { ...r, [field]: value };
      copy.plannedTonnageKg = Math.round(
        Number(copy.boundBunchCount || 0) * Number(copy.standardBranchKg || 37)
      );
      copy.remainingBunchCount = Math.max(
        0,
        Number(copy.boundBunchCount || 0) - Number(copy.harvestedBunchCount || 0)
      );
      if (copy.harvestedBunchCount > 0) {
        copy.actualAvgBranchKg = Number(
          (copy.harvestedNetKg / copy.harvestedBunchCount).toFixed(1)
        );
      }
      if (field === 'manualHumanDelayDays') {
        const d = Number(value) || 0;
        copy.humanErrorType = (
          d > 0
            ? 'Geç Kurdele Bağlama (İnsan Hatası)'
            : d < 0
            ? 'Erken Kurdele Bağlama'
            : 'Hatasız / Zamanında'
        ) as BananaHumanErrorType;
      }
      return copy;
    });
    saveRows(updated);
  };

  const handleDeleteRow = (id: string) => {
    saveRows(rows.filter(r => r.id !== id));
    showInfo('Muz kurdele takvim satırı silindi.');
  };

  const handleExportCsv = () => {
    const headers = [
      'Döngü',
      'Sera',
      'Sektör',
      'Kurdele Rengi',
      'Bağlama Tarihi',
      'Tahmini Hasat',
      'Kaç Günlük / Haftalık',
      'İnsan Hatası Gecikme (Gün)',
      'Pazar Hedefi (Export / Yerel)',
      'Kasa Tipi',
      'Bağlanan Dal',
      'Kesilen Dal',
      'Hasat Net Kg',
      'Ortalama Hasat Dal Kg',
      'Serada Kalan Dal',
      'Kalibre (mm)',
      'Durum'
    ].join(',');

    const csvRows = filteredRows.map(r => {
      const mat = analyzeBananaRibbonMaturation(r);
      return [
        r.cycleYear,
        r.greenhouseName,
        r.sectorCode,
        r.ribbonColor,
        r.taggingDate,
        r.expectedHarvestDate,
        `${mat.effectiveDaysWithHumanDelay} gün (${mat.weeks} hf)`,
        r.manualHumanDelayDays,
        r.targetMarket === 'EXPORT_PAZAR' ? 'İhracat (Export)' : 'Yerel Pazar',
        r.crateType,
        r.boundBunchCount,
        r.harvestedBunchCount,
        r.harvestedNetKg,
        r.actualAvgBranchKg,
        r.remainingBunchCount,
        r.fingerCaliberMm,
        r.status
      ]
        .map(v => `"${String(v ?? '').replace(/"/g, '""')}"`)
        .join(',');
    });

    const blob = new Blob(['\uFEFF' + [headers, ...csvRows].join('\r\n')], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Muz_Kurdele_Hasat_Takvimi_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    showSuccess('Muz Kurdele Hasat Takvimi CSV olarak indirildi.');
  };

  return (
    <div className="space-y-5 bg-white p-3 sm:p-5 rounded-3xl border border-amber-200/80 shadow-sm text-slate-900">
      {/* 1. AYDIN TEMALI SERA MUZ KURDELE HASAT TAKVİMİ ÜST HEADER & HIZLI AKSİYONLAR */}
      <div className="bg-gradient-to-r from-white via-amber-50/80 to-emerald-50/70 border border-amber-200/90 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-emerald-700 hover:bg-emerald-800 p-0.5 shadow-md shrink-0">
              <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center">
                <svg viewBox="0 0 64 64" className="w-10 h-10">
                  <rect x="6" y="8" width="52" height="48" rx="10" fill="#fffbeb" stroke="#f59e0b" strokeWidth="2.2" />
                  <path d="M12 22 Q32 10 52 22" fill="none" stroke="#10b981" strokeWidth="2.2" strokeDasharray="3 2" />
                  <path d="M22 24 C20 36, 28 45, 42 42 C34 40, 27 33, 27 24 Z" fill="#f59e0b" />
                  <path d="M28 22 C27 33, 35 41, 47 37 C39 36, 33 30, 33 22 Z" fill="#fbbf24" />
                  <circle cx="27" cy="22" r="4" fill="#2563eb" stroke="#ffffff" strokeWidth="1.5" />
                </svg>
              </div>
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold mb-1">
                 Aydın Temalı Sera Muz Kurdele & Hasat Tahmin Platformu · 2026  2027
              </div>
              <h2 className="text-lg sm:text-2xl font-bold text-slate-900 tracking-tight">
                MuzKurdeleView — 11-Hafta Hasat Takvimi, Harvest Forecasting & Sera Verimlilik Analizi
              </h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Muz modülünden (Sera No, Sektör, Kg, Tarih) canlı entegrasyon · Renk kodlu (Ekim–Kasım) Beklenen vs. Gerçekleşen Hasat Tahmini ve toplu Kasa/Renk yönetimi
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setEditingRibbonRowId('NEW');
                setActiveQuickForm(activeQuickForm === 'ADD_RIBBON' ? 'NONE' : 'ADD_RIBBON');
              }}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition"
            >
              <Plus className="w-4 h-4" />
              <span> Kurdele Bağlama Ekle / Güncelle</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveQuickForm(
                  activeQuickForm === 'ADD_DAILY_HARVEST' ? 'NONE' : 'ADD_DAILY_HARVEST'
                )
              }
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition"
            >
              <Scale className="w-4 h-4" />
              <span> + Günlük Muz Hasadı Gir</span>
            </button>

            <button
              type="button"
              onClick={() => setShowActualKgLinkModal(prev => !prev)}
              className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition"
            >
              <Link2 className="w-3.5 h-3.5" />
              <span> Gerçekleşen Kg (Text / Link) Entegre Et</span>
            </button>

            <button
              type="button"
              onClick={() => syncFromMuzAndDailyHarvestModules(false)}
              className="px-3 py-2 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition"
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-600" />
              <span>Kalite İzlenebilirlikten Güncelle</span>
            </button>

            <button
              type="button"
              onClick={handleExportCsv}
              className="px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        {/* ALT GÖRÜNÜM SEÇİCİ: 1) HASAT TAKVİMİ (NET TARİH SIRALI), 2) HARVEST FORECASTING (BEKLENEN VS GERÇEKLEŞEN), 3) G.SHEET TOPLAM SAYFASI, 4) 1..7 SERA SEKTÖR BOYUNCA BAĞLANAN */}
        <div className="mt-4 pt-3 border-t border-amber-200/80 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setActiveSubView('HARVEST_CALENDAR_MAIN')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition ${
                activeSubView === 'HARVEST_CALENDAR_MAIN'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-amber-50'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-amber-500" />
              <span> Net Tarih Sıralı Muz Hasat Takvimi</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubView('HARVEST_FORECASTING_VIEW')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition ${
                activeSubView === 'HARVEST_FORECASTING_VIEW'
                  ? 'bg-sky-700 text-white border-sky-800 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-sky-50'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-sky-500" />
              <span> Harvest Forecasting (Beklenen vs. Gerçekleşen · Renk & Ekim–Kasım)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubView('TOPLAM_SHEET_TABLE')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition ${
                activeSubView === 'TOPLAM_SHEET_TABLE'
                  ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-emerald-50'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span> G.Sheet "Toplam" Sayfası (Gerçekleşen Hasat Kg + Ekim/Kasım Kurdele & Gecikme)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubView('SECTOR_1_TO_7_VIEW')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition ${
                activeSubView === 'SECTOR_1_TO_7_VIEW'
                  ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-amber-50'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-amber-600" />
              <span> 1. 2. 3. 4. 5. 6. 7. Sera Boyunca Sektör Bağlananlar</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700">
            <span>Tarih Sıralaması:</span>
            <select
              value={dateSortOrder}
              onChange={e => setDateSortOrder(e.target.value as any)}
              className="bg-white border border-amber-300 rounded-xl px-2.5 py-1 text-xs font-bold text-amber-950 cursor-pointer"
            >
              <option value="TAGGING_ASC"> Bağlama Tarihi (Eskiden Yeniye · Kronolojik)</option>
              <option value="TAGGING_DESC"> Bağlama Tarihi (Yeniden Eskiye)</option>
              <option value="HARVEST_ASC"> Tahmini Hasat Tarihi Sıralı</option>
            </select>
          </div>
        </div>
      </div>

      {/* GERÇEKLEŞEN KG: TEXT İÇİNDEKİ LİNKTEN VEYA KANTAR SAYFASINDAN ENTEGRASYON PANELİ */}
      {showActualKgLinkModal && (
        <div className="bg-white border-2 border-sky-400 rounded-2xl p-4 space-y-3 shadow-md text-xs">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div>
              <span className="font-bold text-sky-900 flex items-center gap-1.5">
                <Link2 className="w-4 h-4 text-sky-600" />
                <span>
                  Gerçekleşen Kg Entegrasyonu — Text İçindeki Google Sheets Linkinden veya Kantar Sayfasından Çek
                </span>
              </span>
              <p className="text-[11px] text-slate-600 mt-0.5">
                İçinde Google Sheets linki bulunan metni (.txt içeriğini) veya doğrudan tabloyu aşağıya yapıştırın; sistem <strong>gb 7- 8 === GB-7-8</strong> kısaltmalarını eşleştirerek <strong>Gerçekleşen Kg</strong> sütunlarını otomatik doldurur.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowActualKgLinkModal(false)}
              className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <textarea
            rows={3}
            value={actualKgLinkOrTextInput}
            onChange={e => setActualKgLinkOrTextInput(e.target.value)}
            placeholder="Text içindeki Google Sheets linkini veya tablo satırlarını buraya yapıştırın..."
            className="w-full bg-slate-50 border border-sky-300 rounded-xl p-2.5 text-xs tabular-nums text-slate-900"
          />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] text-slate-500">
              Varsayılan Kaynaklar: Muz Kurdele G.Sheet (Toplam + Sheet34 + Sheet22 Hoşalyagramy,kg) & Muz Kontrolleri
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isSyncingActualKg}
                onClick={() => handleIntegrateActualKgFromTextOrLink(false)}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer shadow-sm flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingActualKg ? 'animate-spin' : ''}`} />
                <span>Gerçekleşen Kg Verilerini Şimdi Entegre Et</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. MEVCUT MUZ KURDELE BAĞLAMA GÜNCELLE & YENİ PLAN EKLE FORMU */}
      {activeQuickForm === 'ADD_RIBBON' && (
        <form
          onSubmit={handleAddRibbonCohort}
          className="bg-white border-2 border-amber-400 rounded-2xl p-4 space-y-3.5 shadow-md text-xs"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
            <div className="flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-amber-600" />
              <span className="font-bold text-slate-900 text-xs sm:text-sm">
                 Mevcut Muz Kurdele Bağlama Güncelle veya Yeni Kurdele Planı Ekle
              </span>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={editingRibbonRowId}
                onChange={e => handleSelectExistingRibbonToEdit(e.target.value)}
                className="bg-amber-50 border border-amber-300 rounded-xl px-3 py-1.5 text-xs font-bold text-amber-900"
              >
                <option value="NEW"> Yeni Kurdele Bağlama Kaydı Oluştur</option>
                {rows.map(r => (
                  <option key={r.id} value={r.id}>
                    ✏️ Güncelle: {r.greenhouseName} ({r.sectorCode}) — {r.ribbonColor}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => setActiveQuickForm('NONE')}
                className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-2.5">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Döngü</label>
              <select
                value={newCycle}
                onChange={e => setNewCycle(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-slate-900 font-bold"
              >
                <option value="2026→2027 Devamlı">2026→2027 Devamlı</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Sera No</label>
              <select
                value={newGh}
                onChange={e => setNewGh(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-slate-900 font-bold"
              >
                {BANANA_GREENHOUSES_2027.map(g => (
                  <option key={g.id} value={g.name}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-amber-800 mb-1">Sektör</label>
              <select
                value={newSector}
                onChange={e => setNewSector(e.target.value)}
                className="w-full bg-amber-50 border border-amber-300 rounded-lg px-2 py-1.5 text-amber-900 font-bold"
              >
                <option value="Sektör 1">Sektör 1</option>
                <option value="Sektör 2">Sektör 2</option>
                <option value="Sektör 3">Sektör 3</option>
                <option value="Sektör 4">Sektör 4</option>
                <option value="Sektör A (Kuzey)">Sektör A (Kuzey)</option>
                <option value="Sektör B (Güney)">Sektör B (Güney)</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Kurdele Rengi</label>
              <select
                value={newRibbonColor}
                onChange={e => setNewRibbonColor(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-slate-900 font-bold"
              >
                {BANANA_12_MONTH_RIBBONS.map(r => (
                  <option key={r.monthIndex} value={`${r.monthNameTr} — ${r.ribbonName}`}>
                    {r.monthNameTr} — {r.ribbonName}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Bağlama Tarihi</label>
              <input
                type="date"
                value={newTagDate}
                onChange={e => setNewTagDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-slate-900 tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Tahmini Hasat</label>
              <input
                type="date"
                value={newHarvestDate}
                onChange={e => setNewHarvestDate(e.target.value)}
                className="w-full bg-emerald-50 border border-emerald-300 rounded-lg px-2 py-1.5 text-emerald-900 tabular-nums font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Bağlanan Dal</label>
              <input
                type="number"
                value={newBoundCount}
                onChange={e => setNewBoundCount(Number(e.target.value))}
                className="w-full bg-amber-50 border border-amber-300 rounded-lg px-2 py-1.5 text-amber-900 font-bold tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Hedef Pazar</label>
              <select
                value={newMarket}
                onChange={e => setNewMarket(e.target.value as BananaTargetMarket)}
                className="w-full bg-sky-50 border border-sky-300 rounded-lg px-2 py-1.5 text-sky-900 font-bold"
              >
                <option value="EXPORT_PAZAR"> Export Pazar</option>
                <option value="YEREL_PAZAR"> Yerel Pazar</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-rose-700 mb-1">İnsan Hatası (+/- Gün)</label>
              <input
                type="number"
                value={newHumanDelay}
                onChange={e => setNewHumanDelay(Number(e.target.value))}
                placeholder="Örn: +5"
                className="w-full bg-rose-50 border border-rose-300 rounded-lg px-2 py-1.5 text-rose-800 tabular-nums font-bold"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-600">
              {editingRibbonRowId !== 'NEW'
                ? 'Seçili mevcut kurdele bağlama kaydı güncellenerek Gantt çizelgesine ve takvim tablosuna yansıtılacaktır.'
                : 'Yeni kurdele bağlama kaydı doğrudan 11-haftalık Gantt çizelgesine ve takvime eklenecektir.'}
            </span>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold cursor-pointer shadow-sm"
            >
              {editingRibbonRowId !== 'NEW' ? '💾 Mevcut Kurdele Bağlamayı Güncelle' : '➕ Yeni Kurdele Planını Kaydet'}
            </button>
          </div>
        </form>
      )}

      {activeQuickForm === 'ADD_DAILY_HARVEST' && (
        <form
          onSubmit={handleAddDailyBananaHarvest}
          className="bg-white border-2 border-emerald-400 rounded-2xl p-4 space-y-3 shadow-md text-xs"
        >
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <span className="font-bold text-emerald-800">
               Günlük Muz Hasadı Gir — Sera No, Kurdele, Kesilen Dal, Kantar Kg ve Kalibre
            </span>
            <button
              type="button"
              onClick={() => setActiveQuickForm('NONE')}
              className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-6 gap-2.5">
            <div className="sm:col-span-2">
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Sera & Kurdele Seçin</label>
              <select
                value={targetRowId || (rows[0]?.id ?? '')}
                onChange={e => setTargetRowId(e.target.value)}
                className="w-full bg-slate-50 border border-emerald-300 rounded-lg px-2.5 py-1.5 text-slate-900 font-bold"
              >
                {rows.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.greenhouseName} ({r.sectorCode} · {r.ribbonColor}) — Kalan: {r.remainingBunchCount} dal
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-1">Kesim Tarihi</label>
              <input
                type="date"
                value={harvestDateInput}
                onChange={e => setHarvestDateInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-slate-900 tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-amber-800 mb-1">Kesilen Dal Adedi</label>
              <input
                type="number"
                min="1"
                value={cutBunchesInput}
                onChange={e => setCutBunchesInput(Number(e.target.value))}
                className="w-full bg-amber-50 border border-amber-300 rounded-lg px-2 py-1.5 text-amber-900 font-bold tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-emerald-800 mb-1">Kantar Net Kg</label>
              <input
                type="number"
                min="1"
                value={netKgInput}
                onChange={e => setNetKgInput(Number(e.target.value))}
                className="w-full bg-emerald-50 border border-emerald-300 rounded-lg px-2 py-1.5 text-emerald-900 font-bold tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-sky-800 mb-1">Kalibre (mm) / Boy (cm)</label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="0.5"
                  value={caliberInput}
                  onChange={e => setCaliberInput(Number(e.target.value))}
                  className="w-1/2 bg-sky-50 border border-sky-300 rounded-lg px-1.5 py-1.5 text-sky-900 tabular-nums font-bold"
                  title="Parmak Kalibre (mm)"
                />
                <input
                  type="number"
                  step="0.5"
                  value={lengthInput}
                  onChange={e => setLengthInput(Number(e.target.value))}
                  className="w-1/2 bg-sky-50 border border-sky-300 rounded-lg px-1.5 py-1.5 text-sky-900 tabular-nums font-bold"
                  title="Parmak Boyu (cm)"
                />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between pt-1">
            <div className="text-[11px] text-slate-700">
              Fiili Dal Ortalaması:{' '}
              <strong className="text-amber-700 tabular-nums">
                {cutBunchesInput > 0 ? (netKgInput / cutBunchesInput).toFixed(1) : '0'} kg/dal
              </strong>{' '}
              · Otomatik Pazar Uygunluğu:{' '}
              <strong className={caliberInput >= 39 && lengthInput >= 20 ? 'text-emerald-700' : 'text-amber-700'}>
                {caliberInput >= 39 && lengthInput >= 20
                  ? '🌍 İhracat (iç kural: kalınlık ≥39 / boy ≥20 cm)'
                  : '🏪 Yerel Pazar (İç Piyasa)'}
              </strong>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer shadow-sm"
            >
              Hasadı Takvime İşle
            </button>
          </div>
        </form>
      )}

      {/* 2.5 SERA & KURDELE AKILLI FİLTRE TOPLAMLARI (Bahçe & Meyve Akıllı Filtre Toplamları gibi Sera Bazlı) */}
      <div className="bg-white border border-amber-200/90 rounded-2xl p-4 space-y-3.5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-amber-600" />
            <span className="text-xs sm:text-sm font-bold text-slate-900">
              Sera & Kurdele Akıllı Filtre Toplamları (Sera Bazlı Canlı Tonaj & Dal Özeti)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedMarket}
              onChange={e => setSelectedMarket(e.target.value)}
              className="bg-sky-50 border border-sky-300 rounded-xl px-3 py-1.5 text-xs font-bold text-sky-900 cursor-pointer"
            >
              <option value="ALL">Tüm Pazarlar (Export + Yerel)</option>
              <option value="EXPORT_PAZAR"> İhracat (Export Pazar)</option>
              <option value="YEREL_PAZAR"> Yerel Pazar (İç Piyasa)</option>
            </select>

            <select
              value={selectedCycle}
              onChange={e => setSelectedCycle(e.target.value)}
              className="bg-amber-50 border border-amber-300 rounded-xl px-3 py-1.5 text-xs font-bold text-amber-900 cursor-pointer"
            >
              <option value="ALL">Tüm Döngüler (20262027)</option>
              <option value="2026→2027 Devamlı">2026→2027 Devam Edenler</option>
              <option value="2027">2027 Kurdeleleri</option>
            </select>

            <div className="relative w-52 sm:w-60">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Sera, sektör, renk, kasa ara..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-2.5 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-amber-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Sera Bazlı Akıllı Filtre Kartları (Üzerinde Kurdele Sayısı, Planlanan Tonaj, Kesilen Tonaj ve Kalan Dal) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-9 gap-2">
          {smartGreenhouseFilterTotals.map(gh => {
            const isSelected = selectedGreenhouse === gh.key;
            return (
              <button
                key={gh.key}
                type="button"
                onClick={() => setSelectedGreenhouse(gh.key)}
                className={`p-2.5 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-amber-500 ring-2 ring-amber-400/50 shadow-sm'
                    : 'bg-slate-50/80 border-slate-200 hover:border-amber-300 hover:bg-amber-50/30'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className={`text-xs font-bold ${isSelected ? 'text-amber-950' : 'text-slate-900'}`}>
                    {gh.label}
                  </span>
                  <span className="text-[10px] tabular-nums font-bold text-slate-600">
                    {gh.count} grup
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[10px] tabular-nums tabular-nums">
                  <span className="text-amber-800 font-bold" title="Planlanan Tonaj">
                    Plan: {gh.plannedTon}T
                  </span>
                  <span className="text-emerald-700 font-bold" title="Kesilen Hasat Tonajı">
                    Kesim: {gh.harvestedTon}T
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between text-[9px] text-slate-500 tabular-nums">
                  <span>Bağ: {gh.boundBunches} dal</span>
                  <span className="text-slate-700 font-bold">Kalan: {gh.remainingBunches}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Kurdele Rengi Akıllı Filtre Butonları (Üzerinde Grup Sayısı ve Plan/Kesim Tonajı) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5">
          {smartRibbonFilterTotals.map(rib => {
            const isSelected = selectedRibbonFilter === rib.key;
            return (
              <button
                key={rib.key}
                type="button"
                onClick={() => setSelectedRibbonFilter(rib.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-amber-50 hover:border-amber-300'
                }`}
              >
                <span
                  className="w-3 h-3 rounded-full border border-white/60 shrink-0"
                  style={{ backgroundColor: rib.hex }}
                />
                <span>{rib.label}</span>
                <span
                  className={`text-[10px] tabular-nums tabular-nums ${
                    isSelected ? 'text-amber-300' : 'text-slate-500'
                  }`}
                >
                  {rib.count} · {rib.plannedTon}T
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ALT GÖRÜNÜMLER: HARVEST FORECASTING, G.SHEET 'TOPLAM' SAYFASI VEYA 1..7 SERA SEKTÖR MATRİSİ */}
      {activeSubView === 'HARVEST_FORECASTING_VIEW' && (
        <BananaHarvestForecastingView
          calendarRows={rows}
          selectedGreenhouse={selectedGreenhouse}
          onSelectGreenhouse={setSelectedGreenhouse}
          onUpdateRowCell={updateRowCell}
        />
      )}

      {(activeSubView === 'TOPLAM_SHEET_TABLE' || activeSubView === 'SECTOR_1_TO_7_VIEW') && (
        <BananaToplamSectorAndQualityViews
          activeSubMode={activeSubView}
          calendarRows={filteredRows}
          sectorRecords={sectorRecords}
          selectedGreenhouse={selectedGreenhouse}
          onSyncSectorsFromSheets={handleSync1to7SectorsFromSheets}
          isSyncingSectors={isSyncingSectors}
        />
      )}

      {/* 2.8 DÜNYA STANDARTLARINDA HASAT TAKVİMİ ANALİZİ (GÜNLÜK HASAT, HASAT GECİKME, ÇALIŞAN KİŞİ SAYISI — KALİTE İZLENEBİLİRLİKTEN) */}
      <WorldStandardHarvestAnalyticsPanel
        mode="BANANA_GREENHOUSE"
        bananaRows={filteredRows}
        muzRecords={muzRecords}
        dailyHarvestRecords={dailyHarvestRecords}
      />

      {/* 3. 11 HAFTALIK HASAT DÖNGÜSÜ — SERA BAZLI VERİMLİLİK ANALİZİ GRAFİĞİ VE ÖNCELİKLİ SERALAR */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        {/* Sol 7 Sütun: Sera Bazlı 11-Haftalık Verimlilik & Tonaj Grafiği */}
        <div className="xl:col-span-7 bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                   11 Haftalık Hasat Döngüsü — Sera Bazlı Verimlilik Analizi Grafiği
                </h3>
                <p className="text-[11px] text-slate-500">
                  Sera bazında Planlanan Tonaj, Kesilen Net Tonaj, Ortalama Dal Ağırlığı (kg/dal) ve 11-Hafta Hasat Verimliliği (%)
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-[11px] tabular-nums">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold">
                Ort. Dal: {greenhousePriorityAnalytics.globalAvgHarvestedBranchKg} kg/dal
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 font-bold">
                Kesilen: {greenhousePriorityAnalytics.totalHarvTon} Ton
              </span>
            </div>
          </div>

          <div className="w-full h-64 min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={greenhousePriorityAnalytics.greenhousesRanked}
                margin={{ top: 8, right: 16, left: 0, bottom: 4 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="greenhouseName" tick={{ fill: '#334155', fontSize: 11, fontWeight: 700 }} />
                <YAxis
                  yAxisId="left"
                  tick={{ fill: '#475569', fontSize: 10 }}
                  unit=" T"
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fill: '#059669', fontSize: 10 }}
                  unit=" kg"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '12px',
                    fontSize: '11px',
                    color: '#0f172a'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <Bar
                  yAxisId="left"
                  dataKey="plannedTon"
                  name="Planlanan Tonaj (Ton)"
                  fill="#fcd34d"
                  radius={[6, 6, 0, 0]}
                />
                <Bar
                  yAxisId="left"
                  dataKey="harvestedTon"
                  name="Kesilen Hasat (Ton)"
                  fill="#10b981"
                  radius={[6, 6, 0, 0]}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="avgHarvestedBranchKg"
                  name="Ort. Dal Ağırlığı (kg/dal)"
                  stroke="#0284c7"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#0284c7' }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sağ 5 Sütun: İnsan Hataları & Hangi Seraya Önem Vermeliyiz Öncelik Kartları */}
        <div className="xl:col-span-5 bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-amber-600" />
                <span>Sera Öncelik Sırası & İnsan Hatası Analizi</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Geç/erken kurdele bağlama günleri ve 11. hafta kesim yoğunluğuna göre
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {greenhousePriorityAnalytics.greenhousesRanked.slice(0, 4).map((gh, idx) => (
              <div
                key={gh.greenhouseName}
                onClick={() =>
                  setSelectedGreenhouse(
                    selectedGreenhouse === gh.greenhouseName ? 'ALL' : gh.greenhouseName
                  )
                }
                className={`p-3 rounded-xl border transition cursor-pointer ${
                  gh.priorityLevel === 'KRİTİK ÖNCELİK'
                    ? 'bg-rose-50/70 border-rose-300 hover:bg-rose-50'
                    : gh.priorityLevel === 'YÜKSEK DİKKAT'
                    ? 'bg-amber-50/70 border-amber-300 hover:bg-amber-50'
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs font-bold text-slate-900">
                    #{idx + 1} {gh.greenhouseName}
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${
                      gh.priorityLevel === 'KRİTİK ÖNCELİK'
                        ? 'bg-rose-100 text-rose-800 border-rose-300'
                        : gh.priorityLevel === 'YÜKSEK DİKKAT'
                        ? 'bg-amber-100 text-amber-900 border-amber-300'
                        : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    }`}
                  >
                    {gh.priorityLevel}
                  </span>
                </div>

                <div className="mt-2 grid grid-cols-2 gap-1.5 text-[10px] tabular-nums">
                  <div className="bg-white p-1.5 rounded-lg border border-slate-200/80">
                    <div className="text-[9px] text-slate-500">Ort. Dal / Verim</div>
                    <div className="font-bold text-emerald-700">
                      {gh.avgHarvestedBranchKg} kg · %{gh.efficiencyPct}
                    </div>
                  </div>
                  <div className="bg-white p-1.5 rounded-lg border border-slate-200/80">
                    <div className="text-[9px] text-slate-500">İnsan Hatası</div>
                    <div
                      className={`font-bold ${
                        gh.totalHumanDelayDays > 0 ? 'text-rose-700' : 'text-slate-700'
                      }`}
                    >
                      {gh.totalHumanDelayDays > 0 ? `+${gh.totalHumanDelayDays} gün` : '0 gün'}
                    </div>
                  </div>
                </div>

                <div className="mt-2 flex items-center justify-between text-[10px] text-slate-600">
                  <span>11. Hf Bekleyen: <strong className="text-amber-800">{gh.ready11thWeekCount}</strong></span>
                  <span>Kalan: <strong className="text-slate-900 tabular-nums">{gh.remainingBunches} dal</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. HARVEST FORECASTING (BEKLENEN VS. GERÇEKLEŞEN HASAT ANALİZİ — RENK SEGMENTLERİ & EKİM-KASIM GÖSTERGELERİ) */}
      {activeSubView === 'HARVEST_CALENDAR_MAIN' && (
        <BananaHarvestForecastingView
          calendarRows={rows}
          selectedGreenhouse={selectedGreenhouse}
          onSelectGreenhouse={setSelectedGreenhouse}
          onUpdateRowCell={updateRowCell}
        />
      )}

      {/* 5. TOPLU İŞLEM (BULK ACTION) ARAYÜZÜ — SEÇİLEN SATIRLARIN RENK VEYA KASA TİPİNİ TEK İŞLEMLE GÜNCELLE */}
      <div className="bg-white border-2 border-amber-300 rounded-2xl p-4 space-y-3 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={toggleSelectAllFiltered}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer shadow-xs"
            >
              {filteredRows.length > 0 && filteredRows.every(r => selectedRowIds.includes(r.id))
                ? '☑ Tüm Seçimi Kaldır'
                : `☐ Tablodaki Tüm Satırları Seç (${filteredRows.length})`}
            </button>

            <div className="text-xs font-bold text-slate-800">
              Toplu İşlem İçin Seçilen Satır:{' '}
              <strong className="text-amber-700 tabular-nums text-sm">
                {selectedRowIds.length}
              </strong>{' '}
              adet
            </div>

            {selectedRowIds.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedRowIds([])}
                className="text-xs font-bold text-rose-600 hover:underline cursor-pointer"
              >
                Seçimi Temizle
              </button>
            )}
          </div>

          {/* TOPLU SEÇİMLİ KASA VE RENK GÜNCELLEME (BULK EDIT) KONTROLLERİ */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-bold text-slate-700 text-[11px]">
              Toplu İşlem Türü:
            </span>
            <select
              value={bulkField}
              onChange={e => {
                const f = e.target.value as any;
                setBulkField(f);
                if (f === 'CRATE') setBulkValue(BANANA_CRATE_OPTIONS[0]);
                else if (f === 'RIBBON_COLOR')
                  setBulkValue(`${BANANA_12_MONTH_RIBBONS[0].monthNameTr} — ${BANANA_12_MONTH_RIBBONS[0].ribbonName}`);
                else if (f === 'MARKET') setBulkValue('EXPORT_PAZAR');
                else if (f === 'STATUS') setBulkValue('11. Hafta — Hasat Dönemine Girdi');
                else if (f === 'HUMAN_DELAY') setBulkValue('0');
              }}
              className="bg-white border-2 border-amber-400 rounded-xl px-3 py-1.5 text-amber-950 font-bold cursor-pointer"
            >
              <option value="CRATE"> Seçilenlerin Kasa Tipini Toplu Güncelle</option>
              <option value="RIBBON_COLOR"> Seçilenlerin Kurdele Rengini Toplu Güncelle</option>
              <option value="MARKET"> Seçilenlerin Pazarını (Export / Yerel) Güncelle</option>
              <option value="STATUS"> Seçilenlerin Hasat Durumunu Güncelle</option>
              <option value="HUMAN_DELAY">⏱ Seçilenlerin İnsan Hatası Gününü (+/-) Güncelle</option>
            </select>

            {bulkField === 'CRATE' && (
              <select
                value={bulkValue}
                onChange={e => setBulkValue(e.target.value)}
                className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-slate-900 font-bold"
              >
                {BANANA_CRATE_OPTIONS.map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            )}

            {bulkField === 'RIBBON_COLOR' && (
              <select
                value={bulkValue}
                onChange={e => setBulkValue(e.target.value)}
                className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-amber-900 font-bold"
              >
                {BANANA_12_MONTH_RIBBONS.map(r => (
                  <option key={r.monthIndex} value={`${r.monthNameTr} — ${r.ribbonName}`}>
                    {r.monthNameTr} — {r.ribbonName}
                  </option>
                ))}
              </select>
            )}

            {bulkField === 'MARKET' && (
              <select
                value={bulkValue}
                onChange={e => setBulkValue(e.target.value)}
                className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-sky-900 font-bold"
              >
                <option value="EXPORT_PAZAR"> İhracat (Export Pazar)</option>
                <option value="YEREL_PAZAR"> Yerel Pazar (İç Piyasa)</option>
              </select>
            )}

            {bulkField === 'STATUS' && (
              <select
                value={bulkValue}
                onChange={e => setBulkValue(e.target.value)}
                className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-emerald-900 font-bold"
              >
                <option value="Kurdele Bağlandı"> Kurdele Bağlandı</option>
                <option value="11. Hafta — Hasat Dönemine Girdi"> 11. Hafta — Hasat Dönemine Girdi</option>
                <option value="Kalibre Testinde (10-15 Gün)"> Kalibre Testinde (10-15 Gün)</option>
                <option value="Hasat-1 (İlk Kesim)"> Hasat-1 (İlk Kesim)</option>
                <option value="Hasat-2 (İkinci Kesim)"> Hasat-2 (İkinci Kesim)</option>
                <option value="Tamamlandı"> Tamamlandı</option>
                <option value="Hasat Yok"> Hasat Yok</option>
              </select>
            )}

            {bulkField === 'HUMAN_DELAY' && (
              <input
                type="number"
                value={bulkValue}
                onChange={e => setBulkValue(e.target.value)}
                placeholder="+/- Gün"
                className="w-24 bg-white border border-rose-300 rounded-xl px-2.5 py-1.5 text-rose-800 tabular-nums font-bold"
              />
            )}

            <button
              type="button"
              onClick={handleApplyBulkEdit}
              className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold cursor-pointer shadow-xs transition"
            >
              ⚡ Seçili ({selectedRowIds.length}) Satıra Tek İşlemle Uygula
            </button>
          </div>
        </div>
      </div>

      {/* 6. ANLAŞILIR GÖRSEL MUZ HASAT TAKVİMİ (GANTT AKIŞI) & MATRİS TABLOSU */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-md overflow-hidden">
        {/* SADELEŞTİRİLMİŞ GÖRSEL TAKVİM ÖZETİ (GANTT TARZI — AZ SAYISAL VERİ, NET HAFTA & KURDELE AKIŞI) */}
        <div className="p-4 bg-emerald-700 hover:bg-emerald-800 text-white border-b border-slate-700">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold mb-1">
                 Sadeleştirilmiş Görsel Muz Hasat Takvimi · Gantt Akışı
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                Sera Bazlı Kurdele & Hasat Haftası Akışı (Önemli Göstergeler — Az Sayısal Karmaşa)
              </h3>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Her seranın aktif kurdele rengi, Ekim–Kasım sezon işareti, en çok kaçıncı haftada yoğunlaştığı (11. Hafta vs &gt;11. Hafta) ve kesim ilerlemesi
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-[11px]">
              <span className="px-2.5 py-1 rounded-lg bg-sky-500/20 border border-sky-400/40 text-sky-200 font-bold">
                ⏳ &le;10. Hafta: Gelişim
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 font-bold">
                 11. Hafta: İdeal Kesim
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-rose-500/20 border border-rose-400/40 text-rose-200 font-bold">
                 &gt;11. Hafta (12–15+ Hf): Gecikmiş
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2.5 mt-3.5">
            {BANANA_GREENHOUSE_LIST.map(ghName => {
              const ghRows = filteredRows.filter(
                r => normalizeBananaGreenhouseName(r.greenhouseName) === ghName
              );
              if (ghRows.length === 0) return null;

              const enrichedGh = ghRows.map(r => {
                const m = analyzeBananaRibbonMaturation(r);
                const wk = Math.max(1, Math.round(m.effectiveDaysWithHumanDelay / 7));
                const isOctNov =
                  /ekim|kasım|kasim|oct|nov|\b10\b|\b11\b/i.test(r.ribbonColor || '') ||
                  /-(10|11)-/.test(r.taggingDate || '');
                return { r, m, wk, isOctNov };
              });

              const over11 = enrichedGh.filter(x => x.wk > 11);
              const ideal11 = enrichedGh.filter(x => x.wk === 11);
              const octNovItems = enrichedGh.filter(x => x.isOctNov);

              const wkCounts: Record<number, number> = {};
              enrichedGh.forEach(x => {
                wkCounts[x.wk] = (wkCounts[x.wk] || 0) + 1;
              });
              const peakWkEntry = Object.entries(wkCounts).sort((a, b) => b[1] - a[1])[0];
              const peakWk = peakWkEntry ? Number(peakWkEntry[0]) : 11;

              const totalPlan = ghRows.reduce((s, r) => s + (r.plannedTonnageKg || 0), 0);
              const totalReal = ghRows.reduce((s, r) => s + (r.harvestedNetKg || 0), 0);
              const progPct = totalPlan > 0 ? Math.min(100, Math.round((totalReal / totalPlan) * 100)) : 0;
              const ganttBarPct = Math.min(100, Math.max(12, Math.round((peakWk / 15) * 100)));

              return (
                <div
                  key={`visual-gh-card-${ghName}`}
                  onClick={() =>
                    setSelectedGreenhouse(selectedGreenhouse === ghName ? 'ALL' : ghName)
                  }
                  className={`p-3 rounded-xl border transition cursor-pointer ${
                    selectedGreenhouse === ghName
                      ? 'bg-amber-500/20 border-amber-400 ring-1 ring-amber-300'
                      : 'bg-slate-800/90 border-slate-700 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-xs text-white">{ghName}</span>
                    <div className="flex items-center gap-1">
                      {octNovItems.length > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[9px] font-bold">
                          🍂 Ekim–Kasım ({octNovItems.length})
                        </span>
                      )}
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          over11.length > 0
                            ? 'bg-rose-500/30 text-rose-200 border border-rose-400/40'
                            : ideal11.length > 0
                            ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/40'
                            : 'bg-sky-500/30 text-sky-200 border border-sky-400/40'
                        }`}
                      >
                        Peak: {peakWk}. Hafta
                      </span>
                    </div>
                  </div>

                  <div className="mt-2 space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-300">
                      <span>
                        11. Hf: <strong className="text-emerald-300">{ideal11.length}</strong> · &gt;11. Hf:{' '}
                        <strong className="text-rose-300">{over11.length}</strong>
                      </span>
                      <span className="tabular-nums text-emerald-300 font-bold">
                        Kesim: %{progPct}
                      </span>
                    </div>
                    <div className="relative w-full h-3 rounded-full bg-slate-50 overflow-hidden border border-slate-200">
                      <div
                        className="absolute top-0 bottom-0 w-0.5 bg-amber-300 z-10"
                        style={{ left: '73%' }}
                        title="11. Hafta İdeal Kesim Sınırı"
                      />
                      <div
                        className={`h-full rounded-full ${
                          over11.length > 0
                            ? 'bg-emerald-700 hover:bg-emerald-100'
                            : 'bg-emerald-700 hover:bg-emerald-100'
                        }`}
                        style={{ width: `${ganttBarPct}%` }}
                      />
                    </div>
                  </div>

                  <div className="mt-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 flex-wrap">
                      {enrichedGh.slice(0, 7).map(({ r, wk }) => (
                        <span
                          key={`dot-${r.id}`}
                          className="w-3 h-3 rounded-full border border-white/70 shadow-2xs"
                          style={{ backgroundColor: r.ribbonHex }}
                          title={`${r.ribbonColor} (${wk}. Hafta)`}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] text-slate-300 tabular-nums">
                      {ghRows.length} kurdele
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="overflow-x-auto max-h-[520px]">
          <table className="w-full text-left text-[11px] border-collapse">
            <thead className="bg-slate-100 text-slate-800 sticky top-0 z-20 border-b border-slate-300">
              <tr>
                <th className="p-2.5 border-r border-slate-200 text-center w-10">
                  <input
                    type="checkbox"
                    checked={
                      filteredRows.length > 0 &&
                      filteredRows.every(r => selectedRowIds.includes(r.id))
                    }
                    onChange={toggleSelectAllFiltered}
                    className="accent-amber-600 cursor-pointer w-3.5 h-3.5"
                  />
                </th>
                <th className="p-2.5 border-r border-slate-200 bg-amber-50/90 font-bold text-amber-950">
                  <div>Net Bağlama Tarihi</div>
                  <div className="text-[9px] text-amber-800 font-semibold">Tarih Sıralı (Kronolojik)</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 font-bold">
                  <div>Sera (Kanonik) & Sekme</div>
                  <div className="text-[9px] text-slate-500 font-normal">GB-7-8, Maksat 9-10 vb.</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 bg-amber-50/80 font-bold text-amber-950">
                  <div>Kurdele Rengi (Güncelle)</div>
                  <div className="text-[9px] text-amber-700 font-semibold">G.Sheet Toplam Rengi</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 bg-emerald-50/60 font-bold text-emerald-950">
                  <div>Tahmini Hasat Tarihi</div>
                  <div className="text-[9px] text-emerald-700 font-semibold">11. Hafta Kesim Hedefi</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 bg-emerald-50/70">
                  <div className="text-emerald-950 font-bold">11. Hafta & Gantt İlerleme</div>
                  <div className="text-[9px] text-emerald-700 font-semibold">Kaç Günlük / Mevsim Etkisi</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 bg-rose-50/70">
                  <div className="text-rose-950 font-bold">İnsan Hatası (Gün)</div>
                  <div className="text-[9px] text-rose-700 font-semibold">Geç/Erken Kurdele Bağlama</div>
                </th>
                <th className="p-2.5 text-right border-r border-slate-200 font-bold">Bağlanan Dal</th>
                <th className="p-2.5 text-right border-r border-slate-200 bg-emerald-50/80">
                  <div className="text-emerald-950 font-bold">Kesilen Dal & Net Kg</div>
                  <div className="text-[9px] text-emerald-700 font-semibold">Canlı Kantar Verisi</div>
                </th>
                <th className="p-2.5 text-right border-r border-slate-200 font-bold">
                  <div>Ort. Hasat Dal</div>
                  <div className="text-[9px] text-slate-500 font-normal">
                    Genel Ort: {greenhousePriorityAnalytics.globalAvgHarvestedBranchKg} kg
                  </div>
                </th>
                <th className="p-2.5 text-right border-r border-slate-200 bg-amber-50/60">
                  <div className="text-amber-950 font-bold">Kalan Dal</div>
                  <div className="text-[9px] text-amber-700 font-semibold">Serada Bekleyen</div>
                </th>
                <th className="p-2.5 border-r border-slate-200 font-bold">Hasat Statüsü</th>
                <th className="p-2.5 border-r border-slate-200 bg-rose-50/80">
                  <div className="text-rose-950 font-bold">Gecikmiş & Takvim Durumu</div>
                  <div className="text-[9px] text-rose-700 font-semibold">Gecikme / 11. Hf / Erken</div>
                </th>
                <th className="p-2.5 text-center font-bold">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRows.map(row => {
                const mat = analyzeBananaRibbonMaturation(row);
                const ganttPct = Math.min(100, Math.max(8, Math.round((mat.effectiveDaysWithHumanDelay / 98) * 100)));
                return (
                  <tr
                    key={row.id}
                    className={`hover:bg-amber-50/50 transition ${
                      selectedRowIds.includes(row.id) ? 'bg-amber-100/60' : 'bg-white'
                    }`}
                  >
                    <td className="p-2 border-r border-slate-200 text-center">
                      <input
                        type="checkbox"
                        checked={selectedRowIds.includes(row.id)}
                        onChange={() => toggleSelectRow(row.id)}
                        className="accent-amber-600 cursor-pointer w-3.5 h-3.5"
                      />
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-[11px] bg-amber-50/30">
                      <div className="font-bold text-slate-900">{row.taggingDate}</div>
                      <div className="text-[9px] text-slate-500 font-sans truncate max-w-[140px]">
                        {row.notes || row.cycleYear}
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200">
                      <div className="font-bold text-slate-900">
                        {normalizeBananaGreenhouseName(row.greenhouseName)}
                      </div>
                      <div className="text-[10px] text-amber-800 font-bold">
                        {row.sectorCode}
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200 bg-amber-50/30">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-4 h-4 rounded-full shrink-0 border border-slate-400 shadow-xs"
                          style={{ backgroundColor: row.ribbonHex }}
                        />
                        <select
                          value={row.ribbonColor}
                          onChange={e => updateRowCell(row.id, 'ribbonColor', e.target.value)}
                          className="bg-white border border-amber-300 rounded-lg px-2 py-1 text-[10px] font-bold text-slate-900 w-40"
                        >
                          {!BANANA_12_MONTH_RIBBONS.some(
                            r => `${r.monthNameTr} — ${r.ribbonName}` === row.ribbonColor
                          ) && <option value={row.ribbonColor}>{row.ribbonColor}</option>}
                          {BANANA_12_MONTH_RIBBONS.map(r => {
                            const label = `${r.monthNameTr} — ${r.ribbonName}`;
                            return (
                              <option key={r.monthIndex} value={label}>
                                {label}
                              </option>
                            );
                          })}
                        </select>
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-[11px] bg-emerald-50/20">
                      <div className="text-emerald-900 font-bold">{row.expectedHarvestDate}</div>
                      <div className="text-[9px] text-slate-500">
                        Test: {row.expectedTestDate || '—'}
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200">
                      <div className="font-bold text-emerald-900 text-[10px]">{mat.timingLabel}</div>
                      <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden my-1">
                        <div
                          className={`h-full rounded-full ${
                            mat.isLateOverripe
                              ? 'bg-rose-500'
                              : mat.isIn11thWeekWindow
                              ? 'bg-emerald-500'
                              : 'bg-amber-500'
                          }`}
                          style={{ width: `${ganttPct}%` }}
                        />
                      </div>
                      <div className="text-[9px] text-slate-500">{mat.seasonType}</div>
                    </td>
                    <td className="p-2 border-r border-slate-200 bg-rose-50/20">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          value={row.manualHumanDelayDays}
                          onChange={e =>
                            updateRowCell(row.id, 'manualHumanDelayDays', Number(e.target.value))
                          }
                          className={`w-14 bg-white border rounded-lg px-1.5 py-0.5 tabular-nums font-bold text-center ${
                            row.manualHumanDelayDays !== 0
                              ? 'border-rose-400 text-rose-800 bg-rose-50'
                              : 'border-slate-300 text-slate-700'
                          }`}
                        />
                        <span className="text-[10px] text-slate-500">gün</span>
                      </div>
                      <div
                        className={`text-[9px] mt-0.5 ${
                          row.manualHumanDelayDays !== 0 ? 'text-rose-700 font-bold' : 'text-slate-500'
                        }`}
                      >
                        {row.humanErrorType}
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-right">
                      <input
                        type="number"
                        value={row.boundBunchCount}
                        onChange={e =>
                          updateRowCell(row.id, 'boundBunchCount', Number(e.target.value))
                        }
                        className="w-16 bg-slate-50 border border-slate-200 rounded px-1 text-right font-bold text-slate-900 outline-none"
                      />
                      <div className="text-[9px] text-slate-500 mt-0.5">
                        Plan: {(row.plannedTonnageKg / 1000).toFixed(1)}T
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-right bg-emerald-50/30">
                      <div className="flex items-center justify-end gap-1">
                        <input
                          type="number"
                          value={row.harvestedBunchCount}
                          onChange={e =>
                            updateRowCell(row.id, 'harvestedBunchCount', Number(e.target.value))
                          }
                          className="w-14 bg-white border border-emerald-200 rounded px-1 text-right font-bold text-emerald-900 outline-none"
                        />
                        <span className="text-[9px] text-slate-500">dal</span>
                      </div>
                      <div className="flex items-center justify-end gap-1 mt-1">
                        <input
                          type="number"
                          value={row.harvestedNetKg}
                          onChange={e =>
                            updateRowCell(row.id, 'harvestedNetKg', Number(e.target.value))
                          }
                          className="w-20 bg-white border border-emerald-200 rounded px-1 text-right font-bold text-emerald-700 outline-none"
                        />
                        <span className="text-[9px] text-emerald-700">kg</span>
                      </div>
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-right">
                      {row.actualAvgBranchKg > 0 ? (
                        <div>
                          <span
                            className={`font-bold ${
                              row.actualAvgBranchKg >=
                              greenhousePriorityAnalytics.globalAvgHarvestedBranchKg
                                ? 'text-emerald-700'
                                : 'text-amber-700'
                            }`}
                          >
                            {row.actualAvgBranchKg} kg
                          </span>
                          <div className="text-[9px] text-slate-500">
                            Hedef: {row.standardBranchKg} kg
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="p-2 border-r border-slate-200 tabular-nums text-right font-bold text-amber-900 bg-amber-50/40">
                      {row.remainingBunchCount.toLocaleString('tr-TR')} dal
                    </td>
                    <td className="p-2 border-r border-slate-200">
                      <select
                        value={row.status}
                        onChange={e => updateRowCell(row.id, 'status', e.target.value)}
                        className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-[10px] font-bold text-slate-900"
                      >
                        <option value="Kurdele Bağlandı"> Kurdele Bağlandı</option>
                        <option value="11. Hafta — Hasat Dönemine Girdi"> 11. Hafta — Hasat Dönemine Girdi</option>
                        <option value="Kalibre Testinde (10-15 Gün)"> Kalibre Testinde (10-15 Gün)</option>
                        <option value="Hasat-1 (İlk Kesim)"> Hasat-1 (İlk Kesim)</option>
                        <option value="Hasat-2 (İkinci Kesim)"> Hasat-2 (İkinci Kesim)</option>
                        <option value="Tamamlandı"> Tamamlandı</option>
                        <option value="Hasat Yok"> Hasat Yok</option>
                      </select>
                    </td>
                    <td className="p-2 border-r border-slate-200">
                      {mat.isLateOverripe || row.manualHumanDelayDays > 0 ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold bg-rose-100 text-rose-900 border border-rose-300">
                          🚨 Gecikmiş ({row.manualHumanDelayDays > 0 ? `+${row.manualHumanDelayDays}G Hatası` : `${mat.weeks} Hf`})
                        </span>
                      ) : mat.isEarlyHarvest || row.manualHumanDelayDays < 0 ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          ⚡ Erken Durum ({mat.weeks} Hf)
                        </span>
                      ) : mat.isIn11thWeekWindow ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                          🟢 11. Hafta Kesimde ({mat.weeks} Hf)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-300">
                          ✅ Normal ({mat.weeks} Hf)
                        </span>
                      )}
                    </td>
                    <td className="p-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleSelectExistingRibbonToEdit(row.id)}
                          className="p-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 cursor-pointer"
                          title="Mevcut Kurdele Bağlama Kaydını Düzenle"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(row.id)}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                          title="Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* TAKVİM SONU DURUM ÖZETİ — 11 HAFTAYI GEÇEN (>11. HAFTA) ANALİZİ & EN ÇOK KAÇINCI HAFTADA HANGİ SERA HASADI DENK GELİYOR */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 space-y-4">
          {(() => {
            const enrichedAll = filteredRows.map(r => {
              const m = analyzeBananaRibbonMaturation(r);
              const wk = Math.max(1, Math.round(m.effectiveDaysWithHumanDelay / 7));
              const gh = normalizeBananaGreenhouseName(r.greenhouseName);
              return { r, m, wk, gh };
            });

            const over11Rows = enrichedAll.filter(x => x.wk > 11 || x.m.isLateOverripe);
            const week11Rows = enrichedAll.filter(x => x.wk === 11);

            const weekMap: Record<number, { count: number; byGh: Record<string, number> }> = {};
            const over11WeekMap: Record<number, { count: number; byGh: Record<string, number> }> = {};

            enrichedAll.forEach(item => {
              if (!weekMap[item.wk]) weekMap[item.wk] = { count: 0, byGh: {} };
              weekMap[item.wk].count += 1;
              weekMap[item.wk].byGh[item.gh] = (weekMap[item.wk].byGh[item.gh] || 0) + 1;

              if (item.wk > 11) {
                if (!over11WeekMap[item.wk]) over11WeekMap[item.wk] = { count: 0, byGh: {} };
                over11WeekMap[item.wk].count += 1;
                over11WeekMap[item.wk].byGh[item.gh] = (over11WeekMap[item.wk].byGh[item.gh] || 0) + 1;
              }
            });

            const sortedAllWeeks = Object.entries(weekMap).sort((a, b) => b[1].count - a[1].count);
            const sortedOver11Weeks = Object.entries(over11WeekMap).sort((a, b) => b[1].count - a[1].count);

            const peakOverallWk = sortedAllWeeks[0];
            const peakOverallGh = peakOverallWk
              ? Object.entries(peakOverallWk[1].byGh).sort((a, b) => b[1] - a[1])[0]
              : null;

            const peakOver11Wk = sortedOver11Weeks[0];
            const peakOver11Gh = peakOver11Wk
              ? Object.entries(peakOver11Wk[1].byGh).sort((a, b) => b[1] - a[1])[0]
              : null;

            return (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-rose-900 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      Takvim Sonu Durum Özeti — 11 Haftayı Geçen (&gt;11. Hafta) Analizi &amp; Sera × Hafta Yoğunluk Matrisi
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Uzun liste yerine en çok kaçıncı haftada hangi sera hasadının denk geldiğini gösteren özet tablo
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] tabular-nums font-bold">
                    <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-900 border border-rose-300">
                      &gt;11. Hafta Geç: {over11Rows.length} Grup (Peak:{' '}
                      {peakOver11Wk ? `${peakOver11Wk[0]}. Hf · ${peakOver11Gh?.[0] || ''}` : 'Yok'})
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300">
                      11. Hafta İdeal: {week11Rows.length} Grup
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-950 border border-amber-300">
                      Genel Yoğunluk: {peakOverallWk ? `${peakOverallWk[0]}. Hafta (${peakOverallGh?.[0] || ''})` : '11. Hafta'}
                    </span>
                  </div>
                </div>

                {/* KOMPAKT SERA × HAFTA YOĞUNLUK MATRİSİ (7 SERA SATIRI — UZUN KART LİSTESİ YERİNE) */}
                <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto shadow-2xs">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 border-b border-slate-200 text-[11px]">
                        <th className="py-2 px-3 font-bold">Sera Adı</th>
                        <th className="py-2 px-3 font-bold text-center">&le;10. Hafta (Erken/Gelişim)</th>
                        <th className="py-2 px-3 font-bold text-center bg-emerald-50 text-emerald-900">
                          11. Hafta (İdeal Kesim)
                        </th>
                        <th className="py-2 px-3 font-bold text-center bg-amber-50 text-amber-900">
                          12. Hafta (+1 Hf Geç)
                        </th>
                        <th className="py-2 px-3 font-bold text-center bg-orange-50 text-orange-900">
                          13. Hafta (+2 Hf Geç)
                        </th>
                        <th className="py-2 px-3 font-bold text-center bg-rose-50 text-rose-900">
                          14+ Hafta (Kritik Geç)
                        </th>
                        <th className="py-2 px-3 font-bold">En Çok Denk Gelen Hafta (Peak) &amp; Kalan Dal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {BANANA_GREENHOUSE_LIST.map(ghName => {
                        const ghItems = enrichedAll.filter(x => x.gh === ghName);
                        if (ghItems.length === 0) return null;

                        const w10 = ghItems.filter(x => x.wk <= 10);
                        const w11 = ghItems.filter(x => x.wk === 11);
                        const w12 = ghItems.filter(x => x.wk === 12);
                        const w13 = ghItems.filter(x => x.wk === 13);
                        const w14Plus = ghItems.filter(x => x.wk >= 14);
                        const over11All = ghItems.filter(x => x.wk > 11);

                        const ghWkMap: Record<number, number> = {};
                        ghItems.forEach(x => {
                          ghWkMap[x.wk] = (ghWkMap[x.wk] || 0) + 1;
                        });
                        const topWk = Object.entries(ghWkMap).sort((a, b) => b[1] - a[1])[0];
                        const remBunches = ghItems.reduce((s, x) => s + (x.r.remainingBunchCount || 0), 0);

                        return (
                          <tr
                            key={`matrix-end-${ghName}`}
                            onClick={() =>
                              setSelectedGreenhouse(selectedGreenhouse === ghName ? 'ALL' : ghName)
                            }
                            className="hover:bg-amber-50/50 cursor-pointer transition"
                          >
                            <td className="py-2 px-3 font-bold text-slate-900">
                              {ghName}{' '}
                              {over11All.length > 0 && (
                                <span className="ml-1 px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 text-[10px] tabular-nums">
                                  &gt;11Hf: {over11All.length}
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-center tabular-nums text-slate-600">
                              {w10.length > 0 ? `${w10.length} grup` : '—'}
                            </td>
                            <td className="py-2 px-3 text-center tabular-nums font-bold text-emerald-800 bg-emerald-50/30">
                              {w11.length > 0 ? `${w11.length} grup` : '—'}
                            </td>
                            <td className="py-2 px-3 text-center tabular-nums font-bold text-amber-900 bg-amber-50/30">
                              {w12.length > 0 ? `${w12.length} grup` : '—'}
                            </td>
                            <td className="py-2 px-3 text-center tabular-nums font-bold text-orange-900 bg-orange-50/30">
                              {w13.length > 0 ? `${w13.length} grup` : '—'}
                            </td>
                            <td className="py-2 px-3 text-center tabular-nums font-bold text-rose-900 bg-rose-50/30">
                              {w14Plus.length > 0 ? `${w14Plus.length} grup` : '—'}
                            </td>
                            <td className="py-2 px-3">
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-bold text-slate-900">
                                  {topWk ? `${topWk[0]}. Hafta (${topWk[1]} kurdele)` : '—'}
                                </span>
                                <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 tabular-nums text-[10px] font-bold">
                                  Kalan: {remBunches.toLocaleString('tr-TR')} dal
                                </span>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* SADECE EN KRİTİK 6 GECİKMİŞ (>11. HAFTA) KURDELE ÖZETİ (UZUN LİSTE YERİNE KOMPAKT KARTLAR) */}
                {over11Rows.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                    {over11Rows
                      .sort((a, b) => b.wk - a.wk)
                      .slice(0, 6)
                      .map(({ r, m, wk }) => (
                        <div
                          key={`top-over11-${r.id}`}
                          className="p-2.5 rounded-xl border bg-rose-50/80 border-rose-200 text-rose-950 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate">
                              {normalizeBananaGreenhouseName(r.greenhouseName)} —{' '}
                              <span className="text-amber-800">{r.ribbonColor}</span>
                            </div>
                            <div className="text-[10px] text-slate-700 mt-0.5">
                              <strong>{wk}. Hafta</strong> (+{wk - 11} Hf Geç) · {m.seasonType}
                            </div>
                          </div>
                          <span className="px-2 py-1 rounded-lg bg-white border border-rose-200 text-rose-800 tabular-nums text-[10px] font-bold shrink-0">
                            {r.remainingBunchCount} dal
                          </span>
                        </div>
                      ))}
                  </div>
                )}
              </>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
