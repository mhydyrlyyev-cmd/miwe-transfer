import React from 'react';
import { MuzRecord, HarvestRecord } from '../../types';
import { BananaRibbonCalendarHub } from './BananaRibbonCalendarHub';

export interface MuzKurdeleViewProps {
  muzRecords?: MuzRecord[];
  dailyHarvestRecords?: HarvestRecord[];
}

/**
 * Dedicated MuzKurdeleView component for the Muz module & Harvest Planning Portal.
 * Displays the 11-week ribbon color cycle visual tracker, associated greenhouse/sector numbers,
 * daily harvest totals, bulk Kasa/Renk/Pazar status updater, and end-of-calendar delay status summary.
 */
export const MuzKurdeleView: React.FC<MuzKurdeleViewProps> = ({
  muzRecords = [],
  dailyHarvestRecords = []
}) => {
  return (
    <BananaRibbonCalendarHub
      muzRecords={muzRecords}
      dailyHarvestRecords={dailyHarvestRecords}
    />
  );
};
