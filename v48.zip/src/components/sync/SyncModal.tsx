import React, { useEffect } from 'react';
import { X, RefreshCw, Wifi, WifiOff, Database } from 'lucide-react';
import { PendingSyncCard } from '../dashboard/PendingSyncCard';

interface SyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  offlineQueue: Array<{ action: string; payload: any; timestamp?: string }>;
  isOnline: boolean;
  isSyncing: boolean;
  onSyncAll: () => void;
  onSyncSingle: (index: number) => void;
  onDeleteItem: (index: number) => void;
  onEditItem?: (item: any) => void;
  onPullFromSheets?: () => void;
}

export const SyncModal: React.FC<SyncModalProps> = ({
  isOpen,
  onClose,
  offlineQueue,
  isOnline,
  isSyncing,
  onSyncAll,
  onSyncSingle,
  onDeleteItem,
  onEditItem,
  onPullFromSheets
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Senkronizasyon Durumu"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-5 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div 
        className="fixed inset-0" 
        onClick={onClose} 
        aria-hidden="true" 
      />

      <div className="relative w-full max-w-4xl max-h-[92dvh] sm:max-h-[90dvh] bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-t-2xl sm:rounded-2xl shadow-2xl border border-slate-300 dark:border-slate-800 flex flex-col overflow-hidden z-10">
        
        {/* Modal Header */}
        <div className="px-4 sm:px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`p-2 rounded-xl border shrink-0 ${
              isOnline 
                ? 'bg-emerald-950 border-emerald-600 text-emerald-400' 
                : 'bg-amber-950 border-amber-600 text-amber-400'
            }`}>
              {isOnline ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-white truncate">
                  Senkronizasyon & Çevrimdışı
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-xs tabular-nums font-bold ${
                  isOnline 
                    ? 'bg-emerald-900/80 text-emerald-300 border border-emerald-600' 
                    : 'bg-amber-900/80 text-amber-300 border border-amber-500 animate-pulse'
                }`}>
                  {isOnline ? 'Online' : 'Offline'}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate hidden sm:block">
                Yerel depolama ve Google Sheets bulut veri tabanı eşitleme paneli
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onPullFromSheets && isOnline && (
              <button
                type="button"
                onClick={onPullFromSheets}
                disabled={isSyncing}
                title="Google Sheets'ten Güncel Verileri Çek"
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-800/80 hover:bg-teal-700 text-white text-xs font-bold border border-teal-600 transition active:scale-95 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>Buluttan Çek</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          <PendingSyncCard
            offlineQueue={offlineQueue}
            isOnline={isOnline}
            isSyncing={isSyncing}
            onSyncAll={onSyncAll}
            onSyncSingle={onSyncSingle}
            onDeleteItem={onDeleteItem}
            onEditItem={onEditItem}
          />
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 shrink-0">
          <div className="flex items-center gap-1.5 tabular-nums text-xs">
            <Database className="w-4 h-4 text-slate-400" />
            <span>Kuyrukta: <strong className="text-slate-900 dark:text-slate-100 font-bold">{offlineQueue.length}</strong> kayıt bekliyor</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-bold transition min-h-[44px] cursor-pointer"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
