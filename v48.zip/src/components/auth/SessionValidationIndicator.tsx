import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Key,
  Database,
  RefreshCw,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  User,
  Eye,
  EyeOff
} from 'lucide-react';
import { SessionAuditResult } from '../../utils/authService';

interface SessionValidationIndicatorProps {
  audit: SessionAuditResult | null;
  onRevalidate: () => void;
  className?: string;
}

export const SessionValidationIndicator: React.FC<SessionValidationIndicatorProps> = ({
  audit,
  onRevalidate,
  className = ''
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(() => {
    // If there is an error on startup, auto-expand so user/tester immediately notices
    if (typeof window !== 'undefined') {
      const saved = sessionStorage.getItem('miwe_session_card_expanded');
      if (saved !== null) return saved === 'true';
    }
    return audit?.status === 'ERROR';
  });

  const [showFullToken, setShowFullToken] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  if (!audit) return null;

  const toggleExpanded = () => {
    setIsExpanded(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('miwe_session_card_expanded', String(next));
      }
      return next;
    });
  };

  const handleCopySummary = async () => {
    const summary = {
      denetimZamani: audit.checkedAt,
      durum: audit.status,
      mesaj: audit.statusMessage,
      localStorage: {
        miwe_admin_auth: audit.adminAuthRaw,
        miwe_session_token: audit.sessionTokenRaw ? '(gizli)' : null,
        tokenUzunluk: audit.tokenLength,
        tokenGecerli: audit.isTokenValid
      },
      kullanici: audit.user ? {
        id: audit.user.id,
        adSoyad: audit.user.fullName,
        rol: audit.user.role,
        durum: audit.user.status,
        email: audit.user.email
      } : null
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(summary, null, 2));
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleTriggerRevalidate = () => {
    setIsRevalidating(true);
    onRevalidate();
    setTimeout(() => setIsRevalidating(false), 450);
  };

  // v4.4: oturum anahtarı ekranda hiçbir zaman gösterilmez (yalnız var/yok ve uzunluk)
  const tokenDisplay = audit.sessionTokenRaw ? `•••••••• (${audit.tokenLength} bayt)` : '(Bulunamadı - Yok)';

  // Visual status styles
  const isOk = audit.status === 'VALID';
  const isErr = audit.status === 'ERROR';

  const badgeBg = isOk
    ? 'bg-emerald-500/10 text-emerald-700 border-emerald-300'
    : isErr
    ? 'bg-rose-500/10 text-rose-700 border-rose-300 animate-pulse'
    : 'bg-amber-500/10 text-amber-700 border-amber-300';

  const cardBorder = isOk
    ? 'border-emerald-200 bg-white'
    : isErr
    ? 'border-rose-300 bg-rose-50/40'
    : 'border-amber-200 bg-amber-50/40';

  return (
    <aside aria-label="Oturum Doğrulama ve LocalStorage Denetimi" className={`w-full transition-all duration-200 ${className}`}>
      {/* 1. COMPACT BAR / INDICATOR */}
      <div
        className={`flex flex-wrap items-center justify-between gap-2.5 px-3.5 py-2 rounded-xl border text-xs shadow-xs transition-colors ${
          isOk
            ? 'bg-emerald-50/90 border-emerald-200 text-emerald-950'
            : isErr
            ? 'bg-rose-50 border-rose-200 text-rose-950'
            : 'bg-amber-50 border-amber-200 text-amber-950'
        }`}
      >
        <div className="flex items-center gap-2.5 flex-wrap min-w-0">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-bold text-[11px] ${badgeBg}`}>
            {isOk ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            ) : isErr ? (
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            )}
            <span>
              {isOk
                ? 'OTURUM DOĞRULANDI'
                : isErr
                ? 'OTURUM / TOKEN HATASI'
                : 'OTURUM UYARISI'}
            </span>
          </span>

          <div className="flex items-center gap-2 tabular-nums text-[11px] text-slate-700 flex-wrap">
            <span className="flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded border border-slate-200">
              <span className="text-slate-500 font-sans">admin_auth:</span>
              <strong className={audit.adminAuthRaw === 'true' ? 'text-emerald-700' : 'text-slate-500'}>
                "{audit.adminAuthRaw ?? 'null'}"
              </strong>
            </span>

            <span className="flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded border border-slate-200">
              <span className="text-slate-500 font-sans">token:</span>
              {audit.isTokenValid ? (
                <strong className="text-emerald-700">
                  {audit.sessionTokenRaw ? `var (${audit.tokenLength} bayt)` : 'yok'}
                </strong>
              ) : (
                <strong className="text-rose-600">
                  {audit.sessionTokenRaw ? 'GEÇERSİZ' : 'YOK'}
                </strong>
              )}
            </span>

            {audit.user && (
              <span className="hidden md:inline-flex items-center gap-1 text-slate-600 font-sans text-[11px]">
                <User className="w-3 h-3 text-slate-400" />
                <span>{audit.user.fullName}</span>
                <span className="tabular-nums text-[10px] px-1 py-0.2 rounded bg-slate-200 text-slate-700 font-bold">
                  {audit.user.role}
                </span>
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5 ml-auto shrink-0">
          <button
            type="button"
            onClick={handleTriggerRevalidate}
            disabled={isRevalidating}
            title="localStorage verilerini yeniden oku ve doğrula (F5 Simülasyonu)"
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold transition cursor-pointer shadow-2xs active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 text-emerald-600 ${isRevalidating ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Yeniden Doğrula</span>
          </button>

          <button
            type="button"
            onClick={toggleExpanded}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold transition cursor-pointer shadow-2xs"
            title={isExpanded ? 'Detay kartını daralt' : 'Doğrulama kartını genişlet'}
          >
            <span className="font-sans">{isExpanded ? 'Gizle' : 'Doğrulama Kartı'}</span>
            {isExpanded ? (
              <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            )}
          </button>
        </div>
      </div>

      {/* 2. EXPANDED VERIFICATION CARD */}
      {isExpanded && (
        <div className={`mt-2 rounded-2xl border p-4 sm:p-5 shadow-xs transition-all ${cardBorder}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3">
            <div className="flex items-center gap-2.5">
              <div className={`p-2 rounded-xl ${isOk ? 'bg-emerald-100 text-emerald-700' : isErr ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'}`}>
                <Database className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>LocalStorage Oturum &amp; Yetki Doğrulama Masası</span>
                  <span className={`text-[10px] tabular-nums px-2 py-0.5 rounded-full font-bold ${badgeBg}`}>
                    {audit.status}
                  </span>
                </h4>
                <p className="text-xs text-slate-500">
                  F5 yenilemesi ve tarayıcı başlatma esnasında yerel oturum anahtarlarının anlık denetim sonucu
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-[11px] tabular-nums text-slate-400">
                Son Kontrol: {audit.checkedAt}
              </span>
              <button
                type="button"
                onClick={handleCopySummary}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition cursor-pointer"
                title="Tüm doğrulama özetini panoya kopyala"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700 font-bold">Kopyalandı!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>Özeti Kopyala</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* STATUS MESSAGE BANNER */}
          <div className={`my-3.5 p-3 rounded-xl border text-xs font-medium flex items-start gap-2.5 ${
            isOk
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : isErr
              ? 'bg-rose-100/90 border-rose-300 text-rose-950 font-semibold'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            {isOk ? (
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              <span>{audit.statusMessage}</span>
            </div>
          </div>

          {/* DATA METRICS GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* 1. miwe_admin_auth */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-600 text-[11px] tabular-nums">miwe_admin_auth</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                  audit.adminAuthRaw === 'true'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-600'
                }`}>
                  {audit.adminAuthRaw === 'true' ? 'YETKİLİ' : 'PASİF'}
                </span>
              </div>
              <div className="tabular-nums text-sm font-bold text-slate-900 truncate">
                "{audit.adminAuthRaw ?? 'null'}"
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                {audit.adminAuthRaw === 'true'
                  ? 'F5 sonrasında Admin yetkisi korunuyor.'
                  : 'Admin yetki bayrağı aktif değil.'}
              </p>
            </div>

            {/* 2. miwe_session_token */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-600 text-[11px] tabular-nums">miwe_session_token</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                  audit.isTokenValid
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-rose-100 text-rose-800'
                }`}>
                  {audit.isTokenValid ? `${audit.tokenLength}b GEÇERLİ` : 'EKSİK/BOZUK'}
                </span>
              </div>
              <div className="tabular-nums text-xs text-slate-900 flex items-center justify-between gap-1 break-all bg-white p-1 rounded border border-slate-200">
                <span className="truncate">
                  {tokenDisplay}
                </span>

              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Express API yetkisi: {audit.isTokenValid ? '30 Günlük Oturum Aktif' : 'Token bulunamadı, 401 riski!'}
              </p>
            </div>

            {/* 3. miwe_current_user */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-600 text-[11px] tabular-nums">miwe_current_user</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                  audit.user?.status === 'APPROVED'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {audit.user?.status || 'YOK'}
                </span>
              </div>
              <div className="font-semibold text-xs text-slate-900 truncate">
                {audit.user?.fullName || 'Oturum Açılmamış'}
              </div>
              <div className="flex items-center gap-1.5 tabular-nums text-[11px] text-slate-600">
                <span>Rol:</span>
                <strong className="text-slate-900 font-bold">{audit.user?.role || '-'}</strong>
                {audit.user?.jobTitle && (
                  <span className="text-[10px] text-slate-400 font-sans truncate">({audit.user.jobTitle})</span>
                )}
              </div>
            </div>

            {/* 4. F5 Koruma & Dayanıklılık */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-600 text-[11px] font-sans">F5 Yenileme Durumu</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">
                  DAYANIKLI
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-800 font-medium">
                <Key className="w-3.5 h-3.5 text-blue-600" />
                <span>Oturum Belleği Aktif</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Tarayıcı yenilendiğinde oturum düşmeden token ve kullanıcı profili kalıcı yüklenir.
              </p>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
