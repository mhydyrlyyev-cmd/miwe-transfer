import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, Check, AlertTriangle, Plus, Trash2, Edit3, Shield, CheckCircle, 
  Search, Sliders, Layers, Sparkles, Filter, Apple, MapPin, Building,
  BookOpen, FileText, ExternalLink
} from 'lucide-react';
import { optionsService, OptionItem, DEFAULT_CLEAN_OPTIONS, DEFAULT_PRODUCT_VARIETIES } from '../../services/optionsService';

interface AdminOptionsStandardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: { fullName?: string; role?: string };
}

export const AdminOptionsStandardsModal: React.FC<AdminOptionsStandardsModalProps> = ({
  isOpen,
  onClose,
  currentUser
}) => {
  const [activeTab, setActiveTab] = useState<'varieties' | 'locations' | 'destinations' | 'standards'>('varieties');
  const [items, setItems] = useState<OptionItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductFilter, setSelectedProductFilter] = useState('ALL');
  
  // New item modal/form state
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newOptionValue, setNewOptionValue] = useState('');
  const [newOptionProduct, setNewOptionProduct] = useState('Elma');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editValueText, setEditValueText] = useState('');

  // Restrictions
  const [isVarietiesRestricted, setIsVarietiesRestricted] = useState(false);

  const loadData = () => {
    setItems(optionsService.getAllRegistryItems());
    setIsVarietiesRestricted(optionsService.isRestricted('varieties'));
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  useEffect(() => {
    const handleUpdate = () => loadData();
    window.addEventListener('miwe_options_updated', handleUpdate);
    return () => window.removeEventListener('miwe_options_updated', handleUpdate);
  }, []);

  const handleToggleRestriction = () => {
    const nextVal = !isVarietiesRestricted;
    setIsVarietiesRestricted(nextVal);
    optionsService.setRestriction('varieties', nextVal);
  };

  const handleAddNewOption = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOptionValue.trim()) return;

    const category = activeTab === 'varieties' ? 'varieties' : 
                     activeTab === 'locations' ? 'locations' : 'destinations';

    const newItem = optionsService.addOption(
      category,
      newOptionValue.trim(),
      currentUser?.fullName || 'Admin',
      activeTab === 'varieties' ? newOptionProduct : undefined
    );

    // Auto approve admin added items
    optionsService.toggleApproval(newItem.id, true);

    setNewOptionValue('');
    setIsAddingItem(false);
    loadData();
  };

  const handleSaveEdit = (id: string) => {
    if (!editValueText.trim()) return;
    optionsService.updateOptionByAdmin(id, {
      correctedSpelling: editValueText.trim(),
      isApproved: true
    });
    setEditingItemId(null);
    setEditValueText('');
    loadData();
  };

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const matchCategory = 
        activeTab === 'varieties' ? item.category === 'varieties' :
        activeTab === 'locations' ? item.category === 'locations' :
        item.category === 'destinations';

      if (!matchCategory) return false;

      if (activeTab === 'varieties' && selectedProductFilter !== 'ALL') {
        if (item.productContext !== selectedProductFilter) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const valMatch = item.value.toLowerCase().includes(q) || 
                         (item.correctedSpelling && item.correctedSpelling.toLowerCase().includes(q));
        const userMatch = item.addedBy && item.addedBy.toLowerCase().includes(q);
        return valMatch || userMatch;
      }

      return true;
    });
  }, [items, activeTab, selectedProductFilter, searchQuery]);

  // Built-in standard list for current category
  const defaultList = useMemo(() => {
    if (activeTab === 'varieties') {
      if (selectedProductFilter === 'ALL') {
        return Object.entries(DEFAULT_PRODUCT_VARIETIES).flatMap(([p, vars]) => 
          vars.map(v => ({ product: p, name: v }))
        );
      }
      return (DEFAULT_PRODUCT_VARIETIES[selectedProductFilter] || []).map(v => ({ 
        product: selectedProductFilter, 
        name: v 
      }));
    }
    if (activeTab === 'locations') {
      return (DEFAULT_CLEAN_OPTIONS.locations || []).map(v => ({ product: 'Genel', name: v }));
    }
    if (activeTab === 'destinations') {
      return (DEFAULT_CLEAN_OPTIONS.destinations || []).map(v => ({ product: 'Tesis', name: v }));
    }
    return [];
  }, [activeTab, selectedProductFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-emerald-700 hover:bg-emerald-800 text-white p-5 sm:p-6 flex items-center justify-between border-b border-indigo-900/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-700 hover:bg-emerald-800 flex items-center justify-center text-white shadow-lg">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] tabular-nums font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                  Admin portal
                </span>
                <span className="text-xs text-indigo-300/80 font-semibold">Merkezi Seçenekler & Standartlar</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                Çeşit (Sort / Variety), Parsel & Standart Yönetimi
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-800 px-5 flex items-center gap-2 overflow-x-auto shrink-0 py-2.5">
          <button
            type="button"
            onClick={() => { setActiveTab('varieties'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'varieties'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>1. Çeşitler (Sort / Variety)</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-black/20 text-white">
              {items.filter(i => i.category === 'varieties').length} Eklenen
            </span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('locations'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'locations'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>2. Lokasyon / Parsel / Blok</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-black/20 text-white">
              {items.filter(i => i.category === 'locations').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('destinations'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'destinations'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>3. Tesis & Hedef Depolar</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('standards'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'standards'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>4. SFAC PHM-SOP & Streif Standartları</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {activeTab !== 'standards' ? (
            <>
              {/* Controls Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2 flex-1">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Seçenek ara veya kullanıcı adıyla filtrele..."
                      className="w-full pl-9 pr-3 py-2 text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  {activeTab === 'varieties' && (
                    <select
                      value={selectedProductFilter}
                      onChange={(e) => setSelectedProductFilter(e.target.value)}
                      className="text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="ALL">Tüm Meyveler</option>
                      {Object.keys(DEFAULT_PRODUCT_VARIETIES).map(p => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {activeTab === 'varieties' && (
                    <button
                      type="button"
                      onClick={handleToggleRestriction}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer ${
                        isVarietiesRestricted
                          ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-300 dark:border-rose-700'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                      }`}
                      title="Açıkken kullanıcılar sadece admin tarafından onaylanmış çeşitleri seçebilir"
                    >
                      <Shield className="w-3.5 h-3.5" />
                      <span>{isVarietiesRestricted ? 'Sadece Onaylılara İzin Ver: Açık' : 'Serbest Seçim Modu'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setIsAddingItem(true)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Yeni Ekle</span>
                  </button>
                </div>
              </div>

              {/* Add New Item Dialog */}
              {isAddingItem && (
                <form onSubmit={handleAddNewOption} className="bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 p-4 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-indigo-950 dark:text-indigo-200 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>Resmi Standart Seçenek Ekle (Tüm Kullanıcılara Gözükür)</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsAddingItem(false)}
                      className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                    >
                      İptal
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {activeTab === 'varieties' && (
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Meyve / Ürün</label>
                        <select
                          value={newOptionProduct}
                          onChange={(e) => setNewOptionProduct(e.target.value)}
                          className="w-full text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2"
                        >
                          {Object.keys(DEFAULT_PRODUCT_VARIETIES).map(p => (
                            <option key={p} value={p}>{p}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className={activeTab === 'varieties' ? 'sm:col-span-2' : 'sm:col-span-3'}>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Doğru Yazılışı / İsim *
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          required
                          value={newOptionValue}
                          onChange={(e) => setNewOptionValue(e.target.value)}
                          placeholder="Örn: Scarlet Spur, B-Z, veya Datly Miwe Soğuk Depo..."
                          className="flex-1 text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <button
                          type="submit"
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer"
                        >
                          Kaydet & Onayla
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              )}

              {/* User-Submitted Options (Bekleyen veya Eklenenler) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-600" />
                    <span>Kullanıcılar Tarafından Eklenen Dinamik Seçenekler ({filteredItems.length})</span>
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    Admin doğru yazılışını düzeltebilir, onaylayabilir veya silebilir.
                  </span>
                </div>

                {filteredItems.length === 0 ? (
                  <div className="p-6 text-center bg-slate-50 dark:bg-slate-800 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-500 text-xs">
                    Kullanıcılar tarafından henüz yeni bir seçenek eklenmemiş veya arama kriterine uygun kayıt yok.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {filteredItems.map(item => (
                      <div
                        key={item.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          item.isApproved
                            ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                            : 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              {editingItemId === item.id ? (
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="text"
                                    value={editValueText}
                                    onChange={(e) => setEditValueText(e.target.value)}
                                    className="text-xs font-bold bg-white dark:bg-slate-800 border border-indigo-400 rounded-lg px-2 py-1 outline-none"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleSaveEdit(item.id)}
                                    className="p-1 bg-emerald-600 text-white rounded-lg text-xs"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingItemId(null)}
                                    className="p-1 bg-slate-300 text-slate-700 rounded-lg text-xs"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <span className="font-bold text-xs text-slate-900 dark:text-slate-100">
                                  {item.correctedSpelling || item.value}
                                </span>
                              )}

                              {item.correctedSpelling && (
                                <span className="text-[10px] bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200 px-1.5 py-0.2 rounded tabular-nums">
                                  Düzeltildi
                                </span>
                              )}

                              {item.productContext && (
                                <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.2 rounded font-bold">
                                  {item.productContext}
                                </span>
                              )}
                            </div>

                            <div className="text-[11px] text-slate-500 flex items-center gap-2">
                              <span>Ekleyen: <strong>{item.addedBy || 'Kullanıcı'}</strong></span>
                              <span>•</span>
                              <span>{new Date(item.createdAt).toLocaleDateString('tr-TR')}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingItemId(item.id);
                                setEditValueText(item.correctedSpelling || item.value);
                              }}
                              className="p-1.5 text-slate-600 hover:text-indigo-600 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs transition"
                              title="Yazılışı Düzelt"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                optionsService.toggleApproval(item.id);
                                loadData();
                              }}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition ${
                                item.isApproved
                                  ? 'bg-emerald-600 text-white border-emerald-700'
                                  : 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                              }`}
                            >
                              {item.isApproved ? '✓ Onaylı' : 'Onayla'}
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm('Bu seçeneği silmek istediğinize emin misiniz?')) {
                                  optionsService.deleteOption(item.id);
                                  loadData();
                                }
                              }}
                              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                              title="Sil"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Standart Sistem Seçenekleri (Kalıcı Kütüphane) */}
              <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Resmi Sistem Kütüphanesi ({defaultList.length})</span>
                  </h3>
                  <span className="text-[11px] text-slate-500 font-semibold">
                    Zirai standartlara uygun sabit onaylı seçenekler
                  </span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {defaultList.map((item, idx) => (
                    <div
                      key={idx}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                    >
                      <span className="text-indigo-600 dark:text-indigo-400 text-[10px] tabular-nums">
                        [{item.product}]
                      </span>
                      <span>{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            /* Sfac phm-sop & streif standartlari tablosu */
            <div className="space-y-5">
              <div className="bg-emerald-700 hover:bg-emerald-800 text-white p-4 sm:p-5 rounded-2xl border border-teal-500/30 flex items-start justify-between gap-3 shadow-lg">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] tabular-nums font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40">
                      SFAC INDIA PHM-SOP (24 MAY 2022) &amp; WSU
                    </span>
                    <span className="text-xs text-teal-200 font-bold">Resmi Hasat Sonrası &amp; Depolama Standartları</span>
                  </div>
                  <h3 className="text-base font-bold text-white">
                    Meyve Kalite Kriterleri, Optimum Saklama Sıcaklıkları &amp; Fizyolojik Bozukluklar
                  </h3>
                  <p className="text-xs text-teal-200/80 leading-relaxed">
                    Referans belge: Draft PHM-SOP for Fruits &amp; Vegetables (SFAC India 2022), WSU Tree Fruit Extension ve Eurofins/CTIFL.
                  </p>
                </div>

                <a
                  href="https://sfacindia.com/UploadFile/Statistics/Draft-PHM-SOP-Fruits-and-Vegetables-24-May-2022.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-1.5"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>PDF Referansı Aç</span>
                </a>
              </div>

              {/* Standartlar Tablosu */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="py-3 px-3">Ürün / Çeşit</th>
                      <th className="py-3 px-3">Optimum Hasat İndeksi</th>
                      <th className="py-3 px-3">Sertlik &amp; Brix Normu</th>
                      <th className="py-3 px-3">Depo Sıcaklığı &amp; RH (%)</th>
                      <th className="py-3 px-3">Maksimum Süre &amp; Kritik Kusurlar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium text-slate-800 dark:text-slate-200">
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800">
                      <td className="py-2.5 px-3 font-bold">
                         Elma (Granny Smith, Red Chief, Gala, Golden)
                      </td>
                      <td className="py-2.5 px-3">
                        Streif SI: 0.12 - 0.18<br />
                        Nişasta Skalası: 3.0 - 5.0 / 10
                      </td>
                      <td className="py-2.5 px-3">
                        Sertlik: 6.8 - 8.2 kg/cm²<br />
                        Brix: 12.0 - 14.5 °Bx
                      </td>
                      <td className="py-2.5 px-3">
                        0.0°C - 1.0°C<br />
                        %90 - %95 RH
                      </td>
                      <td className="py-2.5 px-3">
                        CA Depo: 6 - 10 Ay<br />
                        <span className="text-[10px] text-rose-600 font-semibold">Acı benek, su kalbi, kabuk yanıklığı</span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800">
                      <td className="py-2.5 px-3 font-bold">
                         Şeftali &amp; Nektarin (Extreme 314, Big Top)
                      </td>
                      <td className="py-2.5 px-3">
                        Zemin rengi yeşilden sarıya dönüşüm, omuz dolgunluğu
                      </td>
                      <td className="py-2.5 px-3">
                        Sertlik: 4.5 - 6.5 kg/cm²<br />
                        Brix: 10.5 - 13.5 °Bx
                      </td>
                      <td className="py-2.5 px-3">
                        -0.5°C - 0.0°C<br />
                        %90 - %95 RH
                      </td>
                      <td className="py-2.5 px-3">
                        2 - 4 Hafta (2-8°C Chilling Injury tehlikesi!)<br />
                        <span className="text-[10px] text-rose-600 font-semibold">İç unlaşma ve kahverengileşme</span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800">
                      <td className="py-2.5 px-3 font-bold">
                         Muz (Cavendish Grand Nain)
                      </td>
                      <td className="py-2.5 px-3">
                        11-12. hafta şerit rengi, Kalibrasyon 36-40 mm, Parmak boyu ≥20 cm
                      </td>
                      <td className="py-2.5 px-3">
                        Yeşil Hasat Skalası 1-2<br />
                        Brix: 3.5 - 5.0 °Bx (Yeşil)
                      </td>
                      <td className="py-2.5 px-3">
                        13.0°C - 14.0°C<br />
                        %85 - %95 RH
                      </td>
                      <td className="py-2.5 px-3">
                        Yeşil nakliye 2-4 hafta<br />
                        <span className="text-[10px] text-rose-600 font-semibold">&lt;12.8°C üşüme hasarı (gri kabuk)</span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800">
                      <td className="py-2.5 px-3 font-bold">
                         Badem (Nonpareil, Guara, Ferragnes)
                      </td>
                      <td className="py-2.5 px-3">
                        Ağaçta kabuk açılması ≥ %70, 10 gün önce su kesimi
                      </td>
                      <td className="py-2.5 px-3">
                        İç Randıman: %32 - %38<br />
                        Kurutma Nemi: %4.5 - %6.0
                      </td>
                      <td className="py-2.5 px-3">
                        0.0°C - 10.0°C (Kuru Depo)<br />
                        &lt; %65 RH
                      </td>
                      <td className="py-2.5 px-3">
                        12 - 24 Ay<br />
                        <span className="text-[10px] text-rose-600 font-semibold">&gt;%6.5 nemde Aflatoksin ve küf riski</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-800 px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500 font-semibold">
            Merkezi Veritabanı: Eklenen seçenekler tüm kullanıcıların formlarında anında güncellenir.
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
