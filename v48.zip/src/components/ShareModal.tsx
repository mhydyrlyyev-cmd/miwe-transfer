import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  Smartphone, 
  WifiOff, 
  QrCode, 
  Globe, 
  ExternalLink,
  Info,
  ShieldCheck
} from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Mevcut çalışan domain veya ana yayın adresi
  const appUrl = typeof window !== 'undefined' && window.location.href.includes('ai.studio')
    ? window.location.origin
    : 'https://miwe-hil.ai.studio';

  const handleCopy = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(appUrl);
      } else {
        const input = document.createElement('input');
        input.value = appUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Kopyalama hatası:', err);
    }
  };

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(appUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-slate-800 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#0f4a33] text-white px-6 py-5 flex items-center justify-between border-b border-emerald-950">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
                Uygulama Bağlantısını Paylaş & Yayınla
              </h2>
              <p className="text-xs text-emerald-200/80">
                Saha personeli, ambar sorumluları ve yöneticilerle paylaşım rehberi
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-emerald-300 hover:text-white hover:bg-emerald-800/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Main Link Box */}
          <div>
            <label className="text-xs font-bold text-slate-600 block mb-2">
               Herkese Paylaşılacak Canlı Yayın Linki:
            </label>
            <div className="flex items-center gap-2 bg-slate-50 border-2 border-emerald-500/40 rounded-2xl p-2 pl-3 shadow-inner">
              <span className="text-xs tabular-nums font-bold text-slate-800 truncate flex-1 select-all">
                {appUrl}
              </span>
              <button
                onClick={handleCopy}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Kopyalandı!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Linki Kopyala</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* QR Code & Mobile Fast Access */}
          <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row items-center gap-4">
            <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm shrink-0">
              <img 
                src={qrUrl} 
                alt="QR Kod" 
                className="w-28 h-28 object-contain"
                loading="lazy" 
              />
            </div>
            <div className="space-y-1.5 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 font-bold text-xs text-slate-900">
                <QrCode className="w-4 h-4 text-emerald-700" />
                <span>Kamera ile Tara & Cepten Aç</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Saha çalışanları telefonlarının kamerasıyla bu QR kodu okutarak hiçbir kurulum yapmadan anında uygulamaya girebilir.
              </p>
              <div className="flex items-center justify-center sm:justify-start gap-2 pt-1">
                <a
                  href={`https://wa.me/?text=${encodeURIComponent('MIWE HIL Kalite ve İzlenebilirlik Portalı: ' + appUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold inline-flex items-center gap-1 shadow-sm transition"
                >
                  WhatsApp ile Gönder
                </a>
              </div>
            </div>
          </div>

          {/* Offline & Mobil Kurulum Rehberi */}
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-950">
              <Smartphone className="w-4 h-4 text-emerald-700 shrink-0" />
              <span> Telefona / Tablete Uygulama Olarak Kaydetme (PWA):</span>
            </div>
            <ol className="text-xs text-emerald-900/90 space-y-1.5 list-decimal pl-5">
              <li>Telefon tarayıcısında (Chrome veya Safari) linki açın.</li>
              <li>Menüden (üç nokta veya paylaş butonu) <strong>"Ana Ekrana Ekle"</strong> (Add to Home Screen) seçeneğine basın.</li>
              <li>Uygulama tıpkı yerel bir mobil uygulama gibi tam ekran çalışır.</li>
            </ol>
          </div>

          {/* Offline Data Guarantees */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
              <WifiOff className="w-4 h-4 text-amber-700 shrink-0" />
              <span> İnternetsiz (Offline) Sahada Nasıl Çalışır?</span>
            </div>
            <p className="text-xs text-amber-900/90 leading-relaxed">
              Bahçe, sera ve ambar gibi internetin çekmediği yerlerde formları doldurup kaydettiğinizde tüm bilgiler telefonunuzun yerel hafızasına (Offline Queue) kaydedilir. İnternet geldiğinde sağ üstteki <strong>"Senk"</strong> butonuna basarak veya otomatik olarak Google E-Tablo'ya gönderebilirsiniz.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-100 px-6 py-3.5 flex items-center justify-between border-t border-slate-200">
          <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>MIWE HIL (Quality) Entegre Kalite Portalı</span>
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-sm"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
