import React from 'react';
import { RefreshCw, CheckCircle2, AlertTriangle, AlertCircle, CloudOff, Cloud } from 'lucide-react';

export type SyncProcessStatus = 'SUCCESS' | 'PENDING' | 'ERROR' | 'SYNCING';

interface SyncProgressBarProps {
  isSyncing: boolean;
  isOnline: boolean;
  pendingCount: number;
  lastSyncTime?: string | null;
  lastStatus?: SyncProcessStatus;
  errorMessage?: string | null;
  onSyncNow?: () => void | Promise<void>;
  compact?: boolean;
}

export const SyncProgressBar: React.FC<SyncProgressBarProps> = ({
  isSyncing,
  isOnline,
  pendingCount,
  lastSyncTime,
  lastStatus,
  errorMessage,
  onSyncNow,
  compact = false,
}) => {
  // Determine actual effective status
  let status: SyncProcessStatus = 'SUCCESS';
  if (!isOnline) {
    status = 'PENDING';
  } else if (isSyncing) {
    status = 'SYNCING';
  } else if (lastStatus === 'ERROR' || !!errorMessage) {
    status = 'ERROR';
  } else if (pendingCount > 0) {
    status = 'PENDING';
  } else {
    status = 'SUCCESS';
  }

  // Calculate percentage
  let percentage = 100;
  if (status === 'SYNCING') {
    percentage = 75;
  } else if (status === 'PENDING') {
    percentage = pendingCount > 0 ? Math.max(15, 100 - (pendingCount * 15)) : 50;
  } else if (status === 'ERROR') {
    percentage = 35;
  } else {
    percentage = 100;
  }

  const statusConfig = {
    SUCCESS: {
      label: 'Başarılı (Senkronize)',
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500',
      bgLight: 'bg-emerald-950/40 border-emerald-800/60',
      icon: CheckCircle2,
    },
    PENDING: {
      label: isOnline ? `Bekliyor (${pendingCount} işlem)` : 'Çevrimdışı (Kuyrukta)',
      color: 'text-amber-400',
      bgColor: 'bg-amber-500',
      bgLight: 'bg-amber-950/40 border-amber-800/60',
      icon: isOnline ? AlertTriangle : CloudOff,
    },
    ERROR: {
      label: 'Senkronizasyon Hatası',
      color: 'text-rose-400',
      bgColor: 'bg-rose-500',
      bgLight: 'bg-rose-950/40 border-rose-800/60',
      icon: AlertCircle,
    },
    SYNCING: {
      label: 'Senkronize Ediliyor...',
      color: 'text-sky-400',
      bgColor: 'bg-sky-500',
      bgLight: 'bg-sky-950/40 border-sky-800/60',
      icon: RefreshCw,
    },
  }[status];

  const StatusIcon = statusConfig.icon;

  if (compact) {
    return (
      <div className="w-full space-y-1 text-xs">
        <div className="flex items-center justify-between text-[11px]">
          <span className={`flex items-center gap-1.5 font-bold ${statusConfig.color}`}>
            <StatusIcon className={`w-3.5 h-3.5 ${status === 'SYNCING' ? 'animate-spin' : ''}`} />
            {statusConfig.label}
          </span>
          <span className="text-[10px] text-slate-400 tabular-nums">%{percentage}</span>
        </div>
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className={`h-full ${statusConfig.bgColor} transition-all duration-500 rounded-full ${
              status === 'SYNCING' ? 'animate-pulse' : ''
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className={`p-3 rounded-xl border ${statusConfig.bgLight} transition-all duration-200`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-lg bg-slate-900/80 border border-slate-700/80 ${statusConfig.color}`}>
            <StatusIcon className={`w-4 h-4 ${status === 'SYNCING' ? 'animate-spin' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">Senkronizasyon Durumu</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md ${
                status === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300' :
                status === 'PENDING' ? 'bg-amber-500/20 text-amber-300' :
                status === 'ERROR' ? 'bg-rose-500/20 text-rose-300' : 'bg-sky-500/20 text-sky-300'
              }`}>
                {status}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              {statusConfig.label}
              {lastSyncTime && <span className="ml-1 text-slate-500">• Son: {lastSyncTime}</span>}
            </div>
          </div>
        </div>

        {onSyncNow && (
          <button
            type="button"
            onClick={onSyncNow}
            disabled={isSyncing || !isOnline}
            className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border transition flex items-center gap-1 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              status === 'ERROR'
                ? 'bg-rose-900/60 hover:bg-rose-800 text-rose-200 border-rose-700'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
            title="Şimdi Senkronize Et"
          >
            <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Eşitleniyor' : 'Eşitle'}</span>
          </button>
        )}
      </div>

      {/* Progress Bar with Indicator */}
      <div className="space-y-1">
        <div className="w-full h-2 bg-slate-900/90 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <div
            className={`h-full ${statusConfig.bgColor} rounded-full transition-all duration-500 ${
              status === 'SYNCING' ? 'animate-pulse bg-sky-500' : ''
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-400 tabular-nums">
          <span className="flex items-center gap-1">
            {isOnline ? (
              <span className="inline-flex items-center text-emerald-400 gap-1"><Cloud className="w-3 h-3" /> Çevrimiçi</span>
            ) : (
              <span className="inline-flex items-center text-amber-400 gap-1"><CloudOff className="w-3 h-3" /> Çevrimdışı</span>
            )}
          </span>
          <span>%{percentage} Tamamlandı</span>
        </div>
      </div>

      {errorMessage && (
        <div className="mt-2 text-[10px] text-rose-300 bg-rose-950/70 border border-rose-900 p-1.5 rounded-lg">
          ⚠️ {errorMessage}
        </div>
      )}
    </div>
  );
};
