import React, { useState } from 'react';
import { X, Plus, Trash2, Layers, Save, Sliders, CheckCircle2 } from 'lucide-react';
import { CustomFieldDefinition, ModuleKey } from '../types';

interface CustomFieldsModalProps {
  isOpen?: boolean;
  customFields: CustomFieldDefinition[];
  onSaveCustomFields?: (fields: CustomFieldDefinition[]) => void;
  onSaveField?: (field: CustomFieldDefinition) => void;
  onDeleteField?: (id: string) => void;
  onClose: () => void;
}

export const CustomFieldsModal: React.FC<CustomFieldsModalProps> = ({
  isOpen = true,
  customFields,
  onSaveCustomFields,
  onSaveField,
  onDeleteField,
  onClose
}) => {
  const [fields, setFields] = useState<CustomFieldDefinition[]>(customFields || []);
  const [targetModule, setTargetModule] = useState<ModuleKey>('HARVEST');
  const [label, setLabel] = useState('');
  const [fieldType, setFieldType] = useState<'text' | 'number' | 'select' | 'boolean' | 'date'>('text');
  const [optionsStr, setOptionsStr] = useState('');
  const [required, setRequired] = useState(false);

  if (isOpen === false) return null;

  const handleAddField = () => {
    if (!label.trim()) {
      alert('Lütfen alan etiketi / adını yazın.');
      return;
    }

    const fieldKey = label.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Date.now();
    const options = fieldType === 'select' ? optionsStr.split(',').map(s => s.trim()).filter(Boolean) : undefined;

    const newField: CustomFieldDefinition = {
      id: `cf-${Date.now()}`,
      moduleKey: targetModule,
      label: label.trim(),
      fieldKey,
      fieldType,
      options,
      required
    };

    setFields(prev => [...prev, newField]);
    if (onSaveField) {
      onSaveField(newField);
    }
    setLabel('');
    setOptionsStr('');
    setRequired(false);
  };

  const handleDeleteField = (id: string) => {
    setFields(prev => prev.filter(f => f.id !== id));
    if (onDeleteField) {
      onDeleteField(id);
    }
  };

  const handleSaveAndClose = () => {
    if (onSaveCustomFields) {
      onSaveCustomFields(fields);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full my-8 overflow-hidden">
        {/* Header */}
        <div className="bg-[#5c1d24] text-white px-6 py-4 flex items-center justify-between border-b border-rose-950">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Dinamik Form Yönetimi & Yeni Alan / Kutu Ekleme
              </h2>
              <p className="text-xs text-rose-200/80">
                Gelecekte modüllere yeni sütunlar veya veri giriş kutucukları ekleyin
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-rose-200 hover:text-white bg-rose-950/60 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Add New Field Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-[#5c1d24]" />
              <span>Yeni Alan / Kutucuk Tanımla</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Hangi Modüle Eklensin?
                </label>
                <select
                  value={targetModule}
                  onChange={(e) => setTargetModule(e.target.value as ModuleKey)}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
                >
                  <option value="HARVEST"> Günlük Hasat (Saha)</option>
                  <option value="FIELD"> Saha Meyve Testi</option>
                  <option value="MUZ"> Muz Sera / MAP / Gazlama</option>
                  <option value="BADEM"> Badem Kalite & Kurutma</option>
                  <option value="LOJISTIK"> Lojistik & Sevkiyat</option>
                  <option value="AMBAR"> Ambar Kabul & Oda</option>
                  <option value="INCIDENT"> Incident & Barlag Akty</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Alan Adı / Etiketi *
                </label>
                <input
                  type="text"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="Örn: Gübreleme Kodu"
                  className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Veri Tipi
                </label>
                <select
                  value={fieldType}
                  onChange={(e) => setFieldType(e.target.value as any)}
                  className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2"
                >
                  <option value="text">Metin (Yazı)</option>
                  <option value="number">Sayısal (Rakam)</option>
                  <option value="select">Açılır Liste (Seçenekli)</option>
                  <option value="boolean">Onay Kutusu (Evet/Hayır)</option>
                  <option value="date">Tarih</option>
                </select>
              </div>
            </div>

            {fieldType === 'select' && (
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Açılır Liste Seçenekleri (Virgülle ayırın):
                </label>
                <input
                  type="text"
                  value={optionsStr}
                  onChange={(e) => setOptionsStr(e.target.value)}
                  placeholder="A Sınıfı, B Sınıfı, C Sınıfı"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={required}
                  onChange={(e) => setRequired(e.target.checked)}
                  className="w-3.5 h-3.5 text-[#5c1d24] rounded"
                />
                <span>Zorunlu Alan Olsun</span>
              </label>

              <button
                type="button"
                onClick={handleAddField}
                className="flex items-center gap-1.5 px-4 py-2 bg-[#5c1d24] hover:bg-[#43141a] text-white text-xs font-bold rounded-lg transition shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Alanı Listeye Ekle</span>
              </button>
            </div>
          </div>

          {/* Current Custom Fields List */}
          <div>
            <h3 className="text-xs font-bold text-slate-700 mb-2">
              Aktif Özel Alanlar ({fields.length})
            </h3>

            {fields.length === 0 ? (
              <p className="text-xs text-slate-400 italic bg-slate-50 p-4 rounded-xl text-center border border-dashed border-slate-200">
                Henüz özel bir alan eklenmedi. Yukarıdaki formdan istediğiniz modüle anında yeni kutucuk ekleyebilirsiniz.
              </p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {fields.map(f => (
                  <div
                    key={f.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-200 shadow-sm text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-slate-800 font-bold">{f.label}</strong>
                        <span className="px-1.5 py-0.5 rounded text-[10px] tabular-nums bg-slate-100 text-slate-600">
                          {f.moduleKey}
                        </span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-50 text-[#5c1d24] font-semibold">
                          {f.fieldType}
                        </span>
                        {f.required && (
                          <span className="text-[10px] text-red-600 font-bold">*Zorunlu</span>
                        )}
                      </div>
                      {f.options && f.options.length > 0 && (
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Seçenekler: {f.options.join(', ')}
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteField(f.id)}
                      className="text-red-500 hover:text-red-700 p-1.5 rounded-lg hover:bg-red-50 transition"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100"
          >
            Vazgeç
          </button>
          <button
            type="button"
            onClick={handleSaveAndClose}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-[#5c1d24] hover:bg-[#43141a] text-white text-xs font-bold shadow-md transition"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Kaydet & Uygula</span>
          </button>
        </div>
      </div>
    </div>
  );
};
