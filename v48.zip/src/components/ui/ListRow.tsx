import React from 'react';
import { ChevronRight } from 'lucide-react';
import { cx } from './cx';

/** v46: renkli nokta + başlık/alt satır + sağda rozet/işlem. Uyarı ve karar listelerinde. */
export interface ListRowProps {
  title: React.ReactNode;
  sub?: React.ReactNode;
  right?: React.ReactNode;
  dot?: 'error' | 'warn' | 'info' | 'ok' | null;
  onClick?: () => void;
  children?: React.ReactNode;
}
const DOT = { error: 'bg-rose-500', warn: 'bg-amber-500', info: 'bg-sky-500', ok: 'bg-emerald-500' };

export function ListRow({ title, sub, right, dot, onClick, children }: ListRowProps) {
  return (
    <div className="py-2.5 border-t border-slate-100 dark:border-slate-800 first:border-0">
      <div className={cx('flex items-center gap-3', onClick && 'cursor-pointer')} onClick={onClick} role={onClick ? 'button' : undefined}>
        {dot && <span className={cx('w-2 h-2 rounded-full shrink-0', DOT[dot])} aria-hidden="true" />}
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">{title}</div>
          {sub && <div className="text-xs text-slate-500 dark:text-slate-400">{sub}</div>}
        </div>
        {right}
        {onClick && <ChevronRight className="w-4 h-4 text-slate-300 shrink-0" aria-hidden="true" />}
      </div>
      {children}
    </div>
  );
}
export default ListRow;
