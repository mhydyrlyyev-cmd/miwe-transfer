import React from 'react';
import { cx } from './cx';

/** v46: gri zemin üstünde beyaz seçili parça (ana sayfa dili). */
export interface SegmentedProps<K extends string> {
  value: K;
  onChange: (k: K) => void;
  items: { key: K; label: React.ReactNode; count?: number }[];
  ariaLabel?: string;
}
export function Segmented<K extends string>({ value, onChange, items, ariaLabel }: SegmentedProps<K>) {
  return (
    <div role="tablist" aria-label={ariaLabel} className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold overflow-x-auto">
      {items.map(it => (
        <button key={it.key} type="button" role="tab" aria-selected={it.key === value} onClick={() => onChange(it.key)}
          className={cx('flex-1 whitespace-nowrap text-center px-2 py-1.5 rounded-lg cursor-pointer', it.key === value ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400')}>
          {it.label}{typeof it.count === 'number' ? ` ${it.count}` : ''}
        </button>
      ))}
    </div>
  );
}
export default Segmented;
