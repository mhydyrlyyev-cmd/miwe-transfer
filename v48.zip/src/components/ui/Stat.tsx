import React from 'react';
import { cx } from './cx';

/** v46: ana sayfa dilinde tek sayı kutusu (en fazla 3 yan yana). */
export interface StatProps {
  label: React.ReactNode;
  value: React.ReactNode;
  unit?: string;
  note?: React.ReactNode;
  tone?: 'neutral' | 'ok' | 'warn' | 'error';
  onClick?: () => void;
  active?: boolean;
}
const TONE = { neutral: 'text-slate-900 dark:text-white', ok: 'text-emerald-700 dark:text-emerald-300', warn: 'text-amber-700 dark:text-amber-300', error: 'text-rose-700 dark:text-rose-300' };

export function Stat({ label, value, unit, note, tone = 'neutral', onClick, active }: StatProps) {
  const Tag: any = onClick ? 'button' : 'div';
  return (
    <Tag type={onClick ? 'button' : undefined} onClick={onClick}
      className={cx('text-left bg-white dark:bg-slate-900 border rounded-2xl p-3 min-w-0', active ? 'border-slate-500 ring-1 ring-slate-400' : 'border-slate-200 dark:border-slate-800', onClick && 'cursor-pointer')}>
      <div className="text-xs text-slate-500 dark:text-slate-400 truncate">{label}</div>
      <div className={cx('text-2xl font-bold tabular-nums leading-tight', TONE[tone])}>{value}{unit && <span className="text-sm font-semibold text-slate-500 ml-1">{unit}</span>}</div>
      {note && <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{note}</div>}
    </Tag>
  );
}
export default Stat;
