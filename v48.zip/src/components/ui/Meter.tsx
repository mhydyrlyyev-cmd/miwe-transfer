import React from 'react';

/** v46: etiketli yatay çubuk (aşama, ürün, puan). Renk aşama sözlüğünden verilir. */
export interface MeterProps { label: React.ReactNode; value: number; max: number; color?: string; note?: React.ReactNode; icon?: React.ReactNode }
export function Meter({ label, value, max, color = '#2F7D3A', note, icon }: MeterProps) {
  const pct = max > 0 ? Math.max(value > 0 ? 2 : 0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div className="flex items-center gap-3 py-1.5">
      {icon && <span className="w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0" style={{ background: color }}>{icon}</span>}
      <div className="flex-1 min-w-0">
        <div className="flex justify-between gap-2 text-xs mb-1"><span className="text-slate-700 dark:text-slate-200 font-medium truncate">{label}</span><span className="tabular-nums text-slate-900 dark:text-white font-semibold whitespace-nowrap">{note}</span></div>
        <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden"><div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} /></div>
      </div>
    </div>
  );
}
export default Meter;
