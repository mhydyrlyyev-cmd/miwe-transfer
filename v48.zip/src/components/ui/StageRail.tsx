import React, { useState } from 'react';
import { ChevronDown, ShieldCheck, Ban, ClipboardList } from 'lucide-react';
import { STAGES, STAGE_BY_KEY, STAGE_TONE, StageKey } from '../../config/processStages';
import { cx } from './cx';

/**
 * v3.6 — Aşama şeridi. Her modül sayfasının üstünde: süreç zincirinde neredesiniz,
 * bu sayfada ne kaydedilir / ne kaydedilmez (hangi sayfada), bu aşamanın kalite kontrolleri.
 * Amaç: hasat ↔ ön soğutma, depo ↔ sevk verilerinin birbirine karışmaması.
 */
interface Props {
  current: StageKey;
  /** Hangi sayfadasınız: kayıt formu mu, izleme mi */
  mode?: 'entry' | 'monitor';
  onNavigate?: (view: string) => void;
  /** Aşamaya özel küçük sayaç (ör. uyarı sayısı) */
  badges?: Partial<Record<StageKey, number>>;
  className?: string;
}

export function StageRail({ current, mode = 'entry', onNavigate, badges, className }: Props) {
  const [open, setOpen] = useState(false);
  const cur = STAGE_BY_KEY[current];
  const tone = STAGE_TONE[cur.color];

  return (
    <div className={cx('rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden', className)}>
      {/* Zincir */}
      <nav aria-label="Süreç aşamaları" className="flex items-stretch overflow-x-auto">
        {STAGES.map((s, i) => {
          const active = s.key === current;
          const t = STAGE_TONE[s.color];
          const target = s.monitorView && !active ? s.monitorView : s.entryView;
          const badge = badges?.[s.key];
          return (
            <React.Fragment key={s.key}>
              <button
                type="button"
                onClick={() => onNavigate?.(active ? (mode === 'entry' ? (s.monitorView || s.entryView) : s.entryView) : target)}
                aria-current={active ? 'step' : undefined}
                className={cx(
                  'flex-1 min-w-[84px] flex items-center gap-2 px-2.5 py-2 text-left transition cursor-pointer',
                  active ? t.solid : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                )}
                title={active ? (mode === 'entry' ? (s.monitorLabel ? `${s.monitorLabel} sayfasına git` : '') : `${s.entryLabel} sayfasına git`) : `${s.label} sayfasına git`}
              >
                <span className={cx('shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-black',
                  active ? 'bg-white/25 text-white' : cx(t.dot, 'text-white'))}>{s.no}</span>
                <span className="min-w-0">
                  <span className={cx('block text-xs font-bold leading-tight truncate', active ? 'text-white' : 'text-slate-800 dark:text-slate-100')}>{s.short}</span>
                  {active && <span className="block text-[10px] opacity-90 leading-tight truncate">{mode === 'entry' ? s.entryLabel : (s.monitorLabel || s.entryLabel)}</span>}
                </span>
                {!!badge && (
                  <span className={cx('ml-auto shrink-0 min-w-5 h-5 px-1 rounded-full text-[10px] font-black flex items-center justify-center',
                    active ? 'bg-white text-slate-900' : 'bg-rose-500 text-white')}>{badge}</span>
                )}
              </button>
              {i < STAGES.length - 1 && <span aria-hidden="true" className="w-px bg-slate-200 dark:bg-slate-800" />}
            </React.Fragment>
          );
        })}
      </nav>

      {/* Bu aşamanın kapsamı */}
      <button type="button" onClick={() => setOpen(v => !v)} aria-expanded={open}
        className={cx('w-full flex items-center gap-2 px-3 py-1.5 text-[11px] font-semibold border-t cursor-pointer', tone.soft, tone.text)}>
        <ClipboardList className="w-3.5 h-3.5" />
        <span className="truncate">Bu sayfada: {cur.records.slice(0, 2).join(' · ')}{cur.records.length > 2 ? ' …' : ''}</span>
        <ChevronDown className={cx('w-3.5 h-3.5 ml-auto transition-transform', open && 'rotate-180')} />
      </button>
      {open && (
        <div className="grid sm:grid-cols-3 gap-3 p-3 text-xs border-t border-slate-200 dark:border-slate-800">
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-1"><ClipboardList className="w-3.5 h-3.5" />Burada kaydedilir</div>
            <ul className="space-y-0.5 text-slate-600 dark:text-slate-300 list-disc pl-4">{cur.records.map(r => <li key={r}>{r}</li>)}</ul>
          </div>
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-1"><Ban className="w-3.5 h-3.5" />Burada değil</div>
            <ul className="space-y-1">
              {cur.notHere.map(n => {
                const st = STAGE_BY_KEY[n.where];
                return (
                  <li key={n.what} className="text-slate-600 dark:text-slate-300">
                    {n.what} →{' '}
                    <button type="button" onClick={() => onNavigate?.(st.entryView)} className={cx('font-bold underline-offset-2 hover:underline cursor-pointer', STAGE_TONE[st.color].text)}>{st.label}</button>
                  </li>
                );
              })}
            </ul>
          </div>
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" />Kalite kontrol noktaları</div>
            <ul className="space-y-0.5 text-slate-600 dark:text-slate-300 list-disc pl-4">{cur.quality.map(q => <li key={q}>{q}</li>)}</ul>
          </div>
        </div>
      )}
    </div>
  );
}
