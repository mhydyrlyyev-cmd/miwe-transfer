import React, { useState } from 'react';
import { X, Send, Bell, AlertTriangle, CheckSquare, Info, ShieldAlert, Sparkles } from 'lucide-react';
import { addNotification, AppNotification } from '../../utils/notificationService';
import { AppUser } from '../../types/auth';

interface CreateNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AppUser | null;
  onSuccess?: (msg: string) => void;
}

export const CreateNotificationModal: React.FC<CreateNotificationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<AppNotification['type']>('CRITICAL_ALERT');
  const [targetUser, setTargetUser] = useState<string>('ALL');
  const [actionLink, setActionLink] = useState<string>('DASHBOARD');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    addNotification(
      targetUser,
      title.trim(),
      message.trim(),
      type,
      actionLink
    );

    if (onSuccess) {
      onSuccess(`"${title}" başlıklı bildirim başarıyla yayınlandı.`);
    }

    // Reset & close
    setTitle('');
    setMessage('');
    onClose();
  };

  const handleQuickTemplate = (templateType: 'CRITICAL_STOCK' | 'DEGREE_1_INCIDENT' | 'TASK' | 'MAINTENANCE') => {
    if (templateType === 'CRITICAL_STOCK') {
      setType('CRITICAL_ALERT');
      setTitle('🚨 Acil Kritik Stok Uyarısı: Şeftali / Extreme 314');
      setMessage('Datly Miwe Merkez Soğuk Hava Deposu Oda 1 stoğu kritik eşik olan 2,500 kg seviyesinin altına inmiştir. Lütfen acil yeni hasat tedariği başlatın.');
      setActionLink('DASHBOARD');
    } else if (templateType === 'DEGREE_1_INCIDENT') {
      setType('CRITICAL_ALERT');
      setTitle('🚨 1. DERECE BARLAG AKTY (Kritik Kalite Olayı)');
      setMessage('Soğuk zincir sıcaklık aşımı tespit edildi (+15.2°C). 2,400 kg ürün risk altında. Acil DÖF ve kalite izolasyonu başlatıldı.');
      setActionLink('INCIDENT');
    } else if (templateType === 'TASK') {
      setType('TASK_ASSIGNED');
      setTitle('📋 Saha Görevi: Muz Sarartma & Brix Kontrolü');
      setMessage('Hemsaýa Muz Gazlama Odası #2 için olgunluk indeksi, pulpa sertliği ve brix ölçüm verilerini sisteme kaydedin.');
      setActionLink('MUZ');
    } else if (templateType === 'MAINTENANCE') {
      setType('SYSTEM');
      setTitle('⚙️ Planlı Soğuk Depo Kalibrasyon & Bakımı');
      setMessage('Merkez Soğuk Depo #1 ve #2 ozonlama ve sıcaklık sensörleri kalibrasyon testi saat 18:00 itibarıyla gerçekleştirilecektir.');
      setActionLink('DASHBOARD');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">Yeni Bildirim & Duyuru Yayınla</h3>
              <p className="text-xs text-teal-200/80">Sistem personeline anlık görev veya acil durum uyarısı gönderin</p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
          
          {/* Quick Templates */}
          <div>
            <span className="text-[11px] font-bold text-slate-400 block mb-2">
              Hızlı Şablonlar
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleQuickTemplate('CRITICAL_STOCK')}
                className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-left text-[11px] font-bold hover:brightness-95 transition cursor-pointer flex items-center gap-1.5"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                <span className="truncate">Kritik Stok</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickTemplate('DEGREE_1_INCIDENT')}
                className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-left text-[11px] font-bold hover:brightness-95 transition cursor-pointer flex items-center gap-1.5"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span className="truncate">1. Derece Olay</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickTemplate('TASK')}
                className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 text-teal-700 dark:text-teal-300 text-left text-[11px] font-bold hover:brightness-95 transition cursor-pointer flex items-center gap-1.5"
              >
                <CheckSquare className="w-3.5 h-3.5 text-teal-500 shrink-0" />
                <span className="truncate">Görev Ata</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickTemplate('MAINTENANCE')}
                className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 text-left text-[11px] font-bold hover:brightness-95 transition cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span className="truncate">Sistem/Bakım</span>
              </button>
            </div>
          </div>

          {/* Bildirim Türü */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Bildirim Türü
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'CRITICAL_ALERT', label: 'Kritik Uyarı', icon: AlertTriangle, color: 'text-rose-500 border-rose-400 bg-rose-50 dark:bg-rose-950/40' },
                { id: 'TASK_ASSIGNED', label: 'Görev Atama', icon: CheckSquare, color: 'text-teal-500 border-teal-400 bg-teal-50 dark:bg-teal-950/40' },
                { id: 'SYSTEM', label: 'Sistem Duyurusu', icon: Sparkles, color: 'text-blue-500 border-blue-400 bg-blue-50 dark:bg-blue-950/40' },
                { id: 'INFO', label: 'Bilgi', icon: Info, color: 'text-slate-500 border-slate-400 bg-slate-50 dark:bg-slate-950/40' }
              ].map(item => {
                const Icon = item.icon;
                const isSelected = type === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setType(item.id as any)}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition cursor-pointer ${
                      isSelected
                        ? item.color + ' ring-2 ring-teal-500 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Hedef Kitle & Modül Yönlendirme */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Hedef Kullanıcı / Grup
              </label>
              <select
                value={targetUser}
                onChange={(e) => setTargetUser(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="ALL"> Tüm Personel (Genel Bildirim)</option>
                {currentUser && <option value={currentUser.id}>👤 Yalnızca Ben ({currentUser.fullName})</option>}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                İlgili Modül / Sayfa
              </label>
              <select
                value={actionLink}
                onChange={(e) => setActionLink(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="DASHBOARD">Dashboard (Genel)</option>
                <option value="INCIDENT">Barlag Akty (Incident / DÖF)</option>
                <option value="HARVEST">Hasat Kayıtları</option>
                <option value="AMBAR">Ambar & Soğuk Depo</option>
                <option value="MUZ">Muz Gazlama & Sarartma</option>
                <option value="BADEM">Badem İşleme</option>
                <option value="ANALYTICS">Analitik & Raporlar</option>
              </select>
            </div>
          </div>

          {/* Başlık */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Bildirim Başlığı <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Örn: 🚨 Kritik Stok Uyarısı veya 📋 Yeni Hasat Denetim Görevi"
              required
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          {/* Mesaj Detayı */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Bildirim Açıklaması / Detay <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Personelin görmesini istediğiniz ayrıntılı talimat, oda numarası veya kriz detayını yazın..."
              required
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-normal text-slate-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !message.trim()}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Bildirimi Yayınla</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
