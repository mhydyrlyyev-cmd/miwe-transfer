import React, { useState } from 'react';
import {
  Activity,
  Thermometer,
  Wind,
  Gauge,
  Sparkles,
  Clock,
  CheckCircle2,
  X,
  Play,
  RotateCcw,
  Zap,
  Sliders,
  ShieldCheck,
  Flame,
  Droplets,
  Layers
} from 'lucide-react';
import { BananaScadaChamberData, BananaRipeningStageProgram } from '../../types';
import { DEFAULT_BANANA_RIPENING_STAGES, AVAILABLE_SCADA_ROOMS } from '../../data/bananaRipeningData';

interface BananaRipeningScadaModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: BananaScadaChamberData;
  onApplyScadaData: (data: BananaScadaChamberData) => void;
}

export const BananaRipeningScadaModal: React.FC<BananaRipeningScadaModalProps> = ({
  isOpen,
  onClose,
  initialData,
  onApplyScadaData
}) => {
  const [selectedChamberId, setSelectedChamberId] = useState<string>(
    initialData?.chamberId || AVAILABLE_SCADA_ROOMS[0].id
  );

  const selectedRoomConfig = AVAILABLE_SCADA_ROOMS.find(r => r.id === selectedChamberId) || AVAILABLE_SCADA_ROOMS[0];

  // Sensor states matching the Siemens / Kendall screens
  const [ambientTemp1C, setAmbientTemp1C] = useState<number>(initialData?.ambientTemp1C ?? 19.1);
  const [ambientTemp2C, setAmbientTemp2C] = useState<number>(initialData?.ambientTemp2C ?? 19.0);
  const [pulpTemp1C, setPulpTemp1C] = useState<number>(initialData?.pulpTemp1C ?? 17.6);
  const [pulpTemp2C, setPulpTemp2C] = useState<number>(initialData?.pulpTemp2C ?? 17.6);
  const [ethylenePpm, setEthylenePpm] = useState<number>(initialData?.ethylenePpm ?? 1.3);
  const [co2Ppm, setCo2Ppm] = useState<number>(initialData?.co2Ppm ?? 2553.1);
  const [humidityPercent, setHumidityPercent] = useState<number>(initialData?.humidityPercent ?? 82.0);
  
  const [activeStageIndex, setActiveStageIndex] = useState<number>(initialData?.activeStageIndex ?? 1);
  const [totalRunTimeHours, setTotalRunTimeHours] = useState<number>(initialData?.totalRunTimeHours ?? 151);
  const [elapsedTimeHours, setElapsedTimeHours] = useState<number>(initialData?.elapsedTimeHours ?? 42);

  const [evapFan1State, setEvapFan1State] = useState<boolean>(initialData?.evaporatorFan1State ?? true);
  const [evapFan2State, setEvapFan2State] = useState<boolean>(initialData?.evaporatorFan2State ?? true);
  const [evapFinTempC, setEvapFinTempC] = useState<number>(initialData?.evapFinTempC ?? 2.5);
  const [defrostRemainingMin, setDefrostRemainingMin] = useState<number>(initialData?.defrostRemainingMin ?? 25);
  const [coolingStatusText, setCoolingStatusText] = useState<string>(
    initialData?.coolingStatusText ?? 'Kademeli Sarartma & Gazlama Devam Ediyor'
  );

  const [stages, setStages] = useState<BananaRipeningStageProgram[]>(
    initialData?.stagesMatrix || DEFAULT_BANANA_RIPENING_STAGES
  );

  if (!isOpen) return null;

  const handleStageChange = (
    index: number,
    field: keyof BananaRipeningStageProgram,
    value: string | number
  ) => {
    setStages(prev => {
      const updated = [...prev];
      updated[index] = {
        ...updated[index],
        [field]: typeof value === 'string' && field !== 'stageNameTr' ? Number(value) || 0 : value
      };
      return updated;
    });
  };

  const handleApply = () => {
    const scadaData: BananaScadaChamberData = {
      chamberId: selectedChamberId,
      chamberType: selectedRoomConfig.type,
      ambientTemp1C: Number(ambientTemp1C) || 0,
      ambientTemp2C: Number(ambientTemp2C) || 0,
      pulpTemp1C: Number(pulpTemp1C) || 0,
      pulpTemp2C: Number(pulpTemp2C) || 0,
      ethylenePpm: Number(ethylenePpm) || 0,
      co2Ppm: Number(co2Ppm) || 0,
      humidityPercent: Number(humidityPercent) || 0,
      activeStageIndex,
      totalRunTimeHours: Number(totalRunTimeHours) || 0,
      elapsedTimeHours: Number(elapsedTimeHours) || 0,
      evaporatorFan1State: evapFan1State,
      evaporatorFan2State: evapFan2State,
      evapFinTempC: Number(evapFinTempC) || 0,
      defrostRemainingMin: Number(defrostRemainingMin) || 0,
      coolingStatusText,
      stagesMatrix: stages
    };

    onApplyScadaData(scadaData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border-2 border-amber-200 rounded-3xl w-full max-w-5xl shadow-sm overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="bg-emerald-700 hover:bg-emerald-100 p-4 border-b border-amber-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 shadow-inner">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900">
                  Siemens & Kendall SCADA • Muz Sarartma & Soğuk Hava Kontrolörü
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200 tabular-nums">
                  Plc smart line v1.0
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Endüstriyel sarartma odası sensör telemetrisi, etilen/CO2 dozajı ve 7-Aşama olgunlaştırma eğrisi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white hover:bg-slate-50 text-slate-500 hover:text-slate-900 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 text-slate-900">
          
          {/* Chamber Selector & Live Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* Chamber Selection */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
              <label className="text-xs font-bold text-amber-700 flex items-center gap-2">
                <Activity className="w-4 h-4 text-amber-700" />
                <span>Aktif SCADA Odası / Depo Seçimi</span>
              </label>
              <select
                value={selectedChamberId}
                onChange={(e) => setSelectedChamberId(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-bold focus:ring-2 focus:ring-amber-500"
              >
                {AVAILABLE_SCADA_ROOMS.map((room) => (
                  <option key={room.id} value={room.id} className="bg-white text-slate-900">
                    {room.name}
                  </option>
                ))}
              </select>

              <div className="pt-2 border-t border-slate-200/80 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span>Oda Tipi:</span>
                  <span className="font-bold text-teal-700 tabular-nums">{selectedRoomConfig.type}</span>
                </div>
                <div className="flex items-center justify-between text-slate-500">
                  <span>Referans Sıcaklık:</span>
                  <span className="font-bold text-emerald-700 tabular-nums">{selectedRoomConfig.defaultTemp}°C</span>
                </div>
                <div className="flex items-center justify-between text-slate-500">
                  <span>Program Durumu:</span>
                  <span className="font-bold text-amber-700 tabular-nums">Aşama {activeStageIndex} / 7</span>
                </div>
              </div>
            </div>

            {/* Live Telemetry Gauges */}
            <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* Pulp Temperature (果肉温度) */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-teal-200 space-y-1">
                <div className="flex items-center justify-between text-[11px] text-teal-700 font-bold">
                  <span className="flex items-center gap-1">
                    <Thermometer className="w-3.5 h-3.5 text-teal-700" />
                    <span>Meyve Eti (Pulp)</span>
                  </span>
                  <span className="tabular-nums text-[9px] bg-teal-50 px-1 rounded border border-teal-800">果肉</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.1"
                    value={pulpTemp1C}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      setPulpTemp1C(val);
                      setPulpTemp2C(val);
                    }}
                    className="w-16 tabular-nums text-xl font-bold text-teal-700 bg-transparent border-b border-teal-200 focus:outline-hidden"
                  />
                  <span className="text-xs text-teal-700 tabular-nums">°C</span>
                </div>
                <div className="text-[10px] text-slate-500">Hedef: 16.5 - 18.0°C</div>
              </div>

              {/* Room Temp 1 & 2 */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-blue-200 space-y-1">
                <div className="flex items-center justify-between text-[11px] text-blue-700 font-bold">
                  <span className="flex items-center gap-1">
                    <Thermometer className="w-3.5 h-3.5 text-blue-700" />
                    <span>Oda Ort. Sıcaklık</span>
                  </span>
                  <span className="tabular-nums text-[9px] bg-blue-50 px-1 rounded border border-blue-800">冷库</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.1"
                    value={ambientTemp1C}
                    onChange={(e) => setAmbientTemp1C(parseFloat(e.target.value) || 0)}
                    className="w-16 tabular-nums text-xl font-bold text-blue-700 bg-transparent border-b border-blue-200 focus:outline-hidden"
                  />
                  <span className="text-xs text-blue-700 tabular-nums">°C</span>
                </div>
                <div className="text-[10px] text-slate-500">Sensör 2: {ambientTemp2C}°C</div>
              </div>

              {/* Ethylene C2H4 (乙烯) */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-amber-200 space-y-1">
                <div className="flex items-center justify-between text-[11px] text-amber-700 font-bold">
                  <span className="flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-amber-700" />
                    <span>Etilen (C2H4)</span>
                  </span>
                  <span className="tabular-nums text-[9px] bg-amber-50 px-1 rounded border border-amber-800">乙烯</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.1"
                    value={ethylenePpm}
                    onChange={(e) => setEthylenePpm(parseFloat(e.target.value) || 0)}
                    className="w-16 tabular-nums text-xl font-bold text-amber-700 bg-transparent border-b border-amber-200 focus:outline-hidden"
                  />
                  <span className="text-xs text-amber-700 tabular-nums">ppm</span>
                </div>
                <div className="text-[10px] text-slate-500">Dozaj Sınırı: 700 ppm</div>
              </div>

              {/* CO2 & Humidity */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-emerald-200 space-y-1">
                <div className="flex items-center justify-between text-[11px] text-emerald-700 font-bold">
                  <span className="flex items-center gap-1">
                    <Droplets className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Bağıl Nem & CO2</span>
                  </span>
                  <span className="tabular-nums text-[9px] bg-emerald-50 px-1 rounded border border-emerald-800">湿度</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.5"
                    value={humidityPercent}
                    onChange={(e) => setHumidityPercent(parseFloat(e.target.value) || 0)}
                    className="w-14 tabular-nums text-xl font-bold text-emerald-700 bg-transparent border-b border-emerald-200 focus:outline-hidden"
                  />
                  <span className="text-xs text-emerald-700 tabular-nums">%</span>
                </div>
                <div className="text-[10px] text-slate-500">CO2: {co2Ppm} ppm</div>
              </div>
            </div>
          </div>

          {/* 7-Stage Ripening Program Curve (Siemens Matrix) */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-700" />
                <h4 className="text-xs font-bold text-amber-700">
                  7-Aşamalı Muz Sarartma Programı (Siemens Smart Line Matrix)
                </h4>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">Program Süresi:</span>
                <span className="font-bold text-teal-700 tabular-nums">{totalRunTimeHours} Saat</span>
                <span className="text-slate-500">|</span>
                <span className="text-slate-500">Geçen:</span>
                <span className="font-bold text-amber-700 tabular-nums">{elapsedTimeHours} Saat</span>
              </div>
            </div>

            {/* Matrix Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-white text-slate-600 tabular-nums text-[11px] border-b border-slate-200">
                    <th className="py-2 px-2.5">Aşama (阶段)</th>
                    <th className="py-2 px-2.5">Aşama Adı & İşlem</th>
                    <th className="py-2 px-2.5">Süre (Saat)</th>
                    <th className="py-2 px-2.5">Hedef Sıcaklık (°C)</th>
                    <th className="py-2 px-2.5">Etilen C2H4 (ppm)</th>
                    <th className="py-2 px-2.5">CO2 Limiti (ppm)</th>
                    <th className="py-2 px-2.5">Bağıl Nem (%)</th>
                    <th className="py-2 px-2.5 text-center">Durum</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 tabular-nums">
                  {stages.map((stage, idx) => {
                    const isActive = activeStageIndex === stage.stageNumber;
                    return (
                      <tr
                        key={stage.stageNumber}
                        className={`hover:bg-slate-100/60 transition ${
                          isActive ? 'bg-amber-50 border-l-4 border-amber-400' : ''
                        }`}
                      >
                        <td className="py-2 px-2.5 font-bold text-amber-700 whitespace-nowrap">
                          {stage.stageNumber}. Aşama
                        </td>
                        <td className="py-2 px-2.5 font-sans font-medium text-slate-700">
                          {stage.stageNameTr}
                        </td>
                        <td className="py-2 px-2.5">
                          <input
                            type="number"
                            value={stage.durationHours}
                            onChange={(e) => handleStageChange(idx, 'durationHours', e.target.value)}
                            className="w-14 bg-white border border-slate-200 rounded px-1.5 py-1 text-center text-teal-700 font-bold"
                          />
                        </td>
                        <td className="py-2 px-2.5">
                          <input
                            type="number"
                            step="0.5"
                            value={stage.setTempC}
                            onChange={(e) => handleStageChange(idx, 'setTempC', e.target.value)}
                            className="w-14 bg-white border border-slate-200 rounded px-1.5 py-1 text-center text-blue-700 font-bold"
                          />
                        </td>
                        <td className="py-2 px-2.5">
                          <input
                            type="number"
                            value={stage.setEthylenePpm}
                            onChange={(e) => handleStageChange(idx, 'setEthylenePpm', e.target.value)}
                            className="w-14 bg-white border border-slate-200 rounded px-1.5 py-1 text-center text-amber-700 font-bold"
                          />
                        </td>
                        <td className="py-2 px-2.5">
                          <input
                            type="number"
                            value={stage.setCo2Ppm}
                            onChange={(e) => handleStageChange(idx, 'setCo2Ppm', e.target.value)}
                            className="w-16 bg-white border border-slate-200 rounded px-1.5 py-1 text-center text-slate-600"
                          />
                        </td>
                        <td className="py-2 px-2.5">
                          <input
                            type="number"
                            value={stage.setHumidityPercent}
                            onChange={(e) => handleStageChange(idx, 'setHumidityPercent', e.target.value)}
                            className="w-14 bg-white border border-slate-200 rounded px-1.5 py-1 text-center text-emerald-700 font-bold"
                          />
                        </td>
                        <td className="py-2 px-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => setActiveStageIndex(stage.stageNumber)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer ${
                              isActive
                                ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                                : 'bg-white text-slate-500 hover:text-slate-900'
                            }`}
                          >
                            {isActive ? '▶ AKTİF' : 'Seç'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Evaporator & Cold Store Mechanical Controls */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-2">
              <span className="font-bold text-slate-600 flex items-center gap-1.5">
                <Wind className="w-4 h-4 text-teal-700" />
                <span>Evaporatör Fan Durumu</span>
              </span>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={evapFan1State}
                    onChange={(e) => setEvapFan1State(e.target.checked)}
                    className="rounded text-teal-600 focus:ring-teal-500"
                  />
                  <span>Fan 1 (Açık)</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={evapFan2State}
                    onChange={(e) => setEvapFan2State(e.target.checked)}
                    className="rounded text-teal-600 focus:ring-teal-500"
                  />
                  <span>Fan 2 (Açık)</span>
                </label>
              </div>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-slate-600 flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-blue-700" />
                <span>Kanatçık (Fin) & Defrost</span>
              </span>
              <div className="flex items-center gap-3">
                <span>Fin: <strong className="tabular-nums text-teal-700">{evapFinTempC}°C</strong></span>
                <span>Defrost: <strong className="tabular-nums text-amber-700">{defrostRemainingMin} Dk</strong></span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="font-bold text-slate-600">SCADA Durum Bildirimi</span>
              <input
                type="text"
                value={coolingStatusText}
                onChange={(e) => setCoolingStatusText(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-900"
              />
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-600 text-xs font-bold transition cursor-pointer"
          >
            İptal
          </button>

          <button
            type="button"
            onClick={handleApply}
            className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-100 text-slate-950 font-bold text-xs shadow-sm shadow-amber-500/20 transition cursor-pointer flex items-center gap-2 active:scale-98"
          >
            <ShieldCheck className="w-4 h-4 text-slate-950" />
            <span>SCADA Parametrelerini Hasat Kaydına Bağla ve Kaydet</span>
          </button>
        </div>

      </div>
    </div>
  );
};
