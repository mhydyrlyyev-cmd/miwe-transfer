import React, { useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Search, FlaskConical, FileText, Info, Snowflake } from 'lucide-react';
import { FieldRecord, ReferenceItem } from '../../types';
import { evaluateBatchQualityRisk, BatchQualityRiskAssessment } from '../../utils/qualityStandards';
import { findStandard } from '../../config/standardsCatalog';
import { cleanName } from '../../utils/qrRef';
import { Stat, ListRow, Meter, Badge, Card } from '../ui';

/**
 * v46 — Kalite (ana sayfa tasarım dili)
 * Üstte 3 sayı (uygun / sınırda / uygun değil), altında "Bekleyen karar" listesi ve ürüne göre sonuç.
 * Her kural kaynağını yazar (UNECE/OECD ya da iç hedef); ölçülmeyen değer sonuca girmez.
 * Eski 7 günlük tonaj–kalite grafiği ve otomatik Freeze-Dry bandı v45'te kaldırıldı.
 */
interface QualityInsightCardProps {
  fieldRecords: FieldRecord[];
  references?: ReferenceItem[];
  onSelectReference?: (refId: string) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onOpenTraceability?: (ref: ReferenceItem) => void;
  onOpenFieldTest?: (refId: string) => void;
  isCompact?: boolean;
  defaultExpanded?: boolean;
  onNavigateToAnalytics?: () => void;
  onNavigateToRecords?: () => void;
}

type Level = BatchQualityRiskAssessment['riskLevel'];
const LEVEL: Record<Level, { label: string; dot: 'error' | 'warn' | 'ok'; tone: 'error' | 'warn' | 'ok' }> = {
  CRITICAL: { label: 'Uygun değil', dot: 'error', tone: 'error' },
  WARNING: { label: 'Sınırda', dot: 'warn', tone: 'warn' },
  SAFE: { label: 'Uygun', dot: 'ok', tone: 'ok' },
};

function QualityInsightCardInner({
  fieldRecords = [], references = [], onSelectReference, onRerouteToFreezeDry, onOpenTraceability, onOpenFieldTest,
  isCompact = false, defaultExpanded = false,
}: QualityInsightCardProps) {
  const [open, setOpen] = useState(defaultExpanded);
  const [filter, setFilter] = useState<Level | 'PENDING'>('PENDING');
  const [q, setQ] = useState('');
  const [openRow, setOpenRow] = useState<string | null>(null);
  const [confirmFd, setConfirmFd] = useState<string | null>(null);

  const refMap = useMemo(() => new Map(references.map(r => [r.refId, r])), [references]);
  const rows = useMemo(() => fieldRecords.map(rec => evaluateBatchQualityRisk(rec, refMap.get(rec.refId))), [fieldRecords, refMap]);
  const counts = useMemo(() => ({
    SAFE: rows.filter(r => r.riskLevel === 'SAFE').length,
    WARNING: rows.filter(r => r.riskLevel === 'WARNING').length,
    CRITICAL: rows.filter(r => r.riskLevel === 'CRITICAL').length,
  }), [rows]);

  const shown = useMemo(() => {
    const s = q.trim().toLocaleLowerCase('tr');
    return rows
      .filter(r => (filter === 'PENDING' ? r.riskLevel !== 'SAFE' : r.riskLevel === filter))
      .filter(r => !s || [r.refId, r.product, r.variety, r.orchard || ''].some(x => String(x).toLocaleLowerCase('tr').includes(s)))
      .sort((a, b) => (a.riskLevel === b.riskLevel ? a.healthScore - b.healthScore : a.riskLevel === 'CRITICAL' ? -1 : 1));
  }, [rows, filter, q]);

  const byProduct = useMemo(() => {
    const m = new Map<string, { ok: number; total: number }>();
    rows.forEach(r => {
      const k = cleanName(r.product) || 'Belirtilmemiş';
      const x = m.get(k) || { ok: 0, total: 0 };
      x.total += 1; if (r.riskLevel === 'SAFE') x.ok += 1;
      m.set(k, x);
    });
    return [...m.entries()].sort((a, b) => b[1].total - a[1].total).slice(0, 8);
  }, [rows]);

  if (fieldRecords.length === 0) return null;

  return (
    <section id="quality-insight-card" className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden ${isCompact ? 'mb-3' : 'mb-6'}`}>
      <button type="button" onClick={() => setOpen(v => !v)} aria-expanded={open}
        className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left cursor-pointer">
        <div className="min-w-0">
          <h2 className="text-[15px] font-bold text-slate-900 dark:text-white">Kalite</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">{counts.SAFE} uygun · {counts.WARNING} sınırda · {counts.CRITICAL} uygun değil</p>
        </div>
        {open ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
      </button>

      {open && (
        <div className="px-3 pb-4 space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <Stat label="Uygun" value={counts.SAFE} tone="ok" onClick={() => setFilter(filter === 'SAFE' ? 'PENDING' : 'SAFE')} active={filter === 'SAFE'} />
            <Stat label="Sınırda" value={counts.WARNING} tone="warn" onClick={() => setFilter(filter === 'WARNING' ? 'PENDING' : 'WARNING')} active={filter === 'WARNING'} />
            <Stat label="Uygun değil" value={counts.CRITICAL} tone="error" onClick={() => setFilter(filter === 'CRITICAL' ? 'PENDING' : 'CRITICAL')} active={filter === 'CRITICAL'} />
          </div>

          <label className="flex items-center gap-2 px-3 min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900">
            <Search className="w-4 h-4 text-slate-400" aria-hidden="true" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Parti, ürün, bahçe ara" className="flex-1 bg-transparent text-sm outline-none text-slate-900 dark:text-white" />
          </label>

          <Card padding="md" title={filter === 'PENDING' ? 'Bekleyen karar' : LEVEL[filter].label} subtitle={filter === 'PENDING' ? 'Önce bunlara bakın' : `${shown.length} parti`}>
            {shown.length === 0 && <p className="text-sm text-slate-500 py-2">{filter === 'PENDING' ? 'Karar bekleyen parti yok.' : 'Bu grupta parti yok.'}</p>}
            {shown.slice(0, 40).map(r => {
              const L = LEVEL[r.riskLevel];
              const first = r.triggeredRules[0];
              const ref = refMap.get(r.refId);
              const isOpen = openRow === r.recordId;
              return (
                <ListRow key={r.recordId} dot={L.dot}
                  title={`${r.refId} · ${cleanName(r.variety) || cleanName(r.product)}`}
                  sub={first ? `${first.ruleName} · ${first.currentValue} / ${first.thresholdValue}` : `${cleanName(r.product)} · ${cleanName(r.orchard || r.location || '')}`}
                  right={<Badge tone={L.tone}>{r.riskLevel === 'CRITICAL' ? 'Yeniden test' : L.label}</Badge>}
                  onClick={() => setOpenRow(isOpen ? null : r.recordId)}>
                  {isOpen && (
                    <div className="mt-2 ml-5 space-y-2">
                      {r.triggeredRules.length > 0 && (
                        <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-0.5">
                          {r.triggeredRules.map((x, i) => <li key={i}>• {x.ruleName}: {x.currentValue} ({x.thresholdValue})</li>)}
                        </ul>
                      )}
                      <p className="text-xs text-slate-600 dark:text-slate-300">{r.recommendedAction}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {onOpenFieldTest && <button type="button" onClick={() => onOpenFieldTest(r.refId)} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-emerald-700 cursor-pointer"><FlaskConical className="w-3.5 h-3.5" />Yeni test</button>}
                        {onOpenTraceability && ref && <button type="button" onClick={() => onOpenTraceability(ref)} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"><FileText className="w-3.5 h-3.5" />Pasaport</button>}
                        {onSelectReference && <button type="button" onClick={() => onSelectReference(r.refId)} className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer">Kaydı aç</button>}
                        {onRerouteToFreezeDry && r.actionType === 'FREEZE_DRY' && (
                          confirmFd === r.refId
                            ? <button type="button" onClick={() => { onRerouteToFreezeDry(r.refId, 'Doğrulanmış kalite sonucu: standart altı'); setConfirmFd(null); }} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-700 text-white text-xs font-semibold cursor-pointer"><Snowflake className="w-3.5 h-3.5" />Onayla: Freeze-Dry</button>
                            : <button type="button" onClick={() => setConfirmFd(r.refId)} className="px-2.5 py-1.5 rounded-lg border border-cyan-200 text-xs font-semibold text-cyan-800 cursor-pointer">Freeze-Dry'a yönlendir</button>
                        )}
                      </div>
                    </div>
                  )}
                </ListRow>
              );
            })}
          </Card>

          {byProduct.length > 0 && (
            <Card padding="md" title="Ürüne göre sonuç" subtitle="Her ürün kendi standardına göre">
              {byProduct.map(([name, x]) => {
                const std = findStandard(name);
                const src = std && std.status === 'VERIFIED' ? std.code : 'iç hedef';
                return <Meter key={name} label={`${name} (${src})`} value={x.ok} max={x.total} color={x.ok / Math.max(1, x.total) >= 0.75 ? '#2F7D3A' : '#B7791F'} note={`${x.ok}/${x.total} uygun`} />;
              })}
            </Card>
          )}

          <p className="flex items-start gap-2 text-[11px] text-slate-500 px-1"><Info className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />Etiket kaynağı gösterir: UNECE/OECD = resmî standart, iç hedef = işletme kuralı. Ölçülmeyen değer sonuca girmez.</p>
        </div>
      )}
    </section>
  );
}

/** Hata sınırı: kalite paneli çökerse sayfanın geri kalanı çalışmaya devam eder. */
export class QualityInsightCard extends React.Component<QualityInsightCardProps, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(err: unknown) { console.error('[QualityInsightCard]', err); }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-3 mb-3 rounded-2xl border border-amber-200 bg-amber-50 text-xs text-amber-900 flex items-center justify-between gap-2">
          <span>Kalite paneli yüklenemedi.</span>
          <button type="button" onClick={() => this.setState({ hasError: false })} className="px-2.5 py-1 rounded-lg bg-white border border-amber-200 font-semibold cursor-pointer">Yeniden dene</button>
        </div>
      );
    }
    return <QualityInsightCardInner {...this.props} />;
  }
}

export default QualityInsightCard;
