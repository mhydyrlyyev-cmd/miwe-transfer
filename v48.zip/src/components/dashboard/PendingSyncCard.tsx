import React, { useState } from 'react';
import {
  CloudOff,
  Cloud,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Clock,
  Camera,
  Layers,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Wifi,
  WifiOff,
  ExternalLink
} from 'lucide-react';

interface PendingSyncCardProps {
  offlineQueue: Array<{ action: string; payload: any; timestamp?: string }>;
  isOnline: boolean;
  isSyncing: boolean;
  onSyncAll: () => void;
  onSyncSingle: (index: number) => void;
  onDeleteItem: (index: number) => void;
  onEditItem?: (item: any) => void;
}

interface ModuleMeta {
  label: string;
  emoji: string;
  colorClass: string;
  badgeClass: string;
}

export const PendingSyncCard: React.FC<PendingSyncCardProps> = ({
  offlineQueue = [],
  isOnline,
  isSyncing,
  onSyncAll,
  onSyncSingle,
  onDeleteItem,
  onEditItem
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [selectedModuleFilter, setSelectedModuleFilter] = useState<string>('ALL');

  const getModuleMeta = (moduleKey?: string): ModuleMeta => {
    switch (moduleKey?.toUpperCase()) {
      case 'HARVEST':
        return {
          label: 'Günlük Hasat',
          emoji: '🌿',
          colorClass: 'border-emerald-300 bg-emerald-50/60 text-emerald-950',
          badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300'
        };
      case 'LOJISTIK':
        return {
          label: 'Lojistik & Delilnama',
          emoji: '🚚',
          colorClass: 'border-blue-300 bg-blue-50/60 text-blue-950',
          badgeClass: 'bg-blue-100 text-blue-800 border-blue-300'
        };
      case 'FIELD':
        return {
          label: 'Meyve Kalite Testi',
          emoji: '🍎',
          colorClass: 'border-rose-300 bg-rose-50/60 text-rose-950',
          badgeClass: 'bg-rose-100 text-rose-800 border-rose-300'
        };
      case 'MUZ':
        return {
          label: 'Muz Kalite Kontrol',
          emoji: '🍌',
          colorClass: 'border-amber-300 bg-amber-50/60 text-amber-950',
          badgeClass: 'bg-amber-100 text-amber-800 border-amber-300'
        };
      case 'BADEM':
        return {
          label: 'Badem Test & Randıman',
          emoji: '🥜',
          colorClass: 'border-orange-300 bg-orange-50/60 text-orange-950',
          badgeClass: 'bg-orange-100 text-orange-800 border-orange-300'
        };
      case 'AMBAR':
        return {
          label: 'Ambar Kabul & Depo',
          emoji: '🏭',
          colorClass: 'border-teal-300 bg-teal-50/60 text-teal-950',
          badgeClass: 'bg-teal-100 text-teal-800 border-teal-300'
        };
      case 'FREEZE_DRY':
        return {
          label: 'Freeze-Dry Liyofilizasyon',
          emoji: '❄️',
          colorClass: 'border-cyan-300 bg-cyan-50/60 text-cyan-950',
          badgeClass: 'bg-cyan-100 text-cyan-800 border-cyan-300'
        };
      case 'EXPORT_SAMPLE':
        return {
          label: 'Eksport Numune',
          emoji: '🌐',
          colorClass: 'border-indigo-300 bg-indigo-50/60 text-indigo-950',
          badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-300'
        };
      case 'SALES':
        return {
          label: 'Satış & Sevkiyat',
          emoji: '🛍️',
          colorClass: 'border-purple-300 bg-purple-50/60 text-purple-950',
          badgeClass: 'bg-purple-100 text-purple-800 border-purple-300'
        };
      case 'INCIDENT':
        return {
          label: 'Barlag Akty & DÖF',
          emoji: '⚠️',
          colorClass: 'border-red-300 bg-red-50/60 text-red-950',
          badgeClass: 'bg-red-100 text-red-800 border-red-300'
        };
      default:
        return {
          label: moduleKey || 'Genel Kayıt',
          emoji: '📋',
          colorClass: 'border-slate-300 bg-slate-50/70 text-slate-900',
          badgeClass: 'bg-slate-100 text-slate-800 border-slate-300'
        };
    }
  };

  const getRecordTitle = (item: any) => {
    const p = item.payload;
    if (!p) return 'Kayıt';
    const rec = p.record || p;
    const ref = p.newRefData || {};
    return (
      rec.refId ||
      rec.delilnamaNo ||
      rec.lotNo ||
      ref.refId ||
      rec.id ||
      'KAYIT'
    );
  };

  const getRecordSummary = (item: any) => {
    const p = item.payload;
    if (!p) return '';
    const rec = p.record || p;
    const ref = p.newRefData || {};
    const parts = [];

    if (rec.product || ref.product) parts.push(rec.product || ref.product);
    if (rec.variety) parts.push(rec.variety);
    if (rec.operator) parts.push(`Operatör: ${rec.operator}`);
    if (rec.dailyTotalKg) parts.push(`${rec.dailyTotalKg} kg`);
    else if (rec.weightKg) parts.push(`${rec.weightKg} kg`);
    else if (rec.acceptedWeightKg) parts.push(`${rec.acceptedWeightKg} kg`);
    else if (rec.totalLoadKg) parts.push(`${rec.totalLoadKg} kg`);

    return parts.join(' • ');
  };

  const getPhotoCount = (item: any) => {
    const p = item.payload;
    if (!p) return 0;
    const rec = p.record || p;
    if (Array.isArray(rec.photos)) return rec.photos.length;
    if (rec.photoUrl) return 1;
    return 0;
  };

  // Group items by moduleKey
  const groupedItems = React.useMemo(() => {
    const groups: { [key: string]: { items: Array<{ item: any; originalIndex: number }>; meta: ModuleMeta } } = {};

    offlineQueue.forEach((item, index) => {
      const rawModule = item.payload?.moduleKey || item.action?.replace('submit', '').toUpperCase() || 'GENEL';
      const key = rawModule.toUpperCase();
      if (!groups[key]) {
        groups[key] = {
          items: [],
          meta: getModuleMeta(key)
        };
      }
      groups[key].items.push({ item, originalIndex: index });
    });

    return groups;
  }, [offlineQueue]);

  const groupKeys = Object.keys(groupedItems);
  const totalPhotosWaiting = offlineQueue.reduce((acc, curr) => acc + getPhotoCount(curr), 0);

  // If no items in queue, show an elegant compact synced indicator
  if (offlineQueue.length === 0) {
    return (
      <div className="bg-white border border-emerald-200/90 rounded-2xl p-3.5 shadow-xs mb-6 transition">
        <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-800 font-semibold">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600"></span>
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Saha Senkronizasyon Durumu: <strong>Tüm Veriler Güncel & Senkronize</strong></span>
          </div>
          <div className="flex items-center gap-3 text-slate-500 text-[11px]">
            <span className="flex items-center gap-1">
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-medium">Çevrimiçi (Online)</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-600" />
                  <span className="text-amber-700 font-medium">Çevrimdışı (Offline Mod)</span>
                </>
              )}
            </span>
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded tabular-nums font-bold">
              0 Bekleyen Kayıt
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-amber-200/90 rounded-2xl shadow-xs overflow-hidden mb-6 transition">
      {/* Top Header Bar */}
      <div className="p-4 bg-white border-b border-amber-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-50 border border-amber-200/80 rounded-xl text-amber-700">
            <CloudOff className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Bekleyen Senkronizasyonlar Listesi
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                {offlineQueue.length} Kayıt Bekliyor
              </span>
              {totalPhotosWaiting > 0 && (
                <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                  <Camera className="w-3 h-3 text-slate-500" />
                  <span>{totalPhotosWaiting} Fotoğraf</span>
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Çevrimdışı sahada girilen kayıtlar modül bazlı gruplandırılmıştır. İnternet bağlantınız sağlandığında tek tıkla aktarın.
            </p>
          </div>
        </div>

        {/* Sync All Button & Controls */}
        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          <button
            type="button"
            onClick={onSyncAll}
            disabled={isSyncing}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs rounded-xl shadow-xs transition active:scale-95 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-white ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Senkronize Ediliyor...' : 'Tümünü Senkronize Et'}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition cursor-pointer"
            title={isExpanded ? 'Daralt' : 'Genişlet'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expandable Module Groups Body */}
      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4 bg-slate-50/50">
          
          {/* Quick Filter Bar */}
          <div className="flex items-center justify-between gap-2 flex-wrap border-b border-slate-200 pb-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-bold text-slate-700 mr-1">Modül Filtresi:</span>
              <button
                type="button"
                onClick={() => setSelectedModuleFilter('ALL')}
                className={`text-xs px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                  selectedModuleFilter === 'ALL'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Tümü ({offlineQueue.length})
              </button>
              {groupKeys.map(k => {
                const grp = groupedItems[k];
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setSelectedModuleFilter(k)}
                    className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                      selectedModuleFilter === k
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    <span>{grp.meta.emoji}</span>
                    <span>{grp.meta.label}</span>
                    <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-100 text-slate-800 tabular-nums font-bold">
                      {grp.items.length}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              {isOnline ? (
                <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                  <Wifi className="w-3 h-3 text-emerald-600" />
                  <span>Bağlantı Aktif</span>
                </span>
              ) : (
                <span className="flex items-center gap-1 text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md">
                  <WifiOff className="w-3 h-3 text-rose-600" />
                  <span>Çevrimdışı</span>
                </span>
              )}
            </div>
          </div>

          {/* Module Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groupKeys
              .filter(k => selectedModuleFilter === 'ALL' || selectedModuleFilter === k)
              .map(moduleKey => {
                const grp = groupedItems[moduleKey];

                return (
                  <div
                    key={moduleKey}
                    className={`rounded-xl border shadow-xs overflow-hidden flex flex-col bg-white ${grp.meta.colorClass}`}
                  >
                    {/* Card Top Title */}
                    <div className="p-3 border-b flex items-center justify-between gap-2 bg-white/80">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{grp.meta.emoji}</span>
                        <span className="text-xs font-bold text-slate-900 font-serif">
                          {grp.meta.label}
                        </span>
                      </div>
                      <span className={`text-[11px] tabular-nums font-bold px-2 py-0.5 rounded-md border ${grp.meta.badgeClass}`}>
                        {grp.items.length} bekliyor
                      </span>
                    </div>

                    {/* Records List */}
                    <div className="divide-y divide-slate-100 flex-1 max-h-64 overflow-y-auto">
                      {grp.items.map(({ item, originalIndex }) => {
                        const title = getRecordTitle(item);
                        const summary = getRecordSummary(item);
                        const photoCount = getPhotoCount(item);
                        const ts = item.timestamp || item.payload?.record?.timestamp || item.payload?.timestamp;
                        const timeStr = ts ? new Date(ts).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : 'Şimdi';

                        return (
                          <div
                            key={originalIndex}
                            className="p-2.5 hover:bg-slate-50/90 transition flex items-center justify-between gap-2"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="tabular-nums font-bold text-xs text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                                  {title}
                                </span>
                                <span className="text-[10px] text-slate-400 tabular-nums">
                                  {timeStr}
                                </span>
                                {photoCount > 0 && (
                                  <span className="text-[10px] font-bold text-teal-700 bg-teal-50 border border-teal-200 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                                    <Camera className="w-2.5 h-2.5" />
                                    <span>{photoCount} foto</span>
                                  </span>
                                )}
                              </div>
                              {summary && (
                                <p className="text-[11px] text-slate-600 truncate mt-0.5 font-medium">
                                  {summary}
                                </p>
                              )}
                            </div>

                            {/* Item Actions */}
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => onSyncSingle(originalIndex)}
                                disabled={isSyncing}
                                title="Sadece Bu Kaydı Senkronize Et"
                                className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition cursor-pointer disabled:opacity-50"
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => onDeleteItem(originalIndex)}
                                title="Kuyruktan Sil"
                                className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Card Footer */}
                    <div className="p-2 bg-slate-50 border-t border-slate-200/60 text-[10px] text-slate-500 flex items-center justify-between">
                      <span>Grup: {grp.meta.label}</span>
                      <span className="tabular-nums font-bold text-slate-700">{grp.items.length} adet işlem</span>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* Bottom Summary Bar */}
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2 font-medium">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                Cihaz yerel hafızasında (IndexedDB/LocalStorage) güvenle tutulmaktadır. Tarayıcıyı kapatsanız dahi veriler kaybolmaz.
              </span>
            </div>
            <button
              type="button"
              onClick={onSyncAll}
              disabled={isSyncing}
              className="text-xs font-bold text-amber-900 underline hover:text-amber-950 flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <span>{isSyncing ? 'Aktarılıyor...' : 'Şimdi Buluta Aktar →'}</span>
            </button>
          </div>

        </div>
      )}
    </div>
  );
};
