import React, { useState, useMemo, useEffect } from 'react';
import { 
  AlertTriangle, 
  Warehouse, 
  TrendingDown, 
  Layers, 
  Sliders, 
  ArrowRight, 
  PlusCircle, 
  CheckCircle2, 
  PackageCheck, 
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Boxes,
  BellRing
} from 'lucide-react';
import { AmbarRecord, LojistikRecord, SalesRecord, ReferenceItem, ModuleKey } from '../../types';
import { addNotification } from '../../utils/notificationService';

interface CriticalStockAlertCardProps {
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  references: ReferenceItem[];
  onSelectModule: (moduleKey: ModuleKey, action?: 'NEW' | 'EXISTING') => void;
  onOpenAnalytics?: () => void;
  currentUserId?: string;
}

export interface StockProductSummary {
  product: string;
  variety: string;
  warehouse: string;
  roomNo: string;
  totalAcceptedKg: number;
  totalDispatchedKg: number;
  currentStockKg: number;
  currentStockTons: number;
  thresholdKg: number;
  stockPercentage: number;
  status: 'CRITICAL_URGENT' | 'LOW_WARNING' | 'SAFE';
  lastAcceptanceDate: string;
  refCount: number;
}

export const CriticalStockAlertCard: React.FC<CriticalStockAlertCardProps> = ({
  ambarRecords,
  lojistikRecords,
  salesRecords,
  references,
  onSelectModule,
  onOpenAnalytics,
  currentUserId = 'anonymous'
}) => {
  // Threshold state (default 5,000 kg = 5 Tons)
  const [thresholdKg, setThresholdKg] = useState<number>(() => {
    const saved = localStorage.getItem('miwe_critical_stock_threshold');
    return saved ? Number(saved) : 5000;
  });

  const [filterType, setFilterType] = useState<'ALL' | 'CRITICAL_ONLY' | 'SAFE_ONLY'>('ALL');
  const [isExpanded, setIsExpanded] = useState(true);
  const [lastNotificationSent, setLastNotificationSent] = useState<string | null>(null);

  // Save threshold change
  const handleThresholdChange = (val: number) => {
    const num = Math.max(100, val);
    setThresholdKg(num);
    localStorage.setItem('miwe_critical_stock_threshold', String(num));
  };

  // Map references for quick lookup
  const refMap = useMemo(() => {
    const map = new Map<string, ReferenceItem>();
    references.forEach(r => map.set(r.refId, r));
    return map;
  }, [references]);

  // Aggregate stock data from Ambar, Lojistik, Sales
  const { stockList, totalStockKg, criticalCount, lowCount, safeCount } = useMemo(() => {
    // 1. Group accepted ambar weights by Product + Variety + Warehouse
    const grouped = new Map<string, {
      product: string;
      variety: string;
      warehouse: string;
      roomNo: string;
      acceptedKg: number;
      lastDate: string;
      refs: Set<string>;
    }>();

    // Cold-Start Mode: Only process real ambarRecords (no fake sample records)
    const recordsToProcess = ambarRecords;

    recordsToProcess.forEach(a => {
      const parentRef = refMap.get(a.refId);
      const prodName = parentRef?.product || 'Meyve';
      const variety = prodName.includes('(') ? prodName.split('(')[1].replace(')', '').trim() : 'Standart';
      const cleanProd = prodName.replace(/\(.*\)/, '').trim();
      const warehouse = a.warehouse || 'Merkez Depo';
      const key = `${cleanProd}__${variety}__${warehouse}`;

      if (!grouped.has(key)) {
        grouped.set(key, {
          product: cleanProd,
          variety,
          warehouse,
          roomNo: a.roomNo || 'Oda 1',
          acceptedKg: 0,
          lastDate: a.acceptanceDate || (a.timestamp ? String(a.timestamp).slice(0, 10) : ''),
          refs: new Set()
        });
      }

      const entry = grouped.get(key)!;
      entry.acceptedKg += (a.acceptedWeightKg || 0);
      entry.refs.add(a.refId);
      if (a.acceptanceDate && a.acceptanceDate > entry.lastDate) {
        entry.lastDate = a.acceptanceDate;
      }
    });

    // 2. Calculate exit / sales / dispatched weight per product
    const dispatchedMap = new Map<string, number>();
    salesRecords.forEach(s => {
      // Find matching product
      const parentRef = refMap.get(s.refId);
      const prod = parentRef?.product || s.product || '';
      const cleanProd = prod.replace(/\(.*\)/, '').trim();
      if (cleanProd) {
        dispatchedMap.set(cleanProd, (dispatchedMap.get(cleanProd) || 0) + (s.totalQuantityKg || 0));
      }
    });

    // Build the final summary array
    const list: StockProductSummary[] = [];
    let grandTotalKg = 0;
    let crit = 0;
    let low = 0;
    let safe = 0;

    grouped.forEach((val) => {
      const dispatched = dispatchedMap.get(val.product) || 0;
      const currentKg = Math.max(0, val.acceptedKg - dispatched);
      const currentTons = Number((currentKg / 1000).toFixed(2));
      grandTotalKg += currentKg;

      const percentage = Math.min(100, Math.round((currentKg / thresholdKg) * 100));

      let status: StockProductSummary['status'] = 'SAFE';
      if (currentKg < thresholdKg * 0.5) {
        status = 'CRITICAL_URGENT';
        crit++;
      } else if (currentKg < thresholdKg) {
        status = 'LOW_WARNING';
        low++;
      } else {
        safe++;
      }

      list.push({
        product: val.product,
        variety: val.variety,
        warehouse: val.warehouse,
        roomNo: val.roomNo,
        totalAcceptedKg: val.acceptedKg,
        totalDispatchedKg: dispatched,
        currentStockKg: currentKg,
        currentStockTons: currentTons,
        thresholdKg,
        stockPercentage: percentage,
        status,
        lastAcceptanceDate: val.lastDate,
        refCount: val.refs.size
      });
    });

    // Sort by most critical first (lowest percentage)
    list.sort((a, b) => a.currentStockKg - b.currentStockKg);

    return {
      stockList: list,
      totalStockKg: grandTotalKg,
      criticalCount: crit,
      lowCount: low,
      safeCount: safe
    };
  }, [ambarRecords, salesRecords, references, refMap, thresholdKg]);

  // Push critical notification if urgent items detected
  useEffect(() => {
    if (criticalCount > 0) {
      const urgentItems = stockList.filter(s => s.status === 'CRITICAL_URGENT');
      const firstItem = urgentItems[0];
      const notifKey = `${firstItem?.product}-${firstItem?.currentStockKg}-${thresholdKg}`;
      
      if (lastNotificationSent !== notifKey) {
        addNotification(
          currentUserId,
          `🚨 Kritik Stok Uyarısı: ${firstItem.product} (${firstItem.currentStockKg.toLocaleString('tr-TR')} kg)`,
          `${firstItem.warehouse} (${firstItem.roomNo}) içerisinde ${firstItem.product} stoğu belirlenen ${thresholdKg.toLocaleString('tr-TR')} kg eşiğinin altına düşmüştür (${firstItem.currentStockKg.toLocaleString('tr-TR')} kg kaldı). Lütfen yeni hasat/tedarik planlayın.`,
          'CRITICAL_ALERT',
          'DASHBOARD'
        );
        setLastNotificationSent(notifKey);
      }
    }
  }, [criticalCount, stockList, thresholdKg, currentUserId, lastNotificationSent]);

  // Filtered display list
  const filteredList = useMemo(() => {
    if (filterType === 'CRITICAL_ONLY') {
      return stockList.filter(s => s.status === 'CRITICAL_URGENT' || s.status === 'LOW_WARNING');
    }
    if (filterType === 'SAFE_ONLY') {
      return stockList.filter(s => s.status === 'SAFE');
    }
    return stockList;
  }, [stockList, filterType]);

  const presetThresholds = [2500, 5000, 7500, 10000];

  return (
    <div className="w-full bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
      
      {/* 1. Header & Quick Controls */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-500/10 via-rose-500/5 to-transparent dark:from-amber-950/30 dark:via-rose-950/20 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Left: Title & Status Badges */}
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 shrink-0">
            <AlertTriangle className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100">
                Ambar Kritik Stok Uyarıları
              </h3>
              {criticalCount > 0 ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white shadow-xs animate-pulse">
                  {criticalCount} Acil Kritik
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Stoklar Güvende
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Soğuk hava deposu ve ambar bazında güvenlik stoğu kontrolü (Eşik: {thresholdKg.toLocaleString('tr-TR')} kg)
            </p>
          </div>
        </div>

        {/* Right: Controls & Threshold Selector */}
        <div className="flex items-center gap-2.5 self-end sm:self-auto flex-wrap">
          
          {/* Preset Buttons */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl border border-slate-200 dark:border-slate-700/60 text-xs">
            <span className="text-[10px] font-bold text-slate-400 px-2 hidden md:inline">Eşik:</span>
            {presetThresholds.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => handleThresholdChange(preset)}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                  thresholdKg === preset
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {preset >= 1000 ? `${preset / 1000}T` : `${preset}kg`}
              </button>
            ))}
          </div>

          {/* Toggle Expand / Collapse */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition cursor-pointer"
            title={isExpanded ? 'Daralt' : 'Genişlet'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

      </div>

      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4">
          
          {/* 2. Key Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            
            <div className="bg-slate-50 dark:bg-slate-950/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] font-bold text-slate-400 block">Toplam Depo Stoğu</span>
              <p className="text-lg font-bold text-slate-800 dark:text-slate-100 tabular-nums mt-0.5">
                {(totalStockKg / 1000).toFixed(1)} <span className="text-xs font-sans font-bold text-slate-500">Ton</span>
              </p>
            </div>

            <div className="bg-rose-50/60 dark:bg-rose-950/20 p-3 rounded-xl border border-rose-100 dark:border-rose-900/40">
              <span className="text-[10px] font-bold text-rose-500 block">Kritik Seviye (&lt; %50)</span>
              <p className="text-lg font-bold text-rose-600 dark:text-rose-400 tabular-nums mt-0.5">
                {criticalCount} <span className="text-xs font-sans font-bold text-rose-400">Ürün</span>
              </p>
            </div>

            <div className="bg-amber-50/60 dark:bg-amber-950/20 p-3 rounded-xl border border-amber-100 dark:border-amber-900/40">
              <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 block">Eşik Altı (&lt; Eşik)</span>
              <p className="text-lg font-bold text-amber-600 dark:text-amber-400 tabular-nums mt-0.5">
                {lowCount} <span className="text-xs font-sans font-bold text-amber-400">Ürün</span>
              </p>
            </div>

            <div className="bg-emerald-50/60 dark:bg-emerald-950/20 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/40">
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 block">Güvenli Stok</span>
              <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
                {safeCount} <span className="text-xs font-sans font-bold text-emerald-400">Ürün</span>
              </p>
            </div>

          </div>

          {/* 3. Filter Tabs */}
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setFilterType('ALL')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filterType === 'ALL'
                    ? 'bg-slate-800 dark:bg-slate-200 text-white dark:text-slate-900'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                Tümü ({stockList.length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('CRITICAL_ONLY')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filterType === 'CRITICAL_ONLY'
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-500 hover:text-rose-600'
                }`}
              >
                🚨 Sadece Kritik & Uyarı ({criticalCount + lowCount})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('SAFE_ONLY')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filterType === 'SAFE_ONLY'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-500 hover:text-emerald-600'
                }`}
              >
                ✅ Güvenli ({safeCount})
              </button>
            </div>

            {onOpenAnalytics && (
              <button
                type="button"
                onClick={onOpenAnalytics}
                className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Soğuk Oda Detayları</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 4. Product Stock Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredList.length === 0 ? (
              <div className="col-span-full py-8 text-center text-slate-400 text-xs">
                Seçili filtreye uygun ürün kaydı bulunamadı.
              </div>
            ) : (
              filteredList.map((item, idx) => {
                const isUrgent = item.status === 'CRITICAL_URGENT';
                const isLow = item.status === 'LOW_WARNING';
                
                return (
                  <div
                    key={`${item.product}-${item.variety}-${idx}`}
                    className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                      isUrgent
                        ? 'bg-rose-50/30 dark:bg-rose-950/10 border-rose-200 dark:border-rose-900/50 shadow-xs'
                        : isLow
                        ? 'bg-amber-50/20 dark:bg-amber-950/10 border-amber-200 dark:border-amber-900/40'
                        : 'bg-slate-50/40 dark:bg-slate-950/30 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      {/* Card Top: Title & Badge */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                            {item.product}
                            {item.variety && (
                              <span className="text-[10px] font-normal px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                                {item.variety}
                              </span>
                            )}
                          </h4>
                          <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 truncate max-w-[200px]" title={item.warehouse}>
                            <Warehouse className="w-3 h-3 text-slate-400 shrink-0" />
                            {item.warehouse} ({item.roomNo})
                          </span>
                        </div>

                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold shrink-0 ${
                          isUrgent
                            ? 'bg-rose-500 text-white animate-pulse'
                            : isLow
                            ? 'bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-700'
                            : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                        }`}>
                          {isUrgent ? 'Kritik Acil' : isLow ? 'Düşük Stok' : 'Yeterli'}
                        </span>
                      </div>

                      {/* Stock Quantity & Visual Progress Bar */}
                      <div className="mt-3 space-y-1.5">
                        <div className="flex items-baseline justify-between text-xs tabular-nums">
                          <span className="font-bold text-slate-800 dark:text-slate-100 text-base">
                            {item.currentStockKg.toLocaleString('tr-TR')} <span className="text-[10px] font-sans font-medium text-slate-400">kg</span>
                          </span>
                          <span className="text-[11px] text-slate-400">
                            Eşik: {thresholdKg.toLocaleString('tr-TR')} kg ({item.stockPercentage}%)
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isUrgent
                                ? 'bg-rose-500'
                                : isLow
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, item.stockPercentage)}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-400 tabular-nums">
                        {item.refCount} Parti Kabulü
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onSelectModule('HARVEST', 'NEW')}
                          className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                          title="Bu ürün için tarlada yeni hasat girişi başlat"
                        >
                          <PlusCircle className="w-3 h-3" />
                          <span>Hasat Başlat</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onSelectModule('AMBAR', 'NEW')}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                          title="Ambar kabul kaydı oluştur"
                        >
                          <Warehouse className="w-3 h-3" />
                          <span>Kabul</span>
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>

        </div>
      )}

    </div>
  );
};
