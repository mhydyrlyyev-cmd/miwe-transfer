import React, { useMemo, useState } from 'react';
import { Warehouse, Truck, Trash2, X, AlertTriangle, Layers } from 'lucide-react';
import { QRScannerModal } from '../common/QRScannerModal';
import { ReferenceItem } from '../../types';
import { parseScannedRef, cleanName } from '../../utils/qrRef';
import { getStatusConfig } from '../../utils/statusStyles';

/**
 * v4.0 — Toplu QR tarama (muz paletleri vb.).
 * Kamera açık kalır; her okutulan palet listeye eklenir (tekrar sayılmaz).
 * Sonra "Depo kabul" veya "Sevk" sırayla açılır: her kayıttan sonra başarı ekranında
 * "Sıradaki palet" düğmesi bir sonrakini aynı forma getirir.
 */
export type BatchAction = 'RECEIVE' | 'DISPATCH';

interface Props {
  isOpen: boolean;
  references: ReferenceItem[];
  onClose: () => void;
  onStart: (action: BatchAction, refIds: string[]) => void;
}

const placeOf = (r: ReferenceItem) => String(r.greenhouse || r.orchard || r.location || '—');

export const BatchScanModal: React.FC<Props> = ({ isOpen, references, onClose, onStart }) => {
  const [items, setItems] = useState<ReferenceItem[]>([]);
  const [misses, setMisses] = useState<string[]>([]);

  const find = (text: string): ReferenceItem | undefined => {
    const q = text.trim().toLowerCase();
    return references.find(r => r.refId.toLowerCase() === q) || references.find(r => r.refId.toLowerCase().includes(q));
  };

  const onScan = (raw: string) => {
    const id = parseScannedRef(raw);
    if (!id) return;
    const ref = find(id);
    if (!ref) { setMisses(m => (m.includes(id) ? m : [id, ...m].slice(0, 5))); return; }
    setItems(list => (list.some(x => x.refId === ref.refId) ? list : [...list, ref]));
  };

  const byPlace = useMemo(() => {
    const m = new Map<string, number>();
    items.forEach(r => m.set(placeOf(r), (m.get(placeOf(r)) || 0) + 1));
    return [...m.entries()];
  }, [items]);
  const products = useMemo(() => new Set(items.map(r => `${r.product}`)), [items]);

  const close = () => { setItems([]); setMisses([]); onClose(); };
  const start = (a: BatchAction) => { const ids = items.map(r => r.refId); setItems([]); setMisses([]); onStart(a, ids); };

  const footer = (
    <div className="p-4 space-y-3 text-white">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-bold"><Layers className="w-4 h-4 text-teal-400" /> Okutulan: {items.length}</div>
        {items.length > 0 && (
          <button type="button" onClick={() => setItems([])} className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white cursor-pointer">
            <Trash2 className="w-3.5 h-3.5" /> Temizle
          </button>
        )}
      </div>

      {byPlace.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {byPlace.map(([p, n]) => (
            <span key={p} className="px-2 py-0.5 rounded-full bg-slate-800 text-[11px] font-bold text-slate-200">{p}: {n}</span>
          ))}
        </div>
      )}

      {products.size > 1 && (
        <div className="flex items-center gap-2 text-[11px] text-amber-300"><AlertTriangle className="w-3.5 h-3.5" /> Listede farklı ürünler var: {[...products].join(', ')}</div>
      )}
      {misses.length > 0 && (
        <div className="text-[11px] text-rose-300">Bulunamadı: {misses.join(', ')}</div>
      )}

      <ul className="space-y-1.5">
        {items.map((r, i) => (
          <li key={r.refId} className="flex items-center gap-2 rounded-xl bg-slate-800/70 px-3 py-2">
            <span className="w-6 text-[11px] font-bold text-slate-400 tabular-nums">{i + 1}</span>
            <span className="flex-1 min-w-0">
              <span className="block tabular-nums text-xs font-bold truncate">{r.refId}</span>
              <span className="block text-[11px] text-slate-400 truncate">{[cleanName(r.product), cleanName(r.sortVariety || r.variety), placeOf(r)].filter(Boolean).join(' · ')} · {getStatusConfig(r.status).label}</span>
            </span>
            <button type="button" aria-label="Listeden çıkar" onClick={() => setItems(list => list.filter(x => x.refId !== r.refId))} className="p-1 text-slate-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </li>
        ))}
      </ul>

      <div className="grid grid-cols-2 gap-2 pt-1">
        <button type="button" disabled={!items.length} onClick={() => start('RECEIVE')}
          className="flex items-center justify-center gap-2 min-h-[48px] rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-sm font-bold cursor-pointer">
          <Warehouse className="w-4 h-4" /> Depo kabul ({items.length})
        </button>
        <button type="button" disabled={!items.length} onClick={() => start('DISPATCH')}
          className="flex items-center justify-center gap-2 min-h-[48px] rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-sm font-bold cursor-pointer">
          <Truck className="w-4 h-4" /> Sevk ({items.length})
        </button>
      </div>
      <p className="text-[11px] text-slate-400">Formlar sırayla açılır. Her kayıttan sonra "Sıradaki palet" ile devam edin.</p>
    </div>
  );

  return (
    <QRScannerModal
      isOpen={isOpen}
      onClose={close}
      onScanSuccess={onScan}
      continuous
      title="Toplu QR tarama"
      subtitle="Paletleri arka arkaya okutun"
      footer={footer}
    />
  );
};

export default BatchScanModal;
