import React, { useEffect, useState } from 'react';
import { Leaf, Snowflake, Warehouse, Truck, ShoppingBag, MapPin, Award, FlaskConical, LogIn, ShieldCheck, Loader2 } from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';
import { fetchPublicRef, PublicRef } from '../../services/publicRefs';
import { getStatusConfig } from '../../utils/statusStyles';

/**
 * v4.0 — Giriş yapmadan QR okutan herkesin gördüğü sayfa: yalnız bilgi, işlem yok.
 * Personel "Personel girişi" ile girer; girişten sonra aynı partinin işlem menüsü açılır.
 */
interface Props {
  refId: string;
  onStaffLogin: () => void;
  /** Önizleme/test için hazır veri (verilirse sunucudan okunmaz) */
  initialData?: PublicRef | null;
}

const fmt = (d: string) => {
  if (!d) return '';
  const t = new Date(d + 'T00:00:00');
  return isNaN(t.getTime()) ? d : t.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
};

export const PublicRefView: React.FC<Props> = ({ refId, onStaffLogin, initialData }) => {
  const [data, setData] = useState<PublicRef | null>(initialData ?? null);
  const [loading, setLoading] = useState(initialData === undefined);

  useEffect(() => {
    if (initialData !== undefined) return;
    let alive = true;
    setLoading(true);
    fetchPublicRef(refId).then(d => { if (alive) { setData(d); setLoading(false); } });
    return () => { alive = false; };
  }, [refId]);

  const steps = data ? [
    { label: 'Hasat', at: data.harvestAt, Icon: Leaf, tone: 'bg-emerald-600' },
    { label: 'Ön soğutma', at: data.precoolAt, Icon: Snowflake, tone: 'bg-sky-600' },
    { label: 'Soğuk depo', at: data.storeAt, Icon: Warehouse, tone: 'bg-indigo-600' },
    { label: 'Sevk', at: data.shipAt, Icon: Truck, tone: 'bg-amber-600' },
    { label: 'Satış', at: data.soldAt, Icon: ShoppingBag, tone: 'bg-slate-700' },
  ] : [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <header className="bg-[#0F3D2E] text-white">
        <div className="max-w-xl mx-auto px-5 py-5 flex items-center gap-3">
          <BrandLogo size={44} />
          <div className="leading-tight">
            <div className="font-bold tracking-tight">MIWE HIL</div>
            <div className="text-[11px] text-emerald-200 font-bold">Ürün izlenebilirlik kartı</div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-xl w-full mx-auto px-4 py-5 space-y-4">
        {loading && (
          <div className="flex items-center justify-center gap-2 py-16 text-slate-500"><Loader2 className="w-5 h-5 animate-spin" /> Bilgiler yükleniyor…</div>
        )}

        {!loading && !data && (
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 text-center">
            <div className="tabular-nums text-sm font-bold text-slate-800 dark:text-slate-100 break-all">{refId}</div>
            <p className="mt-3 text-slate-600 dark:text-slate-300 text-sm">Bu parti için herkese açık bilgi henüz yayınlanmadı.</p>
          </div>
        )}

        {!loading && data && (
          <>
            <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
              <div className="tabular-nums text-xs font-bold text-slate-500 break-all">{data.refId}</div>
              <h1 className="mt-1 font-display text-2xl font-bold text-slate-900 dark:text-white">
                {data.product}{data.variety ? <span className="text-slate-500 font-semibold"> · {data.variety}</span> : null}
              </h1>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                {data.place && <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200"><MapPin className="w-4 h-4 text-emerald-700" />{data.place}</div>}
                {data.harvestAt && <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200"><Leaf className="w-4 h-4 text-emerald-700" />Hasat: {fmt(data.harvestAt)}</div>}
                {data.qualityClass && <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200"><Award className="w-4 h-4 text-amber-600" />Kalite sınıfı: {data.qualityClass}</div>}
                {data.testCount > 0 && <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200"><FlaskConical className="w-4 h-4 text-violet-700" />{data.testCount} kalite testi bağlı</div>}
              </div>
              {data.status && (
                <div className="mt-3 inline-flex px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                  Durum: {getStatusConfig(data.status as any).label}
                </div>
              )}
            </section>

            <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
              <h2 className="text-xs font-bold text-slate-500 mb-3">Ürünün yolculuğu</h2>
              <ol className="space-y-0">
                {steps.map((s, i) => {
                  const done = !!s.at;
                  return (
                    <li key={s.label} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <span className={`w-9 h-9 rounded-full flex items-center justify-center text-white ${done ? s.tone : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}>
                          <s.Icon className="w-4.5 h-4.5" />
                        </span>
                        {i < steps.length - 1 && <span className={`w-0.5 flex-1 min-h-5 ${done ? 'bg-slate-300 dark:bg-slate-700' : 'bg-slate-100 dark:bg-slate-800'}`} />}
                      </div>
                      <div className="pb-4">
                        <div className={`text-sm font-bold ${done ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>{s.label}</div>
                        <div className="text-xs text-slate-500">{done ? fmt(s.at) : 'Henüz değil'}</div>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </section>

            <p className="flex items-start gap-2 text-xs text-slate-500 px-1">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-700" />
              Bu sayfa yalnızca bilgi içindir. Kayıt ve işlem yapmak için personel girişi gerekir.
            </p>
          </>
        )}

        <button
          type="button"
          onClick={onStaffLogin}
          className="w-full flex items-center justify-center gap-2 min-h-[52px] rounded-2xl bg-[#0F3D2E] hover:bg-[#0b2f23] text-white font-bold cursor-pointer"
        >
          <LogIn className="w-5 h-5" /> Personel girişi
        </button>
      </main>
    </div>
  );
};

export default PublicRefView;
