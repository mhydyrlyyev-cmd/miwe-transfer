import React, { useEffect } from 'react';
import { X, Printer, CheckCircle2, AlertTriangle, Truck, Warehouse, Apple, Banana, Nut, AlertOctagon, FileCheck, Layers, Calendar, User, ShieldCheck, Snowflake, Globe, ShoppingBag, Lock } from 'lucide-react';
import { ReferenceItem, HarvestRecord, FieldRecord, MuzRecord, BademRecord, LojistikRecord, AmbarRecord, FreezeDryRecord, ExportSampleRecord, SalesRecord, IncidentRecord } from '../../types';

interface TraceabilityModalProps {
  reference: ReferenceItem;
  harvestRecords?: HarvestRecord[];
  fieldRecords: FieldRecord[];
  muzRecords: MuzRecord[];
  bademRecords: BademRecord[];
  lojistikRecords: LojistikRecord[];
  ambarRecords: AmbarRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  exportSampleRecords?: ExportSampleRecord[];
  salesRecords?: SalesRecord[];
  incidentRecords: IncidentRecord[];
  onClose: () => void;
  onOpenLedger?: (ref: ReferenceItem) => void;
}

export const TraceabilityModal: React.FC<TraceabilityModalProps> = ({
  reference,
  harvestRecords = [],
  fieldRecords,
  muzRecords,
  bademRecords,
  lojistikRecords,
  ambarRecords,
  freezeDryRecords = [],
  exportSampleRecords = [],
  salesRecords = [],
  incidentRecords,
  onClose,
  onOpenLedger
}) => {
  const refId = reference.refId;

  useEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  // Find all associated module records for this exact RefID
  const harvestRec = harvestRecords.find(r => r.refId === refId);
  const fieldRec = fieldRecords.find(r => r.refId === refId);
  const muzRec = muzRecords.find(r => r.refId === refId);
  const bademRec = bademRecords.find(r => r.refId === refId);
  const lojistikRec = lojistikRecords.find(r => r.refId === refId);
  const ambarRec = ambarRecords.find(r => r.refId === refId);
  const freezeDryRec = freezeDryRecords.find(r => r.refId === refId);
  const exportRec = exportSampleRecords.find(r => r.refId === refId);
  const salesRec = salesRecords.find(r => r.refId === refId);
  const incidents = incidentRecords.filter(r => r.refId === refId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full my-2 sm:my-8 overflow-hidden print:m-0 print:border-none print:shadow-none relative pb-20 sm:pb-0">
        
        {/* Top Header - sticky & responsive */}
        <div className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md text-white px-3 sm:px-6 py-2.5 sm:py-4 flex items-center justify-between border-b border-slate-800 print:bg-slate-900 print:text-white shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 sm:p-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-400 shrink-0">
              <FileCheck className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-lg font-bold tracking-tight text-white tabular-nums truncate">
                  {refId}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500 text-slate-950 font-sans">
                  360° Kalite pasaportu
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans hidden sm:block">
                MIWE TEST 2026 Uçtan Uca İzlenebilirlik ve Uygunluk Sertifikası
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 print:hidden">
            {onOpenLedger && (
              <button
                type="button"
                onClick={() => onOpenLedger(reference)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-emerald-300 border border-emerald-500/30 text-xs font-bold rounded-xl transition shadow min-h-[40px] cursor-pointer"
                title="Bu referansın SHA-256 kriptografik defterini ve blok zincirini aç"
              >
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">SHA-256 Defteri</span>
                <span className="sm:hidden">Defter</span>
              </button>
            )}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow min-h-[40px]"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Yazdır</span>
              <span className="sm:hidden">PDF</span>
            </button>
            <button
              onClick={onClose}
              className="flex items-center gap-1 px-3 sm:px-3.5 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[40px]"
              title="Kapat"
              aria-label="Kapat"
            >
              <X className="w-4 h-4" />
              <span>Kapat</span>
            </button>
          </div>
        </div>

        {/* Modal Body / Passport Card */}
        <div className="p-6 space-y-6">
          
          {/* Quick Info Header Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <span className="text-[10px] font-bold text-slate-400">Ürün & Varyete</span>
              <p className="text-sm font-bold text-slate-900">{reference.product}</p>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400">Toplam Miktar</span>
              <p className="text-sm font-bold text-slate-900 tabular-nums">
                {(reference.quantity ?? 0).toLocaleString('tr-TR')} {reference.unit || 'kg'}
              </p>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400">Başlangıç Lokasyonu</span>
              <p className="text-sm font-bold text-slate-900">{reference.source || reference.location}</p>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400">Sistem Statüsü</span>
              <p className="text-sm font-bold text-emerald-800 tabular-nums">{reference.status}</p>
            </div>
          </div>

          {/* Timeline & 4 Stages */}
          <div className="space-y-4">
            
            {/* STAGE 1: HASAT & İLK KALİTE TESTİ */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold text-xs">
                    01
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Hasat & İlk Kalite Muayenesi ({reference.moduleKey})
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Tarih: {reference.createdAt ? new Date(reference.createdAt).toLocaleString('tr-TR') : '-'}
                    </span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Tamamlandı</span>
                </span>
              </div>

              {/* Harvest Record details with Delilnama */}
              {harvestRec && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-emerald-50/50 p-3 rounded-lg">
                    <div>Operatör: <strong>{harvestRec.operator}</strong></div>
                    <div>Hasat Aşaması: <strong>{harvestRec.harvestStage}</strong></div>
                    <div>Günlük Toplam: <strong className="tabular-nums text-emerald-900">{harvestRec.dailyTotalKg} kg</strong></div>
                    <div>İşçi / Sorumlu: <strong>{harvestRec.workerCount ? `${harvestRec.workerCount} İşçi` : '-'} / {harvestRec.foreman || '-'}</strong></div>
                    <div>Hedef: <strong>{harvestRec.destination}</strong></div>
                    <div>Lot No: <strong className="tabular-nums">{harvestRec.lotNo}</strong></div>
                    {harvestRec.delilnama && (
                      <div className="col-span-2">
                        Delilnama №: <strong className="tabular-nums text-rose-600 font-bold">№ {harvestRec.delilnama.delilnamaNo}</strong> ({harvestRec.delilnama.miwe} - {harvestRec.delilnama.miweGornusi})
                      </div>
                    )}
                  </div>

                  {harvestRec.delilnama && harvestRec.delilnama.grades && (
                    <div className="bg-white border border-slate-200 rounded-lg p-3">
                      <div className="text-[11px] font-bold text-slate-800 mb-2">
                        Standart Kalite Sınıfları Dağılımı (Delilnama № {harvestRec.delilnama.delilnamaNo}):
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {harvestRec.delilnama.grades.map((g, gIdx) => (
                          <div key={gIdx} className="bg-slate-50 border border-slate-200 rounded-md p-2 text-xs">
                            <div className="font-bold text-slate-900 flex items-center justify-between">
                              <span>{g.gradeKey}</span>
                              <span className="tabular-nums text-emerald-800 font-bold">{g.hasylNetKg} kg</span>
                            </div>
                            {g.satysaBerlenKg ? (
                              <div className="text-[10px] text-slate-500 mt-0.5">
                                Satışa: <span className="tabular-nums font-semibold">{g.satysaBerlenKg} kg</span>
                              </div>
                            ) : null}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Field specific details */}
              {fieldRec && (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3 rounded-lg">
                    <div>Operatör: <strong>{fieldRec.operator}</strong></div>
                    <div>Ortalama Brix: <strong className="tabular-nums text-emerald-800">%{fieldRec.avgBrix}</strong></div>
                    <div>Ortalama Sertlik: <strong className="tabular-nums">{fieldRec.avgHardness} kg/cm²</strong></div>
                    <div>Ortalama Çap: <strong className="tabular-nums">{fieldRec.avgDiameter} mm</strong></div>
                    <div>Nitrat Testi: <strong className={`tabular-nums ${fieldRec.nitratePass ? 'text-emerald-700' : 'text-rose-700'}`}>{fieldRec.nitrateMgKg} mg/kg ({fieldRec.nitratePass ? 'Uygun' : 'Limit Aşımı'})</strong></div>
                    <div>Kalite Sınıfı: <strong>{fieldRec.qualityGrade}</strong></div>
                    <div>Muayene Kararı: <strong className="text-emerald-800">{fieldRec.decision}</strong></div>
                    <div>Numune Adedi: <strong>{fieldRec.sampleCount} Adet</strong></div>
                  </div>

                  {(fieldRec.starchIndex !== undefined || fieldRec.streifIndex !== undefined) && (
                    <div className="flex flex-wrap items-center gap-2 p-2.5 bg-indigo-50/70 border border-indigo-200 rounded-lg text-xs">
                      <span className="font-bold text-indigo-950"> Nişasta & Streif İndeksi (SI):</span>
                      {fieldRec.starchIndex !== undefined && (
                        <span className="px-2 py-0.5 bg-white border border-indigo-200 rounded tabular-nums font-bold text-indigo-900">
                          Nişasta: {fieldRec.starchIndex.toFixed(1)} / 10
                        </span>
                      )}
                      {fieldRec.streifIndex !== undefined && (
                        <span className="px-2 py-0.5 bg-indigo-700 text-white rounded tabular-nums font-bold">
                          SI: {fieldRec.streifIndex.toFixed(3)}
                        </span>
                      )}
                      {fieldRec.streifInterpretation && (
                        <span className="text-[11px] text-indigo-800 font-semibold">
                          ({fieldRec.streifInterpretation})
                        </span>
                      )}
                    </div>
                  )}

                  {fieldRec.specialCropTest && (
                    <div className="flex flex-wrap items-center gap-2 p-2.5 bg-teal-50/80 border border-teal-200 rounded-lg text-xs">
                      <span className="font-bold text-teal-950">🌾 {fieldRec.specialCropTest.cropNameTr}:</span>
                      <span className="px-2 py-0.5 bg-white border border-teal-200 rounded tabular-nums font-bold text-teal-900">
                        {fieldRec.specialCropTest.metric1Name}: {fieldRec.specialCropTest.metric1Value} {fieldRec.specialCropTest.metric1Unit || ''}
                      </span>
                      {fieldRec.specialCropTest.metric2Name && (
                        <span className="px-2 py-0.5 bg-white border border-teal-200 rounded tabular-nums font-bold text-teal-900">
                          {fieldRec.specialCropTest.metric2Name}: {fieldRec.specialCropTest.metric2Value} {fieldRec.specialCropTest.metric2Unit || ''}
                        </span>
                      )}
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${fieldRec.specialCropTest.statusBadge}`}>
                        {fieldRec.specialCropTest.interpretation}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Muz specific details */}
              {muzRec && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-amber-50/60 p-3 rounded-lg">
                  <div>Operatör: <strong>{muzRec.operator}</strong></div>
                  <div>Sera No: <strong>{muzRec.greenhouseNo}</strong></div>
                  <div>Kurdele Rengi: <strong className="text-amber-900">{muzRec.ribbonColor}</strong></div>
                  <div>Olgunluk Skalası: <strong className="tabular-nums">{muzRec.ripenessScale} / 7</strong></div>
                  <div>Kalibrasyon: <strong className="tabular-nums">{muzRec.calibrationMm} mm</strong></div>
                  <div>Parmak Uzunluğu: <strong className="tabular-nums">{muzRec.fingerLengthCm} cm</strong></div>
                  <div>Meyve Eti Sertliği: <strong className="tabular-nums">{muzRec.pulpFirmness} kg/cm²</strong></div>
                  <div>Kalite Statüsü: <strong className="text-emerald-800">{muzRec.qualityStatus}</strong></div>

                  {muzRec.banana3PointBrix && (
                    <div className="col-span-2 sm:col-span-4 bg-amber-100/90 p-2 rounded-lg border border-amber-300 text-[11px] mt-1 flex items-center justify-between flex-wrap gap-2">
                      <span className="font-bold text-amber-950 flex items-center gap-1">
                        <span> 3 Nokta Meyve Brix Ölçümü:</span>
                      </span>
                      <div className="flex items-center gap-3 tabular-nums text-slate-800">
                        <span>Sap: <strong>{muzRec.banana3PointBrix.topPoint} °Bx</strong></span>
                        <span>Gövde: <strong>{muzRec.banana3PointBrix.middlePoint} °Bx</strong></span>
                        <span>Uç: <strong>{muzRec.banana3PointBrix.bottomPoint} °Bx</strong></span>
                        <span className="bg-emerald-200 text-emerald-950 font-bold px-2 py-0.5 rounded border border-emerald-400">
                          Ort: {muzRec.banana3PointBrix.avg3Point} °Bx
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Badem specific details */}
              {bademRec && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-orange-50/60 p-3 rounded-lg">
                  <div>Operatör: <strong>{bademRec.operator}</strong></div>
                  <div>Çeşit / Sort: <strong>{bademRec.variety}</strong></div>
                  <div>Hesaplanan Randıman: <strong className="tabular-nums text-orange-800 text-sm">%{bademRec.kernelYieldPercent}</strong></div>
                  <div>Nem Oranı: <strong className="tabular-nums">%{bademRec.moisturePercent}</strong></div>
                  <div>Kalibre: <strong className="tabular-nums">{bademRec.calibre}</strong></div>
                  <div>Toplam Kusur: <strong className="tabular-nums">%{bademRec.totalDefectPercent}</strong></div>
                  <div>Ciddi Kusur: <strong className="tabular-nums">%{bademRec.seriousDefectPercent}</strong></div>
                  <div>Sınıflandırma: <strong>{bademRec.classification}</strong></div>
                </div>
              )}
            </div>

            {/* STAGE 2: LOJİSTİK & SEVKİYAT */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                    02
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Lojistik, Sevkiyat & Delilnama
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Soğuk zincir taşıma ve araç sevkiyat kaydı
                    </span>
                  </div>
                </div>
                
                {lojistikRec ? (
                  <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Sevk Edildi ({lojistikRec.status})</span>
                  </span>
                ) : (
                  <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                    Henüz Sevk Edilmedi
                  </span>
                )}
              </div>

              {lojistikRec ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-blue-50/50 p-3 rounded-lg">
                  <div>Delilnama No: <strong className="tabular-nums text-blue-900">{lojistikRec.delilnamaNo}</strong></div>
                  <div>Araç Plakası: <strong className="tabular-nums font-bold">{lojistikRec.vehiclePlate}</strong></div>
                  <div>Sürücü: <strong>{lojistikRec.driver}</strong></div>
                  <div>Taşıma Tipi: <strong>{lojistikRec.transportType}</strong></div>
                  <div>Palet / Kasa: <strong className="tabular-nums">{lojistikRec.palletCount} Palet / {lojistikRec.caseCount} Kasa</strong></div>
                  <div>Yükleme Ağırlığı: <strong className="tabular-nums">{lojistikRec.weightKg} kg</strong></div>
                  <div>Çıkış Sıcaklığı: <strong className="tabular-nums text-blue-800">{lojistikRec.departureTemperature}°C</strong></div>
                  <div>Transit Hedef Isı: <strong className="tabular-nums text-blue-800">{lojistikRec.transitTemperature}°C</strong></div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">
                  Bu referans için henüz Lojistik modülünden Delilnama oluşturulmadı.
                </p>
              )}
            </div>

            {/* STAGE 3: AMBAR KABUL & SOĞUK ODA */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                    03
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Ambar Kabul, Depo & Kantar Girişi
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Depolama sıcaklığı, fire hesabı ve oda yerleşimi
                    </span>
                  </div>
                </div>

                {ambarRec ? (
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Depoya Alındı ({ambarRec.acceptanceStatus})</span>
                  </span>
                ) : (
                  <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                    Kabul Bekliyor
                  </span>
                )}
              </div>

              {ambarRec ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-emerald-50/50 p-3 rounded-lg">
                  <div>Depo / Tesis: <strong>{ambarRec.warehouse}</strong></div>
                  <div>Soğuk Oda No: <strong>{ambarRec.roomNo}</strong></div>
                  <div>Kantar Kabul: <strong className="tabular-nums text-emerald-900 font-bold">{ambarRec.acceptedWeightKg} kg</strong></div>
                  <div>Fire Farkı: <strong className="tabular-nums text-amber-800">{ambarRec.weightDiffKg} kg (%{ambarRec.weightDiffPercent})</strong></div>
                  <div>Ürün Sıcaklığı: <strong className="tabular-nums text-blue-700">{ambarRec.productTemperature}°C</strong></div>
                  <div>Oda Sıcaklığı & Nem: <strong className="tabular-nums">{ambarRec.roomTemperature}°C / %{ambarRec.humidityPercent}</strong></div>
                  <div>Hijyen Durumu: <strong className="text-emerald-700">{ambarRec.hygieneStatus}</strong></div>
                  <div>Soğuk Zincir: <strong className="text-emerald-700">{ambarRec.coldChainStatus}</strong></div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">
                  Bu referans henüz ambar kantarından kabul edilmedi.
                </p>
              )}
            </div>

            {/* STAGE: FREEZE-DRY LIYOFILIZASYON */}
            {freezeDryRec && (
              <div className="border border-cyan-200 rounded-xl p-4 bg-cyan-50/40 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-cyan-200 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-cyan-100 text-cyan-800 flex items-center justify-center font-bold text-xs">
                      <Snowflake className="w-4 h-4 text-cyan-700" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-cyan-950">
                        Freeze-Dry Liyofilizasyon & Paketleme
                      </h3>
                      <span className="text-[10px] text-cyan-700">
                        -40°C Şoklama, vakum kurutma ve azotlu ambalaj
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-cyan-800 bg-cyan-100 px-2 py-0.5 rounded">
                    {freezeDryRec.processStatus}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-white/80 p-3 rounded-lg border border-cyan-100">
                  <div>Giren Yaş Hammadde: <strong className="tabular-nums">{freezeDryRec.rawWeightKg} kg</strong></div>
                  <div>Çıkan Kuru Net: <strong className="tabular-nums text-cyan-900 font-bold">{freezeDryRec.finalDryWeightKg} kg</strong></div>
                  <div>Kuru Ürün Nemi: <strong className="tabular-nums text-emerald-700 font-bold">%{freezeDryRec.finalMoisturePercent}</strong></div>
                  <div>Verim / Randıman: <strong className="tabular-nums">%{freezeDryRec.yieldRatioPercent}</strong></div>
                  <div>Şoklama Odası: <strong>{freezeDryRec.shockFreezerRoom} ({freezeDryRec.shockFreezerTempC}°C)</strong></div>
                  <div>Vakum Basıncı: <strong className="tabular-nums">{freezeDryRec.vacuumPressureMbar} mbar</strong></div>
                  <div>Üretilen Paket: <strong className="tabular-nums font-bold">{freezeDryRec.totalPackagesProduced} Adet</strong></div>
                  <div>Ambalaj Tipi: <strong>{freezeDryRec.packagingType}</strong></div>
                </div>
              </div>
            )}

            {/* STAGE: EXPORT 3G TRANSIT NUMUNE */}
            {exportRec && (
              <div className="border border-teal-200 rounded-xl p-4 bg-teal-50/40 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-teal-200 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                      <Globe className="w-4 h-4 text-teal-700" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-teal-950">
                        İhracat 3G Transit Şahit Numune & Varış Testi
                      </h3>
                      <span className="text-[10px] text-teal-700">
                        Hedef ülke teslimat simülasyonu ve dehidrasyon kaybı
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-teal-800 bg-teal-100 px-2 py-0.5 rounded">
                    {exportRec.shelfLifeDecision}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-white/80 p-3 rounded-lg border border-teal-100">
                  <div>Hedef Ülke / Şehir: <strong>{exportRec.destinationCountry}</strong></div>
                  <div>Simüle Yolculuk: <strong>{exportRec.transitDays} Gün</strong></div>
                  <div>Su Kaybı Oranı: <strong className="tabular-nums text-teal-800">%{exportRec.waterLossPercent}</strong></div>
                  <div>Ağırlık Kaybı: <strong className="tabular-nums text-teal-800">%{exportRec.weightLossPercent}</strong></div>
                  <div>Varış Brix: <strong className="tabular-nums">%{exportRec.avgBrix}</strong></div>
                  <div>Varış Sertlik: <strong className="tabular-nums">{exportRec.avgHardness} kg/cm²</strong></div>
                  <div>Test Tarihi: <strong className="tabular-nums">{exportRec.testDate || exportRec.timestamp}</strong></div>
                  <div>Sorumlu: <strong>{exportRec.operator}</strong></div>
                </div>

                {/* Excel şablonu verileri varsa göster */}
                {(exportRec.supplier || exportRec.expertName || exportRec.wastePercent !== undefined) && (
                  <div className="mt-3 border-t border-teal-200/60 pt-3 text-xs space-y-2">
                    <div className="text-[11px] font-bold text-teal-950 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
                      <span> Avrasya kalite standartlari raporu (excel entegrasyonu)</span>
                    </div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-amber-50/50 p-2.5 rounded-lg border border-amber-100 text-[11px] text-slate-800">
                      <div>Tedarikçi: <strong>{exportRec.supplier || '-'}</strong></div>
                      <div>Parti No / Batch: <strong className="tabular-nums">{exportRec.batchNumber || '-'}</strong></div>
                      <div>Kategori / Sınıf: <strong>{exportRec.category || '-'}</strong></div>
                      <div>Palet Sayısı: <strong>{exportRec.palletCount || '-'}</strong></div>
                      <div>Karar Skoru (1-5): <strong className="text-teal-700">{exportRec.assessmentForQuality || '-'}</strong></div>
                      <div>Kalibre (Beyan/Ölçüm): <strong>{exportRec.caliberDeclared || '-'}/{exportRec.caliberActual || '-'}</strong></div>
                      <div>Kutu Adedi / Ağırlık: <strong className="tabular-nums">{exportRec.sampleBoxCount || '-'} Kutu / {exportRec.sampleWeightKg || '-'} kg</strong></div>
                      <div>Tat & Lezzet: <strong>{exportRec.tasteBrix || '-'}</strong></div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px] bg-sky-50/40 p-2 rounded border border-sky-100">
                      <div>t°C (Doküman): <strong className="tabular-nums text-blue-800">{exportRec.docTemperature || '-'}</strong></div>
                      <div>t°C (Soğutucu): <strong className="tabular-nums text-blue-800">{exportRec.coolingUnitTemperature || '-'}</strong></div>
                      <div>t°C (Fiili): <strong className="tabular-nums text-rose-700 font-bold">{exportRec.actualTemperature || '-'}</strong></div>
                    </div>

                    <div className="bg-white rounded-lg border border-teal-100 overflow-hidden text-[11px]">
                      <div className="bg-teal-50 px-3 py-1 font-bold text-[10px] text-teal-950 border-b border-teal-100 flex items-center justify-between">
                        <span>Hasar & Çürüme Detayları (Yol Dayanım Sonu)</span>
                        <span className="tabular-nums text-teal-800 font-bold text-xs">Total Atık: %{exportRec.wastePercent || 0}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 p-2 text-center text-slate-700">
                        <div className="bg-rose-50/50 p-1.5 rounded border border-rose-100">
                          <div className="text-[9px] text-rose-800 font-bold">Toplam Çürüme (Rot)</div>
                          <div className="tabular-nums font-bold text-rose-700">{exportRec.rotKg || 0} kg (%{exportRec.rotPercent || 0})</div>
                          <div className="text-[8px] text-rose-500 italic">İç Nekroz: {exportRec.internalRotNecrosisKg || 0} kg</div>
                        </div>
                        <div className="bg-orange-50/50 p-1.5 rounded border border-orange-100">
                          <div className="text-[9px] text-orange-800 font-bold">Mekanik Hasar</div>
                          <div className="tabular-nums font-bold text-orange-700">{exportRec.mechanicsKg || 0} kg (%{exportRec.mechanicsPercent || 0})</div>
                          <div className="text-[8px] text-orange-500 italic">Prokol/Вырыв</div>
                        </div>
                        <div className="bg-amber-50/50 p-1.5 rounded border border-amber-100">
                          <div className="text-[9px] text-amber-800 font-bold">Tepe Erimesi</div>
                          <div className="tabular-nums font-bold text-amber-700">{exportRec.dilutionTopKg || 0} kg (%{exportRec.dilutionTopPercent || 0})</div>
                          <div className="text-[8px] text-amber-500 italic">Разжижение верхушки</div>
                        </div>
                      </div>
                    </div>

                    {exportRec.expertName && (
                      <div className="text-[10px] text-slate-600 flex justify-end font-bold pr-2 italic">
                        Ф.И.О. эксперта / Kalite Uzmanı: {exportRec.expertName}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* STAGE: COMMERCIAL SALES & DISPATCH */}
            {salesRec && (
              <div className="border border-purple-200 rounded-xl p-4 bg-purple-50/40 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-purple-200 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-xs">
                      <ShoppingBag className="w-4 h-4 text-purple-700" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-purple-950">
                        Satış & Sevkiyat Çıkış Kaydı
                      </h3>
                      <span className="text-[10px] text-purple-700">
                        Fatura, müşteri ve sevkiyat hacmi
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-purple-800 bg-purple-100 px-2 py-0.5 rounded tabular-nums">
                    {salesRec.invoiceNo}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-white/80 p-3 rounded-lg border border-purple-100">
                  <div>Müşteri: <strong>{salesRec.customer}</strong></div>
                  <div>Satış Kanalı: <strong>{salesRec.salesChannel}</strong></div>
                  <div>Sevk Edilen Net: <strong className="tabular-nums text-purple-900 font-bold">{salesRec.totalQuantityKg} kg</strong></div>
                  <div>Kasa / Palet: <strong className="tabular-nums">{salesRec.totalCases} Kasa / {salesRec.totalPallets || 0} Palet</strong></div>
                  <div>Sevk Tarihi: <strong className="tabular-nums">{salesRec.salesDate}</strong></div>
                  <div>Araç Plakası: <strong>{salesRec.vehiclePlate}</strong></div>
                  <div>Ödeme Durumu: <strong>{salesRec.paymentStatus}</strong></div>
                  <div>Operatör: <strong>{salesRec.operator}</strong></div>
                </div>
              </div>
            )}

            {/* STAGE 4: INCIDENT & BARLAG AKTY */}
            {incidents.length > 0 && (
              <div className="border border-rose-200 rounded-xl p-4 bg-rose-50/40 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-rose-200 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-xs">
                      04
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-rose-950">
                        Kalite Sapması & Incident Tutanağı ({incidents.length} Kayıt)
                      </h3>
                      <span className="text-[10px] text-rose-600">
                        Resmi Barlag Akty ve DÖF Faaliyet Takibi
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {incidents.map((inc) => (
                    <div key={inc.id} className="bg-white border border-rose-200 rounded-lg p-3 text-xs space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="tabular-nums font-bold text-rose-900">{inc.incidentId} - {inc.incidentType}</span>
                        <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-rose-100 text-rose-800">
                          {inc.status} ({inc.priority})
                        </span>
                      </div>
                      <div><strong>Olay:</strong> {inc.description}</div>
                      <div><strong>Kök Neden:</strong> {inc.rootCause}</div>
                      <div><strong>DÖF Aksiyonu:</strong> {inc.correctiveAction}</div>
                      <div className="text-[11px] text-slate-500">Sorumlu: {inc.responsible} | Etkilenen: {inc.affectedQuantityKg} kg</div>
                      {inc.photos && inc.photos.length > 0 && (
                        <div className="pt-2">
                          <span className="text-[10px] font-bold text-slate-500 block mb-1">Kanıt Fotoğrafları:</span>
                          <div className="flex items-center gap-2 flex-wrap">
                            {inc.photos.map((ph, pidx) => (
                              <a
                                key={pidx}
                                href={ph}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-12 h-12 rounded-lg overflow-hidden border border-slate-200 block shadow-sm hover:opacity-80 transition"
                              >
                                <img src={ph} alt={`Evidence ${pidx + 1}`} className="w-full h-full object-cover" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Verification Stamp Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
            <div>
              Sertifika Doğrulama Kodu: <span className="tabular-nums font-bold text-slate-700">{refId}-AUTH-2026</span>
            </div>
            <div>
              MIWE TEST 2026 Kalite Güvence & Denetim Sistemi &bull; Dijital İmza Onaylı
            </div>
          </div>

        </div>

        {/* Bottom Actions */}
        <div className="p-3.5 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="text-xs text-slate-500 font-medium">
            360° İzlenebilirlik Pasaportu önizlemesi
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
            >
              <Printer className="w-4 h-4" />
              <span>Yazdır / PDF Olarak Kaydet</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
            >
              <X className="w-4 h-4" />
              <span>Pasaportu Kapat</span>
            </button>
          </div>
        </div>

      </div>

      {/* Mobile Floating Quick Action Bar */}
      <div className="fixed bottom-4 left-3 right-3 z-50 sm:hidden flex items-center justify-between gap-2 p-2 bg-slate-950/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-700/80 print:hidden">
        <button
          type="button"
          onClick={onClose}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
        >
          <X className="w-4 h-4" />
          <span>Kapat</span>
        </button>
        <button
          type="button"
          onClick={handlePrint}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
        >
          <Printer className="w-4 h-4" />
          <span>PDF / Yazdır</span>
        </button>
      </div>
    </div>
  );
};
