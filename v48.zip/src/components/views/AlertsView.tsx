import React, { useMemo, useState } from 'react';
import { Copy } from 'lucide-react';
import { findRefConflicts } from '../../utils/refConflicts';
import { cleanName } from '../../utils/qrRef';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord, BalanceAdjustment, FieldRecord } from '../../types';
import ColdChainPanel from '../coldchain/ColdChainPanel';
import { PageHeader, ListRow, Badge } from '../ui';

/**
 * v3.7 — Tüm uyarılar tek sayfada (ana panel "Tümü" ve mobil alt menü "Uyarılar").
 * Her uyarı kendi aşama etiketini taşır; ayrıntılı işlem kendi aşama sayfasında yapılır.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  /** v3.8: RefID çakışma kontrolü için */
  fieldRecords?: FieldRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onOpenRecord: (refId: string) => void;
  onOpenPrecooling: (ref: ReferenceItem) => void;
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onBack: () => void;
}

const fmtD = (d: string) => d.split('-').reverse().slice(0, 2).join('.');

export default function AlertsView(p: Props) {
  const conflicts = useMemo(() => findRefConflicts(p.references, p.harvestRecords, p.fieldRecords || []), [p.references, p.harvestRecords, p.fieldRecords]);
  const [showAll, setShowAll] = useState(false);
  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader onBack={p.onBack} title="Uyarılar" subtitle="Tüm aşamaların uyarıları; en acil olan üstte. Etiket, uyarının hangi aşamaya ait olduğunu gösterir." />
      {/* v3.8: aynı RefID'yi paylaşan farklı partiler (eski numaralandırma hatasından) */}
      {conflicts.length > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white pt-1">Kayıt düzeltmesi <span className="text-slate-400 font-semibold">{conflicts.length}</span></h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Aynı numara farklı partilere verilmiş. Kontrol edip gerekirse yeni numarayla ayırın.</p>
          {(showAll ? conflicts : conflicts.slice(0, 5)).map(c => (
            <ListRow key={c.refId} dot="warn" title={c.refId}
              sub={c.reason === 'DATE_SPREAD' ? `Hasat tarihleri: ${c.dates.map(fmtD).join(', ')}` : c.variants.map(v => `${cleanName(v.product)} · ${cleanName(v.orchard)}`).join('  |  ')}
              right={<Badge tone="neutral" icon={<Copy className="w-3 h-3" />}>Kayıt</Badge>}
              onClick={() => p.onOpenRecord(c.refId)} />
          ))}
          {conflicts.length > 5 && (
            <button type="button" onClick={() => setShowAll(v => !v)} className="mt-1 mb-1 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer">{showAll ? 'Daha az göster' : `Tümünü göster (${conflicts.length})`}</button>
          )}
        </section>
      )}

      <ColdChainPanel
        references={p.references} harvestRecords={p.harvestRecords} ambarRecords={p.ambarRecords}
        lojistikRecords={p.lojistikRecords} salesRecords={p.salesRecords}
        currentUserName={p.currentUserName} isReadOnly={p.isReadOnly}
        onOpenRecord={p.onOpenRecord} onOpenPrecooling={p.onOpenPrecooling}
        onAddBalanceAdjustment={p.onAddBalanceAdjustment}
      />
    </div>
  );
}
