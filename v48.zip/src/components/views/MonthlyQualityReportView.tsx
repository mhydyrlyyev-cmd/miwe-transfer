import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Download,
  ShieldAlert,
  AlertTriangle,
  Flame,
  Award,
  Sparkles,
  Users,
  Plus,
  Save,
  Check,
  X,
  TrendingDown,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Briefcase,
  ChevronDown,
  ChevronUp,
  Scale,
  Warehouse,
  FileSpreadsheet,
  Info,
  BookOpen,
  Table,
  RotateCcw
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  LineChart,
  Line,
  CartesianGrid
} from 'recharts';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  LojistikRecord,
  AmbarRecord,
  IncidentRecord
} from '../../types';
import { doc, onSnapshot, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import {
  saveMonthlyReportToFirestore,
  fetchMonthlyReportsFromFirestore
} from '../../lib/firestoreService';
import { addDebugLog } from '../../utils/debugLogger';

export type ReportPersona = 'ALL' | 'MANAGER' | 'FINANCE' | 'PRODUCER' | 'OPERATOR';

interface MonthlyQualityReportViewProps {
  references?: ReferenceItem[];
  harvestRecords?: HarvestRecord[];
  fieldRecords?: FieldRecord[];
  muzRecords?: any[];
  bademRecords?: any[];
  lojistikRecords?: LojistikRecord[];
  ambarRecords?: AmbarRecord[];
  freezeDryRecords?: any[];
  exportSampleRecords?: any[];
  salesRecords?: any[];
  incidentRecords?: IncidentRecord[];
  feedbacks?: any[];
  stats?: any;
  fieldBreakdown?: any;
  initialPersona?: ReportPersona;
  onBackToDashboard?: () => void;
  onClose?: () => void;
  targetReportId?: string;
}

export const getRecordYearMonth = (val: any): string | null => {
  if (!val) return null;
  if (typeof val === 'object' && val.seconds) {
    const d = new Date(val.seconds * 1000);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }
  const s = String(val).trim();
  const isoMatch = s.match(/^(\d{4})[-/](\d{2})/);
  if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}`;
  const euMatch = s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})/);
  if (euMatch) return `${euMatch[3]}-${euMatch[2].padStart(2, '0')}`;
  const num = Number(s);
  if (!isNaN(num) && num > 1000000000) {
    const d = new Date(num > 1000000000000 ? num : num * 1000);
    if (!isNaN(d.getTime())) {
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    }
  }
  const parsed = new Date(s);
  if (!isNaN(parsed.getTime())) {
    return `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, '0')}`;
  }
  return null;
};

const MONTHS_LIST = [
  { value: 'ALL', tr: 'Tüm Dönemler (Ana Pano)' },
  { value: '01', tr: 'Ocak' },
  { value: '02', tr: 'Şubat' },
  { value: '03', tr: 'Mart' },
  { value: '04', tr: 'Nisan' },
  { value: '05', tr: 'Mayıs' },
  { value: '06', tr: 'Haziran' },
  { value: '07', tr: 'Temmuz' },
  { value: '08', tr: 'Ağustos' },
  { value: '09', tr: 'Eylül' },
  { value: '10', tr: 'Ekim' },
  { value: '11', tr: 'Kasım' },
  { value: '12', tr: 'Aralık' }
];

export interface StaffTask {
  id: string;
  title: string;
  completed: boolean;
  dueDate?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  department: 'FIELD' | 'STORAGE' | 'LOGISTICS' | 'QUALITY' | 'PACKAGING';
  departmentLabel: string;
  assignedTasks: number;
  completedTasks: number;
  performanceScore: number;
  tasksList: StaffTask[];
}

export interface ScientificBadgeData {
  title: string;
  category: string;
  description: string;
  formula?: string;
  tableHeaders?: string[];
  tableRows?: string[][];
  criteria: string[];
}

export const SCIENTIFIC_BADGES_DATA: Record<string, ScientificBadgeData> = {
  WSU: {
    title: 'WSU (Washington State University) Nişasta-İyot Skalası',
    category: 'Bilimsel Hasat & Olgunluk Metodu',
    description: 'Elma meyvelerinde nişastanın şekere (glikoz/fruktoz) hidrolizini potasyum iyodür (Lugol) çözeltisi reaksiyonu ile 1-6 / 1-8 skalasında ölçen küresel standart testtir.',
    formula: 'WSU İndeksi = Çekirdek evresinden dış kabuğa doğru beyazlaşan (şekere dönen) radyal doku yüzdesi.',
    tableHeaders: ['Skala Değeri', 'Nişasta Oranı', 'Önerilen Depolama Rejimi & Hasat Kararı'],
    tableRows: [
      ['Skala 1 - 2', '%90 - %100 Nişasta', 'Meyve hamdır; dalında bekletilmelidir.'],
      ['Skala 3 - 4', '%60 - %80 Nişasta', 'Kontrollü Atmosfer (CA/DCA, 6-9 Ay) ideal depolama penceresi.'],
      ['Skala 5 - 6', '%30 - %50 Nişasta', 'Taze tüketim ve hızlı ihracat sevk pencereleri.'],
      ['Skala 7 - 8', '< %20 Nişasta', 'Aşırı olgun; iç unlanma riski yüksek, Freeze-Dry/Sanayi sevk.']
    ],
    criteria: [
      'Skala 1 - 2: Nişasta %90-100 dolu (Tamamen koyu lacivert/siyah) -> Meyve hamdır, dalında bekletilmelidir.',
      'Skala 3 - 4: Çekirdek evi açılmış, kanallar belirginleşmiş -> Kontrollü Atmosfer (CA/DCA, 6-9 Ay) depolama için en ideal hasat penceresidir.',
      'Skala 5 - 6: Nişastanın %60\'ı hidroliz olmuş -> Doğrudan taze pazar ve hızlı ihracat tüketim olgunluğu.',
      'Skala 7 - 8: Nişasta tamamen yok -> Aşırı olgun, iç unlanma ve fizyolojik çürüme riski yüksektir.'
    ]
  },
  CTIFL: {
    title: 'CTIFL Hasat & Streif İndeksi Kılavuzu',
    category: 'Avrupa Meyve Hasat & Depolama Standardı',
    description: 'Fransa ve Avrupa Birliği akreditasyonunda kullanılan CTIFL olgunluk endeksleri, Streif İndeksi formülasyonu ile hasat zamanını gün bazında kesinleştirir.',
    formula: 'Streif İndeksi (SI) = Sertlik (kg/cm²) / [ Brix (°Bx) × Nişasta İndeksi (1-10) ]',
    tableHeaders: ['Streif İndeksi (SI)', 'Depolama Rejimi', 'Ticari Karar & İhracat Primi'],
    tableRows: [
      ['> 0.18 SI', 'ULO / Dinamik CA (9 Ay)', 'Erken/Mükemmel depolama kalitesi, yüksek ihracat primi.'],
      ['0.10 - 0.18 SI', 'Standart Soğuk Depo (3-6 Ay)', 'Optimum ihracat ve taze pazar kalitesi.'],
      ['0.07 - 0.09 SI', 'Kısa Depo (< 1 Ay)', 'İç pazar taze satış sevk zorunluluğu.'],
      ['< 0.07 SI', 'Depolanamaz', 'Acil tüketim veya kurutma/Freeze-Dry sanayi.']
    ],
    criteria: [
      'SI > 0.18: ULO (Ultra Low Oxygen) & Dinamik CA depolarında 9 aya kadar saklanabilir.',
      'SI 0.10 - 0.18: Standart soğuk depolarda 3-6 ay depolama için optimum ihracat standardı.',
      'SI < 0.07: Acil sevk veya kurutma/sanayi (Freeze-Dry) işleme yönlendirmesi.'
    ]
  },
  ORTA_ASYA: {
    title: 'Orta Asya & Türkmenistan Bölgesel İklim Kalibrasyonu',
    category: 'Coğrafi & İklimsel Adaptasyon Kılavuzu',
    description: 'Ahal, Mary, Lebap ve Daşoguz havzalarında yaz aylarında hava sıcaklığı 40°C üzerine çıktığı için meyve solunum hızı 3 kat artar. Gece-gündüz sıcaklık farkının azaldığı dönemlerde şekerlenme hızlanırken sertlik ani düşüş gösterebilir.',
    formula: 'Sıcak Saat Hasat Durdurma Protokolü: Günlük hasat 11:00 - 16:30 arası durdurulmalı; tarladan depoya pulldown < 4 saat olmalıdır.',
    tableHeaders: ['Çeşit / Zaman Penceresi', 'Sıcaklık / İklim Koşulu', 'Saha Operasyon Kuralı'],
    tableRows: [
      ['Sabah Hasadı (05:30-11:00)', '< 28°C Meyve Eti', 'Meyve eti sertliği korunur, direkt hızlı soğutmaya alınır.'],
      ['Öğle Durdurma (11:00-16:30)', '> 38°C Ortam', 'Hasat yasaktır; toplanan kasalar güneş altında bekletilemez.'],
      ['Gala, Golden & Fuji', 'Erken Şekerlenme', 'Sıcak iklimde Streif indeksi hızlı düşer, nakil ivmelendirilir.']
    ],
    criteria: [
      'Gala, Golden ve Fuji: Sıcak iklimde erken şekerlenme yapar, Streif indeksi beklenenden erken düşer.',
      'Sabah Hasadı Zorunluluğu: 05:30 - 11:00 arası hasat edilen partilerin meyve eti sıcaklığı 18°C altındadır.',
      'Gölgeleme & Hızlı Nakil: Parselde toplanan kasalar doğrudan güneş altında 20 dakikadan fazla bekletilmemelidir.'
    ]
  },
  UNECE: {
    title: 'UNECE FFV-26 (Taze Elma Uluslararası Ticari Standardı)',
    category: 'Birleşmiş Milletler Avrupa Ekonomik Komisyonu Standartları',
    description: 'Birleşmiş Milletler UNECE FFV-26 standardı, taze elma partilerinin uluslararası ihracat kalitesi, boyut homojenliği ve kusur toleranslarını belirler.',
    formula: 'Tolerans: Ekstra Sınıf için maks %5; Sınıf I için maks %10 kalite sapması kabul edilir.',
    tableHeaders: ['Kalite Sınıfı', 'Maks. Kusur Toleransı', 'Çap & Kabuk Standartları', 'Ticari Hedef'],
    tableRows: [
      ['Ekstra Sınıf', 'Maksimum %5', 'Kusursuz, sapı tam, lekesiz, %100 renk', 'Süpermarket & İhracat Primi'],
      ['Sınıf I', 'Maksimum %10', 'Hafif renk/şekil kusuru, kabuk lekesi < 1cm²', 'Standart İhracat & Toptan Market'],
      ['Sınıf II', 'Maksimum %10', 'Kabuk lekesi < 2.5cm², taze tüketime uygun', 'İç Pazar Yerel Tüketim'],
      ['Sanayi / Iskarta', 'Tolerans Dışı', 'Gözle görülür çürük veya şekil bozukluğu', 'Kurutma & Meyve Suyu Sanayi']
    ],
    criteria: [
      'Ekstra Sınıf: Kusursuz kalitede; sapı tam, lekesiz ve çeşit tipikliğini 100% gösteren meyveler (%5 tolerans).',
      'Sınıf I: Hafif şekil veya renk kusurları tolere edilir; kabuk kusuru toplamda 1.0 cm²\'yi aşamaz (%10 tolerans).',
      'Sınıf II: Taze tüketime uygun, kabuk lekesi 2.5 cm²\'yi geçmeyen ürünler (%10 tolerans).',
      'Sanayi / Iskarta: Bu standartlara uymayan partiler Freeze-Dry veya konsantre meyve suyu tesisine yönlendirilir.'
    ]
  },
  CODEX_STAN: {
    title: 'Codex STAN 299-2010 (Codex Alimentarius Taze Elma Standardı)',
    category: 'Dünya Sağlık Örgütü (WHO) & FAO Gıda Standardı',
    description: 'Codex Alimentarius Komisyonu tarafından belirlenen küresel gıda güvenliği ve ihracat toleransı parametreleridir.',
    formula: 'MRL Uyumu: Sıfır kimyasal kalıntı sapması (Codex CAC/MRL 02).',
    tableHeaders: ['Kalite Parametresi', 'Codex Eşik Değeri', 'Uluslararası Uyumluluk Kuralı'],
    tableRows: [
      ['Asgari Şeker (Brix)', '≥ 11.5° - 13.0° Bx', 'Çeşidine göre asgari şekerleşme alt sınırı.'],
      ['Asgari Sertlik', '≥ 6.0 - 7.5 kg/cm²', 'Nakliye ve raf ömrü mukavemeti için penetrometre sınırı.'],
      ['Pestisit Kalıntısı (MRL)', '0.0 ppm Sapma (CAC/MRL 02)', 'Sertifikalı laboratuvar analiz raporu zorunlu.'],
      ['PHI İlaç Arınma', 'Son Uygulama Güvencesi', 'Hasat öncesi ilaçlama bekleme süresi sertifikalandırılmış olmalıdır.']
    ],
    criteria: [
      'Minimum Şeker (Brix): Çeşidine göre asgari 11.5° - 13.0° Brix gereklidir.',
      'Minimum Sertlik: Çeşidine göre penetrometrede asgari 6.0 - 7.5 kg/cm² olmalıdır.',
      'İlaç Arınma Süresi (PHI): Hasat öncesi son ilaçlama bekleme süresi sertifikalandırılmış olmalıdır.'
    ]
  }
};



export const MonthlyQualityReportView: React.FC<MonthlyQualityReportViewProps> = ({
  references: allReferences = [],
  harvestRecords: allHarvestRecords = [],
  fieldRecords: allFieldRecords = [],
  lojistikRecords: allLojistikRecords = [],
  ambarRecords: allAmbarRecords = [],
  incidentRecords: allIncidentRecords = [],
  initialPersona = 'ALL',
  onBackToDashboard,
  onClose,
  targetReportId
}) => {
  const handleBack = onBackToDashboard || onClose || (() => {});

  // v2.8: Ürün filtresi — farklı ürünlerin Brix/sertlik ortalamaları karışmasın (ör. Elma ve Hurma Hachiya)
  const [productFilter, setProductFilter] = useState<string>('ALL');
  const baseProduct = (p: string) => p.replace(/\s*\(.*\)\s*$/, '').trim();
  const productOf = (refId?: string, own?: string) => baseProduct(own || allReferences.find(r => r.refId === refId)?.product || '');
  const productOptions = useMemo(() => {
    const set = new Set<string>();
    allReferences.forEach(r => r.product && set.add(baseProduct(r.product)));
    allFieldRecords.forEach(f => f.product && set.add(baseProduct(f.product)));
    return Array.from(set).filter(Boolean).sort((a, b) => a.localeCompare(b, 'tr'));
  }, [allReferences, allFieldRecords]);
  const matchP = (p: string) => productFilter === 'ALL' || p.toLocaleLowerCase('tr') === productFilter.toLocaleLowerCase('tr');
  const references = useMemo(() => allReferences.filter(r => matchP(baseProduct(r.product || ''))), [allReferences, productFilter]);
  const harvestRecords = useMemo(() => allHarvestRecords.filter(h => matchP(productOf(h.refId, (h as any).product))), [allHarvestRecords, allReferences, productFilter]);
  const fieldRecords = useMemo(() => allFieldRecords.filter(f => matchP(productOf(f.refId, f.product))), [allFieldRecords, allReferences, productFilter]);
  const lojistikRecords = useMemo(() => allLojistikRecords.filter(l => matchP(productOf(l.refId, (l as any).product))), [allLojistikRecords, allReferences, productFilter]);
  const ambarRecords = useMemo(() => allAmbarRecords.filter(a => matchP(productOf(a.refId, (a as any).product))), [allAmbarRecords, allReferences, productFilter]);
  const incidentRecords = useMemo(() => allIncidentRecords.filter(i => matchP(productOf(i.refId, (i as any).product))), [allIncidentRecords, allReferences, productFilter]);
  const mixedProductsInTests = productFilter === 'ALL' && new Set(allFieldRecords.map(f => productOf(f.refId, f.product).toLocaleLowerCase('tr')).filter(Boolean)).size > 1;

  // DÖNEM SEÇİCİ - En son operasyonel kaydı olan ayı veya mevcut ayı tespit et
  const initialPeriod = useMemo(() => {
    const allDates: any[] = [];
    references.forEach(r => { if (r.createdAt || (r as any).timestamp) allDates.push(r.createdAt || (r as any).timestamp); });
    harvestRecords.forEach(h => { if (h.recordDate || h.timestamp) allDates.push(h.recordDate || h.timestamp); });
    fieldRecords.forEach(f => { if (f.timestamp || (f as any).testDate) allDates.push(f.timestamp || (f as any).testDate); });
    ambarRecords.forEach(a => { if (a.acceptanceDate || a.timestamp) allDates.push(a.acceptanceDate || a.timestamp); });
    incidentRecords.forEach(i => { if (i.timestamp || i.incidentDate) allDates.push(i.timestamp || i.incidentDate); });

    const validYMs = allDates
      .map(d => getRecordYearMonth(d))
      .filter((ym): ym is string => Boolean(ym))
      .sort()
      .reverse();

    if (validYMs.length > 0) {
      const [y, m] = validYMs[0].split('-');
      return { year: y, month: m };
    }
    const now = new Date();
    return {
      year: String(now.getFullYear()),
      month: String(now.getMonth() + 1).padStart(2, '0')
    };
  }, [references, harvestRecords, fieldRecords, ambarRecords, incidentRecords]);

  const [selectedYear, setSelectedYear] = useState<string>(initialPeriod.year);
  const [selectedMonthNumber, setSelectedMonthNumber] = useState<string>(initialPeriod.month);

  const selectedMonthKey = useMemo(() => {
    if (selectedMonthNumber === 'ALL') return `${selectedYear}-ALL`;
    return `${selectedYear}-${selectedMonthNumber}`;
  }, [selectedYear, selectedMonthNumber]);

  const availableYears = useMemo(() => ['2027', '2026', '2025', '2024'], []);

  const formatMonthLabel = (mKey: string) => {
    if (mKey.includes('ALL')) return `Tüm Dönemler (${selectedYear})`;
    const [year, month] = mKey.split('-');
    const mInfo = MONTHS_LIST.find(m => m.value === month) || { tr: month };
    return `${mInfo.tr} ${year}`;
  };

  // PAYDAŞ BAZLI SEÇMELİ GÖRÜNÜM (PERSONA)
  const [selectedPersona, setSelectedPersona] = useState<ReportPersona>(initialPersona);

  // AKORDEON (AÇILIR-KAPANIR) AÇIKLIK DURUMU
  const [openAccordions, setOpenAccordions] = useState<Record<string, boolean>>({
    'R-01': true,
    'R-02': true,
    'R-03': false,
    'R-04': false,
    'R-05': false,
    'R-06': true
  });

  const setAllAccordions = (open: boolean) => {
    setOpenAccordions({
      'R-01': open,
      'R-02': open,
      'R-03': open,
      'R-04': open,
      'R-05': open,
      'R-06': open
    });
  };

  const handleSelectPersona = (persona: ReportPersona) => {
    setSelectedPersona(persona);
    if (persona === 'MANAGER') {
      setOpenAccordions({ 'R-01': false, 'R-02': false, 'R-03': true, 'R-04': true, 'R-05': false, 'R-06': true });
    } else if (persona === 'FINANCE') {
      setOpenAccordions({ 'R-01': false, 'R-02': true, 'R-03': false, 'R-04': false, 'R-05': true, 'R-06': false });
    } else if (persona === 'PRODUCER') {
      setOpenAccordions({ 'R-01': true, 'R-02': true, 'R-03': false, 'R-04': false, 'R-05': false, 'R-06': true });
    } else if (persona === 'OPERATOR') {
      setOpenAccordions({ 'R-01': true, 'R-02': false, 'R-03': false, 'R-04': true, 'R-05': false, 'R-06': true });
    } else {
      setOpenAccordions({ 'R-01': true, 'R-02': true, 'R-03': false, 'R-04': false, 'R-05': false, 'R-06': true });
    }
  };

  // TARGET REPORT ID SCROLL & OPEN EFFECT
  useEffect(() => {
    if (targetReportId) {
      setOpenAccordions(prev => ({ ...prev, [targetReportId]: true }));
      setTimeout(() => {
        const el = document.getElementById(`report-${targetReportId}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 150);
    }
  }, [targetReportId]);

  const toggleAccordion = (id: string) => {
    setOpenAccordions(prev => ({ ...prev, [id]: !prev[id] }));
  };



  // MODAL DURUMLARI
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [selectedStaffDetail, setSelectedStaffDetail] = useState<StaffMember | null>(null);
  const [isSavingFirestore, setIsSavingFirestore] = useState<boolean>(false);
  const [activeRefBadgeModal, setActiveRefBadgeModal] = useState<ScientificBadgeData | null>(null);

  // FIRESTORE VERİLERİ
  const [firestoreReportData, setFirestoreReportData] = useState<Record<string, any>>({});

  useEffect(() => {
    let isMounted = true;
    try {
      const docRef = doc(db, 'monthlyQualityReports', selectedMonthKey);
      const unsubscribe = onSnapshot(docRef, (docSnap) => {
        if (isMounted) {
          if (docSnap.exists()) {
            setFirestoreReportData(prev => ({ ...prev, [selectedMonthKey]: docSnap.data() }));
          } else {
            setFirestoreReportData(prev => ({ ...prev, [selectedMonthKey]: {} }));
          }
        }
      }, (err) => {
        console.warn('[MonthlyReport] Firestore onSnapshot uyarısı:', err);
      });
      return () => {
        isMounted = false;
        unsubscribe();
      };
    } catch {
      fetchMonthlyReportsFromFirestore(selectedMonthKey)
        .then(res => {
          if (isMounted && res && res[selectedMonthKey]) {
            setFirestoreReportData(prev => ({ ...prev, [selectedMonthKey]: res[selectedMonthKey] }));
          }
        })
        .catch(err => {
          console.warn('[MonthlyReport] Firestore okuma uyarısı:', err);
        });
      return () => {
        isMounted = false;
      };
    }
  }, [selectedMonthKey]);

  const activeMonthOverride = firestoreReportData[selectedMonthKey] || {};

  // Operasyonel Veri Eşleştirme (Tarih bazlı)
  const isDateInSelectedPeriod = (dateVal?: any) => {
    if (selectedMonthNumber === 'ALL') return true;
    if (!dateVal) return false;
    const ym = getRecordYearMonth(dateVal);
    return ym === selectedMonthKey;
  };

  const filteredRefs = useMemo(() => references.filter(r => isDateInSelectedPeriod(r.createdAt || (r as any).timestamp)), [references, selectedMonthKey, selectedMonthNumber]);
  const filteredHarvests = useMemo(() => harvestRecords.filter(h => isDateInSelectedPeriod(h.recordDate || h.timestamp || (h as any).date)), [harvestRecords, selectedMonthKey, selectedMonthNumber]);
  const filteredFields = useMemo(() => fieldRecords.filter(f => isDateInSelectedPeriod(f.timestamp || (f as any).testDate || (f as any).date)), [fieldRecords, selectedMonthKey, selectedMonthNumber]);
  const filteredAmbar = useMemo(() => ambarRecords.filter(a => isDateInSelectedPeriod(a.acceptanceDate || a.timestamp || (a as any).date)), [ambarRecords, selectedMonthKey, selectedMonthNumber]);
  const filteredIncidents = useMemo(() => incidentRecords.filter(i => isDateInSelectedPeriod(i.incidentDate || i.timestamp || (i as any).date)), [incidentRecords, selectedMonthKey, selectedMonthNumber]);

  // ANA PANO GENEL CANLI HESAPLAMALARI (Tüm operasyonel tablolardan anlık türetilir)
  const dashboardCalculations = useMemo(() => {
    // 1. Saha testleri: Sertlik, Brix, Nişasta
    let dashH = 0, countH = 0;
    let dashB = 0, countB = 0;
    let dashS = 0, countS = 0;

    fieldRecords.forEach(rec => {
      if (rec.avgHardness > 0) {
        dashH += rec.avgHardness;
        countH++;
      } else if (rec.samples && rec.samples.length > 0) {
        const sHard = rec.samples.filter(s => s.hardness > 0);
        if (sHard.length > 0) {
          dashH += sHard.reduce((acc, s) => acc + s.hardness, 0) / sHard.length;
          countH++;
        }
      }

      if (rec.avgBrix > 0) {
        dashB += rec.avgBrix;
        countB++;
      } else if (rec.samples && rec.samples.length > 0) {
        const sBrix = rec.samples.filter(s => s.brix > 0);
        if (sBrix.length > 0) {
          dashB += sBrix.reduce((acc, s) => acc + s.brix, 0) / sBrix.length;
          countB++;
        }
      }

      if (rec.starchIndex && rec.starchIndex > 0) {
        dashS += rec.starchIndex;
        countS++;
      } else if (rec.samples && rec.samples.length > 0) {
        const sStarch = rec.samples.filter(s => s.starch !== undefined && s.starch > 0);
        if (sStarch.length > 0) {
          dashS += sStarch.reduce((acc, s) => acc + (s.starch || 0), 0) / sStarch.length;
          countS++;
        }
      }
    });

    const hardness = countH > 0 ? Number((dashH / countH).toFixed(1)) : 0;
    const brix = countB > 0 ? Number((dashB / countB).toFixed(1)) : 0;
    const starch = countS > 0 ? Number((dashS / countS).toFixed(1)) : 0;

    // 2. Hasat & Kalite Dağılımı & Hacim
    let totalHarvestKg = 0;
    let extraKg = 0;
    let c1Kg = 0;
    let c2Kg = 0;
    let indKg = 0;

    harvestRecords.forEach(h => {
      const kg = Number(h.dailyTotalKg) || 0;
      totalHarvestKg += kg;
      const g = (h.kaliteSinifi || '').toUpperCase();
      if (g.includes('EKSTRA') || g.includes('EXTRA') || g.includes('V-20')) {
        extraKg += kg;
      } else if (g.includes('1.') || g.includes('I ') || g.includes('V-22')) {
        c1Kg += kg;
      } else if (g.includes('2.') || g.includes('II ') || g.includes('V-24')) {
        c2Kg += kg;
      } else {
        indKg += kg;
      }
    });

    // Parti referanslarından toplam kg hesabı
    let totalRefKg = 0;
    references.forEach(r => {
      let q = Number(r.quantity) || 0;
      const u = (r.unit || '').toLowerCase();
      if (u.includes('ton')) q *= 1000;
      totalRefKg += q;
    });

    const effectiveTotalKg = totalHarvestKg > 0 ? totalHarvestKg : totalRefKg;
    const totalTons = Number((effectiveTotalKg / 1000).toFixed(1));

    const extraPct = totalHarvestKg > 0
      ? Number(((extraKg / totalHarvestKg) * 100).toFixed(1))
      : (references.length > 0 ? 60 : 0);
    const class1Pct = totalHarvestKg > 0
      ? Number(((c1Kg / totalHarvestKg) * 100).toFixed(1))
      : (references.length > 0 ? 30 : 0);
    const fireRatePct = totalHarvestKg > 0 ? 1.5 : 0;

    // 3. Olaylar
    const openInc = incidentRecords.filter(i => i.status !== 'RESOLVED' && i.status !== 'CLOSED');
    const openCount = openInc.length;
    const derece1 = openInc.filter(i => i.priority === 'HIGH' || (i as any).severity === 'HIGH' || i.actDegree === 1).length;
    const derece2 = openInc.filter(i => i.priority === 'MEDIUM' || (i as any).severity === 'MEDIUM' || i.actDegree === 2).length;

    const totalRecords = fieldRecords.length + harvestRecords.length + references.length + ambarRecords.length + incidentRecords.length;

    return {
      hardness,
      brix,
      starch,
      extraPct,
      class1Pct,
      fireRatePct,
      totalTons,
      openCount,
      derece1,
      derece2,
      totalRecords
    };
  }, [fieldRecords, harvestRecords, references, ambarRecords, incidentRecords]);

  // Dönemde veri var mı kontrolü
  const hasPeriodData = useMemo(() => {
    const hasOp = filteredRefs.length > 0 || filteredHarvests.length > 0 || filteredFields.length > 0 || filteredAmbar.length > 0 || filteredIncidents.length > 0;
    const hasOverride = Boolean(activeMonthOverride && Object.keys(activeMonthOverride).length > 0);
    return hasOp || hasOverride;
  }, [filteredRefs, filteredHarvests, filteredFields, filteredAmbar, filteredIncidents, activeMonthOverride]);

  // =========================================================================
  // RAPOR R-01: STREIF İNDEKSİ VE HASAT ZAMANLAMASI
  // =========================================================================
  const r01Data = useMemo(() => {
    const ov = activeMonthOverride.r01Streif || {};
    const hasOverride = ov.hardness !== undefined && ov.brix !== undefined && ov.starch !== undefined;

    let fieldH: number | null = null;
    let fieldB: number | null = null;
    let fieldS: number | null = null;

    if (filteredFields.length > 0) {
      let sumH = 0, countH = 0;
      let sumB = 0, countB = 0;
      let sumS = 0, countS = 0;

      for (const rec of filteredFields) {
        if (rec.avgHardness > 0) { sumH += rec.avgHardness; countH++; }
        if (rec.avgBrix > 0) { sumB += rec.avgBrix; countB++; }
        if (rec.samples && rec.samples.length > 0) {
          for (const s of rec.samples) {
            if (s.starch !== undefined && s.starch > 0) {
              sumS += s.starch;
              countS++;
            }
          }
        }
      }
      if (countH > 0) fieldH = Number((sumH / countH).toFixed(2));
      if (countB > 0) fieldB = Number((sumB / countB).toFixed(2));
      if (countS > 0) fieldS = Number((sumS / countS).toFixed(1));
    }

    const hasRealStreif = hasOverride || (fieldH !== null && fieldB !== null && fieldS !== null);

    if (!hasRealStreif) {
      return {
        hasStreifData: false,
        isEdited: hasOverride,
        hardness: 0,
        brix: 0,
        starch: 0,
        streifIndex: 0,
        stage: 'OPTIMAL_HARVEST' as const,
        stageLabel: 'Veri Yok',
        stageColor: 'text-slate-400',
        pointerPercent: 50,
        commercialNote: 'Bu döneme ait saha test kaydı (Brix, Sertlik, İyot) bulunamadı.'
      };
    }

    const hardness = ov.hardness !== undefined ? Number(ov.hardness) : (fieldH ?? 0);
    const brix = ov.brix !== undefined ? Number(ov.brix) : (fieldB ?? 0);
    const starch = ov.starch !== undefined ? Number(ov.starch) : (fieldS ?? 0);

    const rawSI = (brix * starch) > 0 ? (hardness / (brix * starch)) : 0;
    const streifIndex = Number(rawSI.toFixed(3));

    let stage: 'LONG_STORAGE' | 'OPTIMAL_HARVEST' | 'FRESH_SALE';
    let stageLabel = '';
    let stageColor = '';
    let pointerPercent = 50;

    if (streifIndex >= 0.18) {
      stage = 'LONG_STORAGE';
      stageLabel = 'Uzun Depolama (6-9 Ay CA/DCA)';
      stageColor = 'text-sky-400';
      pointerPercent = Math.min(95, 70 + ((streifIndex - 0.18) / 0.08) * 25);
    } else if (streifIndex >= 0.10) {
      stage = 'OPTIMAL_HARVEST';
      stageLabel = 'Optimum Hasat (3-6 Ay Depolama)';
      stageColor = 'text-emerald-400';
      pointerPercent = 30 + ((streifIndex - 0.10) / 0.08) * 40;
    } else {
      stage = 'FRESH_SALE';
      stageLabel = 'Taze Satış & Sanayi (<1 Ay)';
      stageColor = 'text-amber-400';
      pointerPercent = Math.max(5, 5 + ((streifIndex - 0.04) / 0.06) * 25);
    }

    let calculatedCommercialNote = '';
    if (streifIndex < 0.07) {
      calculatedCommercialNote = 'Acil Satış & Sanayi Sevk: Nişasta tamamen hidroliz olmuş (SI < 0.07), iç yumuşama riski yüksek.';
    } else if (streifIndex < 0.10) {
      calculatedCommercialNote = 'Kısa Dönem Depolama (1-2 Ay): Ürün tüketim olgunluğundadır (SI 0.07 - 0.09).';
    } else if (streifIndex <= 0.18) {
      calculatedCommercialNote = 'Optimum Hasat & Uzun Dönem CA Depolama (6-9 Ay): Streif indeksi mükemmel (0.10 - 0.18 SI).';
    } else {
      calculatedCommercialNote = 'Erken Hasat / Dalında Bekleme: Nişasta açılımı henüz yetersiz (SI > 0.18).';
    }
    const commercialNote = ov.commercialNote || calculatedCommercialNote;

    return {
      hasStreifData: true,
      isEdited: hasOverride,
      hardness,
      brix,
      starch,
      streifIndex,
      stage,
      stageLabel,
      stageColor,
      pointerPercent,
      commercialNote
    };
  }, [filteredFields, activeMonthOverride]);

  // =========================================================================
  // RAPOR R-02: KALİTE SINIFLANDIRMASI VE FİRE/KAYIP
  // =========================================================================
  const r02Data = useMemo(() => {
    const ov = activeMonthOverride.r02QualityFire || {};
    const hasOverride = ov.extraPct !== undefined || ov.fireRatePct !== undefined || ov.totalTons !== undefined;
    const hasHarvests = filteredHarvests.length > 0;

    if (!hasOverride && !hasHarvests) {
      return {
        hasQualityFireData: false,
        isEdited: hasOverride,
        extraPct: 0,
        class1Pct: 0,
        class2Pct: 0,
        industryPct: 0,
        fireRatePct: 0,
        totalTons: 0,
        estLossKg: 0,
        estLossTmt: 0,
        pieData: [],
        isFireHigh: false,
        commercialNote: 'Bu döneme ait hasat veya kalite sınıflandırma kaydı bulunamadı.'
      };
    }

    let computedTotalKg = 0;
    let extraKg = 0;
    let c1Kg = 0;
    let c2Kg = 0;
    let indKg = 0;

    filteredHarvests.forEach(h => {
      const kg = Number(h.dailyTotalKg) || 0;
      computedTotalKg += kg;
      const grade = (h.kaliteSinifi || '').toUpperCase();
      if (grade.includes('EKSTRA') || grade.includes('EXTRA') || grade.includes('V-20')) {
        extraKg += kg;
      } else if (grade.includes('1.') || grade.includes('I ') || grade.includes('V-22')) {
        c1Kg += kg;
      } else if (grade.includes('2.') || grade.includes('II ') || grade.includes('V-24')) {
        c2Kg += kg;
      } else {
        indKg += kg;
      }
    });

    const extraPct = ov.extraPct !== undefined ? Number(ov.extraPct) : (computedTotalKg > 0 ? Number(((extraKg / computedTotalKg) * 100).toFixed(1)) : 0);
    const class1Pct = ov.class1Pct !== undefined ? Number(ov.class1Pct) : (computedTotalKg > 0 ? Number(((c1Kg / computedTotalKg) * 100).toFixed(1)) : 0);
    const class2Pct = ov.class2Pct !== undefined ? Number(ov.class2Pct) : (computedTotalKg > 0 ? Number(((c2Kg / computedTotalKg) * 100).toFixed(1)) : 0);
    const industryPct = ov.industryPct !== undefined ? Number(ov.industryPct) : (computedTotalKg > 0 ? Number(((indKg / computedTotalKg) * 100).toFixed(1)) : 0);

    const totalTons = ov.totalTons !== undefined ? Number(ov.totalTons) : (computedTotalKg > 0 ? Number((computedTotalKg / 1000).toFixed(1)) : 0);

    const fireRatePct = ov.fireRatePct !== undefined ? Number(ov.fireRatePct) : 0;
    const estLossKg = Math.round((totalTons * 1000) * (fireRatePct / 100));
    const estLossTmt = Math.round(estLossKg * 10);

    const isSumInconsistent = (extraPct + class1Pct + fireRatePct) > 100;

    const pieData = [
      { name: 'Ekstra Kalite', value: extraPct, color: '#10b981' },
      { name: '1. Sınıf', value: class1Pct, color: '#06b6d4' },
      { name: '2. Sınıf', value: class2Pct, color: '#f59e0b' },
      { name: 'Sanayi / Iskarta', value: industryPct, color: '#ef4444' }
    ].filter(p => p.value > 0);

    const isFireHigh = fireRatePct > 2.5;

    let calculatedR02Note = '';
    if (totalTons === 0) {
      calculatedR02Note = 'Bu dönemde kayıtlı tonaj bulunmuyor.';
    } else if (fireRatePct <= 1.5) {
      calculatedR02Note = `Mükemmel Kalite & Fire Kontrolü: %${fireRatePct.toFixed(1)} fire oranı hedef aralıktadır.`;
    } else {
      calculatedR02Note = `Fire Oranı Dikkat Çekiyor: %${fireRatePct.toFixed(1)} fire oranı mevcut.`;
    }
    const commercialNote = ov.commercialNote || calculatedR02Note;

    return {
      hasQualityFireData: true,
      isEdited: hasOverride,
      isSumInconsistent,
      extraPct,
      class1Pct,
      class2Pct,
      industryPct,
      fireRatePct,
      totalTons,
      estLossKg,
      estLossTmt,
      pieData,
      isFireHigh,
      commercialNote
    };
  }, [filteredHarvests, activeMonthOverride]);

  // =========================================================================
  // RAPOR R-03: BARLAG AKTY VE RİSK YÖNETİMİ
  // =========================================================================
  const r03Data = useMemo(() => {
    const ov = activeMonthOverride.r03Incidents || {};
    const hasOverride = ov.openCount !== undefined;
    const openIncidents = filteredIncidents.filter(i => i.status !== 'RESOLVED' && i.status !== 'CLOSED');

    const openCount = ov.openCount !== undefined ? Number(ov.openCount) : openIncidents.length;
    const d1 = ov.derece1 !== undefined ? Number(ov.derece1) : openIncidents.filter(i => i.priority === 'HIGH' || (i as any).severity === 'HIGH' || i.actDegree === 1).length;
    const d2 = ov.derece2 !== undefined ? Number(ov.derece2) : openIncidents.filter(i => i.priority === 'MEDIUM' || (i as any).severity === 'MEDIUM' || i.actDegree === 2).length;
    const d3 = ov.derece3 !== undefined ? Number(ov.derece3) : openIncidents.filter(i => i.priority === 'LOW' || (i as any).severity === 'LOW' || i.actDegree === 3).length;

    // Gerçek haftalık olay dağılımı (filteredIncidents tarihine göre)
    const weekCounts: Record<string, { olaySayisi: number; derece1: number }> = {
      '1. Hafta': { olaySayisi: 0, derece1: 0 },
      '2. Hafta': { olaySayisi: 0, derece1: 0 },
      '3. Hafta': { olaySayisi: 0, derece1: 0 },
      '4. Hafta': { olaySayisi: 0, derece1: 0 }
    };
    filteredIncidents.forEach(inc => {
      const dStr = inc.incidentDate || inc.timestamp || '';
      const dayNum = parseInt(dStr.slice(8, 10), 10) || 1;
      const wKey = dayNum <= 7 ? '1. Hafta' : dayNum <= 14 ? '2. Hafta' : dayNum <= 21 ? '3. Hafta' : '4. Hafta';
      weekCounts[wKey].olaySayisi++;
      if (inc.actDegree === 1 || inc.priority === 'HIGH' || (inc as any).severity === 'HIGH') {
        weekCounts[wKey].derece1++;
      }
    });

    const weeklyTrend = ov.weeklyTrend || (filteredIncidents.length > 0 ? [
      { week: '1. Hafta', olaySayisi: weekCounts['1. Hafta'].olaySayisi, derece1: weekCounts['1. Hafta'].derece1 },
      { week: '2. Hafta', olaySayisi: weekCounts['2. Hafta'].olaySayisi, derece1: weekCounts['2. Hafta'].derece1 },
      { week: '3. Hafta', olaySayisi: weekCounts['3. Hafta'].olaySayisi, derece1: weekCounts['3. Hafta'].derece1 },
      { week: '4. Hafta', olaySayisi: weekCounts['4. Hafta'].olaySayisi, derece1: weekCounts['4. Hafta'].derece1 }
    ] : []);

    // Gerçek kök neden dağılımı (filteredIncidents kategorilerine göre)
    const causeMap = new Map<string, number>();
    filteredIncidents.forEach(inc => {
      const c = inc.rootCauseCategory || inc.incidentType || 'Kalite Sapması';
      causeMap.set(c, (causeMap.get(c) || 0) + 1);
    });
    const rootCauses = ov.rootCauses || (filteredIncidents.length > 0 ? Array.from(causeMap.entries()).map(([cause, count]) => ({
      cause,
      count,
      pct: Math.round((count / Math.max(1, filteredIncidents.length)) * 100)
    })) : []);

    const managementNote = ov.managementNote || (
      openCount === 0
        ? 'Bu dönemde açık Barlag Akty bulunmamaktadır; operasyonel riskler kontrol altındadır.'
        : d1 > 0
          ? 'Kritik Derece 1 olaylar mevcut, acil DÖF başlatılmalıdır.'
          : 'Açık olaylar kontrol altındadır.'
    );

    return {
      isEdited: hasOverride,
      openCount,
      derece1: d1,
      derece2: d2,
      derece3: d3,
      weeklyTrend,
      rootCauses,
      managementNote
    };
  }, [filteredIncidents, activeMonthOverride]);

  // =========================================================================
  // RAPOR R-04: PERSONEL VE DEPARTMAN VERİMLİLİĞİ
  // =========================================================================
  const [selectedStaffDept, setSelectedStaffDept] = useState<'ALL' | 'FIELD' | 'STORAGE' | 'LOGISTICS' | 'QUALITY'>('ALL');

  const deduplicatedStaff = useMemo<StaffMember[]>(() => {
    const rawList: StaffMember[] = (activeMonthOverride.staffMembers && Array.isArray(activeMonthOverride.staffMembers) && activeMonthOverride.staffMembers.length > 0)
      ? activeMonthOverride.staffMembers
      : [];

    if (rawList.length === 0) {
      const opMap = new Map<string, StaffMember>();
      const addOp = (name: string, dept: 'FIELD' | 'STORAGE' | 'LOGISTICS' | 'QUALITY' | 'PACKAGING', label: string, role: string, taskTitle: string) => {
        const clean = name.trim();
        if (!clean) return;
        const key = clean.toLowerCase();
        const existing = opMap.get(key);
        if (existing) {
          existing.assignedTasks++;
          existing.completedTasks++;
          existing.tasksList.push({
            id: `task-${existing.tasksList.length + 1}`,
            title: taskTitle,
            completed: true
          });
          existing.performanceScore = 100;
        } else {
          opMap.set(key, {
            id: `STF-${opMap.size + 1}`,
            name: clean,
            role,
            department: dept,
            departmentLabel: label,
            assignedTasks: 1,
            completedTasks: 1,
            performanceScore: 100,
            tasksList: [
              { id: 'task-1', title: taskTitle, completed: true }
            ]
          });
        }
      };

      filteredFields.forEach(f => {
        if (f.operator) addOp(f.operator, 'FIELD', 'Saha (FIELD)', 'Saha Test Operatörü', `Saha Testi: ${f.refId}`);
      });
      filteredHarvests.forEach(h => {
        if (h.operator) addOp(h.operator, 'FIELD', 'Saha (FIELD)', 'Hasat & Kalite Sorumlusu', `Hasat Partisi: ${h.refId}`);
      });
      filteredAmbar.forEach(a => {
        if (a.operator) addOp(a.operator, 'STORAGE', 'Depo (STORAGE)', 'Ambar Kabul Sorumlusu', `Kabul Belgesi: ${a.refId}`);
      });
      filteredIncidents.forEach(i => {
        const op = i.assignedTo || i.operator;
        if (op) addOp(op, 'QUALITY', 'Kalite Lab (QUALITY)', 'Kalite Güvence & Denetim', `Barlag Akty: ${i.actNumber || i.incidentId}`);
      });

      rawList.push(...Array.from(opMap.values()));
    }

    const staffMap = new Map<string, StaffMember>();
    const seenNames = new Set<string>();

    for (const member of rawList) {
      const cleanName = (member.name || '').trim().toLowerCase();
      const cleanId = (member.id || '').trim().toUpperCase();
      if (cleanName && !seenNames.has(cleanName) && !staffMap.has(cleanId)) {
        seenNames.add(cleanName);
        staffMap.set(cleanId || cleanName, member);
      }
    }

    return Array.from(staffMap.values());
  }, [activeMonthOverride, filteredFields, filteredHarvests, filteredAmbar, filteredIncidents]);

  const filteredStaffList = useMemo(() => {
    if (selectedStaffDept === 'ALL') return deduplicatedStaff;
    return deduplicatedStaff.filter(s => s.department === selectedStaffDept);
  }, [deduplicatedStaff, selectedStaffDept]);

  const r04ManagementNote = useMemo(() => {
    const fieldStaff = deduplicatedStaff.filter(s => s.department === 'FIELD');
    const fieldCompletionRate = fieldStaff.length > 0
      ? Math.round((fieldStaff.reduce((acc, s) => acc + s.completedTasks, 0) / Math.max(1, fieldStaff.reduce((acc, s) => acc + s.assignedTasks, 0))) * 100)
      : 0;

    if (deduplicatedStaff.length === 0) {
      return 'Bu dönem için kayıtlı personel/görev verisi bulunmuyor.';
    }
    return `Tüm departmanlar ortalama %${fieldCompletionRate > 0 ? fieldCompletionRate : 100} tamamlama ile operasyonel hedeflerin üzerindedir.`;
  }, [deduplicatedStaff]);

  // =========================================================================
  // RAPOR R-05: TESİS PERFORMANSI VE KAPASİTE
  // =========================================================================
  const r05Data = useMemo(() => {
    const ov = activeMonthOverride.r05Facilities || {};
    const hasOverride = Boolean(ov.facilities && ov.facilities.length > 0);

    let facilities = ov.facilities;
    if (!facilities) {
      const warehouseMap = new Map<string, { totalKg: number; daysSum: number; count: number }>();
      filteredAmbar.forEach(a => {
        const wh = a.warehouse || 'Merkez Soğuk Depo';
        const kg = Number(a.acceptedWeightKg) || 0;
        const cur = warehouseMap.get(wh) || { totalKg: 0, daysSum: 0, count: 0 };
        cur.totalKg += kg;
        if (a.acceptanceDate) {
          const diffMs = Date.now() - new Date(a.acceptanceDate).getTime();
          const d = Math.max(0, Math.round(diffMs / (1000 * 60 * 60 * 24)));
          cur.daysSum += d;
          cur.count++;
        }
        warehouseMap.set(wh, cur);
      });

      facilities = Array.from(warehouseMap.entries()).map(([name, data]) => ({
        name,
        dolulukPct: Math.min(100, Math.round((data.totalKg / 5000000) * 100)),
        beklemeGun: data.count > 0 ? Math.round(data.daysSum / data.count) : 0,
        kapasiteTon: 5000,
        riskliLotCount: 0
      }));
    }

    const avgDoluluk = facilities.length > 0 ? Math.round(facilities.reduce((acc: number, f: any) => acc + f.dolulukPct, 0) / facilities.length) : 0;
    const criticalOverduePct = ov.criticalOverduePct !== undefined ? Number(ov.criticalOverduePct) : (
      facilities.length > 0
        ? Math.round((facilities.filter((f: any) => f.beklemeGun > 60).length / facilities.length) * 100)
        : 0
    );

    const commercialNote = ov.commercialNote || (
      facilities.length === 0
        ? 'Bu döneme ait tesis ambar kabul kaydı bulunamadı.'
        : 'Tesis rotasyonu dengeli, kritik bekleme süresini aşan parti bulunmamaktadır.'
    );

    return {
      hasFacilitiesData: facilities.length > 0,
      isEdited: hasOverride,
      facilities,
      avgDoluluk,
      criticalOverduePct,
      commercialNote
    };
  }, [filteredAmbar, activeMonthOverride]);

  // =========================================================================
  // RAPOR R-06: ZİRAİ & KALİTE TEST NUMUNELERİ ANALİZ RAPORU
  // =========================================================================
  const [selectedTestStageFilter, setSelectedTestStageFilter] = useState<'ALL' | 'HASAT_ONCESI' | 'HASAT_ZAMANI' | 'DEPODA' | 'SEVKIYAT_ONCESI'>('ALL');

  const r06Data = useMemo(() => {
    let totalSampleFruits = 0;
    let totalSampleKg = 0;

    const formattedTests = filteredFields.map(f => {
      const fruits = f.fruitCountSampled || f.sampleCount || (f.samples ? f.samples.length : 0) || 5;
      const sampleKg = f.testSampleWeightKg || (f.testSampleWeightG ? f.testSampleWeightG / 1000 : Number((fruits * 0.18).toFixed(2)));
      const avgFruitWeightG = f.avgFruitWeightG || (sampleKg > 0 && fruits > 0 ? Math.round((sampleKg * 1000) / fruits) : 180);

      totalSampleFruits += fruits;
      totalSampleKg += sampleKg;

      const stage: 'HASAT_ONCESI' | 'HASAT_ZAMANI' | 'DEPODA' | 'SEVKIYAT_ONCESI' =
        (f as any).testStage || (f.notes?.toLowerCase().includes('depo') ? 'DEPODA' : f.notes?.toLowerCase().includes('sevkiyat') ? 'SEVKIYAT_ONCESI' : f.notes?.toLowerCase().includes('ön') ? 'HASAT_ONCESI' : 'HASAT_ZAMANI');

      const stageLabelMap = {
        HASAT_ONCESI: 'Hasat Öncesi (Ön Olgunluk)',
        HASAT_ZAMANI: 'Hasat Zamanı (Kabul & Olum)',
        DEPODA: 'Hasat Sonrası / Depoda',
        SEVKIYAT_ONCESI: 'Sevkiyat / İhracat Öncesi'
      };

      const brixVal = f.avgBrix || (f.samples && f.samples.length > 0 ? Number((f.samples.reduce((acc: number, s: any) => acc + (s.brix || 0), 0) / f.samples.length).toFixed(1)) : 0);
      const hardnessVal = f.avgHardness || (f.samples && f.samples.length > 0 ? Number((f.samples.reduce((acc: number, s: any) => acc + (s.hardness || 0), 0) / f.samples.length).toFixed(1)) : 0);
      const starchVal = f.starchIndex || (f.samples && f.samples.length > 0 ? Number((f.samples.reduce((acc: number, s: any) => acc + (s.starch || 0), 0) / f.samples.length).toFixed(1)) : 0);

      return {
        id: f.id || f.refId || `TEST-${Math.random()}`,
        refId: f.refId || 'LAB-TEST',
        testType: f.testType || 'Laboratuvar Analizi',
        productName: (f as any).variety || (f as any).productName || 'Elma (Red Delicious)',
        location: f.location || (f as any).parsel || 'Saha Lab',
        testDate: (f as any).testDate || f.timestamp || new Date().toISOString().split('T')[0],
        fruits,
        sampleKg: Number(sampleKg.toFixed(2)),
        avgFruitWeightG,
        brix: brixVal,
        hardness: hardnessVal,
        starch: starchVal,
        verdict: (f as any).verdict || f.notes || 'Laboratuvar Onaylı',
        stage,
        stageLabel: stageLabelMap[stage] || stage
      };
    });

    const stageCounts = {
      HASAT_ONCESI: formattedTests.filter(t => t.stage === 'HASAT_ONCESI').length,
      HASAT_ZAMANI: formattedTests.filter(t => t.stage === 'HASAT_ZAMANI').length,
      DEPODA: formattedTests.filter(t => t.stage === 'DEPODA').length,
      SEVKIYAT_ONCESI: formattedTests.filter(t => t.stage === 'SEVKIYAT_ONCESI').length
    };

    const filteredTests = selectedTestStageFilter === 'ALL'
      ? formattedTests
      : formattedTests.filter(t => t.stage === selectedTestStageFilter);

    return {
      totalTestCount: filteredFields.length,
      totalSampleFruits,
      totalSampleKg: Number(totalSampleKg.toFixed(2)),
      formattedTests,
      filteredTests,
      stageCounts
    };
  }, [filteredFields, selectedTestStageFilter]);

  // FIRESTORE KAYDETME
  const handleSaveToFirestore = async (updatedData: any) => {
    setIsSavingFirestore(true);
    try {
      const payload = {
        monthKey: selectedMonthKey,
        ...activeMonthOverride,
        isEdited: true,
        r01Streif: updatedData.r01Streif || r01Data,
        r02QualityFire: updatedData.r02QualityFire || r02Data,
        r03Incidents: updatedData.r03Incidents || r03Data,
        staffMembers: updatedData.staffMembers || deduplicatedStaff,
        r05Facilities: updatedData.r05Facilities || r05Data
      };

      const ok = await saveMonthlyReportToFirestore(selectedMonthKey, payload);
      if (ok) {
        setFirestoreReportData(prev => ({ ...prev, [selectedMonthKey]: payload }));
        addDebugLog('STORAGE', 'INFO', `[MonthlyReport] Firestore raporu kaydedildi: ${selectedMonthKey}`);
      }
    } catch (err) {
      console.error('Firestore kaydetme hatası:', err);
    } finally {
      setIsSavingFirestore(false);
      setIsEditModalOpen(false);
    }
  };

  // OTOMATİK VERİYE SIFIRLA (MANUEL DEĞİŞİKLİKLERİ KALDIR)
  const handleResetToAutomatic = async () => {
    setIsSavingFirestore(true);
    try {
      if (db) {
        await deleteDoc(doc(db, 'monthlyQualityReports', selectedMonthKey));
      }
      setFirestoreReportData(prev => {
        const next = { ...prev };
        delete next[selectedMonthKey];
        return next;
      });
      addDebugLog('STORAGE', 'INFO', `[MonthlyReport] Manuel veriler sıfırlandı, ana pano verilerine dönüldü: ${selectedMonthKey}`);
    } catch (err) {
      console.error('Sıfırlama hatası:', err);
    } finally {
      setIsSavingFirestore(false);
      setIsEditModalOpen(false);
    }
  };

  // EXPORT CSV
  const handleExportCSV = () => {
    const rows = [
      ['MIWE HIL - OPERASYONEL KALİTE VE TİCARET RAPORLARI'],
      ['Dönem', formatMonthLabel(selectedMonthKey)],
      ['Tarih', new Date().toLocaleDateString('tr-TR')],
      [''],
      ['R-01: STREIF İNDEKSİ VE HASAT ZAMANLAMASI'],
      ['Sertlik (kg/cm2)', r01Data.hardness],
      ['Brix (% Şeker)', r01Data.brix],
      ['Nişasta İndeksi (1-10)', r01Data.starch],
      ['Streif İndeksi (SI)', r01Data.streifIndex],
      ['Hasat/Depolama Kararı', r01Data.stageLabel],
      ['Ticari Yansıma', r01Data.commercialNote],
      [''],
      ['R-02: KALİTE SINIFLANDIRMASI VE FİRE/KAYIP'],
      ['Ekstra Kalite Payı (%)', `${r02Data.extraPct}%`],
      ['1. Sınıf Kalite Payı (%)', `${r02Data.class1Pct}%`],
      ['Fire Oranı (%)', `${r02Data.fireRatePct}%`],
      ['Tahmini Fire Miktarı (kg)', `${r02Data.estLossKg} kg`],
      ['Tahmini Finansal Kayıp (TMT)', `${r02Data.estLossTmt} TMT`],
      ['Ticari Yansıma', r02Data.commercialNote],
      [''],
      ['R-03: BARLAG AKTY VE RİSK YÖNETİMİ'],
      ['Açık Olay Sayısı', r03Data.openCount],
      ['Derece 1 (Kritik)', r03Data.derece1],
      ['Derece 2 (Majör)', r03Data.derece2],
      ['Yönetimsel Yansıma', r03Data.managementNote],
      [''],
      ['R-04: PERSONEL VE DEPARTMAN VERİMLİLİĞİ'],
      ['Personel', 'Görev', 'Departman', 'Tamamlanan', 'Atanan', 'Skor'],
      ...deduplicatedStaff.map(s => [s.name, s.role, s.departmentLabel, s.completedTasks, s.assignedTasks, `${s.performanceScore}/100`]),
      ['Yönetimsel Yansıma', r04ManagementNote],
      [''],
      ['R-05: TESİS PERFORMANSI VE KAPASİTE'],
      ['Tesis', 'Doluluk (%)', 'Ortalama Bekleme (Gün)', 'Kapasite (Ton)'],
      ...r05Data.facilities.map((f: any) => [f.name, `${f.dolulukPct}%`, `${f.beklemeGun} Gün`, `${f.kapasiteTon} Ton`]),
      ['Ticari Yansıma', r05Data.commercialNote]
    ];

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + rows.map(e => e.join(';')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MIWE_Raporlama_Merkezi_${selectedMonthKey}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen w-full max-w-full overflow-x-hidden p-3 sm:p-6 space-y-6 rounded-3xl font-sans border border-slate-200 shadow-xs">

      {/* v2.8: Ürün filtresi */}
      <div className="bg-white border border-slate-200 rounded-2xl p-3 flex flex-col sm:flex-row sm:items-center gap-2">
        <label htmlFor="mqr-product" className="text-xs font-semibold text-slate-700">Ürün</label>
        <select id="mqr-product" value={productFilter} onChange={(e) => setProductFilter(e.target.value)}
          className="min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 sm:w-72">
          <option value="ALL">Tüm ürünler</option>
          {productOptions.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        {mixedProductsInTests && (
          <span className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2 py-1">
            Brix ve sertlik ortalamaları birden çok ürünü karıştırıyor; doğru değer için ürün seçin.
          </span>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 1. ÜST EYLEM & FİLTRE ÇUBUĞU                                              */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
        
        <div className="flex items-center gap-3 flex-wrap w-full md:w-auto">
          <button
            type="button"
            onClick={handleBack}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-200"
          >
            &larr; Panoya Dön
          </button>

          <div className="h-4 w-px bg-slate-200 hidden sm:block"></div>

          {/* DÖNEM SEÇİCİ */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
            <Calendar className="w-4 h-4 text-emerald-600 shrink-0 ml-1" />
            <span className="text-xs font-bold text-slate-700">Dönem:</span>
            
            <select
              value={selectedMonthNumber}
              onChange={(e) => setSelectedMonthNumber(e.target.value)}
              className="bg-white border border-slate-200 text-slate-900 text-xs font-bold rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              {MONTHS_LIST.map(m => (
                <option key={m.value} value={m.value}>
                  {m.tr}
                </option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="bg-white border border-slate-200 text-slate-900 text-xs font-bold rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              {availableYears.map(y => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>

            {selectedMonthNumber !== 'ALL' && !hasPeriodData && (
              <button
                type="button"
                onClick={() => setSelectedMonthNumber('ALL')}
                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                title="Bu ayda henüz kayıt yok; ana panodaki tüm aktif kayıtları görüntülemek için tıklayınız"
              >
                <Sparkles className="w-3 h-3 text-amber-600" />
                <span>Ana Panoyu Göster</span>
              </button>
            )}
          </div>

          {/* TÜMÜNÜ AÇ / KAPAT */}
          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setAllAccordions(true)}
              className="px-2.5 py-1 text-[11px] font-bold text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition cursor-pointer"
            >
              Tümünü Aç
            </button>
            <span className="text-slate-300">|</span>
            <button
              type="button"
              onClick={() => setAllAccordions(false)}
              className="px-2.5 py-1 text-[11px] font-bold text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition cursor-pointer"
            >
              Kapat
            </button>
          </div>
        </div>

        {/* EYLEMLER */}
        <div className="flex items-center gap-2 self-stretch md:self-auto justify-end">
          <button
            type="button"
            onClick={() => setIsEditModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Veri Gir / Düzenle</span>
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition border border-slate-200 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-500" />
            <span>Excel (CSV)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* PAYDAŞ BAZLI SEÇMELİ GÖRÜNÜM (PERSONA SELECTOR)                           */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 p-3 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800 shrink-0">
          <span className="p-1 rounded-lg bg-teal-50 text-teal-700 border border-teal-200">
            <Users className="w-3.5 h-3.5" />
          </span>
          <span className="uppercase text-[11px] text-slate-500">Kullanıcı Rolü &amp; Odak:</span>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => handleSelectPersona('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedPersona === 'ALL'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Tümü / Genel Bakış
          </button>

          <button
            type="button"
            onClick={() => handleSelectPersona('MANAGER')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedPersona === 'MANAGER'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <span></span>
            <span>Yönetici (Risk &amp; Personel)</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectPersona('FINANCE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedPersona === 'FINANCE'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <span></span>
            <span>Finans (Ciro &amp; Fire)</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectPersona('PRODUCER')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedPersona === 'PRODUCER'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <span></span>
            <span>Üretici / Ziraat (Streif &amp; Hasat)</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectPersona('OPERATOR')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedPersona === 'OPERATOR'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <span></span>
            <span>Saha İşçisi (Görevler)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. GENEL DÖNEM BOŞ EKRAN KONTROLÜ                                         */}
      {/* ========================================================================= */}
      {!hasPeriodData ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-10 sm:p-16 text-center space-y-4 max-w-xl mx-auto my-12 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 tracking-tight">Bu döneme ait veri girilmemiş</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            <span className="text-teal-700 font-bold">{formatMonthLabel(selectedMonthKey)}</span> dönemi için henüz sistemde kayıtlı zirai test veya kalite raporu bulunmamaktadır.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setIsEditModalOpen(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Veri Gir / Rapor Oluştur</span>
            </button>
          </div>
        </div>
      ) : (
        /* ========================================================================= */
        /* 3. 5 Farkli akordeon rapor listesi (r-01 - r-05)                          */
        /* ========================================================================= */
        <div className="space-y-4">

          {/* ----------------------------------------------------------------------- */}
          {/* R-01: STREIF İNDEKSİ VE HASAT ZAMANLAMASI (Ziraat & Ticaret)            */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-01" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-01')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-sky-500/20 text-sky-300 border border-sky-400/30">
                  R-01
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Streif İndeksi ve Hasat Zamanlaması</span>
                    {r01Data.isEdited && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                        düzenlendi
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">(Ziraat &amp; Ticaret)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Brix, sertlik ve iyot testine dayalı depolanabilirlik ve hasat penceresi tayini
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs tabular-nums font-bold text-sky-400 bg-sky-950/60 border border-sky-800/50 px-2.5 py-1 rounded-lg hidden sm:block">
                  {r01Data.hasStreifData
                    ? `SI: ${r01Data.streifIndex} (${r01Data.stage === 'LONG_STORAGE' ? 'Uzun Depolama' : r01Data.stage === 'OPTIMAL_HARVEST' ? 'Optimum Hasat' : 'Taze Satış'})`
                    : 'SI: Veri Bekleniyor'}
                </span>
                {openAccordions['R-01'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-01'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {!r01Data.hasStreifData ? (
                  <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-6 sm:p-8 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                      <AlertTriangle className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-white">Hesaplama için Brix, Sertlik ve İyot testlerini giriniz</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Seçili dönemde Streif İndeksi (SI) hesaplanabilmesi için meyve penetrometre sertliği, Brix refraktometre şekeri ve WSU nişasta-iyot testi değerlerinin girilmesi gerekmektedir.
                    </p>
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setIsEditModalOpen(true)}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Test Verisi Gir</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                
                {/* 4 ÖLÇÜM KARTI */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                    <span className="text-[11px] font-bold text-slate-400 block">Sertlik (Penetrometre)</span>
                    <span className="text-xl font-bold text-white tabular-nums mt-0.5 block">{r01Data.hardness} kg/cm²</span>
                  </div>
                  <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                    <span className="text-[11px] font-bold text-slate-400 block">Şeker (Brix Refraktometre)</span>
                    <span className="text-xl font-bold text-amber-400 tabular-nums mt-0.5 block">{r01Data.brix}° Bx</span>
                  </div>
                  <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                    <span className="text-[11px] font-bold text-slate-400 block">Nişasta Açılımı (İyot 1-10)</span>
                    <span className="text-xl font-bold text-sky-400 tabular-nums mt-0.5 block">{r01Data.starch} / 10</span>
                  </div>
                  <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                    <span className="text-[11px] font-bold text-slate-400 block">Hesaplanan Streif İndeksi</span>
                    <span className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5 block">{r01Data.streifIndex} SI</span>
                  </div>
                </div>

                {/* BÜYÜK STREIF İNDEKS SKALASI GÖSTERGESİ */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                    <span className="flex items-center gap-1.5">
                      <Scale className="w-4 h-4 text-emerald-700" />
                      <span>Streif İndeks Skalası &amp; Olgunluk Alanı</span>
                    </span>
                    <span className={`font-bold ${r01Data.stageColor}`}>
                      {r01Data.stageLabel}
                    </span>
                  </div>

                  {/* Renkli Gradyan Skala Çubuğu */}
                  <div className="relative pt-6 pb-2">
                    {/* İbre Marker */}
                    <div
                      className="absolute top-0 -translate-x-1/2 flex flex-col items-center transition-all duration-500"
                      style={{ left: `${r01Data.pointerPercent}%` }}
                    >
                      <span className="text-[10px] tabular-nums font-bold text-slate-900 bg-white border border-slate-600 px-2 py-0.5 rounded shadow-sm">
                        SI: {r01Data.streifIndex}
                      </span>
                      <div className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[6px] border-t-white mt-0.5"></div>
                    </div>

                    <div className="h-4 w-full rounded-full bg-emerald-700 hover:bg-emerald-100 shadow-inner"></div>

                    {/* Skala Bölgeleri */}
                    <div className="flex justify-between text-[10px] font-bold text-slate-500 mt-2 px-1">
                      <span className="text-amber-700">&lt; 0.10 SI: Taze Satış / Sanayi</span>
                      <span className="text-emerald-700">0.10 - 0.18 SI: Optimum Hasat</span>
                      <span className="text-sky-700">&gt; 0.18 SI: Uzun Depolama (CA/DCA)</span>
                    </div>
                  </div>
                </div>

                {/* ULUSLARARASI BİLİMSEL REFERANSLAR (WSU / CTIFL / ORTA ASYA) */}
                <div className="flex items-center gap-2 flex-wrap bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1.5 mr-1">
                    <BookOpen className="w-3.5 h-3.5 text-sky-400" />
                    <span>Bilimsel Metot &amp; Eşikler:</span>
                  </span>
                  
                  <button
                    type="button"
                    onClick={() => setActiveRefBadgeModal(SCIENTIFIC_BADGES_DATA.WSU)}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] tabular-nums font-bold bg-sky-500/10 text-sky-300 border border-sky-500/30 hover:bg-sky-500/25 hover:border-sky-400 hover:shadow-md hover:shadow-sky-950/50 transition cursor-pointer flex items-center gap-1.5 group"
                    title="WSU Nişasta Skalası Teknik Detaylarını ve Eşik Tablosunu Görüntüle"
                  >
                    <Info className="w-3 h-3 text-sky-400 group-hover:scale-110 transition-transform" />
                    <span>[WSU Nişasta Skalası]</span>
                    <Table className="w-3 h-3 text-sky-400 opacity-70 group-hover:opacity-100" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveRefBadgeModal(SCIENTIFIC_BADGES_DATA.CTIFL)}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] tabular-nums font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25 hover:border-emerald-400 hover:shadow-md hover:shadow-emerald-950/50 transition cursor-pointer flex items-center gap-1.5 group"
                    title="CTIFL Hasat Kılavuzu Teknik Detaylarını ve Eşik Tablosunu Görüntüle"
                  >
                    <Info className="w-3 h-3 text-emerald-400 group-hover:scale-110 transition-transform" />
                    <span>[CTIFL Hasat Kılavuzu]</span>
                    <Table className="w-3 h-3 text-emerald-400 opacity-70 group-hover:opacity-100" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveRefBadgeModal(SCIENTIFIC_BADGES_DATA.ORTA_ASYA)}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] tabular-nums font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25 hover:border-amber-400 hover:shadow-md hover:shadow-amber-950/50 transition cursor-pointer flex items-center gap-1.5 group"
                    title="Orta Asya İklim Kalibrasyonu Teknik Detaylarını ve Eşik Tablosunu Görüntüle"
                  >
                    <Info className="w-3 h-3 text-amber-400 group-hover:scale-110 transition-transform" />
                    <span>[Orta Asya İklim Kalibrasyonu]</span>
                    <Table className="w-3 h-3 text-amber-400 opacity-70 group-hover:opacity-100" />
                  </button>
                </div>

                {/* TİCARİ YANSIMA */}
                <div className="bg-sky-950/40 border border-sky-500/40 rounded-xl p-3.5 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-sky-300 block">
                      Ticari Yansıma (Ziraat &amp; Satış Stratejisi)
                    </span>
                    <p className="text-xs sm:text-sm text-sky-100 font-medium mt-0.5">
                      "{r01Data.commercialNote}"
                    </p>
                  </div>
                </div>

                {/* KAYNAK VE DÜZENLEME BİLGİSİ */}
                <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
                  <span>Kaynak: fieldRecords (Saha Testleri) • {filteredFields.length} kayıt • {formatMonthLabel(selectedMonthKey)}</span>
                  {r01Data.isEdited && (
                    <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                      düzenlendi
                    </span>
                  )}
                </div>
              </>
            )}
          </div>
        )}
          </div>

          {/* ----------------------------------------------------------------------- */}
          {/* R-02: KALİTE SINIFLANDIRMASI VE FİRE/KAYIP (Finans & Ticaret)            */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-02" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-02')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  R-02
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Kalite Sınıflandırması ve Fire/Kayıp</span>
                    {r02Data.isEdited && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                        düzenlendi
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">(Finans &amp; Ticaret)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Ekstra/1. Sınıf dağılımı, fire oranı ve ciro kayıp hesabı
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs tabular-nums font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2.5 py-1 rounded-lg hidden sm:block">
                  {r02Data.hasQualityFireData
                    ? `Fire: %${r02Data.fireRatePct} • Ekstra+1.Sınıf: %${(r02Data.extraPct + r02Data.class1Pct).toFixed(1)}`
                    : 'Kalite: Veri Bekleniyor'}
                </span>
                {openAccordions['R-02'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-02'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {!r02Data.hasQualityFireData ? (
                  <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-6 sm:p-8 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                      <AlertTriangle className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-white">Henüz bu döneme ait kalite sınıflandırması ve fire verisi girilmedi</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Kalite sınıfları dağılımı (Ekstra, 1. Sınıf, 2. Sınıf, Sanayi) ve fire oranı analizlerini görüntülemek için hasat verisi kaydedin veya manuel değer girin.
                    </p>
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setIsEditModalOpen(true)}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Kalite &amp; Fire Verisi Gir</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                
                {/* TUTARSIZLIK UYARISI BANNERI */}
                {r02Data.isSumInconsistent && (
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex items-start gap-2.5 text-amber-300 text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>
                      <strong>Tutarsızlık Uyarısı:</strong> Ekstra (%{r02Data.extraPct}) + 1. Sınıf (%{r02Data.class1Pct}) + Fire (%{r02Data.fireRatePct}) toplamı %{(r02Data.extraPct + r02Data.class1Pct + r02Data.fireRatePct).toFixed(1)} olup %100'ü aşıyor! Lütfen oranları kontrol ediniz.
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  
                  {/* PASTA GRAFİĞİ: EKSTRA / 1. SINIF / SANAYİ */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between">
                    <span className="text-xs font-bold text-slate-600 mb-2">
                      Kalite Sınıfları Dağılımı (Pasta Grafiği)
                    </span>

                    <div className="w-full h-44 relative">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={r02Data.pieData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={38}
                            outerRadius={65}
                            stroke="#0f172a"
                            strokeWidth={2}
                          >
                            {r02Data.pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold text-slate-600 pt-2 border-t border-slate-200">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Ekstra: %{r02Data.extraPct}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-cyan-500"></span> 1. Sınıf: %{r02Data.class1Pct}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> 2. Sınıf: %{r02Data.class2Pct}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Sanayi: %{r02Data.industryPct}
                      </div>
                    </div>
                  </div>

                  {/* FİRE VE FİNANSAL CİRO KAYBI ÇUBUĞU */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between space-y-4">
                    <span className="text-xs font-bold text-slate-600">
                      Fire Oranı ve Finansal Kayıp Çubuğu
                    </span>

                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-bold">
                        <span className="text-slate-500">Ortalama Fire Oranı:</span>
                        <span className={`tabular-nums ${r02Data.isFireHigh ? 'text-rose-700 font-bold' : 'text-emerald-700'}`}>
                          %{r02Data.fireRatePct} (Hedef &lt; %2.5)
                        </span>
                      </div>
                      <div className="w-full bg-white h-3 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            r02Data.isFireHigh ? 'bg-rose-500' : 'bg-emerald-500'
                          }`}
                          style={{ width: `${Math.min(100, r02Data.fireRatePct * 20)}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] font-bold text-slate-500 block">Tahmini Fire Ağırlığı</span>
                        <span className="text-base font-bold text-rose-700 tabular-nums mt-0.5 block">{r02Data.estLossKg} kg</span>
                      </div>
                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] font-bold text-slate-500 block">Ciro / Değer Kaybı</span>
                        <span className="text-base font-bold text-amber-700 tabular-nums mt-0.5 block">~{r02Data.estLossTmt} TMT</span>
                      </div>
                    </div>

                    <span className="text-[10px] text-slate-500 font-medium">
                      Toplam {r02Data.totalTons} Ton hasat/kabul hacmi üzerinden hesaplanmıştır.
                    </span>
                  </div>

                </div>

                {/* ULUSLARARASI KALİTE & İHRACAT STANDARTLARI (UNECE FFV-26 / CODEX STAN 299) */}
                <div className="flex items-center gap-2 flex-wrap bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1.5 mr-1">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Ticari Standartlar &amp; Toleranslar:</span>
                  </span>

                  <button
                    type="button"
                    onClick={() => setActiveRefBadgeModal(SCIENTIFIC_BADGES_DATA.UNECE)}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] tabular-nums font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/25 hover:border-cyan-400 hover:shadow-md hover:shadow-cyan-950/50 transition cursor-pointer flex items-center gap-1.5 group"
                    title="UNECE FFV-26 Sınıflandırma ve Eşik Tablosunu Görüntüle"
                  >
                    <Info className="w-3 h-3 text-cyan-400 group-hover:scale-110 transition-transform" />
                    <span>[UNECE FFV-26 Elma Sınıflandırması]</span>
                    <Table className="w-3 h-3 text-cyan-400 opacity-70 group-hover:opacity-100" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveRefBadgeModal(SCIENTIFIC_BADGES_DATA.CODEX_STAN)}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] tabular-nums font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25 hover:border-emerald-400 hover:shadow-md hover:shadow-emerald-950/50 transition cursor-pointer flex items-center gap-1.5 group"
                    title="Codex STAN 299 İhracat Toleransları ve Eşik Tablosunu Görüntüle"
                  >
                    <Info className="w-3 h-3 text-emerald-400 group-hover:scale-110 transition-transform" />
                    <span>[Codex STAN 299 İhracat Toleransları]</span>
                    <Table className="w-3 h-3 text-emerald-400 opacity-70 group-hover:opacity-100" />
                  </button>
                </div>

                {/* TİCARİ YANSIMA */}
                <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-3.5 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                    <TrendingDown className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-emerald-300 block">
                      Ticari Yansıma (Finans &amp; Ciro Analizi)
                    </span>
                    <p className="text-xs sm:text-sm text-emerald-100 font-medium mt-0.5">
                      "{r02Data.commercialNote}"
                    </p>
                  </div>
                </div>

                {/* KAYNAK VE DÜZENLEME BİLGİSİ */}
                <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
                  <span>Kaynak: harvestRecords (Hasat &amp; Kalite Sınıfları) • {filteredHarvests.length} kayıt • {formatMonthLabel(selectedMonthKey)}</span>
                  {r02Data.isEdited && (
                    <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                      düzenlendi
                    </span>
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </div>

          {/* ----------------------------------------------------------------------- */}
          {/* R-03: BARLAG AKTY VE RİSK YÖNETİMİ (Yönetim & Risk)                      */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-03" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-03')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-rose-500/20 text-rose-300 border border-rose-400/30">
                  R-03
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Barlag Akty ve Risk Yönetimi</span>
                    {r03Data.isEdited && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                        düzenlendi
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">(Yönetim &amp; Risk)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Haftalık olay trend çizgisi, kök neden bar grafiği ve DÖF aksiyonları
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className={`text-xs tabular-nums font-bold px-2.5 py-1 rounded-lg hidden sm:block ${
                  r03Data.openCount === 0
                    ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/50'
                    : 'text-rose-400 bg-rose-950/60 border border-rose-800/50'
                }`}>
                  {r03Data.openCount === 0 ? 'Açık Olay: 0 (Kusursuz)' : `Açık Olay: ${r03Data.openCount} • Derece 1: ${r03Data.derece1}`}
                </span>
                {openAccordions['R-03'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-03'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {r03Data.openCount === 0 ? (
                  <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-6 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-emerald-300">0 Açık Barlag Akty (Kusursuz Kalite Standartı)</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Bu dönemde açık, bekleyen veya çözülmemiş herhangi bir operasyonel uygunsuzluk kaydı bulunmamaktadır. Tüm partiler kabul toleransları ve SFAC SOP standartlarına uygundur.
                    </p>
                  </div>
                ) : (
                  <>
                
                {/* 3 DERECE KARTI */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-rose-950/40 border border-rose-500/40 rounded-xl p-3 text-center">
                    <span className="text-[10px] font-bold text-rose-300 block">Derece 1 (Kritik)</span>
                    <span className="text-2xl font-bold text-rose-400 tabular-nums mt-0.5 block">{r03Data.derece1}</span>
                  </div>
                  <div className="bg-amber-950/40 border border-amber-500/40 rounded-xl p-3 text-center">
                    <span className="text-[10px] font-bold text-amber-300 block">Derece 2 (Majör)</span>
                    <span className="text-2xl font-bold text-amber-400 tabular-nums mt-0.5 block">{r03Data.derece2}</span>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                    <span className="text-[10px] font-bold text-slate-500 block">Derece 3 (Minör)</span>
                    <span className="text-2xl font-bold text-slate-600 tabular-nums mt-0.5 block">{r03Data.derece3}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  
                  {/* HAFTALIK OLAY TREND ÇİZGİSİ */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
                    <span className="text-xs font-bold text-slate-600 block">
                      Haftalık Olay Trend Çizgisi (LineChart)
                    </span>

                    <div className="w-full h-40">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={r03Data.weeklyTrend}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis dataKey="week" stroke="#64748b" fontSize={10} />
                          <YAxis stroke="#64748b" fontSize={10} />
                          <Tooltip
                            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                          />
                          <Line type="monotone" dataKey="olaySayisi" name="Toplam Olay" stroke="#f43f5e" strokeWidth={2.5} dot={{ r: 4 }} />
                          <Line type="monotone" dataKey="derece1" name="Derece 1 Kritik" stroke="#e11d48" strokeWidth={1.5} strokeDasharray="4 4" />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* KÖK NEDEN BAR GRAFİĞİ */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
                    <span className="text-xs font-bold text-slate-600 block">
                      Kök Neden Dağılımı (BarChart)
                    </span>

                    <div className="w-full h-40">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={r03Data.rootCauses} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis type="number" stroke="#64748b" fontSize={10} />
                          <YAxis dataKey="cause" type="category" width={110} stroke="#94a3b8" fontSize={9} />
                          <Tooltip
                            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                          />
                          <Bar dataKey="pct" name="Risk %" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                </div>

                {/* YÖNETİMSEL YANSIMA */}
                <div className="bg-rose-950/40 border border-rose-500/40 rounded-xl p-3.5 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 shrink-0 mt-0.5">
                    <ShieldAlert className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-rose-300 block">
                      Yönetimsel Yansıma (Risk &amp; DÖF Kararı)
                    </span>
                    <p className="text-xs sm:text-sm text-rose-100 font-medium mt-0.5">
                      "{r03Data.managementNote}"
                    </p>
                  </div>
                </div>
              </>
            )}

            {/* KAYNAK VE DÜZENLEME BİLGİSİ */}
            <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
              <span>Kaynak: incidentRecords (Barlag Akty &amp; Risk Olayları) • {filteredIncidents.length} kayıt • {formatMonthLabel(selectedMonthKey)}</span>
              {r03Data.isEdited && (
                <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                  düzenlendi
                </span>
              )}
            </div>
          </div>
        )}
      </div>

          {/* ----------------------------------------------------------------------- */}
          {/* R-04: PERSONEL VE DEPARTMAN VERİMLİLİĞİ (Yönetim & İK)                  */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-04" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-04')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  R-04
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Personel ve Departman Verimliliği</span>
                    {Boolean(activeMonthOverride.staffMembers) && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                        düzenlendi
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">(Yönetim &amp; İK)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Görev tamamlama ilerleme çubukları ve departman performans takibi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs tabular-nums font-bold text-indigo-400 bg-indigo-950/60 border border-indigo-800/50 px-2.5 py-1 rounded-lg hidden sm:block">
                  {deduplicatedStaff.length} Personel (Tekil)
                </span>
                {openAccordions['R-04'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-04'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {deduplicatedStaff.length === 0 ? (
                  <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-6 sm:p-8 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto">
                      <Users className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-white">Henüz bu döneme ait personel görev kaydı bulunamadı</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Saha, ambar ve lojistik formlarındaki sorumlu operatörler otomatik olarak tespit edilir ve departman verimlilik skorlarına dönüştürülür.
                    </p>
                  </div>
                ) : (
                  <>
                {/* DEPARTMAN FİLTRESİ */}
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setSelectedStaffDept('ALL')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedStaffDept === 'ALL' ? 'bg-indigo-600 text-slate-900' : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      Tümü ({deduplicatedStaff.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedStaffDept('FIELD')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedStaffDept === 'FIELD' ? 'bg-indigo-600 text-slate-900' : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      Saha
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedStaffDept('STORAGE')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedStaffDept === 'STORAGE' ? 'bg-indigo-600 text-slate-900' : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      Depo
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedStaffDept('LOGISTICS')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedStaffDept === 'LOGISTICS' ? 'bg-indigo-600 text-slate-900' : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      Lojistik
                    </button>
                  </div>

                  <span className="text-[11px] text-slate-500 font-medium">
                    *Mükerrer isimler otomatik olarak tekilleştirilmiştir.
                  </span>
                </div>

                {/* PERSONEL GÖREV İLERLEME ÇUBUKLARI (PROGRESS BARS) */}
                <div className="space-y-3">
                  {filteredStaffList.map((staff) => {
                    const pct = staff.assignedTasks > 0 ? Math.round((staff.completedTasks / staff.assignedTasks) * 100) : 0;
                    const isBelowTarget = pct < 90;

                    return (
                      <div
                        key={staff.id}
                        onClick={() => setSelectedStaffDetail(staff)}
                        className="bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition cursor-pointer group"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition">
                              {staff.name}
                            </h4>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                              {staff.departmentLabel}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400">{staff.role}</p>
                        </div>

                        {/* Progress Bar & Tamamlama */}
                        <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                          <div className="space-y-1 w-36 sm:w-48">
                            <div className="flex justify-between text-[11px] font-bold">
                              <span className="text-slate-400">Görev:</span>
                              <span className={`tabular-nums ${isBelowTarget ? 'text-amber-400' : 'text-emerald-400'}`}>
                                {staff.completedTasks}/{staff.assignedTasks} (%{pct})
                              </span>
                            </div>
                            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-500 ${
                                  pct >= 90 ? 'bg-emerald-500' : pct >= 75 ? 'bg-amber-500' : 'bg-rose-500'
                                }`}
                                style={{ width: `${pct}%` }}
                              ></div>
                            </div>
                          </div>

                          <div className="bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 text-right shrink-0">
                            <span className="text-[9px] font-bold text-slate-500 block">Skor</span>
                            <span className="text-sm font-bold text-slate-900 tabular-nums">{staff.performanceScore}/100</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* YÖNETİMSEL YANSIMA */}
                <div className="bg-indigo-950/40 border border-indigo-500/40 rounded-xl p-3.5 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 shrink-0 mt-0.5">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-indigo-300 block">
                      Yönetimsel Yansıma (İK &amp; İş Gücü Kararı)
                    </span>
                    <p className="text-xs sm:text-sm text-indigo-100 font-medium mt-0.5">
                      "{r04ManagementNote}"
                    </p>
                  </div>
                </div>
              </>
            )}

            {/* KAYNAK VE DÜZENLEME BİLGİSİ */}
            <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
              <span>Kaynak: operationalForms &amp; staffMembers (Operasyon Görevleri) • {deduplicatedStaff.length} personel • {formatMonthLabel(selectedMonthKey)}</span>
              {Boolean(activeMonthOverride.staffMembers) && (
                <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                  düzenlendi
                </span>
              )}
            </div>
          </div>
        )}
      </div>

          {/* ----------------------------------------------------------------------- */}
          {/* R-05: TESİS PERFORMANSI VE KAPASİTE (Operasyon & Finans)                 */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-05" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-05')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-purple-500/20 text-purple-300 border border-purple-400/30">
                  R-05
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Tesis Performansı ve Kapasite</span>
                    {r05Data.isEdited && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                        düzenlendi
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">(Operasyon &amp; Finans)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Soğuk depo doluluk oranları, depoda kalma süreleri ve riskli stok analizi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs tabular-nums font-bold text-purple-400 bg-purple-950/60 border border-purple-800/50 px-2.5 py-1 rounded-lg hidden sm:block">
                  Doluluk: %{r05Data.avgDoluluk} • &gt;60 Gün Bekleme: %{r05Data.criticalOverduePct}
                </span>
                {openAccordions['R-05'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-05'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {!r05Data.hasFacilitiesData ? (
                  <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-6 sm:p-8 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mx-auto">
                      <Warehouse className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-white">Henüz bu döneme ait tesis ambar kabul kaydı bulunamadı</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Ambar kabul modülünde depolara ürün kabulü yapıldığında, tesis kapasite doluluk oranları ve ortalama bekleme günleri bu ekranda otomatik güncellenir.
                    </p>
                  </div>
                ) : (
                  <>
                {/* TESİS BAZLI DOLULUK VE BEKLEME SÜRESİ TABLOSU */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {r05Data.facilities.map((fac: any, idx: number) => {
                    const isOver60 = fac.beklemeGun > 60;

                    return (
                      <div key={idx} className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <Warehouse className="w-4 h-4 text-purple-400" />
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            isOver60 ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-white text-slate-500'
                          }`}>
                            {isOver60 ? 'Riskli Bekleme' : 'Normal Rejim'}
                          </span>
                        </div>

                        <div>
                          <h4 className="text-xs font-bold text-slate-900">{fac.name}</h4>
                          <span className="text-[10px] text-slate-500">Kapasite: {fac.kapasiteTon} Ton</span>
                        </div>

                        <div className="space-y-1.5 pt-1 border-t border-slate-200">
                          <div className="flex justify-between text-[11px] font-bold">
                            <span className="text-slate-500">Doluluk Oranı:</span>
                            <span className="text-purple-400 tabular-nums">%{fac.dolulukPct}</span>
                          </div>
                          <div className="w-full bg-white h-2 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-purple-500 rounded-full"
                              style={{ width: `${fac.dolulukPct}%` }}
                            ></div>
                          </div>

                          <div className="flex justify-between text-[11px] font-bold pt-1">
                            <span className="text-slate-500">Ort. Bekleme:</span>
                            <span className={`tabular-nums ${isOver60 ? 'text-rose-700' : 'text-slate-700'}`}>
                              {fac.beklemeGun} Gün
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* TİCARİ YANSIMA */}
                <div className="bg-purple-950/40 border border-purple-500/40 rounded-xl p-3.5 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400 shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-purple-300 block">
                      Ticari Yansıma (Operasyon &amp; Stok Risk Kararı)
                    </span>
                    <p className="text-xs sm:text-sm text-purple-100 font-medium mt-0.5">
                      "{r05Data.commercialNote}"
                    </p>
                  </div>
                </div>
              </>
            )}

            {/* KAYNAK VE DÜZENLEME BİLGİSİ */}
            <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
              <span>Kaynak: ambarRecords (Soğuk Depo &amp; Tesis Kabul) • {filteredAmbar.length} kayıt • {formatMonthLabel(selectedMonthKey)}</span>
              {r05Data.isEdited && (
                <span className="text-[9px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                  düzenlendi
                </span>
              )}
            </div>
          </div>
        )}
      </div>

          {/* ----------------------------------------------------------------------- */}
          {/* R-06: ZİRAİ & KALİTE TEST NUMUNELERİ ANALİZ RAPORU                       */}
          {/* ----------------------------------------------------------------------- */}
          <div id="report-R-06" className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
            <div
              onClick={() => toggleAccordion('R-06')}
              className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition select-none"
            >
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-xl text-xs font-bold tabular-nums bg-teal-500/20 text-teal-300 border border-teal-400/30">
                  R-06
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Zirai &amp; Kalite Test Numuneleri Analiz Raporu</span>
                    <span className="text-[11px] font-bold text-teal-400 hidden sm:inline">(Laboratuvar &amp; Zirai Test Arşivi)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Hasat öncesi, zamanı ve sonrası test edilen numune adedi, ağırlığı ve ölçüm sonuçları
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs tabular-nums font-bold text-teal-400 bg-teal-950/60 border border-teal-800/50 px-2.5 py-1 rounded-lg hidden sm:block">
                  Numune: {r06Data.totalSampleFruits} Meyve ({r06Data.totalSampleKg} kg) • {r06Data.totalTestCount} Test
                </span>
                {openAccordions['R-06'] ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </div>

            {openAccordions['R-06'] && (
              <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950/60 space-y-5">
                {/* AYRIŞTIRMA BİLGİ BANNERI */}
                <div className="bg-teal-950/30 border border-teal-500/30 rounded-xl p-3 flex items-center justify-between gap-3 text-xs text-teal-200">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
                    <span>
                      <strong>Laboratuvar Ayrıştırması:</strong> Test numuneleri ticari stok ve lojistik sevkiyat rakamlarından %100 ayrıştırılmıştır.
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] tabular-nums font-bold bg-teal-500/20 text-teal-300 border border-teal-400/30 shrink-0">
                    Zirai Test Karantina Modu
                  </span>
                </div>

                {/* 4 AŞAMA ÖZET KARTLARI */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Hasat Öncesi Testler</span>
                    <span className="text-lg font-bold text-sky-700 tabular-nums block">{r06Data.stageCounts.HASAT_ONCESI} Analiz</span>
                    <span className="text-[11px] text-slate-500 block">Ön olgunluk &amp; Nişasta</span>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Hasat Zamanı Testler</span>
                    <span className="text-lg font-bold text-emerald-700 tabular-nums block">{r06Data.stageCounts.HASAT_ZAMANI} Analiz</span>
                    <span className="text-[11px] text-slate-500 block">Hasat olum &amp; kabul</span>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Depoda Testler</span>
                    <span className="text-lg font-bold text-purple-400 tabular-nums block">{r06Data.stageCounts.DEPODA} Analiz</span>
                    <span className="text-[11px] text-slate-500 block">Depolama &amp; Olgunlaşma</span>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Sevkiyat Öncesi Testler</span>
                    <span className="text-lg font-bold text-amber-700 tabular-nums block">{r06Data.stageCounts.SEVKIYAT_ONCESI} Analiz</span>
                    <span className="text-[11px] text-slate-500 block">İhracat çıkış kontrolü</span>
                  </div>
                </div>

                {/* AŞAMA FİLTRE BUTONLARI */}
                <div className="flex items-center gap-2 flex-wrap bg-slate-900/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-[11px] font-bold text-slate-400 ml-1">Aşama Filtresi:</span>
                  {[
                    { id: 'ALL', label: 'Tüm Testler' },
                    { id: 'HASAT_ONCESI', label: 'Hasat Öncesi' },
                    { id: 'HASAT_ZAMANI', label: 'Hasat Zamanı' },
                    { id: 'DEPODA', label: 'Depoda' },
                    { id: 'SEVKIYAT_ONCESI', label: 'Sevkiyat Öncesi' }
                  ].map(btn => (
                    <button
                      key={btn.id}
                      type="button"
                      onClick={() => setSelectedTestStageFilter(btn.id as any)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedTestStageFilter === btn.id
                          ? 'bg-teal-600 text-white shadow-md'
                          : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>

                {/* DETAYLI TEST NUMUNELERİ TABLOSU */}
                {r06Data.filteredTests.length === 0 ? (
                  <div className="bg-white border border-slate-200 rounded-xl p-6 text-center text-xs text-slate-500">
                    Seçili aşamada test kaydı bulunamadı.
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 tabular-nums text-[10px]">
                          <th className="py-2.5 px-3">Tarih &amp; Referans</th>
                          <th className="py-2.5 px-3">Aşama &amp; Test Tipi</th>
                          <th className="py-2.5 px-3">Parti &amp; Lokasyon</th>
                          <th className="py-2.5 px-3 text-right">Meyve Adedi</th>
                          <th className="py-2.5 px-3 text-right">Numune Ağırlığı</th>
                          <th className="py-2.5 px-3 text-right">Ort. Meyve Gramajı</th>
                          <th className="py-2.5 px-3 text-center">Brix / Sertlik / Nişasta</th>
                          <th className="py-2.5 px-3">Karar &amp; Sonuç</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-medium">
                        {r06Data.filteredTests.map((t, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/40 transition">
                            <td className="py-2.5 px-3 tabular-nums">
                              <span className="text-slate-900 block font-bold">{t.testDate}</span>
                              <span className="text-[10px] text-teal-700">{t.refId}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-teal-700 border border-slate-200 block w-fit">
                                {t.stageLabel}
                              </span>
                              <span className="text-[11px] text-slate-500 mt-0.5 block">{t.testType}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-slate-700 block font-bold">{t.productName}</span>
                              <span className="text-[10px] text-slate-500 block">{t.location}</span>
                            </td>
                            <td className="py-2.5 px-3 text-right tabular-nums text-slate-900 font-bold">
                              {t.fruits} adet
                            </td>
                            <td className="py-2.5 px-3 text-right tabular-nums text-amber-700 font-bold">
                              {t.sampleKg} kg
                            </td>
                            <td className="py-2.5 px-3 text-right tabular-nums text-sky-700 font-bold">
                              {t.avgFruitWeightG} g
                            </td>
                            <td className="py-2.5 px-3 text-center tabular-nums text-[11px]">
                              <span className="text-amber-700 font-bold">{t.brix}°Bx</span>
                              <span className="text-slate-500 mx-1">|</span>
                              <span className="text-emerald-700 font-bold">{t.hardness} kg</span>
                              <span className="text-slate-500 mx-1">|</span>
                              <span className="text-sky-700 font-bold">SI {t.starch}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-emerald-700 text-[11px] font-bold block">{t.verdict}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* KAYNAK SATIRI */}
                <div className="text-[10px] text-slate-500 tabular-nums mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 flex-wrap gap-2">
                  <span>Kaynak: fieldRecords &amp; labTests (Zirai Test Arşivi) • {r06Data.totalTestCount} test kaydı • {r06Data.totalSampleFruits} test meyvesi ({r06Data.totalSampleKg} kg)</span>
                  <span className="text-teal-400 font-bold"> Ticari Stoktan Ayrıştırıldı</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VERİ GİR / DÜZENLE MODALI                                                */}
      {/* ========================================================================= */}
      {isEditModalOpen && (
        <EditReportsModal
          selectedMonthKey={selectedMonthKey}
          formatMonthLabel={formatMonthLabel}
          r01Data={r01Data}
          r02Data={r02Data}
          r03Data={r03Data}
          deduplicatedStaff={deduplicatedStaff}
          r05Data={r05Data}
          dashboardCalculations={dashboardCalculations}
          isSaving={isSavingFirestore}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleSaveToFirestore}
          onReset={handleResetToAutomatic}
        />
      )}

      {/* ========================================================================= */}
      {/* PERSONEL GÖREV DETAY MODALI                                              */}
      {/* ========================================================================= */}
      {selectedStaffDetail && (
        <StaffTaskModal
          staff={selectedStaffDetail}
          onClose={() => setSelectedStaffDetail(null)}
          onToggleTask={async (staffId, taskId) => {
            const updatedStaff = deduplicatedStaff.map(s => {
              if (s.id === staffId) {
                const updatedTasks = s.tasksList.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
                const comp = updatedTasks.filter(t => t.completed).length;
                return { ...s, completedTasks: comp, tasksList: updatedTasks };
              }
              return s;
            });
            handleSaveToFirestore({ staffMembers: updatedStaff });
          }}
        />
      )}

      {/* ========================================================================= */}
      {/* 4. ULUSLARARASI BİLİMSEL & TİCARİ AKREDİTASYON MODALI (KATMANLI GİZLİLİK) */}
      {/* ========================================================================= */}
      {activeRefBadgeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-white border border-teal-200 rounded-3xl max-w-xl w-full p-6 shadow-sm text-slate-900 space-y-4 relative my-8 max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setActiveRefBadgeModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-500 hover:text-slate-900 bg-white hover:bg-slate-50 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 pr-8">
              <div className="p-3 rounded-2xl bg-teal-50 text-teal-700 border border-teal-200 shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] tabular-nums font-bold bg-teal-50 text-teal-700 border border-teal-200 inline-block">
                  {activeRefBadgeModal.category}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {activeRefBadgeModal.title}
                </h3>
              </div>
            </div>

            <div className="space-y-3 pt-2 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-slate-600 leading-relaxed">
                {activeRefBadgeModal.description}
              </div>

              {activeRefBadgeModal.formula && (
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 block">Formül / Metodoloji</span>
                  <span className="tabular-nums text-emerald-700 font-bold mt-0.5 block">{activeRefBadgeModal.formula}</span>
                </div>
              )}

              {/* TEKNİK EŞİK TABLOSU */}
              {activeRefBadgeModal.tableHeaders && activeRefBadgeModal.tableRows && (
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 overflow-x-auto">
                  <div className="flex items-center gap-1.5 text-teal-700 text-[11px] font-bold">
                    <Table className="w-3.5 h-3.5" />
                    <span>Teknik Parametre &amp; Eşik Tablosu</span>
                  </div>
                  
                  <table className="w-full text-left text-[11px] text-slate-600 border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-900/90 text-slate-500 text-[10px] font-bold">
                        {activeRefBadgeModal.tableHeaders.map((head, hIdx) => (
                          <th key={hIdx} className="py-2 px-2.5 font-bold">{head}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {activeRefBadgeModal.tableRows.map((row, rIdx) => (
                        <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-slate-900/40' : 'bg-slate-50'}>
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className={`py-2 px-2.5 font-medium ${cIdx === 0 ? 'tabular-nums text-teal-700 font-bold shrink-0' : ''}`}>
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* KRİTERLER LİSTESİ */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold text-slate-500 block">Kriterler &amp; Saha Kuralları</span>
                {activeRefBadgeModal.criteria.map((crit, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-slate-700">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-700 shrink-0 mt-0.5" />
                    <span>{crit}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveRefBadgeModal(null)}
                className="px-5 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer border border-slate-200"
              >
                Anlaşıldı / Kapat
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

// =========================================================================
// SUB-COMPONENT: EDIT MODAL FOR 5 REPORTS
// =========================================================================
interface EditReportsModalProps {
  selectedMonthKey: string;
  formatMonthLabel: (m: string) => string;
  r01Data: any;
  r02Data: any;
  r03Data: any;
  deduplicatedStaff: StaffMember[];
  r05Data: any;
  dashboardCalculations: any;
  isSaving: boolean;
  onClose: () => void;
  onSave: (data: any) => void;
  onReset: () => void;
}

const EditReportsModal: React.FC<EditReportsModalProps> = ({
  selectedMonthKey,
  formatMonthLabel,
  r01Data,
  r02Data,
  r03Data,
  deduplicatedStaff,
  r05Data,
  dashboardCalculations,
  isSaving,
  onClose,
  onSave,
  onReset
}) => {
  // Eğer seçili ayda değerler 0 ise ana panodaki genel canlı verileri varsayılan yap
  const [hardness, setHardness] = useState<number>(
    r01Data.hardness > 0 ? r01Data.hardness : (dashboardCalculations?.hardness ?? 0)
  );
  const [brix, setBrix] = useState<number>(
    r01Data.brix > 0 ? r01Data.brix : (dashboardCalculations?.brix ?? 0)
  );
  const [starch, setStarch] = useState<number>(
    r01Data.starch > 0 ? r01Data.starch : (dashboardCalculations?.starch ?? 0)
  );

  // R-02 states
  const [extraPct, setExtraPct] = useState<number>(
    r02Data.extraPct > 0 ? r02Data.extraPct : (dashboardCalculations?.extraPct ?? 0)
  );
  const [class1Pct, setClass1Pct] = useState<number>(
    r02Data.class1Pct > 0 ? r02Data.class1Pct : (dashboardCalculations?.class1Pct ?? 0)
  );
  const [fireRatePct, setFireRatePct] = useState<number>(
    r02Data.fireRatePct > 0 ? r02Data.fireRatePct : (dashboardCalculations?.fireRatePct ?? 0)
  );
  const [totalTons, setTotalTons] = useState<number>(
    r02Data.totalTons > 0 ? r02Data.totalTons : (dashboardCalculations?.totalTons ?? 0)
  );

  // R-03 states
  const [openCount, setOpenCount] = useState<number>(
    r03Data.openCount > 0 ? r03Data.openCount : (dashboardCalculations?.openCount ?? 0)
  );
  const [derece1, setDerece1] = useState<number>(
    r03Data.derece1 > 0 ? r03Data.derece1 : (dashboardCalculations?.derece1 ?? 0)
  );
  const [derece2, setDerece2] = useState<number>(
    r03Data.derece2 > 0 ? r03Data.derece2 : (dashboardCalculations?.derece2 ?? 0)
  );

  const [appliedFromDashboard, setAppliedFromDashboard] = useState<boolean>(
    Boolean((r01Data.hardness === 0 && dashboardCalculations?.hardness > 0) || (r02Data.totalTons === 0 && dashboardCalculations?.totalTons > 0))
  );

  // Ana panodaki tüm aktif testlerden canlı verileri butona basınca anında çek
  const handlePullFromMainDashboard = () => {
    if (!dashboardCalculations) return;
    setHardness(dashboardCalculations.hardness ?? 0);
    setBrix(dashboardCalculations.brix ?? 0);
    setStarch(dashboardCalculations.starch ?? 0);
    setExtraPct(dashboardCalculations.extraPct ?? 0);
    setClass1Pct(dashboardCalculations.class1Pct ?? 0);
    setFireRatePct(dashboardCalculations.fireRatePct ?? 0);
    setTotalTons(dashboardCalculations.totalTons ?? 0);
    setOpenCount(dashboardCalculations.openCount ?? 0);
    setDerece1(dashboardCalculations.derece1 ?? 0);
    setDerece2(dashboardCalculations.derece2 ?? 0);
    setAppliedFromDashboard(true);
  };

  // Kontrol: Ekstra + 1. Sınıf + Fire > %100 uyarısı
  const totalQualityFire = extraPct + class1Pct + fireRatePct;
  const isSumInconsistent = totalQualityFire > 100;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      r01Streif: {
        hardness,
        brix,
        starch
      },
      r02QualityFire: {
        extraPct,
        class1Pct,
        class2Pct: Math.max(0, 100 - (extraPct + class1Pct + 2.5)),
        industryPct: 2.5,
        fireRatePct,
        totalTons
      },
      r03Incidents: {
        openCount,
        derece1,
        derece2,
        derece3: Math.max(0, openCount - (derece1 + derece2))
      },
      staffMembers: deduplicatedStaff,
      r05Facilities: r05Data
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-xl w-full p-6 space-y-4 text-slate-900 shadow-sm my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              + 5 Rapor Verisi Gir / Düzenle
            </h3>
            <p className="text-xs text-slate-500">
              {formatMonthLabel(selectedMonthKey)} dönemi canlı Firestore parametreleri
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 hover:bg-slate-50 rounded-full text-slate-500 hover:text-slate-900 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ANA PANO CANLI VERİLERİ AKTARMA BİLGİ VE AKSİYON KARTI */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 space-y-2">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="text-xs font-bold text-emerald-700">
                Ana Pano Canlı Operasyonel Verileri
              </span>
            </div>
            <button
              type="button"
              onClick={handlePullFromMainDashboard}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm shadow-emerald-950/50 cursor-pointer"
              title="Ana panodaki tüm aktif testleri, partileri ve olayları anlık olarak forma kopyalar"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>Ana Panodan Al ({dashboardCalculations?.totalRecords || 0} Kayıt)</span>
            </button>
          </div>
          <div className="text-[11px] text-emerald-700/80 tabular-nums flex items-center justify-between flex-wrap gap-1">
            <span>
              Sertlik: {dashboardCalculations?.hardness} kg • Brix: {dashboardCalculations?.brix}° • Hacim: {dashboardCalculations?.totalTons} Ton • Açık Olay: {dashboardCalculations?.openCount}
            </span>
            {appliedFromDashboard && (
              <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                 Ana panodan aktarıldı
              </span>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 max-h-[65vh] overflow-y-auto pr-1">
          
          {/* R-01 DÜZENLEME */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-sky-700">
              R-01: Streif İndeksi (Sertlik, Brix, İyot)
            </h4>
            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Sertlik (kg/cm²)</label>
                <input
                  type="number"
                  step="0.1"
                  value={hardness}
                  onChange={e => setHardness(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Brix (°Bx)</label>
                <input
                  type="number"
                  step="0.1"
                  value={brix}
                  onChange={e => setBrix(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Nişasta (1-10)</label>
                <input
                  type="number"
                  step="0.1"
                  value={starch}
                  onChange={e => setStarch(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>
          </div>

          {/* R-02 DÜZENLEME */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-emerald-700">
              R-02: Kalite Dağılımı ve Fire
            </h4>

            {isSumInconsistent && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5 flex items-start gap-2 text-amber-700 text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Tutarsızlık Uyarısı:</strong> Ekstra (%{extraPct}) + 1. Sınıf (%{class1Pct}) + Fire (%{fireRatePct}) = %{totalQualityFire.toFixed(1)} (%100'ü aşıyor). Lütfen oranları kontrol ediniz.
                </span>
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Ekstra (%)</label>
                <input
                  type="number"
                  value={extraPct}
                  onChange={e => setExtraPct(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">1. Sınıf (%)</label>
                <input
                  type="number"
                  value={class1Pct}
                  onChange={e => setClass1Pct(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Fire Oranı (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={fireRatePct}
                  onChange={e => setFireRatePct(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Hacim (Ton)</label>
                <input
                  type="number"
                  step="0.1"
                  value={totalTons}
                  onChange={e => setTotalTons(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* R-03 DÜZENLEME */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-rose-700">
              R-03: Barlag Akty Olayları
            </h4>
            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Açık Olay Sayısı</label>
                <input
                  type="number"
                  value={openCount}
                  onChange={e => setOpenCount(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Derece 1 (Kritik)</label>
                <input
                  type="number"
                  value={derece1}
                  onChange={e => setDerece1(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Derece 2 (Majör)</label>
                <input
                  type="number"
                  value={derece2}
                  onChange={e => setDerece2(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              disabled={isSaving}
              onClick={onReset}
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-bold text-amber-700 hover:text-amber-300 bg-amber-50 hover:bg-amber-50 rounded-xl border border-amber-200 transition cursor-pointer disabled:opacity-50"
              title="Manuel değerleri siler ve ana panodaki operasyonel kayıtlardan otomatik hesaplanan verilere geri döner"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Otomatik Veriye Sıfırla</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-900 rounded-xl cursor-pointer"
              >
                İptal
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Kaydediliyor...' : 'Firestore\'a Kaydet'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

// =========================================================================
// SUB-COMPONENT: STAFF TASK DETAIL MODAL
// =========================================================================
interface StaffTaskModalProps {
  staff: StaffMember;
  onClose: () => void;
  onToggleTask: (staffId: string, taskId: string) => void;
}

const StaffTaskModal: React.FC<StaffTaskModalProps> = ({ staff, onClose, onToggleTask }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 space-y-4 text-slate-900 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div>
            <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              {staff.departmentLabel}
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-1">{staff.name}</h3>
            <p className="text-xs text-slate-500">{staff.role}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 hover:bg-slate-50 rounded-full text-slate-500 hover:text-slate-900 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-600">Görev Listesi:</h4>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {staff.tasksList.map(t => (
              <div
                key={t.id}
                onClick={() => onToggleTask(staff.id, t.id)}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition ${
                  t.completed ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-50/80'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-4 h-4 rounded flex items-center justify-center border ${
                    t.completed ? 'bg-emerald-600 border-emerald-600 text-slate-900' : 'border-slate-600 bg-white'
                  }`}>
                    {t.completed && <Check className="w-3 h-3" />}
                  </div>
                  <span className={`text-xs font-medium ${t.completed ? 'line-through text-slate-500' : ''}`}>
                    {t.title}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-white hover:bg-slate-50 text-slate-900 font-bold text-xs rounded-xl cursor-pointer"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
