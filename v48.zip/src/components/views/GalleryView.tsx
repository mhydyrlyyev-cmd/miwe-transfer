import React, { useState, useEffect, useMemo } from 'react';
import { 
  Image as ImageIcon, 
  MapPin, 
  Tag, 
  Calendar, 
  Search, 
  Filter, 
  RefreshCcw, 
  ArrowLeft, 
  X, 
  Maximize2, 
  Trash2, 
  Folder, 
  ChevronLeft, 
  ChevronRight, 
  Download, 
  Grid, 
  Layers, 
  FolderOpen,
  CheckCircle2
} from 'lucide-react';
import { PhotoRecord, getAllPhotos, deletePhoto } from '../../utils/db';
import { ReferenceItem, HarvestRecord, FieldRecord, IncidentRecord, MuzRecord, BademRecord, FreezeDryRecord, LojistikRecord, AmbarRecord, ExportSampleRecord, SalesRecord } from '../../types';

interface GalleryViewProps {
  onBack?: () => void;
  onDeletePhoto?: (photo: PhotoRecord) => void;
  references?: ReferenceItem[];
  harvestRecords?: HarvestRecord[];
  fieldRecords?: FieldRecord[];
  incidentRecords?: IncidentRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  lojistikRecords?: LojistikRecord[];
  ambarRecords?: AmbarRecord[];
  exportSampleRecords?: ExportSampleRecord[];
  salesRecords?: SalesRecord[];
}

interface AlbumGroup {
  id: string;
  title: string;
  moduleKey: string;
  description: string;
  coverUrl: string;
  count: number;
  latestTimestamp: string;
  photos: PhotoRecord[];
}

const EMPTY_ARRAY: any[] = [];

export const GalleryView: React.FC<GalleryViewProps> = ({
  onBack,
  onDeletePhoto,
  references = EMPTY_ARRAY,
  harvestRecords = EMPTY_ARRAY,
  fieldRecords = EMPTY_ARRAY,
  incidentRecords = EMPTY_ARRAY,
  muzRecords = EMPTY_ARRAY,
  bademRecords = EMPTY_ARRAY,
  freezeDryRecords = EMPTY_ARRAY,
  lojistikRecords = EMPTY_ARRAY,
  ambarRecords = EMPTY_ARRAY,
  exportSampleRecords = EMPTY_ARRAY,
  salesRecords = EMPTY_ARRAY
}) => {
  const [photos, setPhotos] = useState<PhotoRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'ALBUMS' | 'GRID'>('ALBUMS');
  const [selectedAlbumId, setSelectedAlbumId] = useState<string | null>(null);
  const [filterModule, setFilterModule] = useState<string>('ALL');
  const [filterSearch, setFilterSearch] = useState<string>('');
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);
  const [deleteSuccessMsg, setDeleteSuccessMsg] = useState<string | null>(null);
  const [photoToDelete, setPhotoToDelete] = useState<PhotoRecord | null>(null);
  const [isDeletingPhoto, setIsDeletingPhoto] = useState(false);

  const loadPhotos = async () => {
    try {
      setLoading(true);
      const dbPhotos = await getAllPhotos();

      // Aggregate photos from records
      const recordPhotos: PhotoRecord[] = [];

      harvestRecords.forEach((h) => {
        (h.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `harvest_${h.id || h.refId}_${idx}`,
              refId: h.refId,
              moduleKey: 'HARVEST',
              dataUrl: photoUrl,
              timestamp: h.date || new Date().toISOString(),
              location: h.orchard || h.fieldLocation || 'Bahçe',
              description: `Hasat Fotoğrafı #${idx + 1} (${h.product || ''})`,
              synced: true
            });
          }
        });
      });

      fieldRecords.forEach((f) => {
        (f.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `field_${f.id || f.refId}_${idx}`,
              refId: f.refId,
              moduleKey: 'FIELD',
              dataUrl: photoUrl,
              timestamp: f.testDate || new Date().toISOString(),
              location: f.orchard || f.location || 'Laboratuvar',
              description: `Meyve Testi #${idx + 1} (${f.product || ''})`,
              synced: true
            });
          }
        });
      });

      muzRecords.forEach((m) => {
        (m.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `muz_${m.id || m.refId}_${idx}`,
              refId: m.refId,
              moduleKey: 'MUZ',
              dataUrl: photoUrl,
              timestamp: m.testDate || new Date().toISOString(),
              location: m.greenhouse || 'Muz Seraları',
              description: `Muz Kalite Fotoğrafı #${idx + 1}`,
              synced: true
            });
          }
        });
      });

      bademRecords.forEach((b) => {
        (b.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `badem_${b.id || b.refId}_${idx}`,
              refId: b.refId,
              moduleKey: 'BADEM',
              dataUrl: photoUrl,
              timestamp: b.testDate || new Date().toISOString(),
              location: b.orchard || 'Badem Bahçesi',
              description: `Badem Randıman #${idx + 1}`,
              synced: true
            });
          }
        });
      });

      freezeDryRecords.forEach((fd) => {
        (fd.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `fd_${fd.id || fd.refId}_${idx}`,
              refId: fd.refId,
              moduleKey: 'FREEZE_DRY',
              dataUrl: photoUrl,
              timestamp: fd.processDate || new Date().toISOString(),
              location: 'Freeze & Dry Tesisi',
              description: `Freeze-Dry Numune #${idx + 1}`,
              synced: true
            });
          }
        });
      });

      incidentRecords.forEach((inc) => {
        (inc.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `inc_${inc.id || inc.incidentId}_${idx}`,
              refId: inc.refId || inc.actNumber || inc.incidentId,
              moduleKey: 'INCIDENT',
              dataUrl: photoUrl,
              timestamp: inc.incidentDate || new Date().toISOString(),
              location: inc.location || 'Denetim İstasyonu',
              description: `Akt Kanıtı #${idx + 1}: ${inc.description?.substring(0, 40) || ''}`,
              synced: true
            });
          }
        });
      });

      references.forEach((r) => {
        (r.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `ref_${r.refId}_${idx}`,
              refId: r.refId,
              moduleKey: r.moduleKey || 'REFERANS',
              dataUrl: photoUrl,
              timestamp: r.createdAt || new Date().toISOString(),
              location: r.orchard || r.location || 'Saha',
              description: `Referans Fotoğrafı #${idx + 1}`,
              synced: true
            });
          }
        });
      });

      exportSampleRecords.forEach((es) => {
        (es.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `es_${es.id || es.refId}_${idx}`,
              refId: es.refId,
              moduleKey: 'EXPORT_SAMPLE',
              dataUrl: photoUrl,
              timestamp: es.testDate || new Date().toISOString(),
              location: es.destinationCountry || 'Eksport Lab',
              description: `İhracat Şahit Numunesi #${idx + 1} (${es.product || ''})`,
              synced: true
            });
          }
        });
      });

      lojistikRecords.forEach((l) => {
        (l.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `lojistik_${l.id || l.refId}_${idx}`,
              refId: l.refId,
              moduleKey: 'LOJISTIK',
              dataUrl: photoUrl,
              timestamp: l.shipmentDate || new Date().toISOString(),
              location: `${l.source} → ${l.destination}`,
              description: `Lojistik Sevkiyat #${idx + 1} (${l.vehiclePlate || ''})`,
              synced: true
            });
          }
        });
      });

      ambarRecords.forEach((a) => {
        (a.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `ambar_${a.id || a.refId}_${idx}`,
              refId: a.refId,
              moduleKey: 'AMBAR',
              dataUrl: photoUrl,
              timestamp: a.acceptanceDate || new Date().toISOString(),
              location: `${a.warehouse || 'Depo'} - ${a.roomNo || ''}`,
              description: `Ambar Kabul #${idx + 1}`,
              synced: true
            });
          }
        });
      });

      salesRecords.forEach((s) => {
        (s.photos || []).forEach((photoUrl, idx) => {
          if (photoUrl && photoUrl.length > 20) {
            recordPhotos.push({
              id: `sales_${s.id || s.refId}_${idx}`,
              refId: s.refId,
              moduleKey: 'SALES',
              dataUrl: photoUrl,
              timestamp: s.salesDate || new Date().toISOString(),
              location: s.customer || 'Satış Noktası',
              description: `Satış Sevkiyat #${idx + 1} (${s.product || ''})`,
              synced: true
            });
          }
        });
      });

      // Deduplicate by dataUrl
      const combined = [...dbPhotos];
      recordPhotos.forEach((rp) => {
        if (!combined.some((cp) => cp.dataUrl === rp.dataUrl)) {
          combined.push(rp);
        }
      });

      setPhotos(
        combined.sort(
          (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        )
      );
    } catch (err) {
      console.error('Failed to load photos:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPhotos();
  }, [
    harvestRecords,
    fieldRecords,
    muzRecords,
    bademRecords,
    freezeDryRecords,
    incidentRecords,
    references,
    lojistikRecords,
    ambarRecords,
    exportSampleRecords,
    salesRecords
  ]);

  // Handle Photo Delete Request (Opens iframe-safe confirmation modal)
  const handleDelete = (e: React.MouseEvent, photo: PhotoRecord) => {
    e.stopPropagation();
    setPhotoToDelete(photo);
  };

  const confirmDeletePhotoExecution = async () => {
    if (!photoToDelete) return;
    const photo = photoToDelete;
    setIsDeletingPhoto(true);
    try {
      await deletePhoto(photo.id, photo.dataUrl);
      if (onDeletePhoto) {
        await onDeletePhoto(photo);
      }
      setPhotos((prev) => prev.filter((p) => p.id !== photo.id && p.dataUrl !== photo.dataUrl));
      if (selectedPhotoIndex !== null) {
        setSelectedPhotoIndex(null);
      }
      setPhotoToDelete(null);
      setDeleteSuccessMsg(`"${photo.refId || 'Saha'}" fotoğrafı galeriden ve bağlı kayıttan başarıyla silindi.`);
      setTimeout(() => setDeleteSuccessMsg(null), 3500);
    } catch (err) {
      console.error('Fotoğraf silinemedi:', err);
      setDeleteSuccessMsg('Fotoğraf silinirken bir hata oluştu.');
      setTimeout(() => setDeleteSuccessMsg(null), 3500);
    } finally {
      setIsDeletingPhoto(false);
    }
  };

  // Filtered Photos List
  const filteredPhotos = useMemo(() => {
    return photos.filter((photo) => {
      const matchesModule = filterModule === 'ALL' || photo.moduleKey === filterModule;
      const matchesSearch =
        !filterSearch ||
        (photo.location && photo.location.toLowerCase().includes(filterSearch.toLowerCase())) ||
        (photo.refId && photo.refId.toLowerCase().includes(filterSearch.toLowerCase())) ||
        (photo.description && photo.description.toLowerCase().includes(filterSearch.toLowerCase()));

      const matchesAlbum = !selectedAlbumId || photo.moduleKey === selectedAlbumId;

      return matchesModule && matchesSearch && matchesAlbum;
    });
  }, [photos, filterModule, filterSearch, selectedAlbumId]);

  // Build Albums Grouping
  const albums = useMemo<AlbumGroup[]>(() => {
    const map: Record<string, PhotoRecord[]> = {};

    photos.forEach((p) => {
      const key = p.moduleKey || 'GENEL';
      if (!map[key]) map[key] = [];
      map[key].push(p);
    });

    const albumDefinitions: Record<string, { title: string; desc: string }> = {
      MUZ: { title: '🍌 Muz Kalite Albümü', desc: 'Muz seraları, şeker testi, brix ve meyve eti fotoğrafları' },
      HARVEST: { title: '🍒 Günlük Hasat Albümü', desc: 'Bahçe kabul, kasa, palet ve günlük toplama görselleri' },
      FIELD: { title: '🔬 Meyve Kalite Testi Albümü', desc: 'Sertlik, brix, penetrometre ve tarla analizleri' },
      BADEM: { title: '🥜 Badem Randıman Albümü', desc: 'Kırım, iç randıman, kabuk ve çifte badem fotoğrafları' },
      FREEZE_DRY: { title: '❄️ Freeze & Dry Albümü', desc: 'Liyofilizasyon, dondurarak kurutma numuneleri' },
      INCIDENT: { title: '⚠️ Barlag Akty & Uygunsuzluk', desc: 'Hasar tutanakları, 5-Why kök sebep ve karantina albümü' },
      AMBAR: { title: '🏭 Ambar Kabul & Stok Albümü', desc: 'Giriş kontrol, sıcaklık ve paketleme görselleri' },
      REFERANS: { title: '📋 Genel Saha Kayıt Albümü', desc: 'İstasyon ve parti takip görsel arşivi' }
    };

    return Object.keys(map).map((key) => {
      const list = map[key];
      const def = albumDefinitions[key] || { title: `📁 ${key} Albümü`, desc: `${key} modülüne ait fotoğraflar` };
      return {
        id: key,
        title: def.title,
        moduleKey: key,
        description: def.desc,
        coverUrl: list[0]?.dataUrl || '',
        count: list.length,
        latestTimestamp: list[0]?.timestamp || new Date().toISOString(),
        photos: list
      };
    });
  }, [photos]);

  // Currently viewing photo in Lightbox
  const currentPhoto = selectedPhotoIndex !== null ? filteredPhotos[selectedPhotoIndex] : null;

  // Lightbox Navigation
  const handlePrevPhoto = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (selectedPhotoIndex !== null && selectedPhotoIndex > 0) {
      setSelectedPhotoIndex(selectedPhotoIndex - 1);
    }
  };

  const handleNextPhoto = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (selectedPhotoIndex !== null && selectedPhotoIndex < filteredPhotos.length - 1) {
      setSelectedPhotoIndex(selectedPhotoIndex + 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedPhotoIndex === null) return;
      if (e.key === 'ArrowLeft') handlePrevPhoto();
      if (e.key === 'ArrowRight') handleNextPhoto();
      if (e.key === 'Escape') setSelectedPhotoIndex(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedPhotoIndex, filteredPhotos]);

  // Download image helper
  const handleDownloadImage = (e: React.MouseEvent, photo: PhotoRecord) => {
    e.stopPropagation();
    const a = document.createElement('a');
    a.href = photo.dataUrl;
    a.download = `saha_fotograf_${photo.refId || 'gorsel'}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {deleteSuccessMsg && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-emerald-500 flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="text-xs font-bold">{deleteSuccessMsg}</span>
        </div>
      )}

      {/* Main Header Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 sm:p-5">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition shadow-2xs border border-slate-200"
              >
                <ArrowLeft className="w-4 h-4 text-slate-600" />
                <span>Geri Dön</span>
              </button>
            )}
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-emerald-600" />
                <span>Saha Fotoğraf Albümleri & Arşivi</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Modül bazlı düzenlenmiş, büyütülebilir ve silinebilir fotoğraf galerisi ({photos.length} Görsel)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {/* View Mode Switcher */}
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200">
              <button
                onClick={() => { setViewMode('ALBUMS'); setSelectedAlbumId(null); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  viewMode === 'ALBUMS' && !selectedAlbumId
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Folder className="w-3.5 h-3.5 text-emerald-600" />
                <span>Albümler</span>
              </button>
              <button
                onClick={() => { setViewMode('GRID'); setSelectedAlbumId(null); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  viewMode === 'GRID'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Grid className="w-3.5 h-3.5 text-slate-600" />
                <span>Tüm Fotoğraflar</span>
              </button>
            </div>

            <button
              onClick={loadPhotos}
              className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl transition border border-slate-200"
              title="Yenile"
            >
              <RefreshCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2 border-t border-slate-100">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="RefID, Lokasyon veya Açıklama ara..."
              value={filterSearch}
              onChange={(e) => setFilterSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs font-medium bg-slate-50 border border-slate-200 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl transition outline-none"
            />
          </div>

          <div className="relative w-full sm:w-60 shrink-0">
            <Filter className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <select
              value={filterModule}
              onChange={(e) => setFilterModule(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs font-bold text-slate-800 bg-slate-50 border border-slate-200 focus:bg-white focus:border-emerald-500 rounded-xl transition outline-none appearance-none cursor-pointer"
            >
              <option value="ALL">Tüm Modüller (Filtresiz)</option>
              <option value="MUZ"> 03 Muz Kalite</option>
              <option value="HARVEST"> 01 Günlük Hasat</option>
              <option value="FIELD"> 02 Meyve Testi</option>
              <option value="BADEM"> 04 Badem Randıman</option>
              <option value="AMBAR"> 06 Ambar Kabul</option>
              <option value="FREEZE_DRY"> 07 Freeze & Dry</option>
              <option value="INCIDENT"> 10 Barlag Akty</option>
            </select>
          </div>
        </div>

        {/* Selected Album Breadcrumb */}
        {selectedAlbumId && (
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Albüm:</span>
              <span className="text-xs font-bold text-emerald-900 bg-emerald-100 px-2.5 py-1 rounded-lg flex items-center gap-1.5 border border-emerald-300">
                <FolderOpen className="w-3.5 h-3.5 text-emerald-700" />
                {albums.find(a => a.id === selectedAlbumId)?.title || selectedAlbumId}
              </span>
              <span className="text-xs font-bold text-slate-500">
                ({filteredPhotos.length} Fotoğraf)
              </span>
            </div>
            <button
              onClick={() => setSelectedAlbumId(null)}
              className="text-xs font-bold text-slate-600 hover:text-slate-900 underline flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Tüm Albümlere Dön
            </button>
          </div>
        )}
      </div>

      {/* Loading Spinner */}
      {loading ? (
        <div className="flex justify-center items-center h-48 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : photos.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center space-y-2">
          <ImageIcon className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">Saha Fotoğrafı Bulunamadı</h3>
          <p className="text-xs text-slate-500">Henüz saha formlarından çekilen veya galeriden yüklenen görsel yok.</p>
        </div>
      ) : viewMode === 'ALBUMS' && !selectedAlbumId ? (
        /* ALBUM CARDS GRID */
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {albums.map((album) => (
            <div
              key={album.id}
              onClick={() => setSelectedAlbumId(album.id)}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-xl hover:border-emerald-300 transition duration-300 cursor-pointer overflow-hidden group flex flex-col"
            >
              {/* Album Cover with Stack Effect */}
              <div className="aspect-[4/3] bg-slate-900 relative overflow-hidden">
                {album.coverUrl ? (
                  <img
                    src={album.coverUrl}
                    alt={album.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-108 transition duration-500"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-800 text-slate-500">
                    <ImageIcon className="w-10 h-10" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent" />
                
                {/* Photo Count Badge */}
                <div className="absolute top-3 right-3 bg-emerald-950/90 backdrop-blur-md text-emerald-200 text-[11px] font-bold px-2.5 py-1 rounded-full border border-emerald-500/40 shadow-sm flex items-center gap-1">
                  <Layers className="w-3 h-3 text-emerald-400" />
                  <span>{album.count} Fotoğraf</span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[10px] font-bold text-teal-300 block mb-0.5">
                    Saha Albümü
                  </span>
                  <h3 className="text-sm font-bold text-white leading-tight truncate">
                    {album.title}
                  </h3>
                </div>
              </div>

              {/* Album Info Footer */}
              <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex-1 flex flex-col justify-between space-y-2">
                <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                  {album.description}
                </p>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-slate-500">
                  <span>Son Yükleme:</span>
                  <span className="tabular-nums text-slate-700">
                    {new Date(album.latestTimestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Individual photo grid */
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredPhotos.map((photo, index) => (
            <div
              key={photo.id || index}
              onClick={() => setSelectedPhotoIndex(index)}
              className="bg-white rounded-2xl overflow-hidden shadow-xs border border-slate-200 hover:shadow-lg hover:border-emerald-300 transition group cursor-pointer flex flex-col"
            >
              <div className="aspect-[4/3] bg-slate-100 relative overflow-hidden">
                <img
                  src={photo.dataUrl}
                  alt={photo.description || 'Saha görseli'}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                
                {/* Delete Button on Hover */}
                <button
                  type="button"
                  onClick={(e) => handleDelete(e, photo)}
                  className="absolute top-2 right-2 p-2 bg-rose-600/90 hover:bg-rose-700 backdrop-blur text-white rounded-xl shadow-md transition opacity-80 hover:opacity-100"
                  title="Fotoğrafı Sil"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>

                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition flex items-center justify-center pointer-events-none">
                  <span className="flex items-center gap-1 text-[11px] font-bold text-white bg-black/70 px-3 py-1.5 rounded-xl backdrop-blur-xs">
                    <Maximize2 className="w-3.5 h-3.5" /> Büyüt
                  </span>
                </div>
              </div>

              <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-800 text-[10px] font-bold rounded-md flex items-center gap-1">
                      <Tag className="w-3 h-3 text-slate-400" />
                      {photo.moduleKey}
                    </span>
                    {photo.refId && (
                      <span className="text-[10px] tabular-nums text-emerald-700 font-bold bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md">
                        {photo.refId}
                      </span>
                    )}
                  </div>

                  {photo.location && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-800 font-bold mb-1 truncate">
                      <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                      <span className="truncate">{photo.location}</span>
                    </div>
                  )}

                  {photo.description && (
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                      {photo.description}
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-medium">
                  <div className="flex items-center gap-1 tabular-nums">
                    <Calendar className="w-3 h-3" />
                    {new Date(photo.timestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <button
                    type="button"
                    onClick={(e) => handleDownloadImage(e, photo)}
                    className="text-slate-500 hover:text-emerald-700 p-1"
                    title="İndir"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* LIGHTBOX FULLSCREEN MODAL */}
      {currentPhoto && selectedPhotoIndex !== null && (
        <div
          onClick={() => setSelectedPhotoIndex(null)}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 cursor-zoom-out animate-in fade-in duration-200"
        >
          <div
            className="max-w-5xl w-full max-h-[92vh] bg-slate-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header Bar */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 bg-emerald-800/80 text-emerald-200 text-xs font-bold rounded-lg border border-emerald-600">
                  {currentPhoto.moduleKey}
                </span>
                <span className="tabular-nums text-xs font-bold text-teal-300 bg-slate-800 px-2 py-0.5 rounded-lg border border-slate-700">
                  {currentPhoto.refId}
                </span>
                <span className="text-xs text-slate-300 font-medium">
                  • {currentPhoto.location}
                </span>
                <span className="text-xs text-slate-500 tabular-nums">
                  ({selectedPhotoIndex + 1} / {filteredPhotos.length})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => handleDownloadImage(e, currentPhoto)}
                  className="p-2 rounded-xl text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
                  title="İndir"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                </button>
                <button
                  onClick={(e) => handleDelete(e, currentPhoto)}
                  className="p-2 rounded-xl text-rose-300 hover:text-white bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 transition"
                  title="Fotoğrafı Sil"
                >
                  <Trash2 className="w-4 h-4 text-rose-400" />
                </button>
                <button
                  onClick={() => setSelectedPhotoIndex(null)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Image Stage with Navigation Controls */}
            <div className="relative bg-slate-950 flex-1 flex items-center justify-center p-2 min-h-[50vh] max-h-[70vh] overflow-hidden group">
              {/* Previous Image Arrow */}
              {selectedPhotoIndex > 0 && (
                <button
                  type="button"
                  onClick={handlePrevPhoto}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full transition shadow-lg backdrop-blur-xs border border-white/20 z-10"
                  title="Önceki Fotoğraf (Sol Ok)"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              )}

              <img
                src={currentPhoto.dataUrl}
                alt={currentPhoto.description || 'Saha Görseli'}
                className="max-h-[66vh] w-auto object-contain rounded-xl shadow-2xl"
              />

              {/* Next Image Arrow */}
              {selectedPhotoIndex < filteredPhotos.length - 1 && (
                <button
                  type="button"
                  onClick={handleNextPhoto}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full transition shadow-lg backdrop-blur-xs border border-white/20 z-10"
                  title="Sonraki Fotoğraf (Sağ Ok)"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              )}
            </div>

            {/* Modal Footer Bar */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 text-xs text-slate-300 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <p className="text-slate-300 font-medium">
                {currentPhoto.description || 'Açıklama belirtilmedi.'}
              </p>
              <div className="text-[10px] text-slate-400 tabular-nums shrink-0">
                Tarih: {new Date(currentPhoto.timestamp).toLocaleString('tr-TR')}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PHOTO DELETE CONFIRMATION MODAL */}
      {photoToDelete && (
        <div
          onClick={() => !isDeletingPhoto && setPhotoToDelete(null)}
          className="fixed inset-0 z-[60] bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden p-5 space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-rose-100 text-rose-600 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Fotoğrafı Silmeyi Onayla
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  <strong>{photoToDelete.refId || photoToDelete.moduleKey || 'Saha'}</strong> kaydına ait bu fotoğrafı galeriden, çevrimdışı önbellekten (IndexedDB) ve bağlı form kaydından kalıcı olarak silmek istediğinize emin misiniz?
                </p>
              </div>
            </div>

            {photoToDelete.dataUrl && (
              <div className="h-32 w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center">
                <img
                  src={photoToDelete.dataUrl}
                  alt="Silinecek görsel"
                  className="max-h-full w-auto object-contain"
                />
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                disabled={isDeletingPhoto}
                onClick={() => setPhotoToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="button"
                disabled={isDeletingPhoto}
                onClick={confirmDeletePhotoExecution}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeletingPhoto ? 'Siliniyor...' : 'Evet, Kalıcı Olarak Sil'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
