import React, { useMemo, useState } from 'react';
import { X, Search, Check, Timer, AlertTriangle, ChevronLeft, Banana, Nut, Play, Square } from 'lucide-react';
import { ReferenceItem, ProcessStepEntry } from '../../types';
import { FLOWS, FlowKey, FlowStep, RIPENING, bademHarvestAdvice, bademMoistureAdvice } from '../../config/processFlows';
import { cleanName } from '../../utils/qrRef';

/**
 * v4.3 — Muz 7 adım / badem akışı.
 * Otomatik adımlar mevcut kayıtlardan okunur (muz kaydı, depo kabul, sevk, satış);
 * diğer adımlar burada işaretlenir ve partinin `processSteps` listesine yazılır.
 */
interface Props {
  isOpen: boolean;
  flow: FlowKey;
  references: ReferenceItem[];
  muzRecords: any[];
  ambarRecords: any[];
  lojistikRecords: any[];
  salesRecords: any[];
  currentUserName?: string;
  onSaveStep: (refId: string, entry: ProcessStepEntry) => Promise<boolean>;
  onOpenIncident: (refId: string) => void;
  onClose: () => void;
  /** doğrudan bu partinin adımlarını aç (ör. QR'dan) */
  initialRefId?: string;
}

type StepState = { done: boolean; at?: string; entry?: ProcessStepEntry; running?: boolean };

const day = (v?: string) => (v ? String(v).slice(0, 10) : '');
const fmt = (v?: string) => { if (!v) return ''; const d = new Date(v); return isNaN(d.getTime()) ? day(v) : d.toLocaleDateString('tr-TR', { day: '2-digit', month: 'short' }); };
const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const uid = () => `PS-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
const daysBetween = (a: string, b: string) => (Date.parse(b) - Date.parse(a)) / 864e5;

export const ProcessFlowModal: React.FC<Props> = (p) => {
  const def = FLOWS[p.flow];
  const [q, setQ] = useState('');
  const [openRef, setOpenRef] = useState<string | null>(p.initialRefId || null);
  const [editStep, setEditStep] = useState<string | null>(null);
  const [vals, setVals] = useState<Record<string, any>>({});
  const [at, setAt] = useState(nowLocal());
  const [note, setNote] = useState('');
  const [reason, setReason] = useState('');
  const [openAkt, setOpenAkt] = useState(true);
  const [saving, setSaving] = useState(false);

  const lots = useMemo(() => {
    const rx = p.flow === 'MUZ' ? /muz|banan/i : /badem|almond/i;
    return p.references
      .filter(r => !(r as any).archived && r.refKind !== 'TEST' && (r.moduleKey === p.flow || rx.test(r.product || '')))
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }, [p.references, p.flow]);

  const stateOf = (ref: ReferenceItem): Record<string, StepState> => {
    const out: Record<string, StepState> = {};
    const mine = (ref.processSteps || []).filter(s => s.flow === p.flow);
    const muz = p.muzRecords.filter(m => m.refId === ref.refId).map(m => m.timestamp || m.recordDate).filter(Boolean).sort();
    const ships = p.lojistikRecords.filter(l => l.refId === ref.refId).map(l => l.shipmentDate || l.timestamp).filter(Boolean).sort();
    const firstShip = ships[0];
    const ambar = p.ambarRecords.filter(a => a.refId === ref.refId).map(a => a.acceptanceDate || a.timestamp).filter(Boolean).sort();
    const sales = p.salesRecords.filter(s => s.refId === ref.refId).map(s => s.salesDate || s.timestamp).filter(Boolean).sort();
    for (const st of def.steps) {
      const manual = [...mine].reverse().find(s => s.step === st.key);
      let autoAt: string | undefined;
      if (st.auto === 'MUZ_RECORD') autoAt = muz[0];
      if (st.auto === 'LOJISTIK') autoAt = firstShip;
      if (st.auto === 'SALES') autoAt = sales[0];
      if (st.auto === 'AMBAR_BEFORE_SHIP') autoAt = ambar.find(a => !firstShip || a <= firstShip);
      if (st.auto === 'AMBAR_AFTER_SHIP') autoAt = firstShip ? ambar.find(a => a > firstShip) : undefined;
      if (st.timed && manual) out[st.key] = { done: !!manual.endAt, running: !manual.endAt, at: manual.endAt || manual.at, entry: manual };
      else out[st.key] = { done: !!(manual || autoAt), at: manual?.at || autoAt, entry: manual };
    }
    return out;
  };

  const ref = openRef ? lots.find(r => r.refId === openRef) : undefined;
  const list = lots.filter(r => !q.trim() || `${r.refId} ${r.product} ${r.greenhouse || ''} ${r.orchard || ''} ${r.location || ''}`.toLowerCase().includes(q.trim().toLowerCase()));

  if (!p.isOpen) return null;

  const startEdit = (st: FlowStep, s?: StepState) => {
    setEditStep(st.key);
    setAt(nowLocal()); setNote(''); setReason(''); setOpenAkt(true);
    const v: Record<string, any> = {};
    (st.fields || []).forEach(f => { v[f.key] = s?.entry?.values?.[f.key] ?? f.def ?? ''; });
    if (st.timed && s?.running) v.exitColor = RIPENING.targetColor;
    setVals(v);
  };

  const save = async (st: FlowStep, s: StepState) => {
    if (!ref) return;
    const iso = new Date(at).toISOString();
    let entry: ProcessStepEntry;
    let incident = false;
    if (st.timed && s.running && s.entry) {
      const planned = Number(s.entry.values?.plannedDays) || RIPENING.days;
      const d = daysBetween(s.entry.at, iso);
      const early = d < planned - 0.25;
      if (early && !reason.trim()) { alert('Erken çıkış nedeni yazın (geç hasat, teknik sorun vb.).'); return; }
      entry = { ...s.entry, endAt: iso, values: { ...(s.entry.values || {}), exitColor: Number(vals.exitColor) || null, actualDays: Math.round(d * 10) / 10 }, early, reason: early ? reason.trim() : undefined, note: note || s.entry.note };
      incident = early && openAkt;
    } else {
      const values: Record<string, any> = {};
      (st.fields || []).forEach(f => { const v = vals[f.key]; values[f.key] = f.type === 'number' ? (v === '' || v == null ? null : Number(v)) : (v ?? ''); });
      entry = { id: uid(), flow: p.flow, step: st.key, at: iso, by: p.currentUserName, values, decision: values.decision ? String(values.decision) : undefined, note: note || undefined };
    }
    setSaving(true);
    const ok = await p.onSaveStep(ref.refId, entry);
    setSaving(false);
    if (ok) { setEditStep(null); if (incident) p.onOpenIncident(ref.refId); }
  };

  const Icon = p.flow === 'MUZ' ? Banana : Nut;

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm" onClick={p.onClose}>
      <div className="w-full sm:max-w-2xl max-h-[92vh] flex flex-col bg-slate-50 dark:bg-slate-950 rounded-t-3xl sm:rounded-3xl shadow-2xl" onClick={e => e.stopPropagation()} role="dialog" aria-label={def.title}>
        <div className="flex items-center justify-between gap-3 px-5 py-4 bg-white dark:bg-slate-900 rounded-t-3xl border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            {ref ? (
              <button type="button" onClick={() => { setOpenRef(null); setEditStep(null); }} className="p-2 -ml-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Geri"><ChevronLeft className="w-5 h-5" /></button>
            ) : (
              <span className={`w-10 h-10 rounded-xl flex items-center justify-center ${p.flow === 'MUZ' ? 'bg-yellow-50 text-yellow-700' : 'bg-orange-50 text-orange-800'}`}><Icon className="w-5 h-5" /></span>
            )}
            <div className="min-w-0">
              <div className="font-bold text-slate-900 dark:text-white truncate">{ref ? ref.refId : def.title}</div>
              <div className="text-xs text-slate-500 truncate">{ref ? [cleanName(ref.product), cleanName(ref.sortVariety || ref.variety), cleanName(ref.greenhouse || ref.orchard || ref.location)].filter(Boolean).join(' · ') : `${lots.length} parti`}</div>
            </div>
          </div>
          <button type="button" onClick={p.onClose} className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Kapat"><X className="w-5 h-5" /></button>
        </div>

        {!ref && (
          <>
            <div className="px-5 py-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
              <label className="relative block">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input value={q} onChange={e => setQ(e.target.value)} placeholder="RefID, sera / bahçe ara…" className="w-full min-h-[40px] pl-9 pr-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
              </label>
            </div>
            <ul className="flex-1 overflow-y-auto p-4 space-y-2">
              {list.map(r => {
                const st = stateOf(r);
                const doneN = def.steps.filter(s => st[s.key].done).length;
                const cur = def.steps.find(s => !st[s.key].done);
                const run = st.SARARTMA?.running ? st.SARARTMA : undefined;
                const runDays = run?.entry ? daysBetween(run.entry.at, new Date().toISOString()) : 0;
                const late = run?.entry && runDays > (Number(run.entry.values?.plannedDays) || RIPENING.days) + 1;
                return (
                  <li key={r.refId}>
                    <button type="button" onClick={() => setOpenRef(r.refId)} className="w-full text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 hover:border-slate-300 cursor-pointer">
                      <div className="flex items-center justify-between gap-2">
                        <span className="tabular-nums text-xs font-bold text-slate-900 dark:text-white truncate">{r.refId}</span>
                        <span className="text-xs font-bold text-slate-500 tabular-nums">{doneN}/{def.steps.length}</span>
                      </div>
                      <div className="text-xs text-slate-500 truncate">{[cleanName(r.greenhouse || r.orchard || r.location), cur ? `Sıradaki: ${cur.label}` : 'Tamamlandı'].filter(Boolean).join(' · ')}</div>
                      <div className="mt-2 flex gap-1">
                        {def.steps.map(s => (
                          <span key={s.key} title={s.label} className={`h-1.5 flex-1 rounded-full ${st[s.key].done ? 'bg-emerald-500' : st[s.key].running ? 'bg-amber-400' : 'bg-slate-200 dark:bg-slate-800'}`} />
                        ))}
                      </div>
                      {run && (
                        <div className={`mt-2 inline-flex items-center gap-1 text-[11px] font-bold ${late ? 'text-rose-700' : 'text-amber-700'}`}>
                          <Timer className="w-3.5 h-3.5" /> Sarartmada {Math.floor(runDays)}. gün{late ? ' — süre aşıldı' : ''}
                        </div>
                      )}
                    </button>
                  </li>
                );
              })}
              {list.length === 0 && <li className="py-12 text-center text-sm text-slate-500">Bu akışta parti yok.</li>}
            </ul>
          </>
        )}

        {ref && (() => {
          const st = stateOf(ref);
          return (
            <ol className="flex-1 overflow-y-auto p-4 space-y-2">
              {def.steps.map((s, i) => {
                const S = st[s.key];
                const editing = editStep === s.key;
                const v = S.entry?.values || {};
                const advice = s.key === 'TEST' ? bademHarvestAdvice(Number(editing ? vals.hullSplitPct : v.hullSplitPct), Number(editing ? vals.kernelMoisturePct : v.kernelMoisturePct))
                  : s.key === 'NEM' ? bademMoistureAdvice(Number(editing ? vals.wholeMoisturePct : v.wholeMoisturePct), Number(editing ? vals.kernelMoisturePct : v.kernelMoisturePct)) : null;
                const runningDays = S.running && S.entry ? daysBetween(S.entry.at, new Date(at).toISOString()) : 0;
                const planned = Number(S.entry?.values?.plannedDays) || RIPENING.days;
                return (
                  <li key={s.key} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
                    <div className="flex items-start gap-3">
                      <span className={`mt-0.5 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${S.done ? 'bg-emerald-600 text-white' : S.running ? 'bg-amber-400 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'}`}>
                        {S.done ? <Check className="w-4 h-4" /> : i + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{s.label}</span>
                          {S.at && <span className="text-xs text-slate-500">{fmt(S.at)}</span>}
                        </div>
                        {s.hint && <p className="text-xs text-slate-500 mt-0.5">{s.hint}</p>}
                        {S.entry && !editing && (
                          <p className="text-xs text-slate-700 dark:text-slate-300 mt-1">
                            {Object.entries(S.entry.values || {}).filter(([, x]) => x !== null && x !== '').map(([k, x]) => `${k === 'decision' ? 'Karar' : (s.fields?.find(f => f.key === k)?.label || (k === 'exitColor' ? 'Çıkış rengi' : k === 'actualDays' ? 'Gerçek süre (gün)' : k))}: ${x}`).join(' · ')}
                            {S.entry.early && <span className="block text-rose-700 font-bold">Erken çıkış: {S.entry.reason}</span>}
                          </p>
                        )}
                        {advice && <p className={`text-xs font-bold mt-1 ${advice.ok ? 'text-emerald-700' : 'text-amber-700'}`}>{advice.text}</p>}
                        {S.running && !editing && <p className="text-xs font-bold text-amber-700 mt-1">Sarartmada · {Math.floor(daysBetween(S.entry!.at, new Date().toISOString()))}/{planned} gün</p>}

                        {!editing && (!S.done || s.timed) && !(S.done && s.timed) && (
                          <button type="button" onClick={() => startEdit(s, S)} className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
                            {s.timed ? (S.running ? <><Square className="w-3.5 h-3.5" /> Bitir</> : <><Play className="w-3.5 h-3.5" /> Başlat</>) : (s.auto ? 'Elle işaretle' : 'Kaydet')}
                          </button>
                        )}

                        {editing && (
                          <div className="mt-2 space-y-2">
                            <label className="block text-xs font-semibold text-slate-600">{s.timed && S.running ? 'Bitiş zamanı' : 'Zaman'}
                              <input type="datetime-local" value={at} onChange={e => setAt(e.target.value)} className="mt-1 w-full min-h-[38px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
                            </label>
                            {!(s.timed && S.running) && (s.fields || []).map(f => (
                              <label key={f.key} className="block text-xs font-semibold text-slate-600">{f.label}{f.unit ? ` (${f.unit})` : ''}
                                {f.type === 'select' ? (
                                  <select value={vals[f.key] ?? ''} onChange={e => setVals(v => ({ ...v, [f.key]: e.target.value }))} className="mt-1 w-full min-h-[38px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm">
                                    <option value="">Seçin…</option>
                                    {f.options?.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                                  </select>
                                ) : (
                                  <input type={f.type === 'number' ? 'number' : 'text'} inputMode={f.type === 'number' ? 'decimal' : undefined} min={f.min} max={f.max} step={f.step}
                                    value={vals[f.key] ?? ''} onChange={e => setVals(v => ({ ...v, [f.key]: e.target.value }))}
                                    className="mt-1 w-full min-h-[38px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
                                )}
                              </label>
                            ))}
                            {s.timed && S.running && (
                              <>
                                <label className="block text-xs font-semibold text-slate-600">Çıkış rengi (1–7, hedef {RIPENING.targetColor})
                                  <input type="number" min={1} max={7} step={1} value={vals.exitColor ?? ''} onChange={e => setVals(v => ({ ...v, exitColor: e.target.value }))} className="mt-1 w-full min-h-[38px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
                                </label>
                                {runningDays < planned - 0.25 && (
                                  <div className="rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 p-2.5 space-y-2">
                                    <p className="flex items-center gap-1.5 text-xs font-bold text-rose-800 dark:text-rose-200"><AlertTriangle className="w-4 h-4" /> Erken çıkış: {runningDays.toFixed(1)} / {planned} gün</p>
                                    <input value={reason} onChange={e => setReason(e.target.value)} placeholder="Neden? (geç hasat, teknik sorun…)" className="w-full min-h-[38px] px-2 rounded-lg border border-rose-300 bg-white dark:bg-slate-950 text-sm" />
                                    <label className="flex items-center gap-2 text-xs font-semibold text-rose-900 dark:text-rose-200"><input type="checkbox" checked={openAkt} onChange={e => setOpenAkt(e.target.checked)} /> Kayıttan sonra akt (olay) formunu aç</label>
                                  </div>
                                )}
                              </>
                            )}
                            <input value={note} onChange={e => setNote(e.target.value)} placeholder="Not (isteğe bağlı)" className="w-full min-h-[38px] px-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm" />
                            <div className="flex gap-2">
                              <button type="button" disabled={saving} onClick={() => save(s, S)} className="flex-1 min-h-[42px] rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-sm font-bold cursor-pointer">{saving ? 'Kaydediliyor…' : 'Kaydet'}</button>
                              <button type="button" onClick={() => setEditStep(null)} className="px-4 min-h-[42px] rounded-xl border border-slate-300 dark:border-slate-700 text-sm font-bold cursor-pointer">Vazgeç</button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ol>
          );
        })()}
      </div>
    </div>
  );
};

export default ProcessFlowModal;
