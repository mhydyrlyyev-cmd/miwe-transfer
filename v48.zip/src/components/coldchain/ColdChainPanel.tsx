import React, { useMemo, useState } from 'react';
import { Scale, Snowflake } from 'lucide-react';
import type { AmbarRecord, BalanceAdjustment, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { analyzeColdChain, ColdChainAlert, LotFlow } from '../../utils/coldChainEngine';
import { Button, Tabs, Segmented, ListRow, Badge } from '../ui';
import { ALERT_STAGE, STAGE_BY_KEY, StageKey } from '../../config/processStages';

/**
 * v3.4 — Soğuk Zincir Paneli (Madde 3, 4, 8, 9, 11)
 * Lojistik + depo + ön soğutma tek çatı: uyarılar, parti akışı (kütle dengesi),
 * oda / bahçe / varış KPI'ları ve fire oranları. Sade: varsayılan sekme yalnızca uyarılar.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onOpenPrecooling?: (ref: ReferenceItem) => void;
  onOpenRecord?: (refId: string) => void;
  /** v3.6: yalnızca bu aşamanın uyarıları ve tabloları (boşsa tümü) */
  stage?: StageKey;
}

type TabKey = 'ALERTS' | 'LOTS' | 'ROOMS' | 'ORCHARDS' | 'DEST' | 'LOSS';

const kg = (v?: number | null) => (v === undefined || v === null ? '—' : `${Math.round(v).toLocaleString('tr-TR')}`);

const ADJ_LABEL: Record<BalanceAdjustment['kind'], string> = {
  LOSS: 'Fire / kayıp yaz',
  DIRECT_TO_STORE: 'Ön soğutmasız depoya alındı',
  LATE_HARVEST: 'Geç gelen hasat ekle',
  CORRECTION: 'Hasat kg düzeltmesi (±)',
};

export default function ColdChainPanel(p: Props) {
  const [tab, setTab] = useState<TabKey>('ALERTS');
  const [levelFilter, setLevelFilter] = useState<'ALL' | ColdChainAlert['level']>('ALL');
  const [adjFor, setAdjFor] = useState<{ refId: string; kind: BalanceAdjustment['kind']; kg: string; reason: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const summary = useMemo(() => analyzeColdChain({
    references: p.references, harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords,
    lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords,
  }), [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);

  const stageAlerts = useMemo(() => (p.stage ? summary.alerts.filter(a => ALERT_STAGE[a.kind] === p.stage) : summary.alerts), [summary.alerts, p.stage]);
  const counts = useMemo(() => ({
    critical: stageAlerts.filter(a => a.level === 'critical').length,
    warning: stageAlerts.filter(a => a.level === 'warning').length,
    info: stageAlerts.filter(a => a.level === 'info').length,
  }), [stageAlerts]);
  const lotMap = useMemo(() => new Map(summary.lots.map(l => [l.ref.refId, l])), [summary.lots]);
  const activeLots = summary.lots.filter(l => (p.stage === 'ON_SOGUTMA' ? l.ref.status === 'CREATED' : l.ref.status !== 'COMPLETED' && l.ref.status !== 'SOLD' && l.ref.status !== 'CLOSED'));

  const startAdj = (a: ColdChainAlert) => {
    const lot = lotMap.get(a.refId);
    const open = lot ? Math.round(Math.abs(lot.openBalanceKg)) : 0;
    setErr(null);
    setAdjFor({ refId: a.refId, kind: a.kind === 'OVER_BALANCE' ? 'LATE_HARVEST' : 'LOSS', kg: open ? String(open) : '', reason: '' });
  };
  const saveAdj = async () => {
    if (!adjFor || !p.onAddBalanceAdjustment) return;
    const v = Number(adjFor.kg.replace(',', '.'));
    if (!Number.isFinite(v) || v === 0 || (adjFor.kind !== 'CORRECTION' && v < 0)) { setErr('Geçerli bir kg girin.'); return; }
    if (adjFor.kind === 'LOSS' && !adjFor.reason.trim()) { setErr('Fire için neden yazın (çürük, ezik, tartı farkı…).'); return; }
    setSaving(true);
    const ok = await p.onAddBalanceAdjustment(adjFor.refId, {
      id: `adj-${Date.now()}`, at: new Date().toISOString(), by: p.currentUserName || '—',
      kind: adjFor.kind, kg: v, reason: adjFor.reason.trim() || undefined,
    });
    setSaving(false);
    if (ok !== false) setAdjFor(null);
  };

  const shownAlerts = stageAlerts.filter(a => levelFilter === 'ALL' || a.level === levelFilter);
  const allowed: Record<string, TabKey[]> = { ON_SOGUTMA: ['ALERTS', 'LOTS', 'ORCHARDS'], SOGUK_DEPO: ['ALERTS', 'ROOMS', 'LOSS'], SEVK: ['ALERTS', 'DEST'] };
  const showStore = p.stage !== 'ON_SOGUTMA';
  const tabAllowed = (k: TabKey) => !p.stage || allowed[p.stage]?.includes(k);
  const input = 'w-full min-h-[40px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100';
  const th = 'px-2 py-1.5 text-left font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap';
  const td = 'px-2 py-1.5 whitespace-nowrap tabular-nums';

  return (
    <section className="space-y-3">
      <Tabs<TabKey>
        ariaLabel="Soğuk zincir"
        value={tab}
        onChange={setTab}
        items={([
          { key: 'ALERTS', label: 'Uyarılar', count: stageAlerts.length },
          { key: 'LOTS', label: p.stage === 'ON_SOGUTMA' ? 'Sahadaki partiler' : 'Parti akışı', count: activeLots.length },
          { key: 'ROOMS', label: 'Odalar' },
          { key: 'ORCHARDS', label: 'Bahçeler' },
          { key: 'DEST', label: 'Varış' },
          { key: 'LOSS', label: 'Fire' },
        ] as { key: TabKey; label: string; count?: number }[]).filter(t => tabAllowed(t.key))}
      />

      {tab === 'ALERTS' && (
        <Segmented<'ALL' | ColdChainAlert['level']>
          ariaLabel="Uyarı düzeyi"
          value={levelFilter}
          onChange={setLevelFilter}
          items={[
            { key: 'ALL', label: 'Tümü', count: stageAlerts.length },
            { key: 'critical', label: 'Acil', count: counts.critical },
            { key: 'warning', label: 'Bugün', count: counts.warning },
            { key: 'info', label: 'Bilgi', count: counts.info },
          ]}
        />
      )}

      {tab === 'ALERTS' && (
        <div className="space-y-3">
          {shownAlerts.length === 0 && <p className="text-sm text-slate-500 py-4 text-center">Soğuk zincirde açık uyarı yok.</p>}
          {([
            ['critical', 'Şimdi bakılmalı'],
            ['warning', 'Bugün içinde'],
            ['info', 'Bilgi'],
          ] as const).map(([lvl, heading]) => {
            const list = shownAlerts.filter(a => a.level === lvl).slice(0, 40);
            if (!list.length) return null;
            return (
              <div key={lvl} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white pt-1 pb-1">{heading} <span className="text-slate-400 font-semibold">{list.length}</span></h3>
                {list.map(a => {
                  const lot = lotMap.get(a.refId);
                  const isBalance = a.kind === 'OPEN_BALANCE' || a.kind === 'OVER_BALANCE';
                  const isPrecool = a.kind === 'PRECOOL_DURATION' || a.kind === 'TARGET_ROOM_MISSING' || a.kind === 'MCP_UNDECIDED' || a.kind === 'MCP_DEADLINE';
                  return (
                    <ListRow key={a.id} dot={lvl === 'critical' ? 'error' : lvl === 'warning' ? 'warn' : 'info'}
                      title={a.title}
                      sub={<>
                        <button type="button" className="font-semibold text-teal-800 dark:text-teal-300 hover:underline" onClick={() => p.onOpenRecord?.(a.refId)}>{a.refId}</button>
                        {a.product ? ` · ${a.product}` : ''}{a.location ? ` · ${a.location}` : ''}
                        <span className="block">{a.detail}</span>
                      </>}
                      right={!p.stage ? <Badge tone={lvl === 'critical' ? 'error' : lvl === 'warning' ? 'warn' : 'info'}>{STAGE_BY_KEY[ALERT_STAGE[a.kind]].short}</Badge> : undefined}>
                      {a.actions.length > 0 && <ul className="mt-1 ml-5 text-[11px] text-slate-600 dark:text-slate-300 list-disc pl-4">{a.actions.map(x => <li key={x}>{x}</li>)}</ul>}
                      {!p.isReadOnly && (isBalance || isPrecool) && (
                        <div className="flex flex-wrap gap-1.5 mt-2 ml-5">
                          {isBalance && p.onAddBalanceAdjustment && <Button size="sm" variant="soft" tone="slate" icon={<Scale />} onClick={() => startAdj(a)}>Bakiyeyi kapat</Button>}
                          {(isPrecool || a.kind === 'OPEN_BALANCE') && p.onOpenPrecooling && lot && <Button size="sm" variant="soft" tone="sky" icon={<Snowflake />} onClick={() => p.onOpenPrecooling!(lot.ref)}>Ön soğutma fişi</Button>}
                        </div>
                      )}
                      {adjFor?.refId === a.refId && isBalance && (
                        <div className="mt-2 ml-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 space-y-2">
                          <select aria-label="İşlem" className={input} value={adjFor.kind} onChange={e => setAdjFor({ ...adjFor, kind: e.target.value as BalanceAdjustment['kind'] })}>
                            {(Object.keys(ADJ_LABEL) as BalanceAdjustment['kind'][]).map(k => <option key={k} value={k}>{ADJ_LABEL[k]}</option>)}
                          </select>
                          <div className="grid grid-cols-2 gap-2">
                            <input aria-label="kg" inputMode="decimal" className={input} placeholder="kg" value={adjFor.kg} onChange={e => setAdjFor({ ...adjFor, kg: e.target.value })} />
                            <input aria-label="Neden" className={input} placeholder="Neden / not" value={adjFor.reason} onChange={e => setAdjFor({ ...adjFor, reason: e.target.value })} />
                          </div>
                          <p className="text-[11px] text-slate-500">RefID değişmez. Kayıt partinin geçmişine eklenir; fire raporunda görünür.</p>
                          {err && <p className="text-xs text-rose-700" role="alert">{err}</p>}
                          <div className="flex justify-end gap-2">
                            <Button size="sm" variant="soft" tone="slate" onClick={() => setAdjFor(null)} disabled={saving}>Vazgeç</Button>
                            <Button size="sm" variant="primary" loading={saving} onClick={saveAdj}>Kaydet</Button>
                          </div>
                        </div>
                      )}
                    </ListRow>
                  );
                })}
              </div>
            );
          })}
        </div>
      )}

      {tab === 'LOTS' && (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2">
          <table className="min-w-full text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60"><tr>
              <th className={th}>RefID</th><th className={th}>Ürün · Bahçe</th><th className={th}>Hasat kg</th><th className={th}>Ön soğ. kg</th>
              <th className={th}>Açık bakiye</th><th className={th}>Iskarta %</th>{showStore && <><th className={th}>Depo kg</th><th className={th}>Çıkış</th><th className={th}>Kalan</th></>}
              <th className={th}>Hasat→ÖS</th><th className={th}>ÖS süresi</th><th className={th}>1-MCP</th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeLots.slice(0, 100).map((l: LotFlow) => (
                <tr key={l.ref.refId}>
                  <td className={td}><button type="button" className="font-ref font-semibold text-teal-800 dark:text-teal-300" onClick={() => p.onOpenRecord?.(l.ref.refId)}>{l.ref.refId}</button></td>
                  <td className="px-2 py-1.5 max-w-[160px] truncate">{l.ref.product}{l.ref.orchard ? ` · ${l.ref.orchard}` : ''}</td>
                  <td className={td}>{kg(l.harvestKg)}</td>
                  <td className={td}>{l.precooledKg ? kg(l.precooledKg) : '—'}</td>
                  <td className={`${td} font-semibold ${l.openBalanceKg > 0 ? 'text-amber-700' : l.openBalanceKg < 0 ? 'text-rose-700' : ''}`}>{l.openBalanceKg ? kg(l.openBalanceKg) : '—'}</td>
                  <td className={td}>{l.lossPct.sortingCull ?? '—'}</td>
                  {showStore && <>
                    <td className={td}>{l.storedKg ? kg(l.storedKg) : '—'}</td>
                    <td className={td}>{l.outKg ? kg(l.outKg) : '—'}</td>
                    <td className={td}>{kg(l.remainingKg)}</td>
                  </>}
                  <td className={td}>{l.harvestToPrecoolH !== null ? `${Math.round(l.harvestToPrecoolH)} sa` : '—'}</td>
                  <td className={td}>{l.precoolH !== null ? `${Math.round(l.precoolH)} sa${l.precoolOpen ? ' ⏳' : ''}` : '—'}</td>
                  <td className={td}>{!l.mcp.required ? '—' : l.mcp.appliedAt ? 'Uygulandı' : l.mcp.decision === 'NO' ? 'Hayır' : l.mcp.decision === 'YES' ? `Evet · ${l.mcp.daysLeft ?? '—'} gün` : `Karar yok · ${l.mcp.daysLeft ?? '—'} gün`}</td>
                </tr>
              ))}
              {activeLots.length === 0 && <tr><td colSpan={showStore ? 12 : 9} className="text-center text-slate-500 py-4">Aktif parti yok.</td></tr>}
            </tbody>
          </table>
          <p className="text-[11px] text-slate-500 mt-2">Açık bakiye = hasat − ön soğutma − doğrudan depo − fire. Artı: sahada bekleyen; eksi: hasat eksik yazılmış.</p>
        </div>
      )}

      {tab === 'ROOMS' && (
        <SimpleTable
          head={['Depo', 'Oda', 'Parti', 'kg', 'Ort. gün', 'Geciken kontrol']}
          rows={summary.byRoom.map(r => [r.warehouse, r.room, r.lots, kg(r.kg), r.avgDays, r.overdueChecks || '—'])}
          empty="Depoda aktif parti yok."
        />
      )}
      {tab === 'ORCHARDS' && (
        <SimpleTable
          head={['Bahçe', 'Parti', 'Hasat kg', 'Ort. hasat→ÖS (sa)', 'Açık bakiye kg', 'Iskarta %']}
          rows={summary.byOrchard.map(o => [o.orchard, o.lots, kg(o.harvestKg), o.avgHarvestToPrecoolH ?? '—', o.openBalanceKg ? kg(o.openBalanceKg) : '—', o.cullPct ?? '—'])}
          empty="Bahçe verisi yok."
        />
      )}
      {tab === 'DEST' && (
        <SimpleTable
          head={['Varış / alıcı', 'Sevk', 'kg']}
          rows={summary.byDestination.map(d => [d.destination, d.shipments, kg(d.kg)])}
          empty="Sevk / satış yok."
        />
      )}
      {tab === 'LOSS' && (
        <SimpleTable
          head={['Ürün', 'Hasat kg', 'Fire kg', 'Fire %', 'Ön soğ. kg', 'Iskarta kg', 'Iskarta %', 'Beklenen ıskarta %']}
          rows={summary.byProductLoss.map(x => [x.product, kg(x.harvestKg), x.lossKg ? kg(x.lossKg) : '—', x.lossPct ?? '—', x.precooledKg ? kg(x.precooledKg) : '—', x.culledKg ? kg(x.culledKg) : '—', x.cullPct ?? '—', x.expectedCullPct ?? '—'])}
          empty="Fire hesaplamak için ön soğutma fişinde ıskarta kg veya fire kaydı gerekir."
        />
      )}
    </section>
  );
}

function SimpleTable({ head, rows, empty }: { head: string[]; rows: (string | number)[][]; empty: string }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2">
      <table className="min-w-full text-xs">
        <thead className="bg-slate-50 dark:bg-slate-800/60"><tr>{head.map(h => <th key={h} className="px-2 py-1.5 text-left font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} className="px-2 py-1.5 whitespace-nowrap tabular-nums">{c}</td>)}</tr>)}
          {rows.length === 0 && <tr><td colSpan={head.length} className="text-center text-slate-500 py-4">{empty}</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
