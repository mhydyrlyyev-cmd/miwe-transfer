import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './index.css';
import { installKeyboardAvoidance } from './utils/keyboardAvoidance';

installKeyboardAvoidance();
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import { LanguageProvider } from './context/LanguageContext';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { initGlobalErrorLogging } from './utils/debugLogger';

// Initialize global runtime error monitoring
initGlobalErrorLogging();

import { registerSW } from 'virtual:pwa-register';

// Register Service Worker with safe prompt-based update flow (never auto-reloads while typing forms)
export let updateSW: (reloadPage?: boolean) => Promise<void> = async () => {};

if ('serviceWorker' in navigator) {
  if (import.meta.env.DEV) {
    // Development mode: unregister any stale service workers to prevent cached chunk conflicts
    navigator.serviceWorker.getRegistrations().then((registrations) => {
      for (const registration of registrations) {
        registration.unregister();
      }
    });
    if ('caches' in window) {
      caches.keys().then((names) => {
        for (const name of names) {
          caches.delete(name);
        }
      });
    }
  } else {
    // Production PWA registration
    updateSW = registerSW({
      // Yayından sonra yeni sürüm, uygulama açıkken de 30 dakikada bir kontrol edilir
      onRegisteredSW(_swUrl, registration) {
        if (registration) {
          setInterval(() => { registration.update().catch(() => {}); }, 30 * 60 * 1000);
        }
      },
      onNeedRefresh() {
        window.dispatchEvent(new CustomEvent('sw-update-available', { detail: { updateSW } }));
      },
      onOfflineReady() {
        console.info('[PWA] Uygulama çevrimdışı çalışmaya hazır.');
      }
    });
  }
}


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <ThemeProvider>
        <LanguageProvider>
          <ToastProvider>
            <App />
          </ToastProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  </StrictMode>,
);
