import React, { useState, useMemo } from 'react';
import { MapPin, BarChart3, ChevronDown, ChevronUp, Layers, AlertTriangle, ShieldAlert, LayoutGrid } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { ActiveFieldContext, ReferenceItem, AmbarRecord, FieldRecord } from '../../types';
import { QualityInsightCard } from '../dashboard/QualityInsightCard';

interface GlobalPlatformFooterProps {
  activeFieldContext: ActiveFieldContext | null;
  onSelectFieldContext: (ctx: ActiveFieldContext | null) => void;
  references: ReferenceItem[];
  ambarRecords: AmbarRecord[];
  fieldRecords?: FieldRecord[];
  onOpenSystemView: (view: 'HARVEST_PORTAL' | 'QUALITY_ROADMAP' | 'ANALYTICS' | 'REFERENCES' | any) => void;
  currentView?: string;
  onSearchRef?: (refId: string) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onOpenTraceability?: (ref: ReferenceItem) => void;
  onOpenFieldTest?: (refId: string) => void;
}

export const GlobalPlatformFooter: React.FC<GlobalPlatformFooterProps> = ({
  activeFieldContext,
  onSelectFieldContext,
  references = [],
  ambarRecords = [],
  fieldRecords = [],
  onOpenSystemView,
  currentView,
  onSearchRef,
  onRerouteToFreezeDry,
  onOpenTraceability,
  onOpenFieldTest
}) => {
  const [showStockChart, setShowStockChart] = useState<boolean>(true);

  // Compute stock quantities (kg) by product
  const stockChartData = useMemo(() => {
    const productMap = new Map<string, { product: string; stockKg: number; batchCount: number }>();

    // 1. Process from Ambar records if available
    if (ambarRecords && ambarRecords.length > 0) {
      ambarRecords.forEach((amb) => {
        const ref = references?.find(r => r.refId === amb.refId);
        const prod = (ref?.product || amb.notes?.split(' ')?.[0] || 'Genel Meyve').replace(/\s*\(\s*\)\s*$/, '').trim(); // v3.9: boş "()" temizlenir
        const weight = Number(amb.acceptedWeightKg) || 0;
        
        const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
        existing.stockKg += weight;
        existing.batchCount += 1;
        productMap.set(prod, existing);
      });
    }

    // 2. Supplement from references where status is RECEIVED or CREATED
    if (references && references.length > 0) {
      references.forEach((ref) => {
        const prod = (ref.product || 'Diğer').replace(/\s*\(\s*\)\s*$/, '').trim();
        let kg = Number(ref.quantity) || 0;
        const u = (ref.unit || '').toLowerCase();
        if (u.includes('ton')) kg *= 1000;
        if (u.includes('kasa') || u.includes('box')) kg *= 15; // standard avg 15kg/crate
        
        if (!ambarRecords || ambarRecords.length === 0 || !ambarRecords.some(a => a.refId === ref.refId)) {
          const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
          existing.stockKg += kg;
          existing.batchCount += 1;
          productMap.set(prod, existing);
        }
      });
    }

    // Return empty array if no real warehouse stock records exist
    if (productMap.size === 0) {
      return [];
    }

    const palette = ['#10b981', '#0d9488', '#0284c7', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6', '#14b8a6'];

    return Array.from(productMap.values())
      .filter(item => item.stockKg > 0)
      .sort((a, b) => b.stockKg - a.stockKg)
      .slice(0, 8)
      .map((item, idx) => ({
        ...item,
        fill: palette[idx % palette.length]
      }));
  }, [references, ambarRecords]);

  const totalStockKg = useMemo(() => {
    return stockChartData.reduce((acc, curr) => acc + curr.stockKg, 0);
  }, [stockChartData]);
  return (
    <div className="w-full space-y-5 pt-6 pb-4 border-t border-slate-200 dark:border-slate-800">
      
      {/* ------------------------------------------------------------------------- */}
      {/* MEVCUT ÜRÜN STOK DAĞILIMI & KALİTE ÖNGÖRÜ RİSK RADARI                     */}
      {/* ------------------------------------------------------------------------- */}
      <div className="space-y-4">

        {/* MEVCUT ÜRÜN STOK DAĞILIMI (KG) & RECHARTS GRAFİK */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/70 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800">
                <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100">
                    Mevcut Ürün Stok Dağılımı (kg)
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 font-mono">
                    {(totalStockKg / 1000).toFixed(1)} Ton Toplam
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Ambar kabulü yapılmış ve depolardaki aktif ürün partilerinin kilogram bazlı anlık stok hacmi
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowStockChart(!showStockChart)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-slate-950 dark:hover:text-white bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl transition cursor-pointer"
            >
              <span>{showStockChart ? 'Grafiği Gizle' : 'Grafiği Göster'}</span>
              {showStockChart ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {showStockChart && (
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              {stockChartData.length === 0 ? (
                <div className="py-6 px-4 text-center bg-slate-50 dark:bg-slate-800 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    ⏳ Sıfır Veri / Veri Bekleniyor (Cold-Start Modu)
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    İlk gerçek Ambar Kabul veya Hasat partisi girildiğinde ürün bazlı stok grafiği otomatik hesaplanacaktır.
                  </p>
                </div>
              ) : (
                <>
                  <div className="w-full h-44 sm:h-52 min-w-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stockChartData} margin={{ top: 10, right: 10, left: -15, bottom: 25 }}>
                        <XAxis
                          dataKey="product"
                          tick={{ fontSize: 10, fill: '#64748b' }}
                          interval={0}
                          angle={-15}
                          textAnchor="end"
                          tickLine={false}
                        />
                        <YAxis
                          tick={{ fontSize: 10, fill: '#64748b' }}
                          tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
                          tickLine={false}
                          axisLine={false}
                        />
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-xl border border-slate-700">
                                  <p className="font-bold text-teal-300">{data.product}</p>
                                  <p className="text-slate-200 mt-1 flex items-center gap-2">
                                    <span>Stok Miktarı:</span>
                                    <strong className="font-mono text-emerald-400">
                                      {data.stockKg.toLocaleString()} kg
                                    </strong>
                                  </p>
                                  <p className="text-[10px] text-slate-400 mt-0.5">
                                    Hacim: {(data.stockKg / 1000).toFixed(2)} Ton • {data.batchCount} Parti
                                  </p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar
                          dataKey="stockKg"
                          radius={[6, 6, 0, 0]}
                          maxBarSize={45}
                        >
                          {stockChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill || '#10b981'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Quick summary product badges */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-1 mt-2 text-xs">
                    {stockChartData.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 dark:bg-slate-800 rounded-lg shrink-0 border border-slate-200 dark:border-slate-700"
                      >
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.fill }} />
                        <span className="font-medium text-slate-700 dark:text-slate-300">{item.product}:</span>
                        <strong className="font-mono text-slate-900 dark:text-white">{item.stockKg.toLocaleString()} kg</strong>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------------------- */}
      {/* KALİTE ÖNGÖRÜ RİSK RADARI & RAF ÖMRÜ MATRİSİ                              */}
      {/* ------------------------------------------------------------------------- */}
      <div className="w-full">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">Kalite riskleri ve raf ömrü</h2>
        </div>
        <QualityInsightCard
          fieldRecords={fieldRecords}
          references={references}
          onSelectReference={onSearchRef}
          onRerouteToFreezeDry={onRerouteToFreezeDry}
          onOpenTraceability={onOpenTraceability}
          onOpenFieldTest={onOpenFieldTest}
          isCompact={true}
          defaultExpanded={false}
          onNavigateToAnalytics={() => onOpenSystemView('ANALYTICS')}
          onNavigateToRecords={() => onOpenSystemView('REFERENCES')}
        />
      </div>

    </div>
  );
};

