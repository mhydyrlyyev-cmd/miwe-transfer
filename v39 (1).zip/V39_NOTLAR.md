# v39 — v38 üzerine yama (giriş ekranı + ana menü + ana panel temizliği)

Proje köküne aynı yollarla kopyalayın. Firestore kuralı DEĞİŞMEDİ.

1. Giriş ekranı (LoginView): açık tasarım. Solda/üstte koyu yeşil marka paneli: logo + 4 aşama simgesi
   (açıklama ve şirket adı yok). Form mantığı (personel, yönetici, kayıt, parola sıfırlama, Google) aynen.
2. Ana menü (yeni HomeMenu, eski "Portal Komut Merkezi" yerine): selam, arama, 4 aşama kartı (parti sayısı,
   uyarı rozeti), Ana panel ve Uyarılar, Hızlı kayıt, Diğer modüller (Muz, Badem, Freeze-dry, Satış, İhracat),
   Raporlar ve kayıtlar, Yardım ve yönetim. Eski PortalLauncher dosyası silinmedi, kullanılmıyor.
3. Ana panel: üstteki büyük "Ana Portallara Dön" şeridi → ince "← Ana menü" bağlantısı.
   "Stokları ve kayıtları sıfırla" ana ekrandan kaldırıldı → panelin altında kapalı "Yönetici araçları".
4. Sayfa altı: "Portallar menüsünü aç" bandı kaldırıldı; kalite radarı başlığı sadeleşti.
5. Boş çeşit etiketi: "Meyve / Genel Ürün ()" → "Meyve / Genel Ürün" (grafikte ve yeni kayıtlarda).
