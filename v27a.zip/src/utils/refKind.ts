import type { ReferenceItem } from '../types';

/**
 * v2.7 — Test kaydı mı? (stok, sevkiyat, lojistik, depo kabul ve satış listelerine girmez)
 * - refKind açıkça verilmişse o geçerlidir.
 * - Eski kayıtlarda (refKind yok): Meyve Kalite Testi ve İhracat Numunesi her zaman test;
 *   Muz ve Badem kayıtları miktar (kg) yoksa test sayılır.
 */
export function isTestReference(ref: Partial<ReferenceItem> | null | undefined): boolean {
  if (!ref) return false;
  if (ref.refKind === 'TEST') return true;
  if (ref.refKind === 'LOT') return false;
  const m = String(ref.moduleKey || '');
  if (m === 'FIELD' || m === 'EXPORT_SAMPLE') return true;
  if ((m === 'MUZ' || m === 'BADEM') && !((ref.quantity ?? 0) > 0)) return true;
  return false;
}

/** Stok/sevkiyat hesaplarına girecek gerçek partiler */
export function lotReferencesOnly<T extends Partial<ReferenceItem>>(refs: T[]): T[] {
  return refs.filter(r => !isTestReference(r));
}
