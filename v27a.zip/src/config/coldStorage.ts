/**
 * v2.7 — Soğuk depo oda kapasiteleri (palet). İsteğe bağlı.
 * Anahtar: "<Depo adı>__<Oda adı>" (kayıtlarda yazıldığı gibi). Boş bırakılan odada
 * doluluk yüzdesi gösterilmez, yalnızca içerik listelenir.
 * Örnek: 'Datly Miwe (1000T Soğuk Depo & Ambalaj Tesisleri)__Oda 1 (Sowuk Depo - 1.0°C)': 120
 */
export const ROOM_CAPACITY_PALLETS: Record<string, number> = {};

export function roomCapacity(warehouse: string, room: string): number | null {
  const v = ROOM_CAPACITY_PALLETS[`${warehouse}__${room}`];
  return typeof v === 'number' && v > 0 ? v : null;
}
