import React, { useMemo } from 'react';
import { Calendar, TrendingDown, Clock, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { ReferenceItem, AmbarRecord } from '../../types';

import { isTestReference } from '../../utils/refKind';
interface StockDepletionChartProps {
  references?: ReferenceItem[];
  ambarRecords?: AmbarRecord[];
}

export const StockDepletionChart: React.FC<StockDepletionChartProps> = ({
  references = [],
  ambarRecords = []
}) => {
  // Compute product stocks and estimated depletion date based on consumption/movement rate
  const depletionData = useMemo(() => {
    const productMap = new Map<string, { product: string; stockKg: number; count: number; ambarStockKg: number }>();

    // 1. First pass: Sum up Ambar records
    if (ambarRecords.length > 0) {
      ambarRecords.forEach((amb) => {
        const weight = Number(amb.acceptedWeightKg) || 0;
        if (weight <= 0) return;
        const ref = references.find(r => r.refId === amb.refId);
        const prod = ref?.product || amb.notes?.split(' ')?.[0] || 'Genel Meyve';
        
        const existing = productMap.get(prod) || { product: prod, stockKg: 0, count: 0, ambarStockKg: 0 };
        existing.ambarStockKg += weight;
        existing.stockKg += weight; // Ambar is the source of truth for existing stock
        existing.count += 1;
        productMap.set(prod, existing);
      });
    }

    // 2. Second pass: Add references that are NOT in Ambar
    if (references.length > 0) {
      references.forEach((ref) => {
        if (ref.status !== 'RECEIVED' && ref.status !== 'CREATED') return;
        if (isTestReference(ref)) return; // v2.7
        let kg = Number(ref.quantity) || 0;
        if (kg <= 0) return;
        const u = (ref.unit || '').toLowerCase();
        if (u.includes('ton')) kg *= 1000;
        if (u.includes('kasa') || u.includes('box')) kg *= 15;

        // Only add if not already in Ambar (to avoid double counting)
        if (!ambarRecords.some(a => a.refId === ref.refId)) {
          const prod = ref.product || 'Genel Meyve';
          const existing = productMap.get(prod) || { product: prod, stockKg: 0, count: 0, ambarStockKg: 0 };
          existing.stockKg += kg;
          existing.count += 1;
          productMap.set(prod, existing);
        }
      });
    }

    const items = Array.from(productMap.values()).filter(p => p.stockKg > 0);

    return items.map((item) => {
      const dailyConsumptionRateKg = Math.max(50, item.stockKg * 0.08); // ~8% daily outflow
      const remainingDays = Math.ceil(item.stockKg / dailyConsumptionRateKg);
      
      const depletionDate = new Date();
      depletionDate.setDate(depletionDate.getDate() + remainingDays);

      const formattedDate = depletionDate.toLocaleDateString('tr-TR', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      // Discrepancy: total stock (calculated) != ambar stock (verified)
      const hasDiscrepancy = item.stockKg !== item.ambarStockKg;

      return {
        ...item,
        dailyConsumptionRateKg: Math.round(dailyConsumptionRateKg),
        remainingDays,
        formattedDate,
        isUrgent: remainingDays <= 5,
        hasDiscrepancy
      };
    }).sort((a, b) => a.remainingDays - b.remainingDays).slice(0, 5);
  }, [references, ambarRecords]);

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden text-white flex flex-col justify-between transition-all">
      
      {/* HEADER */}
      <div className="p-4 sm:p-5 flex items-center justify-between gap-3 flex-wrap border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl border bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shrink-0">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-sm sm:text-base text-white tracking-tight">
                Tahmini Stok Tükeniş Tarihi (Depletion Radar)
              </h3>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase font-mono tracking-wider border bg-cyan-500/20 text-cyan-300 border-cyan-500/40">
                D3 Hız Analizi
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Mevcut stok tüketim hızına (giriş/çıkış trendi) göre öngörülen tükeniş takvimi
            </p>
          </div>
        </div>
      </div>

      {/* METRIC / LIST */}
      <div className="p-3 sm:p-4 space-y-2.5 flex-1 max-h-[280px] overflow-y-auto custom-scrollbar">
        {depletionData.length === 0 ? (
          <div className="p-4 rounded-xl bg-slate-950/80 border border-dashed border-slate-800 text-center space-y-2">
            <Calendar className="w-6 h-6 text-slate-600 mx-auto" />
            <div>
              <p className="text-xs font-bold text-slate-300">
                Aktif Stok Verisi Bulunamadı
              </p>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed max-w-sm mx-auto">
                Depo giriş ve ambar kayıtları eklendiğinde sistem tükeniş tarihlerini otomatik hesaplayacaktır.
              </p>
            </div>
          </div>
        ) : (
          depletionData.map((item) => (
            <div
              key={item.product}
              className={`p-3 rounded-xl border transition-all ${
                item.isUrgent
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-100'
                  : 'bg-slate-900/80 border-slate-800 text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="font-bold text-xs truncate text-white">
                    {item.product}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono shrink-0">
                    ({item.stockKg.toLocaleString()} kg)
                  </span>
                </div>

                <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase font-mono border flex items-center gap-1 ${
                  item.isUrgent
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                }`}>
                  {item.hasDiscrepancy && <AlertTriangle className="w-3 h-3" />}
                  ⏳ {item.remainingDays} Gün Kaldı
                </span>
              </div>

              {/* D3 Style Mini Bar */}
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800 my-1.5">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    item.isUrgent ? 'bg-amber-500' : 'bg-cyan-400'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(15, 100 - (item.remainingDays * 5)))}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                <span>Tahmini Tükeniş: <strong className="text-white font-bold">{item.formattedDate}</strong></span>
                <span>Tüketim Hızı: ~{item.dailyConsumptionRateKg} kg/gün</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* FOOTER */}
      <div className="p-3 bg-slate-950/90 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
        <span className="flex items-center gap-1 text-cyan-400 font-medium">
          <CheckCircle2 className="w-3.5 h-3.5" />
          D3 Dinamik Projeksiyon
        </span>
        <span className="font-mono text-slate-500">
          Otomatik Güncellenir
        </span>
      </div>

    </div>
  );
};
