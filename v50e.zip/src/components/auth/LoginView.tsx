import React, { useState, useEffect } from 'react';
import { BrandLogo } from '../common/BrandLogo';
import { Snowflake, Warehouse, Truck,
  ShieldCheck,
  Leaf,
  Lock,
  Mail,
  Phone,
  User,
  Building,
  Briefcase,
  LogIn,
  UserPlus,
  AlertCircle,
  CheckCircle2,
  KeyRound,
  ArrowRight,
  Eye,
  EyeOff,
  RotateCcw,
  Check,
  Clock,
  Wifi,
  WifiOff,
  ChevronLeft
} from 'lucide-react';
import { AppUser, KNOWN_COMPANIES, KNOWN_JOB_TITLES } from '../../types/auth';
import {
  loginUser,
  loginWithGoogle,
  completeGoogleRedirect,
  isInIframe,
  loginAdmin,
  registerUser,
  requestPasswordReset,
  resetPasswordWithCode,
  syncWithServer
} from '../../utils/authService';
import { evaluatePasswordStrength } from '../../utils/security';

interface LoginViewProps {
  onLoginSuccess: (user: AppUser) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  // Portal mode: General Personnel Portal vs Isolated Admin Portal
  const [isAdminPortalMode, setIsAdminPortalMode] = useState(false);

  // Tab for General Personnel
  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER' | 'FORGOT_PASSWORD'>('LOGIN');

  // Network status
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial server sync
    syncWithServer().catch(() => {});

    // v45: yönlendirmeli Google girişinden dönüldüyse sonucu tamamla
    completeGoogleRedirect().then(res => {
      if (!res) return;
      if (res.success && res.user) { onLoginSuccess(res.user); return; }
      if (res.status === 'PENDING') setLoginStatusNotice('⏳ Google hesabınızla başvurunuz alındı. Sistem Yöneticisi onayladıktan sonra giriş yapabilirsiniz.');
      else { setLoginError(res.message); setOfferNewTab(!!res.openInNewTab); }
    }).catch(() => {});

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Password visibility states
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegPasswordConfirm, setShowRegPasswordConfirm] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [showResetPasswordConfirm, setShowResetPasswordConfirm] = useState(false);

  // General Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [offerNewTab, setOfferNewTab] = useState<boolean>(false);
  const [loginStatusNotice, setLoginStatusNotice] = useState<string | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);

  // Admin Login form state
  const [adminIdentifier, setAdminIdentifier] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState<string | null>(null);
  const [isAdminLoggingIn, setIsAdminLoggingIn] = useState(false);

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPasswordConfirm, setRegPasswordConfirm] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regCompany, setRegCompany] = useState<string>(KNOWN_COMPANIES[0]);
  const [regCustomCompany, setRegCustomCompany] = useState('');
  const [regJobTitle, setRegJobTitle] = useState<string>(KNOWN_JOB_TITLES[1]);
  const [regCustomJobTitle, setRegCustomJobTitle] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccessMessage, setRegSuccessMessage] = useState<string | null>(null);

  // Password Reset form state
  const [resetStep, setResetStep] = useState<'REQUEST' | 'VERIFY_AND_SET'>('REQUEST');
  const [resetEmail, setResetEmail] = useState('');
  const [resetVerificationCode, setResetVerificationCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetNewPasswordConfirm, setResetNewPasswordConfirm] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);
  const [verificationCodeDelivery, setVerificationCodeDelivery] = useState<string | null>(null);

  // Password strength calculations
  const regPasswordStrength = evaluatePasswordStrength(regPassword);
  const resetPasswordStrength = evaluatePasswordStrength(resetNewPassword);

  // Handle General Login
  const handleGoogleLogin = async () => {
    setLoginError(null);
    setLoginStatusNotice(null);
    setIsCheckingStatus(true);
    try {
      setOfferNewTab(false);
      const res = await loginWithGoogle();
      if (!res.success) {
        if (res.redirecting) return;
        if (res.openInNewTab) setOfferNewTab(true);
        if (res.status === 'PENDING') {
          setLoginStatusNotice('⏳ Google hesabınızla başvurunuz alındı. Sistem Yöneticisi onayladıktan sonra giriş yapabilirsiniz.');
        } else {
          setLoginError(res.message);
        }
        return;
      }
      if (res.user) onLoginSuccess(res.user);
    } finally {
      setIsCheckingStatus(false);
    }
  };

  const handleGeneralLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError(null);
    setLoginStatusNotice(null);

    if (!loginIdentifier.trim() || !loginPassword.trim()) {
      setLoginError('Lütfen e-posta ve parolanızı girin.');
      return;
    }

    setIsCheckingStatus(true);
    try {
      const res = await loginUser(loginIdentifier, loginPassword);
      if (!res.success) {
        if (res.status === 'PENDING') {
          setLoginStatusNotice(
            '⏳ Hesabınız sistemde kayıtlı ancak henüz Sistem Yöneticisi (Admin) tarafından onaylanmadı. Admin onayından sonra yetkilendirilen modüllerle giriş yapabileceksiniz.'
          );
        } else if (res.status === 'REJECTED' || res.status === 'DEACTIVATED') {
          setLoginError('⛔ Bu hesap yönetici tarafından askıya alınmış veya deaktife edilmiştir.');
        } else {
          setLoginError(res.message);
        }
        return;
      }

      if (res.user) {
        onLoginSuccess(res.user);
      }
    } finally {
      setIsCheckingStatus(false);
    }
  };

  // Handle Admin Portal Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);

    if (!adminIdentifier.trim() || !adminPassword.trim()) {
      setAdminError('Lütfen yönetici e-posta / kimliğini ve parolanızı girin.');
      return;
    }

    setIsAdminLoggingIn(true);
    try {
      const res = await loginAdmin(adminIdentifier, adminPassword);
      if (!res.success) {
        setAdminError(res.message);
        return;
      }

      if (res.user) {
        onLoginSuccess(res.user);
      }
    } finally {
      setIsAdminLoggingIn(false);
    }
  };

  // Handle Register (New User)
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccessMessage(null);

    if (!regFullName.trim()) {
      setRegError('Lütfen ad ve soyadınızı girin.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setRegError('Lütfen geçerli bir e-posta adresi girin.');
      return;
    }
    if (!regPhone.trim()) {
      setRegError('Lütfen telefon numaranızı girin.');
      return;
    }
    if (!regPassword.trim() || regPassword.length < 8) {
      setRegError('Parola en az 8 karakter olmalıdır.');
      return;
    }
    if (regPassword !== regPasswordConfirm) {
      setRegError('Girdiğiniz parolalar birbiriyle uyuşmuyor.');
      return;
    }

    const companyFinal = regCompany === 'OTHER' ? regCustomCompany.trim() : regCompany;
    if (!companyFinal) {
      setRegError('Lütfen görev yaptığınız firmayı belirtin.');
      return;
    }

    const jobTitleFinal = regJobTitle === 'OTHER' ? regCustomJobTitle.trim() : regJobTitle;
    if (!jobTitleFinal) {
      setRegError('Lütfen unvan / görevinizi belirtin.');
      return;
    }

    const res = await registerUser({
      fullName: regFullName,
      password: regPassword,
      phone: regPhone,
      email: regEmail,
      company: companyFinal,
      jobTitle: jobTitleFinal
    });

    if (!res.success) {
      setRegError(res.message);
      return;
    }

    setRegSuccessMessage(res.message);
    setTimeout(() => {
      setLoginIdentifier(regEmail);
      setLoginPassword('');
      setActiveTab('LOGIN');
      setLoginStatusNotice(
        '✅ Kayıt başvurunuz başarıyla alındı! Ziyaretçi (Salt Okunur / PASIF_READER) olarak anında giriş yapabilir, tüm verileri ve raporları görüntüleyebilirsiniz. Veri girişi ve düzenleme yetkisi için Sistem Yöneticinizden yetkilendirme talep edebilirsiniz.'
      );
    }, 2000);
  };

  // Handle Request Reset Code
  const handleRequestResetCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccessMessage(null);

    const cleanEmail = resetEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setResetError('Lütfen geçerli bir kayıtlı e-posta adresi girin.');
      return;
    }

    const res = await requestPasswordReset(cleanEmail);
    if (!res.success) {
      setResetError(res.message);
      return;
    }

    // Firebase: sıfırlama e-postadaki bağlantıyla tamamlanır; kod adımına geçilmez
    setResetVerificationCode('');
    setResetSuccessMessage(res.message);
  };

  // Handle Verify Code & Set New Password
  const handleVerifyAndSetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccessMessage(null);

    if (!resetVerificationCode.trim() || resetVerificationCode.trim().length !== 6) {
      setResetError('Lütfen 6 haneli doğrulama kodunu eksiksiz girin.');
      return;
    }

    if (!resetNewPassword.trim() || resetNewPassword.length < 3) {
      setResetError('Yeni parola en az 3 karakter olmalıdır.');
      return;
    }

    if (resetNewPassword !== resetNewPasswordConfirm) {
      setResetError('Girdiğiniz yeni parolalar birbiriyle uyuşmuyor.');
      return;
    }

    const res = await resetPasswordWithCode(resetEmail, resetVerificationCode, resetNewPassword);
    if (!res.success) {
      setResetError(res.message);
      return;
    }

    setResetSuccessMessage(res.message);
    setTimeout(() => {
      setLoginIdentifier(resetEmail);
      setLoginPassword(resetNewPassword);
      setActiveTab('LOGIN');
      setResetStep('REQUEST');
      setResetVerificationCode('');
      setResetNewPassword('');
      setResetNewPasswordConfirm('');
      setVerificationCodeDelivery(null);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 lg:flex">
      {/* v3.9: marka paneli — yalnız logo ve 4 aşama simgesi (tasarım: Giriş) */}
      <aside className="bg-[#0F3D2E] text-white px-5 pt-7 pb-6 lg:w-[44%] lg:min-h-screen lg:px-14 lg:py-14 flex flex-col lg:justify-center gap-6 lg:gap-10">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <BrandLogo size={60} />
            <div>
              <div className="font-display text-xl lg:text-2xl font-bold">MIWE HIL</div>
              <div className="text-xs lg:text-sm text-white/75">Hasat · Soğuk zincir · Kalite</div>
            </div>
          </div>
          {isOnline ? (
            <span className="lg:hidden inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 text-white text-xs font-semibold"><Wifi className="w-3.5 h-3.5" />Çevrimiçi</span>
          ) : (
            <span className="lg:hidden inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-bold"><WifiOff className="w-3.5 h-3.5" />Çevrimdışı</span>
          )}
        </div>
        <div className="flex gap-2 lg:gap-3 lg:max-w-md" aria-label="Süreç aşamaları">
          {[
            { k: 'Hasat', Icon: Leaf },
            { k: 'Ön soğutma', Icon: Snowflake },
            { k: 'Soğuk depo', Icon: Warehouse },
            { k: 'Sevk', Icon: Truck },
          ].map(({ k, Icon }) => (
            <span key={k} title={k} className="flex-1 h-11 lg:h-16 rounded-xl lg:rounded-2xl bg-white/12 flex items-center justify-center">
              <Icon className="w-5 h-5 lg:w-7 lg:h-7" aria-label={k} />
            </span>
          ))}
        </div>
        <div className="hidden lg:flex items-center gap-2 text-sm">
          {isOnline
            ? <span className="inline-flex items-center gap-1.5 text-white/80"><Wifi className="w-4 h-4" />Çevrimiçi</span>
            : <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400 text-slate-950 font-bold"><WifiOff className="w-4 h-4" />Çevrimdışı — kayıtlar sırada bekler</span>}
        </div>
      </aside>

      <div className="flex-1 flex flex-col justify-center px-4 py-6 sm:px-6 lg:px-12">
      {/* Main Container */}
      <div className="max-w-md w-full mx-auto my-6 space-y-4">

        {/* TOP-LEVEL PORTAL SELECTOR: CLEAR SEPARATION OF PERSONNEL vs ADMIN */}
        <div className="grid grid-cols-2 p-1.5 bg-white backdrop-blur-md rounded-2xl border border-slate-200 shadow-xl gap-2">
          <button
            type="button"
            onClick={() => {
              setIsAdminPortalMode(false);
              setAdminError(null);
              setLoginError(null);
            }}
            className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer text-xs font-bold ${
              !isAdminPortalMode
                ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-lg border border-teal-500/40 ring-1 ring-teal-500/30'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <User className={`w-4 h-4 ${!isAdminPortalMode ? 'text-teal-700' : 'text-slate-500'}`} />
            <span>Personel Girişi</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setIsAdminPortalMode(true);
              setAdminError(null);
              setAdminPassword('');
              setLoginError(null);
            }}
            className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer text-xs font-bold ${
              isAdminPortalMode
                ? 'bg-emerald-700 hover:bg-emerald-800 text-white border border-emerald-700'
                : 'text-amber-800 hover:text-amber-800 hover:bg-amber-50 border border-amber-500/20'
            }`}
          >
            <ShieldCheck className={`w-4 h-4 ${isAdminPortalMode ? 'text-white' : 'text-amber-800'}`} />
            <span>Yönetici girişi</span>
          </button>
        </div>
        
        {/* ========================================================================= */}
        {/* SCENARIO A: ISOLATED ADMIN PORTAL (ŞİFRELİ KORUMALI)                      */}
        {/* ========================================================================= */}
        {isAdminPortalMode ? (
          <div className="bg-white backdrop-blur-md rounded-3xl border-2 border-amber-500/60 shadow-2xl shadow-amber-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Admin Header Banner */}
            <div className="bg-white p-4 border-b border-amber-500/40 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-500/50 flex items-center justify-center text-amber-700 shadow-inner">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-amber-800 flex items-center gap-1.5">
                    <span>Sistem Yöneticisi Girişi</span>
                  </h3>
                  <p className="text-[10px] text-amber-800">Şifreli & Yetkili Denetim Paneli</p>
                </div>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-amber-800 bg-amber-50 px-2 py-1 rounded-lg border border-amber-500/30">
                <Lock className="w-3 h-3 text-amber-800" />
                <span>Şifre Zorunlu</span>
              </div>
            </div>

            {/* Admin Form Content */}
            <div className="p-6 sm:p-7 space-y-5">
              <div className="text-center space-y-1 pb-1">
                <h2 className="text-lg font-bold text-slate-900 flex items-center justify-center gap-2">
                  <Lock className="w-5 h-5 text-amber-800" />
                  <span>Yönetici Kimlik Doğrulama</span>
                </h2>
                <p className="text-xs text-slate-500">
                  Kullanıcı onayları, rol yetkileri ve sistem ayarları için yönetici parolanızı girin.
                </p>
              </div>

              {adminError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span className="font-medium">{adminError}</span>
                </div>
              )}

              <form onSubmit={handleAdminLogin} className="space-y-4">
                {/* Admin Identifier */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-amber-800" />
                    <span>Yönetici E-Posta / Kullanıcı Adı *</span>
                  </label>
                  <input
                    type="text"
                    value={adminIdentifier}
                    onChange={(e) => setAdminIdentifier(e.target.value)}
                    placeholder="admin@miwe.com veya kullanıcı adı"
                    className="w-full bg-white border border-slate-300 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500/50 transition"
                    required
                  />
                </div>

                {/* Admin Password */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-800" />
                      <span>Yönetici Güvenlik Parolası *</span>
                    </label>
                    <span className="text-[10px] text-amber-800 tabular-nums">256-bit SHA Korumalı</span>
                  </div>
                  <div className="relative">
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      placeholder="Yönetici parolanızı girin..."
                      autoFocus
                      className="w-full bg-white border border-amber-500/50 focus:border-amber-400 rounded-xl pl-3.5 pr-10 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500/60 tabular-nums transition"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(!showAdminPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-1"
                      title={showAdminPassword ? 'Parolayı gizle' : 'Parolayı göster'}
                    >
                      {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Security Note */}
                <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-500/30 text-[11px] text-amber-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-800 shrink-0" />
                  <span>Şifresiz giriş yapılamaz. Yönetici hesabı yetkisiz erişimlere karşı tam korumalıdır.</span>
                </div>

                {/* Admin Login Submit Button */}
                <button
                  type="submit"
                  disabled={isAdminLoggingIn}
                  className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/25 transition cursor-pointer flex items-center justify-center gap-2 mt-2 active:scale-98"
                >
                  <ShieldCheck className="w-4 h-4 text-slate-950" />
                  <span>{isAdminLoggingIn ? 'Doğrulanıyor...' : 'Yönetici Olarak Güvenli Giriş Yap'}</span>
                  <ArrowRight className="w-4 h-4 text-slate-950" />
                </button>
              </form>

              <div className="pt-3 border-t border-slate-200 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsAdminPortalMode(false);
                    setAdminError(null);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-900 transition cursor-pointer inline-flex items-center gap-1.5 font-medium"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Personel & Uzman Girişine Dön</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================================= */
          /* Scenario b: general personnel portal                                      */
          /* ========================================================================= */
          <div className="bg-white backdrop-blur-md rounded-3xl border border-slate-300 shadow-2xl overflow-hidden">
            {/* Navigation Tabs */}
            <div className="grid grid-cols-3 p-1.5 bg-white border-b border-slate-200 text-xs font-bold gap-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('LOGIN');
                  setLoginError(null);
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer text-[11px] ${
                  activeTab === 'LOGIN'
                    ? 'bg-slate-200 text-slate-900 shadow-xs border border-slate-300 font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <LogIn className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                <span>Giriş Yap</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('REGISTER');
                  setRegError(null);
                  setRegSuccessMessage(null);
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer text-[11px] ${
                  activeTab === 'REGISTER'
                    ? 'bg-slate-200 text-slate-900 shadow-xs border border-slate-300 font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span>Kayıt Ol</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('FORGOT_PASSWORD');
                  setResetError(null);
                  setResetSuccessMessage(null);
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer text-[11px] ${
                  activeTab === 'FORGOT_PASSWORD'
                    ? 'bg-slate-200 text-slate-900 shadow-xs border border-slate-300 font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-800 shrink-0" />
                <span>Şifre Sıfırla</span>
              </button>
            </div>

            {/* General Form Content */}
            <div className="p-6 sm:p-7 space-y-5">
              
              {/* TAB 1: LOGIN */}
              {activeTab === 'LOGIN' && (
                <form onSubmit={handleGeneralLogin} className="space-y-4">
                  <div className="text-center space-y-1 pb-1">
                    <h2 className="text-lg font-bold text-slate-900">Personel Girişi</h2>
                    <p className="text-xs text-slate-500">
                      Kayıtlı e-posta veya kullanıcı adı ve parolanızla giriş yapın.
                    </p>
                  </div>

                  {/* Status Notice (Pending Approval) */}
                  {loginStatusNotice && (
                    <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-500/40 text-amber-900 text-xs leading-relaxed space-y-2.5">
                      <div className="flex items-start gap-2.5">
                        <AlertCircle className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                        <div>{loginStatusNotice}</div>
                      </div>
                      <div className="pt-1 flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleGeneralLogin()}
                          disabled={isCheckingStatus}
                          className="px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-500/30 text-amber-900 text-[11px] font-bold border border-amber-500/40 flex items-center gap-1.5 transition cursor-pointer"
                        >
                          <RotateCcw className={`w-3 h-3 ${isCheckingStatus ? 'animate-spin text-amber-800' : ''}`} />
                          <span>{isCheckingStatus ? 'Kontrol Ediliyor...' : 'Onay Durumunu Yenile'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Login Error */}
                  {loginError && (
                    <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-500/40 text-rose-800 text-xs space-y-2">
                      <div className="flex items-center gap-2.5">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span className="font-medium">{loginError}</span>
                      </div>
                      {offerNewTab && (
                        <a href={window.location.href} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center justify-center w-full py-2 rounded-xl bg-emerald-700 text-white font-bold">
                          Uygulamayı yeni sekmede aç
                        </a>
                      )}
                    </div>
                  )}
                  {!loginError && isInIframe() && (
                    <p className="text-[11px] text-slate-500">Önizleme penceresindesiniz: Google girişi burada çalışmayabilir. E-posta ve şifre her yerde çalışır.</p>
                  )}

                  {/* Identifier Input */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      <span>E-posta *</span>
                    </label>
                    <input
                      type="text"
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="ad.soyad@domain.com"
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                      required
                    />
                  </div>

                  {/* Password Input */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-slate-500" />
                        <span>Parola *</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('FORGOT_PASSWORD');
                          setResetEmail(loginIdentifier.includes('@') ? loginIdentifier : '');
                          setResetError(null);
                        }}
                        className="text-[11px] text-amber-800 hover:text-amber-800 hover:underline cursor-pointer"
                      >
                        Şifremi Unuttum?
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showLoginPassword ? 'text' : 'password'}
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-white border border-slate-300 rounded-xl pl-3.5 pr-10 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowLoginPassword(!showLoginPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-1"
                        title={showLoginPassword ? 'Parolayı gizle' : 'Parolayı göster'}
                      >
                        {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-2 active:scale-98"
                  >
                    <span>Personel Olarak Giriş Yap</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  {/* Google ile giriş (Firebase Authentication) */}
                  <button
                    type="button"
                    onClick={handleGoogleLogin}
                    className="w-full py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2 border border-slate-300"
                  >
                    <span aria-hidden="true" className="font-bold text-sm">G</span>
                    <span>Google hesabıyla giriş yap</span>
                  </button>

                  {/* Admin Switch Link */}
                  <div className="pt-3 border-t border-slate-200 text-center">
                    <p className="text-[11px] text-slate-500">
                      Sistem yöneticisi misiniz?{' '}
                      <button
                        type="button"
                        onClick={() => {
                          setIsAdminPortalMode(true);
                          setAdminError(null);
                          setAdminPassword('');
                        }}
                        className="text-amber-800 hover:text-amber-800 font-bold hover:underline cursor-pointer inline-flex items-center gap-1"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Yönetici girişi</span>
                      </button>
                    </p>
                  </div>
                </form>
              )}

              {/* TAB 2: REGISTER */}
              {activeTab === 'REGISTER' && (
                <form onSubmit={handleRegister} className="space-y-3.5">
                  <div className="text-center space-y-1 pb-1">
                    <h2 className="text-lg font-bold text-slate-900">Yeni Personel Kaydı</h2>
                    <p className="text-xs text-slate-500 leading-snug">
                      Kaydınız anında "Ziyaretçi (Salt Okunur / PASIF_READER)" modunda açılır. Veri girişi ve düzenleme yetkisi için Yönetici onayı talep edebilirsiniz.
                    </p>
                  </div>

                  {regSuccessMessage && (
                    <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-200 text-xs leading-relaxed flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <span>{regSuccessMessage}</span>
                    </div>
                  )}

                  {regError && (
                    <div className="p-3 rounded-2xl bg-rose-50 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{regError}</span>
                    </div>
                  )}

                  {/* Ad Soyad */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      <span>Adı ve Soyadı *</span>
                    </label>
                    <input
                      type="text"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="Adınız ve Soyadınız"
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                      required
                    />
                  </div>

                  {/* E-posta & Telefon */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-slate-500" />
                        <span>E-posta Adresi *</span>
                      </label>
                      <input
                        type="email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        placeholder="ad.soyad@domain.com"
                        className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-slate-500" />
                        <span>Telefon No *</span>
                      </label>
                      <input
                        type="text"
                        value={regPhone}
                        onChange={(e) => setRegPhone(e.target.value)}
                        placeholder="+993 6X XXXXXX"
                        className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Görev Yaptığı Firma */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-slate-500" />
                      <span>Bölüm *</span>
                    </label>
                    <select
                      value={regCompany}
                      onChange={(e) => setRegCompany(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    >
                      {KNOWN_COMPANIES.map((comp) => (
                        <option key={comp} value={comp} className="bg-slate-50 text-slate-900">
                          {comp}
                        </option>
                      ))}
                      <option value="OTHER" className="bg-slate-50 text-slate-900">Diğer (Özel Belirt)</option>
                    </select>
                    {regCompany === 'OTHER' && (
                      <input
                        type="text"
                        value={regCustomCompany}
                        onChange={(e) => setRegCustomCompany(e.target.value)}
                        placeholder="Firma adını yazın..."
                        className="w-full mt-1 bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900"
                        required
                      />
                    )}
                  </div>

                  {/* Görevi / Pozisyon */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                      <span>Görevi / Pozisyonu *</span>
                    </label>
                    <select
                      value={regJobTitle}
                      onChange={(e) => setRegJobTitle(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    >
                      {KNOWN_JOB_TITLES.map((job) => (
                        <option key={job} value={job} className="bg-slate-50 text-slate-900">
                          {job}
                        </option>
                      ))}
                      <option value="OTHER" className="bg-slate-50 text-slate-900">Diğer Pozisyon</option>
                    </select>
                    {regJobTitle === 'OTHER' && (
                      <input
                        type="text"
                        value={regCustomJobTitle}
                        onChange={(e) => setRegCustomJobTitle(e.target.value)}
                        placeholder="Görevinizi yazın..."
                        className="w-full mt-1 bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900"
                        required
                      />
                    )}
                  </div>

                  {/* Parola & Parola Onayı */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-slate-500" />
                        <span>Parola *</span>
                      </label>
                      <div className="relative">
                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white border border-slate-300 rounded-xl pl-3.5 pr-9 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegPassword(!showRegPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-0.5"
                        >
                          {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                        <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                        <span>Parola Onayı *</span>
                      </label>
                      <div className="relative">
                        <input
                          type={showRegPasswordConfirm ? 'text' : 'password'}
                          value={regPasswordConfirm}
                          onChange={(e) => setRegPasswordConfirm(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white border border-slate-300 rounded-xl pl-3.5 pr-9 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegPasswordConfirm(!showRegPasswordConfirm)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-0.5"
                        >
                          {showRegPasswordConfirm ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Password Strength Meter */}
                  {regPassword.length > 0 && (
                    <div className="space-y-1.5 p-2.5 bg-white rounded-xl border border-slate-200">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500 font-bold">Şifre Güvenliği:</span>
                        <span className="font-bold text-teal-700">{regPasswordStrength.label}</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden flex gap-1">
                        {[1, 2, 3, 4].map((level) => (
                          <div
                            key={level}
                            className={`h-full flex-1 transition-all duration-300 rounded-full ${
                              level <= regPasswordStrength.score ? regPasswordStrength.color : 'bg-slate-200'
                            }`}
                          />
                        ))}
                      </div>
                      {regPasswordConfirm && (
                        <div className="text-[10px] flex items-center gap-1 mt-1 font-semibold">
                          {regPassword === regPasswordConfirm ? (
                            <span className="text-emerald-700 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Parolalar eşleşiyor
                            </span>
                          ) : (
                            <span className="text-rose-600 flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" /> Parolalar eşleşmiyor
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Submit Register */}
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-2 active:scale-98"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Kayıt Başvurusunu Gönder</span>
                  </button>
                </form>
              )}

              {/* TAB 3: PASSWORD RESET */}
              {activeTab === 'FORGOT_PASSWORD' && (
                <div className="space-y-4">
                  <div className="text-center space-y-1 pb-1">
                    <h2 className="text-lg font-bold text-slate-900">Şifre Sıfırlama</h2>
                    <p className="text-xs text-slate-500 leading-snug">
                      {resetStep === 'REQUEST'
                        ? 'Kayıtlı e-posta adresinizi girin. Size parola sıfırlama bağlantısı gönderilecektir.'
                        : 'E-postanıza gönderilen 6 haneli doğrulama kodunu ve yeni parolanızı belirleyin.'}
                    </p>
                  </div>

                  {verificationCodeDelivery && (
                    <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-500/40 text-amber-900 text-xs leading-relaxed space-y-1.5 animate-in fade-in">
                      <div className="flex items-center gap-2 font-bold text-amber-800">
                        <KeyRound className="w-4 h-4 text-amber-800 shrink-0" />
                        <span>Güvenlik Doğrulama Kodu:</span>
                      </div>
                      <div className="flex items-center justify-between bg-white p-2 rounded-xl border border-amber-500/30">
                        <span className="tabular-nums text-base font-bold text-amber-800">
                          {verificationCodeDelivery}
                        </span>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> 15 dk geçerli
                        </span>
                      </div>
                    </div>
                  )}

                  {resetSuccessMessage && (
                    <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-200 text-xs leading-relaxed flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <span>{resetSuccessMessage}</span>
                    </div>
                  )}

                  {resetError && (
                    <div className="p-3 rounded-2xl bg-rose-50 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{resetError}</span>
                    </div>
                  )}

                  {resetStep === 'REQUEST' && (
                    <form onSubmit={handleRequestResetCode} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-slate-500" />
                          <span>Kayıtlı E-posta Adresi *</span>
                        </label>
                        <input
                          type="email"
                          value={resetEmail}
                          onChange={(e) => setResetEmail(e.target.value)}
                          placeholder="ad.soyad@domain.com"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                      >
                        <KeyRound className="w-4 h-4" />
                        <span>Sıfırlama Bağlantısı Gönder</span>
                      </button>

                      <div className="text-center pt-2">
                        <button
                          type="button"
                          onClick={() => setActiveTab('LOGIN')}
                          className="text-xs text-slate-500 hover:text-slate-900 hover:underline cursor-pointer"
                        >
                          ← Giriş Ekranına Dön
                        </button>
                      </div>
                    </form>
                  )}

                  {resetStep === 'VERIFY_AND_SET' && (
                    <form onSubmit={handleVerifyAndSetPassword} className="space-y-3.5">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                            <span>6 Haneli Doğrulama Kodu *</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setResetStep('REQUEST');
                              setVerificationCodeDelivery(null);
                            }}
                            className="text-[10px] text-amber-800 hover:underline cursor-pointer"
                          >
                            Tekrar Kod İste
                          </button>
                        </label>
                        <input
                          type="text"
                          maxLength={6}
                          value={resetVerificationCode}
                          onChange={(e) => setResetVerificationCode(e.target.value.replace(/\D/g, ''))}
                          placeholder="123456"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-center text-sm tabular-nums font-bold text-amber-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-slate-500" />
                            <span>Yeni Parola *</span>
                          </label>
                          <div className="relative">
                            <input
                              type={showResetPassword ? 'text' : 'password'}
                              value={resetNewPassword}
                              onChange={(e) => setResetNewPassword(e.target.value)}
                              placeholder="••••••••"
                              className="w-full bg-white border border-slate-300 rounded-xl pl-3.5 pr-8 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowResetPassword(!showResetPassword)}
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-0.5"
                            >
                              {showResetPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                            <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                            <span>Parola Onayı *</span>
                          </label>
                          <div className="relative">
                            <input
                              type={showResetPasswordConfirm ? 'text' : 'password'}
                              value={resetNewPasswordConfirm}
                              onChange={(e) => setResetNewPasswordConfirm(e.target.value)}
                              placeholder="••••••••"
                              className="w-full bg-white border border-slate-300 rounded-xl pl-3.5 pr-8 py-2 text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowResetPasswordConfirm(!showResetPasswordConfirm)}
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-900 cursor-pointer p-0.5"
                            >
                              {showResetPasswordConfirm ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>
                      </div>

                      {resetNewPassword.length > 0 && (
                        <div className="space-y-1.5 p-2.5 bg-white rounded-xl border border-slate-200">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="text-slate-500 font-bold">Yeni Şifre Gücü:</span>
                            <span className="font-bold text-teal-700">{resetPasswordStrength.label}</span>
                          </div>
                          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden flex gap-1">
                            {[1, 2, 3, 4].map((level) => (
                              <div
                                key={level}
                                className={`h-full flex-1 transition-all duration-300 rounded-full ${
                                  level <= resetPasswordStrength.score ? resetPasswordStrength.color : 'bg-slate-200'
                                }`}
                              />
                            ))}
                          </div>
                          {resetNewPasswordConfirm && (
                            <div className="text-[10px] flex items-center gap-1 mt-1 font-semibold">
                              {resetNewPassword === resetNewPasswordConfirm ? (
                                <span className="text-emerald-700 flex items-center gap-1">
                                  <Check className="w-3 h-3" /> Parolalar eşleşiyor
                                </span>
                              ) : (
                                <span className="text-rose-600 flex items-center gap-1">
                                  <AlertCircle className="w-3 h-3" /> Parolalar eşleşmiyor
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-2 active:scale-98"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Parolayı Sıfırla & Giriş Yap</span>
                      </button>

                      <div className="text-center pt-2">
                        <button
                          type="button"
                          onClick={() => setActiveTab('LOGIN')}
                          className="text-xs text-slate-500 hover:text-slate-900 hover:underline cursor-pointer"
                        >
                          ← Giriş Ekranına Dön
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

            </div>
          </div>
        )}
      </div>

      </div>
    </div>
  );
};
