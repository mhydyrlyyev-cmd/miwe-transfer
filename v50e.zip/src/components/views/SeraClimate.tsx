import React, { useMemo, useState } from 'react';
import { MapPin, Thermometer, LocateFixed, ClipboardPaste, AlertTriangle, X } from 'lucide-react';
import { findProfile, upsertProfile } from '../../services/locationProfiles';
import { useElevations, useOutsideRecent } from '../../services/agroClimate';
import { useMuzDocs, isClim, isRead, saveClim, saveRead, removeRead, readIssues, parseClimPaste, todayISO, addDays, CLIM_LIMITS, type MuzRead, type SectorRead } from '../../services/muzDaily';

/** v50d — Sera bilgisi (konum, yükseklik, dış hava) + INTA anlık okuma (sektör başına iç °C, nem, ısıtma suyu, havalandırma, perde; dış istasyon). Eski v50c:  (konum, yükseklik, dış hava) + sera içi iklim (otomasyondan günlük giriş ya da toplu yapıştırma; dış hava ile yan yana) */
const inp = 'w-full min-h-[36px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm tabular-nums';
const dm = (iso: string) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}`;
const r1 = (x?: number) => (typeof x === 'number' ? x.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—');

export function SeraInfo({ name, by = '', readOnly }: { name: string; by?: string; readOnly?: boolean }) {
  const pr = findProfile('GREENHOUSE', name);
  const lat = Number(pr?.fields?.lat) || undefined, lon = Number(pr?.fields?.lon) || undefined;
  const [elev] = useElevations([{ lat, lon }]);
  const out = useOutsideRecent(lat, lon);
  const [msg, setMsg] = useState('');
  const [manual, setManual] = useState('');
  const save = async (la: number, lo: number, how: string) => {
    if (!pr) { setMsg('Bu sera için profil yok.'); return; }
    await upsertProfile({ ...pr, fields: { ...pr.fields, lat: Math.round(la * 1e6) / 1e6, lon: Math.round(lo * 1e6) / 1e6 }, updatedBy: by });
    setMsg(`Konum kaydedildi (${how}).`); setManual('');
  };
  const today = out?.days.find(d => d.date === todayISO());
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1.5"><MapPin className="w-4 h-4 text-teal-700" />Sera bilgisi</h2>
      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Konum</div>
          <div className="text-sm font-semibold tabular-nums truncate">{lat && lon ? <a href={`https://maps.google.com/?q=${lat},${lon}`} target="_blank" rel="noreferrer" className="text-teal-800 dark:text-teal-300 underline">{lat.toFixed(4)}, {lon.toFixed(4)}</a> : <span className="text-amber-700">girilmedi</span>}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Denizden yükseklik</div><div className="text-sm font-semibold tabular-nums">{elev !== undefined ? `${elev.toLocaleString('tr-TR')} m` : lat ? '…' : '—'}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Dış hava şu an</div><div className="text-sm font-semibold tabular-nums">{out?.now !== undefined ? `${r1(out.now)} °C` : lat ? (out?.error ? '—' : '…') : '—'}</div></div>
        <div className="min-w-0"><div className="text-[10px] text-slate-500">Dış bugün</div><div className="text-sm font-semibold tabular-nums">{today ? `${r1(today.tMin)} … ${r1(today.tMax)} °C` : '—'}</div></div>
      </div>
      {!readOnly && (
        <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
          <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] gap-1.5">
            <button type="button" onClick={() => {
              if (!navigator.geolocation) { setMsg('Bu cihaz konum vermiyor.'); return; }
              setMsg('Konum alınıyor…');
              navigator.geolocation.getCurrentPosition(p => save(p.coords.latitude, p.coords.longitude, `±${Math.round(p.coords.accuracy)} m`), () => setMsg('Konum alınamadı — izin verin ya da elle yazın.'), { enableHighAccuracy: true, timeout: 15000 });
            }} className="min-h-[36px] px-2.5 rounded-lg border border-teal-300 text-teal-800 dark:text-teal-300 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"><LocateFixed className="w-3.5 h-3.5" />Konumumu al</button>
            <input placeholder="ya da 37.9512, 58.3801" aria-label="Konum (enlem, boylam)" value={manual} onChange={e => setManual(e.target.value)} className={inp} />
            <button type="button" disabled={!/^\s*-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?\s*$/.test(manual)} onClick={() => { const [a, b] = manual.split(',').map(Number); save(a, b, 'elle'); }} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          </div>
          <p className="text-[10px] text-slate-500">{msg || 'Seranın dışında durup "Konumumu al"a basın; ya da Google Haritalar\'dan koordinatı yapıştırın.'}</p>
        </div>
      )}
    </section>
  );
}

export default function SeraClimate({ name, by = '', readOnly }: { name: string; by?: string; readOnly?: boolean }) {
  const docs = useMuzDocs();
  const pr = findProfile('GREENHOUSE', name);
  const outside = useOutsideRecent(Number(pr?.fields?.lat) || undefined, Number(pr?.fields?.lon) || undefined);
  const today = todayISO();
  const reads = useMemo(() => docs.filter(isRead).filter(r => r.sera === name).sort((a, b) => `${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`)), [docs, name]);
  const clim = useMemo(() => docs.filter(isClim).filter(c => c.sera === name), [docs, name]);
  const last = reads[0];
  const nowHM = () => { const d = new Date(); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const [n, setN] = useState(String(last?.sectors.length || 8));
  const cnt = Math.max(1, Math.min(24, Number(n) || 8));
  const blank = () => Array.from({ length: 24 }, () => ({ t: '', rh: '', heat: '', vent: '', curtain: '' }));
  const [rows, setRows] = useState(blank);
  const [vc, setVc] = useState(false);
  const [out, setOut] = useState({ t: '', rh: '', rad: '', wind: '' });
  const [date, setDate] = useState(today);
  const [time, setTime] = useState(nowHM());
  const [open, setOpen] = useState(false);
  const [paste, setPaste] = useState('');
  const [msg, setMsg] = useState('');
  const num = (x: string) => (String(x).trim() === '' ? undefined : Number(String(x).replace(',', '.')));
  const filled = rows.slice(0, cnt).some(r => num(r.t) !== undefined);
  const draftIssues = readIssues({ id: '', calV: 'MUZ', kind: 'read', sera: name, date, time, at: '', sectors: rows.slice(0, cnt).map((r, i) => ({ s: String(i + 1), t: num(r.t), rh: num(r.rh), heat: num(r.heat) })), out: { rh: num(out.rh) } });
  // gün özeti: okumalardan (yoksa eski günlük min-max kaydı)
  const days = Array.from({ length: 14 }, (_, i) => addDays(today, -i));
  const dayOf = (d: string) => {
    const rs = reads.filter(r => r.date === d);
    const ts = rs.flatMap(r => r.sectors.map(x => x.t)).filter((x): x is number => typeof x === 'number');
    const os = rs.map(r => r.out?.t).filter((x): x is number => typeof x === 'number');
    const c = clim.find(x => x.date === d);
    const tMin = ts.length ? Math.min(...ts) : c?.tMin, tMax = ts.length ? Math.max(...ts) : c?.tMax;
    const o = outside?.days.find(x => x.date === d);
    return { n: rs.length, tMin, tMax, oMin: os.length ? Math.min(...os) : o?.tMin, oMax: os.length ? Math.max(...os) : o?.tMax, oSrc: os.length ? 'INTA' : o ? 'model' : '' };
  };
  const wk = days.slice(0, 7).map(dayOf).filter(d => d.tMin !== undefined);
  const cold = wk.filter(d => d.tMin! < CLIM_LIMITS.cold).length, hot = wk.filter(d => (d.tMax ?? -99) > CLIM_LIMITS.hot).length;
  const P = (t: number) => `${Math.max(0, Math.min(100, ((t + 5) / 50) * 100))}%`;
  const tCls = (t?: number) => (t === undefined ? '' : t < CLIM_LIMITS.cold || t > CLIM_LIMITS.hot ? 'text-rose-700 font-semibold' : t < CLIM_LIMITS.coldWarn ? 'text-amber-700' : '');
  const cell = 'w-full min-h-[34px] rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-1 text-xs text-center tabular-nums';
  const pp = paste.trim() ? parseClimPaste(paste) : undefined;
  const issues = last ? readIssues(last) : [];
  const ageH = last ? (Date.now() - new Date(`${last.date}T${last.time}:00`).getTime()) / 3600e3 : Infinity;
  const showVc = vc || (last?.sectors.some(x => x.vent !== undefined || x.curtain !== undefined) ?? false);
  const cols = showVc ? 'grid-cols-[22px_repeat(5,minmax(0,1fr))]' : 'grid-cols-[22px_repeat(3,minmax(0,1fr))]';
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2.5">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Thermometer className="w-4 h-4 text-teal-700" />Sera içi iklim · INTA</h2>
        {last && <span className={`text-[11px] ${ageH > 12 ? 'text-amber-700' : 'text-slate-500'}`}>son okuma {last.date === today ? 'bugün' : last.date.slice(8, 10) + '.' + last.date.slice(5, 7)} {last.time}</span>}
      </div>
      {last ? (
        <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2">
          <div className={`grid ${showVc ? 'grid-cols-[34px_repeat(5,minmax(0,1fr))]' : 'grid-cols-[34px_repeat(3,minmax(0,1fr))]'} gap-1 text-[10px] text-slate-500 font-semibold`}><span>Sek.</span><span className="text-center">İç °C</span><span className="text-center">Nem %</span><span className="text-center">Isıtma</span>{showVc && <><span className="text-center">Hav. %</span><span className="text-center">Perde %</span></>}</div>
          {last.sectors.map(x => {
            const bad = issues.some(i => i.s === x.s);
            return (
              <div key={x.s} className={`grid ${showVc ? 'grid-cols-[34px_repeat(5,minmax(0,1fr))]' : 'grid-cols-[34px_repeat(3,minmax(0,1fr))]'} gap-1 text-xs tabular-nums py-0.5 ${bad ? 'bg-amber-50 dark:bg-amber-950/30 rounded' : ''}`}>
                <span className="font-semibold">{x.s}</span><span className={`text-center ${tCls(x.t)}`}>{r1(x.t)}</span><span className={`text-center ${x.rh !== undefined && (x.rh <= 0 || x.rh > 100) ? 'text-amber-700' : ''}`}>{x.rh ?? '—'}</span><span className="text-center">{r1(x.heat)}</span>
                {showVc && <><span className="text-center">{x.vent ?? '—'}</span><span className="text-center">{x.curtain ?? '—'}</span></>}
              </div>);
          })}
          {last.out && <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1">Dış (INTA): {r1(last.out.t)} °C{last.out.rh !== undefined ? ` · nem ${last.out.rh}%` : ''}{last.out.rad !== undefined ? ` · ışınım ${last.out.rad}` : ''}{last.out.wind !== undefined ? ` · rüzgâr ${r1(last.out.wind)} m/s` : ''}</div>}
          {issues.length > 0 && <ul className="mt-1.5 space-y-0.5">{issues.map((i, k) => <li key={k} className={`text-[11px] flex gap-1 ${i.level === 'bad' ? 'text-rose-700' : 'text-amber-800'}`}><AlertTriangle className="w-3.5 h-3.5 shrink-0" />{i.s ? `Sektör ${i.s}: ` : ''}{i.msg}</li>)}</ul>}
        </div>
      ) : <p className="text-xs text-slate-500">Henüz okuma yok. INTA ekranındaki değerleri günde 2–3 kez (sabah erken, öğlen, akşam) girin; günün en düşük ve en yüksek değeri buradan çıkar.</p>}
      {wk.length > 0 && (
        <div className={`rounded-lg border px-2.5 py-1.5 text-xs ${cold || hot ? 'border-rose-200 bg-rose-50 text-rose-900' : 'border-emerald-200 bg-emerald-50 text-emerald-900'}`}>
          Son 7 gün: {cold ? `${cold} gün ${CLIM_LIMITS.cold} °C altı` : `${CLIM_LIMITS.cold} °C altı yok`} · {hot ? `${hot} gün ${CLIM_LIMITS.hot} °C üstü` : 'sıcak stresi yok'}
        </div>
      )}
      {!readOnly && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-700">
          <button type="button" onClick={() => setOpen(v => !v)} className="w-full min-h-[40px] px-3 text-left text-xs font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">{open ? '▾' : '▸'} INTA ekranından okuma gir</button>
          {open && (
            <div className="px-2.5 pb-2.5 space-y-2">
              <div className="grid grid-cols-3 gap-1.5">
                <label className="text-[10px] text-slate-500">Gün<input type="date" max={today} value={date} onChange={e => e.target.value && setDate(e.target.value)} className={inp} /></label>
                <label className="text-[10px] text-slate-500">Saat<input type="time" value={time} onChange={e => setTime(e.target.value)} className={inp} /></label>
                <label className="text-[10px] text-slate-500">Sektör sayısı<input inputMode="numeric" value={n} onChange={e => setN(e.target.value.replace(/[^\d]/g, ''))} className={inp} /></label>
              </div>
              <div className={`grid ${cols} gap-1 text-[10px] text-slate-500 font-semibold text-center`}><span /><span>İç °C</span><span>Nem %</span><span>Isıtma °C</span>{showVc && <><span>Hav. %</span><span>Perde %</span></>}</div>
              {rows.slice(0, cnt).map((r, i) => (
                <div key={i} className={`grid ${cols} gap-1 items-center`}>
                  <span className="text-xs font-semibold text-center">{i + 1}</span>
                  {(['t', 'rh', 'heat', ...(showVc ? ['vent', 'curtain'] : [])] as const).map(k => (
                    <input key={k} inputMode="decimal" aria-label={`Sektör ${i + 1} ${k}`} value={(r as any)[k]} onChange={e => setRows(rs => rs.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)))} className={cell} />))}
                </div>))}
              {!showVc && <button type="button" onClick={() => setVc(true)} className="text-[11px] text-teal-800 dark:text-teal-300 cursor-pointer">+ havalandırma ve perde % de gir</button>}
              <div>
                <div className="text-[10px] text-slate-500 mb-0.5">Dış istasyon (sağ sütun)</div>
                <div className="grid grid-cols-4 gap-1">
                  {([['t', 'Dış °C'], ['rh', 'Nem %'], ['rad', 'Işınım'], ['wind', 'Rüzgâr']] as const).map(([k, l]) => (
                    <label key={k} className="text-[10px] text-slate-500 text-center">{l}<input inputMode="decimal" value={(out as any)[k]} onChange={e => setOut(o => ({ ...o, [k]: e.target.value }))} className={cell} /></label>))}
                </div>
              </div>
              {filled && draftIssues.length > 0 && <ul className="space-y-0.5">{draftIssues.map((i, k) => <li key={k} className={`text-[11px] flex gap-1 ${i.level === 'bad' ? 'text-rose-700' : 'text-amber-800'}`}><AlertTriangle className="w-3.5 h-3.5 shrink-0" />{i.s ? `Sektör ${i.s}: ` : ''}{i.msg}</li>)}</ul>}
              <button type="button" disabled={!filled || !/^\d{2}:\d{2}$/.test(time)} onClick={async () => {
                const sectors: SectorRead[] = rows.slice(0, cnt).map((r, i) => ({ s: String(i + 1), t: num(r.t), rh: num(r.rh), heat: num(r.heat), vent: showVc ? num(r.vent) : undefined, curtain: showVc ? num(r.curtain) : undefined }));
                const o = { t: num(out.t), rh: num(out.rh), rad: num(out.rad), wind: num(out.wind) };
                await saveRead(name, date, time, sectors, Object.values(o).some(v => v !== undefined) ? o : undefined, by);
                setRows(blank()); setOut({ t: '', rh: '', rad: '', wind: '' }); setTime(nowHM()); setMsg(`${date.slice(8, 10)}.${date.slice(5, 7)} ${time} okuması kaydedildi.`); setOpen(false);
              }} className="w-full min-h-[38px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Okumayı kaydet</button>
              <details>
                <summary className="text-[11px] text-slate-600 dark:text-slate-400 cursor-pointer flex items-center gap-1"><ClipboardPaste className="w-3.5 h-3.5" />Günlük en düşük / en yüksek yapıştır (dosyadan)</summary>
                <textarea rows={3} value={paste} onChange={e => setPaste(e.target.value)} placeholder={'27.11.2026; 16,5; 31,2; 24; 78'} className="mt-1 w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-xs font-mono" />
                {pp && <p className="text-[10px] text-slate-600">{pp.rows.length} satır okundu{pp.bad ? ` · ${pp.bad} okunamadı` : ''}</p>}
                <button type="button" disabled={!pp?.rows.length} onClick={async () => { await saveClim(name, pp!.rows, 'dosya', by); setMsg(`${pp!.rows.length} gün kaydedildi.`); setPaste(''); }} className="mt-1 w-full min-h-[34px] rounded-lg border border-teal-300 text-teal-800 text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
              </details>
            </div>
          )}
        </div>
      )}
      {msg && <p className="text-[11px] text-emerald-700">{msg}</p>}
      <div>
        <div className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 text-[10px] text-slate-500 font-semibold"><span>Gün</span><span>İç min–max</span><span className="flex items-center gap-2"><span className="inline-block w-3 h-1.5 rounded bg-teal-600" />iç <span className="inline-block w-3 h-1.5 rounded bg-slate-300" />dış</span><span className="text-right">Dış</span></div>
        {days.map(d => {
          const x = dayOf(d);
          return (
            <div key={d} className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 items-center text-[11px] tabular-nums py-0.5">
              <span>{dm(d)}</span>
              <span className={tCls(x.tMin)}>{x.tMin !== undefined ? `${r1(x.tMin)} … ${r1(x.tMax)}` : '—'}{x.n ? <span className="text-[9px] text-slate-400"> ·{x.n}</span> : null}</span>
              <div className="relative h-3">
                <div className="absolute inset-y-0 bg-rose-50 dark:bg-rose-950/30" style={{ left: 0, width: P(CLIM_LIMITS.cold) }} />
                {x.oMin !== undefined && x.oMax !== undefined && <div className="absolute top-[9px] h-1 rounded bg-slate-300 dark:bg-slate-600" style={{ left: P(x.oMin), width: `max(2px, calc(${P(x.oMax)} - ${P(x.oMin)}))` }} />}
                {x.tMin !== undefined && x.tMax !== undefined && <div className="absolute top-0.5 h-1.5 rounded bg-teal-600" style={{ left: P(x.tMin), width: `max(3px, calc(${P(x.tMax)} - ${P(x.tMin)}))` }} />}
              </div>
              <span className="text-right text-slate-500">{x.oMin !== undefined ? `${Math.round(x.oMin)} … ${Math.round(x.oMax!)}` : '—'}</span>
            </div>);
        })}
        <div className="grid grid-cols-[40px_78px_minmax(0,1fr)_64px] gap-2 text-[9px] text-slate-400"><span /><span>·n = okuma</span><span className="flex justify-between"><span>−5</span><span>20</span><span>45 °C</span></span><span /></div>
      </div>
      {!readOnly && reads.filter(r => r.date === today).length > 0 && (
        <details className="text-[11px]"><summary className="cursor-pointer text-slate-500">Bugünkü okumalar</summary>
          <ul className="mt-1 space-y-0.5">{reads.filter(r => r.date === today).map(r => (
            <li key={r.id} className="flex items-center gap-2"><span className="flex-1">{r.time} · {r.sectors.length} sektör · ort. {r1(r.sectors.reduce((a, x) => a + (x.t || 0), 0) / Math.max(1, r.sectors.filter(x => typeof x.t === 'number').length))} °C</span>
              <button type="button" aria-label="Okumayı sil" onClick={() => removeRead(r as MuzRead, by)} className="text-slate-400 cursor-pointer"><X className="w-3.5 h-3.5" /></button></li>))}</ul>
        </details>
      )}
    </section>
  );
}
