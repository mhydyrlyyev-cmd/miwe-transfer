/**
 * v49c4 — Bahçe iklimi (Open-Meteo geçmiş + tahmin; ücretsiz, anahtar gerekmez).
 *  · Gün-derece (GDD): çiçeklenmeden bugüne Σ max(0, (Tmax+Tmin)/2 − taban). Taban profilden (varsayılan 10 °C).
 *  · Soğuklama saati: 1 Kasım'dan bugüne 0 < T ≤ 7,2 °C saat sayısı.
 *  · Çiçek donu: çiçeklenme −10 … +25 gün penceresinde tahmin Tmin ≤ 0 °C uyarı, ≤ −2 °C kritik (iç hedef).
 *  · Geçen yıl: aynı takvim aralığı.
 * Veriler bahçe başına 12 saat yerel önbellekte tutulur.
 */
import { useEffect, useState } from 'react';

export const CLIMATE_LIMITS = { chillLowC: 0, chillHighC: 7.2, bloomWarnC: 0, bloomCritC: -2, defaultBaseC: 10, bloomBefore: 10, bloomAfter: 25 };

export interface ClimDay { date: string; tMax: number; tMin: number; chill: number; forecast?: boolean }

const DAY = 86400000;
const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => iso(new Date(new Date(`${s}T00:00:00Z`).getTime() + n * DAY));
const shiftYear = (s: string, n: number) => `${Number(s.slice(0, 4)) + n}${s.slice(4)}`.replace(/-02-29$/, '-02-28');
const KEY = 'miwe_climate_v1';
const TZ = 'Asia%2FAshgabat';

function toDays(j: any, forecastFrom?: string): ClimDay[] {
  const d = j?.daily || {}, h = j?.hourly || {};
  const chill: Record<string, number> = {};
  (h.time || []).forEach((t: string, i: number) => {
    const v = h.temperature_2m?.[i];
    if (typeof v === 'number' && v > CLIMATE_LIMITS.chillLowC && v <= CLIMATE_LIMITS.chillHighC) chill[t.slice(0, 10)] = (chill[t.slice(0, 10)] || 0) + 1;
  });
  return (d.time || []).map((t: string, i: number) => ({
    date: t, tMax: d.temperature_2m_max?.[i], tMin: d.temperature_2m_min?.[i], chill: chill[t] || 0,
    forecast: forecastFrom ? t > forecastFrom : undefined,
  })).filter((x: ClimDay) => typeof x.tMax === 'number' && typeof x.tMin === 'number');
}

async function getJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`İklim servisi ${r.status}`);
  return r.json();
}

/** start → bugün (+7 gün tahmin). Geçmiş için arşiv, son 7 gün ve tahmin için tahmin servisi. */
export async function fetchClimate(lat: number, lon: number, start: string, withForecast: boolean, end?: string): Promise<ClimDay[]> {
  const today = iso(new Date());
  const stop = end || today;
  const ck = `${lat.toFixed(3)},${lon.toFixed(3)},${start},${stop},${withForecast ? 'f' : 'a'}`;
  let cache: Record<string, { at: number; days: ClimDay[] }> = {};
  try { cache = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { cache = {}; }
  if (cache[ck] && Date.now() - cache[ck].at < 12 * 3600000) return cache[ck].days;
  const q = `latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min&hourly=temperature_2m&timezone=${TZ}`;
  const archEnd = withForecast ? addDays(today, -7) : stop;
  const out = new Map<string, ClimDay>();
  if (start <= archEnd) {
    const a = await getJson(`https://archive-api.open-meteo.com/v1/archive?${q}&start_date=${start}&end_date=${archEnd}`);
    for (const x of toDays(a)) out.set(x.date, x);
  }
  if (withForecast) {
    const f = await getJson(`https://api.open-meteo.com/v1/forecast?${q}&past_days=7&forecast_days=7`);
    for (const x of toDays(f, today)) if (x.date >= start) out.set(x.date, x);
  }
  const days = [...out.values()].sort((a, b) => a.date.localeCompare(b.date));
  try {
    const keep = Object.fromEntries(Object.entries(cache).filter(([, v]) => Date.now() - v.at < 2 * DAY));
    localStorage.setItem(KEY, JSON.stringify({ ...keep, [ck]: { at: Date.now(), days } }));
  } catch { /* yer yoksa önbelleksiz devam */ }
  return days;
}

/** "03-25" (AA-GG) ya da "25.03" (GG.AA) → AA-GG */
export function parseMonthDay(v: unknown): string | null {
  const s = String(v ?? '').trim();
  const m = s.match(/^(\d{1,2})\s*([.\-/])\s*(\d{1,2})/);
  if (!m) return null;
  let [mo, da] = m[2] === '.' ? [Number(m[3]), Number(m[1])] : [Number(m[1]), Number(m[3])];
  if (mo > 12 && da <= 12) [mo, da] = [da, mo];
  if (mo < 1 || mo > 12 || da < 1 || da > 31) return null;
  return `${String(mo).padStart(2, '0')}-${String(da).padStart(2, '0')}`;
}

export interface OrchardClimate {
  name: string;
  baseC: number;
  bloom?: string;                 // bu sezonun çiçeklenme tarihi
  nextBloom?: string;
  gdd?: number; gddLast?: number;
  harvestGdd?: number; harvestEta?: string; harvestReached?: string;
  chill: number; chillLast: number; chillStart: string;
  frost: { level: 'none' | 'warn' | 'crit' | 'off'; text: string };
  /** v50e: kış sonucu (1 Mart–31 Ekim arası görünür): 1 Kasım – 28/29 Şubat soğuklama toplamı, geçen kış */
  winter?: { chill: number; last: number; season: string };
  /** v50e: ilkbahar sonucu (çiçek dönemi bittikten sonra): don geceleri, en düşük */
  spring?: { nights: number; critNights: number; min: number; minDate: string; from: string; to: string };
  forecast: ClimDay[];
  error?: string;
  missing: string[];
}

const sumGdd = (days: ClimDay[], base: number) => days.reduce((s, d) => s + Math.max(0, (d.tMax + d.tMin) / 2 - base), 0);

export function computeClimate(name: string, fields: Record<string, unknown>, now: ClimDay[], last: ClimDay[], todayIso = iso(new Date())): OrchardClimate {
  const missing: string[] = [];
  const baseC = Number(fields.gddBaseC) > -10 && fields.gddBaseC !== '' && fields.gddBaseC != null ? Number(fields.gddBaseC) : CLIMATE_LIMITS.defaultBaseC;
  const md = parseMonthDay(fields.bloomDate);
  if (!md) missing.push('Çiçeklenme tarihi');
  const y = Number(todayIso.slice(0, 4));
  const chillStart = todayIso.slice(5) >= '11-01' ? `${y}-11-01` : `${y - 1}-11-01`;
  const past = now.filter(d => d.date <= todayIso);
  const chill = past.filter(d => d.date >= chillStart).reduce((s, d) => s + d.chill, 0);
  const lastToday = shiftYear(todayIso, -1);
  const chillLast = last.filter(d => d.date >= shiftYear(chillStart, -1) && d.date <= lastToday).reduce((s, d) => s + d.chill, 0);
  const forecast = now.filter(d => d.date > todayIso);
  const res: OrchardClimate = { name, baseC, chill, chillLast, chillStart, frost: { level: 'off', text: 'Çiçeklenme tarihi girilmemiş' }, forecast, missing };
  // v50e: kış sonucu — 1 Mart'tan sonra (Kasım'a kadar) geçen kışın toplamı
  const mon = Number(todayIso.slice(5, 7));
  if (mon >= 3 && mon <= 10) {
    const wS = `${y - 1}-11-01`, wE = `${y}-03-01`;
    const w = past.filter(d => d.date >= wS && d.date < wE).reduce((s2, d) => s2 + d.chill, 0);
    const wl = last.filter(d => d.date >= shiftYear(wS, -1) && d.date < shiftYear(wE, -1)).reduce((s2, d) => s2 + d.chill, 0);
    if (w > 0 || wl > 0) res.winter = { chill: Math.round(w), last: Math.round(wl), season: `${y - 1}–${String(y).slice(2)}` };
  }
  if (!md) return res;

  const thisBloom = `${y}-${md}`;
  const bloom = thisBloom <= todayIso ? thisBloom : `${y - 1}-${md}`;
  const nextBloom = thisBloom > todayIso ? thisBloom : `${y + 1}-${md}`;
  res.bloom = bloom; res.nextBloom = nextBloom;
  const since = past.filter(d => d.date >= bloom);
  res.gdd = Math.round(sumGdd(since, baseC));
  const lb = shiftYear(bloom, -1);
  res.gddLast = Math.round(sumGdd(last.filter(d => d.date >= lb && d.date <= lastToday), baseC));

  const target = Number(fields.harvestGdd);
  if (target > 0) {
    res.harvestGdd = target;
    let acc = 0;
    for (const d of since) { acc += Math.max(0, (d.tMax + d.tMin) / 2 - baseC); if (acc >= target) { res.harvestReached = d.date; break; } }
    if (!res.harvestReached) {
      const recent = [...past.slice(-14), ...forecast];
      const rate = recent.length ? sumGdd(recent, baseC) / recent.length : 0;
      if (rate > 0.5) res.harvestEta = addDays(todayIso, Math.ceil((target - (res.gdd || 0)) / rate));
    }
  }

  // çiçek donu penceresi: en yakın çiçeklenme (geçmiş ya da gelecek)
  const near = [bloom, nextBloom].find(b => todayIso >= addDays(b, -CLIMATE_LIMITS.bloomBefore - 7) && todayIso <= addDays(b, CLIMATE_LIMITS.bloomAfter));
  if (!near) {
    const days = Math.round((new Date(nextBloom).getTime() - new Date(todayIso).getTime()) / DAY);
    res.frost = { level: 'off', text: `Çiçeklenme dönemi dışında · sıradaki ≈ ${nextBloom.split('-').reverse().slice(0, 2).join('.')} (${days} gün)` };
  } else {
    const win = forecast.filter(d => d.date >= addDays(near, -CLIMATE_LIMITS.bloomBefore) && d.date <= addDays(near, CLIMATE_LIMITS.bloomAfter));
    const min = win.reduce((m, d) => Math.min(m, d.tMin), Infinity);
    const at = win.find(d => d.tMin === min);
    if (min <= CLIMATE_LIMITS.bloomCritC) res.frost = { level: 'crit', text: `Çiçek donu riski: ${at?.date.split('-').reverse().slice(0, 2).join('.')} ${min.toFixed(1)} °C` };
    else if (min <= CLIMATE_LIMITS.bloomWarnC) res.frost = { level: 'warn', text: `Hafif don: ${at?.date.split('-').reverse().slice(0, 2).join('.')} ${min.toFixed(1)} °C` };
    else res.frost = { level: 'none', text: win.length ? `Çiçeklenme döneminde · 7 gün içinde don yok (en düşük ${min.toFixed(1)} °C)` : 'Çiçeklenme döneminde · tahmin bekleniyor' };
  }
  // v50e: ilkbahar sonucu — bu yılın çiçek dönemi bittiyse geçmiş günlerden don geceleri
  const thisB = `${y}-${md}`;
  const bTo = addDays(thisB, CLIMATE_LIMITS.bloomAfter);
  if (thisB <= todayIso && bTo < todayIso && mon <= 10) {
    const bFrom = addDays(thisB, -CLIMATE_LIMITS.bloomBefore);
    const win = past.filter(d => d.date >= bFrom && d.date <= bTo);
    if (win.length) {
      const m = win.reduce((a2, d) => (d.tMin < a2.tMin ? d : a2), win[0]);
      res.spring = { nights: win.filter(d => d.tMin <= CLIMATE_LIMITS.bloomWarnC).length, critNights: win.filter(d => d.tMin <= CLIMATE_LIMITS.bloomCritC).length, min: m.tMin, minDate: m.date, from: bFrom, to: bTo };
    }
  }
  if (target <= 0 || !fields.harvestGdd) missing.push('Hasat GDD hedefi');
  return res;
}

/** v50e: meyve türüne göre kaba soğuklama ihtiyacı (saat, 0–7,2 °C) — kitap aralıklarının ortası; bizim bahçelerde her yıl gerçek sonuçla düzeltilecek */
export const CHILL_NEED: Record<string, number> = { Kiraz: 900, Elma: 1000, Armut: 900, Nashi: 800, Erik: 700, Şeftali: 650, Nektarin: 650, Kayısı: 600, Hurma: 400, Badem: 350 };
export function chillVerdict(chill: number, need: number): { pct: number; label: 'yeterli' | 'sınırda' | 'yetersiz' } {
  const pct = need ? Math.round((chill / need) * 100) : 0;
  return { pct, label: pct >= 100 ? 'yeterli' : pct >= 75 ? 'sınırda' : 'yetersiz' };
}

export interface ClimatePoint { name: string; lat?: number; lon?: number; fields: Record<string, unknown> }

export function useOrchardClimate(points: ClimatePoint[]) {
  const [data, setData] = useState<Record<string, OrchardClimate>>({});
  const [loading, setLoading] = useState(false);
  const sig = points.map(p => `${p.name}:${p.lat},${p.lon}:${p.fields.bloomDate}:${p.fields.gddBaseC}:${p.fields.harvestGdd}`).join('|');
  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      const today = iso(new Date());
      const y = Number(today.slice(0, 4));
      for (const p of points) {
        if (typeof p.lat !== 'number' || typeof p.lon !== 'number') continue;
        // en eski gerekli gün: geçen yılın 1 Kasım'ı ya da son çiçeklenme
        const md = parseMonthDay(p.fields.bloomDate);
        const chillStart = today.slice(5) >= '11-01' ? `${y}-11-01` : `${y - 1}-11-01`;
        const bloom = md ? (`${y}-${md}` <= today ? `${y}-${md}` : `${y - 1}-${md}`) : chillStart;
        const start = bloom < chillStart ? bloom : chillStart;
        try {
          const [now, last] = await Promise.all([
            fetchClimate(p.lat, p.lon, start, true),
            fetchClimate(p.lat, p.lon, shiftYear(start, -1), false, shiftYear(today, -1)),
          ]);
          if (alive) setData(d => ({ ...d, [p.name]: computeClimate(p.name, p.fields, now, last, today) }));
        } catch (e: any) {
          if (alive) setData(d => ({ ...d, [p.name]: { name: p.name, baseC: CLIMATE_LIMITS.defaultBaseC, chill: 0, chillLast: 0, chillStart, frost: { level: 'off', text: '' }, forecast: [], missing: [], error: 'İklim verisi alınamadı (bağlantı)' } }));
        }
      }
      if (alive) setLoading(false);
    })();
    return () => { alive = false; };
  }, [sig]);
  return { data, loading };
}

/* ───────── v49c13: denizden yükseklik (Open-Meteo elevation, koordinattan) ───────── */
const ELEV_KEY = 'miwe_elev_v1';
/** Hopkins biyoklimatik yasası (A. D. Hopkins, 1918): ilkbahar olayları her ~122 m (400 ft) yükseklikte ~4 gün gecikir (≈ 3,3 gün / 100 m). Kaba kural. */
export const HOPKINS_DAYS_PER_M = 4 / 122;
let elevCache: Record<string, number> = (() => { try { return JSON.parse(localStorage.getItem(ELEV_KEY) || '{}'); } catch { return {}; } })();
const ek = (lat: number, lon: number) => `${lat.toFixed(4)},${lon.toFixed(4)}`;
export function useElevations(points: { lat?: number; lon?: number }[]): (number | undefined)[] {
  const [, f] = useState(0);
  const sig = points.map(p => (p.lat && p.lon ? ek(p.lat, p.lon) : '')).join('|');
  useEffect(() => {
    const need = points.filter(p => p.lat && p.lon && elevCache[ek(p.lat, p.lon)] === undefined) as { lat: number; lon: number }[];
    if (!need.length) return;
    let alive = true;
    getJson(`https://api.open-meteo.com/v1/elevation?latitude=${need.map(p => p.lat).join(',')}&longitude=${need.map(p => p.lon).join(',')}`)
      .then((r: { elevation?: number[] }) => {
        (r.elevation || []).forEach((e, i) => { if (typeof e === 'number') elevCache[ek(need[i].lat, need[i].lon)] = Math.round(e); });
        try { localStorage.setItem(ELEV_KEY, JSON.stringify(elevCache)); } catch { /* yoksay */ }
        if (alive) f(x => x + 1);
      }).catch(() => { /* çevrimdışı */ });
    return () => { alive = false; };
  }, [sig]);
  return points.map(p => (p.lat && p.lon ? elevCache[ek(p.lat, p.lon)] : undefined));
}

/* ───────── v50c: dış hava — son 14 gün min/max + şu an (sera karşılaştırması) ───────── */
export interface OutsideRecent { now?: number; days: { date: string; tMin: number; tMax: number }[]; error?: string }
const OUT_KEY = 'miwe_outside_v1';
export function useOutsideRecent(lat?: number, lon?: number): OutsideRecent | undefined {
  const k = lat && lon ? `${lat.toFixed(3)},${lon.toFixed(3)}` : '';
  const [v, setV] = useState<OutsideRecent | undefined>(() => {
    if (!k) return undefined;
    try { const c = JSON.parse(localStorage.getItem(OUT_KEY) || '{}')[k]; return c && Date.now() - c.t < 3 * 3600e3 ? c.v : undefined; } catch { return undefined; }
  });
  useEffect(() => {
    if (!k || v) return;
    let alive = true;
    getJson(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m&daily=temperature_2m_max,temperature_2m_min&past_days=14&forecast_days=1&timezone=auto`)
      .then((r: any) => {
        const d = r.daily || {};
        const out: OutsideRecent = { now: r.current?.temperature_2m, days: (d.time || []).map((t: string, i: number) => ({ date: t, tMin: d.temperature_2m_min?.[i], tMax: d.temperature_2m_max?.[i] })).filter((x: any) => typeof x.tMin === 'number') };
        try { const all = JSON.parse(localStorage.getItem(OUT_KEY) || '{}'); all[k] = { t: Date.now(), v: out }; localStorage.setItem(OUT_KEY, JSON.stringify(all)); } catch { /* yoksay */ }
        if (alive) setV(out);
      }).catch(() => { if (alive) setV({ days: [], error: 'Dış hava alınamadı (çevrimdışı).' }); });
    return () => { alive = false; };
  }, [k]);
  return v;
}
