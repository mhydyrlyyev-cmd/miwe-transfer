# v50e — İklim dönem sonuçları · INTA anlık okuma (v50d dahil; v50d'yi ayrıca uygulama)

1. (v50d) services/muzDaily.ts + components/views/SeraClimate.tsx: "Sera içi iklim · INTA" — sektör başına iç °C, nem %, ısıtma suyu °C, havalandırma %, perde %; dış istasyon.
   Uyarılar: iç < 13 °C / > 36 °C; sektör ortalamadan ≥ 3 °C farklı; ısıtma suyu diğerlerinden ≥ 15 °C yüksek; nem 0 ya da 100 üstü (sensör?).
   Son 14 gün: günün en düşük / en yüksek iç sıcaklığı okumalardan (·n okuma), dış: INTA yoksa hava modeli.
2. services/agroClimate.ts + components/views/ClimateView.tsx — dönem sonuçları:
   · Kış (kasım–şubat): soğuk ihtiyacının şimdiye kadar yüzdesi (bahçenin meyve türlerine göre: kiraz 900, elma 1000, şeftali/nektarin 650 saat…).
   · Kış sonucu (1 Mart–31 Ekim): 1 Kasım–28 Şubat toplamı, geçen kış; tür başına yeterli (≥%100) / sınırda (%75–99) / yetersiz (<%75).
   · İlkbahar sonucu (çiçek dönemi bitince, ekim sonuna kadar): çiçek döneminde don gecesi sayısı (≤ 0 °C; −2 °C altı ayrıca), en düşük sıcaklık ve günü.
3. components/views/OrchardCardsView.tsx — "Hasat pencereleri" kartında sezon sonucu: tahmin (pencere) ile gerçek hasat başlangıcı farkı, çeşit sayısı, ortalama ± gün, en erken / en geç çeşit (2026 ve 2027 başlayanlar).
4. components/views/ManagementViews.tsx — Yönetici masası › Veri sağlığı: "Konumu girilmemiş sera / bahçe".
5. components/auth/LoginView.tsx — yönetici girişindeki eski "Admin Portal" etiketi kaldırıldı.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (7 dosya)
c80fff3456e21999ce356278c739a056af5d28cde1bf25ce7229012055b89b5a  src/services/muzDaily.ts
39edbed5587f0d1f92c51d742e952c82a168adb9c831e595479151fbde8bbe33  src/services/agroClimate.ts
61e1688fbcd0eddeaa6b743731849ce646988d6ef7d9570215b41f5b6afcf6fa  src/components/views/SeraClimate.tsx
1d159f048c08b3c319c7f881ce8c5800712f108f299c659bf769b1094a139a34  src/components/views/ClimateView.tsx
a6fe57fc83ab49f3a852fdc639b8e187103704fa5488f940553265627b91fdf0  src/components/views/OrchardCardsView.tsx
0ad9ce3517f712d4e9741ea3bbdf67bd471f0f6a5e22f55b63b154adab8a3049  src/components/views/ManagementViews.tsx
779c17b134e36078b9e70a73c358b5bb14682a2e73a5ea40dcbb2ef1abbc4c00  src/components/auth/LoginView.tsx
