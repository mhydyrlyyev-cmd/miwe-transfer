/**
 * MIWE HIL — Ürün Kalite Spesifikasyonları & Kabul Toleransları
 * ------------------------------------------------------------------
 * Kural: Eşik / tolerans uydurulmaz; yalnızca bu dosyadaki değerler esas alınır.
 * Değer null ise = tanımsız (kullanıcı veya kalite departmanı belirleyene kadar).
 */

export interface ProductSpec {
  class1MinPct: number | null;
  mechanicalMaxPct: number | null;
  rottenMaxPct: number | null;
  softMaxPct: number | null;
  internalMaxPct: number | null;
  moldMaxPct: number | null;
  coldDamageMaxPct: number | null;
  firmnessMin: number | null;
  firmnessMax: number | null;
  transportTempMinC: number | null;
  transportTempMaxC: number | null;
  /** v3.3 Soğuk zincir hedefleri (null = tanımsız; kalite departmanı belirler) */
  storageTempMinC?: number | null;
  storageTempMaxC?: number | null;
  storageHumidityMinPct?: number | null;
  storageHumidityMaxPct?: number | null;
  /** Ön soğutma sonunda meyve içi sıcaklık üst sınırı */
  precoolPulpMaxC?: number | null;
  /** Ön soğutmanın en uzun süresi (saat) */
  precoolMaxHours?: number | null;
}

/** İki logger ortalaması arasındaki uyarı farkı (°C) */
export const LOGGER_CONFLICT_WARN_C = 2;

export const PRODUCT_SPECS: Record<string, ProductSpec> = {
  Avokado: {
    class1MinPct: 90, // UNECE FFV-42 / Codex CXS 197-1995 — Sınıf I kalite toleransı: sayıca veya ağırlıkça %10
    mechanicalMaxPct: null,
    rottenMaxPct: null,
    softMaxPct: null,
    internalMaxPct: null,
    moldMaxPct: null,
    coldDamageMaxPct: null,
    firmnessMin: null,
    firmnessMax: null,
    transportTempMinC: null,
    transportTempMaxC: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — Alma.pdf (görnüşi #3, 04.03.2026): saklanyş 0…+2 °C; ön sowatma: kamera 4 °C, miwe içi 4–5 °C (madde 17); tirkeg içi 0…+4 °C, 1–10 gün ýol (madde 25). Satyşda +1…+8 °C (satış, taşıma değil).
  Elma: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 4,
    storageTempMinC: 0,
    storageTempMaxC: 2,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — HURMA.pdf (görnüşi #3, 28.03.2026): sowadyjy ammar 0…+1 °C; daşama 0…+3 °C; öňünden sowatma +5 °C-a çenli, miwe içi 4–5 °C (madde 18). Bir aýdan köp saklamak maslahat berilmeýär.
  Hurma: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 3,
    storageTempMinC: 0,
    storageTempMaxC: 1,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — NEKTARIN.pdf (görnüşi #3, 25.04.2026): sowadyjy ammar 0…+2 °C; daşama 0…+3 °C; öňünden sowatma 4…5 °C. (Sunumdaki +2…+4 °C bu belgeyle uyuşmuyor.)
  Nektarin: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 3,
    storageTempMinC: 0,
    storageTempMaxC: 2,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — ŞETDALY.pdf (görnüşi #3, 25.03.2026): sowadyjy ammar 0…+2 °C; daşama 0…+3 °C; öňünden sowatma 4…5 °C. (Sunumdaki +2…+4 °C bu belgeyle uyuşmuyor.)
  Şeftali: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 3,
    storageTempMinC: 0,
    storageTempMaxC: 2,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — Ülje.pdf (görnüşi #3, 07.03.2026): sowadyjy ammar 0 °C (tek hedef değer, ±tolerans ile değerlendirilir); daşama 0…+3 °C; öňünden sowatma: kamera 2 °C, miwe içi 3 °C (hidro-sowatmada 4–3 °C). (Sunumdaki 0…+4 °C bu belgeyle uyuşmuyor.)
  Kiraz: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 3,
    storageTempMinC: 0,
    storageTempMaxC: 0,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 3,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — Banan.pdf (görnüşi #2, 04.04.2026): +13 °C (saklama) … +16 °C (bişme); transport 13,3 °C (tek hedef değer, ±tolerans), RH 80–90 % (taşıma nemi; ayrı alan yok). Ön sowatma hidro usulda, miwe içi için san ýok.
  Muz: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 13.3,
    transportTempMaxC: 13.3,
    storageTempMinC: 13,
    storageTempMaxC: 16,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: null,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — BADAM.pdf (görnüşi #3, 26.03.2026): saklamak 3–10 °C (iň gowusy 4 °C), çyglylyk 45–55 %; ýadro çyglylygy < 6 %; möhleti 2 ýyla çenli. (Ýygym bölüminde '< 10 °C, < 65 %' hem geçýär.)
  Badem: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: null,
    transportTempMaxC: null,
    storageTempMinC: 3,
    storageTempMaxC: 10,
    storageHumidityMinPct: 45,
    storageHumidityMaxPct: 55,
    precoolPulpMaxC: null,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — ARMYT.pdf (görnüşi #3, 25.03.2026): sowadyjy ammar 0…+2 °C; daşama 0…+5 °C; öňünden sowatma 0…+5 °C, miwe içi 4–5 °C (madde 18).
  Armut: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 5,
    storageTempMinC: 0,
    storageTempMaxC: 2,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  // Kaynak: miwe.qcd "Hil standartynyň maglumaty" — GARALY.pdf (görnüşi #3, 03.10.2026): sowadyjy ammar 0…+2 °C; daşama 0…+3 °C; öňünden sowatma +4…+5 °C; Brix 10°-dan başlaýar.
  Erik: {
    class1MinPct: null, mechanicalMaxPct: null, rottenMaxPct: null, softMaxPct: null, internalMaxPct: null,
    moldMaxPct: null, coldDamageMaxPct: null, firmnessMin: null, firmnessMax: null,
    transportTempMinC: 0,
    transportTempMaxC: 3,
    storageTempMinC: 0,
    storageTempMaxC: 2,
    storageHumidityMinPct: null,
    storageHumidityMaxPct: null,
    precoolPulpMaxC: 5,
    precoolMaxHours: null,
  },
  Varsayilan: {
    class1MinPct: null,
    mechanicalMaxPct: null,
    rottenMaxPct: null,
    softMaxPct: null,
    internalMaxPct: null,
    moldMaxPct: null,
    coldDamageMaxPct: null,
    firmnessMin: null,
    firmnessMax: null,
    transportTempMinC: null,
    transportTempMaxC: null,
  },
};

export function getProductSpec(productName?: string): ProductSpec {
  if (!productName) return PRODUCT_SPECS.Varsayilan;
  const match = Object.keys(PRODUCT_SPECS).find(
    k => k.toLowerCase() === productName.trim().toLowerCase()
  );
  return match ? PRODUCT_SPECS[match] : PRODUCT_SPECS.Varsayilan;
}


/**
 * v3.3 — Oda sıcaklığının, kontrolde girilen AYAR sıcaklığından izin verilen sapması (°C).
 * Bu bir standart değil, işletme toleransıdır; kalite departmanı değiştirebilir.
 */
export const SETPOINT_TOLERANCE_C = 1.0;

/** v3.3 — Ürün adına göre spesifikasyon (çeşit parantezi yok sayılır; tanım yoksa Varsayilan = hepsi boş) */
const PRODUCT_ALIASES: Record<string, string> = {
  alma: 'Elma', elma: 'Elma', apple: 'Elma',
  hurma: 'Hurma', persimmon: 'Hurma', 'trabzon hurması': 'Hurma',
  nektarin: 'Nektarin', nectarine: 'Nektarin',
  'şetdaly': 'Şeftali', 'şeftali': 'Şeftali', peach: 'Şeftali',
  'ülje': 'Kiraz', 'çereşnýa': 'Kiraz', kiraz: 'Kiraz', cherry: 'Kiraz',
  banan: 'Muz', muz: 'Muz', banana: 'Muz',
  badam: 'Badem', badem: 'Badem', almond: 'Badem',
  armyt: 'Armut', armut: 'Armut', pear: 'Armut',
  garaly: 'Erik', erik: 'Erik', plum: 'Erik',
  avokado: 'Avokado', avocado: 'Avokado'
};

/** v3.3 — Ürün adına göre spesifikasyon (çeşit parantezi yok sayılır; Türkmence/İngilizce adlar eşleşir; yoksa Varsayilan = hepsi boş) */
export function specForProduct(product?: string): ProductSpec {
  const base = (product || '').replace(/\s*\(.*\)\s*$/, '').trim();
  const alias = PRODUCT_ALIASES[base.toLocaleLowerCase('tr')];
  return getProductSpec(alias || base);
}
