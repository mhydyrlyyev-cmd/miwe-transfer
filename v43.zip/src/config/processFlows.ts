/**
 * v4.3 — Ürüne özel süreç akışları.
 *  MUZ  : Kesim → Paket → Muhafaza 1 → Sevk → Muhafaza 2 (lojistik merkezi) → Sarartma → Satış
 *  BADEM: Hasat öncesi test → Sulama kesildi → Kombayn hasadı → Kabuk (hull) temizleme → Serme / kurutma
 *         → Nem kontrolü → Karar (kabuklu depo / kırım)
 * MIWE iç standardı (muz sarartma): 14 °C · 35 ppm etilen · 8 gün · çıkış rengi 1–7 skalasında hedef 3.
 * Badem hasat kararı: kabuk açılması ≥ %75 ve iç nem ≈ %12 → sulama kesilir.
 * Badem depo (UNECE): kabuklu tüm meyve nemi ≤ %11,0 veya iç ≤ %7,0.
 */
export type FlowKey = 'MUZ' | 'BADEM';

export interface FlowField {
  key: string;
  label: string;
  unit?: string;
  type: 'number' | 'text' | 'select';
  def?: number | string;
  min?: number; max?: number; step?: number;
  options?: { value: string; label: string }[];
}

export interface FlowStep {
  key: string;
  label: string;
  short: string;
  hint?: string;
  fields?: FlowField[];
  timed?: boolean;            // başlat / bitir (ör. sarartma)
  auto?: 'MUZ_RECORD' | 'AMBAR_BEFORE_SHIP' | 'LOJISTIK' | 'AMBAR_AFTER_SHIP' | 'SALES';
}

export const RIPENING = { tempC: 14, ppm: 35, days: 8, targetColor: 3 };
export const BADEM_LIMITS = { hullSplitMin: 75, kernelMoistureHarvest: 12, wholeMax: 11, kernelMax: 7 };

export const FLOWS: Record<FlowKey, { title: string; steps: FlowStep[] }> = {
  MUZ: {
    title: 'Muz akışı (7 adım)',
    steps: [
      { key: 'KESIM', label: 'Kesim', short: 'Kesim', auto: 'MUZ_RECORD', hint: 'Muz kalite kaydı (kesim) açılınca otomatik işaretlenir.' },
      { key: 'PAKET', label: 'Paketleme', short: 'Paket', auto: 'MUZ_RECORD', fields: [{ key: 'boxes', label: 'Kutu sayısı', type: 'number', min: 0 }] },
      { key: 'MUHAFAZA1', label: 'Muhafaza 1 (sera / pakethane)', short: 'Muh. 1', auto: 'AMBAR_BEFORE_SHIP', fields: [{ key: 'tempC', label: 'Oda sıcaklığı', unit: '°C', type: 'number', def: 14, step: 0.1 }] },
      { key: 'SEVK', label: 'Sevk', short: 'Sevk', auto: 'LOJISTIK' },
      { key: 'MUHAFAZA2', label: 'Muhafaza 2 (lojistik merkezi)', short: 'Muh. 2', auto: 'AMBAR_AFTER_SHIP', fields: [{ key: 'tempC', label: 'Oda sıcaklığı', unit: '°C', type: 'number', def: 14, step: 0.1 }] },
      {
        key: 'SARARTMA', label: 'Sarartma', short: 'Sarartma', timed: true,
        hint: `Standart: ${RIPENING.tempC} °C · ${RIPENING.ppm} ppm etilen · ${RIPENING.days} gün · çıkış rengi hedef ${RIPENING.targetColor}/7. Erken çıkışta akt açılır.`,
        fields: [
          { key: 'room', label: 'Oda', type: 'text' },
          { key: 'tempC', label: 'Sıcaklık', unit: '°C', type: 'number', def: RIPENING.tempC, step: 0.1 },
          { key: 'ppm', label: 'Etilen', unit: 'ppm', type: 'number', def: RIPENING.ppm, step: 1 },
          { key: 'plannedDays', label: 'Planlanan süre', unit: 'gün', type: 'number', def: RIPENING.days, step: 1, min: 1, max: 20 },
        ],
      },
      { key: 'SATIS', label: 'Satış', short: 'Satış', auto: 'SALES' },
    ],
  },
  BADEM: {
    title: 'Badem akışı',
    steps: [
      { key: 'TEST', label: 'Hasat öncesi test', short: 'Test',
        hint: `Kabuk açılması ≥ %${BADEM_LIMITS.hullSplitMin} ve iç nem ≈ %${BADEM_LIMITS.kernelMoistureHarvest} → sulama kesilir.`,
        fields: [
          { key: 'hullSplitPct', label: 'Kabuk (hull) açılması', unit: '%', type: 'number', min: 0, max: 100, step: 1 },
          { key: 'kernelMoisturePct', label: 'İç nemi', unit: '%', type: 'number', min: 0, max: 60, step: 0.1 },
        ] },
      { key: 'SULAMA', label: 'Sulama kesildi', short: 'Sulama' },
      { key: 'KOMBAYN', label: 'Kombayn hasadı', short: 'Hasat', fields: [{ key: 'kg', label: 'Hasat', unit: 'kg', type: 'number', min: 0 }] },
      { key: 'HULL', label: 'Kabuk (hull) temizleme', short: 'Hull' },
      { key: 'KURUTMA', label: 'Serme / kurutma', short: 'Kurutma', fields: [{ key: 'days', label: 'Kurutma süresi', unit: 'gün', type: 'number', min: 0, step: 1 }] },
      { key: 'NEM', label: 'Nem kontrolü', short: 'Nem',
        hint: `UNECE: kabuklu tüm meyve ≤ %${BADEM_LIMITS.wholeMax} veya iç ≤ %${BADEM_LIMITS.kernelMax}.`,
        fields: [
          { key: 'wholeMoisturePct', label: 'Tüm meyve nemi', unit: '%', type: 'number', min: 0, max: 40, step: 0.1 },
          { key: 'kernelMoisturePct', label: 'İç nemi', unit: '%', type: 'number', min: 0, max: 40, step: 0.1 },
        ] },
      { key: 'KARAR', label: 'Karar', short: 'Karar',
        fields: [{ key: 'decision', label: 'Gideceği yer', type: 'select', options: [
          { value: 'INSHELL_DEPO', label: 'Kabuklu (inshell) depo — etiketlenir' },
          { value: 'KIRIM', label: 'Badem işleme (kırım)' },
          { value: 'KURUTMA_GERI', label: 'Kurutmaya geri' },
        ] }] },
    ],
  },
};

/** Badem hasat öncesi testten öneri */
export function bademHarvestAdvice(hull?: number, kernel?: number): { ok: boolean; text: string } | null {
  if (hull == null || isNaN(hull)) return null;
  const okHull = hull >= BADEM_LIMITS.hullSplitMin;
  const okKernel = kernel == null || isNaN(kernel) ? true : kernel <= BADEM_LIMITS.kernelMoistureHarvest + 0.5;
  return okHull && okKernel
    ? { ok: true, text: 'Sulama kesilebilir; hasada hazırlanın.' }
    : { ok: false, text: !okHull ? `Kabuk açılması %${BADEM_LIMITS.hullSplitMin} altında — bekleyin.` : 'İç nem yüksek — bekleyin.' };
}

/** Badem nem kontrolünden öneri */
export function bademMoistureAdvice(whole?: number, kernel?: number): { ok: boolean; text: string } | null {
  const hasW = whole != null && !isNaN(whole); const hasK = kernel != null && !isNaN(kernel);
  if (!hasW && !hasK) return null;
  const ok = (hasW && (whole as number) <= BADEM_LIMITS.wholeMax) || (hasK && (kernel as number) <= BADEM_LIMITS.kernelMax);
  return ok ? { ok: true, text: 'Kabuklu depoya uygun (UNECE nem sınırı içinde).' } : { ok: false, text: 'Nem yüksek — kurutmaya geri veya kırıma.' };
}
