# v43 — Muz 7 adım + badem akışı + "()" temizliği

Uygulama sırası: v42'den SONRA. Dosyaları AYNEN (byte-identical) kopyala. Firestore kuralı DEĞİŞMEDİ.

## 1) Muz akışı (Ana menü › Diğer modüller › "Muz akışı (7 adım)")
Kesim → Paket → Muhafaza 1 → Sevk → Muhafaza 2 (lojistik merkezi) → Sarartma → Satış.
- Otomatik: Kesim/Paket = muz kalite kaydı; Muhafaza 1 = sevkten önceki depo kabulü; Sevk = lojistik kaydı;
  Muhafaza 2 = sevkten sonraki depo kabulü; Satış = satış kaydı. Gerekirse "Elle işaretle".
- **Sarartma (MIWE iç standardı):** Başlat → varsayılan 14 °C · 35 ppm · 8 gün, oda no. Bitir → çıkış rengi (1–7, hedef 3).
  8 günden önce bitirilirse **neden zorunlu** ve "akt formunu aç" seçeneği (varsayılan açık) → kayıttan sonra olay formu
  aynı RefID ile açılır. Listede "Sarartmada 5. gün", süre aşılınca kırmızı "süre aşıldı".
## 2) Badem akışı (Ana menü › Diğer modüller › "Badem akışı")
Hasat öncesi test → Sulama kesildi → Kombayn hasadı → Kabuk (hull) temizleme → Serme / kurutma → Nem kontrolü → Karar.
- Test: kabuk açılması % ve iç nem % → "Sulama kesilebilir" (≥%75 ve ≈%12) veya "bekleyin".
- Nem kontrolü: UNECE kabuklu ≤%11 (tüm meyve) veya ≤%7 (iç) → "kabuklu depoya uygun" / "kurutmaya geri veya kırım".
- Karar: Kabuklu (inshell) depo — etiketlenir / Badem işleme (kırım) / Kurutmaya geri.
## 3) Veri
- Adımlar partinin kaydında `processSteps` listesine yazılır (references koleksiyonu, mevcut kural yeterli).
- Her adım denetim izine düşer ("processStep: MUZ:SARARTMA" vb.).
## 4) Küçük düzeltme
- Bekleyen işlemler ve Referanslar listelerinde "Meyve / Genel Ürün ()" → "Meyve / Genel Ürün".
- Not: ☰ menüsündeki "bekleyen işlem" ile Operasyonel sekme sayısı aynı formülle hesaplanıyor (kod kontrol edildi);
  ekran görüntüsündeki 5 / 6 farkı veri yüklenme anından olabilir — yeniden görülürse ekran görüntüsü gönderin.
## Bu yamada YOK
- Yönetici sayfası ve denetim izi sadeleştirmesi: mevcut ekranların ekran görüntüleri gelince yapılacak.

## Dosyalar
src/types.ts · src/config/processFlows.ts (YENİ) · src/components/flows/ProcessFlowModal.tsx (YENİ) · src/App.tsx ·
src/components/portal/HomeMenu.tsx · src/components/views/PendingOperationsView.tsx · src/components/views/ReferencesView.tsx

## Kabul testleri
1. Ana menü › Diğer modüller'de "Muz akışı (7 adım)" ve "Badem akışı" kutuları açılıyor; muz/badem partileri listeleniyor.
2. Muz partisinde Sarartma → Başlat (14 / 35 / 8 varsayılan) → kaydet; listede "Sarartmada 0. gün".
3. Aynı gün Bitir → erken çıkış uyarısı, neden yazmadan kaydetmiyor; neden + akt seçili → kayıttan sonra olay formu RefID dolu açılıyor.
4. Badem: Test'e 82 / 11,8 girince "Sulama kesilebilir"; Nem'e 10,5 girince "kabuklu depoya uygun".
5. Bekleyen işlemler listesinde "()" yok.
6. TypeScript derleme hatası yok.
