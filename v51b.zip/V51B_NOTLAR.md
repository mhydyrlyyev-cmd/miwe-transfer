# V51b — v51 + muz aktları sera sayfasından kaldırıldı (yalnız Yönetim'de). v51 ayrıca uygulanmaz.

- `src/services/muzDaily.ts` — `d0b186c238b4f78079e19cba24273ae97d3bfac1e65f08518ae9ac1054b1deed`
- `src/components/views/MuzPanel.tsx` — `403608d63e130f87edbcf0e65cd04c410667fdf9278c7e92c120e3464918f4b8`
- `src/config/fieldCrops.ts` — `0357f4722885c37284b52f04b0c6e632ad7239acae4524b827b905f8cb2e6ac1`
- `src/services/fieldDaily.ts` — `be650a9aca461868c674d65e88446c2d4088aaebcb261b55d29a214b7994ee83`
- `src/components/views/FieldPanel.tsx` — `5920cfe655fb67fbb0ec0bb7e2586dbe4d80527e5b5ca394fb103436c62b0880`
- `src/components/views/OrchardCardsView.tsx` — `3aae3a87b22fdc48a67b4dfa5c59d9ca3936293469c6e7663963ecbcb5247389`
- `src/components/dashboard/HomeDashboard.tsx` — `4d8447632ff3854768d5f29f2f28fa39e5b432d109ff1e7eaa5b8a58eed2352d`

Yeni: fieldCrops.ts, fieldDaily.ts, FieldPanel.tsx. Firestore kuralı değişmedi. TAM_LISTE: 204.
