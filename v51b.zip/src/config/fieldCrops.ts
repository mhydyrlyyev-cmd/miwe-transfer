/**
 * v51 — Açık ekin (Garahan) · ekin düzeyinde plan. Kaynak: Açyk ekin býujet 2027 (19.11.26), plan senaryosu.
 * Ekim ve hasat dönemleri bütçedeki "Tohum" ve "Hasat" aylarından; sınıflar GELIR sayfasındaki kalibre / sort paylarından.
 * Parsel listesi gelirse her ekinin altına eklenir; yapı değişmez.
 */
export interface FieldGrade { key: string; label: string; share: number }
export interface FieldCrop {
  id: string; name: string; product: string;
  sowFrom: string; sowTo: string;          // planlanan ekim dönemi (YYYY-AA-GG)
  harvestFrom: string; harvestTo: string;  // bütçedeki hasat dönemi
  ha: number; tPerHa: number; tPerHaReal: number;
  grades: FieldGrade[];
  harvestYear: number;
}
const ONION: FieldGrade[] = [
  { key: 'Extra', label: 'Extra 90+ mm', share: 0.07 }, { key: 'Exclusive', label: 'Exclusive 60–90 mm', share: 0.45 },
  { key: 'Premium', label: 'Premium 40–60 mm', share: 0.30 }, { key: 'Classic', label: 'Classic 30–40 mm', share: 0.13 }, { key: 'Mix', label: 'Mix', share: 0.05 },
];
const SORT3: FieldGrade[] = [{ key: 'I', label: 'I-sort', share: 0.65 }, { key: 'II', label: 'II-sort', share: 0.32 }, { key: 'Mix', label: 'Mix', share: 0.03 }];
export const FIELD_UNIT = 'Açyk ekin (Garahan)';
export const FIELD_SOURCE = 'Açyk ekin býujet 2027 (19.11.26) · plan senaryosu';
export const FIELD_CROPS: FieldCrop[] = [
  { id: 'sogan-guyz-26', name: 'Sogan · güýz 2026 ekişi', product: 'Sogan', sowFrom: '2026-09-01', sowTo: '2026-09-30', harvestFrom: '2027-06-01', harvestTo: '2027-06-30', ha: 40, tPerHa: 35, tPerHaReal: 35, grades: [{ key: 'I', label: 'I-sort', share: 0.7 }, { key: 'II', label: 'II-sort', share: 0.3 }], harvestYear: 2027 },
  { id: 'sogan-subat-27', name: 'Sogan · şubat ekişi', product: 'Sogan', sowFrom: '2027-02-01', sowTo: '2027-02-28', harvestFrom: '2027-08-01', harvestTo: '2027-09-30', ha: 118, tPerHa: 40, tPerHaReal: 35, grades: ONION, harvestYear: 2027 },
  { id: 'patates-subat-27', name: 'Patates · şubat ekişi', product: 'Patates', sowFrom: '2027-02-01', sowTo: '2027-02-28', harvestFrom: '2027-06-01', harvestTo: '2027-07-31', ha: 55, tPerHa: 25, tPerHaReal: 20, grades: SORT3, harvestYear: 2027 },
  { id: 'gara-jowen-27', name: 'Gara jowen', product: 'Gara jowen', sowFrom: '2027-03-01', sowTo: '2027-03-31', harvestFrom: '2027-07-01', harvestTo: '2027-07-31', ha: 20, tPerHa: 5, tPerHaReal: 4, grades: [], harvestYear: 2027 },
  { id: 'gyzyl-sugundyr-27', name: 'Gyzyl şugundyr', product: 'Gyzyl şugundyr', sowFrom: '2027-03-01', sowTo: '2027-03-31', harvestFrom: '2027-09-01', harvestTo: '2027-09-30', ha: 10, tPerHa: 50, tPerHaReal: 40, grades: [], harvestYear: 2027 },
  { id: 'mekge-27', name: 'Mekge', product: 'Mekge', sowFrom: '2027-04-01', sowTo: '2027-04-30', harvestFrom: '2027-09-01', harvestTo: '2027-09-30', ha: 50, tPerHa: 10, tPerHaReal: 7.5, grades: [], harvestYear: 2027 },
  { id: 'patates-awgust-27', name: 'Patates · awgust ekişi', product: 'Patates', sowFrom: '2027-08-01', sowTo: '2027-08-31', harvestFrom: '2027-11-01', harvestTo: '2027-12-31', ha: 50, tPerHa: 20, tPerHaReal: 15, grades: SORT3, harvestYear: 2027 },
  { id: 'sogan-guyz-27', name: 'Sogan · güýz 2027 ekişi (sary + mor)', product: 'Sogan', sowFrom: '2027-09-01', sowTo: '2027-09-30', harvestFrom: '2028-06-01', harvestTo: '2028-06-30', ha: 50, tPerHa: 35, tPerHaReal: 35, grades: [
    { key: 'Extra', label: 'Extra 90+ mm', share: 0.05 }, { key: 'Exclusive', label: 'Exclusive 60–90 mm', share: 0.425 }, { key: 'Premium', label: 'Premium 40–60 mm', share: 0.35 }, { key: 'Classic', label: 'Classic 30–40 mm', share: 0.125 }, { key: 'Mix', label: 'Mix', share: 0.05 }], harvestYear: 2028 },
  { id: 'sarymsak-okt-27', name: 'Sarymsak · oktýabr 2027 ekişi', product: 'Sarymsak', sowFrom: '2027-10-01', sowTo: '2027-10-31', harvestFrom: '2028-06-01', harvestTo: '2028-06-30', ha: 5, tPerHa: 15, tPerHaReal: 7, grades: SORT3, harvestYear: 2028 },
];
