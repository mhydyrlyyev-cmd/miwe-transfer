/**
 * v51 — Açık ekin günlüğü (ekin düzeyinde): ekim kaydı, hasat girişi (kg + sınıf), depo girişi / kayıp, "hasat bitti".
 * Kayıt: Firestore 'ganttParcels' (calV: 'TARLA'; kural değişmez) + yerel önbellek. Plan: config/fieldCrops.ts (bütçe).
 */
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import { FIELD_CROPS, type FieldCrop } from '../config/fieldCrops';

export type FieldKind = 'sow' | 'harv' | 'store' | 'loss' | 'done';
export interface FieldDoc { id: string; calV: 'TARLA'; kind: FieldKind; crop: string; date: string; ha?: number; kg?: number; grades?: Record<string, number>; depo?: string; reason?: string; note?: string; removed?: boolean; at: string; by?: string }

const LS = 'miwe_tarla_v1';
let store: FieldDoc[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: FieldDoc[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'TARLA') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || String(r.at) > String(l.at)) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useFieldDocs(): FieldDoc[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store.filter(d => !d.removed);
}
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
async function put(doc: FieldDoc) {
  store = [...store.filter(s => s.id !== doc.id), doc]; emit();
  try { return await saveRecordToFirestore('GANTT', doc as any); } catch { return false; }
}
export const addFieldDoc = (d: Omit<FieldDoc, 'id' | 'calV' | 'at'>, by?: string) =>
  put({ ...d, id: d.kind === 'sow' || d.kind === 'done' ? `tarla-${d.kind}-${d.crop}` : `tarla-${d.kind}-${d.crop}-${uid()}`, calV: 'TARLA', at: new Date().toISOString(), by });
export const removeFieldDoc = (d: FieldDoc, by?: string) => put({ ...d, removed: true, at: new Date().toISOString(), by });

const DAY = 86400000;
const ms = (iso: string) => Date.parse(`${iso}T00:00:00`);
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const addD = (iso: string, n: number) => { const d = new Date(ms(iso) + n * DAY); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

export type FieldState = 'plan' | 'ekildi' | 'hasat yakın' | 'hasatta' | 'bitti';
export interface FieldStatus {
  crop: FieldCrop; sow?: FieldDoc; done?: FieldDoc;
  planKg: number; ha: number; hFrom: string; hTo: string; shiftDays: number;
  harvKg: number; harvests: FieldDoc[]; gradesKg: Record<string, number>;
  storedKg: number; lostKg: number; state: FieldState; daysTo: number; pct: number;
}
/** Ekin durumu: ekim kaydı girildiyse hasat dönemi gerçek ekim tarihine göre kayar (plan ekim başına göre fark) */
export function fieldStatus(crop: FieldCrop, docs: FieldDoc[], today = todayISO()): FieldStatus {
  const mine = docs.filter(d => d.crop === crop.id);
  const sow = mine.find(d => d.kind === 'sow');
  const done = mine.find(d => d.kind === 'done');
  const shiftDays = sow ? Math.round((ms(sow.date) - ms(crop.sowFrom)) / DAY) : 0;
  const hFrom = addD(crop.harvestFrom, shiftDays), hTo = addD(crop.harvestTo, shiftDays);
  const ha = sow?.ha || crop.ha;
  const planKg = ha * crop.tPerHa * 1000;
  const harvests = mine.filter(d => d.kind === 'harv').sort((a, b) => b.date.localeCompare(a.date));
  const harvKg = harvests.reduce((s, d) => s + (d.kg || 0), 0);
  const gradesKg: Record<string, number> = {};
  for (const h of harvests) for (const [k, v] of Object.entries(h.grades || {})) gradesKg[k] = (gradesKg[k] || 0) + (Number(v) || 0);
  const storedKg = mine.filter(d => d.kind === 'store').reduce((s, d) => s + (d.kg || 0), 0);
  const lostKg = mine.filter(d => d.kind === 'loss').reduce((s, d) => s + (d.kg || 0), 0);
  const daysTo = Math.round((ms(hFrom) - ms(today)) / DAY);
  const state: FieldState = done ? 'bitti' : harvKg > 0 || (today >= hFrom && today <= hTo) ? 'hasatta' : daysTo >= 0 && daysTo <= 15 ? 'hasat yakın' : sow ? 'ekildi' : 'plan';
  return { crop, sow, done, planKg, ha, hFrom, hTo, shiftDays, harvKg, harvests, gradesKg, storedKg, lostKg, state, daysTo, pct: planKg ? Math.round((harvKg / planKg) * 100) : 0 };
}
export function useFieldStatuses(): FieldStatus[] {
  const docs = useFieldDocs();
  return FIELD_CROPS.map(c => fieldStatus(c, docs));
}
