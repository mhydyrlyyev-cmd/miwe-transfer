import React, { useState } from 'react';
import { Sprout, ChevronDown, X, Warehouse } from 'lucide-react';
import { FIELD_SOURCE, type FieldCrop } from '../../config/fieldCrops';
import { useFieldStatuses, addFieldDoc, removeFieldDoc, type FieldStatus, type FieldState } from '../../services/fieldDaily';

/** v51 — Açık ekin (ekin düzeyinde): takvim · ekim kaydı · hasat girişi (sınıf) · depo / kayıp. Plan bütçeden. */
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const dm = (iso: string) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}`;
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const inp = 'w-full min-h-[36px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm tabular-nums';
const btn = 'min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer';
const STATE: Record<FieldState, string> = {
  plan: 'bg-slate-100 text-slate-600 border-slate-200', ekildi: 'bg-sky-50 text-sky-800 border-sky-200', 'hasat yakın': 'bg-amber-50 text-amber-800 border-amber-300',
  hasatta: 'bg-teal-50 text-teal-800 border-teal-300', bitti: 'bg-emerald-50 text-emerald-800 border-emerald-200',
};
const num = (x: string) => Number(String(x).replace(',', '.')) || 0;

function Editor({ s, by, readOnly }: { s: FieldStatus; by: string; readOnly?: boolean }) {
  const c: FieldCrop = s.crop;
  const [sow, setSow] = useState({ date: s.sow?.date || '', ha: s.sow?.ha ? String(s.sow.ha) : String(c.ha) });
  const [h, setH] = useState<{ date: string; kg: string; g: Record<string, string> }>({ date: today(), kg: '', g: {} });
  const [st, setSt] = useState({ kind: 'store' as 'store' | 'loss', kg: '', depo: '', reason: '' });
  const gSum = Object.values(h.g).reduce((a, v) => a + num(v), 0);
  const kgVal = num(h.kg) || gSum;
  const totalG = Object.values(s.gradesKg).reduce((a, v) => a + v, 0);
  return (
    <div className="space-y-3 text-xs">
      <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-400">
        <div>Plan ekim: <b>{dm(c.sowFrom)}–{dm(c.sowTo)}</b></div><div>Hasat (bütçe): <b>{dm(c.harvestFrom)}–{dm(c.harvestTo)}</b></div>
        <div>Verim: <b>{c.tPerHa} t/ha</b> · gerçekçi {c.tPerHaReal}</div><div>Plan: <b>{t1(s.planKg)} t</b>{s.shiftDays ? ` · hasat ${s.shiftDays > 0 ? '+' : ''}${s.shiftDays} gün kaydı` : ''}</div>
      </div>
      {!readOnly && (
        <div>
          <div className="text-[10px] text-slate-500 mb-0.5">Ekim kaydı{s.sow ? ` · girildi ${dm(s.sow.date)}` : ''}</div>
          <div className="grid grid-cols-[minmax(0,1fr)_72px_auto] gap-1.5">
            <input type="date" aria-label="Ekim tarihi" value={sow.date} onChange={e => setSow({ ...sow, date: e.target.value })} className={inp} />
            <input inputMode="decimal" aria-label="Ekilen ha" value={sow.ha} onChange={e => setSow({ ...sow, ha: e.target.value })} className={inp} />
            <button type="button" disabled={!sow.date || !num(sow.ha)} onClick={() => addFieldDoc({ kind: 'sow', crop: c.id, date: sow.date, ha: num(sow.ha) }, by)} className={btn}>Kaydet</button>
          </div>
        </div>
      )}
      <div>
        <div className="text-[10px] text-slate-500 mb-0.5">Hasat girişi (günlük){c.grades.length ? ' · sınıf kg girilirse toplam kendiliğinden' : ''}</div>
        {!readOnly && (
          <div className="space-y-1.5">
            <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] gap-1.5">
              <input type="date" aria-label="Hasat günü" value={h.date} max={today()} onChange={e => setH({ ...h, date: e.target.value })} className={inp} />
              <input inputMode="decimal" placeholder={gSum ? String(Math.round(gSum)) : 'toplam kg'} aria-label="Toplam kg" value={h.kg} onChange={e => setH({ ...h, kg: e.target.value })} className={inp} />
              <button type="button" disabled={!kgVal || !h.date} onClick={async () => { await addFieldDoc({ kind: 'harv', crop: c.id, date: h.date, kg: kgVal, grades: gSum ? Object.fromEntries(Object.entries(h.g).filter(([, v]) => num(v)).map(([k, v]) => [k, num(v)])) : undefined }, by); setH({ date: h.date, kg: '', g: {} }); }} className={btn}>Ekle</button>
            </div>
            {c.grades.length > 0 && (
              <div className="grid grid-cols-3 gap-1.5">{c.grades.map(g => (
                <label key={g.key} className="text-[10px] text-slate-500 truncate">{g.label}<input inputMode="decimal" value={h.g[g.key] || ''} onChange={e => setH({ ...h, g: { ...h.g, [g.key]: e.target.value } })} className={inp} /></label>))}
              </div>
            )}
          </div>
        )}
        {s.harvests.length > 0 && (
          <ul className="mt-1.5 space-y-0.5">{s.harvests.slice(0, 6).map(d => (
            <li key={d.id} className="flex items-center gap-2 text-[11px] tabular-nums"><span className="w-10">{dm(d.date)}</span><b>{t1(d.kg || 0)} t</b>
              <span className="flex-1 truncate text-slate-500">{d.grades ? Object.entries(d.grades).map(([k, v]) => `${k} ${t1(v)}`).join(' · ') : ''}</span>
              {!readOnly && <button type="button" aria-label="Sil" onClick={() => removeFieldDoc(d, by)} className="text-slate-400 cursor-pointer"><X className="w-3.5 h-3.5" /></button>}</li>))}
            {s.harvests.length > 6 && <li className="text-[10px] text-slate-400">+{s.harvests.length - 6} giriş daha</li>}
          </ul>
        )}
      </div>
      {c.grades.length > 0 && totalG > 0 && (
        <div>
          <div className="text-[10px] text-slate-500 mb-0.5">Sınıf: gerçek / plan</div>
          {c.grades.map(g => { const real = (s.gradesKg[g.key] || 0) / totalG; return (
            <div key={g.key} className="grid grid-cols-[110px_minmax(0,1fr)_72px] gap-2 items-center text-[11px] tabular-nums">
              <span className="truncate">{g.label}</span>
              <div className="relative h-2 rounded bg-slate-100 dark:bg-slate-800"><div className="absolute inset-y-0 left-0 rounded bg-teal-600" style={{ width: `${real * 100}%` }} /><div className="absolute -top-0.5 h-3 w-0.5 bg-slate-700" style={{ left: `${g.share * 100}%` }} /></div>
              <span className={`text-right ${real < g.share - 0.05 && ['Extra', 'Exclusive', 'I'].includes(g.key) ? 'text-amber-700' : ''}`}>%{Math.round(real * 100)} / %{Math.round(g.share * 100)}</span>
            </div>); })}
        </div>
      )}
      <div>
        <div className="text-[10px] text-slate-500 mb-0.5 flex items-center gap-1"><Warehouse className="w-3.5 h-3.5" />Depo · kayıp{s.storedKg || s.lostKg ? ` — depoda ${t1(s.storedKg)} t · kayıp ${t1(s.lostKg)} t` : ''}</div>
        {!readOnly && (
          <div className="grid grid-cols-[auto_70px_minmax(0,1fr)_auto] gap-1.5">
            <select aria-label="Tür" value={st.kind} onChange={e => setSt({ ...st, kind: e.target.value as 'store' | 'loss' })} className={inp}><option value="store">Depoya</option><option value="loss">Kayıp</option></select>
            <input inputMode="decimal" placeholder="kg" aria-label="kg" value={st.kg} onChange={e => setSt({ ...st, kg: e.target.value })} className={inp} />
            <input placeholder={st.kind === 'store' ? 'depo / oda' : 'neden (çürük, kurutma…)'} aria-label={st.kind === 'store' ? 'Depo' : 'Neden'} value={st.kind === 'store' ? st.depo : st.reason} onChange={e => setSt(st.kind === 'store' ? { ...st, depo: e.target.value } : { ...st, reason: e.target.value })} className={inp} />
            <button type="button" disabled={!num(st.kg)} onClick={async () => { await addFieldDoc({ kind: st.kind, crop: c.id, date: today(), kg: num(st.kg), depo: st.depo || undefined, reason: st.reason || undefined }, by); setSt({ ...st, kg: '' }); }} className={btn}>Ekle</button>
          </div>
        )}
      </div>
      {!readOnly && s.harvKg > 0 && (
        <button type="button" onClick={() => (s.done ? removeFieldDoc(s.done, by) : addFieldDoc({ kind: 'done', crop: c.id, date: today() }, by))} className="w-full min-h-[34px] rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer">{s.done ? 'Hasadı yeniden aç' : `Hasat bitti (${t1(s.harvKg)} t · planın %${s.pct}'i)`}</button>
      )}
    </div>
  );
}

export default function FieldPanel({ by = '', readOnly }: { by?: string; readOnly?: boolean }) {
  const all = useFieldStatuses();
  const [open, setOpen] = useState<string | null>(null);
  const [y, setY] = useState<2027 | 2028>(2027);
  const list = all.filter(s => s.crop.harvestYear === y).sort((a, b) => a.hFrom.localeCompare(b.hFrom));
  const plan = list.reduce((a, s) => a + s.planKg, 0), got = list.reduce((a, s) => a + s.harvKg, 0), ha = list.reduce((a, s) => a + s.ha, 0);
  const months = Array.from({ length: 12 }, (_, m) => list.reduce((a, s) => {
    const from = new Date(`${s.hFrom}T00:00:00`), to = new Date(`${s.hTo}T00:00:00`);
    const n = (to.getFullYear() - from.getFullYear()) * 12 + to.getMonth() - from.getMonth() + 1;
    let hit = 0; for (let i = 0; i < n; i++) { const d = new Date(from.getFullYear(), from.getMonth() + i, 1); if (d.getFullYear() === y && d.getMonth() === m) hit = 1; }
    return a + (hit ? s.planKg / n : 0);
  }, 0));
  const maxM = Math.max(...months, 1);
  const MON = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
  return (
    <>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{y} hasat planı</div><div className="text-lg font-bold tabular-nums">{t1(plan)} t</div><div className="text-[11px] text-slate-500">{ha.toLocaleString('tr-TR')} ha · {list.length} ekin</div></div>
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">Toplanan</div><div className="text-lg font-bold tabular-nums">{got ? `${t1(got)} t` : '—'}</div><div className="text-[11px] text-slate-500">{got ? `planın %${Math.round((got / plan) * 100)}'i` : 'hasat girişi yok'}</div></div>
      </div>
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
        <div className="flex items-center justify-between mb-1.5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Sprout className="w-4 h-4 text-teal-700" />Ekinler · hasat takvimi</h2>
          <div className="flex gap-1">{([2027, 2028] as const).map(v => <button key={v} type="button" onClick={() => setY(v)} className={`px-2.5 min-h-[28px] rounded-full text-[11px] font-semibold border cursor-pointer ${y === v ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 text-slate-600'}`}>{v} hasadı</button>)}</div>
        </div>
        <div className="grid grid-cols-12 gap-0.5 items-end h-10">{months.map((x, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: x ? `${Math.max(8, (x / maxM) * 100)}%` : 2, opacity: x ? 1 : 0.15 }} />)}</div>
        <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mb-2">{MON.map((m, i) => <span key={m}>{m}{months[i] ? <b className="block text-slate-700 dark:text-slate-300">{Math.round(months[i] / 1000)}</b> : null}</span>)}</div>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{list.map(s => {
          const isO = open === s.crop.id;
          const when = s.state === 'bitti' ? `bitti · ${t1(s.harvKg)} t` : s.state === 'hasatta' ? `${t1(s.harvKg)} / ${t1(s.planKg)} t` : s.daysTo > 0 ? `${s.daysTo} gün kaldı` : '';
          return (
            <li key={s.crop.id} className="py-2">
              <button type="button" onClick={() => setOpen(isO ? null : s.crop.id)} className="w-full text-left cursor-pointer">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold min-w-0 flex-1 truncate">{s.crop.name}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${STATE[s.state]}`}>{s.state}</span>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 ${isO ? 'rotate-180' : ''}`} />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-400 tabular-nums mt-0.5">
                  <span>{s.ha} ha · hasat {dm(s.hFrom)}–{dm(s.hTo)} · plan {t1(s.planKg)} t</span><span className="shrink-0">{when}</span>
                </div>
                {(s.state === 'hasatta' || s.state === 'bitti') && <div className="mt-1 h-1.5 rounded bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-teal-600" style={{ width: `${Math.min(100, s.pct)}%` }} /></div>}
              </button>
              {isO && <div className="mt-2 rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5"><Editor key={s.crop.id} s={s} by={by} readOnly={readOnly} /></div>}
            </li>);
        })}</ul>
        <p className="text-[10px] text-slate-500 mt-1.5">Kaynak: {FIELD_SOURCE}. {y === 2028 ? '2027 güzünde ekilir, 2028\'de hasat edilir.' : 'Ekim kaydı girilince hasat dönemi gerçek ekim gününe göre kayar.'}</p>
      </section>
    </>
  );
}
