import React, { useMemo, useState } from 'react';
import { Banana, Plus, Undo2, Ribbon, Settings2, ChevronDown, PackageCheck, X, AlertTriangle, Truck, Snowflake, ClipboardPaste } from 'lucide-react';
import { UNIT_PLANS } from '../../config/unitPlans';
import {
  seraCode,
  useMuzDocs, useMuzCfg, isDay, isBag, isLoss, isPal, savePal, palWaitH, parseBagPaste, upsertDay, undoCount, saveBag, saveLoss, removeMuzDoc, saveMuzCfg, muzVerdict, dayBunches, muzRefId,
  colorOfDate, colorOfPeriod, periodOf, periodStart, periodRows, cycleCheck, addDays, daysBetween, colorHex, todayISO, MUZ_GRADES, GRADE_LABEL, DEFAULT_CFG, LOSS_REASONS,
  type MuzDay, type MuzGrade, type MuzCfg, type MuzPal,
} from '../../services/muzDaily';

/** v50b — Muz serası: günlük partiler (RefID = gün + sektör + renk), salkım sayımı, akşam kg, paketleme kalitesi → Kadaly / Gaýtadan işlenen, kurdele takvimi */
const n0 = (x: number) => Math.round(x).toLocaleString('tr-TR');
const dm = (iso: string) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}`;
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 });
const inp = 'w-full min-h-[36px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-sm tabular-nums';
const Dot = ({ hex }: { hex: string }) => <span className="inline-block w-3 h-3 rounded-sm shrink-0 border border-black/10" style={{ background: hex }} />;

function Verdict({ d, cfg }: { d: MuzDay; cfg: MuzCfg }) {
  const v = muzVerdict(d.grades, cfg);
  if (!v) return <span className="text-[10px] text-slate-400">kalite girilmedi</span>;
  return <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${v.decision === 'Kadaly' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-300'}`}>{v.decision}</span>;
}

function DayEditor({ d, cfg, by, readOnly }: { d: MuzDay; cfg: MuzCfg; by: string; readOnly?: boolean }) {
  const [cnt, setCnt] = useState('');
  const [kg, setKg] = useState(d.kg !== undefined ? String(d.kg) : '');
  const [g, setG] = useState<Record<MuzGrade, string>>(() => Object.fromEntries(MUZ_GRADES.map(k => [k, d.grades?.[k] !== undefined ? String(d.grades[k]) : ''])) as Record<MuzGrade, string>);
  const num = (s: string) => Number(String(s).replace(',', '.')) || 0;
  const gNum = Object.fromEntries(MUZ_GRADES.map(k => [k, num(g[k])])) as Record<MuzGrade, number>;
  const live = muzVerdict(gNum, cfg);
  if (readOnly) return (
    <div className="text-[11px] text-slate-600 dark:text-slate-400 space-y-0.5">
      <div>Sayım: {d.counts.map(c => `${new Date(c.at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })} +${c.n}`).join(' · ') || '—'}</div>
      {d.grades && <div>Paketleme: {MUZ_GRADES.filter(k => d.grades?.[k]).map(k => `${k} ${n0(d.grades![k]!)}`).join(' · ')}</div>}
      {live && <div>{live.reason}</div>}
    </div>
  );
  return (
    <div className="space-y-2.5">
      <div>
        <div className="text-[10px] text-slate-500 mb-0.5">Gün içi salkım sayımı{d.counts.length ? ` · ${d.counts.map(c => `+${c.n}`).join(' ')}` : ''}</div>
        <div className="grid grid-cols-[minmax(0,1fr)_auto_auto] gap-1.5">
          <input inputMode="numeric" placeholder="salkım" aria-label="Salkım sayısı" value={cnt} onChange={e => setCnt(e.target.value.replace(/[^\d]/g, ''))} className={inp} />
          <button type="button" disabled={!num(cnt)} onClick={async () => { await upsertDay(d.date, d.sera, d.sector, d.color, { addCount: num(cnt) }, by); setCnt(''); }} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer inline-flex items-center gap-1"><Plus className="w-3.5 h-3.5" />Ekle</button>
          <button type="button" disabled={!d.counts.length} onClick={() => undoCount(d, by)} aria-label="Son sayımı geri al" className="min-h-[36px] px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs disabled:opacity-40 cursor-pointer"><Undo2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>
      <div>
        <div className="text-[10px] text-slate-500 mb-0.5">Akşam kg (tartım){d.kg !== undefined && dayBunches(d) ? ` · salkım başı ${(d.kg / dayBunches(d)).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} kg` : ''}</div>
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-1.5">
          <input inputMode="decimal" placeholder="kg" aria-label="Akşam kg" value={kg} onChange={e => setKg(e.target.value)} className={inp} />
          <button type="button" disabled={!num(kg) || num(kg) === d.kg} onClick={() => upsertDay(d.date, d.sera, d.sector, d.color, { kg: num(kg) }, by)} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
        </div>
      </div>
      <div>
        <div className="text-[10px] text-slate-500 mb-0.5 flex items-center gap-1"><PackageCheck className="w-3.5 h-3.5" />Paketleme kalitesi (kg)</div>
        <div className="grid grid-cols-3 gap-1.5">
          {MUZ_GRADES.map(k => (
            <label key={k} className="text-[10px] text-slate-500">{k === 'Iskarta' ? 'Iskarta' : k}
              <input inputMode="decimal" value={g[k]} onChange={e => setG(s => ({ ...s, [k]: e.target.value }))} className={inp} aria-label={GRADE_LABEL[k]} />
            </label>))}
        </div>
        {live && (
          <div className={`mt-1.5 rounded-lg border px-2.5 py-1.5 text-xs ${live.decision === 'Kadaly' ? 'border-emerald-200 bg-emerald-50 text-emerald-900' : 'border-amber-300 bg-amber-50 text-amber-900'}`}>
            <b>{live.decision}</b> · {n0(live.total)} kg · {live.reason}
            {d.kg ? <span className="block text-[10px] opacity-80">Tartım {n0(d.kg)} kg · paketleme {n0(live.total)} kg · fark {n0(d.kg - live.total)} kg</span> : null}
          </div>
        )}
        <button type="button" disabled={!live} onClick={() => upsertDay(d.date, d.sera, d.sector, d.color, { grades: Object.fromEntries(MUZ_GRADES.filter(k => gNum[k]).map(k => [k, gNum[k]])) }, by)} className="mt-1.5 w-full min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaliteyi kaydet</button>
      </div>
    </div>
  );
}

function CycleNote({ cfg }: { cfg: MuzCfg }) {
  const c = cycleCheck(cfg);
  return c.ok
    ? <p className="text-[10px] text-emerald-700">{cfg.colors.length} renk × {cfg.periodDays} gün = {c.cycle} gün döngü ≥ hasat {cfg.harvestDays} + {cfg.periodDays} gün: aynı renk sahada tek kuşak.</p>
    : <p className="text-[10px] text-rose-700 flex gap-1"><AlertTriangle className="w-3.5 h-3.5 shrink-0" />{cfg.colors.length} renk × {cfg.periodDays} gün = {c.cycle} gün; hasat {cfg.harvestDays} + {cfg.periodDays} gün sürüyor. Aynı renk sahada iki kuşak olur — en az {c.minColors} renk gerekli.</p>;
}

function Settings({ cfg, by, onDone }: { cfg: MuzCfg; by: string; onDone: () => void }) {
  const [names, setNames] = useState(cfg.colors.map(c => c.name).join(', '));
  const [start, setStart] = useState(periodStart(cfg, periodOf(cfg, todayISO())));
  const [cur, setCur] = useState(colorOfDate(cfg, todayISO()).name);
  const [period, setPeriod] = useState(String(cfg.periodDays));
  const [hd, setHd] = useState(String(cfg.harvestDays));
  const [bkg, setBkg] = useState(String(cfg.bunchKg));
  const [lg, setLg] = useState({ boxKg: String(cfg.boxKg), bpp: String(cfg.boxesPerPallet), w1: String(cfg.waitWarnH), w2: String(cfg.waitCritH) });
  const [isk, setIsk] = useState(String(cfg.maxIskartaPct));
  const [low, setLow] = useState(String(cfg.maxLowPct));
  const list = names.split(',').map(s => s.trim()).filter(Boolean);
  const hexOf = (n: string) => cfg.colors.find(c => c.name === n)?.hex || DEFAULT_CFG.colors.find(c => c.name.toLocaleLowerCase('tr') === n.toLocaleLowerCase('tr'))?.hex || '#888780';
  const draft: MuzCfg = { ...cfg, colors: list.map(n => ({ name: n, hex: hexOf(n) })), periodDays: Number(period) || 10, harvestDays: Number(hd) || 98 };
  return (
    <div className="space-y-2 text-xs">
      <label className="block text-[10px] text-slate-500">Renk sırası (virgülle; bitince aynı sırayla tekrar)<input value={names} onChange={e => setNames(e.target.value)} className={inp} /></label>
      <div className="grid grid-cols-2 gap-1.5">
        <label className="text-[10px] text-slate-500">Şu anki dönemin rengi
          <select value={list.includes(cur) ? cur : list[0]} onChange={e => setCur(e.target.value)} className={inp}>{list.map(n => <option key={n}>{n}</option>)}</select></label>
        <label className="text-[10px] text-slate-500">Bu renk başladı<input type="date" value={start} onChange={e => e.target.value && setStart(e.target.value)} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Renk dönemi (gün)<input inputMode="numeric" value={period} onChange={e => setPeriod(e.target.value)} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Bağlamadan hasada (gün)<input inputMode="numeric" value={hd} onChange={e => setHd(e.target.value)} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Ort. salkım kg (veri yoksa)<input inputMode="decimal" value={bkg} onChange={e => setBkg(e.target.value)} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Kutu kg<input inputMode="decimal" value={lg.boxKg} onChange={e => setLg({ ...lg, boxKg: e.target.value })} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Palet başına kutu<input inputMode="numeric" value={lg.bpp} onChange={e => setLg({ ...lg, bpp: e.target.value })} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Ön soğutma uyarı (saat) sarı / kırmızı<span className="grid grid-cols-2 gap-1"><input inputMode="numeric" value={lg.w1} onChange={e => setLg({ ...lg, w1: e.target.value })} className={inp} /><input inputMode="numeric" value={lg.w2} onChange={e => setLg({ ...lg, w2: e.target.value })} className={inp} /></span></label>
        <label className="text-[10px] text-slate-500">Iskarta sınırı %<input inputMode="decimal" value={isk} onChange={e => setIsk(e.target.value)} className={inp} /></label>
        <label className="text-[10px] text-slate-500">Classic+Mix sınırı %<input inputMode="decimal" value={low} onChange={e => setLow(e.target.value)} className={inp} /></label>
      </div>
      <CycleNote cfg={draft} />
      <p className="text-[10px] text-slate-500">Sınırlardan biri aşılırsa parti "Gaýtadan işlenen", değilse "Kadaly". Ayar tüm muz seraları için.</p>
      <button type="button" disabled={list.length < 2 || !Number(period) || !Number(hd)} onClick={async () => {
        await saveMuzCfg({ colors: draft.colors, anchor: { date: start, idx: Math.max(0, list.indexOf(cur)) }, periodDays: draft.periodDays, harvestDays: draft.harvestDays, bunchKg: Number(String(bkg).replace(',', '.')) || 25, maxIskartaPct: Number(isk) || 0, maxLowPct: Number(low) || 0, boxKg: Number(String(lg.boxKg).replace(',', '.')) || 18, boxesPerPallet: Number(lg.bpp) || 54, waitWarnH: Number(lg.w1) || 24, waitCritH: Number(lg.w2) || 48 }, by);
        onDone();
      }} className="w-full min-h-[36px] rounded-lg bg-teal-700 text-white font-semibold disabled:opacity-40 cursor-pointer">Ayarı kaydet</button>
    </div>
  );
}

/** v51 — Palet · ön soğutma · sevk · lojistikte kabul. Bekleme sınırı aşılınca sarı / kırmızı (ana sayfaya da düşer). */
function PalletSection({ sera, cfg, days, pals, by, readOnly }: { sera: string; cfg: MuzCfg; days: MuzDay[]; pals: MuzPal[]; by: string; readOnly?: boolean }) {
  const [form, setForm] = useState(false);
  const [f, setF] = useState({ grade: 'Exclusive', boxes: String(cfg.boxesPerPallet), temp: '', refs: [] as string[] });
  const [act, setAct] = useState<string | null>(null);
  const [sv, setSv] = useState({ vehicle: 'Frigorifik', temp: '', sealed: true, boxes: '', note: '' });
  const now = Date.now();
  const recentDays = days.filter(d => d.date >= addDays(todayISO(), -2)).sort((a, b) => b.date.localeCompare(a.date));
  const waiting = pals.filter(p => !p.shippedAt).sort((a, b) => a.coolAt.localeCompare(b.coolAt));
  const onRoad = pals.filter(p => p.shippedAt && !p.receivedAt);
  const doneToday = pals.filter(p => p.receivedAt && p.receivedAt.slice(0, 10) === todayISO());
  const tone = (h: number) => (h >= cfg.waitCritH ? 'text-rose-700 font-semibold' : h >= cfg.waitWarnH ? 'text-amber-700 font-semibold' : 'text-slate-600');
  const nextNo = () => `${seraCode(sera)}-${todayISO().slice(2).replace(/-/g, '')}-${String(pals.filter(p => p.coolAt.slice(0, 10) === todayISO()).length + 1).padStart(2, '0')}`;
  const sumBoxes = waiting.reduce((a, p) => a + p.boxes, 0);
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Snowflake className="w-4 h-4 text-teal-700" />Palet · ön soğutma · sevk</h2>
        <span className="text-[11px] text-slate-500 tabular-nums">{waiting.length ? `${waiting.length} palet · ${n0(sumBoxes)} kutu bekliyor` : 'bekleyen palet yok'}</span>
      </div>
      {waiting.length === 0 && onRoad.length === 0 && !form && <p className="text-[11px] text-slate-500">Sınıflanıp kutulanan muz palete dizilince buraya girin. Ön soğutmada {cfg.waitWarnH} saati geçen palet sarı, {cfg.waitCritH} saati geçen kırmızı olur.</p>}
      <ul className="divide-y divide-slate-100 dark:divide-slate-800">{[...waiting, ...onRoad].map(p => {
        const h = palWaitH(p, now); const isA = act === p.id;
        return (
          <li key={p.id} className="py-1.5">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-mono text-[11px] min-w-0 flex-1 truncate">{p.no} · <b>{p.grade}</b> · {p.boxes} kutu (≈ {t1(p.boxes * cfg.boxKg)} t)</span>
              {p.shippedAt ? <span className="text-[10px] px-2 py-0.5 rounded-full border border-sky-200 bg-sky-50 text-sky-800 shrink-0">yolda · {p.vehicle}</span>
                : <span className={`text-[11px] tabular-nums shrink-0 ${tone(h)}`}>{h < 1 ? '<1' : Math.floor(h)} sa</span>}
            </div>
            <div className="text-[10px] text-slate-500 truncate">{p.refs.length ? p.refs.map(r => r.replace(/^MUZ-\d{6}-[A-Z0-9]+-/, '')).join(' · ') : 'parti seçilmedi'}{p.coolTemp !== undefined ? ` · oda ${p.coolTemp} °C` : ''}{p.shippedAt ? ` · sevk ${p.shippedAt.slice(11, 16)}${p.vehTemp !== undefined ? ` · araç ${p.vehTemp} °C` : ''}${p.sealed ? ' · mühürlü' : ' · mühürsüz!'}` : ''}</div>
            {!readOnly && (
              <button type="button" onClick={() => { setAct(isA ? null : p.id); setSv({ vehicle: 'Frigorifik', temp: '', sealed: true, boxes: String(p.boxes), note: '' }); }} className="mt-1 text-[11px] font-semibold text-teal-800 dark:text-teal-300 cursor-pointer">{isA ? 'Vazgeç' : p.shippedAt ? 'Lojistikte kabul ›' : 'Sevk et ›'}</button>
            )}
            {isA && !p.shippedAt && (
              <div className="mt-1 grid grid-cols-[minmax(0,1fr)_64px_auto] gap-1.5 items-center">
                <select aria-label="Araç" value={sv.vehicle} onChange={e => setSv({ ...sv, vehicle: e.target.value })} className={inp}><option>Frigorifik</option><option>Tentli</option><option>Diğer</option></select>
                <input inputMode="decimal" placeholder="araç °C" aria-label="Araç °C" value={sv.temp} onChange={e => setSv({ ...sv, temp: e.target.value })} className={inp} />
                <label className="text-[11px] flex items-center gap-1"><input type="checkbox" checked={sv.sealed} onChange={e => setSv({ ...sv, sealed: e.target.checked })} />mühür</label>
                {sv.vehicle === 'Tentli' && <p className="col-span-3 text-[10px] text-amber-700">Tentli araç: soğuk zincir kırılır (2026 aktlarında tekrar eden konu).</p>}
                <button type="button" onClick={async () => { await savePal({ ...p, shippedAt: new Date().toISOString(), vehicle: sv.vehicle, vehTemp: sv.temp ? Number(sv.temp.replace(',', '.')) : undefined, sealed: sv.sealed }, by); setAct(null); }} className="col-span-3 min-h-[34px] rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer inline-flex items-center justify-center gap-1"><Truck className="w-3.5 h-3.5" />Sevk edildi</button>
              </div>
            )}
            {isA && p.shippedAt && (
              <div className="mt-1 grid grid-cols-[72px_64px_minmax(0,1fr)] gap-1.5">
                <input inputMode="numeric" placeholder="gelen kutu" aria-label="Gelen kutu" value={sv.boxes} onChange={e => setSv({ ...sv, boxes: e.target.value })} className={inp} />
                <input inputMode="decimal" placeholder="°C" aria-label="Gelişte °C" value={sv.temp} onChange={e => setSv({ ...sv, temp: e.target.value })} className={inp} />
                <input placeholder="not (hasar, eksik…)" aria-label="Not" value={sv.note} onChange={e => setSv({ ...sv, note: e.target.value })} className={inp} />
                {Number(sv.boxes) > 0 && Number(sv.boxes) !== p.boxes && <p className="col-span-3 text-[10px] text-rose-700">Gönderilen {p.boxes}, gelen {sv.boxes} kutu — fark {p.boxes - Number(sv.boxes)}.</p>}
                <button type="button" onClick={async () => { await savePal({ ...p, receivedAt: new Date().toISOString(), recvBoxes: Number(sv.boxes) || p.boxes, recvTemp: sv.temp ? Number(sv.temp.replace(',', '.')) : undefined, recvNote: sv.note || undefined }, by); setAct(null); }} className="col-span-3 min-h-[34px] rounded-lg bg-teal-700 text-white text-xs font-semibold cursor-pointer">Kabul edildi</button>
              </div>
            )}
          </li>);
      })}</ul>
      {doneToday.length > 0 && <p className="text-[11px] text-emerald-700">Bugün lojistikte kabul: {doneToday.length} palet · {n0(doneToday.reduce((a, p) => a + (p.recvBoxes || p.boxes), 0))} kutu{doneToday.some(p => (p.recvBoxes ?? p.boxes) !== p.boxes) ? ' · eksik var!' : ''}</p>}
      {!readOnly && (form ? (
        <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5 space-y-1.5">
          <div className="grid grid-cols-3 gap-1.5">
            <label className="text-[10px] text-slate-500">Sınıf<select value={f.grade} onChange={e => setF({ ...f, grade: e.target.value })} className={inp}>{MUZ_GRADES.filter(g => g !== 'Iskarta').map(g => <option key={g}>{g}</option>)}</select></label>
            <label className="text-[10px] text-slate-500">Kutu<input inputMode="numeric" value={f.boxes} onChange={e => setF({ ...f, boxes: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
            <label className="text-[10px] text-slate-500">Oda °C<input inputMode="decimal" value={f.temp} onChange={e => setF({ ...f, temp: e.target.value })} className={inp} /></label>
          </div>
          <div className="text-[10px] text-slate-500">Hangi partilerden (RefID)</div>
          {recentDays.length === 0 ? <p className="text-[10px] text-slate-500">Son 2 günde parti yok — önce Günlük'ten parti açın.</p> : (
            <div className="flex flex-wrap gap-1">{recentDays.map(d => { const on = f.refs.includes(d.refId); return (
              <button key={d.id} type="button" onClick={() => setF({ ...f, refs: on ? f.refs.filter(x => x !== d.refId) : [...f.refs, d.refId] })} className={`px-2 py-1 rounded-full border text-[10px] font-mono cursor-pointer ${on ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300'}`}>{d.date.slice(8, 10)}.{d.date.slice(5, 7)} S{d.sector} {d.color}</button>); })}</div>
          )}
          <div className="grid grid-cols-2 gap-1.5">
            <button type="button" onClick={() => setForm(false)} className="min-h-[36px] rounded-lg border border-slate-300 text-xs cursor-pointer">Vazgeç</button>
            <button type="button" disabled={!Number(f.boxes)} onClick={async () => { const no = nextNo(); await savePal({ id: `muzpal-${no}-${Date.now().toString(36)}`, sera, no, grade: f.grade, boxes: Number(f.boxes), refs: f.refs, coolAt: new Date().toISOString(), coolTemp: f.temp ? Number(f.temp.replace(',', '.')) : undefined }, by); setForm(false); setF({ ...f, refs: [], temp: '' }); }} className="min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Ön soğutmaya al</button>
          </div>
        </div>
      ) : <button type="button" onClick={() => setForm(true)} className="w-full min-h-[36px] rounded-lg border border-dashed border-teal-400 text-teal-800 dark:text-teal-300 text-xs font-semibold cursor-pointer">+ Palet (sınıf, kutu, partiler)</button>)}
    </section>
  );
}

export default function MuzPanel({ sera, by = '', readOnly, isAdmin }: { sera: string; by?: string; readOnly?: boolean; isAdmin?: boolean }) {
  const docs = useMuzDocs();
  const cfg = useMuzCfg();
  const today = todayISO();
  const [date, setDate] = useState(today);
  const [open, setOpen] = useState<string | null>(null);
  const [sector, setSector] = useState('');
  const [color, setColor] = useState('');
  const [showCfg, setShowCfg] = useState(false);
  const [form, setForm] = useState<'' | 'bag' | 'loss'>('');
  const [bf, setBf] = useState({ date: today, sector: '', row: '', n: '', late: '' });
  const [lf, setLf] = useState({ date: today, color: '', sector: '', row: '', n: '', reason: 'Hastalık' as string });
  const days = useMemo(() => docs.filter(isDay).filter(d => d.sera === sera), [docs, sera]);
  const bags = useMemo(() => docs.filter(isBag).filter(b => b.sera === sera), [docs, sera]);
  const losses = useMemo(() => docs.filter(isLoss).filter(l => l.sera === sera), [docs, sera]);
  const rows = useMemo(() => periodRows(cfg, bags, losses, days), [cfg, bags, losses, days]);
  const kgBase = cfg.bunchKg;
  const pals = useMemo(() => docs.filter(isPal).filter(p => p.sera === sera), [docs, sera]);
  const [paste, setPaste] = useState('');
  // v51: plan katmanı — 2027 aylık plan (v2_1911) → renk dönemi başına beklenen salkım
  const planM = UNIT_PLANS[sera]?.rows?.[0]?.months;
  const planBunches = (k: number) => {
    if (!planM) return 0;
    const mid = addDays(periodStart(cfg, k), cfg.harvestDays + Math.floor(cfg.periodDays / 2));
    const y = Number(mid.slice(0, 4)), m = Number(mid.slice(5, 7)) - 1;
    const dim = new Date(y, m + 1, 0).getDate();
    return (planM[m] || 0) * (cfg.periodDays / dim) / (kgBase || 25);
  };
  const dayList = days.filter(d => d.date === date).sort((a, b) => a.sector.localeCompare(b.sector, 'tr', { numeric: true }) || a.color.localeCompare(b.color));
  const tot = dayList.reduce((s, d) => ({ b: s.b + dayBunches(d), kg: s.kg + (d.kg || 0), noKg: s.noKg + (d.kg === undefined && dayBunches(d) ? 1 : 0) }), { b: 0, kg: 0, noKg: 0 });
  const sectors = [...new Set([...days.map(d => d.sector), ...bags.map(b => b.sector || '')].filter(Boolean))].sort((a, b) => a.localeCompare(b, 'tr', { numeric: true }));
  // bugün hasada gelen renk: beklenen hasat aralığı bugünü kapsayan dönem; yoksa 98 gün önceki dönemin rengi
  const hRow = rows.find(r => r.hFrom && r.hTo && date >= addDays(r.hFrom, -3) && date <= addDays(r.hTo, 5));
  const harvestColor = hRow?.color.name || colorOfDate(cfg, addDays(date, -cfg.harvestDays)).name;
  const selColor = color || harvestColor;
  const exists = dayList.some(d => d.sector === sector.trim() && d.color === selColor);
  // ortalama salkım kg: bu serada akşam kg girilmiş partilerden
  const wk = days.filter(d => d.kg && dayBunches(d));
  const kgB = wk.length ? wk.reduce((s, d) => s + d.kg!, 0) / wk.reduce((s, d) => s + dayBunches(d), 0) : cfg.bunchKg;
  const kgSrc = wk.length ? `${wk.length} partiden` : 'ayardan';
  const nowK = periodOf(cfg, today), nowC = colorOfPeriod(cfg, nowK), left = daysBetween(today, addDays(periodStart(cfg, nowK), cfg.periodDays));
  const next30 = rows.filter(r => r.hAvg && r.hAvg >= today && r.hAvg <= addDays(today, 30));
  const n30 = next30.reduce((s, r) => s + Math.max(0, r.net - r.harvested), 0);
  // bağlanmış ve hasat edilmemiş dönemler (son 98 gün) + şimdiki dönem; kaydı olmayanlar plandan
  const hangK = Array.from({ length: Math.ceil(cfg.harvestDays / cfg.periodDays) + 1 }, (_, i) => nowK - Math.ceil(cfg.harvestDays / cfg.periodDays) + i);
  const rowMap = new Map(rows.map(r => [r.k, r]));
  const calRows = [...new Set([...hangK, ...rows.filter(r => r.k >= nowK - Math.ceil((cfg.harvestDays + 30) / cfg.periodDays)).map(r => r.k)])].sort((a, b) => a - b).map(k => {
    const r = rowMap.get(k);
    const from = periodStart(cfg, k);
    return { k, r, color: colorOfPeriod(cfg, k), from, to: addDays(from, cfg.periodDays - 1), plan: planBunches(k), hAvg: r?.hAvg || addDays(from, cfg.harvestDays + Math.floor(cfg.periodDays / 2)), ended: addDays(from, cfg.periodDays - 1) < today };
  });
  const plan30 = calRows.filter(x => x.hAvg >= today && x.hAvg <= addDays(today, 30)).reduce((a2, x) => a2 + x.plan, 0);
  const hangRec = calRows.filter(x => hangK.includes(x.k)).reduce((a, x) => a + (x.r?.net || 0), 0);
  const hangPlan = calRows.filter(x => hangK.includes(x.k)).reduce((a, x) => a + x.plan, 0);
  const missing = calRows.filter(x => hangK.includes(x.k) && x.ended && !x.r?.bagged).length;
  const pp = paste.trim() ? parseBagPaste(paste) : undefined;
  const noColorLoss = losses.filter(l => !l.color);
  const recent = [...bags.map(b => ({ t: 'bag' as const, d: b })), ...losses.map(l => ({ t: 'loss' as const, d: l }))].sort((a, b) => b.d.at.localeCompare(a.d.at)).slice(0, 6);
  const num = (x: string) => Number(String(x).replace(',', '.')) || 0;

  return (
    <>
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Banana className="w-4 h-4 text-teal-700" />Günlük · {dm(date)}</h2>
          <input type="date" aria-label="Gün" value={date} max={today} onChange={e => e.target.value && setDate(e.target.value)} className="min-h-[32px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 text-xs" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2"><div className="text-[10px] text-slate-500">Salkım (gün içi)</div><div className="text-xl font-bold tabular-nums">{n0(tot.b)}</div></div>
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2"><div className="text-[10px] text-slate-500">Akşam kg</div><div className={`text-xl font-bold tabular-nums ${tot.noKg ? 'text-amber-700' : ''}`}>{tot.kg ? n0(tot.kg) : '—'}</div>{tot.noKg > 0 && <div className="text-[10px] text-amber-700">{tot.noKg} partide girilmedi</div>}</div>
        </div>
        {dayList.length === 0 && <p className="text-xs text-slate-500">Bu gün için parti yok. {readOnly ? '' : 'Aşağıdan sektör ve renk seçip açın.'}</p>}
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{dayList.map(d => {
          const isO = open === d.id;
          return (
            <li key={d.id} className="py-1.5">
              <button type="button" onClick={() => setOpen(isO ? null : d.id)} className="w-full text-left cursor-pointer">
                <div className="flex items-center gap-2">
                  <Dot hex={colorHex(cfg, d.color)} />
                  <span className="text-xs font-semibold min-w-0 flex-1">Sektör {d.sector} · {d.color}</span>
                  <span className="text-xs tabular-nums">{n0(dayBunches(d))} salkım{d.kg !== undefined ? ` · ${n0(d.kg)} kg` : ''}</span>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 shrink-0 ${isO ? 'rotate-180' : ''}`} />
                </div>
                <div className="flex items-center justify-between gap-2 mt-0.5 pl-5"><span className="font-mono text-[10px] text-slate-500 truncate">{d.refId}</span><Verdict d={d} cfg={cfg} /></div>
              </button>
              {isO && <div className="mt-2 pl-5"><DayEditor key={d.at} d={d} cfg={cfg} by={by} readOnly={readOnly} /></div>}
            </li>);
        })}</ul>
        {!readOnly && (
          <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-2.5">
            <div className="text-[10px] text-slate-500 mb-1">Yeni parti · hasada gelen renk <b>{harvestColor}</b></div>
            <div className="grid grid-cols-[72px_minmax(0,1fr)_auto] gap-1.5">
              <input list="muz-sectors" placeholder="Sektör" aria-label="Sektör" value={sector} onChange={e => setSector(e.target.value)} className={inp} />
              <datalist id="muz-sectors">{sectors.map(x => <option key={x} value={x} />)}</datalist>
              <select aria-label="Kurdele rengi" value={selColor} onChange={e => setColor(e.target.value)} className={inp}>{cfg.colors.map(c => <option key={c.name}>{c.name}</option>)}</select>
              <button type="button" disabled={!sector.trim() || exists} onClick={async () => { await upsertDay(date, sera, sector.trim(), selColor, {}, by); setOpen(`muz-${muzRefId(date, sera, sector.trim(), selColor)}`); setSector(''); }}
                className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Aç</button>
            </div>
            {sector.trim() && <div className="font-mono text-[10px] text-slate-500 mt-1">{muzRefId(date, sera, sector.trim(), selColor)}{exists ? ' — zaten açık' : ''}</div>}
          </div>
        )}
      </section>

      <PalletSection sera={sera} cfg={cfg} days={days} pals={pals} by={by} readOnly={readOnly} />
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-2.5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Ribbon className="w-4 h-4 text-teal-700" />Kurdele · hasat takvimi</h2>
          {isAdmin && !readOnly && <button type="button" onClick={() => setShowCfg(v => !v)} aria-label="Kurdele ayarı" className="text-slate-500 cursor-pointer"><Settings2 className="w-4 h-4" /></button>}
        </div>
        <div className="flex items-center gap-2 text-xs"><Dot hex={nowC.hex} /><span>Şu an bağlanan: <b>{nowC.name}</b> · {dm(periodStart(cfg, nowK))}–{dm(addDays(periodStart(cfg, nowK), cfg.periodDays - 1))} · {left} gün kaldı → sonra <b>{colorOfPeriod(cfg, nowK + 1).name}</b></span></div>
        {!cycleCheck(cfg).ok && <CycleNote cfg={cfg} />}
        {showCfg && <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5"><Settings cfg={cfg} by={by} onDone={() => setShowCfg(false)} /></div>}
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2"><div className="text-[10px] text-slate-500">30 günde hasada gelecek</div><div className="text-lg font-bold tabular-nums">{n0(n30 || plan30)} salkım</div><div className="text-[10px] text-slate-500">{n30 ? 'bağlama kaydından' : 'plandan (bağlama kaydı yok)'} · ≈ {t1((n30 || plan30) * kgB)} t · günde ~{n0((n30 || plan30) / 30)}</div></div>
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2"><div className="text-[10px] text-slate-500">Ort. salkım</div><div className="text-lg font-bold tabular-nums">{kgB.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} kg</div><div className="text-[10px] text-slate-500">{kgSrc}</div></div>
        </div>
        {!readOnly && (
          <div className="flex gap-1.5">
            {([['bag', 'Kurdele bağlandı'], ['loss', 'Kayıp gir']] as const).map(([k, l]) => (
              <button key={k} type="button" onClick={() => setForm(form === k ? '' : k)} className={`flex-1 min-h-[36px] rounded-lg border text-xs font-semibold cursor-pointer ${form === k ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 dark:border-slate-700'}`}>{l}</button>))}
          </div>
        )}
        {form === 'bag' && (() => {
          const c = colorOfDate(cfg, bf.date);
          return (
            <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5 space-y-1.5">
              <div className="text-[11px] flex items-center gap-1.5"><Dot hex={c.hex} />Renk: <b>{c.name}</b> (bağlama gününe göre) · hasat ≈ {dm(addDays(bf.date, cfg.harvestDays - num(bf.late)))}</div>
              <div className="grid grid-cols-2 gap-1.5">
                <label className="text-[10px] text-slate-500">Bağlama günü<input type="date" max={today} value={bf.date} onChange={e => e.target.value && setBf({ ...bf, date: e.target.value })} className={inp} /></label>
                <label className="text-[10px] text-slate-500">Salkım<input inputMode="numeric" value={bf.n} onChange={e => setBf({ ...bf, n: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
                <label className="text-[10px] text-slate-500">Sektör<input list="muz-sectors" value={bf.sector} onChange={e => setBf({ ...bf, sector: e.target.value })} className={inp} /></label>
                <label className="text-[10px] text-slate-500">Sıra (isteğe bağlı)<input value={bf.row} onChange={e => setBf({ ...bf, row: e.target.value })} className={inp} /></label>
              </div>
              <label className="block text-[10px] text-slate-500">Geç bağlandı: doğumdan kaç gün sonra (zamanında ise boş)<input inputMode="numeric" value={bf.late} onChange={e => setBf({ ...bf, late: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
              {num(bf.late) > 0 && <p className={`text-[10px] ${num(bf.late) > cfg.periodDays ? 'text-rose-700' : 'text-amber-700'}`}>{num(bf.late) > cfg.periodDays ? `${cfg.periodDays} günü aştı: doğduğu dönemin rengi (${colorOfDate(cfg, addDays(bf.date, -num(bf.late))).name}) kaçırıldı; ${c.name} ile bağlanıyor, hasat ${num(bf.late)} gün öne alınır.` : `Geç bağlama: hasat ${num(bf.late)} gün öne alınır.`}</p>}
              <button type="button" disabled={!num(bf.n)} onClick={async () => { await saveBag(cfg, sera, { date: bf.date, sector: bf.sector.trim() || undefined, row: bf.row.trim() || undefined, bunches: num(bf.n), lateDays: num(bf.late) }, by); setBf({ ...bf, n: '', row: '', late: '' }); }}
                className="w-full min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
              <details>
                <summary className="text-[11px] text-slate-600 dark:text-slate-400 cursor-pointer flex items-center gap-1"><ClipboardPaste className="w-3.5 h-3.5" />Geçmiş bağlamaları toplu yapıştır (defter / Excel)</summary>
                <textarea rows={4} value={paste} onChange={e => setPaste(e.target.value)} placeholder={'25.09.2026; 640; 2\n05.10.2026; 610; 3; 4'} className="mt-1 w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-xs font-mono" />
                <p className="text-[10px] text-slate-500">Her satır: bağlama tarihi; salkım; [sektör]; [geç gün]. Renk tarihten kendiliğinden bulunur.</p>
                {pp && <p className="text-[10px] text-slate-600">{pp.rows.length} satır okundu{pp.bad ? ` · ${pp.bad} okunamadı` : ''}</p>}
                <button type="button" disabled={!pp?.rows.length} onClick={async () => { for (const r of pp!.rows) await saveBag(cfg, sera, { date: r.date, sector: r.sector, bunches: r.bunches, lateDays: r.lateDays }, by); setPaste(''); }} className="mt-1 w-full min-h-[34px] rounded-lg border border-teal-300 text-teal-800 text-xs font-semibold disabled:opacity-40 cursor-pointer">Yapıştırılanları kaydet</button>
              </details>
            </div>);
        })()}
        {form === 'loss' && (
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-2.5 space-y-1.5">
            <div className="grid grid-cols-2 gap-1.5">
              <label className="text-[10px] text-slate-500">Gün<input type="date" max={today} value={lf.date} onChange={e => e.target.value && setLf({ ...lf, date: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Kurdele<select value={lf.color} onChange={e => setLf({ ...lf, color: e.target.value })} className={inp}><option value="">Renksiz (bağlanmamış)</option>{cfg.colors.map(c => <option key={c.name}>{c.name}</option>)}</select></label>
              <label className="text-[10px] text-slate-500">Sektör<input list="muz-sectors" value={lf.sector} onChange={e => setLf({ ...lf, sector: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Sıra<input value={lf.row} onChange={e => setLf({ ...lf, row: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Bitki / salkım<input inputMode="numeric" value={lf.n} onChange={e => setLf({ ...lf, n: e.target.value.replace(/[^\d]/g, '') })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Neden<select value={lf.reason} onChange={e => setLf({ ...lf, reason: e.target.value })} className={inp}>{LOSS_REASONS.map(r => <option key={r}>{r}</option>)}</select></label>
            </div>
            {!lf.color && !lf.sector.trim() && <p className="text-[10px] text-amber-700">Renksiz kayıpta sektör ve sıra yazın.</p>}
            <button type="button" disabled={!num(lf.n) || (!lf.color && !lf.sector.trim())} onClick={async () => { await saveLoss(cfg, sera, { date: lf.date, color: lf.color || undefined, sector: lf.sector.trim() || undefined, row: lf.row.trim() || undefined, plants: num(lf.n), reason: lf.reason }, bags, by); setLf({ ...lf, n: '', row: '' }); }}
              className="w-full min-h-[36px] rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
          </div>
        )}
        <div className={`rounded-lg px-2.5 py-1.5 text-[11px] ${missing ? 'bg-amber-50 text-amber-900' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
          Bağlanmış, hasat bekleyen (son {cfg.harvestDays} gün): <b>{hangRec ? `${n0(hangRec)} salkım kayıtlı` : 'kayıt yok'}</b>{planM ? ` · plana göre ≈ ${n0(hangPlan)} salkım (≈ ${t1(hangPlan * kgB)} t)` : ''}{missing ? ` · ${missing} dönemin bağlama kaydı girilmedi` : ''}
        </div>
        <ul className="divide-y divide-slate-100 dark:divide-slate-800">{calRows.map(x => {
          const r = x.r; const pct = r?.net ? Math.min(100, (r.harvested / r.net) * 100) : 0;
          const inH = x.hAvg && today >= addDays(x.hAvg, -cfg.periodDays) && today <= addDays(x.hAvg, cfg.periodDays);
          return (
            <li key={x.k} className={`py-1.5 ${inH ? 'bg-teal-50/60 dark:bg-teal-950/30 -mx-2 px-2 rounded-lg' : ''}`}>
              <div className="flex items-center gap-2 text-xs">
                <Dot hex={x.color.hex} /><b className="min-w-0 flex-1 truncate">{x.color.name} · bağlama {dm(x.from)}–{dm(x.to)}{x.k === nowK ? ' (şimdi)' : ''}</b>
                <span className="tabular-nums shrink-0">{r?.bagged ? `${n0(r.net)} salkım · ≈ ${t1(r.net * kgB)} t` : x.plan ? <span className="text-slate-500">plan ≈ {n0(x.plan)}</span> : '—'}</span>
              </div>
              <div className="pl-5 text-[11px] text-slate-600 dark:text-slate-400 tabular-nums">
                hasat ≈ <b>{dm(x.hAvg)}</b>{r?.hFrom && r.hTo && r.hFrom !== r.hTo ? ` (${dm(r.hFrom)}–${dm(r.hTo)})` : ''}
                {r?.bagged ? <> · bağlanan {n0(r.bagged)}{(() => { const l = bags.filter(b => b.k === x.k && (b.lateDays || 0) > 0).reduce((s2, b) => s2 + b.bunches, 0); return l ? <span className="text-amber-700"> · geç {n0(l)}</span> : null; })()}{r.lost ? ` · kayıp ${n0(r.lost)}` : ''}{r.harvested ? ` · hasat edilen ${n0(r.harvested)}` : ''}{x.plan ? ` · plan ≈ ${n0(x.plan)}` : ''}</>
                  : x.ended ? <span className="text-amber-700"> · bağlama kaydı yok</span> : <span> · bağlama sürüyor</span>}
              </div>
              {r && r.harvested > 0 && <div className="ml-5 mt-1 h-1.5 rounded bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full rounded" style={{ width: `${pct}%`, background: x.color.hex }} /></div>}
            </li>);
        })}</ul>
        {noColorLoss.length > 0 && (
          <div className="text-[11px] text-slate-600 dark:text-slate-400">
            <b>Renksiz kayıp</b> · {n0(noColorLoss.reduce((s, l) => s + l.plants, 0))} bitki: {Object.entries(noColorLoss.reduce((m, l) => { const k = `S${l.sector || '?'}${l.row ? `·${l.row}` : ''}`; m[k] = (m[k] || 0) + l.plants; return m; }, {} as Record<string, number>)).map(([k, v]) => `${k} ${v}`).join(' · ')}
          </div>
        )}
        {!readOnly && recent.length > 0 && (
          <details className="text-[11px]">
            <summary className="cursor-pointer text-slate-500">Son girişler</summary>
            <ul className="mt-1 space-y-0.5">{recent.map(({ t, d }) => (
              <li key={d.id} className="flex items-center gap-2">
                <Dot hex={colorHex(cfg, (d as any).color || '')} />
                <span className="flex-1 min-w-0 truncate">{dm(d.date)} · {t === 'bag' ? `bağlandı ${(d as any).bunches}${(d as any).lateDays ? ` (geç ${(d as any).lateDays} gün)` : ''}` : `kayıp ${(d as any).plants} · ${(d as any).reason}`}{(d as any).sector ? ` · S${(d as any).sector}` : ''}{(d as any).row ? `·${(d as any).row}` : ''}</span>
                <button type="button" aria-label="Girişi sil" onClick={() => removeMuzDoc(d as any, by)} className="text-slate-400 cursor-pointer"><X className="w-3.5 h-3.5" /></button>
              </li>))}</ul>
          </details>
        )}
      </section>
    </>
  );
}

/** Ana sayfa ve yapılacaklar için: bugünün muz özeti (tüm seralar) */
export function muzTodaySummary(docs: ReturnType<typeof useMuzDocs>) {
  const t = todayISO();
  const ds = docs.filter(isDay).filter(d => d.date === t);
  return { bunches: ds.reduce((s, d) => s + dayBunches(d), 0), kg: ds.reduce((s, d) => s + (d.kg || 0), 0), days: ds };
}
