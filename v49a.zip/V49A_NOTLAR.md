# v49a — Profiller + hasat takvimi + BBCH + hava

## Yeni
- Ana menü › Raporlar ve kayıtlar › **Hasat takvimi**: 2027 plan / 2026 gerçekleşen; bahçe › meyve › çeşit Gantt'ı; pencere (BBCH 65 + min/max gün, yoksa geçmiş yıllar ± 5 gün); gerçek hasat; geçmiş yıllar ortalaması; hasattaki çeşitlerde işçi × kg/gün ile tahmini bitiş, pencereyi aşarsa ek işçi / mesai / 1-MCP önerisi; kaydı eksik hasatlar; sıradaki 14 gün; tablodaki veri sorunları.
- Çeşit kartı: özet (kaynaklı), BBCH aşamaları (beklenen tarih = geçen sezonun aynı günü; "uyuştu / n gün geç"), BBCH gözlemi girişi (kaliteci / agronom, çap), elle başlangıç/bitiş, rewiz ton, işçi, kg/işçi/gün.
- Hava: Open-Meteo, bahçe profilindeki koordinattan; don ≤0 °C, sıcak ≥35 °C, yağmur ≥5 mm, hamle ≥50 km/s, ilaçlama için rüzgâr >15 km/s (iç hedef).
- Profiller (Yardım ve yönetim › Profiller): Bahçe / Sera / Tarla türleri eklendi; 7 bahçe, 12 sera, açık ekin tohum verisi (kullanıcının dosyalarından). Tohum yalnız profil yoksa eklenir.
- Eski "hasat portalı" bağlantıları takvime yönlenir.

## Veri ve kayıt
- Tohum: Miwe_2026 tablosu (126 satır) + tonaj Excel'inden 2027 plan (96 çeşit eşleşti).
- Kullanıcı düzeltmeleri Firestore 'ganttParcels' koleksiyonuna (calV: 49) yazılır — kural değişikliği YOK. Profiller 'locationProfiles' koleksiyonuna.

## SHA-256 (9 dosya)
9e1463341bc37c61ccf771313606d343206db2bd37bbe64e7c15d35ed60c0054  src/App.tsx
33a3e05e06bcf60cb6adef3a41e81e9b858b6499ae6621cc1cc031ce143cf9e0  src/components/coldchain/LocationProfilesModal.tsx
93882f1c9e978d37b9c09f6321cb2e186a4a4d0d3a438fd6d6b53e5e907bcca5  src/components/portal/HomeMenu.tsx
e5c4af43431afc93b89049163233f08183a7bd5fce74d7cad09c8a151202539c  src/components/views/HarvestCalendarView.tsx
2cfb22e9cc61b2b8664593b571a6944e4c82b49099316be474b5194411f6b920  src/config/harvestCalendarSeed.ts
7dbe64f3afbfc4cf7d9ba88f5402eef9124f5cf0961dd5387d6160e6bf194511  src/config/profileSeed.ts
c7fb72875e81c986e01e5e2dcfbfca0b38a121dbb63ede3212b461280c49d66e  src/services/harvestCalendar.ts
7c7b8bd2ebf8245281466dfc525ada5e9def7fe47852fa9022797e33b5f86c84  src/services/locationProfiles.ts
e19b44ff5b56b914f9adc72245ece5f99c9a0e2bf6a1de3f77a8934e1c2277ea  src/services/weather.ts
