/**
 * v49a — Bahçe havası (Open-Meteo, ücretsiz, anahtar gerekmez). Koordinat bahçe profilinden.
 * Saatte bir yenilenir (yerel önbellek). Zirai eşikler "İç hedef"tir ve ayarlanabilir:
 *  don ≤ 0 °C · sıcak ≥ 35 °C · yağmur ≥ 5 mm · hamle rüzgâr ≥ 50 km/s · ilaçlama için ortalama rüzgâr > 15 km/s
 */
import { useEffect, useState } from 'react';

export const AGRO_LIMITS = { frostC: 0, heatC: 35, rainMm: 5, gustKmh: 50, sprayWindKmh: 15 };

export interface DayWx { date: string; tMax: number; tMin: number; rain: number; wind: number; gust: number }
export interface WxAlert { orchard: string; date: string; kind: 'FROST' | 'HEAT' | 'RAIN' | 'GUST' | 'SPRAY'; text: string; level: 'critical' | 'warning' | 'info' }

const KEY = 'miwe_wx_v1';
type Cache = Record<string, { at: number; days: DayWx[] }>;
const readCache = (): Cache => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; } };

export async function fetchWeather(lat: number, lon: number): Promise<DayWx[]> {
  const ck = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const cache = readCache();
  if (cache[ck] && Date.now() - cache[ck].at < 3600000) return cache[ck].days;
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,wind_gusts_10m_max&timezone=Asia%2FAshgabat&forecast_days=7`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Hava servisi ${r.status}`);
  const j = await r.json();
  const d = j.daily || {};
  const days: DayWx[] = (d.time || []).map((t: string, i: number) => ({
    date: t, tMax: d.temperature_2m_max?.[i], tMin: d.temperature_2m_min?.[i], rain: d.precipitation_sum?.[i] ?? 0,
    wind: d.wind_speed_10m_max?.[i] ?? 0, gust: d.wind_gusts_10m_max?.[i] ?? 0,
  }));
  try { localStorage.setItem(KEY, JSON.stringify({ ...readCache(), [ck]: { at: Date.now(), days } })); } catch { /* yoksay */ }
  return days;
}

export function agroAlerts(orchard: string, days: DayWx[], horizon = 3): WxAlert[] {
  const out: WxAlert[] = [];
  for (const d of days.slice(0, horizon)) {
    const day = new Date(`${d.date}T00:00:00`).toLocaleDateString('tr-TR', { weekday: 'long' });
    if (d.tMin <= AGRO_LIMITS.frostC) out.push({ orchard, date: d.date, kind: 'FROST', level: 'critical', text: `${day} don ${Math.round(d.tMin)} °C` });
    if (d.tMax >= AGRO_LIMITS.heatC) out.push({ orchard, date: d.date, kind: 'HEAT', level: 'warning', text: `${day} ${Math.round(d.tMax)} °C · sabah hasadı, hızlı ön soğutma` });
    if (d.rain >= AGRO_LIMITS.rainMm) out.push({ orchard, date: d.date, kind: 'RAIN', level: 'warning', text: `${day} yağmur ${Math.round(d.rain)} mm · hasat durabilir` });
    if (d.gust >= AGRO_LIMITS.gustKmh) out.push({ orchard, date: d.date, kind: 'GUST', level: 'warning', text: `${day} hamle rüzgâr ${Math.round(d.gust)} km/s · dökülme ve sürtme kontrolü` });
    else if (d.wind > AGRO_LIMITS.sprayWindKmh) out.push({ orchard, date: d.date, kind: 'SPRAY', level: 'info', text: `${day} rüzgâr ${Math.round(d.wind)} km/s · ilaçlama uygun değil` });
  }
  return out;
}

/** Birden çok bahçenin havası (koordinatı olanlar). */
export function useOrchardWeather(points: { name: string; lat?: number; lon?: number }[]) {
  const [data, setData] = useState<Record<string, DayWx[]>>({});
  const [error, setError] = useState<string | null>(null);
  const sig = points.map(p => `${p.name}:${p.lat},${p.lon}`).join('|');
  useEffect(() => {
    let alive = true;
    (async () => {
      const res: Record<string, DayWx[]> = {};
      for (const p of points) {
        if (typeof p.lat !== 'number' || typeof p.lon !== 'number') continue;
        try { res[p.name] = await fetchWeather(p.lat, p.lon); } catch (e: any) { if (alive) setError('Hava bilgisi alınamadı (bağlantı).'); }
      }
      if (alive) setData(res);
    })();
    return () => { alive = false; };
  }, [sig]);
  return { data, error };
}
