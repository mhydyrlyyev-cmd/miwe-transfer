/**
 * v49a — Profil tohum verisi (kullanıcının dosyalarından, 23.11.2026):
 *  - tonaj Excel'i (v2_1911 tonajlar genel): bahçe, firma, ürün/çeşit, 2027 plan tonajı
 *  - 2027 verim tahmini (1600 ha): bölüm, parsel, alan, ağaç, çeşit, dikim yılı, anaç
 *  - Book1 (muz): sera bölmeleri, alan, 2027 tonaj
 *  - Açyk ekin býujet 2027: ekin ve alan (para bilgisi alınmadı)
 *  - Bahçe koordinatları: kullanıcının harita noktaları (orchardLocations)
 * Kullanıcı profil ekranında düzenler; bu liste yalnız profil HİÇ yoksa eklenir (id sabit: seed-…).
 */
import type { LocationKind } from '../services/locationProfiles';

export interface SeedProfile {
  id: string;
  kind: LocationKind;
  name: string;
  aliases: string[];
  fields: Record<string, string | number | boolean>;
  note?: string;
}

export const PROFILE_SEED: SeedProfile[] = [
  { id: 'seed-orchard-bagyr', kind: 'ORCHARD', name: 'Bagyr', aliases: ['Bagyr (Nektarin)', 'Bagir'],
    fields: { region: 'Aşgabat', lat: 37.988616, lon: 58.184727, company: 'Nektarin', plan2027Ton: 1042,
      products: 'Elma: Ginger Gold, Golden Delicious, Golden Reinders, Granny Smith, Rosy Glow, Story Inored · Şeftali: Extreme 314, Extreme 436, Plane Summer, Royal Summer, Sweet Dream, UFO-4 · Nektarin: Extreme Red, Fresh Garnet, Gartario · Armut: Williams' } },
  { id: 'seed-orchard-saywan-nektarin', kind: 'ORCHARD', name: 'Saýwan Nektarin', aliases: ['Saywan (Nektarin)', 'Saýwan', 'Saywan', 'Saywan nektarin', 'Saywan nekdarin'],
    fields: { region: 'Balkan', lat: 38.537343, lon: 56.720592, company: 'Nektarin', plan2027Ton: 811,
      products: 'Kiraz: Brooks, Early Burlat, Early Lory, Folfer, Kordia, Lapins, Premier Giant, Regina, Santina, Skeena, Staccato, Sweet Heart · Elma: Early Gold, Gala Vall, Golden Reinders, Rosy Glow, Scarlet Spur · Şeftali: Extreme 436, Plane Delicious, Sweet Dream' } },
  { id: 'seed-orchard-saywan-gursak', kind: 'ORCHARD', name: 'Saýwan Gursak', aliases: ['Gursak', 'Saywan Gursak'],
    fields: { region: 'Balkan', lat: 38.534368, lon: 56.743097, company: 'Gursak', plan2027Ton: 898,
      products: 'Kiraz: Early Burlat, Kordia, Premier Giant, Regina, Staccato · Şeftali: Cresthaven, Extreme 568, Extreme Great, Extreme Gursak, Extreme July, Glohaven, Glosari · Elma: Fuji, Golden Reinders, Rosy Glow, Scarlet Spur · Nektarin: Sweet Lady' } },
  { id: 'seed-orchard-durun', kind: 'ORCHARD', name: 'Durun', aliases: ['Baherden'],
    fields: { region: 'Baherden (Ahal)', lat: 38.383322, lon: 57.432445, company: 'Durun', plan2027Ton: 98,
      products: 'Elma: Scarlet Spur, Golden Reinders, Granny Smith (hasat takviminden)' },
    note: 'Tonaj Excel\'inde "Nektarin · tüm çeşitler, 98 t" yazıyor; hasat takviminde elma. Kontrol edin.' },
  { id: 'seed-orchard-garahan-1200', kind: 'ORCHARD', name: 'Garahan 1200 ha', aliases: ['Garahan (1200)', 'Miwe 1200', 'Garahan1200', 'Garahan 1200'],
    fields: { region: 'Ahal', lat: 37.211482, lon: 59.813087, company: 'MIWE OJSC', sections: 'HS · GB · MA · DM', plan2027Ton: 2500,
      products: 'Badem: Ferraduel, Ferragnes, Lauranne, Makako, Marinada, Nonpareil, Tarraco, Texas, Vairo · Şeftali: Extreme 314, Extreme 514, Extreme Red, Fresh Rock, Gartairo, Plane Sun · Nektarin: Caldesi 85, Extreme 28, Extreme 710, Gartairo, Honey Late · Elma: Ginger Gold, Rosy Glow, Simerenka, Story Inored · Armut: Carmen, Santa Maria, Williams · Nashi: Chojuro, Kosui · Erik: Black Splendor, Pioneer · Hurma: Rojo Brillante' } },
  { id: 'seed-orchard-garahan-1600', kind: 'ORCHARD', name: 'Garahan 1600 ha', aliases: ['Garahan (1628)', '1628 ha', '1628ha', 'Garahan1600', 'Garahan 1600'],
    fields: { region: 'Ahal', lat: 37.190531, lon: 59.888403, areaHa: 1519, treeCount: 632865, rootstock: 'GARNEM', plan2027Ton: 452,
      sections: 'MU 311 ha · 129.537 ağaç · Makako · 2023 | ED 311 ha · 129.537 ağaç · Lauranne + Makako · 2023–26 | IG 300 ha · 124.909 ağaç · Lauranne · 2023 | TE 311 ha · 129.537 ağaç · Vairo + Marta · 2023–25 | LI 286 ha · 119.345 ağaç · Ferragnes + Ferraduel · 2023–24',
      products: 'Badem: Ferraduel, Ferragnes, Lauranne, Makako, Marta, Vairo', plantYears: '2023–2026' } },

  { id: 'seed-gh-garahan-yyladyshana', kind: 'GREENHOUSE', name: 'Garahan Ýyladyşhana', aliases: ['Garahan Teplisa', 'Garahan Yyladyshana', 'Garahan Ýyladyşhana'],
    fields: { crop: 'Kiraz (deneme)', region: 'Ahal' }, note: 'Koordinat girilmedi.' },
  ...([
    ['5 ga', '5GA', 5, 365], ['HS 11-12', 'HS', 10, 870], ['GB 5-6', 'GB', 10, 685], ['GB 7-8', 'GB', 10, 850],
    ['MA 1-2', 'MA', 10, 657], ['MA 3-4', 'MA', 10, 927], ['MU 9-10', 'MU', 10, 911], ['MU 13-14', 'MU', 10, 0],
    ['MU 15-16', 'MU', 10, 0], ['DM 17-18', 'DM', 10, 0], ['DM 19-20', 'DM', 10, 0],
  ] as [string, string, number, number][]).map(([n, sec, ha, t]) => ({
    id: `seed-gh-muz-${n.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`, kind: 'GREENHOUSE' as LocationKind, name: `Muz sera ${n}`,
    aliases: [`Sera ${n}`, `${sec} (${n.split(' ')[1] || n}) muz`],
    fields: { crop: 'Muz', company: sec, areaHa: ha, plan2027Ton: t },
  })),

  { id: 'seed-field-acyk-ekin', kind: 'FIELD', name: 'Açyk ekin (Garahan)', aliases: ['Açyk ekin', 'Acyk ekin', 'Açık ekin'],
    fields: { region: 'Garahan', areaHa: 398,
      crops: 'Soğan şubat 118 ha · Soğan eylül 2026 40 ha · Soğan eylül 2027 50 ha · Patates şubat 55 ha · Patates ağustos 50 ha · Mısır 50 ha · Gara jöwen 20 ha · Kırmızı pancar 10 ha · Sarımsak 5 ha' } },
];
