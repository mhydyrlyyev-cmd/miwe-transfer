import React, { useMemo, useState } from 'react';
import { CalendarRange, Leaf, MapPin, Thermometer, CloudRain, Wind, X, AlertTriangle, ChevronDown } from 'lucide-react';
import type { HarvestRecord } from '../../types';
import { Button, Card, PageHeader, Segmented, Stat, EmptyState } from '../ui';
import {
  buildCalendar, useCalOverrides, saveCalOverride, fmtD, isoD, parseD, expectedBbch, bbchVerdict,
  BBCH_LABEL, type BbchStage, type CalItem,
} from '../../services/harvestCalendar';
import { useLocationProfiles } from '../../services/locationProfiles';
import { useOrchardWeather, agroAlerts, type DayWx } from '../../services/weather';
import { CAL_SEED_ISSUES } from '../../config/harvestCalendarSeed';

/**
 * v49a — Hasat takvimi (platform içi).
 * Bahçe › meyve › çeşit · pencere (BBCH 65 + gün) · gerçek hasat · geçmiş yıllar · tahmini bitiş · hava uyarıları.
 * Her rakamın kaynağı kartta yazar. BBCH gözlemi, elle tarih, rewiz, işçi burada girilir.
 */
interface Props {
  harvestRecords: HarvestRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onBack: () => void;
  onNewHarvest: () => void;
  onOpenProfiles: () => void;
}

const DAY = 86400000;
const t1 = (v?: number) => (v == null ? '—' : v.toLocaleString('tr-TR', { maximumFractionDigits: 1 }));
const STATUS_LABEL = { NOT_STARTED: 'Başlamadı', ACTIVE: 'Hasatta', DONE: 'Bitti' } as const;

export default function HarvestCalendarView(p: Props) {
  const now = Date.now();
  const [season, setSeason] = useState<'2027' | '2026'>(now >= new Date(2027, 1, 1).getTime() ? '2027' : '2026');
  const [fruit, setFruit] = useState('ALL');
  const [orchardF, setOrchardF] = useState('ALL');
  const [open, setOpen] = useState<CalItem | null>(null);
  const [showIssues, setShowIssues] = useState(false);
  const ovs = useCalOverrides();
  const orchards = useLocationProfiles('ORCHARD');
  const S = Number(season);
  const items = useMemo(() => buildCalendar(S, ovs, p.harvestRecords, now), [S, ovs, p.harvestRecords]);

  const fruits = useMemo(() => [...new Set(items.map(i => i.fruit))], [items]);
  const orchardNames = useMemo(() => [...new Set(items.map(i => i.orchard))], [items]);
  const shown = items.filter(i => (fruit === 'ALL' || i.fruit === fruit) && (orchardF === 'ALL' || i.orchard === orchardF));

  // zaman ekseni: sezonun 1 Mayıs – 31 Ekim (pencere dışı olanlar kenara sıkışır)
  const axS = new Date(S, 4, 1).getTime(); const axE = new Date(S, 10, 1).getTime(); const span = axE - axS;
  const P = (t?: number) => (t == null ? 0 : Math.max(0, Math.min(100, ((t - axS) / span) * 100)));

  const active = items.filter(i => i.status === 'ACTIVE' && i.hasProgress);
  const openNoData = items.filter(i => i.status === 'ACTIVE' && !i.hasProgress);
  const risky = items.filter(i => i.risk === 'RISK' || (i.risk === 'LATE' && i.status !== 'DONE'));
  const doneInWin = items.filter(i => i.status === 'DONE' && i.risk === 'OK').length;
  const doneAll = items.filter(i => i.status === 'DONE').length;
  const totTarget = items.reduce((a, i) => a + (i.targetTon || 0), 0);
  const totDone = items.reduce((a, i) => a + (i.doneTon || 0), 0);
  const next14 = items.filter(i => i.status === 'NOT_STARTED' && i.windowStart && i.windowStart >= now && i.windowStart <= now + 14 * DAY).sort((a, b) => a.windowStart! - b.windowStart!);

  // hava: hasatta veya 14 gün içinde başlayacak bahçeler; yoksa tüm bahçeler
  const wxNames = new Set((active.length || next14.length ? [...active, ...next14] : items).map(i => i.orchard));
  const points = orchards.filter(o => wxNames.has(o.name)).map(o => ({ name: o.name, lat: Number(o.fields.lat) || undefined, lon: Number(o.fields.lon) || undefined }));
  const { data: wx, error: wxErr } = useOrchardWeather(points);
  const alerts = Object.entries(wx).flatMap(([n, d]) => agroAlerts(n, d));

  let lastOrchard = '';
  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader onBack={p.onBack} title="Hasat takvimi" subtitle={`Bahçe › meyve › çeşit · ${S}${S === 2026 ? ' gerçekleşen' : ' plan'}`}
        actions={<div className="flex gap-2">
          <Button size="sm" variant="soft" tone="slate" icon={<MapPin />} onClick={p.onOpenProfiles}>Profiller</Button>
          {!p.isReadOnly && <Button size="sm" tone="emerald" icon={<Leaf />} onClick={p.onNewHarvest}>Yeni hasat</Button>}
        </div>} />

      <Segmented ariaLabel="Sezon" value={season} onChange={(k) => setSeason(k as '2027' | '2026')} items={[{ key: '2027', label: '2027 plan' }, { key: '2026', label: '2026 gerçekleşen' }]} />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <Stat label="Hasatta" value={active.length} unit="çeşit" />
        <Stat label={S === 2026 ? 'Hasat / plan' : 'Hasat / plan 2027'} value={`${t1(totDone)} / ${t1(totTarget)}`} unit="t" />
        <Stat label="Pencere içinde biten" value={`${doneInWin} / ${doneAll}`} tone={doneAll && doneInWin < doneAll ? 'warn' : 'neutral'} />
        <Stat label="Risk" value={risky.length} tone={risky.length ? 'error' : 'neutral'} />
      </div>

      {(alerts.length > 0 || wxErr) && (
        <Card title="Hava uyarıları" subtitle="Önümüzdeki 3 gün · Open-Meteo · eşikler iç hedef" padding="sm">
          {wxErr && <p className="text-xs text-slate-500">{wxErr}</p>}
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {alerts.slice(0, 8).map((a, i) => (
              <li key={i} className={`py-2 text-sm flex gap-2 ${a.level === 'critical' ? 'text-rose-800 dark:text-rose-300' : a.level === 'warning' ? 'text-amber-800 dark:text-amber-300' : 'text-slate-600 dark:text-slate-300'}`}>
                {a.kind === 'GUST' || a.kind === 'SPRAY' ? <Wind className="w-4 h-4 mt-0.5 shrink-0" /> : a.kind === 'RAIN' ? <CloudRain className="w-4 h-4 mt-0.5 shrink-0" /> : <Thermometer className="w-4 h-4 mt-0.5 shrink-0" />}
                <span><b className="font-semibold">{a.orchard}</b> · {a.text}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Hasattaki ve riskli kartlar (risk önce) */}
      {[...risky.filter(i => i.status === 'ACTIVE'), ...active.filter(i => i.risk !== 'RISK')].map(i => (
        <ActiveCard key={i.key} item={i} wx={wx[i.orchard]} onOpen={() => setOpen(i)} />
      ))}

      {openNoData.length > 0 && (
        <Card title="Kaydı eksik hasatlar" subtitle="Başlangıç var, kg kaydı veya bitiş tarihi yok" padding="sm">
          <ul className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {openNoData.slice(0, 12).map(i => (
              <li key={i.key}><button type="button" onClick={() => setOpen(i)} className="w-full flex justify-between gap-2 py-2 text-left cursor-pointer">
                <span>{i.orchard} · {i.fruit} · {i.variety}</span><span className="text-slate-500 tabular-nums shrink-0">başladı {fmtD(i.start!)}</span>
              </button></li>
            ))}
          </ul>
        </Card>
      )}

      {next14.length > 0 && (
        <Card title="Sıradaki 14 gün" padding="sm">
          <ul className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {next14.slice(0, 10).map(i => (
              <li key={i.key}><button type="button" onClick={() => setOpen(i)} className="w-full flex justify-between gap-2 py-2 text-left cursor-pointer">
                <span>{i.orchard} · {i.fruit} · {i.variety}</span><span className="text-slate-500 tabular-nums shrink-0">~{fmtD(i.windowStart!)}</span>
              </button></li>
            ))}
          </ul>
        </Card>
      )}

      <Card title="Takvim" subtitle="Pencereye bas → çeşit kartı" padding="sm"
        actions={<div className="flex gap-2">
          <select aria-label="Meyve" value={fruit} onChange={e => setFruit(e.target.value)} className="min-h-[36px] rounded-lg border border-slate-300 bg-white px-2 text-xs dark:bg-slate-900 dark:border-slate-700">
            <option value="ALL">Tüm meyveler</option>{fruits.map(f => <option key={f}>{f}</option>)}
          </select>
          <select aria-label="Bahçe" value={orchardF} onChange={e => setOrchardF(e.target.value)} className="min-h-[36px] rounded-lg border border-slate-300 bg-white px-2 text-xs dark:bg-slate-900 dark:border-slate-700">
            <option value="ALL">Tüm bahçeler</option>{orchardNames.map(f => <option key={f}>{f}</option>)}
          </select>
        </div>}>
        <div className="grid grid-cols-[118px_1fr] gap-2 text-[11px] text-slate-500 mb-1">
          <span />
          <div className="flex justify-between"><span>May</span><span>Haz</span><span>Tem</span><span>Ağu</span><span>Eyl</span><span>Eki</span></div>
        </div>
        {shown.length === 0 && <EmptyState icon={<CalendarRange className="w-5 h-5" />} title="Bu filtrede çeşit yok" description="Meyve veya bahçe filtresini değiştirin." />}
        {[...shown].sort((a, b) => a.orchard.localeCompare(b.orchard, 'tr') || (a.windowStart || 0) - (b.windowStart || 0)).map(i => {
          const head = i.orchard !== lastOrchard; lastOrchard = i.orchard;
          const ws = P(i.windowStart), we = P(i.windowEnd);
          const barTone = i.risk === 'RISK' ? 'bg-rose-200' : i.risk === 'LATE' ? 'bg-amber-200' : 'bg-emerald-200';
          return (
            <div key={i.key}>
              {head && <div className="text-xs font-bold text-slate-900 dark:text-white mt-3 mb-0.5">{i.orchard}</div>}
              <button type="button" onClick={() => setOpen(i)} className="w-full grid grid-cols-[118px_1fr] gap-2 items-center py-1.5 border-t border-slate-100 dark:border-slate-800 text-left cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <span className="text-xs text-slate-700 dark:text-slate-300 leading-tight truncate" title={`${i.fruit} · ${i.variety}`}>{i.fruit} · {i.variety}</span>
                <span className="relative h-5 rounded bg-slate-50 dark:bg-slate-800 block">
                  {i.windowStart && <span className={`absolute top-1 h-3 rounded ${barTone}`} style={{ left: `${ws}%`, width: `${Math.max(1.5, we - ws)}%` }} />}
                  {i.start && <span className="absolute top-[7px] h-1.5 rounded bg-emerald-700" style={{ left: `${P(i.start)}%`, width: `${Math.max(1.2, P(i.end || i.finishEst || (i.start + 3 * DAY)) - P(i.start))}%` }} />}
                  {i.histAvg && <span className="absolute top-0 h-5 w-0.5 bg-amber-700" style={{ left: `${P(i.histAvg)}%` }} />}
                </span>
              </button>
            </div>
          );
        })}
        <div className="flex flex-wrap gap-3 mt-3 text-[11px] text-slate-500">
          <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-emerald-200" />Pencere</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1 bg-emerald-700" />Gerçek hasat</span>
          <span className="flex items-center gap-1"><span className="w-0.5 h-3 bg-amber-700" />Geçmiş yıllar ort.</span>
          <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-rose-200" />Risk</span>
        </div>
      </Card>

      {CAL_SEED_ISSUES.length > 0 && (
        <Card padding="sm">
          <button type="button" onClick={() => setShowIssues(v => !v)} className="w-full flex items-center justify-between text-sm font-semibold text-slate-800 dark:text-slate-200 cursor-pointer">
            <span className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-600" />Tablodaki veri sorunları ({CAL_SEED_ISSUES.length})</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${showIssues ? 'rotate-180' : ''}`} />
          </button>
          {showIssues && <ul className="mt-2 text-xs text-slate-600 dark:text-slate-400 space-y-1">{CAL_SEED_ISSUES.map(s => <li key={s}>• {s}</li>)}</ul>}
        </Card>
      )}

      {open && <VarietySheet item={items.find(x => x.key === open.key) || open} wx={wx[open.orchard]} isReadOnly={p.isReadOnly} by={p.currentUserName} onClose={() => setOpen(null)} />}
    </div>
  );
}

function WxLine({ days }: { days?: DayWx[] }) {
  if (!days?.length) return null;
  const [d0, d1] = days;
  return (
    <div className="flex flex-wrap gap-3 text-xs text-slate-600 dark:text-slate-300 mt-2 pt-2 border-t border-slate-100 dark:border-slate-800">
      <span className="flex items-center gap-1"><Thermometer className="w-3.5 h-3.5" />{Math.round(d0.tMax)}° / {Math.round(d0.tMin)}°</span>
      <span className="flex items-center gap-1"><CloudRain className="w-3.5 h-3.5" />{Math.round(d0.rain)} mm</span>
      <span className={`flex items-center gap-1 ${d0.gust >= 50 ? 'text-amber-700 dark:text-amber-300' : ''}`}><Wind className="w-3.5 h-3.5" />hamle {Math.round(d0.gust)} km/s</span>
      {d1 && <span className="text-slate-500">yarın {Math.round(d1.tMax)}°</span>}
    </div>
  );
}

function ActiveCard({ item: i, wx, onOpen }: { item: CalItem; wx?: DayWx[]; onOpen: () => void }) {
  const pct = i.targetTon ? Math.min(100, (i.doneTon / i.targetTon) * 100) : 0;
  const risk = i.risk === 'RISK';
  return (
    <Card padding="sm" accent={risk ? 'error' : 'ok'}>
      <button type="button" onClick={onOpen} className="w-full text-left cursor-pointer">
        <div className="flex justify-between items-start gap-2">
          <div className="font-bold text-slate-900 dark:text-white">{i.orchard} › {i.fruit} › {i.variety}</div>
          <span className={`shrink-0 text-xs font-bold px-2 py-0.5 rounded-full border ${risk ? 'bg-rose-50 text-rose-800 border-rose-200' : 'bg-emerald-50 text-emerald-800 border-emerald-200'}`}>{risk ? 'Risk' : 'Yolunda'}</span>
        </div>
        <div className="text-xs text-slate-500">Pencere {fmtD(i.windowStart!)}–{fmtD(i.windowEnd!)} · başladı {fmtD(i.start!)}</div>
        <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 my-2 overflow-hidden"><div className="h-full bg-emerald-700" style={{ width: `${pct}%` }} /></div>
        <div className="flex justify-between text-sm tabular-nums"><span>{t1(i.doneTon)} / {t1(i.targetTon)} t</span><span className="text-slate-600 dark:text-slate-300">{i.workers ?? '—'} işçi × {i.kgPerWorker ?? '—'} kg</span></div>
        <div className="text-sm mt-1">Tahmini bitiş <b className={risk ? 'text-rose-700 dark:text-rose-300' : ''}>{i.finishEst ? fmtD(i.finishEst) : '—'}</b> · pencere {fmtD(i.windowEnd!)}</div>
        {i.advice && <div className="text-xs mt-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 px-2 py-1.5">{i.advice}</div>}
      </button>
      <WxLine days={wx} />
    </Card>
  );
}

function VarietySheet({ item: i, wx, isReadOnly, by, onClose }: { item: CalItem; wx?: DayWx[]; isReadOnly?: boolean; by: string; onClose: () => void }) {
  const [stage, setStage] = useState<BbchStage>('65');
  const [date, setDate] = useState(isoD(Date.now()));
  const [diam, setDiam] = useState('');
  const [mStart, setMStart] = useState(i.ov?.manualStart || '');
  const [mEnd, setMEnd] = useState(i.ov?.manualEnd || '');
  const [rewiz, setRewiz] = useState(i.ov?.rewizTon != null ? String(i.ov.rewizTon) : '');
  const [workers, setWorkers] = useState(i.ov?.workers != null ? String(i.ov.workers) : '');
  const [kgpw, setKgpw] = useState(i.ov?.kgPerWorker != null ? String(i.ov.kgPerWorker) : '');
  const [msg, setMsg] = useState<string | null>(null);
  const num = (s: string) => { const n = Number(s.replace(',', '.')); return s.trim() && Number.isFinite(n) ? n : undefined; };
  const input = 'w-full min-h-[40px] rounded-xl border border-slate-300 bg-white px-3 text-sm dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100';
  const label = 'block text-xs text-slate-500 mb-1';
  const exp = expectedBbch(i, stage);
  const stages: BbchStage[] = ['65', '71', '81', '85'];
  const is2026 = i.season === 2026;

  const saveBbch = async () => {
    if (!date) { setMsg('Tarih girin.'); return; }
    const ok = await saveCalOverride(i.season, i.orchard, i.variety, { bbch: { [stage]: date }, ...(num(diam) != null ? { diameterMm: num(diam) } : {}) }, by);
    setMsg(ok ? 'Kaydedildi.' : 'Yerel kaydedildi; sunucuya yazılamadı (oturum veya bağlantı).');
  };
  const savePlan = async () => {
    const ok = await saveCalOverride(i.season, i.orchard, i.variety, { manualStart: mStart || undefined, manualEnd: mEnd || undefined, rewizTon: num(rewiz), workers: num(workers), kgPerWorker: num(kgpw) }, by);
    setMsg(ok ? 'Kaydedildi.' : 'Yerel kaydedildi; sunucuya yazılamadı (oturum veya bağlantı).');
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full sm:max-w-lg max-h-[92vh] overflow-y-auto bg-slate-50 dark:bg-slate-950 rounded-t-3xl sm:rounded-3xl" onClick={e => e.stopPropagation()} role="dialog" aria-label="Çeşit kartı">
        <div className="sticky top-0 flex items-start justify-between gap-3 px-5 py-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="font-bold text-slate-900 dark:text-white">{i.orchard} › {i.fruit} › {i.variety}</div>
            <div className="text-xs text-slate-500">{STATUS_LABEL[i.status]} · pencere {fmtD(i.windowStart!)}–{fmtD(i.windowEnd!)} · {i.windowSource}</div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" aria-label="Kapat"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-4 space-y-3">
          <Card padding="sm" title="Özet">
            <dl className="text-sm divide-y divide-slate-100 dark:divide-slate-800">
              {[
                ['Geçmiş yıllar ortalaması', i.histAvg ? `${fmtD(i.histAvg)} (${i.histYears} yıl)${i.histGapDays ? ` · pencere ${i.histGapDays > 0 ? '+' : ''}${i.histGapDays} gün` : ''}` : '—'],
                ['2024 · 2025 hasat', `${i.seed.h2024 ? fmtD(parseD(i.seed.h2024)) : '—'} · ${i.seed.h2025 ? fmtD(parseD(i.seed.h2025)) : '—'}`],
                ['Hedef tonaj', `${t1(i.targetTon)} t · ${i.targetSource}`],
                ['Hasat edilen', `${t1(i.doneTon)} t${i.offgradeTon ? ` · sort däl ${t1(i.offgradeTon)} t (tonaja girmez)` : ''}`],
                ['Gerçek başlangıç / bitiş', `${i.start ? fmtD(i.start) : '—'} / ${i.end ? fmtD(i.end) : '—'}`],
                ['İşçi × kg/gün', `${i.workers ?? '—'} × ${i.kgPerWorker ?? '—'}${i.ratePerDay ? ` = ${t1(i.ratePerDay)} t/gün` : ''}`],
                ['Tahmini bitiş', i.finishEst ? fmtD(i.finishEst) : '—'],
              ].map(([k, v]) => <div key={k} className="flex justify-between gap-3 py-1.5"><dt className="text-slate-500">{k}</dt><dd className="text-right tabular-nums">{v}</dd></div>)}
            </dl>
            {i.advice && <div className="text-xs mt-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 px-2 py-1.5">{i.advice}</div>}
            <WxLine days={wx} />
          </Card>

          <Card padding="sm" title="BBCH aşamaları" subtitle={is2026 ? 'Tablodaki 2026 gözlemleri' : 'Beklenen tarih: geçen sezonun aynı günü'}>
            <dl className="text-sm divide-y divide-slate-100 dark:divide-slate-800">
              {stages.map(s => {
                const obs = is2026 ? (i.seed as any)[`bbch${s}`] as string | null : i.ov?.bbch?.[s];
                const e = expectedBbch(i, s);
                const v = !is2026 ? bbchVerdict(obs || undefined, e) : undefined;
                return (
                  <div key={s} className="flex justify-between gap-3 py-1.5">
                    <dt>{s} · {BBCH_LABEL[s]}</dt>
                    <dd className="text-right tabular-nums">{obs ? fmtD(parseD(obs)) : '—'}
                      <span className={`block text-[11px] ${v?.tone === 'ok' ? 'text-emerald-700' : v ? 'text-amber-700' : 'text-slate-500'}`}>{v ? v.label : !is2026 && e ? `beklenen ~${fmtD(e)}` : ''}</span>
                    </dd>
                  </div>
                );
              })}
            </dl>
          </Card>

          {!isReadOnly && !is2026 && (
            <Card padding="sm" title="BBCH gözlemi gir" subtitle="Kaliteci veya agronom">
              <div className="grid grid-cols-2 gap-2">
                {stages.map(s => (
                  <button key={s} type="button" onClick={() => setStage(s)} className={`rounded-xl border px-3 py-2 text-left cursor-pointer ${stage === s ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40' : 'border-slate-200 dark:border-slate-700'}`}>
                    <div className="text-sm font-bold">{s}</div><div className="text-xs text-slate-600 dark:text-slate-400">{BBCH_LABEL[s]}</div>
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2 mt-3">
                <div><label className={label}>Gözlem tarihi</label><input type="date" className={input} value={date} onChange={e => setDate(e.target.value)} /></div>
                <div><label className={label}>Ortalama çap (mm)</label><input inputMode="decimal" className={input} value={diam} onChange={e => setDiam(e.target.value)} /></div>
              </div>
              {exp && <p className="text-xs text-slate-500 mt-2">Beklenen ~{fmtD(exp)}{bbchVerdict(date, exp) ? ` · ${bbchVerdict(date, exp)!.label}` : ''}</p>}
              <Button className="mt-3 w-full" tone="emerald" onClick={saveBbch}>Gözlemi kaydet</Button>
            </Card>
          )}

          {!isReadOnly && (
            <Card padding="sm" title="Plan ve işçi" subtitle="Elle tarih otomatik tahminin önüne geçer">
              <div className="grid grid-cols-2 gap-2">
                <div><label className={label}>Hasat başlangıcı (elle)</label><input type="date" className={input} value={mStart} onChange={e => setMStart(e.target.value)} /></div>
                <div><label className={label}>Hasat bitişi (elle)</label><input type="date" className={input} value={mEnd} onChange={e => setMEnd(e.target.value)} /></div>
                <div><label className={label}>Rewiz tonaj (t)</label><input inputMode="decimal" className={input} value={rewiz} onChange={e => setRewiz(e.target.value)} placeholder={i.targetTon != null ? String(i.targetTon) : ''} /></div>
                <div><label className={label}>İşçi sayısı</label><input inputMode="numeric" className={input} value={workers} onChange={e => setWorkers(e.target.value)} placeholder={i.workers != null ? String(i.workers) : ''} /></div>
                <div><label className={label}>kg / işçi / gün</label><input inputMode="decimal" className={input} value={kgpw} onChange={e => setKgpw(e.target.value)} placeholder={i.kgPerWorker != null ? String(i.kgPerWorker) : ''} /></div>
              </div>
              <p className="text-xs text-slate-500 mt-2">İşçi ve kg normalde günlük hasat formundan gelir; burada yalnız düzeltme için.</p>
              <Button className="mt-3 w-full" variant="soft" tone="emerald" onClick={savePlan}>Planı kaydet</Button>
            </Card>
          )}
          {msg && <p className="text-sm text-center text-slate-700 dark:text-slate-300">{msg}</p>}
        </div>
      </div>
    </div>
  );
}
