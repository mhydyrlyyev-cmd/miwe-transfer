import React, { useId } from 'react';

/**
 * MIWE HIL logosu (v39.1) — orijinal amblemin yenilenmiş hali.
 * Turuncu muz yarımı (olgun meyve / hasat, biraz aşağıda) + orta damarından bölünmüş yarım yaprak
 * (tazelik / soğuk zincir, ucu çizgide kalır) · gümüş dikey çizgi = izlenebilirlik süreci ·
 * altın halka = kalite standardı, kesikli dış halka = zaman.
 * 32 px ve altında halkalar düşer, yalnız amblem kalır.
 * variant: 'tile' (zümrüt kare, varsayılan) | 'light' (açık zemin) | 'dark' (koyu zemin)
 */
const TILE = `<defs><radialGradient id="bgTE" cx="50%" cy="42%" r="68%"><stop offset="0" stop-color="#046A44"/><stop offset=".45" stop-color="#024D31"/><stop offset="1" stop-color="#011B11"/></radialGradient>
<linearGradient id="auTE" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FEF08A"/><stop offset=".4" stop-color="#EAB308"/><stop offset="1" stop-color="#B45309"/></linearGradient>
<linearGradient id="orTE" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FBBF24"/><stop offset="1" stop-color="#EA7A0C"/></linearGradient>
<linearGradient id="grTE" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4ADE9F"/><stop offset="1" stop-color="#0E9F6E"/></linearGradient></defs><rect x="1" y="1" width="62" height="62" rx="15" fill="url(#bgTE)"/><rect x="1.6" y="1.6" width="60.8" height="60.8" rx="14.4" fill="none" stroke="url(#auTE)" stroke-opacity=".55" stroke-width=".8"/><circle cx="32" cy="32" r="22.5" fill="none" stroke="url(#auTE)" stroke-width=".7" stroke-dasharray="2.2 1.6" opacity=".9"/><circle cx="32" cy="32" r="19.6" fill="none" stroke="url(#auTE)" stroke-width="1.3"/><g transform="translate(32 32.6) scale(.86) translate(-32 -31)"><path d="M31 21.8 C23.4 23.6 19.6 29.6 19.9 35.2 C20.2 41.2 24.8 45.6 31 46 Z" fill="url(#orTE)"/><path d="M31 21.8 C31 20.6 31.4 19.6 32 18.9" stroke="#7A4A10" stroke-width="1.5" fill="none" stroke-linecap="round"/><circle cx="31" cy="46" r=".8" fill="#5A3A10"/><path d="M33 16.6 C38.6 20 43.8 25.4 44.2 31.6 C44.6 37.4 39.8 42.2 33 43.6 Z" fill="url(#grTE)"/><path d="M33.4 28 C36 26.4 38.4 24.6 40.4 22.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 34 C36 32.4 38.4 30.6 41.8 28.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 40 C36 38.4 38.4 36.6 40.2 34.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><rect x="31.55" y="15.2" width="0.9" height="32.6" rx=".45" fill="#E5E7EB"/></g>`;
const TILE_SMALL = `<defs><radialGradient id="bgTL" cx="50%" cy="42%" r="68%"><stop offset="0" stop-color="#046A44"/><stop offset=".45" stop-color="#024D31"/><stop offset="1" stop-color="#011B11"/></radialGradient>
<linearGradient id="auTL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FEF08A"/><stop offset=".4" stop-color="#EAB308"/><stop offset="1" stop-color="#B45309"/></linearGradient>
<linearGradient id="orTL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FBBF24"/><stop offset="1" stop-color="#EA7A0C"/></linearGradient>
<linearGradient id="grTL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4ADE9F"/><stop offset="1" stop-color="#0E9F6E"/></linearGradient></defs><rect x="1" y="1" width="62" height="62" rx="15" fill="url(#bgTL)"/><rect x="1.6" y="1.6" width="60.8" height="60.8" rx="14.4" fill="none" stroke="url(#auTL)" stroke-opacity=".55" stroke-width=".8"/><g transform="translate(32 32) scale(1.18) translate(-32 -31.2)"><path d="M31 21.8 C23.4 23.6 19.6 29.6 19.9 35.2 C20.2 41.2 24.8 45.6 31 46 Z" fill="url(#orTL)"/><path d="M31 21.8 C31 20.6 31.4 19.6 32 18.9" stroke="#7A4A10" stroke-width="1.5" fill="none" stroke-linecap="round"/><circle cx="31" cy="46" r=".8" fill="#5A3A10"/><path d="M33 16.6 C38.6 20 43.8 25.4 44.2 31.6 C44.6 37.4 39.8 42.2 33 43.6 Z" fill="url(#grTL)"/><path d="M33.4 28 C36 26.4 38.4 24.6 40.4 22.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 34 C36 32.4 38.4 30.6 41.8 28.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 40 C36 38.4 38.4 36.6 40.2 34.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><rect x="31.55" y="15.2" width="0.9" height="32.6" rx=".45" fill="#E5E7EB"/></g>`;
const LIGHT = `<defs><radialGradient id="bgLT" cx="50%" cy="42%" r="68%"><stop offset="0" stop-color="#046A44"/><stop offset=".45" stop-color="#024D31"/><stop offset="1" stop-color="#011B11"/></radialGradient>
<linearGradient id="auLT" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FEF08A"/><stop offset=".4" stop-color="#EAB308"/><stop offset="1" stop-color="#B45309"/></linearGradient>
<linearGradient id="orLT" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FBBF24"/><stop offset="1" stop-color="#EA7A0C"/></linearGradient>
<linearGradient id="grLT" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4ADE9F"/><stop offset="1" stop-color="#0E9F6E"/></linearGradient></defs><circle cx="32" cy="32" r="22.5" fill="none" stroke="#B7861A" stroke-width=".7" stroke-dasharray="2.2 1.6" opacity=".9"/><circle cx="32" cy="32" r="19.6" fill="none" stroke="#B7861A" stroke-width="1.3"/><g transform="translate(32 32.6) scale(.86) translate(-32 -31)"><path d="M31 21.8 C23.4 23.6 19.6 29.6 19.9 35.2 C20.2 41.2 24.8 45.6 31 46 Z" fill="url(#orLT)"/><path d="M31 21.8 C31 20.6 31.4 19.6 32 18.9" stroke="#7A4A10" stroke-width="1.5" fill="none" stroke-linecap="round"/><circle cx="31" cy="46" r=".8" fill="#5A3A10"/><path d="M33 16.6 C38.6 20 43.8 25.4 44.2 31.6 C44.6 37.4 39.8 42.2 33 43.6 Z" fill="url(#grLT)"/><path d="M33.4 28 C36 26.4 38.4 24.6 40.4 22.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 34 C36 32.4 38.4 30.6 41.8 28.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 40 C36 38.4 38.4 36.6 40.2 34.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><rect x="31.55" y="15.2" width="0.9" height="32.6" rx=".45" fill="#E5E7EB"/></g>`;
const DARK = `<defs><radialGradient id="bgDK" cx="50%" cy="42%" r="68%"><stop offset="0" stop-color="#046A44"/><stop offset=".45" stop-color="#024D31"/><stop offset="1" stop-color="#011B11"/></radialGradient>
<linearGradient id="auDK" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FEF08A"/><stop offset=".4" stop-color="#EAB308"/><stop offset="1" stop-color="#B45309"/></linearGradient>
<linearGradient id="orDK" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FBBF24"/><stop offset="1" stop-color="#EA7A0C"/></linearGradient>
<linearGradient id="grDK" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4ADE9F"/><stop offset="1" stop-color="#0E9F6E"/></linearGradient></defs><circle cx="32" cy="32" r="22.5" fill="none" stroke="url(#auDK)" stroke-width=".7" stroke-dasharray="2.2 1.6" opacity=".9"/><circle cx="32" cy="32" r="19.6" fill="none" stroke="url(#auDK)" stroke-width="1.3"/><g transform="translate(32 32.6) scale(.86) translate(-32 -31)"><path d="M31 21.8 C23.4 23.6 19.6 29.6 19.9 35.2 C20.2 41.2 24.8 45.6 31 46 Z" fill="url(#orDK)"/><path d="M31 21.8 C31 20.6 31.4 19.6 32 18.9" stroke="#7A4A10" stroke-width="1.5" fill="none" stroke-linecap="round"/><circle cx="31" cy="46" r=".8" fill="#5A3A10"/><path d="M33 16.6 C38.6 20 43.8 25.4 44.2 31.6 C44.6 37.4 39.8 42.2 33 43.6 Z" fill="url(#grDK)"/><path d="M33.4 28 C36 26.4 38.4 24.6 40.4 22.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 34 C36 32.4 38.4 30.6 41.8 28.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><path d="M33.4 40 C36 38.4 38.4 36.6 40.2 34.4" stroke="#fff" stroke-opacity=".38" stroke-width=".75" fill="none" stroke-linecap="round"/><rect x="31.55" y="15.2" width="0.9" height="32.6" rx=".45" fill="#E5E7EB"/></g>`;

interface BrandLogoProps {
  className?: string;
  size?: number | string;
  showText?: boolean;
  variant?: 'tile' | 'light' | 'dark';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 48,
  showText = false,
  variant = 'tile',
}) => {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const dim = typeof size === 'number' ? `${size}px` : size;
  const small = typeof size === 'number' && size <= 32;
  const src = variant === 'dark' ? DARK : variant === 'light' ? LIGHT : small ? TILE_SMALL : TILE;
  // Aynı sayfada birden çok logo olduğunda gradient kimlikleri çakışmasın
  const inner = src.replace(/(id="|url\(#)(bg|au|or|gr)[A-Z]+/g, (_m, a, b) => `${a}${b}${uid}`);
  return (
    <div className={`inline-flex items-center gap-2.5 shrink-0 ${className}`}>
      <svg
        viewBox="0 0 64 64"
        style={{ width: dim, height: dim }}
        className="shrink-0"
        role="img"
        aria-label="MIWE HIL"
        xmlns="http://www.w3.org/2000/svg"
        dangerouslySetInnerHTML={{ __html: inner }}
      />
      {showText && (
        <div className="flex flex-col leading-tight">
          <span className={`font-black text-sm tracking-tight ${variant === 'dark' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
            MIWE HIL
          </span>
          <span className={`text-[9px] font-bold tracking-wider uppercase ${variant === 'dark' ? 'text-emerald-300' : 'text-emerald-600 dark:text-emerald-400'}`}>
            Quality &amp; Traceability
          </span>
        </div>
      )}
    </div>
  );
};

export default BrandLogo;
