import { OnionIcon, PotatoIcon } from '../common/CropIcons';
import React, { useMemo } from 'react';
import {
  Leaf, Snowflake, Warehouse, Truck, Search, FlaskConical, ShieldAlert, Banana, Nut, Wind, ShoppingCart, Globe2,
  BarChart3, FileText, BookOpen, ListChecks, HelpCircle, History, Users, AlertTriangle, ArrowRight, Wifi, WifiOff, LayoutDashboard,
} from 'lucide-react';
import type { ReferenceItem } from '../../types';
import type { AppUser } from '../../types/auth';
import type { StageKey } from '../../config/processStages';
import { lifecycleCounts } from '../../utils/refLifecycle';

/**
 * v3.9 — Ana menü (eski "Portal Komut Merkezi" yerine).
 * Tasarım: açılış ekranı = selam + arama + 4 aşama + hızlı işlemler + diğer modüller + raporlar + yardım.
 * Uzun açıklama yok; her kutu bir simge ve kısa ad.
 */
interface Props {
  currentUser?: AppUser | null;
  references: ReferenceItem[];
  isOnline: boolean;
  pendingCount: number;
  alertCount: number;
  stageBadges: Partial<Record<StageKey, number>>;
  onNavigate: (view: string, tab?: string) => void;
  onOpenSearch: () => void;
  onOpenUsers?: () => void;
}

type Tile = { label: string; view: string; tab?: string; icon: React.ReactNode; tone: string; adminOnly?: boolean };

const STAGE_TILES: { key: StageKey; no: number; label: string; view: string; icon: React.ReactNode; soft: string; text: string }[] = [
  { key: 'HASAT', no: 1, label: 'Hasat', view: 'HARVEST', icon: <Leaf className="w-6 h-6" />, soft: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300', text: 'text-emerald-700 dark:text-emerald-300' },
  { key: 'ON_SOGUTMA', no: 2, label: 'Ön soğutma', view: 'PRECOOLING', icon: <Snowflake className="w-6 h-6" />, soft: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300', text: 'text-sky-700 dark:text-sky-300' },
  { key: 'SOGUK_DEPO', no: 3, label: 'Soğuk depo', view: 'COLD_STORAGE', icon: <Warehouse className="w-6 h-6" />, soft: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300', text: 'text-indigo-700 dark:text-indigo-300' },
  { key: 'SEVK', no: 4, label: 'Sevk', view: 'TRANSIT', icon: <Truck className="w-6 h-6" />, soft: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', text: 'text-amber-800 dark:text-amber-300' },
];

const QUICK: Tile[] = [
  { label: 'Yeni hasat', view: 'HARVEST', icon: <Leaf className="w-5 h-5" />, tone: 'text-emerald-700' },
  { label: 'Ön soğutma fişi', view: 'PRECOOLING', icon: <Snowflake className="w-5 h-5" />, tone: 'text-sky-700' },
  { label: 'Depo kabul', view: 'AMBAR', icon: <Warehouse className="w-5 h-5" />, tone: 'text-indigo-700' },
  { label: 'Sevk kaydı', view: 'LOJISTIK', icon: <Truck className="w-5 h-5" />, tone: 'text-amber-800' },
  { label: 'Saha testi', view: 'FIELD', icon: <FlaskConical className="w-5 h-5" />, tone: 'text-violet-700' },
  { label: 'Akt / incident', view: 'INCIDENT', icon: <ShieldAlert className="w-5 h-5" />, tone: 'text-rose-700' },
];
const OTHER: Tile[] = [
  { label: 'Muz', view: 'MUZ', icon: <Banana className="w-5 h-5" />, tone: 'text-yellow-700' },
  { label: 'Badem', view: 'BADEM', icon: <Nut className="w-5 h-5" />, tone: 'text-orange-800' },
  { label: 'Diğer ürünler', view: 'FIELD', icon: <span className="inline-flex -space-x-1"><OnionIcon className="w-5 h-5" /><PotatoIcon className="w-5 h-5" /></span>, tone: 'text-fuchsia-800' },
  { label: 'Freeze-dry', view: 'FREEZE_DRY', icon: <Wind className="w-5 h-5" />, tone: 'text-cyan-700' },
  { label: 'Satış', view: 'SALES', icon: <ShoppingCart className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'İhracat numunesi', view: 'EXPORT_SAMPLE', icon: <Globe2 className="w-5 h-5" />, tone: 'text-slate-700' },
];
const REPORTS: Tile[] = [
  { label: 'Rapor merkezi', view: 'REPORT_CENTER', icon: <BarChart3 className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'Aylık yönetim özeti', view: 'REPORTING_PORTAL', tab: 'MONTHLY_REPORT', icon: <FileText className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'İzlenebilirlik defteri', view: 'TRACEABILITY_LEDGER', icon: <BookOpen className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'İstatistik analizi', view: 'REPORTING_PORTAL', tab: 'ANALYTICS', icon: <BarChart3 className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'Standartlar kılavuzu', view: 'REPORTING_PORTAL', tab: 'STANDARDS_4LANG', icon: <BookOpen className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'Referanslar', view: 'REFERENCES', icon: <ListChecks className="w-5 h-5" />, tone: 'text-slate-700' },
  { label: 'Bekleyen işlemler', view: 'PENDING', icon: <History className="w-5 h-5" />, tone: 'text-slate-700' },
];

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return 'İyi geceler';
  if (h < 12) return 'Günaydın';
  if (h < 18) return 'İyi günler';
  return 'İyi akşamlar';
}

export default function HomeMenu(p: Props) {
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);
  const preCount = useMemo(() => p.references.filter(r => !r.archived && r.status === 'CREATED' && (r.precoolingSlips || []).length > 0).length, [p.references]);
  const counts: Record<StageKey, number> = {
    HASAT: Math.max(0, life.SAHADA - preCount),
    ON_SOGUTMA: preCount,
    SOGUK_DEPO: life.DEPODA,
    SEVK: life.YOLDA,
  };
  const isAdmin = p.currentUser?.role === 'ADMIN';
  const firstName = (p.currentUser?.fullName || '').split(' ')[0];
  const today = new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });

  const tileBtn = (t: Tile) => (
    <button key={t.label} type="button" onClick={() => p.onNavigate(t.view, t.tab)}
      className="flex items-center gap-3 min-h-[56px] px-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-left text-sm font-bold text-slate-800 dark:text-slate-100 hover:border-slate-300 hover:shadow-sm transition cursor-pointer">
      <span className={`shrink-0 ${t.tone} dark:text-slate-300`}>{t.icon}</span>
      <span className="leading-tight py-2">{t.label}</span>
    </button>
  );
  const section = (title: string, children: React.ReactNode) => (
    <section className="space-y-2.5">
      <h2 className="text-[11px] font-black tracking-[0.1em] text-slate-500 dark:text-slate-400">{title}</h2>
      {children}
    </section>
  );

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-6 py-5 sm:py-8 space-y-6">
      {/* Selam + durum */}
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="text-sm text-slate-500 dark:text-slate-400 capitalize">{today}</div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">{greeting()}{firstName ? `, ${firstName}` : ''}</h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${p.isOnline ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300' : 'bg-amber-100 text-amber-900'}`}>
            {p.isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}{p.isOnline ? 'Çevrimiçi' : 'Çevrimdışı'}
          </span>
          {p.pendingCount > 0 && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900">{p.pendingCount} kayıt gönderilmeyi bekliyor</span>}
        </div>
      </header>

      {/* Arama */}
      <button type="button" onClick={p.onOpenSearch}
        className="w-full flex items-center gap-3 min-h-[52px] px-4 rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-left text-slate-500 dark:text-slate-400 cursor-pointer hover:border-slate-400">
        <Search className="w-5 h-5" /><span className="text-[15px]">RefID, bahçe veya ürün ara…</span>
      </button>

      {/* 4 aşama */}
      {section('SÜREÇ', (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
          {STAGE_TILES.map(s => {
            const badge = p.stageBadges[s.key];
            return (
              <button key={s.key} type="button" onClick={() => p.onNavigate(s.view)}
                className="relative text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 hover:border-slate-300 hover:shadow-sm transition cursor-pointer">
                <span className={`w-11 h-11 rounded-xl flex items-center justify-center ${s.soft}`}>{s.icon}</span>
                <div className={`mt-3 text-[10px] font-black tracking-wider ${s.text}`}>ADIM {s.no}</div>
                <div className="text-base font-bold text-slate-900 dark:text-white">{s.label}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400"><span className="font-display text-lg font-bold text-slate-900 dark:text-white tabular-nums">{counts[s.key]}</span> parti</div>
                {!!badge && <span className="absolute top-3 right-3 min-w-6 h-6 px-1.5 rounded-full bg-rose-600 text-white text-xs font-black flex items-center justify-center" aria-label={`${badge} uyarı`}>{badge}</span>}
              </button>
            );
          })}
        </div>
      ))}

      {/* Ana panel + uyarılar */}
      <div className="grid sm:grid-cols-2 gap-2.5">
        <button type="button" onClick={() => p.onNavigate('DASHBOARD')}
          className="flex items-center gap-3 min-h-[60px] px-4 rounded-2xl bg-teal-700 hover:bg-teal-800 text-white text-left font-bold cursor-pointer">
          <LayoutDashboard className="w-5 h-5" /><span className="flex-1">Ana panel</span><ArrowRight className="w-5 h-5" />
        </button>
        <button type="button" onClick={() => p.onNavigate('ALERTS')}
          className={`flex items-center gap-3 min-h-[60px] px-4 rounded-2xl text-left font-bold cursor-pointer border ${p.alertCount ? 'bg-rose-50 border-rose-200 text-rose-900 dark:bg-rose-950/40 dark:border-rose-900 dark:text-rose-200' : 'bg-white border-slate-200 text-slate-800 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-100'}`}>
          <AlertTriangle className="w-5 h-5" /><span className="flex-1">Uyarılar</span>
          <span className="font-display text-xl tabular-nums">{p.alertCount}</span>
        </button>
      </div>

      {section('HIZLI KAYIT', <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">{QUICK.map(tileBtn)}</div>)}
      {section('DİĞER MODÜLLER', <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">{OTHER.map(tileBtn)}</div>)}
      {section('RAPORLAR VE KAYITLAR', <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">{REPORTS.map(tileBtn)}</div>)}
      {section('YARDIM VE YÖNETİM', (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
          {tileBtn({ label: 'Rehber ve sorular', view: 'GUIDE_PORTAL', icon: <HelpCircle className="w-5 h-5" />, tone: 'text-slate-700' })}
          {isAdmin && tileBtn({ label: 'Denetim izi', view: 'AUDIT_TRAIL', icon: <History className="w-5 h-5" />, tone: 'text-slate-700' })}
          {isAdmin && p.onOpenUsers && (
            <button type="button" onClick={p.onOpenUsers}
              className="flex items-center gap-3 min-h-[56px] px-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-left text-sm font-bold text-slate-800 dark:text-slate-100 hover:border-slate-300 cursor-pointer">
              <Users className="w-5 h-5 text-slate-700 dark:text-slate-300" /><span className="leading-tight py-2">Kullanıcılar ve onaylar</span>
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
