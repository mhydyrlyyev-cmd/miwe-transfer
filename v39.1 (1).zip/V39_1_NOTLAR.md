# v39.1 — Orijinal logonun yenilenmiş hali (muz yarımı + yarım yaprak) + diğer ürünler görselleri

Uygulama sırası: v39'dan SONRA. Dosyaları AYNEN (byte-identical) kopyala. Firestore kuralı değişmedi (DeployRules GEREKMEZ).

## Logo anlamı
Orijinal amblem korunur: zümrüt kare, altın halka, kesikli dış halka, gümüş dikey çizgi. Turuncu yarım muz kıvrımlı (olgun meyve / hasat, biraz aşağıda); yeşil yarım orta damarından bölünmüş yaprak (tazelik / soğuk zincir), ucu çizgide kalır. Gümüş çizgi = izlenebilirlik süreci, altın halka = kalite standardı, kesikli halka = zaman. 32 px ve altında halkalar düşer.

## Değişen / yeni dosyalar
- src/components/common/BrandLogo.tsx — img yerine satır içi SVG; yeni `variant` ('tile' koyu kare | 'light' | 'dark'); 32 px ve altı halkasız sürüm; gradient kimlikleri useId ile benzersiz. Eski kullanım aynı çalışır.
- src/components/common/CropIcons.tsx (YENİ) — OnionIcon, PotatoIcon
- src/components/auth/LoginView.tsx — marka paneli yeni logo + ürün şeridi (meyve, muz, badem, soğan, patates)
- src/components/portal/HomeMenu.tsx — "Diğer modüller"e "Diğer ürünler" kutusu (Saha testi formunu açar; soğan, patates, domates, nar, mısır, mango, avokado vb. şablonları orada); ızgara 3 sütun
- public/icons/icon-192.png, public/icons/icon-512.png, public/icons/icon-512-maskable.png (YENİ), public/icons/logo.svg, public/icons/icon.svg
- public/icon-192.png, public/icon-512.png, public/apple-touch-icon.png, public/favicon.ico
- public/manifest.json — maskable girdisi icon-512-maskable.png
- index.html — önbellek sürümü ?v=3

## Kabul testleri
1. Giriş sayfası: sol panelde yeni logo (zümrüt kare, altın halka, turuncu muz yarımı + yeşil yarım yaprak); altında 5 yuvarlak ürün simgesi.
2. Ana menü → Diğer modüller: "Diğer ürünler" var, tıklayınca Saha testi açılır.
3. Üst başlıkta (Header) yeni logo görünür; PDF rapor kapağında yeni logo görünür.
4. Tarayıcı sekmesi simgesi (favicon) yeni logo (gerekirse sert yenile).
5. TypeScript hatası yok.

Not: Ayrı modül AÇILMAYACAK; tüm ek ürünler tek girişten (ürün kataloğu) yönetilir. Kivi, yaban mersini, hindistan cevizi, sarımsak şablonları sonraki yamada.
