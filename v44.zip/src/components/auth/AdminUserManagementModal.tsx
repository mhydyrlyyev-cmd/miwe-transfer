import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  X,
  ShieldCheck,
  Users,
  Activity,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Filter,
  Check,
  Edit,
  Trash2,
  Lock,
  Building,
  Briefcase,
  Phone,
  Mail,
  Download,
  AlertTriangle,
  RefreshCw,
  RotateCcw,
  Bug,
  Terminal,
  Cpu,
  Database
} from 'lucide-react';
import { AppUser, ActivityLogItem, ALL_APP_MODULES, UserPermissions, UserStatus } from '../../types/auth';
import {
  getUsers,
  saveUsers,
  fetchUsersList,
  getActivityLogs,
  clearActivityLogs,
  approveUser,
  revokeUserApproval,
  rejectUser,
  updateUserPermissions,
  deleteUser,
  toggleUserActiveStatus,
  adminResetUserPassword,
  logActivity,
  syncWithServer,
  authFetch,
  makeUserPasifReader,
  mergeUsers,
  getSessionToken,
  performSessionAudit,
  SessionAuditResult
} from '../../utils/authService';
import { SessionValidationIndicator } from './SessionValidationIndicator';
import { useToast } from '../../context/ToastContext';
import { getDebugLogs, addDebugLog } from '../../utils/debugLogger';

interface AdminUserManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AppUser;
  onUsersUpdated?: () => void;
}

export const AdminUserManagementModal: React.FC<AdminUserManagementModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUsersUpdated
}) => {
  const { showSuccess, showWarning, showError, showInfo } = useToast();

  // Yetki Kontrolü: yalnızca Firestore profilindeki ADMIN rolü (firestore.rules de doğrular).
  // F5 yenilemelerinde oturumun düşmesini ve sistemden atılmayı engeller.
  const isAuthorized = currentUser?.role === 'ADMIN';

  // Oturum doğrulaması Firebase Authentication tarafından yapılır (localStorage bayrağı yok).

  const [sessionAudit, setSessionAudit] = useState<SessionAuditResult | null>(() => {
    return typeof window !== 'undefined' ? performSessionAudit() : null;
  });

  const handleRevalidateSession = () => {
    const result = performSessionAudit();
    setSessionAudit(result);
    if (result.status === 'VALID') {
      showSuccess('Oturum tokenı ve localStorage anahtarları başarıyla doğrulandı.', 'Oturum Doğrulandı');
    } else if (result.status === 'ERROR') {
      showError(result.statusMessage, 'Oturum Hatası');
    } else {
      showWarning(result.statusMessage, 'Oturum Durumu');
    }
  };

  useEffect(() => {
    if (isOpen) {
      setSessionAudit(performSessionAudit());
    }
  }, [isOpen]);

  const [activeTab, setActiveTab] = useState<'USERS' | 'LOGS' | 'DEBUG'>('USERS');
  const [users, setUsers] = useState<AppUser[]>(() => getUsers());
  const [logs, setLogs] = useState<ActivityLogItem[]>(() => getActivityLogs());

  const handleFactoryReset = () => {
    if (window.confirm("DİKKAT: Sistemdeki tüm işlem kayıtları, form verileri, referanslar ve aktivite logları kalıcı olarak SİLİNECEKTİR (Kullanıcı hesapları hariç). Bu işlem geri alınamaz. Onaylıyor musunuz?")) {
      const keysToClear = [
        'miwe_references',
        'miwe_harvest_records',
        'miwe_field_records',
        'miwe_muz_records',
        'miwe_badem_records',
        'miwe_lojistik_records',
        'miwe_ambar_records',
        'miwe_export_sample_records',
        'miwe_sales_records',
        'miwe_incident_records',
        'miwe_freeze_dry_records',
        'miwe_offline_queue'
      ];
      keysToClear.forEach(key => localStorage.setItem(key, JSON.stringify([])));
      clearActivityLogs();
      setLogs([]);
      alert("Sistem başarıyla sıfırlandı. Yeni kayıt girmeye başlayabilirsiniz.");
      window.location.reload();
    }
  };


  // Search & filter for Users
  const [userSearch, setUserSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | UserStatus>('ALL');

  // Search & filter for Logs
  const [logSearch, setLogSearch] = useState('');
  const [logActionFilter, setLogActionFilter] = useState<string>('ALL');

  // Currently editing user ID for permissions modal/drawer
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userToDeleteConfirm, setUserToDeleteConfirm] = useState<AppUser | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<UserStatus>('APPROVED');
  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [selectedPermissions, setSelectedPermissions] = useState<UserPermissions>({
    canEdit: false,
    canDelete: false,
    canClearDemo: false,
    canExport: true
  });

  const editingUserIdRef = useRef<string | null>(null);
  useEffect(() => {
    editingUserIdRef.current = editingUserId;
  }, [editingUserId]);

  /**
   * Kullanıcı listeleme mantığı:
   * 1. Önce /api/users uç noktasından çekmeyi dene
   * 2. 401 hatası gelirse oturumu sonlandırmadan sessizce console.warn logla ve localStorage'a ('miwe_platform_users') düş
   * 3. Ağ hatası veya sunucu hatasında localStorage'daki miwe_platform_users verisiyle devam et
   */
  const fetchUsersWithFallback = async (): Promise<AppUser[]> => {
    // Tek kaynak: Firestore 'users' (kurallar yalnızca ADMIN'e tüm listeyi açar)
    return fetchUsersList();
  };

  const refreshData = async () => {
    // Düzenleme sırasında formu sıfırlamamak için kontrol
    if (editingUserIdRef.current) return;
    try {
      const mergedUsers = await fetchUsersWithFallback();
      if (!editingUserIdRef.current) {
        setUsers(mergedUsers);
        setLogs(getActivityLogs());
        if (onUsersUpdated) onUsersUpdated();
      }
    } catch {
      setUsers(getUsers());
      setLogs(getActivityLogs());
    }
  };

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const userList = await fetchUsersWithFallback();
        if (Array.isArray(userList) && userList.length > 0) {
          setUsers(userList);
        } else {
          setUsers(getUsers());
        }
        setLogs(getActivityLogs());
        if (onUsersUpdated) onUsersUpdated();
      } catch (err) {
        console.warn('[AdminUserManagementModal] loadUsers hatası, localStorage kullanılıyor:', err);
        setUsers(getUsers());
        setLogs(getActivityLogs());
      }
    };

    if (isOpen) {
      loadUsers();
      syncWithServer().catch(() => {});

      const interval = setInterval(() => {
        if (!editingUserIdRef.current) {
          loadUsers();
        }
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  // v4.4: kayıt metnindeki kullanıcı kimliklerini (uid) isimle değiştir
  const humanizeIds = (text?: string) => {
    let t = String(text || '');
    users.forEach((u: any) => { if (u?.id && u?.fullName && t.includes(u.id)) t = t.split(u.id).join(u.fullName); });
    return t.replace(/→\s*APPROVED/g, '→ onaylandı').replace(/→\s*REJECTED/g, '→ reddedildi').replace(/→\s*PENDING/g, '→ beklemede');
  };

  const pendingUsersCount = useMemo(() => {
    return users.filter(u => u.status === 'PENDING').length;
  }, [users]);

  const editingUser = useMemo(() => {
    return users.find(u => u.id === editingUserId) || null;
  }, [users, editingUserId]);

  // Filtered users
  const filteredUsers = useMemo(() => {
    const q = (userSearch || '').toLowerCase();
    return (users || []).filter(u => {
      if (!u) return false;
      const matchSearch =
        (u.fullName || '').toLowerCase().includes(q) ||
        (u.email || '').toLowerCase().includes(q) ||
        (u.company || '').toLowerCase().includes(q) ||
        (u.jobTitle || '').toLowerCase().includes(q);
      const matchStatus = statusFilter === 'ALL' || u.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [users, userSearch, statusFilter]);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    const q = (logSearch || '').toLowerCase();
    return (logs || []).filter(l => {
      if (!l) return false;
      const matchSearch =
        (l.userName || '').toLowerCase().includes(q) ||
        (l.userEmail || '').toLowerCase().includes(q) ||
        (l.details || '').toLowerCase().includes(q) ||
        (l.refId ? String(l.refId).toLowerCase().includes(q) : false) ||
        (l.company || '').toLowerCase().includes(q);
      const matchAction = logActionFilter === 'ALL' || l.action === logActionFilter;
      return matchSearch && matchAction;
    });
  }, [logs, logSearch, logActionFilter]);

  // Open edit drawer for a user
  const handleOpenEditUser = (user: AppUser) => {
    setEditingUserId(user.id);
    setSelectedStatus(user.status);
    setSelectedModules(user.allowedModules || ['HARVEST', 'FIELD']);
    setSelectedPermissions(
      user.permissions || {
        canEdit: false,
        canDelete: false,
        canClearDemo: false,
        canExport: true
      }
    );
  };

  // Quick Approve / Yetkilendir
  const handleApprove = async (user: AppUser) => {
    const mods = user.allowedModules && user.allowedModules.length > 0 
      ? user.allowedModules 
      : ['HARVEST', 'FIELD', 'MUZ', 'BADEM', 'LOJISTIK', 'AMBAR', 'FREEZE_DRY', 'EXPORT_SAMPLE', 'SALES', 'INCIDENT', 'GALLERY', 'ANALYTICS', 'MONTHLY_REPORT', 'REFERENCES'];
    const perms: UserPermissions = {
      canEdit: true,
      canDelete: false,
      canClearDemo: false,
      canExport: true,
      canViewAll: true
    };

    // 1. ANINDA YEREL REACT STATE'İNİ GÜNCELLE (Sayfa yenilemeye gerek kalmadan anında 'Onaylı' görünsün)
    setUsers(prev => prev.map(u => u.id === user.id ? {
      ...u,
      status: 'APPROVED',
      allowedModules: mods,
      permissions: perms,
      approvedAt: new Date().toISOString(),
      approvedBy: currentUser?.fullName || 'Sistem Yöneticisi'
    } : u));

    // 2. localStorage verisini anında güncelle
    try {
      const currentLocal = getUsers();
      saveUsers(currentLocal.map(u => u.id === user.id ? {
        ...u,
        status: 'APPROVED',
        allowedModules: mods,
        permissions: perms,
        approvedAt: new Date().toISOString(),
        approvedBy: currentUser?.fullName || 'Sistem Yöneticisi'
      } : u));
    } catch {}

    // 3. Sunucuya asenkron isteği gönder
    const success = await approveUser(user.id, mods, perms, currentUser);
    if (success) {
      showSuccess(`"${user.fullName}" kullanıcısı başarıyla onaylandı ve yetkilendirildi.`, 'Kullanıcı Onaylandı');
    } else {
      showWarning(`"${user.fullName}" yerel olarak yetkilendirildi, sunucu eşitlemesi arka planda tamamlanacak.`, 'Yetkilendirme');
    }

    if (onUsersUpdated) onUsersUpdated();
    await refreshData();
  };

  // Onayı Geri Al (Tekrar Aday Statüsüne Döndür)
  const handleRevokeApproval = async (user: AppUser) => {
    if (user.role === 'ADMIN') {
      showError('Sistem ana yöneticisinin onayı geri alınamaz!', 'İşlem Engellendi');
      return;
    }
    if (
      window.confirm(
        `"${user.fullName}" kullanıcısının onayını geri almak ve tekrar "Onay Bekleyen Aday" durumuna çekmek istediğinize emin misiniz?\n\n` +
        `• Kullanıcı derhal sistemden çıkarılacak ve şifresiyle sisteme giriş yapamayacaktır.\n` +
        `• Durumu 'Onay Bekliyor' olarak güncellenecek ve 'Onay Bekleyenler' sekmesine geri dönecektir.\n` +
        `• İstediğiniz zaman tekrar tek tıkla onaylayabilirsiniz.`
      )
    ) {
      // Anında yerel state güncelle
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'PASIF_READER' } : u));
      try {
        const currentLocal = getUsers();
        saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: 'PASIF_READER' } : u));
      } catch {}

      await revokeUserApproval(user.id, currentUser);
      if (editingUserId === user.id) setEditingUserId(null);
      if (onUsersUpdated) onUsersUpdated();
      await refreshData();
      showWarning(
        `"${user.fullName}" kullanıcısının onayı geri alındı ve tekrar "Ziyaretçi (Pasif Reader)" durumuna aktarıldı.`,
        'Onay Geri Alındı'
      );
    }
  };

  // Reject
  const handleReject = async (user: AppUser) => {
    if (window.confirm(`"${user.fullName}" kullanıcısının başvurusunu reddetmek ve erişimini engellemek istediğinize emin misiniz?`)) {
      // Anında yerel state güncelle
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
      try {
        const currentLocal = getUsers();
        saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
      } catch {}

      await rejectUser(user.id, currentUser);
      if (editingUserId === user.id) setEditingUserId(null);
      if (onUsersUpdated) onUsersUpdated();
      await refreshData();
      showWarning(`"${user.fullName}" kullanıcısının erişimi reddedildi.`, 'Başvuru Reddedildi');
    }
  };

  // Save Permissions
  const handleSavePermissions = async () => {
    if (!editingUserId) return;
    const targetUserId = editingUserId;
    const targetStatus = selectedStatus;
    const targetModules = [...selectedModules];
    const targetPermissions = { ...selectedPermissions };

    // 1. ANINDA YEREL REACT STATE'İNİ FONKSİYONEL OLARAK GÜNCELLE
    setUsers(prev => prev.map(u => u.id === targetUserId ? {
      ...u,
      status: targetStatus,
      allowedModules: targetModules,
      permissions: targetPermissions,
      ...(targetStatus === 'APPROVED' ? { 
        approvedAt: new Date().toISOString(), 
        approvedBy: currentUser?.fullName || 'Sistem Yöneticisi' 
      } : {})
    } : u));

    // 2. localStorage verisini de derhal güncelle
    try {
      const currentLocal = getUsers();
      saveUsers(currentLocal.map(u => u.id === targetUserId ? {
        ...u,
        status: targetStatus,
        allowedModules: targetModules,
        permissions: targetPermissions,
        ...(targetStatus === 'APPROVED' ? { 
          approvedAt: new Date().toISOString(), 
          approvedBy: currentUser?.fullName || 'Sistem Yöneticisi' 
        } : {})
      } : u));
    } catch {}

    setEditingUserId(null);

    // 3. Sunucuya asenkron isteği gönder
    const success = await updateUserPermissions(targetUserId, targetModules, targetPermissions, currentUser, targetStatus);
    if (success) {
      showSuccess('Kullanıcı durum, modül ve izinleri başarıyla güncellendi.', 'Bilgiler Kaydedildi');
    } else {
      showWarning('İzinler yerel olarak güncellendi, sunucu eşitlemesi arka planda tamamlanacak.', 'Bilgiler Kaydedildi');
    }

    if (onUsersUpdated) onUsersUpdated();
    await refreshData();
  };

  // Pasife Al / Erişimi İptal Et (Kullanıcı verileri & logları tamamen saklanır)
  const handleRevokeAccess = async (user: AppUser) => {
    if (user.role === 'ADMIN') {
      showError('Sistem ana yöneticisinin erişimi kapatılamaz!', 'İşlem Engellendi');
      return;
    }
    if (window.confirm(`"${user.fullName}" kullanıcısının erişimi İPTAL edilecek ve pasife alınacaktır.\n\nKullanıcı artık giriş yapamayacak, ancak geçmişte oluşturduğu tüm saha kayıtları SİSTEMDE GÜVENLE SAKLANACAKTIR.\n\nDevam etmek istiyor musunuz?`)) {
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
      try {
        const currentLocal = getUsers();
        saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
      } catch {}

      await rejectUser(user.id, currentUser);
      if (editingUserId === user.id) setEditingUserId(null);
      if (onUsersUpdated) onUsersUpdated();
      await refreshData();
      showWarning(`"${user.fullName}" kullanıcısının erişimi iptal edildi.`, 'Erişim İptal Edildi');
    }
  };

  // Aktif / Pasif Toggle Switch Handler
  const handleToggleActiveStatus = async (user: AppUser) => {
    if (user.role === 'ADMIN') {
      showError('Sistem ana yöneticisinin durumu değiştirilemez!', 'İşlem Engellendi');
      return;
    }
    const nextStatus: UserStatus = user.status === 'APPROVED' ? 'DEACTIVATED' : 'APPROVED';
    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: nextStatus } : u));
    try {
      const currentLocal = getUsers();
      saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: nextStatus } : u));
    } catch {}

    const ok = await toggleUserActiveStatus(user.id, user.status);
    if (onUsersUpdated) onUsersUpdated();
    await refreshData();
    if (ok) {
      showSuccess(`"${user.fullName}" kullanıcısının durumu güncellendi.`, 'Durum Güncellendi');
    } else {
      showWarning(`"${user.fullName}" kullanıcısının durumu güncellenemedi.`, 'Güncelleme Başarısız');
    }
  };

  // Open separate Delete User confirmation dialog box
  const handleDeleteUser = (user: AppUser) => {
    if (user.role === 'ADMIN') {
      showError('Sistem ana yöneticisi silinemez!', 'İşlem Engellendi');
      return;
    }
    setUserToDeleteConfirm(user);
  };

  // Execute Permanent Delete from confirmation modal box
  const handleConfirmPermanentDelete = async () => {
    if (!userToDeleteConfirm) return;
    const deletedName = userToDeleteConfirm.fullName;
    const deletedId = userToDeleteConfirm.id;
    // Anında yerel state'i güncelle
    setUsers(prev => prev.filter(u => u.id !== deletedId));
    try {
      const currentLocal = getUsers();
      saveUsers(currentLocal.filter(u => u.id !== deletedId));
    } catch {}

    await deleteUser(deletedId);
    if (editingUserId === deletedId) setEditingUserId(null);
    setUserToDeleteConfirm(null);
    if (onUsersUpdated) onUsersUpdated();
    await refreshData();
    showError(`"${deletedName}" kullanıcısı sistemden kalıcı olarak silindi.`, 'Kullanıcı Silindi');
  };

  // Toggle Module
  const handleToggleModule = (modKey: string) => {
    if (modKey === 'ALL') {
      if (selectedModules.includes('ALL')) {
        setSelectedModules([]);
      } else {
        setSelectedModules(['ALL']);
      }
      return;
    }

    if (selectedModules.includes('ALL')) {
      setSelectedModules([modKey]);
      return;
    }

    if (selectedModules.includes(modKey)) {
      setSelectedModules(selectedModules.filter(m => m !== modKey));
    } else {
      setSelectedModules([...selectedModules, modKey]);
    }
  };

  // Admin Reset User Password
  const handleResetUserPassword = async (user: AppUser) => {
    // Güvenlik: yönetici başkasının parolasını belirlemez; kullanıcıya sıfırlama bağlantısı gider
    if (!window.confirm(`${user.fullName} (${user.email}) adresine parola sıfırlama bağlantısı gönderilsin mi?`)) return;
    const res = await adminResetUserPassword(user.id);
    if (res.success) {
      showSuccess(res.message);
      refreshData();
    } else {
      showError(res.message);
    }
  };

  // Export logs to CSV
  const handleExportLogsCsv = () => {
    const headers = ['Zaman', 'Kullanici', 'E-posta', 'Firma', 'Gorevi', 'Aksiyon', 'Modul', 'RefID', 'Detay'];
    const rows = filteredLogs.map(l => [
      `"${new Date(l.timestamp).toLocaleString('tr-TR')}"`,
      `"${(l.userName || '').replace(/"/g, '""')}"`,
      `"${(l.userEmail || '').replace(/"/g, '""')}"`,
      `"${(l.company || '').replace(/"/g, '""')}"`,
      `"${(l.jobTitle || '').replace(/"/g, '""')}"`,
      `"${l.action || ''}"`,
      `"${l.module || '-'}"`,
      `"${l.refId || '-'}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `miwe_denetim_kayitlari_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  if (!isAuthorized) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-4">
        <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-md text-white text-center space-y-4 shadow-2xl">
          <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold">Yetkisiz Erişim</h3>
          <p className="text-xs text-slate-300">
            Bu portal yalnızca Sistem Yöneticisi (Admin) erişimine açıktır.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition cursor-pointer"
          >
            Kapat
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-2 sm:p-4">
      <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 max-w-5xl w-full overflow-hidden flex flex-col h-[95vh] sm:h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white px-4 py-3 sm:px-5 sm:py-4 flex items-center justify-between gap-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 shrink-0">
              <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-black tracking-wide truncate">Yönetici paneli</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-950 text-teal-300 border border-teal-700/80 font-mono shrink-0">
                  {currentUser.fullName}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 hidden sm:block truncate">
                Kullanıcı onayları, yetkilendirme ve hareket denetim günlüğü
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={refreshData}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              title="Yenile"
            >
              <RefreshCw className="w-4 h-4" />
              <span className="hidden md:inline">Yenile</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900 text-slate-300 hover:text-white transition cursor-pointer"
              title="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-slate-200 bg-slate-50 shrink-0 w-full overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 px-3 sm:px-4 min-w-max">
            <button
              onClick={() => setActiveTab('USERS')}
              className={`py-3 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                activeTab === 'USERS'
                  ? 'border-teal-600 text-teal-900 bg-teal-50/50'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>Kullanıcılar</span>
              {pendingUsersCount > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white animate-pulse shrink-0">
                  {pendingUsersCount} Onay Bekliyor
                </span>
              )}
            </button>
 
            <button
              onClick={() => setActiveTab('LOGS')}
              className={`py-3 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                activeTab === 'LOGS'
                  ? 'border-teal-600 text-teal-900 bg-teal-50/50'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Activity className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Hareketler</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-200 text-slate-700 shrink-0">
                {logs.length}
              </span>
            </button>
 
            <button
              onClick={() => setActiveTab('DEBUG')}
              className={`py-3 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                activeTab === 'DEBUG'
                  ? 'border-rose-600 text-rose-900 bg-rose-50/50'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Bug className="w-4 h-4 text-slate-500 shrink-0" />
              <span>Sistem (teknik)</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">

          {/* TAB 1: USERS MANAGEMENT */}
          {activeTab === 'USERS' && (
            <div className="space-y-3 sm:space-y-4">
              {/* v4.4: oturum doğrulama kartı "Sistem (teknik)" sekmesine taşındı */}

              {/* Search and filter bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 bg-slate-50 p-2.5 sm:p-3 rounded-2xl border border-slate-200">
                <div className="relative flex-1 min-w-0">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="İsim, e-posta, firma veya görev ara..."
                    className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                  />
                </div>

                <div className="flex items-center gap-1 text-xs overflow-x-auto pb-1 md:pb-0 scrollbar-none shrink-0">
                  <span className="text-slate-500 font-bold text-[11px] shrink-0 mr-1">Durum:</span>
                  {(['ALL', 'APPROVED', 'PASIF_READER', 'PENDING', 'DEACTIVATED'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] whitespace-nowrap cursor-pointer shrink-0 ${
                        statusFilter === st
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {st === 'ALL' && `Tümü (${users.length})`}
                      {st === 'APPROVED' && `🟢 Onaylı (${users.filter(u => u.status === 'APPROVED').length})`}
                      {st === 'PASIF_READER' && `🟡 Ziyaretçi (${users.filter(u => u.status === 'PASIF_READER').length})`}
                      {st === 'PENDING' && `⏳ Bekleyen (${users.filter(u => u.status === 'PENDING').length})`}
                      {st === 'DEACTIVATED' && `🔴 Pasif (${users.filter(u => u.status === 'DEACTIVATED' || u.status === 'REJECTED').length})`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Users List */}
              <div className="space-y-3 pb-2">
                {filteredUsers.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-xs text-slate-400">
                    Arama kriterine uygun kullanıcı bulunamadı.
                  </div>
                ) : (
                  filteredUsers.map((user) => {
                    const isEditing = editingUserId === user.id;

                    return (
                      <div
                        key={user.id}
                        className={`rounded-2xl border transition p-3.5 sm:p-4 ${
                          user.status === 'PENDING'
                            ? 'bg-amber-50/50 border-amber-300 shadow-xs ring-1 ring-amber-300/40'
                            : user.status === 'PASIF_READER'
                            ? 'bg-amber-50/20 border-amber-200'
                            : user.status === 'REJECTED' || user.status === 'DEACTIVATED'
                            ? 'bg-slate-50/80 border-slate-200 opacity-90'
                            : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                        }`}
                      >
                        <div className="space-y-3">
                          {/* Card Top: Name & Badges */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-black text-xs flex items-center justify-center shrink-0 border border-teal-200">
                                {(user.fullName || user.email || '?').slice(0, 2).toUpperCase()}
                              </div>
                              <span className="text-sm font-black text-slate-900">{user.fullName || user.email || 'İsimsiz Kullanıcı'}</span>
                              
                              {/* Status Badge */}
                              {user.status === 'APPROVED' && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                                  <span>🟢 Onaylı (Aktif)</span>
                                </span>
                              )}
                              {user.status === 'PASIF_READER' && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                                  <span>🟡 Ziyaretçi (Pasif Reader)</span>
                                </span>
                              )}
                              {user.status === 'PENDING' && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-sky-100 text-sky-900 border border-sky-300 flex items-center gap-1 animate-pulse">
                                  <Clock className="w-3 h-3 text-sky-700" />
                                  <span>⏳ Beklemede</span>
                                </span>
                              )}
                              {(user.status === 'DEACTIVATED' || user.status === 'REJECTED') && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-900 border border-rose-300 flex items-center gap-1">
                                  <XCircle className="w-3 h-3 text-rose-700" />
                                  <span>🔴 Pasif (Giriş Kapalı)</span>
                                </span>
                              )}

                              {user.role === 'ADMIN' && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-900 border border-purple-300">
                                  👑 Master Admin
                                </span>
                              )}
                            </div>

                            {/* Registered timestamp */}
                            {user.createdAt && (
                              <span className="text-[10px] text-slate-400 font-mono">
                                Kayıt: {new Date(user.createdAt).toLocaleDateString('tr-TR')} {new Date(user.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            )}
                          </div>

                          {/* User Metadata Pills */}
                          <div className="flex flex-wrap gap-2 text-xs">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-semibold border border-slate-200">
                              <Building className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                              <span>{user.company || 'Firma Belirtilmemiş'}</span>
                            </span>
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-semibold border border-slate-200">
                              <Briefcase className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                              <span>{user.jobTitle || 'Görev Belirtilmemiş'}</span>
                            </span>
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200">
                              <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span>{user.email}</span>
                            </span>
                            {user.phone && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-mono border border-slate-200">
                                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                <span>{user.phone}</span>
                              </span>
                            )}
                          </div>

                          {/* Permissions & Allowed Modules Summary */}
                          <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-0.5">
                            <span className="text-slate-400 font-bold mr-1">Yetkiler:</span>
                            <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                              user.permissions?.canEdit ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                            }`}>
                              Düzenleme: {user.permissions?.canEdit ? 'Açık' : 'Kapalı'}
                            </span>
                            <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                              user.permissions?.canDelete ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-500'
                            }`}>
                              Silme: {user.permissions?.canDelete ? 'Açık' : 'Kapalı'}
                            </span>
                            <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                              user.permissions?.canClearDemo ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-500'
                            }`}>
                              Örnek Temizle: {user.permissions?.canClearDemo ? 'Açık' : 'Kapalı'}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-teal-50 text-teal-800 border border-teal-200 font-bold text-[10px]">
                              Modüller: {(user.allowedModules || []).includes('ALL') ? 'Tüm Modüller' : `${(user.allowedModules || []).length} Modül`}
                            </span>
                          </div>

                          {/* Action Buttons Section */}
                          <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 w-full">
                            <div className="flex items-center gap-1.5 flex-wrap w-full">
                              {/* 🟢 "Yetkilendir" (Sadece PASIF_READER ve PENDING için) */}
                              {(user.status === 'PASIF_READER' || user.status === 'PENDING') && user.role !== 'ADMIN' && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await handleApprove(user);
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1 transition shadow-xs cursor-pointer"
                                  title="Kullanıcıyı anında onayla ve yetkilendir (Aktif yap)"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>🟢 Yetkilendir</span>
                                </button>
                              )}

                              {/* 🟡 "Pasif Reader Yap" (Sadece APPROVED için) */}
                              {user.status === 'APPROVED' && user.role !== 'ADMIN' && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    // Anında yerel state'i güncelle
                                    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'PASIF_READER' } : u));
                                    try {
                                      const currentLocal = getUsers();
                                      saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: 'PASIF_READER' } : u));
                                    } catch {}

                                    await makeUserPasifReader(user.id, currentUser);
                                    if (onUsersUpdated) onUsersUpdated();
                                    await refreshData();
                                    showSuccess(`"${user.fullName}" kullanıcısının yetkisi PASIF_READER (Ziyaretçi) yapıldı.`, 'Statü Güncellendi');
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                                  title="Geri al, statüyü PASIF_READER yap"
                                >
                                  <span>🟡 Pasif Reader Yap</span>
                                </button>
                              )}

                              {/* 🔴 "Pasife Al" (ADMIN hariç herkes için) */}
                              {user.status !== 'DEACTIVATED' && user.role !== 'ADMIN' && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (window.confirm(`"${user.fullName}" kullanıcısının hesabı PASİFE ALINACAK (DEACTIVATED) ve girişi engellenecektir. Onaylıyor musunuz?`)) {
                                      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
                                      try {
                                        const currentLocal = getUsers();
                                        saveUsers(currentLocal.map(u => u.id === user.id ? { ...u, status: 'DEACTIVATED' } : u));
                                      } catch {}

                                      await rejectUser(user.id, currentUser);
                                      if (onUsersUpdated) onUsersUpdated();
                                      await refreshData();
                                      showWarning(`"${user.fullName}" kullanıcısının hesabı pasife alındı (Giriş kapalı).`, 'Erişim Kapatıldı');
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                                  title="Statüyü DEACTIVATED yap (Giriş tamamen engellenir)"
                                >
                                  <XCircle className="w-3.5 h-3.5 text-rose-600" />
                                  <span>🔴 Pasife Al</span>
                                </button>
                              )}

                              {/* Modül & İzinler Düzenle Button */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenEditUser(user);
                                }}
                                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-300 flex items-center gap-1 transition cursor-pointer"
                              >
                                <Edit className="w-3.5 h-3.5 text-teal-700" />
                                <span>Modül & İzinler</span>
                              </button>

                              {/* Reset Password Button */}
                              <button
                                type="button"
                                onClick={() => handleResetUserPassword(user)}
                                className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold border border-amber-300 flex items-center gap-1 transition cursor-pointer"
                                title="Kullanıcı için geçici şifre belirler"
                              >
                                <Lock className="w-3.5 h-3.5 text-amber-600" />
                                <span className="hidden sm:inline">Şifre Sıfırla</span>
                              </button>

                              {/* Delete User Button */}
                              {user.role !== 'ADMIN' && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteUser(user)}
                                  className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold border border-rose-200 flex items-center gap-1 transition cursor-pointer ml-auto"
                                  title="Kullanıcıyı Kalıcı Sil"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Card İçeriği Sonu */}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 2: AUDIT LOGS (KULLANICI HAREKETLERİ) */}
          {activeTab === 'LOGS' && (
            <div className="space-y-4">
              {/* Search, Action Filter & CSV Export */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                    placeholder="Kullanıcı, firma, refId veya aksiyon ara..."
                    className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={logActionFilter}
                    onChange={(e) => setLogActionFilter(e.target.value)}
                    className="text-xs bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-slate-700 font-semibold"
                  >
                    <option value="ALL">Tüm Hareketler</option>
                    <option value="LOGIN">Giriş Yapma (LOGIN)</option>
                    <option value="CREATE_RECORD">Yeni Kayıt (CREATE)</option>
                    <option value="UPDATE_RECORD">Kayıt Düzenleme (UPDATE)</option>
                    <option value="DELETE_RECORD">Kayıt Silme (DELETE)</option>
                    <option value="DISPATCH_SHIPMENT">Sevkiyat / Çıkış</option>
                    <option value="CLEAR_DEMO_DATA">Örnekleri Temizleme</option>
                    <option value="USER_APPROVED">Kullanıcı Onayı</option>
                    <option value="USER_APPROVAL_REVOKED">Onay Geri Alma (Revoke)</option>
                    <option value="USER_REJECTED">Kullanıcı Reddi / Pasife Alma</option>
                  </select>

                  <button
                    type="button"
                    onClick={handleExportLogsCsv}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>CSV İndir</span>
                  </button>
                </div>
              </div>

              {/* Logs Table / Cards */}
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-900 text-white font-mono text-[11px]">
                      <th className="py-2.5 px-3">Zaman Damgası (Timestamp)</th>
                      <th className="py-2.5 px-3">Kullanıcı E-Postası & Adı</th>
                      <th className="py-2.5 px-3">İşlem Türü (Action)</th>
                      <th className="py-2.5 px-3">Modül / Ref No</th>
                      <th className="py-2.5 px-3">Denetim İzi & İşlem Detayı</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    {filteredLogs.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-400">
                          Henüz kayıtlı bir denetim hareketi bulunamadı.
                        </td>
                      </tr>
                    ) : (
                      filteredLogs.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50 transition">
                          <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                            {new Date(item.timestamp).toLocaleString('tr-TR')}
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-slate-900">{item.userName}</div>
                            <div className="text-[11px] text-teal-800 font-mono font-medium">{item.userEmail || '-'}</div>
                            <div className="text-[10px] text-slate-500 font-semibold">{item.company || 'Genel'} • {item.jobTitle || 'Personel'}</div>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              item.action === 'LOGIN'
                                ? 'bg-blue-100 text-blue-800'
                                : item.action === 'CREATE_RECORD'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.action === 'UPDATE_RECORD'
                                ? 'bg-amber-100 text-amber-800'
                                : item.action === 'USER_APPROVED'
                                ? 'bg-emerald-100 text-emerald-900 font-black border border-emerald-300'
                                : item.action === 'USER_APPROVAL_REVOKED'
                                ? 'bg-amber-100 text-amber-900 font-black border border-amber-300'
                                : item.action === 'USER_REJECTED'
                                ? 'bg-rose-100 text-rose-900 font-black border border-rose-300'
                                : item.action === 'DELETE_RECORD' || item.action === 'CLEAR_DEMO_DATA'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {item.action === 'USER_APPROVED' ? '✅ Onaylama (Approve)' :
                               item.action === 'USER_REJECTED' ? '⛔ Reddetme (Reject)' :
                               item.action === 'USER_APPROVAL_REVOKED' ? '⚠️ Onay Geri Alma' :
                               item.action === 'UPDATE_RECORD' ? '✏️ Düzenleme (Edit)' :
                               item.action === 'DELETE_RECORD' ? '🗑️ Silme (Delete)' :
                               item.action === 'CREATE_RECORD' ? '➕ Yeni Kayıt' :
                               item.action === 'LOGIN' ? '🔑 Giriş (Login)' :
                               item.action}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px]">
                            {item.module && (
                              <span className="text-slate-700 font-bold">{item.module}</span>
                            )}
                            {item.refId && (
                              <span className="block text-[10px] text-emerald-700 font-bold">{item.refId}</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700 text-xs leading-relaxed max-w-md font-sans">
                            {item.details}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: DEBUG & SYSTEM HEALTH CONSOLE */}
          {activeTab === 'DEBUG' && (
            <div className="space-y-4 font-sans text-xs">
              <SessionValidationIndicator
                audit={sessionAudit}
                onRevalidate={handleRevalidateSession}
              />
              {/* System Overview Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-800 shadow-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-400 font-mono text-[10px]">
                    <span>LOCALSTORAGE STATE</span>
                    <Database className="w-3.5 h-3.5 text-teal-400" />
                  </div>
                  <div className="text-base font-extrabold text-teal-300 font-mono">
                    {users.length} Kullanıcı • {logs.length} Log
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Hesap Veritabanı Anahtarı: <code className="text-teal-200">miwe_users</code>
                  </div>
                </div>

                <div className="bg-emerald-950/80 text-emerald-100 p-3.5 rounded-2xl border border-emerald-800 shadow-xs space-y-1">
                  <div className="flex items-center justify-between text-emerald-300 font-mono text-[10px]">
                    <span>ONAYLI HESAPLAR</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-base font-extrabold text-emerald-200 font-mono">
                    {users.filter(u => u.status === 'APPROVED').length} Kullanıcı
                  </div>
                  <div className="text-[10px] text-emerald-300/80">
                    Tam Erişim Yetkili Aktif Üyeler
                  </div>
                </div>

                <div className="bg-amber-950/80 text-amber-100 p-3.5 rounded-2xl border border-amber-800 shadow-xs space-y-1">
                  <div className="flex items-center justify-between text-amber-300 font-mono text-[10px]">
                    <span>ONAY BEKLEYENLER</span>
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-base font-extrabold text-amber-200 font-mono">
                    {users.filter(u => u.status === 'PENDING').length} Bekleyen
                  </div>
                  <div className="text-[10px] text-amber-300/80">
                    Onay / Red İşlemi Bekliyor
                  </div>
                </div>

                <div className="bg-rose-950/80 text-rose-100 p-3.5 rounded-2xl border border-rose-800 shadow-xs space-y-1">
                  <div className="flex items-center justify-between text-rose-300 font-mono text-[10px]">
                    <span>RED / PASİF KULLANICI</span>
                    <Lock className="w-3.5 h-3.5 text-rose-400" />
                  </div>
                  <div className="text-base font-extrabold text-rose-200 font-mono">
                    {users.filter(u => u.status === 'REJECTED').length} Engelli / Pasif
                  </div>
                  <div className="text-[10px] text-rose-300/80">
                    Erişimi İptal Edilenler (Veriler Korunuyor)
                  </div>
                </div>
              </div>

              {/* Function Health & Verification Panel */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-teal-700" />
                    <h3 className="font-extrabold text-slate-900 text-xs">
                      Yönetici Fonksiyon Durum Doğrulaması (Function Health Check)
                    </h3>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    100% HEALTHY
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 font-mono text-[11px]">deleteUser(id)</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">✅ Doğrulandı</span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      Kullanıcı hesabını kalıcı olarak siler. Admin koruma kontrolü aktiftir. Geçmiş sahadaki referans kayıtlarını bozmadan kullanıcı kütüğünü temizler.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 font-mono text-[11px]">rejectUser(id) / handleRevokeAccess</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">✅ Doğrulandı</span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      Kullanıcının sistem girişini iptal eder, status=&apos;REJECTED&apos; yapar. Kullanıcının oluşturduğu tüm geçmiş loglar ve kayıtlar sistemde güvenle saklanır.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 font-mono text-[11px]">approveUser(id, modules, perms)</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">✅ Doğrulandı</span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      Kullanıcı başvurusunu onaylar ve seçilen modüller ile özel hassas yetkileri (edit, delete, clear) tanımlayarak `miwe_users` kütüğüne işler.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 font-mono text-[11px]">updateUserPermissions(id, ...)</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">✅ Doğrulandı</span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      Aktif kullanıcının modül görünürlüklerini ve özel izinlerini anlık günceller, anında oturuma ve state&apos;e yansıtır.
                    </p>
                  </div>
                </div>
              </div>

              {/* Dedicated Debugging Log Stream for validateConsistency & syncWithGas */}
              <div className="bg-slate-950 text-slate-100 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-emerald-300 text-xs">
                      🔍 Veri Akışı & Senkronizasyon Hata Ayıklama (validateConsistency & syncWithGas Debugger)
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {getDebugLogs().length} Kayıtlı Sistem Logu
                  </span>
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto text-[11px]">
                  {getDebugLogs().length === 0 ? (
                    <div className="py-4 text-center text-slate-500">
                      Henüz kaydedilmiş sistem logu bulunmuyor. İşlem yaptıkça `validateConsistency` ve `syncWithGas` hareketleri burada anlık görüntülenecektir.
                    </div>
                  ) : (
                    getDebugLogs().map(entry => (
                      <div
                        key={entry.id}
                        className={`p-2.5 rounded-xl border flex flex-col gap-1 ${
                          entry.level === 'ERROR'
                            ? 'bg-rose-950/60 border-rose-800 text-rose-200'
                            : entry.level === 'WARN'
                            ? 'bg-amber-950/60 border-amber-800 text-amber-200'
                            : 'bg-slate-900 border-slate-800 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap text-[10px]">
                          <div className="flex items-center gap-2">
                            <span className={`px-1.5 py-0.5 rounded font-bold uppercase ${
                              entry.source === 'CONSISTENCY'
                                ? 'bg-cyan-900 text-cyan-300 border border-cyan-700'
                                : 'bg-purple-900 text-purple-300 border border-purple-700'
                            }`}>
                              {entry.source}
                            </span>
                            <span className={`font-bold ${
                              entry.level === 'ERROR' ? 'text-rose-400' : entry.level === 'WARN' ? 'text-amber-400' : 'text-emerald-400'
                            }`}>
                              [{entry.level}]
                            </span>
                            <span className="text-slate-100 font-bold">{entry.message}</span>
                          </div>
                          <span className="text-slate-400 font-mono">
                            {new Date(entry.timestamp).toLocaleTimeString('tr-TR')}
                          </span>
                        </div>
                        {entry.details && (
                          <pre className="text-[10px] bg-slate-950 p-2 rounded border border-slate-800 text-slate-300 overflow-x-auto">
                            {JSON.stringify(entry.details, null, 2)}
                          </pre>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Critical Security & User Management Action Logs */}
              <div className="bg-slate-900 text-slate-100 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-amber-300 text-xs">
                      ⚡ Hassas Yönetici Hareketleri & Güvenlik Logları Inspector
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Son {logs.filter(l => (l.action || '').includes('USER') || (l.action || '').includes('DELETE') || (l.action || '').includes('CLEAR')).length} Kritik Aksiyon
                  </span>
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto text-[11px]">
                  {logs.filter(l => (l.action || '').includes('USER') || (l.action || '').includes('DELETE') || (l.action || '').includes('CLEAR') || l.action === 'UPDATE_RECORD').length === 0 ? (
                    <div className="py-4 text-center text-slate-500">
                      Henüz kayıtlı kritik silme/yönetici aksiyonu bulunmuyor.
                    </div>
                  ) : (
                    logs.filter(l => (l.action || '').includes('USER') || (l.action || '').includes('DELETE') || (l.action || '').includes('CLEAR') || l.action === 'UPDATE_RECORD').map(log => (
                      <div key={log.id} className="p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                              {log.action}
                            </span>
                            <span className="text-teal-300 font-bold">{log.userName}</span>
                            <span className="text-slate-500 text-[10px]">({log.userEmail})</span>
                          </div>
                          <p className="text-slate-300 mt-1 font-sans text-xs">
                            {humanizeIds(log.details)}
                          </p>
                        </div>
                        <span className="text-[10px] text-slate-500 shrink-0">
                          {new Date(log.timestamp).toLocaleTimeString('tr-TR')}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 p-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Toplam {users.length} Kayıtlı Kullanıcı • {logs.length} Denetim Kaydı</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer shadow-xs"
          >
            Kapat
          </button>
        </div>

      </div>

      {/* Separate Dedicated User Deletion Confirmation Box / Modal */}
      {userToDeleteConfirm && (
        <div className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-rose-200 dark:border-rose-900 space-y-5">
            <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400">
              <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Kullanıcı Hesabını Kalıcı Sil
                </h3>
                <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                  Hassas Silme Bölmesi / Tehlikeli İşlem
                </p>
              </div>
            </div>

            <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl p-3.5 text-xs text-slate-700 dark:text-slate-300 space-y-2">
              <p className="font-bold text-slate-900 dark:text-white">
                "{userToDeleteConfirm.fullName}" ({userToDeleteConfirm.email}) kullanıcısını silmek istediğinize emin misiniz?
              </p>
              <div className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400 space-y-1">
                <p>💡 <strong>Önemli İpucu:</strong> Kullanıcının verilerini koruyup sadece sisteme girişini engellemek istiyorsanız, <strong>"Girişi Pasife Al"</strong> butonunu kullanabilirsiniz.</p>
                <p>⚠️ <strong>Kalıcı Silme:</strong> Bu buton hesabı tamamen sistemden kaldıracaktır.</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setUserToDeleteConfirm(null)}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer transition"
              >
                Vazgeç
              </button>
              
              <button
                type="button"
                onClick={() => {
                  handleToggleActiveStatus(userToDeleteConfirm);
                  setUserToDeleteConfirm(null);
                }}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer transition shadow-xs"
              >
                Girişi Pasife Al (Önerilen)
              </button>

              <button
                type="button"
                onClick={handleConfirmPermanentDelete}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs cursor-pointer transition shadow-xs"
              >
                Kullanıcıyı Kalıcı Sil
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOBIL VE MASAUSTU KORUMALI MODUL & IZINLER YONETIM PENCERESI */}
      {editingUser && (
        <div
          className="fixed inset-0 z-60 flex items-end sm:items-center justify-center bg-slate-950/80 backdrop-blur-xs p-0 sm:p-4"
          onClick={(e) => {
            // Mobilde yanlışlıkla dışarı dokunarak kapanmayı engelle
            e.stopPropagation();
          }}
        >
          <div
            className="bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 w-full sm:max-w-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white px-4 py-3.5 sm:px-5 sm:py-4 flex items-center justify-between gap-3 shrink-0 border-b border-slate-800">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-black truncate">
                    Modül & Yetkilendirme Düzenleyici
                  </h3>
                  <p className="text-[11px] text-teal-300 truncate font-semibold">
                    {editingUser.fullName} • {editingUser.jobTitle || 'Personel'} ({editingUser.company || 'Miwe'})
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setEditingUserId(null)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900 text-slate-300 hover:text-white transition cursor-pointer shrink-0"
                title="Kapat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body (Scrollable) */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
              {/* Modül Seçimi */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                    <span>📦</span>
                    <span>Görünecek Modüller:</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => handleToggleModule('ALL')}
                    className="text-xs text-teal-700 hover:text-teal-900 font-black cursor-pointer underline"
                  >
                    {selectedModules.includes('ALL') ? 'Özel Seçime Dön' : 'Tüm Modülleri Ver (Full Access)'}
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ALL_APP_MODULES.map(mod => {
                    const isSelected = selectedModules.includes('ALL') || selectedModules.includes(mod.key);
                    return (
                      <button
                        key={mod.key}
                        type="button"
                        onClick={() => handleToggleModule(mod.key)}
                        className={`p-2.5 rounded-xl text-left border text-xs font-semibold transition cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-teal-50 border-teal-500 text-teal-950 font-bold ring-1 ring-teal-500 shadow-xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <span className="truncate">{mod.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-teal-600 shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Hassas Özel İzinler */}
              <div className="pt-3 border-t border-slate-200 space-y-2.5">
                <span className="text-xs font-black text-slate-900 block">
                  ⚙️ Özel İzinler (Hassas İşlem Yetkileri):
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 cursor-pointer hover:bg-slate-100 transition">
                    <input
                      type="checkbox"
                      checked={selectedPermissions.canEdit}
                      onChange={(e) => setSelectedPermissions(p => ({ ...p, canEdit: e.target.checked }))}
                      className="w-4 h-4 text-teal-600 rounded border-slate-300"
                    />
                    <span>✏️ Kayıt Düzenleme İzni</span>
                  </label>

                  <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 cursor-pointer hover:bg-slate-100 transition">
                    <input
                      type="checkbox"
                      checked={selectedPermissions.canDelete}
                      onChange={(e) => setSelectedPermissions(p => ({ ...p, canDelete: e.target.checked }))}
                      className="w-4 h-4 text-teal-600 rounded border-slate-300"
                    />
                    <span>🗑️ Kayıt Silme İzni</span>
                  </label>

                  <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 cursor-pointer hover:bg-slate-100 transition">
                    <input
                      type="checkbox"
                      checked={selectedPermissions.canClearDemo}
                      onChange={(e) => setSelectedPermissions(p => ({ ...p, canClearDemo: e.target.checked }))}
                      className="w-4 h-4 text-teal-600 rounded border-slate-300"
                    />
                    <span>🧹 Örnekleri Temizleme İzni</span>
                  </label>
                </div>
              </div>

              {/* Hesap Durumu & Onayı Geri Alma */}
              {editingUser.role !== 'ADMIN' && (
                <div className="pt-3 border-t border-slate-200 space-y-2.5">
                  <span className="text-xs font-black text-slate-900 block">
                    🛡️ Hesap Durumu & Onay Durumu:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedStatus('APPROVED')}
                      className={`p-2.5 rounded-xl text-left border text-xs font-bold transition cursor-pointer flex items-center justify-between ${
                        selectedStatus === 'APPROVED'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-1 ring-emerald-500'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <span>✅ Onaylı (Aktif Giriş)</span>
                      {selectedStatus === 'APPROVED' && <Check className="w-4 h-4 text-emerald-600 shrink-0 ml-1" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedStatus('PENDING')}
                      className={`p-2.5 rounded-xl text-left border text-xs font-bold transition cursor-pointer flex items-center justify-between ${
                        selectedStatus === 'PENDING'
                          ? 'bg-amber-50 border-amber-500 text-amber-950 ring-1 ring-amber-500'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <RotateCcw className="w-3.5 h-3.5 text-amber-600" />
                        <span>⏳ Onay Beklet (Aday Yap)</span>
                      </div>
                      {selectedStatus === 'PENDING' && <Check className="w-4 h-4 text-amber-600 shrink-0 ml-1" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedStatus('PASIF_READER')}
                      className={`p-2.5 rounded-xl text-left border text-xs font-bold transition cursor-pointer flex items-center justify-between ${
                        selectedStatus === 'PASIF_READER'
                          ? 'bg-amber-50 border-amber-500 text-amber-950 ring-1 ring-amber-500'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span>🟡 Pasif Reader (Ziyaretçi Modu)</span>
                      </div>
                      {selectedStatus === 'PASIF_READER' && <Check className="w-4 h-4 text-amber-600 shrink-0 ml-1" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedStatus('DEACTIVATED')}
                      className={`p-2.5 rounded-xl text-left border text-xs font-bold transition cursor-pointer flex items-center justify-between ${
                        selectedStatus === 'DEACTIVATED'
                          ? 'bg-rose-50 border-rose-500 text-rose-950 ring-1 ring-rose-500'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <span>🔴 Pasife Al (Erişim Kapalı)</span>
                      {selectedStatus === 'DEACTIVATED' && <Check className="w-4 h-4 text-rose-600 shrink-0 ml-1" />}
                    </button>
                  </div>

                  {selectedStatus === 'PENDING' && (
                    <div className="text-[11px] text-amber-900 bg-amber-50 p-2.5 rounded-xl border border-amber-200 flex items-start gap-2">
                      <RotateCcw className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <span>
                        <strong>Onay Geri Alınacak:</strong> Bu kullanıcı &apos;Yetkileri Kaydet&apos; dendiğinde tekrar onay bekleyen aday listesine aktarılacak ve sisteme girişi kapatılacaktır.
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setEditingUserId(null)}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                Vazgeç / İptal
              </button>
              <button
                type="button"
                onClick={handleSavePermissions}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black shadow-md transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Yetkileri Kaydet & Uygula</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
