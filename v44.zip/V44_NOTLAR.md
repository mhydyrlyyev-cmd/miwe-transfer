# v44 — Yönetici paneli, denetim izi ve parti pasaportu sadeleştirme

Uygulama sırası: v43'ten SONRA. Dosyaları AYNEN (byte-identical) kopyala. Firestore kuralı DEĞİŞMEDİ.

## 1) Yönetici paneli (☰ › Admin)
- Başlık "Yönetici paneli"; sekmeler kısa: **Kullanıcılar · Hareketler (n) · Sistem (teknik)** (emoji yok).
- "OTURUM DOĞRULANDI / admin_auth / token" kartı Kullanıcılar sekmesinden **Sistem (teknik)** sekmesine taşındı.
- **Güvenlik:** oturum anahtarı (token) artık hiçbir yerde gösterilmez — yalnız "var (1184 bayt)"; "tam tokenı göster"
  düğmesi kaldırıldı; kopyalanan teknik raporda token "(gizli)".
- "Hassas yönetici hareketleri" listesinde kullanıcı kimlikleri (GQKrU0…) yerine **kişi adı**; "→ APPROVED" → "→ onaylandı".
## 2) Denetim izi (Ana menü › Yardım ve yönetim › Denetim izi)
- Başlık "Denetim izi"; "STAGE 09" etiketi ve "kriptografik" ifadesi kaldırıldı (kayıtlar kriptografik imzalı değil).
- **Giriş / çıkış kayıtları varsayılan gizli** ("Giriş / çıkışları göster" kutusu ile açılır) — liste artık veri
  değişikliklerini (kayıt, güncelleme, onay, silme, süreç adımı) öne çıkarır.
## 3) İzlenebilirlik defteri / parti pasaportu
- Alan adları Türkçe: PRODUCT → Ürün, SORTVARİETY → Çeşit, NETHARVESTKG → Net hasat (kg), CASECOUNT → Kasa sayısı,
  AVGBRİX → Ort. Brix, AVGHARDNESS → Ort. sertlik, STARCHINDEX → Nişasta indeksi, LOCATION → Yer …; değerler daktilo yazısı değil.

## Dosyalar
src/components/auth/AdminUserManagementModal.tsx · src/components/auth/SessionValidationIndicator.tsx ·
src/components/admin/AuditTrailView.tsx · src/components/views/TraceabilityLedgerView.tsx

## Kabul testleri
1. Yönetici paneli sekmeleri "Kullanıcılar · Hareketler · Sistem (teknik)"; Kullanıcılar sekmesinde oturum kartı yok.
2. Sistem sekmesinde oturum kartı var; token metni görünmüyor (yalnız uzunluk); göz düğmesi yok.
3. Hassas yönetici hareketlerinde kimlik yerine isim ve "onaylandı" yazıyor.
4. Denetim izi açılınca giriş/çıkış kayıtları görünmüyor; kutu işaretlenince görünüyor.
5. Parti pasaportunda alan adları Türkçe.
6. TypeScript derleme hatası yok.
