# v49c6 — Bahçe kartları + Ana sayfa › Bahçeler + 2027 çiçeklenme girişi (v49c5 dahil)

1. Bahçe kartları (Menü › Takvim ve akışlar › Bahçe kartları; YENİ config/orchardCards.ts, OrchardCardsView.tsx):
   Bagyr · Saýwan Nektarin — ağaç, ha, parseller, 2026 gerçekleşen, 2027 plan, çeşit çeşit fark.
   2026 gerçekleşen: hasat fişleri (URETIM 2026); fişi olmayan çeşitte Gantt "satylan" tonu (Rosy Glow: Bagyr 47,8 t · Saýwan 32,4 t; Staccato 2,6 t).
   Çeşide dokununca: Çiçeklenme ve hasat (2026 BBCH 65, 2026/2025/2024 hasat, çiçekten hasada gün) + 2027 BBCH 65 tarihi girişi
   (hasat takvimiyle aynı kayıt) ve tahmini 2027 hasat penceresi; parseller; 2026 sınıf dağılımı; 2027 aylık plan.
2. Ana sayfa › Bahçeler (YENİ OrchardsPanel.tsx, services/orchardOverview.ts): sezon (Kasım'dan sonra ve son 10 günde hasat kaydı yoksa 2027),
   toplam plan ve 2026 gerçekleşen; meyve türüne göre gidişat (plan · hasat edilen · 2026 çizgisi);
   "2027 çiçeklenme girildi x / y çeşit"; bahçe kartları: plan, 2026, çiçek girilen sayısı, ilk tahmini hasat. Bagyr/Saýwan → Bahçe kartı, diğerleri → Hasat takvimi.
Kaynaklar: BYUJET 2027 – Miwe Nektarin (TAZE 6); v2_1911 tonajlar genel; Gantt (hasat takvimi tohumu, 23.11.2026).

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA (2027 çiçeklenme mevcut hasat takvimi kaydına yazılır).

## SHA-256 (7 dosya)
984b7314d9edb1a6f0e25b0a711a5252d9f00ccbae7c1e919583a9af67675a3e  src/App.tsx
925c2c79f384c69a978b1508b1dc6356b3e7cca997e90b221cab102729ca71b1  src/config/orchardCards.ts
258b20af76cb95abfe4fe69df7713070ea3ee8fa03f990a7b95fa8ff2159d0df  src/services/orchardOverview.ts
b7eed114fa23b516ea630d827dfa95ba5aac4e268207e105a86e8c537cd338ab  src/components/views/OrchardCardsView.tsx
9c54ee05713eefe81b4378d4699c4d1f8c59a140d3fc333b5ff931505cf5f5bf  src/components/dashboard/OrchardsPanel.tsx
42201e934fd12d450b3fe67c8de5f248999c748f9f82678ab51c4cff86d8c1a7  src/components/dashboard/HomeDashboard.tsx
6df87a5ef8b4d321b906ba708cd8a26fc7a700a722cbd0c91488ea7a963d01cf  src/components/portal/HomeMenu.tsx
