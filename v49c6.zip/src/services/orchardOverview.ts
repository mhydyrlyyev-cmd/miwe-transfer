/**
 * v49c6 — Bahçeler özeti (Ana sayfa) ve çeşit eşleştirme.
 *  · Sezon: Kasım'dan itibaren (son 10 günde hasat kaydı yoksa) ya da tüm çeşitler bittiyse bir sonraki yıl (Kasım 2026 → 2027).
 *  · 2026 gerçekleşen: Bahçe kartı olan bahçede hasat fişleri (URETIM 2026); fişi olmayan çeşitte Gantt "satylan" tonu.
 *    Diğer bahçelerde Gantt "satylan" tonu.
 *  · Plan: sezon 2027 → tonaj Excel'i (v2_1911); 2026 → rewiz / plan.
 */
import { useMemo } from 'react';
import type { HarvestRecord } from '../types';
import { buildCalendar, useCalOverrides, type CalItem } from './harvestCalendar';
import { CAL_SEED_ROWS } from '../config/harvestCalendarSeed';
import { ORCHARD_CARDS } from '../config/orchardCards';

const ALIAS: Record<string, string> = { gartairo: 'gartario', gallaval: 'galavall', galavall: 'galavall', goldenrainders: 'goldenreinders' };
/** çeşit anahtarı: harf/rakam dışı atılır, bilinen yazım farkları birleştirilir; parantez içi atılır */
export const vkey = (s?: string) => {
  const k = String(s || '').split('(')[0].toLocaleLowerCase('tr').replace(/ý/g, 'y').replace(/ı/g, 'i').replace(/[^a-z0-9]/g, '');
  return ALIAS[k] || k;
};
const DONE_RE = /tamam/i;

/** 2026 gerçekleşen kg ve kaynağı */
export function actual2026(orchard: string, variety: string): { kg: number; src: 'fiş' | 'Gantt' | null; first?: string | null; last?: string | null } {
  const card = ORCHARD_CARDS[orchard];
  const k = vkey(variety);
  const v = card?.varieties.find(x => vkey(x.cesit) === k);
  if (v && v.actual2026Kg > 0) return { kg: v.actual2026Kg, src: 'fiş', first: v.first2026, last: v.last2026 };
  const g = CAL_SEED_ROWS.find(r => r.orchard === orchard && vkey(r.variety) === k && DONE_RE.test(r.status || '') && (r.soldTon || 0) > 0);
  if (g) return { kg: Math.round((g.soldTon || 0) * 1000), src: 'Gantt', first: g.start2026, last: g.end2026 };
  return { kg: 0, src: null };
}

/** takvim satırı (2026 Gantt) — çiçeklenme / hasat tarihleri için */
export const calSeedFor = (orchard: string, variety: string) => CAL_SEED_ROWS.find(r => r.orchard === orchard && vkey(r.variety) === vkey(variety));

const FRUIT_ORDER = ['Kiraz', 'Şeftali', 'Nektarin', 'Erik', 'Elma', 'Armut', 'Hurma', 'Badem'];

export interface OrchardSummary {
  orchard: string; plan: number; done: number; ref2026: number;
  varieties: number; bloomEntered: number; bloomNeeded: number;
  next?: { variety: string; at: number }; hasCard: boolean;
}
export interface FruitSummary { fruit: string; plan: number; done: number; ref2026: number }

export function useOrchardOverview(harvestRecords: HarvestRecord[]) {
  const ovs = useCalOverrides();
  return useMemo(() => {
    const now = Date.now();
    const y = new Date().getFullYear();
    const cur = buildCalendar(y, ovs, harvestRecords, now);
    // Kasım'dan itibaren hasadı süren çeşit yoksa (ya da hepsi bittiyse) bir sonraki sezon gösterilir
    const recent = harvestRecords.some(h => { const t = Date.parse(String(h.recordDate || h.timestamp || '')); return Number.isFinite(t) && now - t < 10 * 86400000 && String(h.recordDate || h.timestamp).startsWith(String(y)); });
    const season = cur.length && !recent && (new Date().getMonth() >= 10 || cur.every(i => i.status === 'DONE')) ? y + 1 : y;
    const items: CalItem[] = season === y ? cur : buildCalendar(season, ovs, harvestRecords, now);
    const orchards = new Map<string, OrchardSummary>();
    const fruits = new Map<string, FruitSummary>();
    const seen = new Set<string>();
    for (const it of items) {
      if (!it.orchard || /ýyladyş|yyladys/i.test(it.orchard)) continue;
      const card = ORCHARD_CARDS[it.orchard];
      const k = `${it.orchard}|${vkey(it.variety)}`;
      const dup = !!card && seen.has(k); seen.add(k);
      // Bahçe kartı olan bahçede 2027 planı kart (v2_1911) çeşit toplamından; aynı çeşidin ikinci satırı sayılmaz
      const cv = card ? card.varieties.find(x => vkey(x.cesit) === vkey(it.variety)) : undefined;
      const plan = dup ? 0 : season > 2026 && card ? (cv?.plan2027Kg || 0) : (it.targetTon || 0) * 1000;
      const done = (it.doneTon || 0) * 1000;
      const ref = dup || season <= 2026 ? 0 : actual2026(it.orchard, it.variety).kg;
      const o = orchards.get(it.orchard) || { orchard: it.orchard, plan: 0, done: 0, ref2026: 0, varieties: 0, bloomEntered: 0, bloomNeeded: 0, hasCard: !!ORCHARD_CARDS[it.orchard] };
      o.plan += plan; o.done += done; o.ref2026 += ref; o.varieties++;
      if (season > 2026) { o.bloomNeeded++; if (it.bbch65) o.bloomEntered++; }
      if (it.status !== 'DONE' && it.windowStart && it.windowStart >= now - 86400000 && (!o.next || it.windowStart < o.next.at)) o.next = { variety: it.variety.split('(')[0].trim(), at: it.windowStart };
      orchards.set(it.orchard, o);
      const f = fruits.get(it.fruit) || { fruit: it.fruit, plan: 0, done: 0, ref2026: 0 };
      f.plan += plan; f.done += done; f.ref2026 += ref; fruits.set(it.fruit, f);
    }
    // Bahçe kartı olan bahçede 2026 toplamı kartla aynı olsun (fişi takvimde olmayan çeşitler dahil)
    for (const [name, card] of Object.entries(ORCHARD_CARDS)) {
      const o = orchards.get(name);
      if (!o || season <= 2026) continue;
      o.ref2026 = card.varieties.reduce((s, v) => s + (v.actual2026Kg || actual2026(name, v.cesit).kg), 0);
    }
    const orchList = [...orchards.values()].filter(o => o.plan > 0 || o.ref2026 > 0).sort((a, b) => b.plan - a.plan);
    const fruitList = [...fruits.values()].filter(f => f.plan > 0 || f.ref2026 > 0).sort((a, b) => FRUIT_ORDER.indexOf(a.fruit) - FRUIT_ORDER.indexOf(b.fruit));
    return { season, orchards: orchList, fruits: fruitList };
  }, [ovs, harvestRecords]);
}
