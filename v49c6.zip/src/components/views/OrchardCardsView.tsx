import React, { useEffect, useMemo, useState } from 'react';
import { ChevronDown, TreeDeciduous, AlertTriangle, Flower2, Check } from 'lucide-react';
import type { HarvestRecord } from '../../types';
import { actual2026, calSeedFor } from '../../services/orchardOverview';
import { buildCalendar, useCalOverrides, saveCalOverride, type CalItem } from '../../services/harvestCalendar';
import { PageHeader } from '../ui';
import { ORCHARD_CARDS, ORCHARD_SOURCES, type VarietyRow, type ParcelRow } from '../../config/orchardCards';

/** v49c5 — Bahçe kartları: parseller (ağaç, alan, dikim) · 2026 gerçekleşen · 2027 plan, çeşit çeşit */
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const n0 = (v: number) => Math.round(v).toLocaleString('tr-TR');
const dm = (s?: string | null) => (s ? s.slice(5).split('-').reverse().join('.') : '');
const MON = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
const GRADE_CLS: Record<string, string> = { Extra: '#0f766e', Exclusive: '#14b8a6', Premium: '#5eead4', Classic: '#a7f3d0', Mix: '#cbd5e1', Ballyk: '#94a3b8', 'Off-grade': '#64748b' };

function Delta({ a, b }: { a: number; b: number }) {
  if (!a && !b) return null;
  if (!a) return <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">2026 yok</span>;
  if (!b) return <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">plan yok</span>;
  const p = Math.round(((b - a) / a) * 100);
  return <span className={`text-[11px] font-semibold px-1.5 py-0.5 rounded-full border tabular-nums ${p >= 0 ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'}`}>{p >= 0 ? '+' : ''}{p}%</span>;
}

function GradeBar({ g }: { g: Record<string, number> }) {
  const tot = Object.values(g).reduce((s, v) => s + v, 0);
  if (!tot) return null;
  return (
    <div>
      <div className="flex h-2.5 rounded-full overflow-hidden">{Object.entries(g).map(([k, v]) => <div key={k} style={{ width: `${(v / tot) * 100}%`, background: GRADE_CLS[k] || '#94a3b8' }} title={k} />)}</div>
      <div className="flex flex-wrap gap-x-2.5 gap-y-0.5 mt-1">{Object.entries(g).map(([k, v]) => (
        <span key={k} className="text-[10px] text-slate-600 dark:text-slate-400 flex items-center gap-1"><span className="w-2 h-2 rounded-sm inline-block" style={{ background: GRADE_CLS[k] || '#94a3b8' }} />{k} %{Math.round((v / tot) * 100)}</span>))}</div>
    </div>
  );
}

interface Ctx { orchard: string; cal27: Map<string, CalItem>; by: string; readOnly: boolean }
const dmy = (s?: string | null) => (s ? s.split('-').reverse().join('.') : '—');
const dmT = (t?: number) => (t ? new Date(t).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }) : '—');

function Phenology({ v, ctx }: { v: VarietyRow; ctx: Ctx }) {
  const seed = calSeedFor(ctx.orchard, v.cesit);
  const it = seed ? ctx.cal27.get(seed.variety) : undefined;
  const [bloom, setBloom] = useState(it?.ov?.bbch?.['65'] || '');
  const [saved, setSaved] = useState<'idle' | 'ok' | 'err'>('idle');
  const stored = it?.ov?.bbch?.['65'];
  useEffect(() => { if (stored && !bloom) setBloom(stored); }, [stored]);
  if (!seed) return <p className="text-[11px] text-slate-500">Bu çeşit hasat takviminde yok — çiçeklenme / hasat tarihi girilemez.</p>;
  const save = async () => { if (!bloom) return; const ok = await saveCalOverride(2027, ctx.orchard, seed.variety, { bbch: { '65': bloom } }, ctx.by); setSaved(ok ? 'ok' : 'err'); };
  return (
    <div className="space-y-1.5">
      <div className="text-[11px] font-semibold text-slate-500 flex items-center gap-1"><Flower2 className="w-3.5 h-3.5" />Çiçeklenme ve hasat</div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs">
        <span className="text-slate-500">2026 çiçek (BBCH 65)</span><span className="tabular-nums">{dmy(seed.bbch65)}</span>
        <span className="text-slate-500">2026 hasat</span><span className="tabular-nums">{seed.start2026 ? `${dm(seed.start2026)}–${dm(seed.end2026)}` : '—'}</span>
        <span className="text-slate-500">2025 · 2024 hasat</span><span className="tabular-nums">{dm(seed.h2025) || '—'} · {dm(seed.h2024) || '—'}</span>
        <span className="text-slate-500">Çiçekten hasada</span><span className="tabular-nums">{seed.minDays != null ? `${seed.minDays}–${seed.maxDays} gün` : '—'}</span>
      </div>
      <div className="rounded-lg border border-teal-200 bg-white dark:bg-slate-900 p-2 mt-1">
        <div className="text-[11px] font-semibold text-teal-800 mb-1">2027 çiçeklenme (BBCH 65 · %75 çiçek)</div>
        {ctx.readOnly ? <div className="text-xs">{it?.ov?.bbch?.['65'] ? dmy(it.ov.bbch['65']) : 'girilmedi'}</div> : (
          <div className="flex items-center gap-2">
            <input type="date" value={bloom} min="2027-01-15" max="2027-06-15" onChange={e => { setBloom(e.target.value); setSaved('idle'); }} className="min-h-[40px] flex-1 rounded-lg border border-slate-300 px-2 text-sm bg-white dark:bg-slate-900" />
            <button type="button" disabled={!bloom} onClick={save} className="min-h-[40px] px-3 rounded-lg bg-teal-700 text-white text-sm font-semibold disabled:opacity-40 cursor-pointer">{saved === 'ok' ? <Check className="w-4 h-4" /> : 'Kaydet'}</button>
          </div>)}
        {saved === 'err' && <div className="text-[11px] text-amber-800 mt-1">Telefonda kaydedildi, internet gelince gönderilecek.</div>}
        <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1">Tahmini hasat: <b className="tabular-nums">{it?.windowStart ? `${dmT(it.windowStart)}–${dmT(it.windowEnd)}` : '—'}</b>{it?.windowSource ? ` · ${it.windowSource}` : ''}</div>
      </div>
    </div>
  );
}

function VarietyItem({ v, parcels, ctx }: { v: VarietyRow; parcels: ParcelRow[]; ctx: Ctx }) {
  const [open, setOpen] = useState(false);
  const a26 = actual2026(ctx.orchard, v.cesit);
  const ps = parcels.filter(p => norm(p.cesit) === norm(v.cesit));
  const trees = ps.reduce((s, p) => s + p.agac, 0), ha = ps.reduce((s, p) => s + p.ha, 0);
  const maxM = Math.max(...v.plan2027Months, 1);
  return (
    <li className="py-2">
      <button type="button" onClick={() => setOpen(o => !o)} className="w-full flex items-center justify-between gap-3 text-left cursor-pointer min-h-[44px]">
        <span className="min-w-0">
          <span className="block text-sm font-semibold text-slate-900 dark:text-white">{v.cesit}</span>
          <span className="block text-[11px] text-slate-500">
            {trees ? `${n0(trees)} ağaç · ${ha.toLocaleString('tr-TR', { maximumFractionDigits: 2 })} ha · ` : ''}
            2026: {a26.kg ? `${t1(a26.kg)} t · ${dm(a26.first)}–${dm(a26.last)}${a26.src === 'Gantt' ? ' · Gantt' : ''}` : <span className="text-amber-700 font-semibold">kayıt yok</span>}
          </span>
        </span>
        <span className="flex items-center gap-2 shrink-0">
          <span className="text-right"><span className="block text-sm font-bold tabular-nums">{v.plan2027Kg ? `${t1(v.plan2027Kg)} t` : '—'}</span><span className="block text-[10px] text-slate-500">2027 plan</span></span>
          <Delta a={a26.kg} b={v.plan2027Kg} />
          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
        </span>
      </button>
      {open && (
        <div className="mt-2 space-y-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3">
          <Phenology v={v} ctx={ctx} />
          {ps.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">Parseller</div>
              <div className="grid grid-cols-[minmax(0,1fr)_44px_56px_44px_48px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Parsel · anaç</span><span className="text-right">Dikim</span><span className="text-right">Ağaç</span><span className="text-right">ha</span><span className="text-right">kg/ağaç</span></div>
              {ps.map((p, i) => (
                <div key={i} className="grid grid-cols-[minmax(0,1fr)_44px_56px_44px_48px] gap-1 text-xs tabular-nums py-0.5">
                  <span className="truncate">{[p.parsel, p.anac].filter(Boolean).join(' · ') || '—'}</span><span className="text-right">{p.yil}</span><span className="text-right">{n0(p.agac)}</span>
                  <span className="text-right">{p.ha.toLocaleString('tr-TR', { maximumFractionDigits: 2 })}</span><span className="text-right">{p.kgAgac || '—'}</span>
                </div>))}
            </div>
          )}
          {v.actual2026Kg > 0 && <div><div className="text-[11px] font-semibold text-slate-500 mb-1">2026 sınıf dağılımı (gerçekleşen)</div><GradeBar g={v.grades2026} /></div>}
          {v.plan2027Kg > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">2027 plan · ay</div>
              <div className="grid grid-cols-12 gap-0.5 items-end h-10">{v.plan2027Months.map((m, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: m ? `${Math.max(8, (m / maxM) * 100)}%` : 2, opacity: m ? 1 : 0.15 }} title={`${MON[i]} ${t1(m)} t`} />)}</div>
              <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mt-0.5">{MON.map(m => <span key={m}>{m[0]}</span>)}</div>
              <div className="mt-2"><GradeBar g={v.plan2027Grades} /></div>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

export default function OrchardCardsView({ onBack, initial, harvestRecords = [], currentUserName = '', isReadOnly = false }: { onBack: () => void; initial?: string; harvestRecords?: HarvestRecord[]; currentUserName?: string; isReadOnly?: boolean }) {
  const names = Object.keys(ORCHARD_CARDS);
  const [sel, setSel] = useState(initial && ORCHARD_CARDS[initial] ? initial : names[0]);
  const card = ORCHARD_CARDS[sel];
  const ovs = useCalOverrides();
  const cal27 = useMemo(() => new Map(buildCalendar(2027, ovs, harvestRecords).filter(i => i.orchard === sel).map(i => [i.variety, i])), [ovs, harvestRecords, sel]);
  const ctx: Ctx = { orchard: sel, cal27, by: currentUserName, readOnly: isReadOnly };
  const s = useMemo(() => {
    const byTur = new Map<string, { agac: number; ha: number; a: number; p: number; vs: VarietyRow[] }>();
    for (const v of card.varieties) { const x = byTur.get(v.tur) || { agac: 0, ha: 0, a: 0, p: 0, vs: [] }; x.a += actual2026(sel, v.cesit).kg; x.p += v.plan2027Kg; x.vs.push(v); byTur.set(v.tur, x); }
    for (const p of card.parcels) { const x = byTur.get(p.tur); if (x) { x.agac += p.agac; x.ha += p.ha; } }
    const agac = card.parcels.reduce((s, p) => s + p.agac, 0), ha = card.parcels.reduce((s, p) => s + p.ha, 0);
    const a = card.varieties.reduce((s, v) => s + actual2026(sel, v.cesit).kg, 0), p = card.varieties.reduce((s, v) => s + v.plan2027Kg, 0);
    const noActual = card.varieties.filter(v => !actual2026(sel, v.cesit).kg && v.plan2027Kg > 5000);
    const bloomIn = card.varieties.filter(v => { const sd = calSeedFor(sel, v.cesit); return sd && cal27.get(sd.variety)?.ov?.bbch?.['65']; }).length;
    const bloomAll = card.varieties.filter(v => calSeedFor(sel, v.cesit)).length;
    return { byTur, agac, ha, a, p, noActual, bloomIn, bloomAll };
  }, [card, sel, cal27]);
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={onBack} title="Bahçe kartları" subtitle="Parseller · 2026 gerçekleşen · 2027 plan" />
      <div className="flex gap-1.5">{names.map(n => (
        <button key={n} type="button" onClick={() => setSel(n)} className={`px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${sel === n ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{n}</button>))}</div>
      <div className="grid grid-cols-2 gap-2">
        {([['Ağaç', n0(s.agac), `${s.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha`], ['Parsel satırı', String(card.parcels.length), `${card.varieties.length} çeşit`],
          ['2026 gerçekleşen', `${t1(s.a)} t`, 'hasat fişleri + Gantt'], ['2027 plan', `${t1(s.p)} t`, s.a ? `${s.p >= s.a ? '+' : ''}${Math.round(((s.p - s.a) / s.a) * 100)}% 2026'ya göre` : '']] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div></div>))}
      </div>
      <div className={`rounded-2xl border px-4 py-2.5 text-xs flex gap-2 ${s.bloomIn < s.bloomAll ? 'border-teal-200 bg-teal-50 text-teal-900' : 'border-emerald-200 bg-emerald-50 text-emerald-900'}`}><Flower2 className="w-4 h-4 shrink-0 mt-0.5" />
        <span>2027 çiçeklenme girildi: <b>{s.bloomIn} / {s.bloomAll}</b> çeşit. Çeşide dokun → BBCH 65 (%75 çiçek) tarihini gir; tahmini hasat penceresi buna göre hesaplanır.</span></div>
      {s.noActual.length > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>2027 planı olup 2026 hasat fişi olmayan: <b>{s.noActual.map(v => v.cesit).join(', ')}</b> — farklı adla mı kaydedildi, kontrol edin.</span></div>
      )}
      {[...s.byTur.entries()].map(([tur, x]) => (
        <section key={tur} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><TreeDeciduous className="w-4 h-4 text-teal-700" />{tur}</h2>
            <span className="text-[11px] text-slate-500 tabular-nums text-right">{x.agac ? `${n0(x.agac)} ağaç · ${x.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha · ` : ''}{t1(x.a)} → {t1(x.p)} t</span>
          </div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{x.vs.map(v => <VarietyItem key={sel + v.cesit} v={v} parcels={card.parcels} ctx={ctx} />)}</ul>
        </section>
      ))}
      <p className="text-[11px] text-slate-500 px-1">Kaynak: parseller — {ORCHARD_SOURCES.parcels}; 2026 — {ORCHARD_SOURCES.actual2026}; 2027 — {ORCHARD_SOURCES.plan2027}. Bir çeşide dokun: parseller, 2026 sınıf dağılımı, 2027 aylık plan.</p>
    </div>
  );
}
