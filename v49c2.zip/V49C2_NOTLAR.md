# v49c2 — Partiler · parti sayfası (testler listesi) · Test ekle · Bugün yapılacaklar · hasatta test süzme

## Partiler (alt menüde "Partiler")
- Arama (RefID, ürün, bahçe, oda) + seçiciler: Aktif · Hasat · Depo · Sevk · Bitti · Testler.
- Sade satır: RefID, ürün · çeşit · yer, kg · tarih, aşama etiketi. Profili olmayan depodaki kayıtlar "deneme".
- ⋯ menüsü: Excel'e aktar (bu liste), Kriterler ve standartlar, Ayrıntılı liste (eski görünüm).
- QR düğmesi: toplu QR tarama.

## Parti sayfası (satıra dokununca)
- Aşama şeridi (Hasat → Ön soğutma → Sortlama → Depo → Sevk), şu anki kg, yer, kaçıncı gün.
- Testler: hasat öncesi (bağlı saha/muz/badem testleri), hasat kaydı, ön soğutma ve sortlama fişleri, depo kabul,
  depo kontrolleri, ihracat / şahit numune, freeze-dry — tek listede, sonuç etiketiyle (uygun / dikkat / uygun değil).
  Kalem simgesi kaydın kendi formunu açar (düzenleme denetim izine düşer). PDF yalnız dışa aktarma.
- "Test ekle": ürüne ve aşamaya uygun test türleri, önerilen üstte; form RefID hazır açılır.
- Zaman çizelgesi: hasat, ön soğutma/sortlama, depoya giriş, oda değişikliği, sevk, satış.
- Alt düğme: Sonraki adım (ön soğutma fişi / depo kabul / sevk kaydı) + PDF.

## Bugün yapılacaklar (yeni sayfa)
Ana sayfadaki listenin tamamı: Gecikti / set dışı · Bugün; seçici: Tümü · Depo ve oda · Uyarılar.
Ana sayfada "+N daha" ve Menü › Raporlar › Bugün yapılacaklar buraya açılır. Uyarı satırı partinin sayfasını açar.

## Günlük hasat — bağlı test
Liste artık yalnız seçilen bahçe ve ürünün son 21 gündeki testleri (en yeni üstte); emoji ve İngilizce başlık kaldırıldı.

## v49c'den sonraki düzeltmeler
- Profili olmayan depodaki (deneme) partiler Ana sayfa uyarı listesine girmez.
- Ana sayfada arama ve zil tekrarı kaldırıldı (üst çubukta var).
- Depolar sayfasında aşama şeridi kaldırıldı; Menü'de "Depolar · oda turu".

## Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (9 dosya)
1136d37c82f59ce5116b04e86e0688e8d3545d007fbe313db7c460b61b2ec849  src/App.tsx
0ef60f56c72e4f4c2669719610837c6fcb86c5981eefbf0b05258fdc05d8701b  src/components/common/MobileBottomBar.tsx
2b43eb211572423fbeaf2014b5fc86867f794edfbc534ad34e14b4f05cef0fc9  src/components/dashboard/HomeDashboard.tsx
0f3ea22df2ffb8af5c37c31584395cd3b7cf6987826f5f14b0afdd86d3c313eb  src/components/forms/DailyHarvestForm.tsx
07af88c03d831afe536830b37e421a1483047a2374dd46c2afa5692a8b3a55b3  src/components/portal/HomeMenu.tsx
d6045444ef2c660509fdb7657f52e4ec90b4086e5036241cf9edea4ef129a054  src/components/views/DepotsView.tsx
71521c6984fe2ba0106c10873db806d876830a8e1aa6686737f6b1c7dd067960  src/components/views/LotsView.tsx
77f4cfcc2b11ef38f40dccc497e7fc0e465b9c6dae9ea195ff22ef08eaff0b00  src/components/views/TodayView.tsx
c68a19391dc684c840bad40a7a5b06a18cb48999852d78e924e0f457b802681b  src/services/lotTests.ts
