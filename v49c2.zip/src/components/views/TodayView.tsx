import React, { useState } from 'react';
import { Thermometer, ClipboardCheck, AlertTriangle, Wrench, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../ui';
import { useHomeData, type Todo } from '../dashboard/HomeDashboard';
import type { AmbarRecord, HarvestRecord, IncidentRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';

/**
 * v49c2 — Bugün yapılacaklar: ana sayfadaki listenin tamamı, aciliyete göre gruplu.
 * Gecikti (set dışı oda, kritik uyarı) · Bugün (oda turları, uyarılar) · Bilgi.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  incidentRecords: IncidentRecord[];
  onNavigate: (view: string) => void;
  onOpenDepot: (t: { depotId?: string; roomId?: string; tour?: boolean }) => void;
  onOpenProfiles: () => void;
  onOpenLot?: (refId: string) => void;
  onBack: () => void;
}

const icon = (id: string) => id.startsWith('room-') ? <Thermometer className="w-4 h-4" /> : id.startsWith('tour-') ? <ClipboardCheck className="w-4 h-4" /> : id === 'cal' ? <Wrench className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />;
const tone = { bad: 'bg-rose-50 text-rose-700', warn: 'bg-amber-50 text-amber-800', info: 'bg-sky-50 text-sky-700' };

export default function TodayView(p: Props) {
  const { todos } = useHomeData(p);
  const [kind, setKind] = useState<'ALL' | 'DEPO' | 'UYARI'>('ALL');
  const filt = todos.filter(t => kind === 'ALL' || (kind === 'DEPO' ? (t.id.startsWith('room-') || t.id.startsWith('tour-')) : !(t.id.startsWith('room-') || t.id.startsWith('tour-'))));
  const groups: [string, Todo[], string][] = [
    ['Gecikti / set dışı', filt.filter(t => t.level === 'bad'), 'text-rose-700'],
    ['Bugün', filt.filter(t => t.level === 'warn' || t.level === 'info'), 'text-slate-900 dark:text-white'],
  ];
  const d = new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <PageHeader onBack={p.onBack} title="Bugün yapılacaklar" subtitle={`${d} · ${todos.length} iş`} />
      <div className="flex gap-1.5">
        {([['ALL', `Tümü ${todos.length}`], ['DEPO', 'Depo ve oda'], ['UYARI', 'Uyarılar']] as const).map(([k, l]) => (
          <button key={k} type="button" onClick={() => setKind(k)} className={`px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${kind === k ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{l}</button>
        ))}
      </div>
      {filt.length === 0 && (
        <div className="rounded-2xl border border-slate-200 bg-white dark:bg-slate-900 p-6 text-center text-sm text-slate-600 flex flex-col items-center gap-2"><CheckCircle2 className="w-6 h-6 text-emerald-600" />Bugün için açık iş yok.</div>
      )}
      {groups.filter(g => g[1].length).map(([title, list, cls]) => (
        <section key={title} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center justify-between mb-1"><h2 className={`text-sm font-bold ${cls}`}>{title}</h2><span className="text-xs text-slate-500">{list.length}</span></div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {list.map(t => (
              <li key={t.id}>
                <button type="button" onClick={t.run} className="w-full flex items-center justify-between gap-3 py-2.5 text-left cursor-pointer">
                  <span className="flex items-center gap-3 min-w-0">
                    <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${tone[t.level]}`}>{icon(t.id)}</span>
                    <span className="min-w-0"><span className="block text-sm font-semibold text-slate-900 dark:text-white truncate">{t.title}</span><span className="block text-xs text-slate-500 truncate">{t.detail}</span></span>
                  </span>
                  <span className="text-xs font-semibold text-teal-700 dark:text-teal-300 whitespace-nowrap">{t.action} ›</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
