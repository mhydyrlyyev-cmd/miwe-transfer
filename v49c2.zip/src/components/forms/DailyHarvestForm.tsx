import React, { useState, useEffect, useRef } from 'react';
import { 
  Sprout, 
  ArrowLeft, 
  Save, 
  Camera, 
  Sparkles, 
  CheckCircle2, 
  UserCheck, 
  Calendar, 
  Layers, 
  MapPin, 
  Hash, 
  Plus, 
  Info, 
  Lock, 
  Unlock, 
  Split, 
  Trash2,
  Link2,
  FileCheck,
  UploadCloud,
  X,
  Eye,
  Loader2
} from 'lucide-react';
import { 
  HarvestRecord, 
  ReferenceItem, 
  MuzRecord,
  BademRecord,
  FieldRecord,
  ActiveFieldContext
} from '../../types';
import { generateRefId } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { SmartInput, SmartCreatableSelect } from '../common/SmartField';
import { compressImage, cachePhoto } from '../../utils/photoStorage';
import { FormStepper } from './FormStepper';
import { useFormSteps, FormStepDefinition } from '../../hooks/useFormSteps';
import { PhotoLightboxModal } from '../common/PhotoLightboxModal';
import { canonicalOrchard } from '../../services/locationProfiles';

interface DailyHarvestFormProps {
  onSave: (record: HarvestRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: HarvestRecord | null;
  customFields?: any[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  fieldRecords?: FieldRecord[];
  activeFieldContext?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

const HARVEST_FORM_STEPS: FormStepDefinition[] = [
  { id: 'step-ref', label: '1. Referans & Bahçe', icon: Sprout, description: 'Referans & Bahçe' },
  { id: 'step-crop', label: '2. Ürün & Evre', icon: Layers, description: 'Ürün & Parsel' },
  { id: 'step-tonnage', label: '3. Tonaj & İşçilik', icon: Hash, description: 'Kilo & Çavuş' },
  { id: 'step-photos', label: '4. Fotoğraf & Onay', icon: Camera, description: 'Görseller & Notlar' },
];

export const DailyHarvestForm: React.FC<DailyHarvestFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  customFields = [],
  muzRecords = [],
  bademRecords = [],
  fieldRecords = [],
  activeFieldContext,
  isReadOnly: isReadOnlyProp = false
}) => {
  const formSteps = useFormSteps({
    steps: HARVEST_FORM_STEPS,
    initialStepIndex: 0
  });

  const isEditing = Boolean(initialRecord);
  const isCompletedRecord = initialRecord?.status === 'COMPLETED';
  const [isReadOnly, setIsReadOnly] = useState<boolean>(isReadOnlyProp || isCompletedRecord);

  const [isNewRef, setIsNewRef] = useState(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || '');
  const [customRefInput, setCustomRefInput] = useState('');

  // Kilit State'leri
  const [isProductLocked, setIsProductLocked] = useState(Boolean(!isNewRef && selectedRefId));
  const [isVarietyLocked, setIsVarietyLocked] = useState(Boolean(!isNewRef && selectedRefId));
  const [isOrchardLocked, setIsOrchardLocked] = useState(Boolean(!isNewRef && selectedRefId));

  // HASAT ÖNCESİ TEST BAĞLANTISI (Madde 4)
  const [selectedPreHarvestRef, setSelectedPreHarvestRef] = useState<string>(initialRecord?.linkedTestRefId || ''); // v2.7: kalıcı bağlantı
  const [preHarvestNotice, setPreHarvestNotice] = useState<string | null>(null);

  // ANA PARAMETRE: BAHÇE / ORCHARD (Auto-populated from activeFieldContext if selected in Gantt or Header)
  const [orchard, setOrchard] = useState(initialRecord?.orchard || activeFieldContext?.orchard || '');
  const [operator, setOperator] = useState(initialRecord?.operator || '');
  const [recordDate, setRecordDate] = useState(initialRecord?.recordDate || new Date().toISOString().split('T')[0]);

  // Ürün & Çeşit (Auto-populated from activeFieldContext)
  const [product, setProduct] = useState(initialRecord?.product || activeFieldContext?.product || '');
  const [variety, setVariety] = useState(initialRecord?.variety || activeFieldContext?.variety || '');
  const [sector, setSector] = useState(
    initialRecord?.sector || activeFieldContext?.sector || activeFieldContext?.parcelCode || ''
  );
  const [harvestStage, setHarvestStage] = useState(
    initialRecord?.harvestStage || activeFieldContext?.harvestCycle || ''
  );
  const [phenologicalStage, setPhenologicalStage] = useState(initialRecord?.phenologicalStage || '');
  
  // Lot & Fiş (Opsiyonel)
  const [lotNo, setLotNo] = useState(initialRecord?.lotNo || '');
  const [receiptNo, setReceiptNo] = useState(initialRecord?.receiptNo || '');
  
  // Tonaj & İşçilik
  const [dailyTotalKg, setDailyTotalKg] = useState<number>(initialRecord?.dailyTotalKg ?? 0);
  const [cumulativeTotalKg, setCumulativeTotalKg] = useState<number>(initialRecord?.cumulativeTotalKg ?? 0);
  const [workerCount, setWorkerCount] = useState<number>(initialRecord?.workerCount ?? 0);
  // v2.8: sahadaki günlük rapor alanları (isteğe bağlı)
  const [harvestDayNo, setHarvestDayNo] = useState<string>(initialRecord?.harvestDayNo != null ? String(initialRecord.harvestDayNo) : '');
  const [rowSection, setRowSection] = useState<string>(initialRecord?.rowSection || '');
  const [toolCount, setToolCount] = useState<string>(initialRecord?.toolCount != null ? String(initialRecord.toolCount) : '');
  const [foreman, setForeman] = useState(initialRecord?.foreman || '');

  // Sonraki Adım & Hedef (Hedef Tesis Opsiyonel)
  const [nextStep, setNextStep] = useState(initialRecord?.nextStep || '');
  const [destination, setDestination] = useState(initialRecord?.destination || '');
  const [status, setStatus] = useState<'ACTIVE' | 'COMPLETED'>(initialRecord?.status || 'COMPLETED');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  
  // FOTOĞRAF HIZLI YÜKLEME, SIKIŞTIRMA VE ÖNİZLEME (Madde 1)
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Pre-Harvest Test Discovery list (Muz, Badem, Saha Meyve)
  const preHarvestList = React.useMemo(() => {
    const list: {
      id: string;
      refId: string;
      type: 'MUZ' | 'BADEM' | 'FIELD';
      displayTitle: string;
      product: string;
      variety: string;
      orchard: string;
      sector: string;
      date: string;
      summary: string;
    }[] = [];

    // Muz Testleri
    muzRecords.forEach(m => {
      list.push({
        id: m.id,
        refId: m.refId,
        type: 'MUZ',
        displayTitle: `Muz testi · ${m.refId} · ${m.greenhouseNo || 'sera'}`,
        product: 'Muz (Banana)',
        variety: 'Cavendish',
        orchard: m.greenhouseNo || '',
        sector: m.greenhouseNo || '',
        date: m.timestamp?.split('T')[0] || '',
        summary: `Kalibrasyon: ${m.calibrationMm ?? '—'} mm, Parmak: ${m.fingerLengthCm ?? '—'} cm, Olgunluk: ${m.ripenessScale ?? '—'}`
      });
    });

    // Badem Testleri
    bademRecords.forEach(b => {
      list.push({
        id: b.id,
        refId: b.refId,
        type: 'BADEM',
        displayTitle: `Badem testi · ${b.refId} · ${b.location || ''}`,
        product: 'Badem (Almond)',
        variety: b.variety || '',
        orchard: b.location || '',
        sector: b.location || '',
        date: b.timestamp?.split('T')[0] || '',
        summary: `İç Randımanı: %${b.kernelYieldPercent ?? '—'}, Nem: %${b.moisturePercent ?? '—'}`
      });
    });

    // Saha Meyve Testleri
    fieldRecords.forEach(f => {
      const weightSummary = f.avgFruitWeightG
        ? `Ort. Meyve: ${f.avgFruitWeightG}g${f.testSampleWeightKg ? ` (Test: ${f.testSampleWeightKg}kg)` : ''}`
        : f.testSampleWeightKg ? `Test Ağırlığı: ${f.testSampleWeightKg}kg` : '';
      const testStage = f.testType || 'Hasattan Önce';

      list.push({
        id: f.id,
        refId: f.refId,
        type: 'FIELD',
        displayTitle: `${testStage} · ${f.refId} · ${f.product} · ${f.orchard || f.location || ''}`,
        product: f.product || '',
        variety: f.sortVariety || '',
        orchard: f.orchard || f.location || '',
        sector: f.location || '',
        date: f.timestamp?.split('T')[0] || '',
        summary: `Brix: ${f.avgBrix ?? '—'}°Bx, Sertlik: ${f.avgHardness ?? '—'} kg/cm²${weightSummary ? ` | ${weightSummary}` : ''}${f.hasNitrateTest ? ` | Nitrat: ${f.nitratePass ? 'Uygun' : 'Aşım'}` : ''}${f.hasQualityGrade && f.kaliteSinifi ? ` | Sınıf: ${f.kaliteSinifi}` : ''}`
      });
    });

    return list.sort((a, b) => b.date.localeCompare(a.date));
  }, [muzRecords, bademRecords, fieldRecords]);

  // v49c2: yalnız bu bahçe ve ürünün son 21 gündeki testleri (bahçe/ürün seçilmemişse yalnız tarih süzülür; seçili test her zaman kalır)
  const visibleTests = React.useMemo(() => {
    const day = (d: string) => (d ? new Date(`${d}T00:00:00`).getTime() : 0);
    const ref = day(recordDate) || Date.now();
    const orch = canonicalOrchard(orchard).toLocaleLowerCase('tr');
    const prod = (product || '').split(/[ (/]/)[0].toLocaleLowerCase('tr');
    return preHarvestList.filter(t => {
      if (t.id === selectedPreHarvestRef || t.refId === selectedPreHarvestRef) return true;
      const age = (ref - day(t.date)) / 86400000;
      if (!t.date || age < -1 || age > 21) return false;
      if (orch && canonicalOrchard(t.orchard).toLocaleLowerCase('tr') !== orch) return false;
      if (prod && !(t.product || '').toLocaleLowerCase('tr').startsWith(prod)) return false;
      return true;
    });
  }, [preHarvestList, recordDate, orchard, product, selectedPreHarvestRef]);

  // HASAT ÖNCESİ TEST REFERANSI SEÇİLDİĞİNDE OTOMATİK DOLDURMA (Madde 4)
  const handlePreHarvestSelect = (selectedId: string) => {
    setSelectedPreHarvestRef(selectedId);
    if (!selectedId) {
      setPreHarvestNotice(null);
      return;
    }

    const testItem = preHarvestList.find(item => item.id === selectedId || item.refId === selectedId);
    if (testItem) {
      setProduct(testItem.product);
      setVariety(testItem.variety);
      setOrchard(testItem.orchard);
      if (testItem.sector) setSector(testItem.sector);
      if (testItem.date) setRecordDate(testItem.date);

      setIsProductLocked(true);
      setIsVarietyLocked(true);
      setIsOrchardLocked(true);

      const noticeText = `Bağlandı: ${testItem.displayTitle} · ${testItem.summary}`;
      setPreHarvestNotice(noticeText);

      // Notes alanına da ekle (eğer önceden yazılmadıysa)
      if (!notes.includes(testItem.refId)) {
        setNotes(prev => prev ? `${prev}\n[Ön Test Ref: ${testItem.refId} - ${testItem.summary}]` : `[Ön Test Ref: ${testItem.refId} - ${testItem.summary}]`);
      }
    }
  };

  // Referans seçilince verileri otomatik doldurma & kilitleme (Madde 5)
  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      const match = existingRefs.find(r => r.refId === selectedRefId);
      if (match) {
        if (match.product) {
          setProduct(match.product.replace(/\(.*\)/, '').trim());
          setIsProductLocked(true);
        }
        if (match.orchard) {
          setOrchard(match.orchard);
          setIsOrchardLocked(true);
        }
        if (match.destination) {
          setDestination(match.destination);
        }
      }
    }
  }, [selectedRefId, isNewRef, existingRefs]);

  // FOTOĞRAF ÇEKME / YÜKLEME VE İSTEMCİDE HIZLI SIKIŞTIRMA (Madde 1)
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsCompressingPhoto(true);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        // Client-side hızlı sıkıştırma (max 1280px genişlik, 80% kalite, ~200-400 KB)
        const compressedBase64 = await compressImage(file, 1280, 1280, 0.82);
        
        // IndexedDB ve Yerel önbelleğe kaydet
        const photoKey = `photo_${Date.now()}_${i}`;
        await cachePhoto(photoKey, compressedBase64);

        setPhotos(prev => [...prev, compressedBase64]);
      }
    } catch (err) {
      console.error('Fotoğraf işleme hatası:', err);
      // Fallback normal data URL
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (re) => {
        if (re.target?.result) {
          setPhotos(prev => [...prev, re.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    } finally {
      setIsCompressingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (cameraInputRef.current) cameraInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // Submit
  const handleSubmit = (e?: React.FormEvent, forceStatus?: 'ACTIVE' | 'COMPLETED') => {
    if (e) e.preventDefault();

    const effectiveStatus = forceStatus || status;
    if (!product.trim()) {
      alert('Ürün / çeşit seçilmeden hasat kaydedilemez. Ürün adı izlenebilirlik ve standart kartı için zorunludur.');
      return;
    }
    const finalOrchard = orchard.trim() || 'Genel Saha / Bahçe (Taslak)';
    const finalProduct = product.trim() || 'Meyve / Genel Ürün';

    let finalRefId = selectedRefId;
    if (isNewRef && !isEditing) {
      finalRefId = customRefInput.trim() || generateRefId('HARVEST');
    }

    const harvestRecord: HarvestRecord = {
      id: (isEditing && initialRecord?.id) 
        ? initialRecord.id 
        : `harv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      refId: finalRefId,
      timestamp: initialRecord?.timestamp || new Date().toISOString(),
      operator: operator.trim() || 'Saha Personeli',
      orchard: finalOrchard,
      recordDate,
      product: finalProduct,
      variety,
      sector,
      harvestStage,
      phenologicalStage,
      kaliteSinifi: initialRecord?.kaliteSinifi || '',
      lotNo,
      receiptNo,
      dailyTotalKg: Number(dailyTotalKg) || 0,
      cumulativeTotalKg: Number(cumulativeTotalKg) || Number(dailyTotalKg) || 0,
      workerCount: Number(workerCount) || 0,
      harvestDayNo: harvestDayNo.trim() !== '' ? Number(harvestDayNo) : undefined,
      rowSection: rowSection.trim() || undefined,
      toolCount: toolCount.trim() !== '' ? Number(toolCount) : undefined,
      foreman,
      nextStep,
      destination,
      status: effectiveStatus,
      notes,
      // v2.7: hasat öncesi test bağlantısı yapısal alan olarak (nota metin eklenmez)
      linkedTestRefId: (preHarvestList.find(it => it.id === selectedPreHarvestRef || it.refId === selectedPreHarvestRef)?.refId) || undefined,
      photos
    };

    const newRefData: Partial<ReferenceItem> | undefined = (isNewRef && !isEditing)
      ? {
          refId: finalRefId,
          moduleKey: 'HARVEST',
          product: `${finalProduct}${variety.trim() ? ` (${variety.trim()})` : ''}`,
          orchard: finalOrchard,
          kaliteSinifi: initialRecord?.kaliteSinifi || '',
          location: destination,
          source: finalOrchard,
          destination,
          finalDestination: destination,
          quantity: dailyTotalKg,
          unit: 'kg',
          status: effectiveStatus === 'COMPLETED' ? 'CREATED' : 'CREATED',
          createdAt: new Date().toISOString(),
          operator: operator.trim() || 'Saha Personeli',
          notes: `Günlük hasat. Bahçe: ${finalOrchard}, Lot: ${lotNo}, Fiş: ${receiptNo}, İşçi: ${workerCount}${selectedPreHarvestRef ? ` (Ön Test: ${selectedPreHarvestRef})` : ''}`
        }
      : undefined;

    onSave(harvestRecord, isNewRef && !isEditing, newRefData);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      {/* Header */}
      <div className="bg-white text-slate-900 px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 shrink-0">
            <Sprout className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-1.5">
                Günlük hasat
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-700">
                Bahçe Öncelikli
              </span>
              {isEditing && (
                <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-bold bg-amber-500 text-slate-950">
                  Düzenleme Modu
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-emerald-700/80 truncate sm:whitespace-normal">
              Bahçe öncelikli hasat tonajı, kantar fişi, parçalı yük ve kütük kaydı
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 hover:text-slate-900 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-700 transition self-end sm:self-center shrink-0"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        
        {/* COMPLETED / READ-ONLY BANNER */}
        {isCompletedRecord && (
          <div className="bg-white border-2 border-emerald-200 rounded-2xl p-4 text-slate-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
            <div className="flex items-start sm:items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                <FileCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-xs font-bold text-emerald-700">
                    Kayıt Durumu: Tamamlandı: Completed
                  </h4>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-600">
                    {isReadOnly ? 'Salt Okunur (Read-Only)' : 'Düzenleme Açık (Unlocked)'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  {isReadOnly 
                    ? 'Bu kayıt tamamlanmış ve kilitlenmiştir. Veri bütünlüğü için form alanları salt okunurdur.'
                    : 'Kilit açıldı. Yapılan değişiklikler kaydedildiğinde mevcut referans verisi güncellenecektir.'}
                </p>
              </div>
            </div>

            {isReadOnlyProp ? (
              <span className="px-3 py-1.5 rounded-xl text-xs font-bold text-amber-950 bg-amber-400 border border-amber-300 flex items-center gap-1.5 shadow-xs">
                <Lock className="w-3.5 h-3.5" />
                <span>Ziyaretçi Modu (Salt Okunur)</span>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => setIsReadOnly(prev => !prev)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-1.5 shadow-sm ${
                  isReadOnly
                    ? 'bg-amber-500 hover:bg-amber-50 text-amber-800 border border-amber-200'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-slate-900'
                }`}
              >
                {isReadOnly ? (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Kilidi Aç ve Düzenle / Unlock & Edit</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Tekrar Kilitle / Lock</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}

        <fieldset disabled={isReadOnly} className="w-full max-w-full min-w-0 block border-0 p-0 m-0">
          <FormStepper
            steps={formSteps.steps}
            currentStepIndex={formSteps.currentStepIndex}
            onStepClick={(idx) => formSteps.goToStep(idx)}
            onNext={formSteps.nextStep}
            onPrev={formSteps.prevStep}
            onSubmit={() => handleSubmit(undefined, 'COMPLETED')}
            onSaveDraft={() => handleSubmit(undefined, 'ACTIVE')}
            onCancel={onCancel}
            submitLabel={isReadOnly ? 'Salt Okunur' : isEditing ? 'Hasat Kaydını Güncelle' : 'Hasat Kaydını Tamamla & Kaydet'}
            isReadOnly={isReadOnly}
          >
            {/* ADIM 1: REFERANS & BAHÇE BİLGİLERİ */}
            <div className="space-y-4">
              {/* Reference Selection & Mode */}
              {!isEditing && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 sm:gap-4 w-full max-w-full min-w-0">
                  <div className="w-full md:w-auto min-w-0">
                    <span className="text-[10px] font-bold text-slate-800 block mb-1.5">
                      Referans ID
                    </span>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
                      <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${isNewRef ? 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-1 ring-emerald-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                        <input
                          type="radio"
                          checked={isNewRef}
                          onChange={() => {
                            setIsNewRef(true);
                            setIsProductLocked(false);
                            setIsVarietyLocked(false);
                            setIsOrchardLocked(false);
                          }}
                          className="text-emerald-600 focus:ring-emerald-500 shrink-0"
                        />
                        <span className="leading-tight">Yeni Referans Oluştur</span>
                      </label>

                      <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${!isNewRef ? 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-1 ring-emerald-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                        <input
                          type="radio"
                          checked={!isNewRef}
                          onChange={() => setIsNewRef(false)}
                          className="text-emerald-600 focus:ring-emerald-500 shrink-0"
                        />
                        <span className="leading-tight">Mevcut Referansa Bağla</span>
                      </label>
                    </div>
                  </div>

                  <div className="w-full md:w-auto min-w-0">
                    {isNewRef ? (
                      <input
                        type="text"
                        value={customRefInput}
                        onChange={(e) => setCustomRefInput(e.target.value)}
                        placeholder="Otomatik (HARV-...) veya Özel Kod"
                        className="w-full md:w-80 text-xs tabular-nums font-bold bg-white border border-emerald-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 max-w-full"
                      />
                    ) : (
                      <div className="space-y-1 w-full min-w-0">
                        <select
                          value={selectedRefId}
                          onChange={(e) => setSelectedRefId(e.target.value)}
                          className="w-full md:w-80 text-xs tabular-nums font-bold bg-white border border-slate-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 max-w-full truncate"
                        >
                          <option value="">Referans Seçiniz...</option>
                          {existingRefs.map(r => (
                            <option key={r.refId} value={r.refId}>
                              {r.refId} - {r.product} ({r.orchard || r.source})
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* HASAT ÖNCESİ TEST REFERANS SEÇİM ALANI (Madde 4) */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <Link2 className="w-4 h-4 text-emerald-700" />
                    <span>Bağlı hasat öncesi test</span>
                  </label>
                  <span className="text-[10px] text-emerald-800 bg-emerald-200/60 px-2 py-0.5 rounded-full font-semibold">
                    son 3 hafta · bu bahçe ve ürün
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <select
                    value={selectedPreHarvestRef}
                    onChange={(e) => handlePreHarvestSelect(e.target.value)}
                    className="w-full text-xs font-semibold bg-white border border-emerald-300 text-slate-900 rounded-xl px-3 py-2.5 shadow-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="">{visibleTests.length ? `Test seç (isteğe bağlı) · ${visibleTests.length} uygun test` : 'Bu bahçe ve ürün için son 3 haftada test yok'}</option>
                    {visibleTests.map(item => (
                      <option key={item.id} value={item.id}>
                        {item.date ? `${item.date.slice(8, 10)}.${item.date.slice(5, 7)} · ` : ''}{item.displayTitle} · {item.summary}
                      </option>
                    ))}
                  </select>

                  {selectedPreHarvestRef && (
                    <button
                      type="button"
                      onClick={() => handlePreHarvestSelect('')}
                      className="px-3 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition shrink-0"
                    >
                      Seçimi Temizle
                    </button>
                  )}
                </div>

                {preHarvestNotice && (
                  <div className="p-2.5 bg-white border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
                    <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-semibold">{preHarvestNotice}</span>
                  </div>
                )}
              </div>

              {/* 1. BAHÇE VE OPERATÖR BİLGİLERİ */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div className="sm:col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-800">
                      Bahçe / Plantasyon (Orchard) *
                    </label>
                    {isOrchardLocked && (
                      <button
                        type="button"
                        onClick={() => setIsOrchardLocked(false)}
                        className="text-[10px] text-amber-700 hover:text-amber-800 flex items-center gap-1 font-semibold"
                      >
                        <Unlock className="w-3 h-3" />
                        <span>Kilidi Aç</span>
                      </button>
                    )}
                  </div>
                  <SmartCreatableSelect
                    label=""
                    categoryKey="orchards"
                    options={[]}
                    value={orchard}
                    onChange={setOrchard}
                    disabled={isOrchardLocked}
                    placeholder="Bahçe / Parsel seçiniz veya yeni ekleyiniz..."
                  />
                </div>

                <div>
                  <SmartCreatableSelect
                    label="Operatör / Kaydeden"
                    categoryKey="operators"
                    options={AUTOCOMPLETE_LISTS.operators}
                    value={operator}
                    onChange={setOperator}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Hasat Tarihi
                  </label>
                  <input
                    type="date"
                    value={recordDate}
                    onChange={(e) => setRecordDate(e.target.value)}
                    className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

              </div>
            </div>

            {/* ADIM 2: ÜRÜN, ÇEŞİT VE PARSEL BİLGİLERİ */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Ürün *
                    </label>
                    {isProductLocked && (
                      <button
                        type="button"
                        onClick={() => setIsProductLocked(false)}
                        className="text-[10px] text-amber-700 flex items-center gap-0.5"
                      >
                        <Unlock className="w-2.5 h-2.5" />
                      </button>
                    )}
                  </div>
                  <SmartCreatableSelect
                    label=""
                    categoryKey="products"
                    options={['Şeftali', 'Nektarin', 'Muz', 'Badem', 'Elma', 'Erik', 'Üzüm']}
                    value={product}
                    onChange={setProduct}
                    disabled={isProductLocked}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Çeşit / Variety
                    </label>
                    {isVarietyLocked && (
                      <button
                        type="button"
                        onClick={() => setIsVarietyLocked(false)}
                        className="text-[10px] text-amber-700 flex items-center gap-0.5"
                      >
                        <Unlock className="w-2.5 h-2.5" />
                      </button>
                    )}
                  </div>
                  <SmartInput
                    label=""
                    value={variety}
                    onChange={(e: any) => setVariety(e.target ? e.target.value : e)}
                    disabled={isVarietyLocked}
                  />
                </div>

                <div>
                  <SmartInput
                    label="Sektör / Parsel"
                    value={sector}
                    onChange={(e: any) => setSector(e.target ? e.target.value : e)}
                  />
                </div>

                <div>
                  <SmartCreatableSelect
                    label="Hasat Aşaması"
                    categoryKey="harvest_stages"
                    options={['1. Hasat (İlk Toplama)', '2. Hasat (Ana Toplama)', '3. Hasat (Dip Toplama)']}
                    value={harvestStage}
                    onChange={setHarvestStage}
                  />
                </div>

                <div>
                  <SmartCreatableSelect
                    label="Fenolojik Evre"
                    categoryKey="phenological_stages"
                    options={['F-08 (Hasat Olgunluğu)', 'F-07 (Dönüm Aşaması)', 'F-09 (Tam Olgunluk)']}
                    value={phenologicalStage}
                    onChange={setPhenologicalStage}
                  />
                </div>

              </div>
            </div>

            {/* ADIM 3: TONAJ, İŞÇİLİK VE HEDEF TESİS */}
            <div className="space-y-4">
              {/* 3. KANTAR FİŞİ, LOT VE TONAJ PARAMETRELERİ */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
                
                <div className="lg:col-span-2">
                  <SmartInput
                    label="Hasat Parti / Lot No (Opsiyonel)"
                    value={lotNo}
                    onChange={(e: any) => setLotNo(e.target ? e.target.value : e)}
                    placeholder="Hasat Parti / Lot No (İsteğe bağlı)"
                  />
                </div>

                <div>
                  <SmartInput
                    label="Kantar Fişi No (Opsiyonel)"
                    value={receiptNo}
                    onChange={(e: any) => setReceiptNo(e.target ? e.target.value : e)}
                    placeholder="Kantar Fişi No (İsteğe bağlı)"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Günlük Hasat (Kg) (Opsiyonel)
                  </label>
                  <input
                    type="number"
                    value={dailyTotalKg || ''}
                    onChange={(e) => setDailyTotalKg(Number(e.target.value))}
                    placeholder="Kg (İsteğe bağlı)"
                    className="w-full text-xs tabular-nums font-bold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    İşçi Sayısı / Workers
                  </label>
                  <input
                    type="number"
                    value={workerCount || ''}
                    onChange={(e) => setWorkerCount(Number(e.target.value))}
                    placeholder="Kişi sayısı"
                    className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 text-slate-800"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Hasat günü</label>
                    <input type="number" min={1} value={harvestDayNo} onChange={(e) => setHarvestDayNo(e.target.value)} placeholder="3"
                      className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 text-slate-800" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Sıra / parsel</label>
                    <input type="text" value={rowSection} onChange={(e) => setRowSection(e.target.value)} placeholder="16"
                      className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 text-slate-800" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Makas sayısı</label>
                    <input type="number" min={0} value={toolCount} onChange={(e) => setToolCount(e.target.value)} placeholder="14"
                      className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 text-slate-800" />
                  </div>
                </div>

                <div>
                  <SmartCreatableSelect
                    label="Çavuş / Ekip Başı"
                    categoryKey="foremen"
                    options={[]}
                    value={foreman}
                    onChange={setForeman}
                    placeholder="Seçiniz veya yeni ekleyiniz..."
                  />
                </div>

              </div>

              {/* 5. HEDEF VE SONRAKİ ADIM */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <SmartCreatableSelect
                  label="Genel Hedef Tesis / Destination (Opsiyonel)"
                  categoryKey="destinations"
                  options={[]}
                  value={destination}
                  onChange={setDestination}
                  placeholder="Seçiniz veya yeni tesis ekleyiniz..."
                />

                <SmartCreatableSelect
                  label="Sonraki Adım / Next Step"
                  categoryKey="harvest_next_steps"
                  options={[
                    'Ön soğutmaya (fiş Ön Soğutma sayfasında)',
                    'Doğrudan soğuk depoya (ön soğutmasız)',
                    'Freeze & Dry İşleme Hattına Yönlendirme',
                    'Doğrudan Ticari Satış'
                  ]}
                  value={nextStep}
                  onChange={setNextStep}
                />
              </div>
            </div>

            {/* ADIM 4: FOTOĞRAFLAR, KALİTE VE ONAY */}
            <div className="space-y-4">
              {/* İşlem Durumu */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  İşlem Durumu
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="ACTIVE">Devam Ediyor / In Progress (Taslak Modu)</option>
                  <option value="COMPLETED">Tamamlandı (Kayıt Kapatılacak)</option>
                </select>
              </div>

              {/* 6. FOTOĞRAF HIZLI YÜKLEME VE ANINDA ÖNİZLEME (Madde 1) */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="block text-xs font-bold text-slate-800">
                      Saha & Hasat Fotoğrafları / Photos (Otomatik Sıkıştırma & Çevrimdışı Önbellek)
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Fotoğraflar istemcide otomatik sıkıştırılır (WebP / JPEG 200-400 KB) ve çevrimdışı önbelleğe alınır.
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => cameraInputRef.current?.click()}
                      disabled={isCompressingPhoto}
                      className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Kamera ile Çek</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isCompressingPhoto}
                      className="px-3.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-emerald-300 shadow-2xs cursor-pointer"
                    >
                      {isCompressingPhoto ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>İşleniyor...</span>
                        </>
                      ) : (
                        <>
                          <span>+ Galeriden Seç</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Gizli Kamera Girişi */}
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />

                  {/* Gizli Galeri Girişi */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>

                {/* Photo Thumbnails */}
                {photos.filter(p => p && p.length > 20).length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-1">
                    {photos.filter(p => p && p.length > 20).map((photoUrl, idx) => (
                      <div
                        key={idx}
                        onClick={() => setLightboxIndex(idx)}
                        className="relative group rounded-xl overflow-hidden border border-slate-200 aspect-square bg-slate-100 shadow-2xs cursor-pointer hover:border-emerald-400 transition"
                        title="Fotoğrafı tam ekran önizlemek veya silmek için dokunun"
                      >
                        <img
                          src={photoUrl}
                          alt={`Hasat Fotoğrafı ${idx + 1}`}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setLightboxIndex(idx);
                            }}
                            className="p-1.5 bg-white text-slate-800 rounded-lg hover:bg-slate-100 transition shadow-sm cursor-pointer"
                            title="Büyüt / Önizle"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemovePhoto(idx);
                            }}
                            className="p-1.5 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition shadow-sm cursor-pointer"
                            title="Kaldır / Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 7. NOTLAR */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Hasat Notları & Açıklama
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="Hava durumu, kasa tipi, traktör no veya hasat detayları..."
                  className="w-full text-xs bg-white border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </FormStepper>
        </fieldset>

      </form>

      {/* Full-Screen Photo Lightbox Modal */}
      <PhotoLightboxModal
        isOpen={lightboxIndex !== null}
        photoUrl={lightboxIndex !== null ? photos[lightboxIndex] : null}
        photoIndex={lightboxIndex ?? 0}
        totalPhotos={photos.length}
        title={`Hasat Fotoğrafı #${(lightboxIndex ?? 0) + 1}`}
        onClose={() => setLightboxIndex(null)}
        onDelete={(idx) => {
          handleRemovePhoto(idx);
          if (photos.length <= 1) {
            setLightboxIndex(null);
          } else if (idx >= photos.length - 1) {
            setLightboxIndex(Math.max(0, photos.length - 2));
          }
        }}
        onPrev={lightboxIndex !== null && lightboxIndex > 0 ? () => setLightboxIndex(prev => (prev !== null ? prev - 1 : 0)) : undefined}
        onNext={lightboxIndex !== null && lightboxIndex < photos.length - 1 ? () => setLightboxIndex(prev => (prev !== null ? prev + 1 : 0)) : undefined}
      />

    </div>
  );
};
