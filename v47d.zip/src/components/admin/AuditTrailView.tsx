import React, { useState, useEffect, useMemo } from 'react';
import { 
  History, 
  ArrowLeft, 
  Filter, 
  Search, 
  RotateCcw, 
  Download, 
  User, 
  Calendar, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  ShieldCheck, 
  Clock, 
  Plus, 
  Edit3, 
  Trash2, 
  LogIn, 
  RefreshCw, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { AppUser, ActivityLogItem, ActivityActionType } from '../../types/auth';
import { fetchActivityLogs, getActivityLogs } from '../../utils/authService';
import { useLanguage } from '../../context/LanguageContext';

interface AuditTrailViewProps {
  onBack?: () => void;
  onNavigateToRecord?: (refId: string) => void;
  currentUser?: AppUser | null;
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({
  onBack,
  onNavigateToRecord,
  currentUser
}) => {
  const { t } = useLanguage();
  const [logs, setLogs] = useState<ActivityLogItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copiedRefId, setCopiedRefId] = useState<string | null>(null);

  // Filters
  const [filterUser, setFilterUser] = useState<string>('ALL');
  const [filterModule, setFilterModule] = useState<string>('ALL');
  const [filterAction, setFilterAction] = useState<string>('ALL');
  const [filterDateRange, setFilterDateRange] = useState<'ALL' | 'TODAY' | 'LAST_3' | 'LAST_7' | 'LAST_30'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  // v4.4: giriş/çıkış kayıtları listeyi boğmasın — varsayılan gizli
  const [showAuth, setShowAuth] = useState<boolean>(false);

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const remoteLogs = await fetchActivityLogs();
      if (remoteLogs && remoteLogs.length > 0) {
        setLogs(remoteLogs);
      } else {
        setLogs(getActivityLogs());
      }
    } catch {
      setLogs(getActivityLogs());
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  // Distinct values for dropdown filters
  const uniqueUsers = useMemo(() => {
    const set = new Set<string>();
    logs.forEach(l => {
      if (l.userName) set.add(l.userName);
    });
    return Array.from(set).sort();
  }, [logs]);

  const uniqueModules = useMemo(() => {
    const set = new Set<string>();
    logs.forEach(l => {
      if (l.module) set.add(l.module);
    });
    return Array.from(set).sort();
  }, [logs]);

  const uniqueActions = useMemo(() => {
    const set = new Set<string>();
    logs.forEach(l => {
      if (l.action) set.add(l.action);
    });
    return Array.from(set).sort();
  }, [logs]);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    const now = new Date().getTime();
    const oneDay = 24 * 60 * 60 * 1000;

    return logs.filter(item => {
      // v4.4: giriş / çıkış (AUTH) kayıtları yalnız istenirse
      if (!showAuth && (item.action === 'LOGIN' || item.action === 'LOGOUT' || item.module === 'AUTH')) {
        return false;
      }
      // User filter
      if (filterUser !== 'ALL' && item.userName !== filterUser) {
        return false;
      }
      // Module filter
      if (filterModule !== 'ALL' && item.module !== filterModule) {
        return false;
      }
      // Action filter
      if (filterAction !== 'ALL' && item.action !== filterAction) {
        return false;
      }
      // Date Range filter
      if (filterDateRange !== 'ALL') {
        const itemTime = new Date(item.timestamp).getTime();
        const diffDays = (now - itemTime) / oneDay;
        if (filterDateRange === 'TODAY' && diffDays > 1) return false;
        if (filterDateRange === 'LAST_3' && diffDays > 3) return false;
        if (filterDateRange === 'LAST_7' && diffDays > 7) return false;
        if (filterDateRange === 'LAST_30' && diffDays > 30) return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchRef = item.refId?.toLowerCase().includes(q);
        const matchUser = item.userName?.toLowerCase().includes(q) || item.userEmail?.toLowerCase().includes(q);
        const matchDetails = item.details?.toLowerCase().includes(q);
        const matchAction = item.action?.toLowerCase().includes(q);
        const matchModule = item.module?.toLowerCase().includes(q);
        if (!matchRef && !matchUser && !matchDetails && !matchAction && !matchModule) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [logs, filterUser, filterModule, filterAction, filterDateRange, searchQuery, showAuth]);

  // KPI calculations
  const kpis = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayCount = logs.filter(l => l.timestamp?.startsWith(today)).length;
    const uniqueUserCount = new Set(logs.map(l => l.userId || l.userName)).size;
    const criticalCount = logs.filter(l => 
      l.action === 'DELETE_RECORD' || 
      l.action === 'CLEAR_DEMO_DATA' || 
      l.action?.includes('REJECT')
    ).length;

    return {
      total: logs.length,
      today: todayCount,
      users: uniqueUserCount,
      critical: criticalCount
    };
  }, [logs]);

  // Group filtered logs by date for vertical timeline
  const groupedLogs = useMemo(() => {
    const groups: Record<string, ActivityLogItem[]> = {};
    filteredLogs.forEach(log => {
      const dateKey = log.timestamp ? log.timestamp.split('T')[0] : 'Diğer';
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      groups[dateKey].push(log);
    });
    return groups;
  }, [filteredLogs]);

  // Action badge renderer
  const getActionConfig = (action: ActivityActionType) => {
    switch (action) {
      case 'CREATE_RECORD':
        return {
          label: 'Kayıt Ekleme',
          badgeClass: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
          dotClass: 'bg-emerald-500 border-emerald-300',
          icon: <Plus className="w-3.5 h-3.5" />
        };
      case 'UPDATE_RECORD':
        return {
          label: 'Güncelleme',
          badgeClass: 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/20',
          dotClass: 'bg-sky-500 border-sky-300',
          icon: <Edit3 className="w-3.5 h-3.5" />
        };
      case 'DELETE_RECORD':
      case 'CLEAR_DEMO_DATA':
        return {
          label: 'Silme / Temizleme',
          badgeClass: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20',
          dotClass: 'bg-rose-500 border-rose-300',
          icon: <Trash2 className="w-3.5 h-3.5" />
        };
      case 'LOGIN':
      case 'REGISTER':
        return {
          label: 'Kullanıcı Girişi',
          badgeClass: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20',
          dotClass: 'bg-purple-500 border-purple-300',
          icon: <LogIn className="w-3.5 h-3.5" />
        };
      case 'USER_APPROVED':
      case 'USER_PERMISSIONS_UPDATED':
        return {
          label: 'Yetki & Onay',
          badgeClass: 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/20',
          dotClass: 'bg-teal-500 border-teal-300',
          icon: <ShieldCheck className="w-3.5 h-3.5" />
        };
      case 'SYSTEM_SYNC':
        return {
          label: 'Sistem Senk',
          badgeClass: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border-cyan-500/20',
          dotClass: 'bg-cyan-500 border-cyan-300',
          icon: <RefreshCw className="w-3.5 h-3.5" />
        };
      default:
        return {
          label: action || 'İşlem',
          badgeClass: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20',
          dotClass: 'bg-slate-500 border-slate-300',
          icon: <FileText className="w-3.5 h-3.5" />
        };
    }
  };

  const handleCopyRef = (refId: string) => {
    navigator.clipboard.writeText(refId);
    setCopiedRefId(refId);
    setTimeout(() => setCopiedRefId(null), 2000);
  };

  const handleExportCSV = () => {
    if (filteredLogs.length === 0) return;
    const headers = ['Zaman Damgası', 'Kullanıcı', 'E-Posta', 'Firma', 'Görev', 'Eylem', 'Modül', 'RefID', 'Detay'];
    const rows = filteredLogs.map(l => [
      `"${l.timestamp || ''}"`,
      `"${l.userName || ''}"`,
      `"${l.userEmail || ''}"`,
      `"${l.company || ''}"`,
      `"${l.jobTitle || ''}"`,
      `"${l.action || ''}"`,
      `"${l.module || ''}"`,
      `"${l.refId || ''}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `miwe_denetim_izi_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* 1. ÜST BAŞLIK VE GERİ DÖNÜŞ BAR */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-teal-500/30 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 transition cursor-pointer shrink-0"
              title="Geri Dön"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-400 font-semibold">Tüm modüller</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1 tracking-tight flex items-center gap-2.5">
              <History className="w-6 h-6 text-teal-400" />
              <span>Denetim izi</span>
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Kim, ne zaman, hangi kaydı ekledi, değiştirdi, onayladı veya sildi. Giriş/çıkış kayıtları varsayılan olarak gizlidir.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto shrink-0 flex-wrap">
          <button
            type="button"
            onClick={loadLogs}
            disabled={isLoading}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer shadow-xs"
          >
            <RotateCcw className={`w-4 h-4 text-teal-400 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Yenile</span>
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold transition cursor-pointer shadow-md active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>CSV Dışa Aktar</span>
          </button>
        </div>
      </div>

      {/* 2. TOP-LEVEL KPI KARTLARI */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>Toplam Denetim Kaydı</span>
            <History className="w-4 h-4 text-teal-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-mono">
            {kpis.total.toLocaleString('tr-TR')}
          </div>
          <div className="text-[11px] text-teal-600 dark:text-teal-400 font-semibold">Tüm modüller &amp; kullanıcılar</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>Bugünkü Eylemler</span>
            <Clock className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
            {kpis.today.toLocaleString('tr-TR')}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">Son 24 saat içindeki aktivite</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>Aktif Operatörler</span>
            <User className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-indigo-600 dark:text-indigo-400 font-mono">
            {kpis.users}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">Farklı kayıt yazarı</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>Kritik İşlemler</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-600 dark:text-rose-400 font-mono">
            {kpis.critical}
          </div>
          <div className="text-[11px] text-rose-500 font-semibold">Silme veya veri sıfırlama</div>
        </div>
      </div>

      {/* 3. GELİŞMİŞ FİLTRE PANELİ */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-teal-500" />
            <span>Denetim Filtreleri &amp; Arama</span>
          </div>

          {(filterUser !== 'ALL' || filterModule !== 'ALL' || filterAction !== 'ALL' || filterDateRange !== 'ALL' || searchQuery) && (
            <button
              type="button"
              onClick={() => {
                setFilterUser('ALL');
                setFilterModule('ALL');
                setFilterAction('ALL');
                setFilterDateRange('ALL');
                setSearchQuery('');
              }}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 cursor-pointer flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Filtreleri Sıfırla</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {/* Arama Input */}
          <div className="relative sm:col-span-2 lg:col-span-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="RefID, kişi veya detay..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-slate-900 dark:text-white"
            />
          </div>

          {/* Kullanıcı Filtresi */}
          <div>
            <select
              value={filterUser}
              onChange={(e) => setFilterUser(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-slate-900 dark:text-white font-medium cursor-pointer"
            >
              <option value="ALL">Tüm Kullanıcılar ({uniqueUsers.length})</option>
              {uniqueUsers.map(u => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </div>

          {/* Modül Filtresi */}
          <div>
            <select
              value={filterModule}
              onChange={(e) => setFilterModule(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-slate-900 dark:text-white font-medium cursor-pointer"
            >
              <option value="ALL">Tüm Modüller ({uniqueModules.length})</option>
              {uniqueModules.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* Eylem Türü Filtresi */}
          <div>
            <select
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-slate-900 dark:text-white font-medium cursor-pointer"
            >
              <option value="ALL">Tüm Eylemler ({uniqueActions.length})</option>
              {uniqueActions.map(a => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </div>

          {/* Zaman Aralığı */}
          <div>
            <select
              value={filterDateRange}
              onChange={(e) => setFilterDateRange(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-slate-900 dark:text-white font-medium cursor-pointer"
            >
              <option value="ALL">Tüm Tarihler</option>
              <option value="TODAY">Bugün</option>
              <option value="LAST_3">Son 3 Gün</option>
              <option value="LAST_7">Son 7 Gün</option>
              <option value="LAST_30">Son 30 Gün</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
          <span>{filteredLogs.length} kayıt listeleniyor</span>
          <label className="inline-flex items-center gap-1.5 cursor-pointer font-semibold text-slate-600 dark:text-slate-300">
            <input type="checkbox" checked={showAuth} onChange={e => setShowAuth(e.target.checked)} className="w-3.5 h-3.5" />
            Giriş / çıkışları göster
          </label>
          {searchQuery && (
            <span className="font-semibold text-teal-600 dark:text-teal-400">"{searchQuery}" araması aktif</span>
          )}
        </div>
      </div>

      {/* 4. DİKEY ZAMAN ÇİZELGESİ (VERTICAL TIMELINE) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
              Kronolojik Olay Akışı
            </h2>
          </div>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            {Object.keys(groupedLogs).length} Farklı Gün
          </span>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="py-12 text-center text-slate-400 space-y-2">
            <History className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700" />
            <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
              Filtrelere uygun denetim kaydı bulunamadı.
            </p>
            <p className="text-xs text-slate-400">
              Lütfen filtre kriterlerinizi genişletin veya yeni kayıt işlemleri gerçekleştirin.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.entries(groupedLogs).map(([dateKey, dateLogs]) => (
              <div key={dateKey} className="space-y-4">
                {/* Gün Başlığı */}
                <div className="sticky top-20 z-10 flex items-center gap-2.5">
                  <div className="px-3 py-1 rounded-xl bg-slate-900 text-white text-xs font-black font-mono shadow-md border border-teal-500/30 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-teal-400" />
                    <span>{dateKey}</span>
                  </div>
                  <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
                </div>

                {/* Timeline Nodes */}
                <div className="relative pl-6 sm:pl-8 space-y-4 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
                  {dateLogs.map((item) => {
                    const actionCfg = getActionConfig(item.action);
                    const timeStr = item.timestamp ? new Date(item.timestamp).toLocaleTimeString() : '';

                    return (
                      <div 
                        key={item.id}
                        className="relative group bg-slate-50/70 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 transition shadow-2xs hover:shadow-md"
                      >
                        {/* Timeline Node Icon Pin */}
                        <div className={`absolute -left-6 sm:-left-8 top-4 w-6 h-6 rounded-full border-2 bg-white dark:bg-slate-900 flex items-center justify-center text-white shadow-xs z-10 ${actionCfg.dotClass}`}>
                          <span className="w-2 h-2 rounded-full bg-slate-900 dark:bg-white" />
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`px-2 py-0.5 rounded-lg text-xs font-bold border flex items-center gap-1 ${actionCfg.badgeClass}`}>
                              {actionCfg.icon}
                              <span>{actionCfg.label}</span>
                            </span>

                            {item.module && (
                              <span className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-slate-200/80 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                {item.module}
                              </span>
                            )}

                            {item.refId && (
                              <div className="flex items-center gap-1 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 px-2 py-0.5 rounded-md text-[11px] font-mono font-bold text-teal-800 dark:text-teal-300">
                                <span>{item.refId}</span>
                                <button
                                  type="button"
                                  onClick={() => handleCopyRef(item.refId!)}
                                  className="text-teal-600 hover:text-teal-800 cursor-pointer ml-0.5"
                                  title="RefID Kopyala"
                                >
                                  {copiedRefId === item.refId ? (
                                    <Check className="w-3 h-3 text-emerald-500" />
                                  ) : (
                                    <Copy className="w-3 h-3" />
                                  )}
                                </button>
                                {onNavigateToRecord && (
                                  <button
                                    type="button"
                                    onClick={() => onNavigateToRecord(item.refId!)}
                                    className="text-teal-600 hover:text-teal-800 cursor-pointer"
                                    title="Kayda Git"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{timeStr}</span>
                          </div>
                        </div>

                        {/* User & Company info */}
                        <div className="mt-2.5 flex items-center gap-2.5 flex-wrap text-xs text-slate-600 dark:text-slate-300">
                          <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                            <div className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center text-[10px] font-mono font-black">
                              {(item.userName || 'U')[0].toUpperCase()}
                            </div>
                            <span>{item.userName || 'Bilinmeyen Kullanıcı'}</span>
                          </div>

                          {item.jobTitle && (
                            <span className="text-[11px] text-slate-500 dark:text-slate-400">
                              • {item.jobTitle}
                            </span>
                          )}

                          {item.company && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                              {item.company}
                            </span>
                          )}
                        </div>

                        {/* Details Message */}
                        {item.details && (
                          <div className="mt-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-200 leading-relaxed font-sans">
                            {item.details}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
