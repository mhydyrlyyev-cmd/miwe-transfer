import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Code2, Database, Zap, ShieldCheck, RefreshCw, AlertCircle, FileSpreadsheet, Download } from 'lucide-react';
import { generateGoogleAppsScriptCode } from '../utils/calculations';

/** v2: Web App (doGet/doPost) ve token kullanılmaz; eski alanlar gizli. */
const LEGACY_WEBAPP = false;

interface GasSetupModalProps {
  onClose: () => void;
  gasUrl: string;
  onSaveGasUrl: (url: string) => void;
  onTestConnection: (url: string, token?: string) => Promise<boolean>;
  spreadsheetUrl?: string;
  onSaveSpreadsheetUrl?: (url: string) => void;
  onPullFromSheets?: (token?: string) => Promise<boolean | void>;
  gasToken?: string;
  onSaveGasToken?: (token: string) => void;
}

export const GasSetupModal: React.FC<GasSetupModalProps> = ({
  onClose,
  gasUrl,
  onSaveGasUrl,
  onTestConnection,
  spreadsheetUrl = '',
  onSaveSpreadsheetUrl,
  onPullFromSheets,
  gasToken = 'miwe-sec-token-2026',
  onSaveGasToken
}) => {
  const [copied, setCopied] = useState(false);
  const [urlInput, setUrlInput] = useState(gasUrl);
  const [tokenInput, setTokenInput] = useState(gasToken);
  const [sheetUrlInput, setSheetUrlInput] = useState(spreadsheetUrl);
  const [testStatus, setTestStatus] = useState<'IDLE' | 'TESTING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [testMessage, setTestMessage] = useState('');
  const [isPulling, setIsPulling] = useState(false);
  const [pullMessage, setPullMessage] = useState('');

  const fullGasCode = generateGoogleAppsScriptCode();

  const handleCopyCode = () => {
    const onDone = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    };

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(fullGasCode).then(onDone).catch(() => {
        try {
          const textarea = document.createElement('textarea');
          textarea.value = fullGasCode;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          onDone();
        } catch (e) {
          console.warn('Fallback copy failed:', e);
        }
      });
    } else {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = fullGasCode;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        onDone();
      } catch (e) {
        console.warn('ExecCommand copy failed:', e);
      }
    }
  };

  const handleSaveSheetUrl = () => {
    if (onSaveSpreadsheetUrl) {
      onSaveSpreadsheetUrl(sheetUrlInput.trim());
      alert('✓ Google E-Tablo direkt linki kaydedildi.');
    }
  };

  const handlePullData = async () => {
    if (!onPullFromSheets) return;
    setIsPulling(true);
    setPullMessage('Google Sheets tablosundan güncel kayıtlar çekiliyor...');
    try {
      await onPullFromSheets();
      setPullMessage('✓ Google Sheets verileri başarıyla içeri aktarıldı ve senkronize edildi.');
    } catch (e: any) {
      setPullMessage(`Hata: ${e.message || 'Veri çekilemedi'}`);
    } finally {
      setIsPulling(false);
    }
  };

  const handleSaveAndTest = async () => {
    const trimmed = urlInput.trim();
    if (!trimmed) {
      alert('Lütfen geçerli bir Google Apps Script Web App URL girin.');
      return;
    }
    if (trimmed.includes('/dev')) {
      alert('Girdiğiniz URL bir geliştirici test URL\'sidir (/dev).\n\nLütfen Google Apps Script editöründe:\n1. "Dağıt (Deploy) > Yeni Dağıtım (New Deployment)" seçin.\n2. Tür olarak "Web Uygulaması (Web App)" seçin.\n3. "Erişim: Herkes (Anyone)" olarak ayarlayın.\n4. Oluşan "/exec" ile biten canlı URL\'yi buraya yapıştırın.');
      return;
    }
    setTestStatus('TESTING');
    setTestMessage('Google Apps Script Web App ile el sıkışılıyor...');

    try {
      const ok = await onTestConnection(urlInput.trim(), tokenInput.trim());
      if (ok) {
        setTestStatus('SUCCESS');
        setTestMessage('✓ Bağlantı Başarılı! Google E-Tablolar veri tabanı entegre.');
        onSaveGasUrl(urlInput.trim());
        if (onSaveGasToken) {
          onSaveGasToken(tokenInput.trim());
        }
        if (onSaveSpreadsheetUrl && sheetUrlInput.trim()) {
          onSaveSpreadsheetUrl(sheetUrlInput.trim());
        }
      } else {
        setTestStatus('ERROR');
        setTestMessage('⚠ Bağlantı kurulamadı. Web App yetkisinin "Tüm Kullanıcılar (Anyone)" olduğundan ve tokenın eşleştiğinden emin olun.');
      }
    } catch (e: any) {
      setTestStatus('ERROR');
      setTestMessage(`Hata: ${e.message || 'CORS veya URL erişim hatası'}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full my-8 overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-400">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                ⚡ Google Apps Script & E-Tablolar Entegrasyonu
              </h2>
              <p className="text-xs text-slate-400">
                Tek tıkla Google Sheets backend kodunu kurun, bağlayın ve senkronize edin
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Quick Setup Instructions (3 Steps) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
                1
              </span>
              <h4 className="text-xs font-bold text-slate-900">E-Tablo & Kod Editörü</h4>
              <p className="text-[11px] text-slate-500 mt-1">
                Google E-Tablolar açın &rarr; <strong>Uzantılar &rarr; Apps Script</strong> menüsüne tıklayın.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
                2
              </span>
              <h4 className="text-xs font-bold text-slate-900">Kodu Yapıştırın</h4>
              <p className="text-[11px] text-slate-500 mt-1">
                Aşağıdaki <strong>Code.gs</strong> kodunu kopyalayın, editördeki eski kodun <strong>tamamının yerine</strong> yapıştırın ve kaydedin.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
                3
              </span>
              <h4 className="text-xs font-bold text-slate-900">Okuma Hesabı &amp; kurulum()</h4>
              <p className="text-[11px] text-slate-500 mt-1">
                Platformda bir okuma hesabı açın ve <strong>Pasif Okuyucu</strong> yapın. E-posta/parolayı kodun başındaki <strong>KURULUM</strong> alanına yazıp <strong>kurulum</strong> fonksiyonunu çalıştırın. Web Uygulaması dağıtımı ve token <strong>gerekmez</strong>.
              </p>
            </div>
          </div>

          {/* Web App URL Config & Connection Tester */}
          <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-4 space-y-3">
            <div className="p-3 rounded-lg bg-white border border-emerald-300 text-[11px] text-emerald-950 leading-relaxed">
              <strong>Mimari v2:</strong> Tablo, Firestore’dan <strong>her 15 dakikada otomatik</strong> güncellenir (tek yönlü). Pivot tablolar için kaynak olarak <strong>PIVOT_DATA</strong> sayfasını seçin. Son güncelleme ve hatalar <strong>_DURUM</strong> sayfasında görünür.
            </div>
            {LEGACY_WEBAPP && (<>
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-emerald-600" />
                <span>Google Apps Script Web Uygulaması URL (Yazma & Okuma API)</span>
              </label>
              <span className="text-[10px] text-emerald-800 font-medium">Örn: https://script.google.com/macros/s/.../exec</span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                className="flex-1 text-xs bg-white border border-emerald-300 rounded-lg px-3 py-2 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={handleSaveAndTest}
                disabled={testStatus === 'TESTING'}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition shadow-sm whitespace-nowrap"
              >
                {testStatus === 'TESTING' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Test Ediliyor...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>Kaydet & Test Et</span>
                  </>
                )}
              </button>
            </div>

            {/* Erişim Anahtarı (APP_TOKEN) */}
            <div className="pt-2 border-t border-emerald-200/80 space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Güvenlik Tokenı (APP_TOKEN)</span>
                </label>
                <span className="text-[10px] text-slate-500">Google Script Properties veya kod içi token</span>
              </div>
              <input
                type="text"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="miwe-sec-token-2026"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {testMessage && (
              <div className={`p-2.5 rounded-lg text-xs font-medium ${
                testStatus === 'SUCCESS' ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' :
                testStatus === 'ERROR' ? 'bg-rose-100 text-rose-900 border border-rose-300' :
                'bg-blue-100 text-blue-900'
              }`}>
                {testMessage}
              </div>
            )}

            </>)}
            {/* Direct Google Sheets URL input */}
            <div className="pt-2 border-t border-emerald-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span>Google E-Tablo Doğrudan Erişim URL'si (Spreadsheet Linki)</span>
                </label>
                <span className="text-[10px] text-slate-500">Üst panodaki butona bağlanır</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={sheetUrlInput}
                  onChange={(e) => setSheetUrlInput(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/.../edit"
                  className="flex-1 text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={handleSaveSheetUrl}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg transition whitespace-nowrap"
                >
                  Kaydet
                </button>
                {sheetUrlInput && (
                  <a
                    href={sheetUrlInput}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition whitespace-nowrap"
                  >
                    <span>Tabloyu Aç</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>

            {LEGACY_WEBAPP && (<>
            {/* Bidirectional Sync (Pull from Google Sheets) */}
            {onPullFromSheets && (
              <div className="pt-2 border-t border-emerald-200/80 flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-teal-600" />
                    <span>Çift Yönlü Senkronizasyon (Google Sheets &rarr; Platform)</span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    Google E-Tablosundaki en güncel kayıtları anında tarayıcıya içeri aktarın (doGet).
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handlePullData}
                  disabled={isPulling}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition shadow-xs whitespace-nowrap"
                >
                  {isPulling ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>İçeri Aktarılıyor...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Verileri İçeri Çek (Pull)</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {pullMessage && (
              <div className="p-2.5 rounded-lg text-xs font-medium bg-teal-50 border border-teal-200 text-teal-900">
                {pullMessage}
              </div>
            )}

            {/* doGet Hatası Çözümü Bilgi Kutusu */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-900 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5 text-amber-950">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>💡 Apps Script editöründe 'doGet' hatası alıyorsanız:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-amber-900 leading-relaxed pl-1">
                <li>
                  <strong>'Çalıştır' (Run) butonu için:</strong> Apps Script üst araç çubuğundaki fonksiyon listesinden <code>doGet</code> yerine <strong><code>setupMIWE</code></strong> fonksiyonunu seçip <strong>Çalıştır</strong>'a basın ve Google izinlerini onaylayın.
                </li>
                <li>
                  <strong>E-Tabloya Bağlı Olma:</strong> Scripti Google Sheet'in içindeki <strong>Uzantılar &gt; Apps Script</strong> menüsünden açtığınızdan emin olun.
                </li>
                <li>
                  <strong>Web App Dağıtımı:</strong> Sağ üstteki <strong>Dağıt &gt; Yeni Dağıtım &gt; Web Uygulaması</strong> deyin. Erişimi olan kişiler: <strong>Tüm Kullanıcılar (Anyone)</strong> seçip linki buraya yapıştırın.
                </li>
              </ul>
            </div>
            </>)}
          </div>

          {/* v45: eski gömülü Code.gs ve eski sayfa listesi kaldırıldı (güncel değildi) */}
          <div className="text-xs text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5">
            <p className="font-bold text-slate-800">Google Sheets nasıl çalışır?</p>
            <p>Tablo, Firestore'daki verilerin <strong>salt okunur kopyasıdır</strong> ve her 15 dakikada bir kendiliğinden güncellenir. Tabloda yapılan değişiklik platforma geri yazılmaz.</p>
            <p>Kurulum: güncel <code>google-apps-script/Code.gs</code> dosyasını tablonun <strong>Uzantılar › Apps Script</strong> ekranına yapıştırın ve bir kez <code>tablolariGuncelle</code> fonksiyonunu çalıştırın. Durum <code>_DURUM</code> sayfasında görünür.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
