import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  Area,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import {
  BarChart3,
  Calendar,
  Filter,
  Eye,
  EyeOff,
  AlertTriangle,
  Clock,
  Layers,
  TrendingUp,
  Users,
  ArrowUpDown,
  Flame,
  CheckCircle2,
  Activity
} from 'lucide-react';
import { MUZ_TOPLAM_EXACT_ROWS } from '../../data/bananaRibbonData';
import {
  BANANA_GREENHOUSES_2027,
  normalizeBananaGreenhouseName
} from '../../data/banana2027Data';
import {
  resolveToplamPeriodNetDates,
  getRibbonColorMeta
} from '../../data/bananaToplamCalendarAdapter';
import { DELILNAMA_2026_BY_TOPLAM_PERIOD_ID } from '../../data/delilnamaBanan2026Data';
import type { MuzRecord, HarvestRecord } from '../../types';

export interface HarvestAnalyticsSectionProps {
  muzRecords?: MuzRecord[];
  harvestRecords?: HarvestRecord[];
  compactMode?: boolean;
  initialSubView?: 'ALL' | 'HARVEST_FORECASTING' | 'HARVEST_DELAY_ANALYSIS';
}

interface EnrichedHarvestCohort {
  id: string;
  periodId: string;
  greenhouseName: string;
  variety: string;
  periodLabel: string;
  ribbonColorName: string;
  ribbonHex: string;
  taggingDate: string;
  expectedHarvestDate: string;
  expectedTons: number;
  realizedTons: number;
  expectedKg: number;
  realizedKg: number;
  boundBunches: number;
  realizationPct: number;
  maturationWeeks: number;
  harvestWeekInt: number;
  delayWeeksOver11: number;
  isOver11Weeks: boolean;
  isOctNovSeasonal: boolean;
  octNovSeasonLabel: string;
}

export interface SeraHarvestDelayFrequencyRow {
  id: string;
  greenhouseName: string;
  variety: string;
  harvestWeek: number;
  harvestWeekLabel: string;
  harvestFrequency: number; // Kaç dönem/parti bu sera ve bu haftada çakışıyor
  delayWeeksOver11: number;
  delayStatusLabel: string;
  totalBoundBunches: number;
  expectedTons: number;
  realizedTons: number;
  varianceTons: number;
  estimatedWorkersNeeded: number;
  estimatedCrewsNeeded: number;
  laborIntensityLevel: 'PEAK_CRITICAL' | 'HIGH_LOAD' | 'MODERATE_LOAD' | 'STANDARD';
  dominantRibbonColor: string;
  dominantRibbonHex: string;
  periodSamples: string[];
}

const GREENHOUSE_VARIETY_MAP: Record<string, string> = {
  'GB-5-6': 'Cavendish Grand Nain',
  'GB-7-8': 'Cavendish Grand Nain',
  'Maksat 9-10': 'Williams Cavendish',
  'Miweli 3-4': 'Grand Nain (Mega)',
  'Miweli 1-2': 'Williams Cavendish',
  'Hem-11-12': 'Cavendish Grand Nain',
  'Hem-5': 'Dwarf Cavendish'
};

export const BANANA_VARIETY_OPTIONS = [
  'ALL',
  'Cavendish Grand Nain',
  'Williams Cavendish',
  'Grand Nain (Mega)',
  'Dwarf Cavendish'
];

export const HarvestAnalyticsSection: React.FC<HarvestAnalyticsSectionProps> = ({
  muzRecords = [],
  harvestRecords = [],
  initialSubView = 'ALL'
}) => {
  // Filters: Date Range, Variety, Greenhouse, Oct-Nov Seasonal Toggle, 11-Week Cycle Trend Toggle
  const [startDate, setStartDate] = useState<string>('2025-11-01');
  const [endDate, setEndDate] = useState<string>('2026-12-31');
  const [selectedVariety, setSelectedVariety] = useState<string>('ALL');
  const [selectedGreenhouse, setSelectedGreenhouse] = useState<string>('ALL');
  const [showOctNovProgress, setShowOctNovProgress] = useState<boolean>(true);
  const [show11WeekCycleTrend, setShow11WeekCycleTrend] = useState<boolean>(true);
  const [forecastAxisMode, setForecastAxisMode] = useState<'BY_CYCLE_WEEK' | 'BY_CALENDAR_WEEK' | 'BY_SERA'>('BY_CYCLE_WEEK');
  const [delaySortBy, setDelaySortBy] = useState<'FREQUENCY_DESC' | 'DELAY_WEEK_DESC' | 'LABOR_DESC' | 'SERA_ASC'>('FREQUENCY_DESC');
  const [activeViewMode, setActiveViewMode] = useState<'ALL' | 'HARVEST_FORECASTING' | 'HARVEST_DELAY_ANALYSIS'>(initialSubView);

  // Build unified dataset from Google Sheets "Toplam" + 2026 Delilnama realized harvests
  const allCohorts = useMemo<EnrichedHarvestCohort[]>(() => {
    const list: EnrichedHarvestCohort[] = [];

    // 1. Process Live Muz Records entered from Main Portal (01)
    muzRecords.forEach((mr, idx) => {
      if (!mr.netWeightKg || mr.netWeightKg <= 0) return;
      const ghName = normalizeBananaGreenhouseName(mr.greenhouseNo || 'GB-5-6');
      const colorMeta = getRibbonColorMeta(mr.ribbonColor || 'Mavi');
      const weeks = mr.harvestAgeWeeks && mr.harvestAgeWeeks > 0 ? mr.harvestAgeWeeks : 11.5;
      const harvestWeekInt = Math.min(15, Math.max(10, Math.round(weeks)));
      const dateIso = ((mr as any).date || mr.timestamp || new Date().toISOString()).slice(0, 10);
      list.push({
        id: `MUZ-LIVE-${idx}`,
        periodId: mr.refId || `LIVE-${idx}`,
        greenhouseName: ghName,
        variety: GREENHOUSE_VARIETY_MAP[ghName] || 'Cavendish Grand Nain',
        periodLabel: `Canlı Muz Kaydı (${mr.refId || dateIso})`,
        ribbonColorName: colorMeta.trLabel,
        ribbonHex: colorMeta.hex,
        taggingDate: dateIso,
        expectedHarvestDate: dateIso,
        expectedKg: mr.netWeightKg,
        realizedKg: mr.netWeightKg,
        expectedTons: Number((mr.netWeightKg / 1000).toFixed(1)),
        realizedTons: Number((mr.netWeightKg / 1000).toFixed(1)),
        boundBunches: Math.max(1, Math.round(mr.netWeightKg / 32)),
        realizationPct: 100,
        maturationWeeks: weeks,
        harvestWeekInt,
        delayWeeksOver11: Math.max(0, Number((weeks - 11).toFixed(1))),
        isOver11Weeks: weeks > 11,
        isOctNovSeasonal: dateIso.includes('-10-') || dateIso.includes('-11-'),
        octNovSeasonLabel: 'Fiili Kayıt'
      });
    });

    // 2. Process Live Harvest Records entered from Main Portal (01)
    harvestRecords.forEach((hr, idx) => {
      const weight = hr.dailyTotalKg || 0;
      if (weight <= 0) return;
      const dateIso = (hr.recordDate || hr.timestamp || new Date().toISOString()).slice(0, 10);
      list.push({
        id: `HARVEST-LIVE-${idx}`,
        periodId: hr.refId || `HARVEST-${idx}`,
        greenhouseName: hr.orchard || 'Saha / Bahçe',
        variety: hr.variety || hr.product || 'Taze Meyve',
        periodLabel: `Fiili Hasat Kaydı (${hr.refId})`,
        ribbonColorName: 'Saha Hasadı',
        ribbonHex: '#10b981',
        taggingDate: dateIso,
        expectedHarvestDate: dateIso,
        expectedKg: weight,
        realizedKg: weight,
        expectedTons: Number((weight / 1000).toFixed(1)),
        realizedTons: Number((weight / 1000).toFixed(1)),
        boundBunches: Math.max(1, Math.round(weight / 25)),
        realizationPct: 100,
        maturationWeeks: 11,
        harvestWeekInt: 11,
        delayWeeksOver11: 0,
        isOver11Weeks: false,
        isOctNovSeasonal: dateIso.includes('-10-') || dateIso.includes('-11-'),
        octNovSeasonLabel: 'Fiili Hasat'
      });
    });

    return list;
  }, [muzRecords, harvestRecords]);

  // Filtered cohorts by Date Range, Variety, and Greenhouse
  const filteredCohorts = useMemo(() => {
    return allCohorts.filter(c => {
      if (selectedVariety !== 'ALL' && c.variety !== selectedVariety) return false;
      if (selectedGreenhouse !== 'ALL' && c.greenhouseName !== selectedGreenhouse) return false;
      if (startDate && c.taggingDate < startDate && c.expectedHarvestDate < startDate) return false;
      if (endDate && c.taggingDate > endDate && c.expectedHarvestDate > endDate) return false;
      return true;
    });
  }, [allCohorts, selectedVariety, selectedGreenhouse, startDate, endDate]);

  // ============================================================================
  // 1. HARVEST FORECASTING DATA (RECHARTS COMPOSEDCHART PER WEEK + 11-WEEK TREND)
  // ============================================================================
  const weeklyForecastComposedData = useMemo(() => {
    if (forecastAxisMode === 'BY_CYCLE_WEEK') {
      const cycleWeeks = [
        { weekNum: 10, label: '10. Hafta (Erken)', idealWeight: 0.88 },
        { weekNum: 11, label: '11. Hafta (İdeal Döngü)', idealWeight: 1.0 },
        { weekNum: 12, label: '12. Hafta (+1 Hf Geç)', idealWeight: 0.94 },
        { weekNum: 13, label: '13. Hafta (+2 Hf Geç)', idealWeight: 0.85 },
        { weekNum: 14, label: '14. Hafta (+3 Hf Geç)', idealWeight: 0.76 },
        { weekNum: 15, label: '15+ Hafta (Kritik Aşım)', idealWeight: 0.68 }
      ];

      return cycleWeeks.map(cw => {
        const items = filteredCohorts.filter(c => {
          if (cw.weekNum === 10) return c.harvestWeekInt <= 10;
          if (cw.weekNum === 15) return c.harvestWeekInt >= 15;
          return c.harvestWeekInt === cw.weekNum;
        });

        const expectedTon = Number(
          (items.reduce((s, i) => s + i.expectedKg, 0) / 1000).toFixed(1)
        );
        const realizedTon = Number(
          (items.reduce((s, i) => s + i.realizedKg, 0) / 1000).toFixed(1)
        );
        const octNovTon = Number(
          (
            items
              .filter(i => i.isOctNovSeasonal)
              .reduce((s, i) => s + (i.realizedKg || i.expectedKg), 0) / 1000
          ).toFixed(1)
        );

        // 11-Week Harvest Cycle Trend Line (Projected benchmark based on 11-week cycle efficiency)
        const cycle11BenchmarkTon = Number((expectedTon * cw.idealWeight).toFixed(1));
        const varianceTon = Number((realizedTon - expectedTon).toFixed(1));
        const variancePct =
          expectedTon > 0 ? Math.round(((realizedTon - expectedTon) / expectedTon) * 100) : 0;
        const completionPct =
          expectedTon > 0 ? Math.min(100, Math.round((realizedTon / expectedTon) * 100)) : 0;

        return {
          name: cw.label,
          shortName: `${cw.weekNum}. Hf`,
          subtitle: `${items.length} sera/kurdele partisi`,
          BeklenenTon: expectedTon,
          GerceklesenTon: realizedTon,
          Cycle11WeekTrendTon: cycle11BenchmarkTon,
          OctNovProgressTon: showOctNovProgress ? octNovTon : 0,
          VarianceTon: varianceTon,
          VariancePct: variancePct,
          completionPct,
          avgWeek: cw.weekNum,
          cohortCount: items.length,
          ribbonHex:
            cw.weekNum === 11
              ? '#10b981'
              : cw.weekNum === 12
                ? '#f59e0b'
                : cw.weekNum >= 13
                  ? '#e11d48'
                  : '#0ea5e9'
        };
      });
    }

    if (forecastAxisMode === 'BY_CALENDAR_WEEK') {
      // Group by periodId (chronological Google Sheets harvest weeks)
      const byPeriod = new Map<
        string,
        {
          periodId: string;
          label: string;
          ribbonHex: string;
          expectedKg: number;
          realizedKg: number;
          octNovKg: number;
          weeksSum: number;
          count: number;
        }
      >();

      filteredCohorts.forEach(c => {
        const cur = byPeriod.get(c.periodId) || {
          periodId: c.periodId,
          label: c.periodLabel,
          ribbonHex: c.ribbonHex,
          expectedKg: 0,
          realizedKg: 0,
          octNovKg: 0,
          weeksSum: 0,
          count: 0
        };
        cur.expectedKg += c.expectedKg;
        cur.realizedKg += c.realizedKg;
        if (c.isOctNovSeasonal) cur.octNovKg += c.realizedKg || c.expectedKg;
        cur.weeksSum += c.maturationWeeks;
        cur.count += 1;
        byPeriod.set(c.periodId, cur);
      });

      return Array.from(byPeriod.values())
        .slice(0, 14)
        .map((p, idx) => {
          const expectedTon = Number((p.expectedKg / 1000).toFixed(1));
          const realizedTon = Number((p.realizedKg / 1000).toFixed(1));
          const avgWk = Number((p.weeksSum / Math.max(1, p.count)).toFixed(1));
          // 11-week cycle trend line adjusts expected output by 11/avgWk ratio
          const cycle11BenchmarkTon = Number(
            (expectedTon * Math.min(1.05, 11.0 / Math.max(10, avgWk))).toFixed(1)
          );
          const octNovTon = Number((p.octNovKg / 1000).toFixed(1));
          const varianceTon = Number((realizedTon - expectedTon).toFixed(1));
          const variancePct =
            expectedTon > 0 ? Math.round(((realizedTon - expectedTon) / expectedTon) * 100) : 0;
          const completionPct =
            expectedTon > 0 ? Math.min(100, Math.round((realizedTon / expectedTon) * 100)) : 0;

          return {
            name: `Hf-${idx + 1}: ${p.label}`,
            shortName: p.label,
            subtitle: `Ort. ${avgWk}. Hafta`,
            BeklenenTon: expectedTon,
            GerceklesenTon: realizedTon,
            Cycle11WeekTrendTon: cycle11BenchmarkTon,
            OctNovProgressTon: showOctNovProgress ? octNovTon : 0,
            VarianceTon: varianceTon,
            VariancePct: variancePct,
            completionPct,
            avgWeek: avgWk,
            cohortCount: p.count,
            ribbonHex: p.ribbonHex
          };
        });
    }

    // BY_SERA
    return BANANA_GREENHOUSES_2027.map(gh => {
      const items = filteredCohorts.filter(c => c.greenhouseName === gh.name);
      const expectedTon = Number((items.reduce((s, i) => s + i.expectedKg, 0) / 1000).toFixed(1));
      const realizedTon = Number((items.reduce((s, i) => s + i.realizedKg, 0) / 1000).toFixed(1));
      const octNovTon = Number(
        (
          items
            .filter(i => i.isOctNovSeasonal)
            .reduce((s, i) => s + (i.realizedKg || i.expectedKg), 0) / 1000
        ).toFixed(1)
      );
      const avgWeek =
        items.length > 0
          ? Number((items.reduce((s, i) => s + i.maturationWeeks, 0) / items.length).toFixed(1))
          : 11.0;
      const cycle11BenchmarkTon = Number(
        (expectedTon * Math.min(1.02, 11.0 / Math.max(10.5, avgWeek))).toFixed(1)
      );
      const varianceTon = Number((realizedTon - expectedTon).toFixed(1));
      const variancePct =
        expectedTon > 0 ? Math.round(((realizedTon - expectedTon) / expectedTon) * 100) : 0;
      const completionPct =
        expectedTon > 0 ? Math.min(100, Math.round((realizedTon / expectedTon) * 100)) : 0;

      return {
        name: gh.name,
        shortName: gh.name,
        subtitle: GREENHOUSE_VARIETY_MAP[gh.name] || 'Cavendish',
        BeklenenTon: expectedTon,
        GerceklesenTon: realizedTon,
        Cycle11WeekTrendTon: cycle11BenchmarkTon,
        OctNovProgressTon: showOctNovProgress ? octNovTon : 0,
        VarianceTon: varianceTon,
        VariancePct: variancePct,
        completionPct,
        avgWeek,
        cohortCount: items.length,
        ribbonHex: items[0]?.ribbonHex || '#10b981'
      };
    }).filter(d => d.BeklenenTon > 0 || d.GerceklesenTon > 0);
  }, [filteredCohorts, forecastAxisMode, showOctNovProgress]);

  // Forecast KPI Totals
  const forecastTotals = useMemo(() => {
    const totalExp = Number(
      (filteredCohorts.reduce((s, c) => s + c.expectedKg, 0) / 1000).toFixed(1)
    );
    const totalReal = Number(
      (filteredCohorts.reduce((s, c) => s + c.realizedKg, 0) / 1000).toFixed(1)
    );
    const varianceTon = Number((totalReal - totalExp).toFixed(1));
    const variancePct = totalExp > 0 ? Math.round(((totalReal - totalExp) / totalExp) * 100) : 0;
    const avgCycleWeek =
      filteredCohorts.length > 0
        ? Number(
            (
              filteredCohorts.reduce((s, c) => s + c.maturationWeeks, 0) / filteredCohorts.length
            ).toFixed(1)
          )
        : 11.0;
    return { totalExp, totalReal, varianceTon, variancePct, avgCycleWeek };
  }, [filteredCohorts]);

  // ============================================================================
  // 2. HARVEST DELAY ANALYSIS VIEW (SERA LOCATIONS & HARVEST WEEKS SORTED BY
  //    HARVEST FREQUENCY TO IDENTIFY PEAK-LOAD WEEKS FOR MANUAL LABOR PLANNING)
  // ============================================================================
  const harvestDelayAnalysisData = useMemo(() => {
    const map = new Map<
      string,
      {
        greenhouseName: string;
        variety: string;
        harvestWeek: number;
        frequency: number;
        totalBoundBunches: number;
        expectedKg: number;
        realizedKg: number;
        dominantRibbonColor: string;
        dominantRibbonHex: string;
        periods: string[];
      }
    >();

    filteredCohorts.forEach(c => {
      const key = `${c.greenhouseName}__W${c.harvestWeekInt}`;
      const existing = map.get(key) || {
        greenhouseName: c.greenhouseName,
        variety: c.variety,
        harvestWeek: c.harvestWeekInt,
        frequency: 0,
        totalBoundBunches: 0,
        expectedKg: 0,
        realizedKg: 0,
        dominantRibbonColor: c.ribbonColorName,
        dominantRibbonHex: c.ribbonHex,
        periods: []
      };
      existing.frequency += 1;
      existing.totalBoundBunches += c.boundBunches;
      existing.expectedKg += c.expectedKg;
      existing.realizedKg += c.realizedKg;
      if (existing.periods.length < 3 && !existing.periods.includes(c.periodLabel)) {
        existing.periods.push(c.periodLabel);
      }
      map.set(key, existing);
    });

    const rows: SeraHarvestDelayFrequencyRow[] = Array.from(map.values()).map(item => {
      const delayWeeksOver11 = Math.max(0, item.harvestWeek - 11);
      const expectedTons = Number((item.expectedKg / 1000).toFixed(1));
      const realizedTons = Number((item.realizedKg / 1000).toFixed(1));
      const varianceTons = Number((realizedTons - expectedTons).toFixed(1));

      // Manual labor calculation: ~1 worker per 3.2 tons or 100 bunches in a peak harvest week + extra for delayed heavy bunches
      const baseWorkers = Math.max(
        2,
        Math.ceil(item.totalBoundBunches / 110) + Math.floor(item.frequency * 1.5)
      );
      const delayPenaltyWorkers = delayWeeksOver11 > 0 ? Math.ceil(delayWeeksOver11 * 1.5) : 0;
      const estimatedWorkersNeeded = baseWorkers + delayPenaltyWorkers;
      const estimatedCrewsNeeded = Math.max(1, Math.ceil(estimatedWorkersNeeded / 5));

      let laborIntensityLevel: SeraHarvestDelayFrequencyRow['laborIntensityLevel'] = 'STANDARD';
      if (item.frequency >= 6 || estimatedWorkersNeeded >= 18) {
        laborIntensityLevel = 'PEAK_CRITICAL';
      } else if (item.frequency >= 4 || estimatedWorkersNeeded >= 12) {
        laborIntensityLevel = 'HIGH_LOAD';
      } else if (item.frequency >= 2 || delayWeeksOver11 >= 1) {
        laborIntensityLevel = 'MODERATE_LOAD';
      }

      const delayStatusLabel =
        item.harvestWeek < 11
          ? 'Erken / 10. Hafta Kesim'
          : item.harvestWeek === 11
            ? '11. Hafta — İdeal Döngü (Gecikmesiz)'
            : `+${delayWeeksOver11} Hafta Gecikmiş (${item.harvestWeek}. Hafta Kesimi)`;

      return {
        id: `${item.greenhouseName}-W${item.harvestWeek}`,
        greenhouseName: item.greenhouseName,
        variety: item.variety,
        harvestWeek: item.harvestWeek,
        harvestWeekLabel:
          item.harvestWeek >= 15 ? '15+ Hafta' : `${item.harvestWeek}. Hafta`,
        harvestFrequency: item.frequency,
        delayWeeksOver11,
        delayStatusLabel,
        totalBoundBunches: item.totalBoundBunches,
        expectedTons,
        realizedTons,
        varianceTons,
        estimatedWorkersNeeded,
        estimatedCrewsNeeded,
        laborIntensityLevel,
        dominantRibbonColor: item.dominantRibbonColor,
        dominantRibbonHex: item.dominantRibbonHex,
        periodSamples: item.periods
      };
    });

    // Sort according to user selection (default: by harvest frequency descending to identify peak-load weeks)
    rows.sort((a, b) => {
      if (delaySortBy === 'FREQUENCY_DESC') {
        if (b.harvestFrequency !== a.harvestFrequency) {
          return b.harvestFrequency - a.harvestFrequency;
        }
        return b.expectedTons - a.expectedTons;
      }
      if (delaySortBy === 'DELAY_WEEK_DESC') {
        if (b.harvestWeek !== a.harvestWeek) {
          return b.harvestWeek - a.harvestWeek;
        }
        return b.harvestFrequency - a.harvestFrequency;
      }
      if (delaySortBy === 'LABOR_DESC') {
        if (b.estimatedWorkersNeeded !== a.estimatedWorkersNeeded) {
          return b.estimatedWorkersNeeded - a.estimatedWorkersNeeded;
        }
        return b.harvestFrequency - a.harvestFrequency;
      }
      return a.greenhouseName.localeCompare(b.greenhouseName) || b.harvestFrequency - a.harvestFrequency;
    });

    // Aggregate by Harvest Week across all seras to highlight top peak-load weeks
    const weekPeakMap = new Map<
      number,
      {
        weekNum: number;
        totalFrequency: number;
        totalWorkers: number;
        totalTons: number;
        seraList: string[];
      }
    >();

    rows.forEach(r => {
      const cur = weekPeakMap.get(r.harvestWeek) || {
        weekNum: r.harvestWeek,
        totalFrequency: 0,
        totalWorkers: 0,
        totalTons: 0,
        seraList: []
      };
      cur.totalFrequency += r.harvestFrequency;
      cur.totalWorkers += r.estimatedWorkersNeeded;
      cur.totalTons += r.expectedTons;
      if (!cur.seraList.includes(r.greenhouseName)) {
        cur.seraList.push(r.greenhouseName);
      }
      weekPeakMap.set(r.harvestWeek, cur);
    });

    const peakWeeksRanked = Array.from(weekPeakMap.values()).sort(
      (a, b) => b.totalFrequency - a.totalFrequency
    );

    return {
      rows,
      peakWeeksRanked,
      topPeakWeek: peakWeeksRanked[0] || null,
      secondPeakWeek: peakWeeksRanked[1] || null
    };
  }, [filteredCohorts, delaySortBy]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-6">
      {/* ===================================================================== */}
      {/* 1. TOP HEADER, SUB-VIEW SWITCHER & GLOBAL FILTERS                      */}
      {/* ===================================================================== */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-semibold">
            <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-black">
              Harvest Forecasting &amp; Delay Analysis
            </span>
            <span aria-hidden="true">·</span>
            <span>Haftalık Beklenen vs. Gerçekleşen (ComposedChart)</span>
            <span aria-hidden="true">·</span>
            <span className="text-rose-700 font-bold">
              Sera × Hafta Hasat Yoğunluğu Planlama
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2 mt-1">
            <BarChart3 className="w-5 h-5 text-emerald-600" />
            <span>
              Harvest Forecasting (11-Hafta Döngü Trendi) &amp; Harvest Delay Analysis (İşgücü Yoğunluk Sıralaması)
            </span>
          </h3>
        </div>

        {/* SUB-VIEW MODE PILLS */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveViewMode('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition cursor-pointer ${
              activeViewMode === 'ALL'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            📊 Tümünü Göster (Forecasting + Delay Analysis)
          </button>
          <button
            type="button"
            onClick={() => setActiveViewMode('HARVEST_FORECASTING')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition cursor-pointer ${
              activeViewMode === 'HARVEST_FORECASTING'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            📈 Harvest Forecasting (ComposedChart)
          </button>
          <button
            type="button"
            onClick={() => setActiveViewMode('HARVEST_DELAY_ANALYSIS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition cursor-pointer ${
              activeViewMode === 'HARVEST_DELAY_ANALYSIS'
                ? 'bg-rose-600 text-white shadow-2xs'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            ⏱️ Hasat Gecikmesi &amp; Yoğunluk Analizi
          </button>
        </div>
      </div>

      {/* GLOBAL FILTER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-2">
          {/* Date Range Filter */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              className="bg-transparent font-mono text-xs font-bold text-slate-800 outline-none"
              title="Başlangıç Tarihi"
            />
            <span className="text-slate-400">→</span>
            <input
              type="date"
              value={endDate}
              onChange={e => setEndDate(e.target.value)}
              className="bg-transparent font-mono text-xs font-bold text-slate-800 outline-none"
              title="Bitiş Tarihi"
            />
          </div>

          {/* Variety Filter */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-amber-600" />
            <select
              value={selectedVariety}
              onChange={e => setSelectedVariety(e.target.value)}
              className="bg-transparent font-bold text-slate-800 outline-none cursor-pointer"
            >
              {BANANA_VARIETY_OPTIONS.map(v => (
                <option key={v} value={v}>
                  {v === 'ALL' ? 'Tüm Çeşitler (Variety)' : v}
                </option>
              ))}
            </select>
          </div>

          {/* Greenhouse Filter */}
          <select
            value={selectedGreenhouse}
            onChange={e => setSelectedGreenhouse(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 cursor-pointer"
          >
            <option value="ALL">Tüm Seralar (7 Sera Lokasyonu)</option>
            {BANANA_GREENHOUSES_2027.map(gh => (
              <option key={gh.name} value={gh.name}>
                {gh.name}
              </option>
            ))}
          </select>
        </div>

        {/* TOGGLES: 11-WEEK HARVEST CYCLE TREND LINE + OCT-NOV SEASONAL PROGRESS */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShow11WeekCycleTrend(prev => !prev)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
              show11WeekCycleTrend
                ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>
              {show11WeekCycleTrend
                ? '📈 11-Hafta Döngü Trend Çizgisi: AÇIK'
                : '📈 11-Hafta Döngü Trend Çizgisi: KAPALI'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowOctNovProgress(prev => !prev)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
              showOctNovProgress
                ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            {showOctNovProgress ? (
              <Eye className="w-3.5 h-3.5" />
            ) : (
              <EyeOff className="w-3.5 h-3.5" />
            )}
            <span>
              {showOctNovProgress
                ? '🍂 Ekim–Kasım İlerlemesi: AÇIK'
                : '🍂 Ekim–Kasım İlerlemesi: GİZLİ'}
            </span>
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* SECTION A: HARVEST FORECASTING (RECHARTS COMPOSEDCHART + 11-WEEK TREND)*/}
      {/* ===================================================================== */}
      {(activeViewMode === 'ALL' || activeViewMode === 'HARVEST_FORECASTING') && (
        <div className="space-y-4">
          {/* Forecasting Header & X-Axis Grouping Switcher */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 bg-gradient-to-r from-emerald-50/80 via-white to-indigo-50/70 p-3.5 rounded-2xl border border-emerald-200">
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase text-emerald-800">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>Harvest Forecasting — Haftalık Beklenen vs. Gerçekleşen Çıktı &amp; 11-Hafta Döngü Sapması</span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Recharts <strong>ComposedChart</strong> üzerinde haftalık <strong>Beklenen (Expected)</strong> ve{' '}
                <strong>Gerçekleşen (Realized)</strong> tonajlar ile <strong>11-Hafta Hasat Döngüsü Trend Çizgisi</strong> karşılaştırması.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setForecastAxisMode('BY_CYCLE_WEEK')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  forecastAxisMode === 'BY_CYCLE_WEEK'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                ⏱️ Hasat Haftasına Göre (10. Hf – 15+ Hf)
              </button>
              <button
                type="button"
                onClick={() => setForecastAxisMode('BY_CALENDAR_WEEK')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  forecastAxisMode === 'BY_CALENDAR_WEEK'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                📅 Takvim Dönem Haftasına Göre
              </button>
              <button
                type="button"
                onClick={() => setForecastAxisMode('BY_SERA')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  forecastAxisMode === 'BY_SERA'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                🏠 7 Sera Lokasyonuna Göre
              </button>
            </div>
          </div>

          {/* 4 Forecasting Summary KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/70">
              <span className="text-[10px] font-black uppercase text-slate-500 block">
                BEKLENEN HASAT (EXPECTED)
              </span>
              <span className="text-xl font-black text-slate-900 font-mono">
                {forecastTotals.totalExp.toLocaleString('tr-TR')} Ton
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                {filteredCohorts.length} kurdele partisi toplamı
              </span>
            </div>

            <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50/50">
              <span className="text-[10px] font-black uppercase text-emerald-800 block">
                GERÇEKLEŞEN HASAT (REALIZED)
              </span>
              <span className="text-xl font-black text-emerald-950 font-mono">
                {forecastTotals.totalReal.toLocaleString('tr-TR')} Ton
              </span>
              <span className="text-[11px] text-emerald-700 font-semibold block mt-0.5">
                Delilnama + Kantar Net Çıktı
              </span>
            </div>

            <div
              className={`p-3 rounded-xl border ${
                forecastTotals.varianceTon >= 0
                  ? 'border-teal-200 bg-teal-50/50'
                  : 'border-rose-200 bg-rose-50/50'
              }`}
            >
              <span className="text-[10px] font-black uppercase text-slate-700 block">
                ÇIKTI SAPMASI (VARIANCE)
              </span>
              <span
                className={`text-xl font-black font-mono ${
                  forecastTotals.varianceTon >= 0 ? 'text-teal-900' : 'text-rose-900'
                }`}
              >
                {forecastTotals.varianceTon > 0 ? `+${forecastTotals.varianceTon}` : forecastTotals.varianceTon}{' '}
                Ton ({forecastTotals.variancePct > 0 ? `+${forecastTotals.variancePct}` : forecastTotals.variancePct}%)
              </span>
              <span className="text-[11px] text-slate-600 block mt-0.5">
                Beklenen vs. Gerçekleşen Farkı
              </span>
            </div>

            <div className="p-3 rounded-xl border border-indigo-200 bg-indigo-50/50">
              <span className="text-[10px] font-black uppercase text-indigo-800 block">
                11-HAFTA DÖNGÜ ORTALAMASI
              </span>
              <span className="text-xl font-black text-indigo-950 font-mono">
                {forecastTotals.avgCycleWeek}. Hafta
              </span>
              <span className="text-[11px] text-indigo-700 font-semibold block mt-0.5">
                Hedef: 11.0 Hafta (Sapma: +{(forecastTotals.avgCycleWeek - 11).toFixed(1)} Hf)
              </span>
            </div>
          </div>

          {/* Main Visualization Grid: Left 7 Cols = Recharts ComposedChart, Right 5 Cols = Gantt Visual Progress */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
            {/* Left 7 Cols: Recharts ComposedChart */}
            <div className="xl:col-span-7 bg-slate-50/60 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div>
                  <span className="text-xs font-black text-slate-900 uppercase tracking-wide block">
                    Haftalık Beklenen vs. Gerçekleşen Hasat &amp; 11-Hafta Döngü Trendi (ComposedChart)
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Çubuklar: Beklenen &amp; Gerçekleşen (Ton) · Çizgi: 11-Hafta Döngü Trendi &amp; Sapma (%)
                  </span>
                </div>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-900 font-bold">
                  {show11WeekCycleTrend ? '11-Hf Trend: Aktif' : '11-Hf Trend: Gizli'}
                </span>
              </div>

              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart
                    data={weeklyForecastComposedData}
                    margin={{ top: 12, right: 16, left: -8, bottom: 16 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: '#1e293b', fontSize: 10, fontWeight: 700 }}
                    />
                    <YAxis
                      yAxisId="left"
                      tick={{ fill: '#475569', fontSize: 11 }}
                      unit=" T"
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      tick={{ fill: '#4f46e5', fontSize: 10 }}
                      unit="%"
                      domain={[-100, 40]}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#cbd5e1',
                        borderRadius: '12px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />

                    {forecastAxisMode === 'BY_CYCLE_WEEK' && (
                      <ReferenceLine
                        yAxisId="left"
                        x="11. Hafta (İdeal Döngü)"
                        stroke="#059669"
                        strokeWidth={2}
                        strokeDasharray="4 4"
                        label={{
                          value: '11. Hafta İdeal Kesim',
                          position: 'top',
                          fill: '#059669',
                          fontSize: 10,
                          fontWeight: 800
                        }}
                      />
                    )}

                    <Bar
                      yAxisId="left"
                      dataKey="BeklenenTon"
                      name="Beklenen Hasat (Expected Ton)"
                      fill="#94a3b8"
                      radius={[6, 6, 0, 0]}
                    >
                      {weeklyForecastComposedData.map((entry, idx) => (
                        <Cell
                          key={`exp-cell-${idx}`}
                          fill={showOctNovProgress ? entry.ribbonHex : '#94a3b8'}
                          fillOpacity={0.55}
                        />
                      ))}
                    </Bar>

                    <Bar
                      yAxisId="left"
                      dataKey="GerceklesenTon"
                      name="Gerçekleşen Hasat (Realized Ton)"
                      fill="#10b981"
                      radius={[6, 6, 0, 0]}
                    />

                    {showOctNovProgress && (
                      <Bar
                        yAxisId="left"
                        dataKey="OctNovProgressTon"
                        name="🍂 Ekim–Kasım Sezon İlerlemesi (Ton)"
                        fill="#f97316"
                        radius={[6, 6, 0, 0]}
                      />
                    )}

                    {show11WeekCycleTrend && (
                      <Area
                        yAxisId="left"
                        type="monotone"
                        dataKey="Cycle11WeekTrendTon"
                        name="11-Hafta Döngü Hedef Trend Çizgisi (Ton)"
                        stroke="#4f46e5"
                        strokeWidth={3}
                        fill="#6366f1"
                        fillOpacity={0.12}
                        dot={{ r: 4, fill: '#4f46e5', strokeWidth: 2, stroke: '#ffffff' }}
                      />
                    )}

                    {show11WeekCycleTrend && (
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="VariancePct"
                        name="Beklenen vs. Gerçekleşen Sapma (Variance %)"
                        stroke="#e11d48"
                        strokeWidth={2.2}
                        strokeDasharray="5 3"
                        dot={{ r: 3.5, fill: '#e11d48' }}
                      />
                    )}
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Right 5 Cols: Gantt-Style Visual Progress Strips */}
            <div className="xl:col-span-5 bg-slate-50/60 border border-slate-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-amber-600" />
                    <span>Görsel Hasat İlerleme Çubukları (Gantt Özeti)</span>
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Sayısal kalabalık olmadan beklenen vs. gerçekleşen ilerleme ve sapma oranı
                  </p>
                </div>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {weeklyForecastComposedData.map(row => {
                  const barWidth = Math.min(100, Math.max(8, row.completionPct));
                  const isOver11 = row.avgWeek > 11.2;
                  return (
                    <div
                      key={row.name}
                      className="bg-white p-2.5 rounded-xl border border-slate-200 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="w-3.5 h-3.5 rounded-full border border-slate-300 shrink-0"
                            style={{ backgroundColor: row.ribbonHex }}
                          />
                          <span className="font-black text-slate-900 truncate">{row.name}</span>
                          <span className="text-[10px] text-slate-500 truncate">{row.subtitle}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] shrink-0">
                          <span
                            className={`font-bold ${
                              isOver11 ? 'text-rose-600' : 'text-emerald-700'
                            }`}
                          >
                            {row.VarianceTon >= 0 ? `+${row.VarianceTon}T` : `${row.VarianceTon}T`}
                          </span>
                          <span className="font-mono font-black text-slate-900">
                            %{row.completionPct}
                          </span>
                        </div>
                      </div>

                      <div className="relative h-4 w-full bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-slate-900/40 z-10"
                          style={{ left: '78%' }}
                          title="11. Hafta Hasat Eşiği"
                        />
                        <div
                          className="h-full rounded-r-md transition-all flex items-center justify-end pr-2 text-[9px] font-black text-white"
                          style={{
                            width: `${barWidth}%`,
                            backgroundColor: showOctNovProgress ? row.ribbonHex : '#10b981'
                          }}
                        >
                          {barWidth >= 25 ? `${row.GerceklesenTon}T / ${row.BeklenenTon}T` : ''}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION B: HARVEST DELAY ANALYSIS VIEW (SERA LOCATIONS & HARVEST WEEKS*/}
      {/*            SORTED BY HARVEST FREQUENCY FOR MANUAL LABOR PLANNING)      */}
      {/* ===================================================================== */}
      {(activeViewMode === 'ALL' || activeViewMode === 'HARVEST_DELAY_ANALYSIS') && (
        <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 space-y-4 border border-slate-800">
          {/* Header & Sort Controls */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-black uppercase tracking-wider mb-1">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>Harvest Delay Analysis · Peak-Load Haftalar &amp; Manuel İşgücü Planlaması</span>
              </div>
              <h4 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                <span>
                  Sera Lokasyonları &amp; Hasat Haftaları — Hasat Sıklığına (Frequency) Göre Sıralı İşgücü Tablosu
                </span>
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                En çok hangi haftalarda hasat yığılması (peak-load) oluştuğunu ve hangi serada kaç kişilik kesim/taşıma ekibi gerektiğini gösterir.
              </p>
            </div>

            {/* Sort By Selector */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs">
                <ArrowUpDown className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-slate-300 font-semibold">Sıralama:</span>
                <select
                  value={delaySortBy}
                  onChange={e => setDelaySortBy(e.target.value as any)}
                  className="bg-transparent text-amber-300 font-black outline-none cursor-pointer"
                >
                  <option value="FREQUENCY_DESC" className="bg-slate-900 text-white">
                    🔥 Hasat Sıklığına Göre (En Yoğun Peak-Load Üstte)
                  </option>
                  <option value="LABOR_DESC" className="bg-slate-900 text-white">
                    👷 Gereken Manuel İşgücüne Göre (İşçi Sayısı Azalan)
                  </option>
                  <option value="DELAY_WEEK_DESC" className="bg-slate-900 text-white">
                    ⏰ Hasat Haftasına Göre (15. Hf ➔ 10. Hf Gecikme)
                  </option>
                  <option value="SERA_ASC" className="bg-slate-900 text-white">
                    🏠 Sera Lokasyonuna Göre (A–Z)
                  </option>
                </select>
              </div>
            </div>
          </div>

          {/* Peak-Load Weeks Banner (Top 4 Peak Harvest Weeks for Manual Labor Planning) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            {harvestDelayAnalysisData.peakWeeksRanked.slice(0, 4).map((pw, idx) => (
              <div
                key={pw.weekNum}
                className={`p-3.5 rounded-xl border ${
                  idx === 0
                    ? 'bg-rose-950/80 border-rose-500/60 ring-1 ring-rose-400/40'
                    : idx === 1
                      ? 'bg-amber-950/70 border-amber-500/50'
                      : 'bg-slate-800/90 border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2 py-0.5 rounded bg-white/10 font-mono font-black text-amber-300">
                    #{idx + 1} PEAK HAFTA: {pw.weekNum}. HAFTA
                  </span>
                  <span className="text-[11px] font-mono font-bold text-emerald-300">
                    Sıklık: {pw.totalFrequency} Parti
                  </span>
                </div>

                <div className="mt-2 flex items-baseline justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">
                      Toplam İşgücü İhtiyacı
                    </span>
                    <span className="text-lg font-black text-white font-mono">
                      {pw.totalWorkers} İşçi / Gün
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block uppercase">Yük Tonajı</span>
                    <span className="text-sm font-black text-amber-300 font-mono">
                      {pw.totalTons.toFixed(1)} Ton
                    </span>
                  </div>
                </div>

                <div className="mt-2 text-[11px] text-slate-300 truncate">
                  Seralar: <strong className="text-white">{pw.seraList.join(', ')}</strong>
                </div>
              </div>
            ))}
          </div>

          {/* Sera Locations & Harvest Weeks Table Sorted by Harvest Frequency */}
          <div className="bg-slate-950/70 rounded-xl border border-slate-800 overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-800/90 text-slate-200 border-b border-slate-700 text-[11px]">
                  <th className="py-2.5 px-3 font-black">#</th>
                  <th className="py-2.5 px-3 font-black">Sera Lokasyonu &amp; Çeşit</th>
                  <th className="py-2.5 px-3 font-black text-center">Hasat Haftası</th>
                  <th className="py-2.5 px-3 font-black text-center bg-amber-500/15 text-amber-300">
                    Hasat Sıklığı (Frequency)
                  </th>
                  <th className="py-2.5 px-3 font-black">11-Hafta Gecikme Durumu</th>
                  <th className="py-2.5 px-3 font-black text-right">Bağlanan Dal &amp; Beklenen Ton</th>
                  <th className="py-2.5 px-3 font-black text-center bg-emerald-500/15 text-emerald-300">
                    Manuel İşgücü Planı (İşçi / Ekip)
                  </th>
                  <th className="py-2.5 px-3 font-black text-center">Peak-Load Seviyesi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {harvestDelayAnalysisData.rows.map((row, index) => {
                  const maxFreq = Math.max(
                    1,
                    harvestDelayAnalysisData.rows[0]?.harvestFrequency || 1
                  );
                  const freqPct = Math.min(100, Math.round((row.harvestFrequency / maxFreq) * 100));

                  return (
                    <tr
                      key={row.id}
                      onClick={() =>
                        setSelectedGreenhouse(
                          selectedGreenhouse === row.greenhouseName ? 'ALL' : row.greenhouseName
                        )
                      }
                      className="hover:bg-slate-800/60 transition cursor-pointer"
                    >
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-400">
                        {index + 1}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full shrink-0 border border-white/60"
                            style={{ backgroundColor: row.dominantRibbonHex }}
                          />
                          <div>
                            <div className="font-black text-white">{row.greenhouseName}</div>
                            <div className="text-[10px] text-slate-400">{row.variety}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-lg font-mono font-black text-xs ${
                            row.harvestWeek > 11
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              : row.harvestWeek === 11
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                          }`}
                        >
                          {row.harvestWeekLabel}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 bg-amber-500/5">
                        <div className="flex flex-col items-center gap-1">
                          <span className="font-mono font-black text-amber-300 text-xs">
                            {row.harvestFrequency} Kez / Dönem
                          </span>
                          <div className="w-24 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                            <div
                              className="h-full bg-amber-400 rounded-full"
                              style={{ width: `${freqPct}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`text-xs font-bold ${
                            row.delayWeeksOver11 > 0
                              ? 'text-rose-300'
                              : row.harvestWeek === 11
                                ? 'text-emerald-300'
                                : 'text-sky-300'
                          }`}
                        >
                          {row.delayStatusLabel}
                        </span>
                        <div className="text-[10px] text-slate-400 truncate max-w-[210px]">
                          Dönem: {row.periodSamples.join(', ')}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono">
                        <div className="font-black text-white">
                          {row.totalBoundBunches.toLocaleString('tr-TR')} dal
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Beklenen: {row.expectedTons}T · Gerçek: {row.realizedTons}T
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center bg-emerald-500/5">
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 font-mono font-black">
                          <Users className="w-3.5 h-3.5 text-emerald-300" />
                          <span>
                            {row.estimatedWorkersNeeded} İşçi ({row.estimatedCrewsNeeded} Ekip)
                          </span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        {row.laborIntensityLevel === 'PEAK_CRITICAL' ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/30 border border-rose-400 text-rose-200 text-[10px] font-black uppercase">
                            🔥 Peak-Load (Kritik İşgücü)
                          </span>
                        ) : row.laborIntensityLevel === 'HIGH_LOAD' ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/30 border border-amber-400 text-amber-200 text-[10px] font-black uppercase">
                            ⚡ Yüksek İşgücü
                          </span>
                        ) : row.laborIntensityLevel === 'MODERATE_LOAD' ? (
                          <span className="px-2 py-0.5 rounded-full bg-sky-500/30 border border-sky-400 text-sky-200 text-[10px] font-bold uppercase">
                            Orta Yük
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-[10px] font-bold uppercase">
                            Standart
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
