import React, { useState, useMemo } from 'react';
import {
  MUZ_TOPLAM_EXACT_ROWS,
  MuzToplamExactRow,
  BananaSectorRibbonRecord
} from '../../data/bananaRibbonData';
import {
  BANANA_GREENHOUSES_2027,
  BANANA_12_MONTH_COLORS_2027,
  normalizeBananaGreenhouseName
} from '../../data/banana2027Data';
import {
  resolveToplamPeriodNetDates,
  getRibbonColorMeta,
  buildSectorHorizontalMatrix
} from '../../data/bananaToplamCalendarAdapter';
import {
  DELILNAMA_2026_BY_TOPLAM_PERIOD_ID,
  DELILNAMA_BANAN_2026_SHEET_URL
} from '../../data/delilnamaBanan2026Data';
import type { BananaContinuityRow } from './BananaRibbonCalendarHub';
import {
  Layers,
  RefreshCw,
  FileSpreadsheet,
  ExternalLink,
  PlusCircle,
  CheckCircle2
} from 'lucide-react';

interface BananaToplamSectorAndQualityViewsProps {
  activeSubMode: 'TOPLAM_SHEET_TABLE' | 'SECTOR_1_TO_7_VIEW';
  calendarRows: BananaContinuityRow[];
  sectorRecords: BananaSectorRibbonRecord[];
  selectedGreenhouse: string;
  onSyncSectorsFromSheets: () => void;
  isSyncingSectors?: boolean;
}

const CUSTOM_TOPLAM_OVERRIDES_KEY = 'OBA_MUZ_TOPLAM_ACTUAL_OVERRIDES_V1';

interface ToplamPeriodOverride {
  customActualKg?: number;
  customRibbonColor?: string;
  customActualHarvestDate?: string;
}

export const BananaToplamSectorAndQualityViews: React.FC<BananaToplamSectorAndQualityViewsProps> = ({
  activeSubMode,
  calendarRows,
  sectorRecords,
  selectedGreenhouse,
  onSyncSectorsFromSheets,
  isSyncingSectors = false
}) => {
  const [selectedNumberedTab, setSelectedNumberedTab] = useState<string>('ALL');
  const [showSummaryRowsInToplam, setShowSummaryRowsInToplam] = useState<boolean>(false);

  // Kullanıcının Toplam tablosunda doğrudan yazabileceği Gerçekleşen Hasat Kg ve Ekim/Kasım Kurdele Rengi & Hasat Tarihi
  const [periodOverrides, setPeriodOverrides] = useState<Record<string, ToplamPeriodOverride>>(() => {
    try {
      const saved = localStorage.getItem(CUSTOM_TOPLAM_OVERRIDES_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {};
  });

  const updatePeriodOverride = (periodId: string, patch: Partial<ToplamPeriodOverride>) => {
    setPeriodOverrides(prev => {
      const next = {
        ...prev,
        [periodId]: {
          ...(prev[periodId] || {}),
          ...patch
        }
      };
      try {
        localStorage.setItem(CUSTOM_TOPLAM_OVERRIDES_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // 1. G.Sheet 'Toplam' Sayfası Tarih Sıralı Dönem Satırları
  const toplamDisplayRows = useMemo(() => {
    return MUZ_TOPLAM_EXACT_ROWS.filter(r =>
      showSummaryRowsInToplam ? true : r.rowType === 'PERIOD'
    );
  }, [showSummaryRowsInToplam]);

  // Toplam Beklenen vs Delilnama Gerçekleşen Özet KPI
  const toplamComparisonKpi = useMemo(() => {
    const periods = MUZ_TOPLAM_EXACT_ROWS.filter(r => r.rowType === 'PERIOD');
    let expectedTotalKg = 0;
    let actualTotalKg = 0;
    let harvestedPeriodsCount = 0;

    periods.forEach(r => {
      const exp = r.tahmKg32 || (r.toplam ? r.toplam * 32 : 0);
      const delil = DELILNAMA_2026_BY_TOPLAM_PERIOD_ID[r.id];
      const ov = periodOverrides[r.id];
      const act =
        ov?.customActualKg !== undefined
          ? ov.customActualKg
          : r.gercekKilo && r.gercekKilo > 0
          ? r.gercekKilo
          : delil?.totalDelilnamaKg || 0;

      expectedTotalKg += exp;
      if (act > 0) {
        actualTotalKg += act;
        harvestedPeriodsCount++;
      }
    });

    return {
      expectedTotalTon: Number((expectedTotalKg / 1000).toFixed(1)),
      actualTotalTon: Number((actualTotalKg / 1000).toFixed(1)),
      harvestedPeriodsCount
    };
  }, [periodOverrides]);

  // 2. 1..7 Sera Sekmeleri ('1.Gkblt-5-6' .. '7.Hmsy-5') Sektör 1..8 Yatay Matrisi
  const sectorMatrixRows = useMemo(() => {
    const all = buildSectorHorizontalMatrix(sectorRecords);
    return all.filter(row => {
      if (
        selectedGreenhouse !== 'ALL' &&
        normalizeBananaGreenhouseName(row.greenhouseName) !==
          normalizeBananaGreenhouseName(selectedGreenhouse)
      ) {
        return false;
      }
      if (selectedNumberedTab !== 'ALL' && row.sheetTab !== selectedNumberedTab) {
        return false;
      }
      return true;
    });
  }, [sectorRecords, selectedGreenhouse, selectedNumberedTab]);

  if (activeSubMode === 'TOPLAM_SHEET_TABLE') {
    return (
      <div className="bg-white border border-amber-300 rounded-2xl shadow-sm overflow-hidden space-y-3 p-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 text-[10px] font-black uppercase mb-1">
              ⚖️ Delilnama "Banan 2026" (gid=167224735) Kantar Sonuçları İle Eşleştirilmiş Tablo
            </div>
            <h3 className="text-xs sm:text-sm font-black text-slate-900 uppercase flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>
                Muz Kurdele Google Sheet "Toplam" Sayfası — Net Tarih Sıralı Hasat & Ağaç Tablosu (Yazılabilir Gerçekleşen Hasat)
              </span>
            </h3>
            <p className="text-[11px] text-slate-600 mt-0.5">
              Delilnama 2026 fişlerinde kurdele rengi yazmadığı için <strong>Kasım / Ekim kurdele bağlama dönemlerinden</strong> itibaren bağlanan renklere göre <strong>Beklenen Hasat (Tahm. Kg 32)</strong> ile <strong>Delilnama Gerçekleşen Hasat (Agram, kg)</strong> karşılaştırılmıştır. Ekim/Kasım ve sonrası için kurdele rengi, gerçekleşen kg ve hasat tarihi doğrudan satır içinde yazılıp güncellenebilir; sistem <strong>Hasat Haftasını ve Gecikmeyi</strong> otomatik hesaplar.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-300 text-xs font-mono">
              <span className="text-slate-600">Beklenen Toplam:</span>{' '}
              <strong className="text-amber-950 font-black">{toplamComparisonKpi.expectedTotalTon} Ton</strong>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-300 text-xs font-mono">
              <span className="text-slate-600">Gerçekleşen (Delilnama):</span>{' '}
              <strong className="text-emerald-900 font-black">{toplamComparisonKpi.actualTotalTon} Ton</strong>
            </div>
            <a
              href={DELILNAMA_BANAN_2026_SHEET_URL}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 text-xs font-bold inline-flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5 text-sky-600" />
              <span>Delilnama Banan 2026</span>
            </a>
            <label className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-300">
              <input
                type="checkbox"
                checked={showSummaryRowsInToplam}
                onChange={e => setShowSummaryRowsInToplam(e.target.checked)}
                className="accent-amber-600"
              />
              <span>Aylık Toplam Satırları</span>
            </label>
          </div>
        </div>

        <div className="overflow-x-auto max-h-[620px]">
          <table className="w-full text-left text-[11px] border-collapse">
            <thead className="bg-slate-100 text-slate-800 sticky top-0 z-10 border-b border-slate-300">
              <tr>
                <th className="p-2 border-r border-slate-200 font-black">Net Bağlama Tarihi</th>
                <th className="p-2 border-r border-slate-200 font-black">Dönem (Sene)</th>
                <th className="p-2 border-r border-slate-200 font-black bg-amber-50">
                  <div>Bağlanan Kurdele Rengi</div>
                  <div className="text-[9px] font-normal text-amber-800">Ekim/Kasım Renk Seçilebilir</div>
                </th>
                <th className="p-2 text-right border-r border-slate-200 font-black">Maksat 9-10</th>
                <th className="p-2 text-right border-r border-slate-200 font-black bg-sky-50/60">GB-7-8</th>
                <th className="p-2 text-right border-r border-slate-200 font-black bg-sky-50/60">GB-5-6</th>
                <th className="p-2 text-right border-r border-slate-200 font-black">Miweli 3-4</th>
                <th className="p-2 text-right border-r border-slate-200 font-black">Miweli 1-2</th>
                <th className="p-2 text-right border-r border-slate-200 font-black">Hem-5</th>
                <th className="p-2 text-right border-r border-slate-200 font-black">Hem-11-12</th>
                <th className="p-2 text-right border-r border-slate-200 font-black bg-amber-100/70">
                  Toplam Ağaç
                </th>
                <th className="p-2 text-right border-r border-slate-200 font-black">
                  Beklenen Kg (32)
                </th>
                <th className="p-2 border-r border-slate-200 font-black bg-emerald-50">
                  <div>Tahmini / Fiili Hasat</div>
                  <div className="text-[9px] font-normal text-emerald-800">Delilnama Hasat Aralığı</div>
                </th>
                <th className="p-2 text-right border-r border-slate-200 font-black bg-emerald-100/80">
                  <div>Gerçekleşen Hasat (Kg)</div>
                  <div className="text-[9px] font-normal text-emerald-900">Yazılabilir / Delilnama</div>
                </th>
                <th className="p-2 text-right border-r border-slate-200 font-black">
                  <div>Beklenen vs Gerçekleşen</div>
                  <div className="text-[9px] font-normal text-slate-500">Karşılaştırma & Ort. Kg</div>
                </th>
                <th className="p-2 font-black bg-rose-50/70">
                  <div>Renk Hasat Haftası & Gecikme</div>
                  <div className="text-[9px] font-normal text-rose-800">11. Hafta (77G) Analizi</div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {toplamDisplayRows.map((r: MuzToplamExactRow) => {
                const isSummary = r.rowType !== 'PERIOD';
                const dates = resolveToplamPeriodNetDates(r.month, r.sene, r.rawTahmHasat);
                const ov = periodOverrides[r.id] || {};
                const effectiveRawColor = ov.customRibbonColor ?? r.rawColor;
                const cMeta = getRibbonColorMeta(effectiveRawColor);
                const delilnamaMatch = DELILNAMA_2026_BY_TOPLAM_PERIOD_ID[r.id];

                // Bu döneme ait takvim satırlarındaki güncel gerçekleşen kg toplamı
                const matchingCalRows = calendarRows.filter(cr =>
                  cr.id.startsWith(`TOPLAM-${r.id}-`)
                );
                const dynamicActualKg = matchingCalRows.reduce(
                  (s, cr) => s + (cr.harvestedNetKg || 0),
                  0
                );

                const defaultActualKg =
                  r.gercekKilo !== null && r.gercekKilo > 0
                    ? Math.round(r.gercekKilo)
                    : delilnamaMatch?.totalDelilnamaKg
                    ? delilnamaMatch.totalDelilnamaKg
                    : dynamicActualKg > 0
                    ? dynamicActualKg
                    : 0;

                const finalActualKg =
                  ov.customActualKg !== undefined ? ov.customActualKg : defaultActualKg;

                const expectedKg = r.tahmKg32 || (r.toplam ? r.toplam * 32 : 0);
                const comparisonPct =
                  expectedKg > 0 && finalActualKg > 0
                    ? Math.round((finalActualKg / expectedKg) * 100)
                    : 0;
                const avgTreeKg =
                  r.toplam && r.toplam > 0 && finalActualKg > 0
                    ? Number((finalActualKg / r.toplam).toFixed(1))
                    : r.ortAgacKg || 0;

                // Bağlama tarihinden fiili/tahmini hasat tarihine kadar geçen hafta ve gecikme hesabı
                const actualHarvIso = ov.customActualHarvestDate || dates.expectedHarvestIso;
                const tagMs = Date.parse(dates.taggingStartIso);
                const harvMs = Date.parse(actualHarvIso);
                const elapsedDays =
                  !isNaN(tagMs) && !isNaN(harvMs)
                    ? Math.max(70, Math.round((harvMs - tagMs) / 86400000))
                    : 85;
                const elapsedWeeks = Number((elapsedDays / 7).toFixed(1));
                const delayDaysFrom11thWeek = elapsedDays - 77;

                return (
                  <tr
                    key={r.id}
                    className={
                      isSummary
                        ? 'bg-slate-100 font-black text-slate-900'
                        : 'bg-white hover:bg-amber-50/40'
                    }
                  >
                    <td className="p-2 border-r border-slate-200 text-[10px] font-bold text-slate-800">
                      {isSummary ? r.month : dates.netBindingRangeLabel}
                    </td>
                    <td className="p-2 border-r border-slate-200 font-sans font-bold text-slate-900">
                      {r.sene}
                    </td>
                    <td className="p-2 border-r border-slate-200 font-sans">
                      {!isSummary ? (
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-3.5 h-3.5 rounded-full border border-slate-400 shrink-0"
                            style={{ backgroundColor: cMeta.hex }}
                          />
                          <select
                            value={effectiveRawColor || 'Karışık'}
                            onChange={e =>
                              updatePeriodOverride(r.id, { customRibbonColor: e.target.value })
                            }
                            className="bg-white border border-amber-300 rounded-lg px-1.5 py-0.5 text-[10px] font-bold text-slate-900"
                          >
                            <option value={effectiveRawColor || 'Karışık'}>
                              {cMeta.fullLabel}
                            </option>
                            <option value="açyk gyzyl">Açık Kırmızı (Açyk Gyzyl)</option>
                            <option value="gök">Mavi (Gök)</option>
                            <option value="gyzyl">Kırmızı (Gyzyl)</option>
                            <option value="gara">Siyah (Gara)</option>
                            <option value="ýaşyl">Yeşil (Ýaşyl)</option>
                            <option value="purple">Mor (Purple)</option>
                            <option value="goňur">Kahverengi (Goňur)</option>
                            <option value="sary">Sarı (Sary)</option>
                            <option value="ak">Beyaz (Ak)</option>
                            <option value="açyk ýaşyl">Açık Yeşil (Açyk Ýaşyl)</option>
                          </select>
                        </div>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {r.maksat910 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200 bg-sky-50/20 font-bold">
                      {r.gb78 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200 bg-sky-50/20 font-bold">
                      {r.gb56 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {r.miweli34 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {r.miweli12 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {r.hem5 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {r.hem1112 ?? '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200 bg-amber-50/60 font-black text-amber-950">
                      {r.toplam !== null ? r.toplam.toLocaleString('tr-TR') : '—'}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200 text-slate-700 font-bold">
                      {expectedKg > 0 ? `${expectedKg.toLocaleString('tr-TR')} kg` : '—'}
                    </td>
                    <td className="p-2 border-r border-slate-200 bg-emerald-50/40">
                      {!isSummary ? (
                        <div className="space-y-0.5">
                          <input
                            type="date"
                            value={actualHarvIso}
                            onChange={e =>
                              updatePeriodOverride(r.id, {
                                customActualHarvestDate: e.target.value
                              })
                            }
                            className="bg-white border border-emerald-300 rounded px-1.5 py-0.5 text-[10px] font-bold text-emerald-950 w-28"
                          />
                          {delilnamaMatch && (
                            <div className="text-[9px] text-emerald-800 font-sans">
                              Delilnama: {delilnamaMatch.delilnamaHarvestWindow}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span>{r.rawTahmHasat}</span>
                      )}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200 bg-emerald-50/70">
                      {!isSummary ? (
                        <div className="flex flex-col items-end gap-0.5">
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              value={finalActualKg || ''}
                              placeholder="0"
                              onChange={e =>
                                updatePeriodOverride(r.id, {
                                  customActualKg: Number(e.target.value) || 0
                                })
                              }
                              className="w-24 bg-white border border-emerald-400 rounded px-1.5 py-0.5 text-right font-black text-emerald-900"
                            />
                            <span className="text-[9px] text-emerald-800 font-bold">kg</span>
                          </div>
                          {delilnamaMatch && (
                            <span className="text-[9px] text-slate-500 font-sans">
                              {delilnamaMatch.receiptRange}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="font-black text-emerald-900">
                          {finalActualKg > 0 ? `${finalActualKg.toLocaleString('tr-TR')} kg` : '—'}
                        </span>
                      )}
                    </td>
                    <td className="p-2 text-right border-r border-slate-200">
                      {!isSummary && finalActualKg > 0 ? (
                        <div>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                              comparisonPct >= 95
                                ? 'bg-emerald-100 text-emerald-900'
                                : comparisonPct >= 75
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-rose-100 text-rose-900'
                            }`}
                          >
                            %{comparisonPct} Gerçekleşti
                          </span>
                          <div className="text-[9px] text-slate-600 mt-0.5">
                            Ort: <strong>{avgTreeKg} kg/ağaç</strong>
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Hasat Bekleniyor</span>
                      )}
                    </td>
                    <td className="p-2 font-sans text-[10px]">
                      {!isSummary ? (
                        <div>
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-black ${
                              elapsedWeeks > 13.5
                                ? 'bg-rose-100 text-rose-900 border border-rose-300'
                                : elapsedWeeks >= 11
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                : 'bg-amber-100 text-amber-900 border border-amber-300'
                            }`}
                          >
                            {elapsedWeeks}. Hafta ({elapsedDays} Gün)
                          </span>
                          <div className="text-[9px] text-slate-600 mt-0.5">
                            {delayDaysFrom11thWeek > 14
                              ? `🚨 +${delayDaysFrom11thWeek - 14} gün gecikmeli kesim`
                              : delayDaysFrom11thWeek >= 0
                              ? `✅ 11. Hafta sonrasında optimal (+${delayDaysFrom11thWeek}G)`
                              : `⚡ Erken Kesim (${delayDaysFrom11thWeek}G)`}
                          </div>
                        </div>
                      ) : (
                        <span>—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-emerald-300 rounded-2xl shadow-sm p-4 space-y-3">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-xs sm:text-sm font-black text-slate-900 uppercase flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>
              1..7 Sera Boyunca Sektör (Sektör 1..8) Kurdele Bağlama & Hasat Matrisi
            </span>
          </h3>
          <p className="text-[11px] text-slate-600">
            Google Sheet başında <strong>1. 2. 3. 4. 5. 6. 7.</strong> diye yazılan sera sekmelerinden (1.Gkblt-5-6 .. 7.Hmsy-5) sektör boyunca bağlanan kurdele ve kesilen hevenk sayıları
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSelectedNumberedTab('ALL')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-black border cursor-pointer ${
              selectedNumberedTab === 'ALL'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-amber-50'
            }`}
          >
            Tüm 1..7 Seralar ({sectorMatrixRows.length})
          </button>
          {BANANA_GREENHOUSES_2027.map(gh => (
            <button
              key={gh.sheetTab}
              type="button"
              onClick={() => setSelectedNumberedTab(gh.sheetTab)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border cursor-pointer ${
                selectedNumberedTab === gh.sheetTab
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                  : 'bg-emerald-50/60 text-emerald-950 border-emerald-300 hover:bg-emerald-100'
              }`}
            >
              {gh.sheetTab} ({gh.name})
            </button>
          ))}
          <button
            type="button"
            onClick={onSyncSectorsFromSheets}
            disabled={isSyncingSectors}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-black flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingSectors ? 'animate-spin' : ''}`} />
            <span>1..7 Sekmeleri Canlı Çek</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto max-h-[580px]">
        <table className="w-full text-left text-[11px] border-collapse">
          <thead className="bg-slate-100 text-slate-800 sticky top-0 z-10 border-b border-slate-300">
            <tr>
              <th className="p-2 border-r border-slate-200 font-black">Sera Sekmesi (1..7)</th>
              <th className="p-2 border-r border-slate-200 font-black">Standart Sera Kodu</th>
              <th className="p-2 border-r border-slate-200 font-black bg-amber-50">Kurdele Rengi</th>
              <th className="p-2 border-r border-slate-200 font-black">Dönem / Hasat</th>
              {[1, 2, 3, 4, 5, 6, 7, 8].map(secNo => (
                <th
                  key={secNo}
                  className="p-2 text-right border-r border-slate-200 font-black bg-emerald-50/50"
                >
                  <div>Sektör {secNo}</div>
                  <div className="text-[9px] font-normal text-slate-500">Bağ / Kesim</div>
                </th>
              ))}
              <th className="p-2 text-right border-r border-slate-200 font-black bg-amber-100/70">
                Sera Toplam Bağlanan
              </th>
              <th className="p-2 text-right border-r border-slate-200 font-black bg-emerald-100/70">
                Sera Kesilen
              </th>
              <th className="p-2 text-right font-black">Kalan Ağaç</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 font-mono">
            {sectorMatrixRows.map(row => (
              <tr key={row.id} className="hover:bg-amber-50/40 bg-white">
                <td className="p-2 border-r border-slate-200 font-bold text-emerald-800">
                  {row.sheetTab}
                </td>
                <td className="p-2 border-r border-slate-200 font-sans font-black text-slate-900">
                  {row.greenhouseName}
                </td>
                <td className="p-2 border-r border-slate-200 font-sans">
                  <span className="inline-flex items-center gap-1.5 font-bold text-slate-900">
                    <span
                      className="w-3 h-3 rounded-full border border-slate-400 shrink-0"
                      style={{ backgroundColor: row.ribbonHex }}
                    />
                    <span>{row.ribbonName}</span>
                  </span>
                </td>
                <td className="p-2 border-r border-slate-200 text-[10px] text-slate-600">
                  <div className="font-bold text-slate-800">{row.weekLabel}</div>
                  <div>{row.harvestWindow}</div>
                </td>
                {row.sectorsBound.map((bVal, idx) => {
                  const hVal = row.sectorsHarvested[idx];
                  return (
                    <td
                      key={idx}
                      className="p-2 text-right border-r border-slate-200 tabular-nums"
                    >
                      {bVal > 0 ? (
                        <div>
                          <span className="font-black text-slate-900">{bVal}</span>
                          <div className="text-[9px] text-emerald-700 font-bold">
                            Kesim: {hVal}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                  );
                })}
                <td className="p-2 text-right border-r border-slate-200 bg-amber-50/60 font-black text-amber-950">
                  {row.totalBound.toLocaleString('tr-TR')}
                </td>
                <td className="p-2 text-right border-r border-slate-200 bg-emerald-50/60 font-black text-emerald-800">
                  {row.totalHarvested.toLocaleString('tr-TR')}
                </td>
                <td className="p-2 text-right font-bold text-slate-800">
                  {row.remaining.toLocaleString('tr-TR')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
