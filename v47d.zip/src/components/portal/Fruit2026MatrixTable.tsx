import React, { useState, useMemo } from 'react';
import {
  Miwe2026Row,
  Miwe2026HarvestStatus,
  INITIAL_MIWE_2026_ROWS,
  INITIAL_MIWE_2027_ROWS,
  MIWE_2026_STATUS_OPTIONS,
  FRUIT_CRATE_AND_WORKER_NORMS,
  PlanCrateOption,
  loadPlanCrateOptions,
  savePlanCrateOptions,
  recalculateMiwe2026Row,
  parseMiweDateMs,
  formatRowsForGoogleSheetsTSV,
  MIWE_GOOGLE_SHEET_URL,
  loadCustomOrchards,
  sanitizeMiweRows,
  isInvalidSaywanGrannySmith
} from '../../data/miwe2026Schema';
import { DelilnamaInfoModal } from './DelilnamaInfoModal';
import { Miwe2026ConjecturePanel } from './Miwe2026ConjecturePanel';
import { WorldStandardHarvestAnalyticsPanel } from './WorldStandardHarvestAnalyticsPanel';
import { HarvestRecord, FieldRecord } from '../../types';
import {
  Search,
  Plus,
  Trash2,
  Edit3,
  Download,
  RotateCcw,
  Smartphone,
  Monitor,
  X,
  FileSpreadsheet,
  Users,
  Package,
  Scale,
  Sprout,
  Calendar,
  Clock,
  ArrowUpDown,
  ExternalLink,
  Copy,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  Filter,
  ChevronDown,
  Printer,
  ChevronUp,
  Info
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

export type ColumnGroupFilter =
  | 'SADE_TAKVIM'
  | 'COMPACT_FIT'
  | 'PHENOLOGY_DATES'
  | 'HARVEST_ANALYSIS_WORKFORCE'
  | 'ALL_COLUMNS';

export type SortOptionKey =
  | 'HARVEST_DATE_ASC'
  | 'HARVEST_DATE_DESC'
  | 'FLOWERING_DATE_ASC'
  | 'THINNING_DATE_ASC'
  | 'HARVEST_DAYS_DESC'
  | 'TONNAGE_DESC'
  | 'ROW_NUM_ASC';

const STORAGE_KEY_2026 = 'MIWE_2026_PORTAL_SCHEMA_V3';
const STORAGE_KEY_2027 = 'MIWE_2027_PORTAL_SCHEMA_V3';

interface Fruit2026MatrixTableProps {
  activeYear?: '2026' | '2027';
  onSwitchYear?: (year: '2026' | '2027') => void;
  harvestRecords?: HarvestRecord[];
  fieldRecords?: FieldRecord[];
}

export const Fruit2026MatrixTable: React.FC<Fruit2026MatrixTableProps> = ({
  activeYear: propYear,
  onSwitchYear,
  harvestRecords = [],
  fieldRecords = []
}) => {
  const { showSuccess, showInfo, showError } = useToast();

  const [internalYear, setInternalYear] = useState<'2026' | '2027'>('2026');
  const activeYear = propYear || internalYear;
  const [isActionsDropdownOpen, setIsActionsDropdownOpen] = useState(false);

  const handleYearChange = (y: '2026' | '2027') => {
    setInternalYear(y);
    if (onSwitchYear) onSwitchYear(y);
  };

  // 2026 Rows State (Saywan Granny Smith veri güvenliği için sanitize edilir)
  const [rows2026, setRows2026] = useState<Miwe2026Row[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_2026);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return sanitizeMiweRows(parsed);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // 2027 Rows State (2026 gibi tüm detaylı bilgileri girebileceğimiz 2027 veri katmanı)
  const [rows2027, setRows2027] = useState<Miwe2026Row[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_2027);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return sanitizeMiweRows(parsed);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Planda Kutu Ekleme & Seçme State
  const [crateOptions, setCrateOptions] = useState<PlanCrateOption[]>(() => loadPlanCrateOptions());
  const [customOrchards, setCustomOrchards] = useState<string[]>(() => loadCustomOrchards());
  const [isCrateModalOpen, setIsCrateModalOpen] = useState(false);
  const [isDelilnamaModalOpen, setIsDelilnamaModalOpen] = useState(false);
  const [showAdvancedPanels, setShowAdvancedPanels] = useState(false);
  const [newCrateName, setNewCrateName] = useState('');
  const [newCrateDims, setNewCrateDims] = useState('50×30 cm');
  const [newCrateKg, setNewCrateKg] = useState<number>(4.0);
  const [newCrateFruits, setNewCrateFruits] = useState('Şetdaly, Nektarin, Alma');

  const rows = activeYear === '2026' ? rows2026 : rows2027;

  const saveRows = (updated: Miwe2026Row[], targetYear: '2026' | '2027' = activeYear) => {
    const sanitized = sanitizeMiweRows(updated);
    if (targetYear === '2026') {
      setRows2026(sanitized);
      try {
        localStorage.setItem(STORAGE_KEY_2026, JSON.stringify(sanitized));
      } catch (e) {
        console.error(e);
      }
    } else {
      setRows2027(sanitized);
      try {
        localStorage.setItem(STORAGE_KEY_2027, JSON.stringify(sanitized));
      } catch (e) {
        console.error(e);
      }
    }
  };

  const [sortingPolicy, setSortingPolicy] = useState<'2026_DELILNAMA_5PCT' | '2027_DESTINATION_SORT'>(
    activeYear === '2027' ? '2027_DESTINATION_SORT' : '2026_DELILNAMA_5PCT'
  );
  // Kullanıcı talebine uygun olarak varsayılan görünüm SADE_TAKVIM (Sadeleştirilmiş ve Kullanışlı) yapıldı
  const [columnGroup, setColumnGroup] = useState<ColumnGroupFilter>('SADE_TAKVIM');
  const [viewMode, setViewMode] = useState<'AUTO' | 'SPREADSHEET' | 'MOBILE_CARDS'>('AUTO');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBahce, setSelectedBahce] = useState<string>('ALL');
  const [selectedMeyve, setSelectedMeyve] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [selectedWeekRange, setSelectedWeekRange] = useState<{ start: number | null; end: number | null }>({
    start: null,
    end: null
  });
  const [sortBy, setSortBy] = useState<SortOptionKey>('HARVEST_DATE_ASC');

  // GG.AA.YYYY veya ay metninden ISO Hafta Numarası (1-52) hesaplama
  const getIsoWeekNumber = (dateStr?: string, fallbackMonth?: string): number | null => {
    if (!dateStr && !fallbackMonth) return null;
    const ms = parseMiweDateMs(dateStr, fallbackMonth);
    if (!ms || isNaN(ms)) return null;
    const target = new Date(ms);
    const dayNr = (target.getDay() + 6) % 7;
    target.setDate(target.getDate() - dayNr + 3);
    const firstThursday = target.getTime();
    target.setMonth(0, 1);
    if (target.getDay() !== 4) {
      target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
    }
    return 1 + Math.ceil((firstThursday - target.getTime()) / 604800000);
  };

  // Modal state for Mobile, 2026 Edit & Direct 2027 Quick Add
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalTargetYear, setModalTargetYear] = useState<'2026' | '2027'>('2026');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [formData, setFormData] = useState<Miwe2026Row>(INITIAL_MIWE_2026_ROWS[0]);

  // Toplu Düzenleme (Bulk Edit) State
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [bulkField, setBulkField] = useState<'CRATE' | 'STATUS' | 'ORCHARD' | 'MONTH' | 'DAYS' | 'WORKER_KG'>('CRATE');
  const [bulkValue, setBulkValue] = useState<string>('');

  const toggleSelectRow = (id: string) => {
    setSelectedRowIds(prev => (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]));
  };

  const toggleSelectAllFiltered = () => {
    const filteredIds = filteredRows.map(r => r.id);
    const allSelected = filteredIds.length > 0 && filteredIds.every(id => selectedRowIds.includes(id));
    if (allSelected) {
      setSelectedRowIds(prev => prev.filter(id => !filteredIds.includes(id)));
    } else {
      setSelectedRowIds(Array.from(new Set([...selectedRowIds, ...filteredIds])));
    }
  };

  const handleApplyBulkEdit = () => {
    if (selectedRowIds.length === 0) {
      showError('Lütfen önce tabloda toplu değiştirmek istediğiniz satırları seçin.');
      return;
    }
    if (!bulkValue && bulkField !== 'CRATE' && bulkField !== 'STATUS') {
      showError('Lütfen uygulanacak yeni değeri girin veya seçin.');
      return;
    }

    const updated = rows.map(r => {
      if (!selectedRowIds.includes(r.id)) return r;
      const copy: Miwe2026Row = { ...r };

      if (bulkField === 'CRATE') {
        const chosenCrateName = bulkValue || crateOptions[0]?.name || copy.secilenKutuAdi;
        const matchedCrate = crateOptions.find(c => c.name === chosenCrateName);
        copy.secilenKutuAdi = chosenCrateName;
        if (matchedCrate) {
          copy.W3_seftaliKutu50x30Kg = matchedCrate.capacityKg;
        }
      } else if (bulkField === 'STATUS') {
        copy.AG3_hasatStatusu = (bulkValue || 'Test Edildi') as Miwe2026HarvestStatus;
      } else if (bulkField === 'ORCHARD') {
        copy.A3_bahce = bulkValue;
      } else if (bulkField === 'MONTH') {
        copy.D3_ortalamaHasatAy = bulkValue;
      } else if (bulkField === 'DAYS') {
        copy.hasatGunSayisi = Math.max(1, Number(bulkValue) || 10);
      } else if (bulkField === 'WORKER_KG') {
        copy.U3_gunlukIsciGucuKg = Math.max(10, Number(bulkValue) || 200);
      }

      return recalculateMiwe2026Row(copy, sortingPolicy);
    });

    saveRows(updated);
    showSuccess(`Seçili ${selectedRowIds.length} satırda toplu güncelleme başarıyla uygulandı.`);
  };

  const handlePolicyChange = (policy: '2026_DELILNAMA_5PCT' | '2027_DESTINATION_SORT') => {
    setSortingPolicy(policy);
    const updated = rows.map(r => recalculateMiwe2026Row(r, policy));
    saveRows(updated);
  };

  // BAHÇE VE MEYVE FİLTRE BAŞINA AKILLI FİLTRE TOPLAMLARI (2026 / 2027'ye Göre)
  const smartOrchardFilterTotals = useMemo(() => {
    const baseOrchards = ['ALL', 'Garahan', 'Saywan', 'Gursak', 'Bagyr', 'Soğan', 'Havuç', 'Patates'];
    const dynamicExtra = customOrchards.filter(
      name => !baseOrchards.some(b => name.toLowerCase().includes(b.toLowerCase()))
    );
    const orchards = [...baseOrchards, ...dynamicExtra];
    return orchards.map(orch => {
      const matching = rows.filter(r => {
        if (orch !== 'ALL' && !r.A3_bahce.toLowerCase().includes(orch.toLowerCase())) return false;
        if (selectedMeyve !== 'ALL' && r.B3_meyve.toLowerCase() !== selectedMeyve.toLowerCase()) return false;
        return true;
      });
      const budgetTon = matching.reduce((s, r) => s + (r.AB3_yonetimButcePlanTon || 0), 0);
      const delilnamaTon = matching.reduce((s, r) => s + (r.AF3_delilnamaHamTon || 0), 0);
      const totalDays = matching.reduce((s, r) => s + (r.hasatGunSayisi || 10), 0);
      return {
        key: orch,
        label: orch === 'ALL' ? 'Tüm Bahçeler' : orch,
        count: matching.length,
        budgetTon: Math.round(budgetTon),
        delilnamaTon: Math.round(delilnamaTon),
        avgDays: matching.length > 0 ? Math.round(totalDays / matching.length) : 0
      };
    }).filter(item => item.key === 'ALL' || item.count > 0 || ['Garahan', 'Saywan', 'Gursak', 'Bagyr'].includes(item.key));
  }, [rows, selectedMeyve, customOrchards]);

  const smartFruitFilterTotals = useMemo(() => {
    const fruits = ['ALL', 'Şetdaly', 'Nektarin', 'Ülje', 'Garaly', 'Alma', 'Armyt', 'Badam', 'Hurma', 'Soğan', 'Havuç', 'Patates'] as const;
    return fruits.map(fr => {
      const matching = rows.filter(r => {
        if (selectedBahce !== 'ALL' && !r.A3_bahce.toLowerCase().includes(selectedBahce.toLowerCase())) return false;
        if (fr !== 'ALL' && r.B3_meyve.toLowerCase() !== fr.toLowerCase()) return false;
        return true;
      });
      const budgetTon = matching.reduce((s, r) => s + (r.AB3_yonetimButcePlanTon || 0), 0);
      const delilnamaTon = matching.reduce((s, r) => s + (r.AF3_delilnamaHamTon || 0), 0);
      return {
        key: fr,
        label: fr === 'ALL' ? 'Tüm Meyveler' : fr,
        count: matching.length,
        budgetTon: Math.round(budgetTon),
        delilnamaTon: Math.round(delilnamaTon)
      };
    });
  }, [rows, selectedBahce]);

  // Filtered & Date-Sorted rows
  const filteredRows = useMemo(() => {
    const filtered = rows.filter(r => {
      if (selectedBahce !== 'ALL' && !r.A3_bahce.toLowerCase().includes(selectedBahce.toLowerCase())) {
        return false;
      }
      if (selectedMeyve !== 'ALL' && r.B3_meyve.toLowerCase() !== selectedMeyve.toLowerCase()) {
        return false;
      }
      if (selectedStatus !== 'ALL' && r.AG3_hasatStatusu !== selectedStatus) {
        return false;
      }
      if (selectedMonth !== 'ALL' && !r.D3_ortalamaHasatAy.toLowerCase().includes(selectedMonth.toLowerCase())) {
        return false;
      }
      if (selectedWeekRange.start !== null || selectedWeekRange.end !== null) {
        const wk = getIsoWeekNumber(r.R3_tahminiHasatTarihi || r.AD3_fiili2026Baslama, r.D3_ortalamaHasatAy);
        if (wk === null) return false;
        if (selectedWeekRange.start !== null && wk < selectedWeekRange.start) return false;
        if (selectedWeekRange.end !== null && wk > selectedWeekRange.end) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          r.A3_bahce.toLowerCase().includes(q) ||
          r.B3_meyve.toLowerCase().includes(q) ||
          r.C3_meyveGrant.toLowerCase().includes(q) ||
          r.D3_ortalamaHasatAy.toLowerCase().includes(q) ||
          r.AG3_hasatStatusu.toLowerCase().includes(q) ||
          (r.secilenKutuAdi || '').toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });

    // TARİHLERE GÖRE SIRALAMA MOTORU
    return [...filtered].sort((a, b) => {
      if (sortBy === 'HARVEST_DATE_ASC') {
        const msA = parseMiweDateMs(a.R3_tahminiHasatTarihi || a.AD3_fiili2026Baslama, a.D3_ortalamaHasatAy);
        const msB = parseMiweDateMs(b.R3_tahminiHasatTarihi || b.AD3_fiili2026Baslama, b.D3_ortalamaHasatAy);
        return msA - msB;
      }
      if (sortBy === 'HARVEST_DATE_DESC') {
        const msA = parseMiweDateMs(a.R3_tahminiHasatTarihi || a.AD3_fiili2026Baslama, a.D3_ortalamaHasatAy);
        const msB = parseMiweDateMs(b.R3_tahminiHasatTarihi || b.AD3_fiili2026Baslama, b.D3_ortalamaHasatAy);
        return msB - msA;
      }
      if (sortBy === 'FLOWERING_DATE_ASC') {
        const msA = parseMiweDateMs(a.F3_bbch65CiceklemeTarihi, a.D3_ortalamaHasatAy);
        const msB = parseMiweDateMs(b.F3_bbch65CiceklemeTarihi, b.D3_ortalamaHasatAy);
        return msA - msB;
      }
      if (sortBy === 'THINNING_DATE_ASC') {
        const msA = parseMiweDateMs(a.G3_bbch71SeyreltmeBaslama, a.D3_ortalamaHasatAy);
        const msB = parseMiweDateMs(b.G3_bbch71SeyreltmeBaslama, b.D3_ortalamaHasatAy);
        return msA - msB;
      }
      if (sortBy === 'HARVEST_DAYS_DESC') {
        return (b.hasatGunSayisi || 0) - (a.hasatGunSayisi || 0);
      }
      if (sortBy === 'TONNAGE_DESC') {
        return (b.AB3_yonetimButcePlanTon || 0) - (a.AB3_yonetimButcePlanTon || 0);
      }
      return a.rowNumber - b.rowNumber;
    });
  }, [rows, selectedBahce, selectedMeyve, selectedStatus, selectedMonth, selectedWeekRange, searchQuery, sortBy]);

  // Seçili Filtreye Göre Canlı Akıllı Toplamlar ve Hasat Analizi
  const kpis = useMemo(() => {
    let totalAb3Budget = 0;
    let totalAf3Delilnama = 0;
    let totalAh3Net = 0;
    let totalV3Workers = 0;
    let totalX3Crates = 0;
    let totalHarvestDays = 0;
    let completedCount = 0;

    filteredRows.forEach(r => {
      totalAb3Budget += r.AB3_yonetimButcePlanTon || 0;
      totalAf3Delilnama += r.AF3_delilnamaHamTon || 0;
      totalAh3Net += r.AH3_netSortSonrasiTon || 0;
      totalV3Workers += r.V3_gerekenIsciSayisi || 0;
      totalX3Crates += r.X3_gerekenKutu50x30Adet || 0;
      totalHarvestDays += r.hasatGunSayisi || 10;
      if (r.AG3_hasatStatusu === 'Tamamlandy') completedCount += 1;
    });

    const avgHarvestDays = filteredRows.length > 0 ? Math.round(totalHarvestDays / filteredRows.length) : 0;
    const realizationPct =
      totalAb3Budget > 0 && totalAf3Delilnama > 0
        ? Math.round((totalAf3Delilnama / totalAb3Budget) * 100)
        : 0;
    const dailyAvgTon =
      avgHarvestDays > 0
        ? Number(((totalAf3Delilnama > 0 ? totalAf3Delilnama : totalAb3Budget) / avgHarvestDays).toFixed(1))
        : 0;

    return {
      totalAb3Budget: Number(totalAb3Budget.toFixed(1)),
      totalAf3Delilnama: Number(totalAf3Delilnama.toFixed(1)),
      totalAh3Net: Number(totalAh3Net.toFixed(1)),
      totalV3Workers,
      totalX3Crates,
      totalHarvestDays,
      avgHarvestDays,
      realizationPct,
      dailyAvgTon,
      completedCount,
      totalVarieties: filteredRows.length
    };
  }, [filteredRows]);

  // Inline cell update with automatic calculation
  const updateCell = (id: string, field: keyof Miwe2026Row, rawVal: string) => {
    const updated = rows.map(r => {
      if (r.id !== id) return r;
      const copy: Miwe2026Row = { ...r };

      if (
        field === 'AB3_yonetimButcePlanTon' ||
        field === 'AC3_agronomRewizPlanTon' ||
        field === 'AF3_delilnamaHamTon' ||
        field === 'AH3_netSortSonrasiTon'
      ) {
        copy[field] = rawVal === '' ? null : Number(rawVal);
      } else if (
        field === 'U3_gunlukIsciGucuKg' ||
        field === 'V3_gerekenIsciSayisi' ||
        field === 'W3_seftaliKutu50x30Kg' ||
        field === 'X3_gerekenKutu50x30Adet' ||
        field === 'hasatGunSayisi'
      ) {
        copy[field] = rawVal === '' ? 0 : Number(rawVal);
      } else {
        (copy as any)[field] = rawVal;
      }

      if (field === 'B3_meyve') {
        const norm = FRUIT_CRATE_AND_WORKER_NORMS.find(n =>
          rawVal.toLowerCase().includes(n.product.toLowerCase())
        );
        if (norm) {
          copy.U3_gunlukIsciGucuKg = norm.defaultWorkerDailyKg;
          copy.W3_seftaliKutu50x30Kg = norm.w3_50x30_kg;
          copy.hasatGunSayisi = norm.defaultHarvestDays;
        }
      }

      if (field === 'secilenKutuAdi') {
        const matchedCrate = crateOptions.find(c => c.name === rawVal);
        if (matchedCrate) {
          copy.W3_seftaliKutu50x30Kg = matchedCrate.capacityKg;
        }
      }

      return recalculateMiwe2026Row(copy, sortingPolicy);
    });
    saveRows(updated);
  };

  // Yeni 2026 veya 2027 Kaydı Ekleme Modalı Aç
  const handleOpenAdd = (targetYear: '2026' | '2027' = activeYear) => {
    const targetList = targetYear === '2026' ? rows2026 : rows2027;
    const nextNum = targetList.length > 0 ? Math.max(...targetList.map(r => r.rowNumber)) + 1 : 4;
    const newRow: Miwe2026Row = recalculateMiwe2026Row(
      {
        id: `MIWE-${targetYear}-R${String(nextNum).padStart(3, '0')}`,
        rowNumber: nextNum,
        A3_bahce: selectedBahce !== 'ALL' ? selectedBahce : 'Garahan',
        B3_meyve: selectedMeyve !== 'ALL' ? selectedMeyve : 'Şetdaly',
        C3_meyveGrant: '',
        D3_ortalamaHasatAy: 'Haziran (6)',
        E3_haftaninGunu: '1',
        F3_bbch65CiceklemeTarihi: `22.03.${targetYear}`,
        G3_bbch71SeyreltmeBaslama: `28.04.${targetYear}`,
        H3_seyreltmeBitmeTarihi: `06.05.${targetYear}`,
        I3_seyreltmeSuresiGun: '8',
        J3_suKesmeTarihiBadem: '',
        K3_testTarihiNotu: `01.06.${targetYear}`,
        L3_hasat2024Tarihi: '08.06.2024',
        M3_hasat2025Tarihi: '06.06.2025',
        N3_yilinGunuMin: '158',
        O3_yilinGunuMax: '163',
        P3_bbchMinGun: '80',
        Q3_bbchMaxGun: '110',
        R3_tahminiHasatTarihi: `07.06.${targetYear}`,
        S3_optimalWindowTarihi: `05.06.${targetYear}`,
        T3_hasat2027Baslama: '06.06.2027',
        U3_gunlukIsciGucuKg: 200,
        V3_gerekenIsciSayisi: 125,
        W3_seftaliKutu50x30Kg: 3.5,
        X3_gerekenKutu50x30Adet: 7143,
        Y3_kutuCesit1Bilgi: '4 kg Viyol',
        Z3_kutuCesit2Bilgi: '8.5 kg Plastik',
        AA3_kutuCesit3Bilgi: '',
        AB3_yonetimButcePlanTon: 25,
        AC3_agronomRewizPlanTon: 25,
        AD3_fiili2026Baslama: `07.06.${targetYear}`,
        AE3_fiili2026BitisNot: `17.06.${targetYear}`,
        AF3_delilnamaHamTon: targetYear === '2026' ? 25 : null,
        AG3_hasatStatusu: targetYear === '2026' ? 'Test Edildi' : 'Başlamady',
        AH3_netSortSonrasiTon: targetYear === '2026' ? 23.75 : null,
        hasatGunSayisi: 10,
        gunlukOrtalamaHasatTon: 2.5,
        butceGerceklesmePct: targetYear === '2026' ? 100 : 0,
        secilenKutuAdi: crateOptions[0]?.name || '50×30 Şeftali / Nektarin Kutusu'
      },
      targetYear === '2027' ? '2027_DESTINATION_SORT' : sortingPolicy
    );

    setModalTargetYear(targetYear);
    setFormData(newRow);
    setIsAddingNew(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (row: Miwe2026Row) => {
    setModalTargetYear(activeYear);
    setFormData({ ...row });
    setIsAddingNew(false);
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent, alsoSendToGoogleSheet = false) => {
    e.preventDefault();
    if (!formData.A3_bahce || !formData.B3_meyve || !formData.C3_meyveGrant) {
      showError('Lütfen Bahçe, Meyve ve Meyve Çeşidi (Grant) alanlarını doldurun.');
      return;
    }
    if (
      formData.A3_bahce.toLowerCase().includes('saywan') &&
      formData.C3_meyveGrant.toLowerCase().includes('granny')
    ) {
      showError(
        'Saywan bahçesinde Granny Smith çeşidi bulunmamaktadır! Lütfen Saywan elma çeşitlerinden birini seçin (Early Gold, Gallaval, Golden Reinders, Scarlet Spur, Rosy Glow).'
      );
      return;
    }
    const targetList = modalTargetYear === '2026' ? rows2026 : rows2027;
    const policy = modalTargetYear === '2027' ? '2027_DESTINATION_SORT' : sortingPolicy;
    const calculated = recalculateMiwe2026Row(formData, policy);

    if (isAddingNew) {
      saveRows([calculated, ...targetList], modalTargetYear);
      handleYearChange(modalTargetYear);
      showSuccess(`${modalTargetYear} Planına "${calculated.A3_bahce} • ${calculated.C3_meyveGrant}" eklendi.`);
    } else {
      saveRows(
        targetList.map(r => (r.id === calculated.id ? calculated : r)),
        modalTargetYear
      );
      showSuccess(`${modalTargetYear} "${calculated.A3_bahce} • ${calculated.C3_meyveGrant}" güncellendi.`);
    }

    if (alsoSendToGoogleSheet) {
      const tsv = formatRowsForGoogleSheetsTSV([calculated], modalTargetYear);
      navigator.clipboard?.writeText(tsv).catch(() => {});
      showSuccess('Satır Google Sheet formatında panoya kopyalandı! Açılan tabloya yapıştırabilirsiniz (Ctrl+V).');
    }

    setIsModalOpen(false);
  };

  // Plana Yeni Kutu Tipi Ekleme
  const handleAddCrateOption = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCrateName.trim() || newCrateKg <= 0) {
      showError('Lütfen kutu adını ve kapasitesini (kg) girin.');
      return;
    }
    const created: PlanCrateOption = {
      id: `CRATE-CUSTOM-${Date.now()}`,
      name: `${newCrateName.trim()} (${newCrateKg} kg)`,
      dimensions: newCrateDims.trim() || '50×30 cm',
      capacityKg: Number(newCrateKg),
      defaultFruits: newCrateFruits.trim() || 'Tüm Meyveler',
      material: 'Özel Plan Kutusu'
    };
    const updated = [created, ...crateOptions];
    setCrateOptions(updated);
    savePlanCrateOptions(updated);
    setNewCrateName('');
    showSuccess(`"${created.name}" plan kutu listesine eklendi.`);
  };

  const handleDeleteCrateOption = (id: string) => {
    const updated = crateOptions.filter(c => c.id !== id);
    setCrateOptions(updated);
    savePlanCrateOptions(updated);
    showInfo('Kutu tipi listeden kaldırıldı.');
  };

  // Google Sheet'e Gönder (TSV Panoya Kopyala)
  const handleCopyForGoogleSheets = () => {
    const tsv = formatRowsForGoogleSheetsTSV(filteredRows, activeYear);
    navigator.clipboard
      ?.writeText(tsv)
      .then(() => {
        showSuccess(
          `${filteredRows.length} satırlık ${activeYear} Meyve Planı Google Sheet formatında kopyalandı! Google Sheet'te Ctrl+V ile yapıştırabilirsiniz.`
        );
      })
      .catch(() => {
        showInfo('Google Sheet tablosu hazır.');
      });
  };

  const handleDelete = (id: string) => {
    saveRows(rows.filter(r => r.id !== id));
    showInfo('Satır takvimden silindi.');
  };

  const handleReset = () => {
    if (activeYear === '2026') {
      localStorage.removeItem(STORAGE_KEY_2026);
      setRows2026(INITIAL_MIWE_2026_ROWS);
      showSuccess('2026 Tablosu orijinal Google Sheet (127 çeşit) verilerine sıfırlandı.');
    } else {
      localStorage.removeItem(STORAGE_KEY_2027);
      setRows2027(INITIAL_MIWE_2027_ROWS);
      showSuccess('2027 Planlama Tablosu varsayılan optimal pencere verilerine sıfırlandı.');
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'Sıra',
      'Bahçe',
      'Meyve',
      'Meyve Çeşidi (Grant)',
      'Ortalama Hasat Ayı',
      'Haftanın Günü',
      '%75 Çiçeklenme Tarihi (BBCH 65)',
      'Seyreltme Başlama (BBCH 71)',
      'Seyreltme Bitme Tarihi',
      'Seyreltme Gün Sayısı',
      '2024 Hasat Tarihi',
      '2025 Hasat Tarihi',
      'Çiçeklenmeden Hasada Gün',
      'Tahmini Hasat Başlama Tarihi',
      '2027 Optimal Hasat Başlama',
      'Hasat Gün Sayısı',
      'Günlük Ortalama Hasat (Ton/Gün)',
      '1 İşçi Günlük Kapasite (Kg)',
      'Gereken İşçi Sayısı',
      'Seçilen Kutu Tipi',
      'Kutu Kapasitesi (Kg)',
      'Gereken Kutu Adedi',
      'Yönetim Bütçe Planı (Ton)',
      'Delilnama Onaylı Ham Meyve (Ton)',
      'Hasat Analizi (%)',
      'Hasat Statüsü'
    ].join(',');

    const csvRows = filteredRows.map(r =>
      [
        r.rowNumber,
        r.A3_bahce,
        r.B3_meyve,
        r.C3_meyveGrant,
        r.D3_ortalamaHasatAy,
        r.E3_haftaninGunu,
        r.F3_bbch65CiceklemeTarihi,
        r.G3_bbch71SeyreltmeBaslama,
        r.H3_seyreltmeBitmeTarihi,
        r.I3_seyreltmeSuresiGun,
        r.L3_hasat2024Tarihi,
        r.M3_hasat2025Tarihi,
        `${r.P3_bbchMinGun}-${r.Q3_bbchMaxGun}`,
        r.R3_tahminiHasatTarihi,
        r.T3_hasat2027Baslama,
        r.hasatGunSayisi,
        r.gunlukOrtalamaHasatTon,
        r.U3_gunlukIsciGucuKg,
        r.V3_gerekenIsciSayisi,
        r.secilenKutuAdi,
        r.W3_seftaliKutu50x30Kg,
        r.X3_gerekenKutu50x30Adet,
        r.AB3_yonetimButcePlanTon ?? '',
        r.AF3_delilnamaHamTon ?? '',
        r.butceGerceklesmePct ? `%${r.butceGerceklesmePct}` : '',
        r.AG3_hasatStatusu
      ]
        .map(v => `"${String(v).replace(/"/g, '""')}"`)
        .join(',')
    );

    const blob = new Blob(['\uFEFF' + [headers, ...csvRows].join('\r\n')], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Miwe_Plan_Harvest_${activeYear}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    showSuccess(`${activeYear} Meyve Hasat Takvimi CSV olarak indirildi.`);
  };

  const activeFiltersSummary = useMemo(() => {
    const list: string[] = [];
    if (selectedBahce !== 'ALL') list.push(selectedBahce);
    if (selectedMeyve !== 'ALL') list.push(selectedMeyve);
    if (selectedStatus !== 'ALL') list.push(selectedStatus);
    if (selectedMonth !== 'ALL') list.push(selectedMonth);
    if (selectedWeekRange.start !== null || selectedWeekRange.end !== null) {
      if (selectedWeekRange.start && selectedWeekRange.end) {
        list.push(`${selectedWeekRange.start}-${selectedWeekRange.end}. hafta`);
      } else if (selectedWeekRange.start) {
        list.push(`≥ ${selectedWeekRange.start}. hafta`);
      } else {
        list.push(`≤ ${selectedWeekRange.end}. hafta`);
      }
    }
    if (searchQuery.trim()) list.push(`"${searchQuery}"`);
    return list;
  }, [selectedBahce, selectedMeyve, selectedStatus, selectedMonth, selectedWeekRange, searchQuery]);

  const handleClearAllFilters = () => {
    setSelectedBahce('ALL');
    setSelectedMeyve('ALL');
    setSelectedStatus('ALL');
    setSelectedMonth('ALL');
    setSelectedWeekRange({ start: null, end: null });
    setSearchQuery('');
    showSuccess('Tüm filtreler temizlendi.');
  };

  const handleExportPdf = () => {
    window.print();
  };

  const showCol = (group: 'PHENOLOGY' | 'ANALYSIS_WORKFORCE' | 'EXTENDED_ONLY') => {
    if (columnGroup === 'ALL_COLUMNS') return true;
    if (columnGroup === 'SADE_TAKVIM') return false;
    if (columnGroup === 'COMPACT_FIT') return group !== 'EXTENDED_ONLY';
    if (columnGroup === 'PHENOLOGY_DATES') return group === 'PHENOLOGY' || group === 'EXTENDED_ONLY';
    if (columnGroup === 'HARVEST_ANALYSIS_WORKFORCE') return group === 'ANALYSIS_WORKFORCE';
    return true;
  };

  return (
    <div className="space-y-4">
      {/* 1. SADE METRO TILE YIL SEÇİMİ VE İŞLEMLER BARI */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-md flex flex-wrap items-center justify-between gap-3">
        {/* 2026 vs 2027 Sekme Geçişi */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 shadow-inner">
          <button
            type="button"
            onClick={() => handleYearChange('2026')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              activeYear === '2026'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>2026 Meyve &amp; Sebze Takvimi</span>
            <span className="px-1.5 py-0.5 rounded bg-black/20 text-[10px] font-mono">
              {rows2026.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleYearChange('2027')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              activeYear === '2027'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>2027 Meyve Planlama Paneli</span>
            <span className="px-1.5 py-0.5 rounded bg-black/20 text-[10px] font-mono">
              {rows2027.length}
            </span>
          </button>
        </div>

        {/* Sağ Aksiyonlar: Delilnama Butonu + Analiz Butonu + İşlemler Menüsü */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setIsDelilnamaModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-black flex items-center gap-2 shadow-md transition cursor-pointer border border-indigo-400/40"
            title="Google Sheet Delilnama kalite sınıfları (Extra, Exclusive, Premium, Classic, Mix, Ballyk) dağılımını incele"
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-300" />
            <span>📋 Delilnama Sınıf Dağılımı</span>
            <span className="px-1.5 py-0.5 rounded bg-indigo-950/80 text-[10px] text-amber-300 font-bold border border-indigo-400/30">
              Sadece Bilgi
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowAdvancedPanels(!showAdvancedPanels)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border ${
              showAdvancedPanels
                ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
            title="Bahçe bazlı hasat gerçekleşme ve dünya standartları panellerini aç/kapat"
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>{showAdvancedPanels ? 'Analiz Panellerini Gizle ▲' : '📊 Analiz Panelleri ▼'}</span>
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => setIsActionsDropdownOpen(!isActionsDropdownOpen)}
              className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-black flex items-center gap-2 shadow-md transition cursor-pointer border border-teal-400/40"
            >
              <span>⚙️ İşlemler</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {isActionsDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-2 z-50 space-y-1.5 text-xs">
                <button
                  type="button"
                  onClick={() => { setIsActionsDropdownOpen(false); setIsDelilnamaModalOpen(true); }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-indigo-300 font-bold flex items-center gap-2 cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-amber-300" />
                  <span>📋 Delilnama Sınıfları (Sadece Bilgi)</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsActionsDropdownOpen(false); handleOpenAdd('2026'); }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-emerald-300 font-bold flex items-center gap-2 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ 2026 Satırı Ekle</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsActionsDropdownOpen(false); handleOpenAdd('2027'); }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-indigo-300 font-bold flex items-center gap-2 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-300" />
                  <span>🚀 + 2027 Planı Ekle</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsActionsDropdownOpen(false); setIsCrateModalOpen(true); }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-amber-300 font-bold flex items-center gap-2 cursor-pointer"
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>📦 Plana Kutu Ekle ({crateOptions.length})</span>
                </button>

                {activeYear === '2026' && (
                  <>
                    <button
                      type="button"
                      onClick={() => { setIsActionsDropdownOpen(false); handleCopyForGoogleSheets(); }}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-teal-300 font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Tabloyu Kopyala</span>
                    </button>

                    <a
                      href={MIWE_GOOGLE_SHEET_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => { setIsActionsDropdownOpen(false); handleCopyForGoogleSheets(); }}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-orange-300 font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Google Sheet'e Git ↗</span>
                    </a>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>





      {/* 2. AKILLI FİLTRELEME VE FİLTRE BAŞINA CANLI TOPLAMLAR (2026 / 2027) */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-3.5 sm:p-4 space-y-3 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-black uppercase tracking-wider text-white">
              Bahçe & Meyve Akıllı Filtre Toplamları ({activeYear})
            </span>
          </div>

          {/* TARİHE GÖRE SIRALAMA SEÇİCİSİ */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-indigo-500/30">
              <ArrowUpDown className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[11px] font-bold text-slate-300">Sıralama:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as SortOptionKey)}
                className="bg-transparent text-xs font-bold text-indigo-300 outline-none cursor-pointer"
              >
                <option value="HARVEST_DATE_ASC" className="bg-slate-900 text-white">
                  📅 Tahmini Hasat Tarihi (Erkenden Geçe ↑)
                </option>
                <option value="HARVEST_DATE_DESC" className="bg-slate-900 text-white">
                  📅 Tahmini Hasat Tarihi (Geçten Erkene ↓)
                </option>
                <option value="FLOWERING_DATE_ASC" className="bg-slate-900 text-white">
                  🌸 %75 Çiçeklenme Tarihi (Erkenden Geçe ↑)
                </option>
                <option value="THINNING_DATE_ASC" className="bg-slate-900 text-white">
                  🌿 Seyreltme Tarihi (Erkenden Geçe ↑)
                </option>
                <option value="HARVEST_DAYS_DESC" className="bg-slate-900 text-white">
                  ⏱️ Hasat Gün Sayısı (Uzundan Kısaya ↓)
                </option>
                <option value="TONNAGE_DESC" className="bg-slate-900 text-white">
                  ⚖️ Yönetim Bütçe Tonajı (Yüksekten Düşüğe ↓)
                </option>
                <option value="ROW_NUM_ASC" className="bg-slate-900 text-white">
                  🔢 Tablo Sıra Numarası (#)
                </option>
              </select>
            </div>

            <div className="relative w-44 sm:w-52">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Bahçe, meyve, çeşit ara..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:border-emerald-500 outline-none"
              />
            </div>

            {/* Ay Seçici (D3_ortalamaHasatAy) */}
            <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-700">
              <span className="text-[11px] font-bold text-slate-400">Ay:</span>
              <select
                value={selectedMonth}
                onChange={e => setSelectedMonth(e.target.value)}
                className="bg-transparent text-xs font-bold text-emerald-300 outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-white">Tüm Aylar</option>
                <option value="Mayıs" className="bg-slate-900 text-white">Mayıs</option>
                <option value="Haziran" className="bg-slate-900 text-white">Haziran</option>
                <option value="Temmuz" className="bg-slate-900 text-white">Temmuz</option>
                <option value="Ağustos" className="bg-slate-900 text-white">Ağustos</option>
                <option value="Eylül" className="bg-slate-900 text-white">Eylül</option>
                <option value="Ekim" className="bg-slate-900 text-white">Ekim</option>
              </select>
            </div>

            {/* Hafta Aralığı Seçici (1-52) */}
            <div className="flex items-center gap-1 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-700 text-xs">
              <span className="text-[11px] font-bold text-slate-400">Hafta:</span>
              <input
                type="number"
                min="1"
                max="52"
                placeholder="1"
                value={selectedWeekRange.start ?? ''}
                onChange={e => setSelectedWeekRange(prev => ({ ...prev, start: e.target.value ? Number(e.target.value) : null }))}
                className="w-10 bg-slate-900 border border-slate-700 rounded-md px-1 py-0.5 text-center text-xs font-bold text-amber-300 outline-none focus:border-amber-400"
                title="Başlangıç Hafta No (1-52)"
              />
              <span className="text-slate-500 font-bold">-</span>
              <input
                type="number"
                min="1"
                max="52"
                placeholder="52"
                value={selectedWeekRange.end ?? ''}
                onChange={e => setSelectedWeekRange(prev => ({ ...prev, end: e.target.value ? Number(e.target.value) : null }))}
                className="w-10 bg-slate-900 border border-slate-700 rounded-md px-1 py-0.5 text-center text-xs font-bold text-amber-300 outline-none focus:border-amber-400"
                title="Bitiş Hafta No (1-52)"
              />
              {(selectedWeekRange.start !== null || selectedWeekRange.end !== null) && (
                <button
                  type="button"
                  onClick={() => setSelectedWeekRange({ start: null, end: null })}
                  className="text-rose-400 hover:text-rose-300 text-[10px] ml-0.5 font-bold cursor-pointer"
                  title="Hafta filtresini temizle"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Bahçe Akıllı Filtre Butonları (Üzerinde Çeşit, Tonaj ve Ort. Gün Toplamları) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {smartOrchardFilterTotals.map(orch => {
            const isSelected = selectedBahce === orch.key;
            return (
              <button
                key={orch.key}
                type="button"
                onClick={() => setSelectedBahce(orch.key)}
                className={`p-2.5 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-gradient-to-br from-emerald-600/30 via-teal-600/20 to-slate-900 border-emerald-400 ring-1 ring-emerald-400/50 shadow-md'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className={`text-xs font-black ${isSelected ? 'text-emerald-300' : 'text-white'}`}>
                    {orch.label}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono font-bold text-slate-300">
                    {orch.count} çeşit
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-amber-300 font-bold" title="Yönetim Bütçe Plan Toplamı">
                    Plan: {orch.budgetTon.toLocaleString('tr-TR')} T
                  </span>
                  <span className="text-emerald-400 font-bold" title="Delilnama Onaylı Ham Tonaj">
                    Ham: {orch.delilnamaTon.toLocaleString('tr-TR')} T
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Meyve Türü Akıllı Filtre Butonları (Üzerinde Çeşit ve Tonaj Toplamları) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5">
          {smartFruitFilterTotals.map(fr => {
            const isSelected = selectedMeyve === fr.key;
            return (
              <button
                key={fr.key}
                type="button"
                onClick={() => setSelectedMeyve(fr.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-400 shadow-md'
                    : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <span>{fr.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                    isSelected ? 'bg-black/30 text-indigo-100' : 'bg-slate-800 text-amber-300'
                  }`}
                >
                  {fr.count} • {fr.budgetTon}T
                </span>
              </button>
            );
          })}

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="ml-auto bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-200 shrink-0"
          >
            <option value="ALL">Tüm Hasat Statüleri</option>
            {MIWE_2026_STATUS_OPTIONS.map(st => (
              <option key={st.value} value={st.value}>
                {st.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 3. SEÇİLİ FİLTREYE GÖRE CANLI HASAT ANALİZİ VE GÜN SAYISI KARTLARI (Kutu Analizi Yerine) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        <div className="bg-slate-900/90 border border-amber-500/25 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Yönetim Bütçe Planı</span>
            <span className="text-amber-400 font-mono">{activeYear}</span>
          </div>
          <div className="text-xl font-black text-amber-300 font-mono mt-1">
            {kpis.totalAb3Budget.toLocaleString('tr-TR')} <span className="text-xs text-slate-400">Ton</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Seçili {kpis.totalVarieties} çeşit toplam hedefi
          </div>
        </div>

        <div className="bg-slate-900/90 border border-emerald-500/25 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Delilnama Fiili Hasat</span>
            <span className="text-emerald-400 font-mono">NET ONAYLI</span>
          </div>
          <div className="text-xl font-black text-emerald-400 font-mono mt-1">
            {kpis.totalAf3Delilnama.toLocaleString('tr-TR')} <span className="text-xs text-slate-400 font-sans font-semibold">Ton</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Sınıf dağılımı sadece bilgi amaçlıdır
          </div>
        </div>

        <div className="bg-slate-900/90 border border-cyan-500/25 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Hasat Analizi</span>
            <span className="text-cyan-400 font-mono">BAŞARI</span>
          </div>
          <div className="text-xl font-black text-cyan-300 font-mono mt-1">
            %{kpis.realizationPct}{' '}
            <span className="text-xs text-slate-400 font-sans font-semibold">Gerçekleşme</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {kpis.completedCount} / {kpis.totalVarieties} çeşit tamamlandı
          </div>
        </div>

        <div className="bg-slate-900/90 border border-violet-500/30 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Hasat Gün Sayısı</span>
            <Clock className="w-3.5 h-3.5 text-violet-400" />
          </div>
          <div className="text-xl font-black text-violet-300 font-mono mt-1">
            Ort. {kpis.avgHarvestDays} <span className="text-xs text-slate-400">Gün</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Toplam {kpis.totalHarvestDays} hasat iş günü
          </div>
        </div>

        <div className="bg-slate-900/90 border border-sky-500/25 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Günlük Hasat & İşçi</span>
            <Users className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl font-black text-sky-300 font-mono mt-1">
            {kpis.dailyAvgTon} <span className="text-xs text-slate-400">Ton/Gün</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Gereken: <strong className="text-white">{kpis.totalV3Workers.toLocaleString('tr-TR')} işçi</strong>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-indigo-500/25 rounded-2xl p-3.5 shadow-md">
          <div className="text-[10px] font-bold text-slate-400 uppercase flex justify-between">
            <span>Planlanan Kutu Adedi</span>
            <Package className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xl font-black text-indigo-300 font-mono mt-1">
            {kpis.totalX3Crates.toLocaleString('tr-TR')} <span className="text-xs text-slate-400">Kutu</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Seçili kutu tiplerine göre
          </div>
        </div>
      </div>

      {/* 4. BAHÇE BAZLI ANALİZ VE DÜNYA STANDARTLARI (KULLANICI TERCİHİYLE AÇILIR/KAPANIR) */}
      {showAdvancedPanels && (
        <div className="space-y-3 animate-in fade-in duration-200">
          <Miwe2026ConjecturePanel
            rows={filteredRows}
            activeYear={activeYear}
            sortingPolicy={sortingPolicy}
            onChangeSortingPolicy={handlePolicyChange}
          />
          <WorldStandardHarvestAnalyticsPanel
            mode="FRUIT_VEG"
            activeYear={activeYear}
            fruitRows={filteredRows}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
          />
        </div>
      )}

      {/* 5. TABLO GÖRÜNÜM ODAK SEKMELERİ (Sadeleştirilmiş ve Kullanışlı) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2 shadow-md">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            type="button"
            onClick={() => setColumnGroup('SADE_TAKVIM')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
              columnGroup === 'SADE_TAKVIM'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black shadow-md'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            ⚡ Sade Hasat Takvimi (Öncelikli)
          </button>
          <button
            type="button"
            onClick={() => setColumnGroup('COMPACT_FIT')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
              columnGroup === 'COMPACT_FIT'
                ? 'bg-teal-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            📊 Standart Matris
          </button>
          <button
            type="button"
            onClick={() => setColumnGroup('PHENOLOGY_DATES')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
              columnGroup === 'PHENOLOGY_DATES'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            🌱 Fenoloji &amp; Tarihler
          </button>
          <button
            type="button"
            onClick={() => setColumnGroup('HARVEST_ANALYSIS_WORKFORCE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
              columnGroup === 'HARVEST_ANALYSIS_WORKFORCE'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            📈 Kutu, İşçi &amp; Süre
          </button>
          <button
            type="button"
            onClick={() => setColumnGroup('ALL_COLUMNS')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
              columnGroup === 'ALL_COLUMNS'
                ? 'bg-violet-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            📋 Tüm 26 Sütun (Detaylı)
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="flex items-center bg-slate-950 p-0.5 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setViewMode('AUTO')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                viewMode === 'AUTO' ? 'bg-slate-800 text-white' : 'text-slate-400'
              }`}
            >
              Oto
            </button>
            <button
              type="button"
              onClick={() => setViewMode('SPREADSHEET')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                viewMode === 'SPREADSHEET' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              <Monitor className="w-3 h-3" />
              <span>Tablo</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('MOBILE_CARDS')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                viewMode === 'MOBILE_CARDS' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              <Smartphone className="w-3 h-3" />
              <span>Kart</span>
            </button>
          </div>

          {activeFiltersSummary.length > 0 && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/15 border border-amber-500/30 rounded-xl text-[11px] text-amber-300">
              <span className="font-bold">{activeFiltersSummary.length} filtre aktif:</span>
              <span className="truncate max-w-[150px] sm:max-w-xs">{activeFiltersSummary.join(', ')}</span>
              <button
                type="button"
                onClick={handleClearAllFilters}
                className="ml-1 text-amber-200 hover:text-white underline cursor-pointer font-bold shrink-0"
                title="Tüm filtreleri sıfırla"
              >
                ✕ Temizle
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 border border-slate-700 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>CSV İndir</span>
          </button>

          <button
            type="button"
            onClick={handleExportPdf}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 border border-slate-700 cursor-pointer"
            title="A4 formatında yazdır / PDF kaydet"
          >
            <Printer className="w-3.5 h-3.5 text-indigo-400" />
            <span>PDF / Yazdır</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 cursor-pointer"
            title="Varsayılan Verilere Sıfırla"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 5.5 TOPLU DÜZENLEME (BULK EDIT) PANELİ — KASA, STATÜ, BAHÇE, HASAT GÜNÜ VB. TOPLU DEĞİŞTİRME */}
      <div className="bg-slate-900/95 border border-indigo-500/35 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2.5 shadow-lg text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={toggleSelectAllFiltered}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold border border-slate-700 cursor-pointer"
          >
            {filteredRows.length > 0 && filteredRows.every(r => selectedRowIds.includes(r.id))
              ? '☑ Tüm Seçimi Kaldır'
              : `☐ Filtrelenenleri Seç (${filteredRows.length})`}
          </button>
          <span className="text-slate-300 font-semibold">
            Seçili Satır: <strong className="text-amber-300 font-mono">{selectedRowIds.length}</strong>
          </span>
          {selectedRowIds.length > 0 && (
            <button
              type="button"
              onClick={() => setSelectedRowIds([])}
              className="text-[11px] text-rose-300 hover:underline cursor-pointer"
            >
              Temizle
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-indigo-300 uppercase">Toplu Değiştir:</span>
          <select
            value={bulkField}
            onChange={e => {
              const f = e.target.value as any;
              setBulkField(f);
              if (f === 'CRATE') setBulkValue(crateOptions[0]?.name || '');
              else if (f === 'STATUS') setBulkValue('Test Edildi');
              else if (f === 'ORCHARD') setBulkValue(customOrchards[0] || 'Garahan');
              else if (f === 'MONTH') setBulkValue('Haziran (6)');
              else if (f === 'DAYS') setBulkValue('10');
              else if (f === 'WORKER_KG') setBulkValue('200');
            }}
            className="bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white font-bold"
          >
            <option value="CRATE">📦 Kutu / Kasa Tipi Seçimi</option>
            <option value="STATUS">🏷️ Hasat Statüsü (Test / Hasat-1 / Hasat Yok)</option>
            <option value="ORCHARD">🌳 Bahçe Adı / Üretim Bölgesi</option>
            <option value="MONTH">📅 Ortalama Hasat Ayı</option>
            <option value="DAYS">⏱️ Hasat Gün Sayısı</option>
            <option value="WORKER_KG">👷 1 İşçi Günlük Norm (Kg)</option>
          </select>

          {bulkField === 'CRATE' && (
            <select
              value={bulkValue || crateOptions[0]?.name || ''}
              onChange={e => setBulkValue(e.target.value)}
              className="bg-slate-950 border border-indigo-500/50 rounded-xl px-2.5 py-1.5 text-indigo-200 font-bold"
            >
              {crateOptions.map(c => (
                <option key={c.id} value={c.name}>
                  {c.name} ({c.capacityKg} kg)
                </option>
              ))}
            </select>
          )}

          {bulkField === 'STATUS' && (
            <select
              value={bulkValue || 'Test Edildi'}
              onChange={e => setBulkValue(e.target.value)}
              className="bg-slate-950 border border-emerald-500/50 rounded-xl px-2.5 py-1.5 text-emerald-300 font-bold"
            >
              {MIWE_2026_STATUS_OPTIONS.map(st => (
                <option key={st.value} value={st.value}>
                  {st.label}
                </option>
              ))}
            </select>
          )}

          {bulkField === 'ORCHARD' && (
            <select
              value={bulkValue || customOrchards[0] || 'Garahan'}
              onChange={e => setBulkValue(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white font-bold"
            >
              {customOrchards.map(o => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          )}

          {bulkField === 'MONTH' && (
            <select
              value={bulkValue || 'Haziran (6)'}
              onChange={e => setBulkValue(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white font-bold"
            >
              <option value="Mayıs (5)">Mayıs (5)</option>
              <option value="Haziran (6)">Haziran (6)</option>
              <option value="Temmuz (7)">Temmuz (7)</option>
              <option value="Ağustos (8)">Ağustos (8)</option>
              <option value="Eylül (9)">Eylül (9)</option>
              <option value="Ekim (10)">Ekim (10)</option>
            </select>
          )}

          {(bulkField === 'DAYS' || bulkField === 'WORKER_KG') && (
            <input
              type="number"
              value={bulkValue}
              onChange={e => setBulkValue(e.target.value)}
              placeholder={bulkField === 'DAYS' ? 'Gün (Örn: 12)' : 'Kg (Örn: 220)'}
              className="w-28 bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-amber-300 font-mono font-bold"
            />
          )}

          <button
            type="button"
            onClick={handleApplyBulkEdit}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-emerald-500 hover:from-indigo-400 hover:to-emerald-400 text-slate-950 font-black cursor-pointer shadow-md"
          >
            Seçili ({selectedRowIds.length}) Satıra Uygula
          </button>
        </div>
      </div>

      {/* 6. MASAÜSTÜ MODERN E-TABLO (TAM ADLANDIRILMIŞ SÜTUNLAR) */}
      {(viewMode === 'SPREADSHEET' || viewMode === 'AUTO') && (
        <div
          className={`bg-slate-900/95 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden miwe-printable-table ${
            viewMode === 'AUTO' ? 'hidden md:block' : 'block'
          }`}
        >
          <div className="overflow-x-auto max-h-[660px]">
            <table className="w-full text-left text-[11px] border-collapse">
              <thead className="bg-slate-950 text-slate-300 sticky top-0 z-20 border-b border-slate-800">
                <tr>
                  <th className="p-2 w-12 text-center font-mono text-slate-500 bg-slate-950 sticky left-0 z-30 border-r border-slate-800">
                    <div className="flex items-center justify-center gap-1">
                      <input
                        type="checkbox"
                        checked={
                          filteredRows.length > 0 &&
                          filteredRows.every(r => selectedRowIds.includes(r.id))
                        }
                        onChange={toggleSelectAllFiltered}
                        className="accent-emerald-500 cursor-pointer"
                        title="Tümünü Seç / Kaldır"
                      />
                      <span>#</span>
                    </div>
                  </th>
                  <th className="p-2 min-w-[120px] bg-slate-950 sticky left-9 z-30 border-r border-slate-800">
                    <div className="font-bold text-white">Bahçe Adı</div>
                    <div className="text-[9px] text-slate-400 font-normal">Üretim Bölgesi</div>
                  </th>
                  <th className="p-2 min-w-[90px] bg-slate-950 sticky left-[156px] z-30 border-r border-slate-800">
                    <div className="font-bold text-amber-300">Meyve</div>
                    <div className="text-[9px] text-slate-400 font-normal">Ürün Türü</div>
                  </th>
                  <th className="p-2 min-w-[135px] bg-slate-950 border-r border-slate-800">
                    <div className="font-bold text-white">Meyve Çeşidi (Grant)</div>
                    <div className="text-[9px] text-slate-400 font-normal">Görnüşi / Çeşit</div>
                  </th>

                  {/* SADE VE KULLANIŞLI TAKVİM SÜTUNLARI VEYA DETAYLI MOD */}
                  {columnGroup === 'SADE_TAKVIM' ? (
                    <>
                      <th className="p-2 min-w-[95px] border-r border-slate-800 bg-indigo-950/25">
                        <div className="font-bold text-indigo-300">Ortalama Ay</div>
                        <div className="text-[9px] text-slate-400 font-normal">Sezon Ayı</div>
                      </th>
                      <th
                        onClick={() =>
                          setSortBy(
                            sortBy === 'HARVEST_DATE_ASC' ? 'HARVEST_DATE_DESC' : 'HARVEST_DATE_ASC'
                          )
                        }
                        className="p-2 min-w-[110px] border-r border-slate-800 bg-indigo-950/50 cursor-pointer hover:bg-indigo-900/50 transition"
                        title="Tarihe göre sıralamak için tıklayın"
                      >
                        <div className="font-bold text-indigo-200 flex items-center gap-1">
                          <span>Tahmini Tarih</span>
                          <ArrowUpDown className="w-3 h-3 text-indigo-400" />
                        </div>
                        <div className="text-[9px] text-indigo-300/80 font-normal">
                          {activeYear} Optimal
                        </div>
                      </th>
                      <th className="p-2 min-w-[85px] text-center border-r border-slate-800 bg-violet-950/35">
                        <div className="font-bold text-violet-200">Süre (Gün)</div>
                        <div className="text-[9px] text-violet-400 font-normal">Hasat Günü</div>
                      </th>
                      <th className="p-2 min-w-[95px] text-right border-r border-slate-800 bg-amber-950/30">
                        <div className="font-bold text-amber-300">Bütçe Hedefi</div>
                        <div className="text-[9px] text-amber-400/80 font-normal">Plan (Ton)</div>
                      </th>
                      <th className="p-2 min-w-[105px] text-right border-r border-slate-800 bg-emerald-950/35">
                        <div className="font-bold text-emerald-300">Fiili Hasat</div>
                        <div className="text-[9px] text-emerald-400/80 font-normal">Delilnama Ton</div>
                      </th>
                      <th className="p-2 min-w-[85px] text-center border-r border-slate-800 bg-cyan-950/30">
                        <div className="font-bold text-cyan-200">Gerçekleşme</div>
                        <div className="text-[9px] text-cyan-400/80 font-normal">Başarı %</div>
                      </th>
                      <th className="p-2 min-w-[105px] text-right border-r border-slate-800 bg-sky-950/25">
                        <div className="font-bold text-sky-200">Günlük &amp; İşçi</div>
                        <div className="text-[9px] text-slate-400 font-normal">T/g · Kişi</div>
                      </th>
                      <th className="p-2 min-w-[145px] border-r border-slate-800 bg-slate-900">
                        <div className="font-bold text-white">Hasat Statüsü</div>
                        <div className="text-[9px] text-slate-400 font-normal">Güncel Durum</div>
                      </th>
                    </>
                  ) : (
                    <>
                      {/* FENOLOJİ VE TARİH SÜTUNLARI */}
                      {showCol('PHENOLOGY') && (
                        <>
                          <th className="p-2 min-w-[90px] border-r border-slate-800 bg-emerald-950/20">
                            <div className="font-bold text-emerald-300">Ortalama Hasat Ayı</div>
                            <div className="text-[9px] text-slate-400 font-normal">Sezon Ayı</div>
                          </th>
                          <th className="p-2 min-w-[95px] border-r border-slate-800 bg-emerald-950/30">
                            <div className="font-bold text-emerald-200">%75 Çiçeklenme</div>
                            <div className="text-[9px] text-emerald-400/80 font-normal">BBCH 65 Tarihi</div>
                          </th>
                          <th className="p-2 min-w-[95px] border-r border-slate-800 bg-teal-950/30">
                            <div className="font-bold text-teal-200">Seyreltme Başlama</div>
                            <div className="text-[9px] text-teal-400/80 font-normal">BBCH 71 Tarihi</div>
                          </th>
                        </>
                      )}

                  {showCol('EXTENDED_ONLY') && (
                    <>
                      <th className="p-2 min-w-[90px] border-r border-slate-800 bg-teal-950/20">
                        <div className="font-bold text-teal-200">Seyreltme Bitiş</div>
                        <div className="text-[9px] text-slate-400 font-normal">ve Gün Süresi</div>
                      </th>
                      <th className="p-2 min-w-[85px] border-r border-slate-800 bg-blue-950/20">
                        <div className="font-bold text-slate-300">2024 & 2025 Hasat</div>
                        <div className="text-[9px] text-slate-400 font-normal">Geçmiş Referans</div>
                      </th>
                      <th className="p-2 min-w-[75px] text-center border-r border-slate-800 bg-blue-950/20">
                        <div className="font-bold text-blue-300">BBCH Gün</div>
                        <div className="text-[9px] text-slate-400 font-normal">Çiçek→Hasat</div>
                      </th>
                    </>
                  )}

                  {/* OPTİMAL HASAT TARİHİ VE 2027 BAŞLAMA */}
                  {showCol('PHENOLOGY') && (
                    <>
                      <th
                        onClick={() =>
                          setSortBy(
                            sortBy === 'HARVEST_DATE_ASC' ? 'HARVEST_DATE_DESC' : 'HARVEST_DATE_ASC'
                          )
                        }
                        className="p-2 min-w-[100px] border-r border-slate-800 bg-indigo-950/40 cursor-pointer hover:bg-indigo-900/50 transition"
                        title="Tarihe göre sıralamak için tıklayın"
                      >
                        <div className="font-bold text-indigo-200 flex items-center gap-1">
                          <span>Tahmini Hasat Tarihi</span>
                          <ArrowUpDown className="w-3 h-3 text-indigo-400" />
                        </div>
                        <div className="text-[9px] text-indigo-300/80 font-normal">
                          {activeYear} Optimal Pencere
                        </div>
                      </th>
                      <th className="p-2 min-w-[95px] border-r border-slate-800 bg-cyan-950/30">
                        <div className="font-bold text-cyan-200">2027 Hasat Başlama</div>
                        <div className="text-[9px] text-cyan-400/80 font-normal">2027 Hedef Tarih</div>
                      </th>
                    </>
                  )}

                  {/* HASAT ANALİZİ, GÜN SAYISI, İŞÇİ VE KUTU PLANI */}
                  {showCol('ANALYSIS_WORKFORCE') && (
                    <>
                      <th className="p-2 min-w-[80px] text-center border-r border-slate-800 bg-violet-950/35">
                        <div className="font-bold text-violet-200">Hasat Gün Sayısı</div>
                        <div className="text-[9px] text-violet-400 font-normal">Hasat Süresi</div>
                      </th>
                      <th className="p-2 min-w-[85px] text-right border-r border-slate-800 bg-violet-950/20">
                        <div className="font-bold text-violet-200">Günlük Hasat</div>
                        <div className="text-[9px] text-slate-400 font-normal">Ort. Ton/Gün</div>
                      </th>
                      <th className="p-2 min-w-[75px] text-right border-r border-slate-800 bg-sky-950/25">
                        <div className="font-bold text-sky-200">1 İşçi Kg/Gün</div>
                        <div className="text-[9px] text-slate-400 font-normal">Günlük Norm</div>
                      </th>
                      <th className="p-2 min-w-[75px] text-right border-r border-slate-800 bg-sky-950/35">
                        <div className="font-bold text-sky-300">Gereken İşçi</div>
                        <div className="text-[9px] text-slate-400 font-normal">Kişi Sayısı</div>
                      </th>
                      <th className="p-2 min-w-[145px] border-r border-slate-800 bg-indigo-950/25">
                        <div className="font-bold text-indigo-200">Seçilen Kutu Tipi</div>
                        <div className="text-[9px] text-indigo-400 font-normal">Planda Kutu Seçimi</div>
                      </th>
                      <th className="p-2 min-w-[85px] text-right border-r border-slate-800 bg-indigo-950/35">
                        <div className="font-bold text-indigo-200">Kutu Sayısı</div>
                        <div className="text-[9px] text-slate-400 font-normal">Gereken Adet</div>
                      </th>
                      <th className="p-2 min-w-[90px] text-right border-r border-slate-800 bg-amber-950/30">
                        <div className="font-bold text-amber-300">Yönetim Bütçe</div>
                        <div className="text-[9px] text-amber-400/80 font-normal">Planlanan (Ton)</div>
                      </th>
                      <th className="p-2 min-w-[95px] text-right border-r border-slate-800 bg-emerald-950/35">
                        <div className="font-bold text-emerald-300">Delilnama Ham</div>
                        <div className="text-[9px] text-emerald-400/80 font-normal">Onaylı Ham (Ton)</div>
                      </th>
                      <th className="p-2 min-w-[95px] text-center border-r border-slate-800 bg-cyan-950/30">
                        <div className="font-bold text-cyan-200">Hasat Analizi %</div>
                        <div className="text-[9px] text-cyan-400/80 font-normal">Bütçe Gerçekleşme</div>
                      </th>
                      <th className="p-2 min-w-[150px] border-r border-slate-800 bg-slate-900">
                        <div className="font-bold text-white">Hasat Statüsü</div>
                        <div className="text-[9px] text-slate-400 font-normal">Güncel Durum</div>
                      </th>
                    </>
                  )}
                </>
              )}

                  <th className="p-2 w-16 text-center bg-slate-950 sticky right-0 z-30 border-l border-slate-800">
                    İşlem
                  </th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-800/60">
                {filteredRows.map(row => {
                  const statusMeta =
                    MIWE_2026_STATUS_OPTIONS.find(s => s.value === row.AG3_hasatStatusu) ||
                    MIWE_2026_STATUS_OPTIONS[0];
                  return (
                    <tr
                      key={row.id}
                      className={`hover:bg-indigo-950/25 transition group ${
                        selectedRowIds.includes(row.id) ? 'bg-indigo-950/30' : ''
                      }`}
                    >
                      <td className="p-1.5 text-center font-mono text-slate-500 bg-slate-950/90 sticky left-0 z-10 border-r border-slate-800">
                        <div className="flex items-center justify-center gap-1">
                          <input
                            type="checkbox"
                            checked={selectedRowIds.includes(row.id)}
                            onChange={() => toggleSelectRow(row.id)}
                            className="accent-emerald-500 cursor-pointer"
                          />
                          <span>{row.rowNumber}</span>
                        </div>
                      </td>

                      {/* Bahçe Adı */}
                      <td className="p-1 bg-slate-900 group-hover:bg-slate-800 sticky left-9 z-10 border-r border-slate-800">
                        <input
                          type="text"
                          value={row.A3_bahce}
                          onChange={e => updateCell(row.id, 'A3_bahce', e.target.value)}
                          className="w-full bg-transparent px-1.5 py-0.5 rounded text-white font-semibold focus:bg-slate-950 outline-none"
                        />
                      </td>

                      {/* Meyve Türü */}
                      <td className="p-1 bg-slate-900 group-hover:bg-slate-800 sticky left-[156px] z-10 border-r border-slate-800">
                        <input
                          type="text"
                          value={row.B3_meyve}
                          onChange={e => updateCell(row.id, 'B3_meyve', e.target.value)}
                          className="w-full bg-transparent px-1.5 py-0.5 rounded text-amber-300 font-medium focus:bg-slate-950 outline-none"
                        />
                      </td>

                      {/* Meyve Çeşidi (Grant) */}
                      <td className="p-1 border-r border-slate-800/60">
                        <input
                          type="text"
                          value={row.C3_meyveGrant}
                          onChange={e => updateCell(row.id, 'C3_meyveGrant', e.target.value)}
                          className="w-full bg-transparent px-1.5 py-0.5 rounded text-white font-bold focus:bg-slate-950 outline-none"
                        />
                      </td>

                      {/* SADE VE KULLANIŞLI TAKVİM GÖRÜNÜMÜ VEYA DETAYLI MOD */}
                      {columnGroup === 'SADE_TAKVIM' ? (
                        <>
                          {/* Ortalama Hasat Ayı */}
                          <td className="p-1 border-r border-slate-800/60">
                            <input
                              type="text"
                              value={row.D3_ortalamaHasatAy}
                              onChange={e => updateCell(row.id, 'D3_ortalamaHasatAy', e.target.value)}
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-slate-300 focus:bg-slate-950 outline-none text-xs"
                            />
                          </td>

                          {/* Tahmini Hasat Tarihi */}
                          <td className="p-1 border-r border-slate-800/60 font-mono bg-indigo-950/15">
                            <input
                              type="text"
                              value={row.R3_tahminiHasatTarihi}
                              onChange={e => updateCell(row.id, 'R3_tahminiHasatTarihi', e.target.value)}
                              placeholder="GG.AA.YYYY"
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-indigo-300 font-bold focus:bg-slate-950 outline-none text-xs"
                            />
                          </td>

                          {/* Hasat Gün Sayısı */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-center bg-violet-950/15">
                            <div className="flex items-center justify-center gap-0.5">
                              <input
                                type="number"
                                min="1"
                                max="90"
                                value={row.hasatGunSayisi || 10}
                                onChange={e => updateCell(row.id, 'hasatGunSayisi', e.target.value)}
                                className="w-10 bg-transparent text-center py-0.5 rounded text-violet-300 font-bold focus:bg-slate-950 outline-none text-xs"
                              />
                              <span className="text-[10px] text-violet-400">g</span>
                            </div>
                          </td>

                          {/* Yönetim Bütçe Planı (Ton) */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <input
                              type="number"
                              step="0.1"
                              value={row.AB3_yonetimButcePlanTon ?? ''}
                              onChange={e => updateCell(row.id, 'AB3_yonetimButcePlanTon', e.target.value)}
                              placeholder="—"
                              className="w-full bg-transparent text-right px-1.5 py-0.5 rounded text-amber-300 font-bold focus:bg-slate-950 outline-none text-xs"
                            />
                          </td>

                          {/* Delilnama Fiili Hasat (Ton) */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <input
                              type="number"
                              step="0.1"
                              value={row.AF3_delilnamaHamTon ?? ''}
                              onChange={e => updateCell(row.id, 'AF3_delilnamaHamTon', e.target.value)}
                              placeholder="—"
                              className="w-full bg-transparent text-right px-1.5 py-0.5 rounded text-emerald-400 font-black focus:bg-slate-950 outline-none text-xs"
                            />
                          </td>

                          {/* Hasat Analizi % */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-center bg-cyan-950/10">
                            <div className="px-1.5">
                              {row.butceGerceklesmePct > 0 ? (
                                <span
                                  className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black ${
                                    row.butceGerceklesmePct >= 95
                                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                  }`}
                                >
                                  %{row.butceGerceklesmePct}
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-500">—</span>
                              )}
                            </div>
                          </td>

                          {/* Günlük Tonaj & İşçi */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right text-xs">
                            <div className="text-sky-300 font-bold">
                              {row.gunlukOrtalamaHasatTon > 0 ? `${row.gunlukOrtalamaHasatTon} T/g` : '—'}
                            </div>
                            <div className="text-[9px] text-slate-400">{row.V3_gerekenIsciSayisi || 0} işçi</div>
                          </td>

                          {/* Hasat Statüsü */}
                          <td className="p-1 border-r border-slate-800/60">
                            <select
                              value={row.AG3_hasatStatusu}
                              onChange={e => updateCell(row.id, 'AG3_hasatStatusu', e.target.value as Miwe2026HarvestStatus)}
                              className={`w-full text-[11px] font-bold rounded-lg px-1.5 py-1 border outline-none cursor-pointer ${statusMeta.badgeColor}`}
                            >
                              {MIWE_2026_STATUS_OPTIONS.map(opt => (
                                <option key={opt.value} value={opt.value} className="bg-slate-900 text-white">
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          </td>
                        </>
                      ) : (
                        <>
                          {/* FENOLOJİ VE TARİHLER */}
                          {showCol('PHENOLOGY') && (
                            <>
                              <td className="p-1 border-r border-slate-800/60">
                                <input
                                  type="text"
                                  value={row.D3_ortalamaHasatAy}
                                  onChange={e => updateCell(row.id, 'D3_ortalamaHasatAy', e.target.value)}
                                  className="w-full bg-transparent px-1.5 py-0.5 rounded text-slate-300 focus:bg-slate-950 outline-none"
                                />
                              </td>
                          <td className="p-1 border-r border-slate-800/60 font-mono">
                            <input
                              type="text"
                              value={row.F3_bbch65CiceklemeTarihi}
                              onChange={e =>
                                updateCell(row.id, 'F3_bbch65CiceklemeTarihi', e.target.value)
                              }
                              placeholder="GG.AA.YYYY"
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-emerald-300 focus:bg-slate-950 outline-none"
                            />
                          </td>
                          <td className="p-1 border-r border-slate-800/60 font-mono">
                            <input
                              type="text"
                              value={row.G3_bbch71SeyreltmeBaslama}
                              onChange={e =>
                                updateCell(row.id, 'G3_bbch71SeyreltmeBaslama', e.target.value)
                              }
                              placeholder="Seyreltme"
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-teal-300 focus:bg-slate-950 outline-none"
                            />
                          </td>
                        </>
                      )}

                      {showCol('EXTENDED_ONLY') && (
                        <>
                          <td className="p-1 border-r border-slate-800/60 font-mono text-xs">
                            <div className="flex items-center gap-1 px-1">
                              <input
                                type="text"
                                value={row.H3_seyreltmeBitmeTarihi}
                                onChange={e =>
                                  updateCell(row.id, 'H3_seyreltmeBitmeTarihi', e.target.value)
                                }
                                placeholder="Bitiş"
                                className="w-20 bg-transparent text-teal-200 focus:bg-slate-950 outline-none"
                              />
                              {row.I3_seyreltmeSuresiGun && (
                                <span className="text-[10px] text-slate-400">
                                  ({row.I3_seyreltmeSuresiGun}g)
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-1 border-r border-slate-800/60 font-mono text-[10px] text-slate-400 px-1.5">
                            <div>24: {row.L3_hasat2024Tarihi || '—'}</div>
                            <div>25: {row.M3_hasat2025Tarihi || '—'}</div>
                          </td>
                          <td className="p-1 border-r border-slate-800/60 font-mono text-center text-blue-300">
                            {row.P3_bbchMinGun}-{row.Q3_bbchMaxGun}g
                          </td>
                        </>
                      )}

                      {showCol('PHENOLOGY') && (
                        <>
                          <td className="p-1 border-r border-slate-800/60 font-mono bg-indigo-950/15">
                            <input
                              type="text"
                              value={row.R3_tahminiHasatTarihi}
                              onChange={e =>
                                updateCell(row.id, 'R3_tahminiHasatTarihi', e.target.value)
                              }
                              placeholder="GG.AA.YYYY"
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-indigo-300 font-bold focus:bg-slate-950 outline-none"
                            />
                          </td>
                          <td className="p-1 border-r border-slate-800/60 font-mono">
                            <input
                              type="text"
                              value={row.T3_hasat2027Baslama}
                              onChange={e =>
                                updateCell(row.id, 'T3_hasat2027Baslama', e.target.value)
                              }
                              placeholder="2027 Hedef"
                              className="w-full bg-transparent px-1.5 py-0.5 rounded text-cyan-300 font-semibold focus:bg-slate-950 outline-none"
                            />
                          </td>
                        </>
                      )}

                      {/* HASAT ANALİZİ, GÜN SAYISI, İŞÇİ VE KUTU PLANI */}
                      {showCol('ANALYSIS_WORKFORCE') && (
                        <>
                          {/* Hasat Gün Sayısı */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-center bg-violet-950/15">
                            <div className="flex items-center justify-center gap-0.5">
                              <input
                                type="number"
                                min="1"
                                max="90"
                                value={row.hasatGunSayisi || 10}
                                onChange={e =>
                                  updateCell(row.id, 'hasatGunSayisi', e.target.value)
                                }
                                className="w-12 bg-transparent text-center py-0.5 rounded text-violet-300 font-bold focus:bg-slate-950 outline-none"
                              />
                              <span className="text-[10px] text-violet-400">gün</span>
                            </div>
                          </td>

                          {/* Günlük Ortalama Hasat Tonajı */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <span className="px-1.5 text-violet-200 font-semibold">
                              {row.gunlukOrtalamaHasatTon > 0
                                ? `${row.gunlukOrtalamaHasatTon} T/g`
                                : '—'}
                            </span>
                          </td>

                          {/* 1 İşçi Günlük Kg */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <input
                              type="number"
                              value={row.U3_gunlukIsciGucuKg || ''}
                              onChange={e =>
                                updateCell(row.id, 'U3_gunlukIsciGucuKg', e.target.value)
                              }
                              className="w-full bg-transparent text-right px-1.5 py-0.5 rounded text-sky-300 focus:bg-slate-950 outline-none"
                            />
                          </td>

                          {/* Gereken İşçi Sayısı */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right bg-sky-950/10">
                            <span className="px-1.5 font-bold text-sky-300">
                              {row.V3_gerekenIsciSayisi
                                ? row.V3_gerekenIsciSayisi.toLocaleString('tr-TR')
                                : '0'}
                            </span>
                          </td>

                          {/* Planda Seçilen Kutu Tipi & Kapasitesi */}
                          <td className="p-1 border-r border-slate-800/60">
                            <div className="flex items-center gap-1">
                              <select
                                value={row.secilenKutuAdi || ''}
                                onChange={e =>
                                  updateCell(row.id, 'secilenKutuAdi', e.target.value)
                                }
                                className="w-full bg-slate-950/80 border border-slate-800 rounded px-1.5 py-0.5 text-[10px] text-indigo-200 outline-none cursor-pointer truncate"
                              >
                                {crateOptions.map(c => (
                                  <option key={c.id} value={c.name} className="bg-slate-900 text-white">
                                    {c.name}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </td>

                          {/* Gereken Kutu Adedi */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right bg-indigo-950/15">
                            <div className="px-1.5">
                              <span className="font-bold text-indigo-300">
                                {row.X3_gerekenKutu50x30Adet
                                  ? row.X3_gerekenKutu50x30Adet.toLocaleString('tr-TR')
                                  : '0'}
                              </span>
                              <span className="block text-[9px] text-slate-400">
                                ({row.W3_seftaliKutu50x30Kg} kg/kutu)
                              </span>
                            </div>
                          </td>

                          {/* Yönetim Bütçe Planı (Ton) */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <input
                              type="number"
                              step="0.1"
                              value={row.AB3_yonetimButcePlanTon ?? ''}
                              onChange={e =>
                                updateCell(row.id, 'AB3_yonetimButcePlanTon', e.target.value)
                              }
                              placeholder="—"
                              className="w-full bg-transparent text-right px-1.5 py-0.5 rounded text-amber-300 font-bold focus:bg-slate-950 outline-none"
                            />
                          </td>

                          {/* Delilnama Onaylı Ham Meyve (Ton) */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-right">
                            <input
                              type="number"
                              step="0.1"
                              value={row.AF3_delilnamaHamTon ?? ''}
                              onChange={e =>
                                updateCell(row.id, 'AF3_delilnamaHamTon', e.target.value)
                              }
                              placeholder="—"
                              className="w-full bg-transparent text-right px-1.5 py-0.5 rounded text-emerald-400 font-black focus:bg-slate-950 outline-none"
                            />
                          </td>

                          {/* Hasat Analizi % (Bütçe Gerçekleşme Oranı) */}
                          <td className="p-1 border-r border-slate-800/60 font-mono text-center bg-cyan-950/10">
                            <div className="px-1.5">
                              {row.butceGerceklesmePct > 0 ? (
                                <span
                                  className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black ${
                                    row.butceGerceklesmePct >= 95
                                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                  }`}
                                >
                                  %{row.butceGerceklesmePct}
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-500">—</span>
                              )}
                            </div>
                          </td>

                          {/* Hasat Statüsü */}
                          <td className="p-1 border-r border-slate-800/60">
                            <select
                              value={row.AG3_hasatStatusu}
                              onChange={e =>
                                updateCell(
                                  row.id,
                                  'AG3_hasatStatusu',
                                  e.target.value as Miwe2026HarvestStatus
                                )
                              }
                              className={`w-full text-[11px] font-bold rounded-lg px-1.5 py-1 border outline-none cursor-pointer ${statusMeta.badgeColor}`}
                            >
                              {MIWE_2026_STATUS_OPTIONS.map(opt => (
                                <option
                                  key={opt.value}
                                  value={opt.value}
                                  className="bg-slate-900 text-white"
                                >
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          </td>
                        </>
                      )}
                    </>
                  )}

                      <td className="p-1 text-center bg-slate-950/90 sticky right-0 z-10 border-l border-slate-800 flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(row)}
                          className="p-1 rounded text-slate-400 hover:text-indigo-300"
                          title="Tüm Bilgileri Düzenle"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(row.id)}
                          className="p-1 rounded text-slate-400 hover:text-rose-400"
                          title="Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. MOBİL KART VE HIZLI DOLDURMA GÖRÜNÜMÜ */}
      {(viewMode === 'MOBILE_CARDS' || viewMode === 'AUTO') && (
        <div className={`space-y-2.5 ${viewMode === 'AUTO' ? 'block md:hidden' : 'block'}`}>
          {filteredRows.map(row => {
            const statusMeta =
              MIWE_2026_STATUS_OPTIONS.find(s => s.value === row.AG3_hasatStatusu) ||
              MIWE_2026_STATUS_OPTIONS[0];
            return (
              <div
                key={row.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 shadow-md"
              >
                <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2">
                  <div>
                    <div className="text-xs text-slate-400 font-mono">
                      #{row.rowNumber} · <strong className="text-white">{row.A3_bahce}</strong> ·{' '}
                      <strong className="text-amber-300">{row.B3_meyve}</strong>
                    </div>
                    <h4 className="text-sm font-black text-white mt-0.5">{row.C3_meyveGrant}</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(row)}
                    className="px-3 py-1 rounded-xl bg-indigo-600 text-white text-xs font-bold flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Düzenle</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono bg-slate-950/70 p-2.5 rounded-xl">
                  <div>
                    <div className="text-[10px] text-slate-400">%75 Çiçeklenme</div>
                    <div className="text-emerald-300 font-bold">
                      {row.F3_bbch65CiceklemeTarihi || '—'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Tahmini Hasat</div>
                    <div className="text-indigo-300 font-bold">
                      {row.R3_tahminiHasatTarihi || '—'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Hasat Gün & Hız</div>
                    <div className="text-violet-300 font-bold">
                      {row.hasatGunSayisi} gün · {row.gunlukOrtalamaHasatTon} T/g
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Bütçe / Delilnama</div>
                    <div className="text-amber-300 font-bold">
                      {row.AB3_yonetimButcePlanTon ?? '—'}T /{' '}
                      <span className="text-emerald-400">{row.AF3_delilnamaHamTon ?? '—'}T</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <span className="text-[11px] text-slate-400">
                    Kutu: <strong className="text-indigo-300">{row.secilenKutuAdi}</strong> (
                    {row.X3_gerekenKutu50x30Adet} ad.)
                  </span>
                  <select
                    value={row.AG3_hasatStatusu}
                    onChange={e =>
                      updateCell(row.id, 'AG3_hasatStatusu', e.target.value as Miwe2026HarvestStatus)
                    }
                    className={`text-xs font-bold rounded-lg px-2.5 py-1 border ${statusMeta.badgeColor}`}
                  >
                    {MIWE_2026_STATUS_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value} className="bg-slate-900 text-white">
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 8. PLANDA KUTU EKLEME & YÖNETİM MODALI */}
      {isCrateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-2xl w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-black text-white">
                    Plana Kutu Tipi Ekle & Kutu Kapasiteleri Yönetimi
                  </h3>
                  <p className="text-xs text-slate-400">
                    2026 ve 2027 hasat planlarında kullanılacak kutu ölçülerini ve aldığı kg miktarlarını tanımlayın
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCrateModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={handleAddCrateOption}
              className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-3 text-xs"
            >
              <div className="font-bold text-amber-300">➕ Yeni Kutu Çeşidi Tanımla</div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Kutu Adı / Tipi</label>
                  <input
                    type="text"
                    required
                    value={newCrateName}
                    onChange={e => setNewCrateName(e.target.value)}
                    placeholder="Örn: 50×30 Çift Sıra Şeftali Kutusu"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Ölçü (En×Boy)</label>
                  <input
                    type="text"
                    value={newCrateDims}
                    onChange={e => setNewCrateDims(e.target.value)}
                    placeholder="50×30 cm"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-amber-300 mb-1">Kapasite (Kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={newCrateKg}
                    onChange={e => setNewCrateKg(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-amber-500/50 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold font-mono"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between gap-2 pt-1">
                <input
                  type="text"
                  value={newCrateFruits}
                  onChange={e => setNewCrateFruits(e.target.value)}
                  placeholder="Uygun meyveler: Şetdaly, Nektarin, Alma..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-300"
                />
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer"
                >
                  + Plana Ekle
                </button>
              </div>
            </form>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-800 bg-slate-950/50 rounded-xl border border-slate-800">
              {crateOptions.map(c => (
                <div key={c.id} className="p-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{c.name}</div>
                    <div className="text-[11px] text-slate-400">
                      Ölçü: {c.dimensions} • Kapasite:{' '}
                      <strong className="text-amber-300">{c.capacityKg} kg</strong> • Meyveler:{' '}
                      {c.defaultFruits}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeleteCrateOption(c.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 9. 2026 & 2027 DETAYLI PLAN EKLEME / DÜZENLEME VE GOOGLE SHEET GÖNDERİM MODALI */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-4xl w-full p-5 space-y-4 max-h-[92vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-black ${
                      modalTargetYear === '2027'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-emerald-500 text-slate-950'
                    }`}
                  >
                    {modalTargetYear} PLANLAMA PANELİ
                  </span>
                  <h3 className="text-base font-black text-white">
                    {isAddingNew
                      ? `Yeni ${modalTargetYear} Meyve Hasat Planı Ekle`
                      : `${modalTargetYear} Satır #${formData.rowNumber} Düzenle (${formData.C3_meyveGrant})`}
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Çiçeklenme (BBCH 65), Seyreltme (BBCH 71), Tahmini Hasat Tarihi, Hasat Gün Sayısı, İşçi, Kutu ve Tonaj Bilgileri
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={e => handleSaveModal(e, false)} className="space-y-4 text-xs">
              {/* Bölüm 1: Kimlik & Zaman */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 uppercase">
                    1. Bahçe, Meyve Çeşidi (Grant) ve Ortalama Hasat Ayı
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-400">Hedef Yıl:</span>
                    <button
                      type="button"
                      onClick={() => setModalTargetYear('2026')}
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        modalTargetYear === '2026'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      2026
                    </button>
                    <button
                      type="button"
                      onClick={() => setModalTargetYear('2027')}
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        modalTargetYear === '2027'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      2027
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Bahçe Adı</label>
                    <select
                      value={formData.A3_bahce}
                      onChange={e => setFormData({ ...formData, A3_bahce: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-semibold"
                    >
                      {customOrchards.map(o => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Meyve / Sebze Türü</label>
                    <select
                      value={formData.B3_meyve}
                      onChange={e => {
                        const val = e.target.value;
                        const norm = FRUIT_CRATE_AND_WORKER_NORMS.find(n =>
                          val.toLowerCase().includes(n.product.toLowerCase())
                        );
                        setFormData(
                          recalculateMiwe2026Row(
                            {
                              ...formData,
                              B3_meyve: val,
                              U3_gunlukIsciGucuKg: norm?.defaultWorkerDailyKg || 200,
                              W3_seftaliKutu50x30Kg: norm?.w3_50x30_kg || 3.5,
                              hasatGunSayisi: norm?.defaultHarvestDays || 10
                            },
                            sortingPolicy
                          )
                        );
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold"
                    >
                      <option value="Şetdaly">Şetdaly (Şeftali)</option>
                      <option value="Nektarin">Nektarin</option>
                      <option value="Ülje">Ülje (Kiraz)</option>
                      <option value="Garaly">Garaly (Erik)</option>
                      <option value="Alma">Alma (Elma)</option>
                      <option value="Armyt">Armyt (Armut)</option>
                      <option value="Badam">Badam (Badem)</option>
                      <option value="Hurma">Hurma</option>
                      <option value="Soğan">Soğan (Kuru Soğan)</option>
                      <option value="Havuç">Havuç</option>
                      <option value="Patates">Patates</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Meyve Çeşidi (Grant / Görnüşi)</label>
                    <input
                      type="text"
                      required
                      value={formData.C3_meyveGrant}
                      onChange={e => setFormData({ ...formData, C3_meyveGrant: e.target.value })}
                      placeholder="Örn: Extreme 314, Santina..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Ortalama Hasat Ayı</label>
                    <select
                      value={formData.D3_ortalamaHasatAy}
                      onChange={e =>
                        setFormData({ ...formData, D3_ortalamaHasatAy: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                    >
                      <option value="Mayıs (5)">Mayıs (5)</option>
                      <option value="Haziran (6)">Haziran (6)</option>
                      <option value="Temmuz (7)">Temmuz (7)</option>
                      <option value="Ağustos (8)">Ağustos (8)</option>
                      <option value="Eylül (9)">Eylül (9)</option>
                      <option value="Ekim (10)">Ekim (10)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Bölüm 2: Fenoloji (BBCH 65/71) & Optimal Hasat Tarihleri */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <div className="font-bold text-indigo-400 uppercase">
                  2. %75 Çiçeklenme (BBCH 65), Seyreltme (BBCH 71) ve Optimal Hasat Tarihleri
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      %75 Çiçeklenme Tarihi (BBCH 65)
                    </label>
                    <input
                      type="text"
                      value={formData.F3_bbch65CiceklemeTarihi}
                      onChange={e =>
                        setFormData({ ...formData, F3_bbch65CiceklemeTarihi: e.target.value })
                      }
                      placeholder="GG.AA.YYYY"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Seyreltme Başlama Tarihi (BBCH 71)
                    </label>
                    <input
                      type="text"
                      value={formData.G3_bbch71SeyreltmeBaslama}
                      onChange={e =>
                        setFormData({ ...formData, G3_bbch71SeyreltmeBaslama: e.target.value })
                      }
                      placeholder="GG.AA.YYYY"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-teal-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Seyreltme Bitme Tarihi</label>
                    <input
                      type="text"
                      value={formData.H3_seyreltmeBitmeTarihi}
                      onChange={e =>
                        setFormData({ ...formData, H3_seyreltmeBitmeTarihi: e.target.value })
                      }
                      placeholder="GG.AA.YYYY"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-teal-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Seyreltme Süresi (Gün)</label>
                    <input
                      type="text"
                      value={formData.I3_seyreltmeSuresiGun}
                      onChange={e =>
                        setFormData({ ...formData, I3_seyreltmeSuresiGun: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">2024 Hasat Başlama Tarihi</label>
                    <input
                      type="text"
                      value={formData.L3_hasat2024Tarihi}
                      onChange={e =>
                        setFormData({ ...formData, L3_hasat2024Tarihi: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">2025 Hasat Başlama Tarihi</label>
                    <input
                      type="text"
                      value={formData.M3_hasat2025Tarihi}
                      onChange={e =>
                        setFormData({ ...formData, M3_hasat2025Tarihi: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-indigo-300 mb-1">
                      Tahmini Hasat Başlama Tarihi
                    </label>
                    <input
                      type="text"
                      value={formData.R3_tahminiHasatTarihi}
                      onChange={e =>
                        setFormData({ ...formData, R3_tahminiHasatTarihi: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-indigo-500/60 rounded-lg px-2.5 py-1.5 text-indigo-300 font-bold font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-cyan-300 mb-1">
                      2027 Optimal Hasat Başlama Tarihi
                    </label>
                    <input
                      type="text"
                      value={formData.T3_hasat2027Baslama}
                      onChange={e =>
                        setFormData({ ...formData, T3_hasat2027Baslama: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-cyan-500/60 rounded-lg px-2.5 py-1.5 text-cyan-300 font-bold font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Bölüm 3: Hasat Gün Sayısı, İşçi, Kutu Seçimi, Yönetim Bütçesi ve Delilnama */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <div className="font-bold text-amber-400 uppercase">
                  3. Hasat Gün Sayısı, İşçi Gücü, Kutu Seçimi, Yönetim Bütçesi ve Delilnama Tonajı
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-violet-300 mb-1">Hasat Gün Sayısı (Süre)</label>
                    <input
                      type="number"
                      min="1"
                      max="90"
                      value={formData.hasatGunSayisi}
                      onChange={e =>
                        setFormData(
                          recalculateMiwe2026Row(
                            { ...formData, hasatGunSayisi: Number(e.target.value) },
                            sortingPolicy
                          )
                        )
                      }
                      className="w-full bg-slate-900 border border-violet-500/50 rounded-lg px-2.5 py-1.5 text-violet-300 font-bold font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Günlük Ortalama Hasat (Ton/Gün)
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={`${formData.gunlukOrtalamaHasatTon} Ton/Gün`}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-violet-200 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">
                      1 İşçi Günlük Kapasite (Kg)
                    </label>
                    <input
                      type="number"
                      value={formData.U3_gunlukIsciGucuKg}
                      onChange={e =>
                        setFormData(
                          recalculateMiwe2026Row(
                            { ...formData, U3_gunlukIsciGucuKg: Number(e.target.value) },
                            sortingPolicy
                          )
                        )
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-sky-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Gereken İşçi Sayısı (Otomatik)
                    </label>
                    <input
                      type="number"
                      value={formData.V3_gerekenIsciSayisi}
                      readOnly
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-sky-400 font-bold font-mono"
                    />
                  </div>

                  {/* Planda Kutu Seçimi */}
                  <div className="sm:col-span-2">
                    <label className="block text-indigo-300 mb-1">
                      Planda Kullanılacak Kutu Tipi Seçin
                    </label>
                    <select
                      value={formData.secilenKutuAdi}
                      onChange={e => {
                        const sel = crateOptions.find(c => c.name === e.target.value);
                        setFormData(
                          recalculateMiwe2026Row(
                            {
                              ...formData,
                              secilenKutuAdi: e.target.value,
                              W3_seftaliKutu50x30Kg: sel
                                ? sel.capacityKg
                                : formData.W3_seftaliKutu50x30Kg
                            },
                            sortingPolicy
                          )
                        );
                      }}
                      className="w-full bg-slate-900 border border-indigo-500/50 rounded-lg px-2.5 py-1.5 text-indigo-200 font-bold"
                    >
                      {crateOptions.map(c => (
                        <option key={c.id} value={c.name}>
                          {c.name} — {c.dimensions} ({c.capacityKg} kg)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Kutu Kapasitesi (Kg)</label>
                    <input
                      type="number"
                      step="0.5"
                      value={formData.W3_seftaliKutu50x30Kg}
                      onChange={e =>
                        setFormData(
                          recalculateMiwe2026Row(
                            { ...formData, W3_seftaliKutu50x30Kg: Number(e.target.value) },
                            sortingPolicy
                          )
                        )
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-indigo-300 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">
                      Gereken Kutu Adedi (Otomatik)
                    </label>
                    <input
                      type="number"
                      value={formData.X3_gerekenKutu50x30Adet}
                      readOnly
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-indigo-400 font-bold font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-amber-300 mb-1">
                      Yönetim Bütçe Planı (Ton)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.AB3_yonetimButcePlanTon ?? ''}
                      onChange={e =>
                        setFormData(
                          recalculateMiwe2026Row(
                            {
                              ...formData,
                              AB3_yonetimButcePlanTon:
                                e.target.value === '' ? null : Number(e.target.value)
                            },
                            sortingPolicy
                          )
                        )
                      }
                      className="w-full bg-slate-900 border border-amber-500/50 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-emerald-300 mb-1">
                      Delilnama Onaylı Ham Meyve (Ton)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.AF3_delilnamaHamTon ?? ''}
                      onChange={e =>
                        setFormData(
                          recalculateMiwe2026Row(
                            {
                              ...formData,
                              AF3_delilnamaHamTon:
                                e.target.value === '' ? null : Number(e.target.value)
                            },
                            sortingPolicy
                          )
                        )
                      }
                      className="w-full bg-slate-900 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-emerald-400 font-bold font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-slate-400 mb-1">Hasat Statüsü</label>
                    <select
                      value={formData.AG3_hasatStatusu}
                      onChange={e =>
                        setFormData({
                          ...formData,
                          AG3_hasatStatusu: e.target.value as Miwe2026HarvestStatus
                        })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-bold"
                    >
                      {MIWE_2026_STATUS_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label} — {opt.description}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                {modalTargetYear === '2026' ? (
                  <a
                    href={MIWE_GOOGLE_SHEET_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={e => {
                      handleSaveModal(e as any, true);
                    }}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    <span>Kaydet & Google Sheet'e Gönder ↗</span>
                  </a>
                ) : (
                  <span className="text-xs text-indigo-300 font-semibold">
                    💾 2027 planları doğrudan merkezi uygulama hafızasına kaydedilir.
                  </span>
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
                  >
                    İptal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black cursor-pointer shadow-md"
                  >
                    {modalTargetYear} Planına Kaydet
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
