import React, { useState, useMemo } from 'react';
import {
  DELILNAMA_RECORDS,
  DELILNAMA_CLASS_STANDARDS,
  getDelilnamaQualitySummary,
  DelilnamaRecord
} from '../../data/delilnamaData';
import {
  X,
  FileSpreadsheet,
  Info,
  CheckCircle2,
  TrendingUp,
  Search,
  Scale,
  Award,
  Layers,
  Sparkles,
  Download,
  AlertCircle
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface DelilnamaInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DelilnamaInfoModal: React.FC<DelilnamaInfoModalProps> = ({ isOpen, onClose }) => {
  const { showSuccess } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCrop, setSelectedCrop] = useState<string>('ALL');
  const [selectedMeydan, setSelectedMeydan] = useState<string>('ALL');

  const summary = useMemo(() => getDelilnamaQualitySummary(), []);

  const filteredRecords = useMemo(() => {
    return DELILNAMA_RECORDS.filter(r => {
      if (selectedCrop !== 'ALL' && !r.miwe.toLowerCase().includes(selectedCrop.toLowerCase())) {
        return false;
      }
      if (selectedMeydan !== 'ALL' && !r.meydan.toLowerCase().includes(selectedMeydan.toLowerCase())) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          r.sene.toLowerCase().includes(q) ||
          r.meydan.toLowerCase().includes(q) ||
          r.miwe.toLowerCase().includes(q) ||
          r.sort.toLowerCase().includes(q) ||
          r.meydanFishNo.toLowerCase().includes(q) ||
          r.rcFishNo.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [searchQuery, selectedCrop, selectedMeydan]);

  const filteredTotals = useMemo(() => {
    let extra = 0, exclusive = 0, premium = 0, classic = 0, mix = 0, ballyk = 0, othod = 0, total = 0;
    filteredRecords.forEach(r => {
      extra += r.extraKg || 0;
      exclusive += r.exclusiveKg || 0;
      premium += r.premiumKg || 0;
      classic += (r.classicV26Kg || 0) + (r.classicV28Kg || 0);
      mix += r.mixKg || 0;
      ballyk += r.ballykKg || 0;
      othod += r.musorOthodKg || 0;
      total += r.jemiAgramKg || 0;
    });
    return {
      extra: Math.round(extra),
      exclusive: Math.round(exclusive),
      premium: Math.round(premium),
      classic: Math.round(classic),
      mix: Math.round(mix),
      ballyk: Math.round(ballyk),
      othod: Math.round(othod),
      total: Math.round(total),
      totalTon: (total / 1000).toFixed(2)
    };
  }, [filteredRecords]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white">
                  Delilnama Hasat Sınıf Dağılımı
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 border border-emerald-500/40 text-emerald-300">
                  Sadece Bilgi İçin
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Google Sheet fiili sevk fişleri, kalite sınıfları ve kalibre kriterleri
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bilgilendirme Bandı (Kritik Kullanıcı Açıklaması) */}
        <div className="px-4 sm:px-5 py-3 bg-indigo-950/40 border-b border-indigo-500/20 flex items-start gap-2.5 text-xs text-indigo-200">
          <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-white">Resmi Kural Bildirimi:</strong> Delilnama Google Sheet'te edilen hasatların sınıflara (Extra, Exclusive, Premium, Classic, Mix, Ballyk) bölünüşü <span className="underline font-bold text-amber-300">sadece bilgi ve kalite analizi içindir</span>. Hasat takvimindeki net rekolte veya sevk tonajından herhangi bir kesinti ya da kayıp düşümü yapılmaz.
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* KPI Kartları */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-slate-400">Toplam Hasat</div>
              <div className="text-base font-black text-white font-mono mt-1">
                {filteredTotals.totalTon} <span className="text-xs text-slate-400 font-sans">Ton</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">{filteredTotals.total.toLocaleString('tr-TR')} kg</div>
            </div>

            <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-400">Extra Export</div>
              <div className="text-base font-black text-emerald-300 font-mono mt-1">
                {filteredTotals.extra.toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-emerald-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${Math.round((filteredTotals.extra / filteredTotals.total) * 100)}` : '%0'}
              </div>
            </div>

            <div className="bg-cyan-950/30 border border-cyan-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-cyan-400">Exclusive</div>
              <div className="text-base font-black text-cyan-300 font-mono mt-1">
                {filteredTotals.exclusive.toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-cyan-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${Math.round((filteredTotals.exclusive / filteredTotals.total) * 100)}` : '%0'}
              </div>
            </div>

            <div className="bg-blue-950/30 border border-blue-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-blue-400">Premium</div>
              <div className="text-base font-black text-blue-300 font-mono mt-1">
                {filteredTotals.premium.toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-blue-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${Math.round((filteredTotals.premium / filteredTotals.total) * 100)}` : '%0'}
              </div>
            </div>

            <div className="bg-purple-950/30 border border-purple-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-purple-400">Classic (İç)</div>
              <div className="text-base font-black text-purple-300 font-mono mt-1">
                {filteredTotals.classic.toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-purple-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${Math.round((filteredTotals.classic / filteredTotals.total) * 100)}` : '%0'}
              </div>
            </div>

            <div className="bg-amber-950/30 border border-amber-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-amber-400">Mix & Ballyk</div>
              <div className="text-base font-black text-amber-300 font-mono mt-1">
                {(filteredTotals.mix + filteredTotals.ballyk).toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-amber-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${Math.round(((filteredTotals.mix + filteredTotals.ballyk) / filteredTotals.total) * 100)}` : '%0'}
              </div>
            </div>

            <div className="bg-rose-950/30 border border-rose-500/30 rounded-2xl p-3">
              <div className="text-[10px] font-bold uppercase text-rose-400">Fire / Othod</div>
              <div className="text-base font-black text-rose-300 font-mono mt-1">
                {filteredTotals.othod.toLocaleString('tr-TR')} <span className="text-[10px] text-slate-400">kg</span>
              </div>
              <div className="text-[10px] text-rose-500/80 mt-0.5">
                {filteredTotals.total > 0 ? `%${((filteredTotals.othod / filteredTotals.total) * 100).toFixed(1)}` : '%0'}
              </div>
            </div>
          </div>

          {/* Filtre ve Arama Barı */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-52 sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Fiş no, bahçe veya çeşit ara..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:border-indigo-500 outline-none"
                />
              </div>

              <select
                value={selectedMeydan}
                onChange={e => setSelectedMeydan(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none cursor-pointer"
              >
                <option value="ALL">Tüm Meydanlar</option>
                <option value="Gursak">Gursak</option>
                <option value="Saywan">Saywan</option>
                <option value="Garahan">Garahan</option>
                <option value="Durun">Bäherden Durun</option>
              </select>

              <select
                value={selectedCrop}
                onChange={e => setSelectedCrop(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none cursor-pointer"
              >
                <option value="ALL">Tüm Meyveler</option>
                <option value="Ülje">Ülje (Kiraz)</option>
                <option value="Şetdaly">Şetdaly (Şeftali)</option>
                <option value="Nektarin">Nektarin</option>
                <option value="Alma">Alma</option>
                <option value="Badam">Badam</option>
                <option value="Banan">Banan</option>
                <option value="Soğan">Soğan</option>
              </select>
            </div>

            <div className="text-[11px] text-slate-400 font-bold">
              Gösterilen: <span className="text-white font-mono">{filteredRecords.length}</span> fiş kaydı
            </div>
          </div>

          {/* Tablo */}
          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950/60">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 text-[11px] uppercase font-bold border-b border-slate-800 sticky top-0">
                <tr>
                  <th className="py-2.5 px-3">Tarih (Sene)</th>
                  <th className="py-2.5 px-3">Meydan (Bahçe)</th>
                  <th className="py-2.5 px-3">Fiş No</th>
                  <th className="py-2.5 px-3">Meyve & Çeşit</th>
                  <th className="py-2.5 px-2 text-right text-emerald-400">Extra (kg)</th>
                  <th className="py-2.5 px-2 text-right text-cyan-400">Exclusive (kg)</th>
                  <th className="py-2.5 px-2 text-right text-blue-400">Premium (kg)</th>
                  <th className="py-2.5 px-2 text-right text-purple-400">Classic (kg)</th>
                  <th className="py-2.5 px-2 text-right text-amber-400">Mix (kg)</th>
                  <th className="py-2.5 px-2 text-right text-pink-400">Ballyk (kg)</th>
                  <th className="py-2.5 px-2 text-right text-rose-400">Fire/Othod</th>
                  <th className="py-2.5 px-3 text-right font-black text-white">Toplam Ağırlık</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredRecords.map(r => (
                  <tr key={r.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 font-mono text-slate-300">{r.sene}</td>
                    <td className="py-2 px-3 font-semibold text-white">{r.meydan}</td>
                    <td className="py-2 px-3 font-mono text-slate-400">
                      #{r.meydanFishNo} <span className="text-[10px] text-slate-500">({r.rcFishNo})</span>
                    </td>
                    <td className="py-2 px-3">
                      <div className="font-bold text-amber-300">{r.miwe}</div>
                      <div className="text-[10px] text-slate-400">{r.sort}</div>
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-emerald-300">
                      {r.extraKg > 0 ? r.extraKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-cyan-300">
                      {r.exclusiveKg > 0 ? r.exclusiveKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-blue-300">
                      {r.premiumKg > 0 ? r.premiumKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-purple-300">
                      {r.classicV26Kg > 0 ? r.classicV26Kg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-amber-300">
                      {r.mixKg > 0 ? r.mixKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-pink-300">
                      {r.ballykKg > 0 ? r.ballykKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-rose-400">
                      {r.musorOthodKg > 0 ? r.musorOthodKg.toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2 px-3 text-right font-mono font-black text-white">
                      {r.jemiAgramKg.toLocaleString('tr-TR')} kg
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Kalite Standartları ve Kalibre Referans Tablosu */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Delilnama Google Sheet Kalite Sınıfları ve Kalibre Standartları (Referans Bilgisi)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {DELILNAMA_CLASS_STANDARDS.map(std => (
                <div key={std.code} className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">{std.className}</span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {std.calibers}
                    </span>
                  </div>
                  <div className="text-[11px] text-amber-300 font-semibold">{std.scope}</div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">{std.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Delilnama verileri Google Sheet kaynaklı olup doğrulanmıştır.</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
