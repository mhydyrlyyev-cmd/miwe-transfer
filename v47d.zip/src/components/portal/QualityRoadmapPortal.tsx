import React, { useState, useMemo, useEffect } from 'react';
import { BrandLogo } from '../common/BrandLogo';
import {
  ShieldCheck,
  ArrowLeft,
  Award,
  Sparkles,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  FileSpreadsheet,
  Globe2,
  Microscope,
  Cpu,
  Layers,
  Zap,
  Target,
  FlaskConical,
  Scale,
  Thermometer,
  Calendar,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  Sparkle,
  TreeDeciduous,
  CheckCircle,
  HelpCircle as HelpIcon,
  Info,
  Clock,
  Printer,
  FileBarChart,
  Boxes,
  FileCheck,
  Check,
  Percent,
  Compass,
  Users,
  Trophy,
  Flame,
  Search,
  Eye,
  Sliders,
  Wind,
  Droplets,
  PackageCheck,
  AlertOctagon,
  RefreshCw,
  Star,
  Activity,
  Phone,
  Radio,
  MapPin,
  CheckSquare,
  XCircle,
  Wrench,
  Ban,
  FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  FreezeDryRecord,
  IncidentRecord,
  ExportSampleRecord,
  SalesRecord,
  AmbarRecord,
  LojistikRecord,
  ModuleKey
} from '../../types';
import { AppUser } from '../../types/auth';
import { DepartmentScoringPortal } from './DepartmentScoringPortal';
import { TraceabilityLedgerView } from '../views/TraceabilityLedgerView';
import { PortalTabItem } from './PortalNavigationBar';
import { AdminSystemPortal } from './AdminSystemPortal';

export const QUALITY_PORTAL_TABS: PortalTabItem[] = [
  { id: 'OVERVIEW', title: '14 İstasyon Kalite KPI', badge: '14 İstasyon', description: 'Tarladan limana 14 operasyonel istasyon akışı ve CCP kontrol noktaları' },
  { id: 'KEY_TOOLS', title: 'Key Tools & İndeksler', description: 'Streif olgunluk indeksi, Brix/Asit oranı ve refraktometre rehberi' },
  { id: 'DEPT_SCORING', title: 'Departman Puanlama Modülü', badge: 'PDF Rapor', description: 'Departman bazlı KPI trendleri, karne puanlaması ve PDF raporu' },
  { id: 'QC_QP_AUDIT', title: 'QC & QP Saha Denetimleri', description: 'Brix, penetrometre, kumpas, nitrat ve MAP gaz analizleri' },
  { id: 'RADAR', title: 'Departman Kalite Radarı', description: 'Departmanlar bazında çok boyutlu kalite puanları ve denge grafiği' },
  { id: 'DEPT_COLLAB', title: 'Departmanlar Arası İşbirliği', description: 'Departmanlar arası geri bildirim ve ortak KPI skorlaması' },
  { id: 'ORCHARD_FRUIT', title: 'Bahçe & Meyve Puanlaması', description: 'Parsel ve çeşit bazında kalite tolerans ve saha puanları' },
  { id: 'STANDARD_DEVIATION', title: 'Standart Sapma & Tolerans', description: 'Tolerans dışı sapmalar ve istatistiksel kalite kontrolü' },
  { id: 'GAP_VISION_2026', title: 'GlobalG.A.P. & Vizyon 2026', description: 'İhracat vizesi, MRL kalıntı ve sertifikasyon hazırlığı' },
  { id: 'FSMA_BLOCKCHAIN_LEDGER', title: 'FSMA 204 Dijital Defter', badge: 'KDE/TLC', description: 'Kritik İzleme Olayları (KDE/TLC) ve izlenebilirlik defteri' },
  { id: 'ADMIN_SYSTEM', title: '⚙️ Sistem Yönetimi', badge: 'Admin & Sistem', description: 'Web worker, bellek denetimi, sistem sağlık skoru, kullanıcı yetkileri ve Google Sheets' }
];

export type QualityPillarCategory = 'STATIONS' | 'SCORING' | 'STANDARDS' | 'ADMIN';

export interface QualityPillarGroup {
  id: QualityPillarCategory;
  title: string;
  badge: string;
  defaultTab: 'OVERVIEW' | 'KEY_TOOLS' | 'QC_QP_AUDIT' | 'RADAR' | 'DEPT_COLLAB' | 'ORCHARD_FRUIT' | 'STANDARD_DEVIATION' | 'DEPT_SCORING' | 'GAP_VISION_2026' | 'FSMA_BLOCKCHAIN_LEDGER' | 'ADMIN_SYSTEM';
  tabIds: string[];
}

export const QUALITY_PILLAR_GROUPS: QualityPillarGroup[] = [
  {
    id: 'STATIONS',
    title: '🎯 İstasyonlar & Saha Denetimi',
    badge: '3 Araç',
    defaultTab: 'OVERVIEW',
    tabIds: ['OVERVIEW', 'QC_QP_AUDIT', 'KEY_TOOLS']
  },
  {
    id: 'SCORING',
    title: '📊 Puanlama, Karne & Radar',
    badge: '5 Modül',
    defaultTab: 'DEPT_SCORING',
    tabIds: ['DEPT_SCORING', 'RADAR', 'DEPT_COLLAB', 'ORCHARD_FRUIT', 'STANDARD_DEVIATION']
  },
  {
    id: 'STANDARDS',
    title: '🛡️ Standartlar & FSMA 204',
    badge: '2 Defter',
    defaultTab: 'GAP_VISION_2026',
    tabIds: ['GAP_VISION_2026', 'FSMA_BLOCKCHAIN_LEDGER']
  },
  {
    id: 'ADMIN',
    title: '⚙️ Sistem Yönetimi & Performans',
    badge: 'Admin & Worker',
    defaultTab: 'ADMIN_SYSTEM',
    tabIds: ['ADMIN_SYSTEM']
  }
];

interface QualityRoadmapPortalProps {
  onBackToMainApp: () => void;
  onBackToPortals?: () => void;
  onBackToDashboard?: () => void;
  onSwitchPortal?: (targetView: string, targetTab?: string, portalInfo?: any) => void;
  currentUser?: AppUser | null;
  fieldRecords?: FieldRecord[];
  ambarRecords?: AmbarRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  harvestRecords?: HarvestRecord[];
  incidentRecords?: IncidentRecord[];
  exportSampleRecords?: ExportSampleRecord[];
  salesRecords?: SalesRecord[];
  lojistikRecords?: LojistikRecord[];
  references?: ReferenceItem[];
  feedbacks?: any[];
  customFields?: any[];
  onForceServerSync?: () => Promise<void>;
  onNavigateToView?: (view: any) => void;
  onSelectModule?: (mod: ModuleKey, action: 'NEW' | 'EXISTING') => void;
  initialTab?: 'OVERVIEW' | 'KEY_TOOLS' | 'QC_QP_AUDIT' | 'RADAR' | 'DEPT_COLLAB' | 'ORCHARD_FRUIT' | 'STANDARD_DEVIATION' | 'DEPT_SCORING' | 'GAP_VISION_2026' | 'FSMA_BLOCKCHAIN_LEDGER' | 'ADMIN_SYSTEM';
}

export type ToolOperationalState = 'ACTIVE' | 'UNUSED' | 'BROKEN' | 'PLANNED';

const STORAGE_KEY_TOOLS_STATE = 'miwe_key_tools_operational_state_v3';
const STORAGE_LAB_SCORES = 'miwe_outsourced_lab_scores_v3';
const STORAGE_KEY_AUDIT_STATE = 'miwe_qc_qp_rd_audit_states_v3';
const STORAGE_KEY_OPERATIONS = 'miwe_active_operations_state_v1';
const STORAGE_KEY_DEPT_RATINGS = 'miwe_dept_collaboration_ratings_v1';
const STORAGE_KEY_ORCHARD_FRUIT_RATINGS = 'miwe_orchard_fruit_quality_ratings_v1';

export const QC_AUDIT_KEYS = ['QC-BRIX', 'QC-PENETRO', 'QC-KUMPAS', 'QC-KESIT', 'QC-DEFECT', 'QC-NITRAT'];
export const QP_AUDIT_KEYS = ['QP-RIBBON', 'QP-MAP', 'QP-PULLDOWN', 'QP-GAS', 'QP-COLDCHAMBER', 'QP-LOGGER'];
export const RD_AUDIT_KEYS = ['RD-5WHY', 'RD-SHELFLIFE', 'RD-FREEZEDRY', 'RD-BOTRYTIS', 'RD-DCA'];
export const LAB_AUDIT_KEYS = ['LAB-MRL', 'LAB-HEAVYMETAL', 'LAB-MICROBIO', 'LAB-NITRATE_CONFIRM', 'LAB-GMO'];
export const QA_AUDIT_KEYS = ['QA-GLOBALGAP', 'QA-BRCGS', 'QA-TRACEABILITY', 'QA-HACCP_CCP', 'QA-SUPPLIER'];

export const ALL_OPERATIONAL_STAGES = [
  { id: 'OP-01', no: 1, title: 'Hasat & Tarla Olgunluk İndeksi', standard: 'Brix, penetrometre sertliği ve renk kartelası', role: 'Erken/geç hasadı engeller, raf ömrünü tayin eder', fruitFlow: 'Meyve dalından koparılmadan önce olgunluk vizesi alır' },
  { id: 'OP-02', no: 2, title: 'Bahçe İçi Toplama & Kasa Lojistiği', standard: 'Gölgeye çekme, temiz kasa, mekanik darbe toleransı', role: 'Darbe ezilmelerini ve tarla ısınmasını önler', fruitFlow: 'Kasa içi havalandırma ve zedelenmesiz yükleme' },
  { id: 'OP-03', no: 3, title: 'Tesis Mal Kabul & Hızlı Giriş Muayenesi', standard: 'Elektronik kantar, parti kabul/ret toleransı', role: 'Brüt/net tartım, kusur yüzdesi tespiti', fruitFlow: 'Tesise giriş ilk fiziksel ve duyusal muayene' },
  { id: 'OP-04', no: 4, title: 'Hızlı Ön Soğutma (Pull-Down <3 Saat)', standard: 'Hydrocooling / Zorlamalı hava çekirdek soğutma', role: 'Solunumu kırar, çekirdek sıcaklığını +4°C ye düşürür', fruitFlow: 'Hasat sonrası ani ısı düşürme ile su kaybı önleme' },
  { id: 'OP-05', no: 5, title: 'Yıkama, Dezenfeksiyon & Mum/Fungisit Banyosu', standard: 'Serbest Klor (80-120 ppm) / PAA ve pH (6.5-7.5) CCP', role: 'HACCP CCP-1 mikrobiyel güvenliği garanti eder', fruitFlow: 'Mantar sporu ve patojen çapraz bulaşması engellenir' },
  { id: 'OP-06', no: 6, title: 'Optik / Manuel Boylama & Sınıflandırma', standard: 'Ekstra Sınıf, 1. Sınıf, 2. Sınıf çap kalibrasyonu', role: 'Kumpas boylama, kusur ayıklama doğrulaması', fruitFlow: 'Homojen kalibre ayrımı ve darbesiz bant akışı' },
  { id: 'OP-07', no: 7, title: 'Ölçülebilir Atık & Fire Ayrımı (Mass-Balance)', standard: 'Kütle dengesi geri izlenebilirliği (Parti bazlı)', role: 'Atık kök nedenini ayrıştırır, Freeze-Dry a aktarır', fruitFlow: 'Standart dışı meyvelerin sıfır atıkla kurtarılması' },
  { id: 'OP-08', no: 8, title: 'Modifiye Atmosfer (MAP) Poşetleme & Gazlama', standard: '%2-5 O₂, %3-5 CO₂ tepe boşluğu gaz dengesi', role: 'Gaz sızdırmazlığı ve solunum yavaşlatma kontrolü', fruitFlow: 'Uzun ihracat yolculuğunda yeşil kalma kalkanı' },
  { id: 'OP-09', no: 9, title: 'Hassas Net Gramaj & Viyol/Kutu Paketleme', standard: 'Kalibre terazi ile net tolerans (±%0.5)', role: 'Eksik veya fazla gramajı engeller, koli düzeni', fruitFlow: 'Meyvelerin viyollere zedelenmeden yerleştirilmesi' },
  { id: 'OP-10', no: 10, title: 'GS1-128 Barkod & Parti (Lot) Kodlaması', standard: 'Parsel, hasat tarihi, paketleme saati, GTIN', role: 'Küresel süpermarket geri izlenebilirlik vizesi', fruitFlow: 'Her kutunun hasat edildiği ağaca kadar takibi' },
  { id: 'OP-11', no: 11, title: 'Hat İçi Metal Dedektörü & Yabancı Madde Kontrolü', standard: 'Fe 1.5mm, Non-Fe 2.0mm, SS316 2.5mm CCP-2', role: 'HACCP CCP-2 fiziksel bulaşan güvenliği', fruitFlow: 'Paketlenen kolinin son yabancı madde taraması' },
  { id: 'OP-12', no: 12, title: 'Paletleme, Köşebent Emniyeti & Çemberleme', standard: 'Euro Palet (120x80 / 120x100), mukavva köşebent', role: 'Yol sarsıntısında kutu ezilmesini önler', fruitFlow: 'Palet içi hava koridorlarının açık bırakılması' },
  { id: 'OP-13', no: 13, title: 'Dinlendirme & Soğuk Muhafaza (1000T Kapasite)', standard: '+1.5°C ±0.5°C, %90-95 Bağıl Nem, Etilen <0.05 ppm', role: 'SCADA sıcaklık, nem ve etilen rejim kontrolü', fruitFlow: 'Sevkiyata kadar optimum depolama ve diri kalma' },
  { id: 'OP-14', no: 14, title: 'Frigorifik Konteyner / Tır Sevk & Yolda Logger', standard: 'Dorse ön soğutma, çift USB/BLE logger, kilit mühür', role: 'Soğuk zincir güvencesi, transit sıcaklık takibi', fruitFlow: 'Varış limanına kadar kesintisiz soğuk zincir' }
];

export const QualityRoadmapPortal: React.FC<QualityRoadmapPortalProps> = ({
  onBackToMainApp,
  currentUser,
  fieldRecords = [],
  ambarRecords = [],
  muzRecords = [],
  bademRecords = [],
  freezeDryRecords = [],
  harvestRecords = [],
  incidentRecords = [],
  exportSampleRecords = [],
  salesRecords = [],
  lojistikRecords = [],
  references = [],
  feedbacks = [],
  customFields = [],
  onForceServerSync,
  onNavigateToView,
  onSelectModule,
  initialTab,
  onBackToPortals,
  onBackToDashboard,
  onSwitchPortal
}) => {
  const isAdminUser = currentUser?.role === 'ADMIN';
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'KEY_TOOLS' | 'QC_QP_AUDIT' | 'RADAR' | 'DEPT_COLLAB' | 'ORCHARD_FRUIT' | 'STANDARD_DEVIATION' | 'DEPT_SCORING' | 'GAP_VISION_2026' | 'FSMA_BLOCKCHAIN_LEDGER' | 'ADMIN_SYSTEM'>(
    initialTab && (initialTab !== 'DEPT_SCORING' || isAdminUser) ? initialTab : 'OVERVIEW'
  );

  const visiblePillarGroups = useMemo(() => {
    if (isAdminUser) return QUALITY_PILLAR_GROUPS;
    return QUALITY_PILLAR_GROUPS.map((grp) =>
      grp.id === 'SCORING'
        ? {
            ...grp,
            badge: '4 Modül',
            defaultTab: 'RADAR' as const,
            tabIds: grp.tabIds.filter((id) => id !== 'DEPT_SCORING')
          }
        : grp
    );
  }, [isAdminUser]);

  const currentPillarGroup = useMemo(() => {
    return visiblePillarGroups.find(grp => grp.tabIds.includes(activeTab)) || visiblePillarGroups[0];
  }, [activeTab, visiblePillarGroups]);

  useEffect(() => {
    if (initialTab && (initialTab !== 'DEPT_SCORING' || isAdminUser)) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isAdminUser]);
  const [selectedCountry, setSelectedCountry] = useState<'RU' | 'KZ' | 'AE' | 'EU'>('RU');
  const [selectedToolCategory, setSelectedToolCategory] = useState<'ALL' | 'FIELD' | 'SORTING' | 'COLD' | 'LAB'>('ALL');
  const [showFormulaModal, setShowFormulaModal] = useState<boolean>(false);
  const [showRecordsBreakdown, setShowRecordsBreakdown] = useState<boolean>(false);
  const [auditMonth, setAuditMonth] = useState<string>('Ekim 2026');

  // Departmanlar Arası Karşılıklı İşbirliği & Kalite Puanlama State'i
  const [deptCollaborationScores, setDeptCollaborationScores] = useState<Record<string, { qualityScore: number; deptScore: number; note?: string }>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DEPT_RATINGS);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'DEPT-HARVEST': { qualityScore: 92, deptScore: 88, note: 'Tarlada gölgeye çekme ve kasalama disiplini' },
      'DEPT-FIELD': { qualityScore: 94, deptScore: 91, note: 'Brix ve olgunluk testleri zamanında yapılıyor' },
      'DEPT-COLD': { qualityScore: 96, deptScore: 93, note: 'Pull-down ve SCADA sıcaklık takibi düzenli' },
      'DEPT-SORTING': { qualityScore: 91, deptScore: 89, note: 'Boylama kalibre toleransları kontrol altında' },
      'DEPT-LOGISTICS': { qualityScore: 95, deptScore: 90, note: 'Dorse ön soğutma ve çift data logger yerleşimi' },
      'DEPT-FREEZEDRY': { qualityScore: 98, deptScore: 96, note: 'Sıfır atık liyofilizasyon kurtarma köprüsü kusursuz' },
      'DEPT-SALES': { qualityScore: 93, deptScore: 92, note: 'Müşteri kalite beklentileri ve sevkiyat planı uyumu' }
    };
  });

  // Bahçe ve Meyve Türüne Göre Kalite Puanlama State'i
  const [orchardFruitScores, setOrchardFruitScores] = useState<Record<string, { qualityScore: number; brixRating: number; handlingRating: number; note?: string }>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_ORCHARD_FRUIT_RATINGS);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'ORCHARD-B1-PEACH': { qualityScore: 94, brixRating: 95, handlingRating: 92, note: 'Extreme 314 şeftali yüksek tat doygunluğu' },
      'ORCHARD-B2-NECTARINE': { qualityScore: 92, brixRating: 93, handlingRating: 90, note: 'Big Top nektarin sertlik ve raf ömrü iyi' },
      'ORCHARD-S1-BANANA': { qualityScore: 96, brixRating: 98, handlingRating: 95, note: 'Sera Cavendish 12-hf kurdele ve kalibre standardı' },
      'ORCHARD-B4-ALMOND': { qualityScore: 95, brixRating: 92, handlingRating: 97, note: 'Laurenne / Guara randıman ve nem <5.5% ideal' },
      'ORCHARD-B3-PLUM': { qualityScore: 89, brixRating: 91, handlingRating: 87, note: 'Siyah erik mumsu pus tabakası korunuyor' },
      'ORCHARD-B5-CHERRY': { qualityScore: 93, brixRating: 96, handlingRating: 90, note: 'Kiraz sap tazeliği ve çatlama toleransı' }
    };
  });

  // Grafik 2 için gerçek veri hesabı (Simülasyon / statik veri iptal)
  const grafik2Data = useMemo(() => {
    const products = new Set<string>();
    references.forEach(r => r.product && products.add(r.product));
    ambarRecords.forEach(a => {
      const ref = references.find(r => r.refId === a.refId);
      if (ref?.product) products.add(ref.product);
    });
    if (muzRecords.length > 0) products.add('Cavendish Muz');
    if (bademRecords.length > 0) products.add('Nonpareil Badem');

    const productList = products.size > 0
      ? Array.from(products)
      : ['Cavendish Muz', 'Extreme Şeftali', 'Big Top Nektarin', 'Nonpareil Badem'];

    return productList.map(prod => {
      const relAmbar = ambarRecords.filter(a => {
        const ref = references.find(r => r.refId === a.refId);
        return ref?.product === prod || (a as any).productName === prod || (prod.includes('Muz') && a.refId?.startsWith('MUZ'));
      });

      const relFreezeDry = freezeDryRecords.filter(fd => {
        const ref = references.find(r => r.refId === fd.refId);
        return ref?.product === prod || fd.product?.includes(prod);
      });

      const n = relAmbar.length + relFreezeDry.length;
      const categoryLabel = `${prod} (n=${n})`;

      const totalAmbarKg = relAmbar.reduce((sum, a) => sum + (a.acceptedWeightKg || a.expectedWeightKg || 0), 0);
      const totalFdKg = relFreezeDry.reduce((sum, fd) => sum + (fd.rawWeightKg || 0), 0);

      if (totalAmbarKg === 0 && totalFdKg === 0) {
        return {
          category: categoryLabel,
          n,
          ekstra: 0,
          birinci: 0,
          freezeDry: 0,
          fire: 0
        };
      }

      let extraKg = 0;
      let birinciKg = 0;
      let fireKg = 0;

      relAmbar.forEach(a => {
        const kg = a.acceptedWeightKg || a.expectedWeightKg || 0;
        const ks = (a.kaliteSinifi || '').toUpperCase();
        if (ks.includes('EXTRA') || ks.includes('EKSTRA') || ks.includes('V-20')) {
          extraKg += kg * 0.7;
          birinciKg += kg * 0.3;
        } else if (ks.includes('I') || ks.includes('1')) {
          birinciKg += kg;
        } else {
          birinciKg += kg * 0.8;
        }
        fireKg += Math.max(0, a.weightDiffKg || (kg * (a.weightDiffPercent || 0) / 100));
      });

      const grandTotal = totalAmbarKg + totalFdKg;
      const ekstraPct = grandTotal > 0 ? Math.round((extraKg / grandTotal) * 100) : 0;
      const birinciPct = grandTotal > 0 ? Math.round((birinciKg / grandTotal) * 100) : 0;
      const fdPct = grandTotal > 0 ? Math.round((totalFdKg / grandTotal) * 100) : 0;
      const firePct = grandTotal > 0 ? Math.max(0, 100 - (ekstraPct + birinciPct + fdPct)) : 0;

      return {
        category: categoryLabel,
        n,
        ekstra: ekstraPct,
        birinci: birinciPct,
        freezeDry: fdPct,
        fire: firePct
      };
    });
  }, [references, ambarRecords, freezeDryRecords, muzRecords, bademRecords]);

  // Grafik 2 için toplam kayıt var mı kontrolü (0 kayıt ise "Veri yok" gösterilir)
  const hasGrafik2Records = useMemo(() => {
    return grafik2Data.some(item => (item.n || 0) > 0);
  }, [grafik2Data]);

  // Bahçe Puanı Arama & Filtre State
  const [orchardFilterSearch, setOrchardFilterSearch] = useState<string>('');
  const [selectedFruitCategory, setSelectedFruitCategory] = useState<string>('ALL');

  // Platform Otomatik Canlı Senkronizasyon Modları ("Platforma göre versin işlemler boyunca")
  const [autoSyncDeptScores, setAutoSyncDeptScores] = useState<boolean>(true);
  const [autoSyncOrchardScores, setAutoSyncOrchardScores] = useState<boolean>(true);

  // Standart Dışı Meyve Sapmaları İçin İnteraktif Yüzdeleri Yürütme Gücü (Simülatör State'i)
  const [simulatedGroundFallenPct, setSimulatedGroundFallenPct] = useState<number | null>(null);
  const [simulatedUnsortedPct, setSimulatedUnsortedPct] = useState<number | null>(null);
  const [simulatedMixedHarvestPct, setSimulatedMixedHarvestPct] = useState<number | null>(null);
  const [simulatedRescueEfficiency, setSimulatedRescueEfficiency] = useState<number>(92);
  const [isDeviationScreenFit, setIsDeviationScreenFit] = useState<boolean>(true);

  // Operasyonel İşlem Dağılımı Aktif/Pasif Seçimi (Tesisimizde Mevcut / Hariç Tut)
  const [activeOperations, setActiveOperations] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_OPERATIONS);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'OP-01': true,
      'OP-02': true,
      'OP-03': true,
      'OP-04': true,
      'OP-05': true,
      'OP-06': true,
      'OP-07': true,
      'OP-08': true,
      'OP-09': true,
      'OP-10': true,
      'OP-11': true,
      'OP-12': true,
      'OP-13': true,
      'OP-14': true
    };
  });

  // İnteraktif Key Tools Durum State'i (16 Kritik Meyve-Sebze Aracı)
  const [toolStates, setToolStates] = useState<Record<string, ToolOperationalState>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_TOOLS_STATE);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'TOOL-1': 'ACTIVE',     // Refraktometre (Aktif)
      'TOOL-2': 'ACTIVE',     // Penetrometre (Aktif)
      'TOOL-3': 'ACTIVE',     // Kumpas (Aktif)
      'TOOL-4': 'UNUSED',     // NDIR Gaz Dedektörü (Cihaz var ama seyrek)
      'TOOL-5': 'ACTIVE',     // Çekirdek Sıcaklık Probu (Aktif)
      'TOOL-6': 'ACTIVE',     // Halojen Nem Tayini (Aktif)
      'TOOL-7': 'ACTIVE',     // Data Logger (Aktif)
      'TOOL-8': 'ACTIVE',     // Soğuk Oda Kompresörleri (Aktif)
      'TOOL-9': 'UNUSED',     // MAP Torba & KMnO4 Şase (Sadece ihracatta)
      'TOOL-10': 'ACTIVE',    // Kantar & Daralama (Aktif)
      'TOOL-11': 'ACTIVE',    // Yıkama Suyu Klor/PAA/pH Titratörü (Aktif)
      'TOOL-12': 'ACTIVE',    // Spektrofotometre / CIE Renk Skalası (Aktif)
      'TOOL-13': 'UNUSED',    // PBI Dansensor Headspace O2/CO2 Ölçer (İhmal)
      'TOOL-14': 'ACTIVE',    // UV Fluo Çürüklük Lambası (Aktif)
      'TOOL-15': 'ACTIVE',    // Dijital Şeker/Asit Titratörü (Aktif)
      'TOOL-16': 'ACTIVE'     // Metal Dedektörü Test Çubuğu (Aktif)
    };
  });

  // İnteraktif QC, QP, Ar-Ge, Laboratuvar ve QA Yetkinlik Denetim Matrisi Durum State'i
  const [auditStates, setAuditStates] = useState<Record<string, ToolOperationalState>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_AUDIT_STATE);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'QC-BRIX': 'ACTIVE',        // Dijital Refraktometre
      'QC-PENETRO': 'ACTIVE',     // Penetrometre
      'QC-KUMPAS': 'ACTIVE',      // Dijital Kumpas & Kalibrasyon
      'QC-KESIT': 'ACTIVE',       // Çekirdek Çatlağı & İç Et Muayenesi
      'QC-DEFECT': 'ACTIVE',      // Yüzey Kusur & Tolerans Sınıflandırma
      'QC-NITRAT': 'UNUSED',      // Portatif Nitrat Ölçer (Seyrek)
      'QP-RIBBON': 'ACTIVE',      // Muz 12-Haftalık Kurdele
      'QP-MAP': 'UNUSED',         // MAP Torba & KMnO4 Şase (İhmal)
      'QP-PULLDOWN': 'ACTIVE',    // Hasat Sonrası Çekirdek Isı Düşürme (<3 Saat)
      'QP-GAS': 'UNUSED',         // NDIR Portatif Gaz Dedektörü (İhmal)
      'QP-COLDCHAMBER': 'ACTIVE', // Soğuk Oda Nem & Sıcaklık Rejimi (Tesis devrede)
      'QP-LOGGER': 'ACTIVE',      // Frigo Çift Data Logger Takibi
      'RD-5WHY': 'UNUSED',        // Barlag Akty 5-Why Kök Neden Analizi (Geliştirilmeli)
      'RD-SHELFLIFE': 'PLANNED',  // Simüle Raf Ömrü Test Odası (Planlanan Ar-Ge)
      'RD-FREEZEDRY': 'ACTIVE',   // Freeze-Dry Sıfır Atık Liyofilizasyon Randımanı
      'RD-BOTRYTIS': 'UNUSED',    // Mantari & Çürüme Yayılım Modeli (İhmal)
      'RD-DCA': 'PLANNED',        // Dinamik Kontrollü Atmosfer DCA Simülasyonu
      'LAB-MRL': 'ACTIVE',        // Dış Akredite Lab Pestisit MRL Taraması (650+ Etken)
      'LAB-HEAVYMETAL': 'ACTIVE', // Ağır Metal Analizleri (Pb, Cd, As)
      'LAB-MICROBIO': 'ACTIVE',   // Patojen Mikrobiyoloji (Salmonella, E. coli)
      'LAB-NITRATE_CONFIRM': 'ACTIVE', // Nitrat Dış Lab Doğrulama Testi
      'LAB-GMO': 'UNUSED',        // GDO & Moleküler Biyoloji Dış Uygunluk
      'QA-GLOBALGAP': 'ACTIVE',   // GLOBALG.A.P. IFA v6 Tarımsal Güvence
      'QA-BRCGS': 'ACTIVE',       // BRCGS Food v9 & IFS Paketleme Standardı
      'QA-TRACEABILITY': 'ACTIVE',// GS1-128 Tam Parti Geri İzlenebilirlik
      'QA-HACCP_CCP': 'ACTIVE',   // Yıkama Suyu Dezenfeksiyon & Metal Dedektör CCP
      'QA-SUPPLIER': 'ACTIVE'     // Fidan, Zirai İlaç & Tedarikçi Kalite Onayı
    };
  });

  // İnteraktif Dış Lab Puanlama Durumu
  const [labScores, setLabScores] = useState<Record<string, number>>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_LAB_SCORES);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'LAB-2026-001': 98,
      'LAB-2026-002': 96,
      'LAB-2026-003': 100,
      'LAB-2026-004': 92,
      'LAB-2026-005': 90,
      'LAB-2026-006': 95
    };
  });

  // Kaydetme Effect'leri
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_OPERATIONS, JSON.stringify(activeOperations));
    } catch (e) {}
  }, [activeOperations]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TOOLS_STATE, JSON.stringify(toolStates));
    } catch (e) {}
  }, [toolStates]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_AUDIT_STATE, JSON.stringify(auditStates));
    } catch (e) {}
  }, [auditStates]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LAB_SCORES, JSON.stringify(labScores));
    } catch (e) {}
  }, [labScores]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DEPT_RATINGS, JSON.stringify(deptCollaborationScores));
    } catch (e) {}
  }, [deptCollaborationScores]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ORCHARD_FRUIT_RATINGS, JSON.stringify(orchardFruitScores));
    } catch (e) {}
  }, [orchardFruitScores]);

  // Departman Karşılıklı Puan Güncelleme Fonksiyonu
  const updateDeptScore = (deptId: string, role: 'qualityScore' | 'deptScore', val: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(val)));
    setDeptCollaborationScores(prev => ({
      ...prev,
      [deptId]: {
        ...(prev[deptId] || { qualityScore: 90, deptScore: 90 }),
        [role]: clamped
      }
    }));
  };

  // Bahçe & Meyve Kalite Puanı Güncelleme Fonksiyonu
  const updateOrchardScore = (itemKey: string, field: 'qualityScore' | 'brixRating' | 'handlingRating', val: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(val)));
    setOrchardFruitScores(prev => ({
      ...prev,
      [itemKey]: {
        ...(prev[itemKey] || { qualityScore: 90, brixRating: 90, handlingRating: 90 }),
        [field]: clamped
      }
    }));
  };

  // Key Tools Durum Değiştirme Fonksiyonu
  const toggleToolStatus = (toolId: string, nextStatus: ToolOperationalState) => {
    setToolStates(prev => ({
      ...prev,
      [toolId]: nextStatus
    }));
  };

  // Denetim Matrisi Durum Değiştirme Fonksiyonu
  const toggleAuditStatus = (auditId: string, nextStatus: ToolOperationalState) => {
    setAuditStates(prev => ({
      ...prev,
      [auditId]: nextStatus
    }));
  };

  // Operasyonel İşlem Durum Değiştirme (Tesisimizde Mevcut vs Hariç Tut)
  const toggleOperationStatus = (opId: string) => {
    setActiveOperations(prev => ({
      ...prev,
      [opId]: !prev[opId]
    }));
  };

  // =========================================================================
  // 1. DİNAMİK YETKİNLİK VE OPERASYONEL AĞIRLIK HESAPLAMA & KAYIT DÖKÜMÜ
  // =========================================================================
  const departmentWorkload = useMemo(() => {
    // 1. Operasyonel işlem sayıları
    const qcCount = fieldRecords.length + ambarRecords.length + bademRecords.length + exportSampleRecords.length;
    const qpCount = muzRecords.length + lojistikRecords.length + harvestRecords.length;
    const rdCount = incidentRecords.length + freezeDryRecords.length;
    const labCount = Math.max(exportSampleRecords.filter(r => (r as any).testType?.includes('Lab') || r.destinationCountry?.includes('İhracat') || Boolean(r.destinationCountry)).length, 4);
    const qaCount = Math.max(fieldRecords.filter(r => (r as any).globalGapAudit || (r as any).inspector).length, 3);
    const totalActions = qcCount + qpCount + rdCount + labCount + qaCount;

    // 2. Yetkinlik Denetim Matrisinden gelen aktiflik puanları (QC, QP, Ar-Ge, Lab, QA)
    const getActiveCapabilityWeight = (keys: string[]) => {
      let score = 0;
      keys.forEach(k => {
        const st = auditStates[k];
        if (st === 'ACTIVE') score += 1.0;
        else if (st === 'UNUSED') score += 0.25; // var ama ihmal edildi
        else if (st === 'BROKEN') score += 0.05; // arızalı
        else if (st === 'PLANNED') score += 0.20; // hedef
      });
      return score;
    };

    const qcCapScore = getActiveCapabilityWeight(QC_AUDIT_KEYS); // max 6.0
    const qpCapScore = getActiveCapabilityWeight(QP_AUDIT_KEYS); // max 6.0
    const rdCapScore = getActiveCapabilityWeight(RD_AUDIT_KEYS); // max 5.0
    const labCapScore = getActiveCapabilityWeight(LAB_AUDIT_KEYS); // max 5.0
    const qaCapScore = getActiveCapabilityWeight(QA_AUDIT_KEYS); // max 5.0

    // Dinamik Ağırlık Gücü: 5 Ana Sütun Dağılımı
    const qcPower = Math.max(1, (qcCapScore / QC_AUDIT_KEYS.length) * 35 * (1 + (qcCount > 0 ? 0.15 : 0)));
    const qpPower = Math.max(1, (qpCapScore / QP_AUDIT_KEYS.length) * 30 * (1 + (qpCount > 0 ? 0.15 : 0)));
    const rdPower = Math.max(1, (rdCapScore / RD_AUDIT_KEYS.length) * 12 * (1 + (rdCount > 0 ? 0.10 : 0)));
    const labPower = Math.max(1, (labCapScore / LAB_AUDIT_KEYS.length) * 13 * (1 + (labCount > 0 ? 0.10 : 0)));
    const qaPower = Math.max(1, (qaCapScore / QA_AUDIT_KEYS.length) * 10 * (1 + (exportSampleRecords.length > 0 ? 0.10 : 0)));

    const totalPower = qcPower + qpPower + rdPower + labPower + qaPower;

    const qcPercent = Math.round((qcPower / totalPower) * 100);
    const qpPercent = Math.round((qpPower / totalPower) * 100);
    const rdPercent = Math.round((rdPower / totalPower) * 100);
    const labPercent = Math.round((labPower / totalPower) * 100);
    const qaPercent = Math.max(0, 100 - (qcPercent + qpPercent + rdPercent + labPercent));

    let dominantArea = 'Kalite Kontrol (QC)';
    if (qpPercent >= qcPercent && qpPercent >= rdPercent && qpPercent >= labPercent) dominantArea = 'Kalite Proses (QP)';
    else if (rdPercent > qcPercent && rdPercent > qpPercent && rdPercent > labPercent) dominantArea = 'Kalite Ar-Ge & Sürdürülebilirlik';
    else if (labPercent > qcPercent && labPercent > qpPercent && labPercent > rdPercent) dominantArea = 'Laboratuvar & MRL';
    else if (qaPercent > qcPercent && qaPercent > qpPercent && qaPercent > rdPercent) dominantArea = 'QA & Uluslararası Sertifikasyon';

    // 14 Operasyonel İşlem Kapsama Oranı
    const activeOpsCount = Object.values(activeOperations).filter(Boolean).length;
    const totalOpsCount = ALL_OPERATIONAL_STAGES.length;
    const opsCoveragePercent = Math.round((activeOpsCount / totalOpsCount) * 100);

    return {
      qcCount,
      qpCount,
      rdCount,
      labCount,
      qaCount,
      qcCapScore: qcCapScore.toFixed(1),
      qpCapScore: qpCapScore.toFixed(1),
      rdCapScore: rdCapScore.toFixed(1),
      labCapScore: labCapScore.toFixed(1),
      qaCapScore: qaCapScore.toFixed(1),
      qcPercent,
      qpPercent,
      rdPercent,
      labPercent,
      qaPercent,
      totalActions,
      dominantArea,
      activeOpsCount,
      totalOpsCount,
      opsCoveragePercent,
      interpretation: `Denetim matrisi ve operasyona göre anlık ağırlık: %${qcPercent} QC, %${qpPercent} QP, %${rdPercent} Ar-Ge, %${labPercent} Laboratuvar ve %${qaPercent} QA Güvence.`
    };
  }, [auditStates, activeOperations, fieldRecords, ambarRecords, bademRecords, exportSampleRecords, muzRecords, lojistikRecords, harvestRecords, incidentRecords, freezeDryRecords]);

  // =========================================================================
  // 2. SÜREÇ ARAYÜZLERİ VE DIŞ ETKEN İNCELENMESİ (KİŞİLERE DEĞİL AKIŞA ODAKLI)
  // =========================================================================
  const incidentAccountability = useMemo(() => {
    let harvestIncidents = 0;   // Saha & Hasat Şefliği (İşçi gecikmesi, erken kesim, darbe ezilme)
    let storageIncidents = 0;   // Soğuk Depo & Tesis Bakım (Kompresör arızası, nem kaybı, MAP şasesi yok)
    let logisticsIncidents = 0; // Lojistik & Frigo Sevk (Frigo mazot bitti, muz üşüdü, palet devrildi)
    let qualityIncidents = 0;   // Kalite Bölümü (Hasat öncesi refraktometre yapılmadı, tolerans aşımı gözden kaçtı)

    incidentRecords.forEach(inc => {
      const text = `${inc.incidentType || ''} ${inc.description || ''} ${inc.rootCause || ''} ${inc.notes || ''} ${inc.detectionStage || ''}`.toLowerCase();
      if (text.includes('işçi az') || text.includes('hasat') || text.includes('ezilme') || text.includes('darbe') || text.includes('erken kesim') || text.includes('toplama')) {
        harvestIncidents++;
      } else if (text.includes('oda') || text.includes('kompresör') || text.includes('depo') || text.includes('nem kaybı') || text.includes('çürü')) {
        storageIncidents++;
      } else if (text.includes('araç') || text.includes('tır') || text.includes('frigo') || text.includes('nakliye') || text.includes('mazot') || text.includes('chilling')) {
        logisticsIncidents++;
      } else {
        qualityIncidents++;
      }
    });

    return {
      harvestIncidents,
      storageIncidents,
      logisticsIncidents,
      qualityIncidents,
      total: incidentRecords.length
    };
  }, [incidentRecords]);

  // Key Tools Durumuna Göre Ceza Puanı Hesaplama (16 Alet Üzerinden)
  const toolsPenalty = useMemo(() => {
    let unusedCount = 0;
    let brokenCount = 0;
    Object.values(toolStates).forEach(st => {
      if (st === 'UNUSED') unusedCount++;
      if (st === 'BROKEN') brokenCount++;
    });
    return {
      unusedCount,
      brokenCount,
      penaltyScore: (unusedCount * 2) + (brokenCount * 5)
    };
  }, [toolStates]);

  // =========================================================================
  // 3. 5 ANA SÜTUN UYUM PUANLARI (QC, QP, AR-GE, LAB, QA)
  // =========================================================================
  const auditCompliance = useMemo(() => {
    const calcScore = (keys: string[]) => {
      let active = 0;
      let total = keys.length;
      keys.forEach(k => {
        const st = auditStates[k];
        if (st === 'ACTIVE') active += 1;
        else if (st === 'UNUSED') active += 0.4; // İhmal edilen alet kısmi puan
        else if (st === 'BROKEN') active += 0;   // Arızalı sıfır puan
        else if (st === 'PLANNED') active += 0.5;// Gelecek plan nötr
      });
      return Math.round((active / total) * 100);
    };

    const qcScore = calcScore(QC_AUDIT_KEYS);
    const qpScore = calcScore(QP_AUDIT_KEYS);
    const rdScore = calcScore(RD_AUDIT_KEYS);
    const labScore = calcScore(LAB_AUDIT_KEYS);
    const qaScore = calcScore(QA_AUDIT_KEYS);
    const overall = Math.round((qcScore * 0.35) + (qpScore * 0.30) + (rdScore * 0.12) + (labScore * 0.13) + (qaScore * 0.10));

    return { qcScore, qpScore, rdScore, labScore, qaScore, overall };
  }, [auditStates]);

  // =========================================================================
  // 4. SÜREÇ ARAYÜZLERİ & GELEN RİSK MATRİSİ (MEYVE & FLOW ODAKLI)
  // "Bize nereden sorunlar gelebilir? Kalitenin yapması gereken kontroller ve meyveye etkisi"
  // =========================================================================
  const processTouchpoints = useMemo(() => {
    return [
      {
        id: 'TOUCH-HARVEST',
        stageName: 'Saha & Bahçe Hasat Şefliği ➔ Kalite Temas Noktası',
        flowTitle: 'Dalında Olgunluk, Mekanik Darbe & PHI Kalıntı Süresi',
        interfaceDescription: 'Bahçeden tarlaya, meyvenin ağaçtan koparılmasından kasaya yerleştirilmesine kadar olan kritik temas alanı.',
        inflowRisks: [
          'İşçi azlığı veya aceleyle meyvenin sıkılarak parmak/tırnak iziyle toplanması (mekanik zedelenme)',
          'Şeker (Brix) düzeyi ve tat oturmadan erken kesim veya tarlada aşırı bekleyip dalında yumuşama',
          'Dolu, rüzgar çiziği ve güneş yanıklı meyvelerin sağlam ürünlerle aynı kasaya karıştırılması',
          'Zirai ilaçlama sonrası yasal bekleme süresi (PHI) dolmadan hasat edilerek MRL riski oluşturulması'
        ],
        qualityControls: [
          'Hasat Öncesi Refraktometre & Penetrometre Protokolü (Her 5 tonda 10 tekil meyve)',
          'Cavendish Muzda 12-Haftalık Kurdele Rengi Doğrulaması ve Hasat Vizesi',
          'Kasa Kabulünde Maksimum %2 Mekanik Kusur / Zedelenme Tolerans Sınırı',
          'Hasat Öncesi Zirai İlaçlama Reçetesi & PHI Gün Kontrolü'
        ],
        fruitImpact: 'Doku zedelenmesi, hücre suyu sızması, depoda 4 kat hızlı solunum ve varış ülkesinde erken çürüme.',
        readinessScore: Math.min(88 + (auditStates['QC-BRIX'] === 'ACTIVE' ? 4 : 0) + (auditStates['QC-PENETRO'] === 'ACTIVE' ? 4 : 0), 96),
        statusBadge: 'HASAT TEMAS NOKTASI',
        badgeColor: 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
      },
      {
        id: 'TOUCH-RECEPTION',
        stageName: 'Tesis Mal Kabul & Hızlı Ön Soğutma ➔ Kalite Temas Noktası',
        flowTitle: 'Çekirdek Sıcaklığı, Pull-Down (<3 Saat) & Kantar Darası',
        interfaceDescription: 'Tarladan gelen sıcak meyvenin tesise girişi, tartımı ve solunum hızının hızla kırılması süreci.',
        inflowRisks: [
          'Tarladan gelen kasanın gölgeye alınmayıp güneş altında beklemesi (çekirdek ısısı +30°C üzerine çıkış)',
          'Ön soğutma (Hydrocooler / Zorlamalı Hava Pull-Down) gecikmesi (>3 saat aşımı)',
          'Kantar daralamasında kasa ağırlığının yanlış girilmesi ve net tonaj sapması',
          'Girişte çürük ve yaralı meyvelerin ayıklanmadan doğrudan soğuk odaya gönderilmesi'
        ],
        qualityControls: [
          'İğne Problu Dijital Termometre (Testo 106) ile Çekirdek Sıcaklık Kabul Muayenesi',
          '3 Saat İçinde Çekirdek Sıcaklığının Hedef Değere (+4°C) İndirilmesi Takibi',
          'Elektronik Kantar Kalibrasyonu ve Brüt/Net Daralama Doğrulaması',
          'Giriş Muayene Kusur Cetveli Tutanaklama (Ekstra Sınıf / 1. Sınıf / Sanayi)'
        ],
        fruitImpact: 'Aşırı solunum ve su kaybı (%3-5 büzüşme firesi), doku gevşemesi, soğuk oda dayanımının %50 düşmesi.',
        readinessScore: auditStates['QP-PULLDOWN'] === 'ACTIVE' ? 92 : 76,
        statusBadge: 'ÖN SOĞUTMA TEMAS NOKTASI',
        badgeColor: 'border-teal-500/40 bg-teal-950/30 text-teal-300'
      },
      {
        id: 'TOUCH-SORTING',
        stageName: 'Yıkama, Dezenfeksiyon & Boylama Hattı ➔ Kalite Temas Noktası',
        flowTitle: 'Dezenfektan CCP, Kalibrasyon, Düşme Yüksekliği & Latent Çürüklük',
        interfaceDescription: 'Meyvenin su banyosundan geçişi, fırçalanması, optik/mekanik kumpasla boylanması ve kusur ayıklaması.',
        inflowRisks: [
          'Yıkama suyunda serbest klor (<50 ppm) veya PAA (<40 ppm) seviyesinin düşmesi (çapraz spor bulaşması CCP)',
          'Boylama eleğinde veya optik kamerada kalibrasyon kayması (farklı kalibrelerin karışması)',
          'Konveyör bantlar arası düşme yüksekliğinin >15 cm olması ve meyvenin çarpma ezilmesi (bruising)',
          'Gözle zor seçilen latent mantar sporlarının (Botrytis, Monilinia) hatta gözden kaçması'
        ],
        qualityControls: [
          'Her 2 Saatte Bir Dijital Titratörle Serbest Klor / PAA ve pH Kontrolü (HACCP CCP-1)',
          'Dijital Kumpas ve Kalibrasyon Halkaları ile Saatlik Boy Doğrulaması',
          '365nm UV Fluo Wood Lambası Altında Latent Çürüklük ve Mantar Spor Muayenesi',
          'Bant Düşme Noktalarında Yumuşak Poliüretan Bariyerlerin Bütünlük Kontrolü'
        ],
        fruitImpact: 'Yıkama suyundan tüm kasalara mantar sporu yayılması; görünüşte sağlam olan meyvede 10 gün sonra iç çürüme.',
        readinessScore: auditStates['QC-KUMPAS'] === 'ACTIVE' ? 90 : 78,
        statusBadge: 'BOYLAMA & DEZENFEKSİYON',
        badgeColor: 'border-blue-500/40 bg-blue-950/30 text-blue-300'
      },
      {
        id: 'TOUCH-PACKING',
        stageName: 'Paketleme, MAP Gazlama & Net Gramaj ➔ Kalite Temas Noktası',
        flowTitle: 'Modifiye Atmosfer (%2-5 O₂, %3-5 CO₂), Sızdırmazlık & GS1-128 Barkod',
        interfaceDescription: 'Meyvelerin viyollere dizilmesi, MAP poşetine koruyucu gaz basımı, vakum yapıştırma ve etiketleme.',
        inflowRisks: [
          'MAP torbasında O₂ oranının <%1 e inmesi (anaerobik solunum/fermantasyon) veya >%5 kalması',
          'Poşet yapıştırma çenesinde mikro delik kalması ve koruyucu gazın dışarı kaçması',
          'Koli net ağırlığında daranın yanlış düşülmesi sonucu gramaj eksiği (cezai şart riski)',
          'Hatalı parsel kodu veya parti numarası basımı sonucu geriye dönük izlenebilirliğin kopması'
        ],
        qualityControls: [
          'PBI Dansensor CheckPoint İğneli Gaz Analizörü ile Her Partiden 3 Torba Tepe Boşluğu Testi',
          'Su Banyosunda Vakum Daldırma ile Torba Mikro Delik ve Sızdırmazlık Testi',
          'Dara Doğrulamalı Endüstriyel Terazi ile Net Gramaj Tolerans Kontrolü',
          'GS1-128 Barkod Okuyucu ile Parti Numarası ve Küresel İzlenebilirlik Testi'
        ],
        fruitImpact: 'Gaz dengesi bozulan meyvede iç kararma ve alkol kokusu; varış gümrüğünde etiket veya gramaj reddi.',
        readinessScore: toolStates['TOOL-13'] === 'ACTIVE' || auditStates['QP-MAP'] === 'ACTIVE' ? 89 : 74,
        statusBadge: 'MAP & PAKETLEME TEMASI',
        badgeColor: 'border-purple-500/40 bg-purple-950/30 text-purple-300'
      },
      {
        id: 'TOUCH-STORAGE',
        stageName: 'Soğuk Muhafaza & Depo Etilen Yönetimi ➔ Kalite Temas Noktası',
        flowTitle: 'Sıcaklık Dalgalanması (<±0.5°C), Bağıl Nem (%90-95 RH) & Etilen Birikimi',
        interfaceDescription: 'Paketlenen ürünlerin 1000 tonluk modern soğuk hava odalarında sevkiyata kadar korunması.',
        inflowRisks: [
          'Kompresör durması veya defrost gecikmesiyle oda sıcaklığının +1.5°C den +6°C üzerine çıkması',
          'Odada bağıl nemin <%88 e düşmesiyle meyvenin su kaybedip saplarının kararması ve büzüşmesi',
          'Klimakterik meyvelerin odasında etilen gazı birikmesi (>0.05 ppm) sonucu erken sararma',
          'İstifte paletlerin hava sirkülasyon kanallarını kapatması ve kör sıcak noktalar oluşması'
        ],
        qualityControls: [
          '2 Saatlik Periyotlarla SCADA ve Bağımsız BLE Logger Sıcaklık Doğrulaması',
          'Portatif NDIR Etilen ve CO₂ Gaz Analizörü ile Rutin Atmosfer Taraması',
          'Psikrometre ile Bağıl Nem Ölçümü (%90-%95 RH Emniyet Aralığı)',
          'KMnO4 Etilen Emici Şaselerin ve Ozon Filtrelerinin Aktiflik Denetimi'
        ],
        fruitImpact: 'Erken sararma, muzda uç kararması, şeftalide unlanma, su kaybından kaynaklı koli başı 200-400g tonaj firesi.',
        readinessScore: toolStates['TOOL-8'] === 'ACTIVE' ? 93 : 75,
        statusBadge: 'SOĞUK MUHAFAZA TEMASI',
        badgeColor: 'border-cyan-500/40 bg-cyan-950/30 text-cyan-300'
      },
      {
        id: 'TOUCH-LOGISTICS',
        stageName: 'Frigorifik Lojistik & Konteyner Sevk ➔ Kalite Temas Noktası',
        flowTitle: 'Dorse Ön Soğutma, Hava Sirkülasyonu, Çift Logger & Yol Sarsıntısı',
        interfaceDescription: 'Meyvelerin frigo tıra veya reefer konteynere yüklenmesi ve 3000+ km uluslararası transit yolculuğu.',
        inflowRisks: [
          'Tır dorsesinin yükleme öncesi ön soğutulmaması (sıcak dorseye soğuk meyve temasıyla yoğunlaşma/terleme)',
          'Paletlerin tırın hava kanallarını (T-Floor) tıkaması ve dorse ucunda hava sirkülasyonunun durması',
          'Gümrük kapısında uzun beklemelerde şoförün soğutucuyu kapatması veya mazotunun bitmesi',
          'Yol titreşiminden köşebentsiz paletlerin kayması, kutuların ezilmesi ve meyvelerin ezilmesi'
        ],
        qualityControls: [
          'Sevkiyat Öncesi 15 Dakikalık Yükleme Kontrol Protokolü (Dorse ısısı, koku, hijyen, sızdırmazlık)',
          'Palet İçine 2 Adet Bağımsız USB/BLE Sıcaklık Loggerı Yerleşimi (En sıcak ve en soğuk noktalara)',
          'Palet Köşebent, Streç Film ve Çemberleme Emniyeti Muayenesi',
          'Şoföre Islak İmzalı Soğuk Zincir Taahhütnamesi Teslimi ve Resmi Mühürleme Tutanağı'
        ],
        fruitImpact: 'Soğuk zincir kırılması (Chilling injury veya aşırı yumuşama), mekanik koli ezilmeleri, varış ülkesinde müşteri reddi.',
        readinessScore: auditStates['QP-LOGGER'] === 'ACTIVE' ? 91 : 77,
        statusBadge: 'FRİGORİFİK LOJİSTİK TEMASI',
        badgeColor: 'border-indigo-500/40 bg-indigo-950/30 text-indigo-300'
      }
    ];
  }, [auditStates, toolStates]);

  // =========================================================================
  // 5. RADAR CHART VERİLERİ (İnteraktif Denetim ve Kayıtlara Göre Dinamik 7 Eksen)
  // =========================================================================
  const radarData = useMemo(() => {
    const qcScore = auditCompliance.qcScore;
    const qpScore = auditCompliance.qpScore;
    const storageScore = toolStates['TOOL-8'] === 'ACTIVE' ? 88 : toolStates['TOOL-8'] === 'UNUSED' ? 70 : 50;
    const rdScore = auditCompliance.rdScore;
    const flwScore = auditStates['RD-FREEZEDRY'] === 'ACTIVE' ? 86 : 65;
    const labValues = Object.values(labScores);
    const labAvg = labValues.length > 0 ? Math.round(labValues.reduce((a, b) => a + b, 0) / labValues.length) : 85;
    const effectiveLab = Math.round((labAvg * 0.55) + (auditCompliance.labScore * 0.45));
    const qaScore = auditCompliance.qaScore;

    return [
      { subject: 'Saha Kontrol (QC)', mevcut: qcScore, hedef: 95, desc: 'Brix, penetrometre, kumpas, kesit ve tolerans testleri' },
      { subject: 'Proses & MAP (QP)', mevcut: qpScore, hedef: 90, desc: 'Kurdele 12-hafta, MAP torba, çekirdek pull-down ve logger' },
      { subject: 'Soğuk Depo & Gaz', mevcut: storageScore, hedef: 92, desc: '1000T kompresör rejimi, portatif gaz ölçümü ve kantar' },
      { subject: 'Ar-Ge & 5-Why (Barlag)', mevcut: rdScore, hedef: 85, desc: 'Barlag Akty kök neden derinliği ve çürüme simülasyonu' },
      { subject: 'Gıda Kaybı / FLW Kurtarma', mevcut: flwScore, hedef: 90, desc: 'Freeze & Dry liyofilizasyon sıfır atık köprüsü' },
      { subject: 'Dış Akredite Lab & MRL', mevcut: effectiveLab, hedef: 95, desc: 'Pestisit (650+ etken), ağır metal ve mikrobiyoloji dış analiz' },
      { subject: 'QA & Sertifikasyon', mevcut: qaScore, hedef: 95, desc: 'GLOBALG.A.P. IFA v6, BRCGS Food v9 ve GS1-128 parti izlenebilirlik' }
    ];
  }, [auditCompliance, toolStates, auditStates, labScores]);

  // =========================================================================
  // 6. STANDART DIŞI, YERE DÜŞEN, BOYLANMAMIŞ & KARIŞIK MEYVE SAPMA ANALİZİ
  // "Zorunlu olan yerler (Gıda güvenliği, CCP, MRL) ve Esnek olan yerler (şekil, hafif renk)"
  // =========================================================================
  const standardDeviationAnalytics = useMemo(() => {
    let groundFallenWeightKg = 0;
    let unsortedWeightKg = 0;
    let mixedHarvestWeightKg = 0;
    let nonStandardGradeKg = 0;
    let totalAssessedKg = 0;

    // Hasat ve referans kayıtlarından sapmaları tara
    references.forEach(r => {
      const kg = (r as any).totalKg || r.quantity || 0;
      totalAssessedKg += kg;

      if (r.isUnsorted || (r.kaliteSinifi && r.kaliteSinifi.toLowerCase().includes('karışık')) || (r.kaliteSinifi && r.kaliteSinifi.toLowerCase().includes('mix'))) {
        mixedHarvestWeightKg += kg;
      }
      if (r.isUnsorted) {
        unsortedWeightKg += kg;
      }
      if (r.kaliteSinifi && (r.kaliteSinifi.includes('Standart Däl') || r.kaliteSinifi.includes('Standart Dışı') || r.kaliteSinifi.includes('Sanayi') || r.kaliteSinifi.includes('Iskarta'))) {
        nonStandardGradeKg += kg;
      }
    });

    // Olay ve tutanak kayıtlarından yere düşen meyveleri süz
    incidentRecords.forEach(inc => {
      const text = `${inc.incidentType || ''} ${inc.description || ''} ${inc.notes || ''}`.toLowerCase();
      if (text.includes('yere düş') || text.includes('toprak temas') || text.includes('dökül') || text.includes('dip meyve')) {
        groundFallenWeightKg += (Number(inc.affectedQuantityKg) || 0);
      }
    });

    const hasData = totalAssessedKg > 0;
    const groundFallenPct = hasData ? Number(((groundFallenWeightKg / totalAssessedKg) * 100).toFixed(1)) : 0;
    const unsortedPct = hasData ? Number(((unsortedWeightKg / totalAssessedKg) * 100).toFixed(1)) : 0;
    const mixedHarvestPct = hasData ? Number(((mixedHarvestWeightKg / totalAssessedKg) * 100).toFixed(1)) : 0;
    const nonStandardPct = hasData ? Number(((nonStandardGradeKg / totalAssessedKg) * 100).toFixed(1)) : 0;

    // Kurtarma ve Geri Kazanım Oranı (Freeze-Dry & 2. Sınıf Sanayi)
    const deviationSum = nonStandardGradeKg + groundFallenWeightKg + unsortedWeightKg;
    const rescuedViaFreezeDryKg = nonStandardGradeKg + unsortedWeightKg * 0.4;
    const rescueRatePct = deviationSum > 0 ? Math.min(100, Number(((rescuedViaFreezeDryKg / deviationSum) * 100).toFixed(1))) : 100;

    return {
      totalAssessedKg,
      groundFallenWeightKg,
      groundFallenPct,
      unsortedWeightKg,
      unsortedPct,
      mixedHarvestWeightKg,
      mixedHarvestPct,
      nonStandardGradeKg,
      nonStandardPct,
      rescueRatePct,
      rescuedViaFreezeDryKg: Math.round(rescuedViaFreezeDryKg)
    };
  }, [references, incidentRecords]);

  // =========================================================================
  // 7. PLATFORMA GÖRE CANLI İŞLEM PUANLARI (DEPARTMAN VE BAHÇE/MEYVE METRİKLERİ)
  // "Platforma göre versin işlemler boyunca"
  // =========================================================================
  const platformOperationMetrics = useMemo(() => {
    // A. DEPARTMAN CANLI PERFORMANS ANALİZİ
    // 1. Hasat Şefliği (Tarlada hasat kayıtları, ezilme/darbe ve işçi disiplini)
    const harvestIncidentsCount = incidentAccountability.harvestIncidents;
    const totalHarvestKg = harvestRecords.reduce((acc, h) => acc + (h.dailyTotalKg || 0), 0);
    const harvestQualityScore = Math.max(60, Math.min(100, Math.round(96 - (harvestIncidentsCount * 3.5))));
    const harvestDeptScore = Math.max(65, Math.min(100, Math.round(94 - (harvestIncidentsCount * 2.0))));

    // 2. Saha Ziraat & İlaçlama (Field Records: Brix, sertlik, kusur testleri)
    const fieldTestsCount = fieldRecords.length;
    const fieldAvgBrix = fieldRecords.length > 0 ? fieldRecords.reduce((acc, f) => acc + (f.avgBrix || 12), 0) / fieldRecords.length : 12.8;
    const fieldPassedRatio = fieldRecords.length > 0 ? fieldRecords.filter(f => f.decision?.includes('Uygun')).length / fieldRecords.length : 0.90;
    const fieldQualityScore = Math.max(65, Math.min(100, Math.round(80 + (fieldPassedRatio * 18))));
    const fieldDeptScore = Math.max(70, Math.min(100, Math.round(82 + (fieldTestsCount > 0 ? 12 : 5))));

    // 3. Soğuk Depo & Tesis Bakım (Ambar Records: Soğuk zincir, sıcaklık ve kabul)
    const ambarAcceptedCount = ambarRecords.filter(a => a.acceptanceStatus === 'ACCEPTED').length;
    const ambarTotal = Math.max(1, ambarRecords.length);
    const coldChainPassRatio = ambarRecords.length > 0 ? ambarRecords.filter(a => a.coldChainStatus === 'Uygun').length / ambarTotal : 0.95;
    const storageIncidentsCount = incidentAccountability.storageIncidents;
    const coldQualityScore = Math.max(60, Math.min(100, Math.round((coldChainPassRatio * 95) - (storageIncidentsCount * 4))));
    const coldDeptScore = Math.max(65, Math.min(100, Math.round(92 - (storageIncidentsCount * 2))));

    // 4. Boylama & Paketleme Hattı (Tasnif, MAP torbalama, kalibre ve fire)
    const unsortedRatio = standardDeviationAnalytics.unsortedPct;
    const sortingQualityScore = Math.max(60, Math.min(100, Math.round(97 - (unsortedRatio * 0.7))));
    const sortingDeptScore = Math.max(65, Math.min(100, Math.round(94 - (unsortedRatio * 0.4))));

    // 5. Frigorifik Lojistik & Sevk (Lojistik Records: Araç sıcaklığı, logger ve teslimat)
    const lojistikDeliveredCount = lojistikRecords.filter(l => l.status === 'DELIVERED').length;
    const logisticsIncidentsCount = incidentAccountability.logisticsIncidents;
    const lojistikTotal = Math.max(1, lojistikRecords.length);
    const lojistikQualityScore = Math.max(60, Math.min(100, Math.round(96 - (logisticsIncidentsCount * 4))));
    const lojistikDeptScore = Math.max(65, Math.min(100, Math.round(93 - (logisticsIncidentsCount * 2.5))));

    // 6. Freeze-Dry Liyofilizasyon (FreezeDry Records: Randıman, çıtırlık, sıfır atık)
    const fdRecordsCount = freezeDryRecords.length;
    const fdAvgYield = freezeDryRecords.length > 0 ? freezeDryRecords.reduce((acc, r) => acc + (r.yieldRatioPercent || 15), 0) / freezeDryRecords.length : 16.5;
    const fdQualityScore = Math.max(75, Math.min(100, Math.round(90 + (standardDeviationAnalytics.rescueRatePct * 0.08))));
    const fdDeptScore = Math.max(80, Math.min(100, Math.round(92 + (fdRecordsCount > 0 ? 6 : 2))));

    // 7. Satış & İhracat Operasyon (Sales Records & Export Samples: Kabul, şikayet yok)
    const exportPassedCount = exportSampleRecords.filter(e => e.shelfLifeDecision === 'EXCELLENT' || e.shelfLifeDecision === 'COMPLIANT' || (e as any).overallVerdict === 'PASS').length;
    const exportTotal = Math.max(1, exportSampleRecords.length);
    const salesQualityScore = Math.max(65, Math.min(100, Math.round(85 + ((exportPassedCount / exportTotal) * 12))));
    const salesDeptScore = Math.max(70, Math.min(100, Math.round(88 + ((salesRecords.length > 0 ? 8 : 4)))));

    const liveDeptStats: Record<string, { qualityScore: number; deptScore: number; realOpsText: string }> = {
      'DEPT-HARVEST': {
        qualityScore: harvestQualityScore,
        deptScore: harvestDeptScore,
        realOpsText: `${harvestRecords.length} hasat parti işlemi (${Math.round(totalHarvestKg).toLocaleString('tr-TR')} kg) & ${harvestIncidentsCount} tutanak`
      },
      'DEPT-FIELD': {
        qualityScore: fieldQualityScore,
        deptScore: fieldDeptScore,
        realOpsText: `${fieldTestsCount} saha test protokolü (Ort. Brix: ${fieldAvgBrix.toFixed(1)}°Bx, %${Math.round(fieldPassedRatio * 100)} vize)`
      },
      'DEPT-COLD': {
        qualityScore: coldQualityScore,
        deptScore: coldDeptScore,
        realOpsText: `${ambarRecords.length} depo kabul/muhafaza kaydı (%${Math.round(coldChainPassRatio * 100)} soğuk zincir uygun)`
      },
      'DEPT-SORTING': {
        qualityScore: sortingQualityScore,
        deptScore: sortingDeptScore,
        realOpsText: `${references.length} parti tasnifi (Boylanmama oranı: %${unsortedRatio})`
      },
      'DEPT-LOGISTICS': {
        qualityScore: lojistikQualityScore,
        deptScore: lojistikDeptScore,
        realOpsText: `${lojistikRecords.length} frigorifik sevkiyat (${lojistikDeliveredCount} teslim edildi, ${logisticsIncidentsCount} sapma)`
      },
      'DEPT-FREEZEDRY': {
        qualityScore: fdQualityScore,
        deptScore: fdDeptScore,
        realOpsText: `${freezeDryRecords.length} liyofilizasyon süreci (Sıfır atık kurtarma: %${standardDeviationAnalytics.rescueRatePct})`
      },
      'DEPT-SALES': {
        qualityScore: salesQualityScore,
        deptScore: salesDeptScore,
        realOpsText: `${salesRecords.length} satış & ${exportSampleRecords.length} ihracat parti sertifikasyonu`
      }
    };

    // B. BAHÇE VE MEYVEYE GÖRE CANLI PLATFORM ANALİZİ
    // Gerçekleşen Field + Harvest + Muz + Badem kayıtlarından bahçe/meyve bazlı istatistik çıkar
    const orchardStatsMap: Record<string, {
      fruit: string;
      orchardName: string;
      type: string;
      sampleCount: number;
      brixSum: number;
      hardnessSum: number;
      defectRatioSum: number;
      totalKg: number;
      incidents: number;
    }> = {};

    // 1. FieldRecords taraması
    fieldRecords.forEach(f => {
      const orchardName = f.orchard || f.location || 'Bahçe 1';
      const fruitName = f.product || 'Şeftali';
      const key = `${orchardName}_${fruitName}`.toUpperCase().replace(/\s+/g, '_');

      if (!orchardStatsMap[key]) {
        orchardStatsMap[key] = {
          fruit: `${f.sortVariety ? `${f.sortVariety} ` : ''}${fruitName}`,
          orchardName,
          type: fruitName,
          sampleCount: 0,
          brixSum: 0,
          hardnessSum: 0,
          defectRatioSum: 0,
          totalKg: 0,
          incidents: 0
        };
      }

      orchardStatsMap[key].sampleCount++;
      orchardStatsMap[key].brixSum += (f.avgBrix || 12);
      orchardStatsMap[key].hardnessSum += (f.avgHardness || 5.5);
      orchardStatsMap[key].defectRatioSum += (f.defectPercent || 4);
    });

    // 2. HarvestRecords taraması
    harvestRecords.forEach(h => {
      const orchardName = h.orchard || h.location || 'Hasat Alanı';
      const fruitName = h.product || 'Meyve';
      const key = `${orchardName}_${fruitName}`.toUpperCase().replace(/\s+/g, '_');

      if (!orchardStatsMap[key]) {
        orchardStatsMap[key] = {
          fruit: `${h.variety ? `${h.variety} ` : ''}${fruitName}`,
          orchardName,
          type: fruitName,
          sampleCount: 0,
          brixSum: 0,
          hardnessSum: 0,
          defectRatioSum: 0,
          totalKg: 0,
          incidents: 0
        };
      }
      orchardStatsMap[key].totalKg += (h.dailyTotalKg || 0);
    });

    // 3. Muz kayıtları
    muzRecords.forEach(m => {
      const orchardName = m.greenhouseNo || 'Sera Bölgesi 1';
      const fruitName = 'Muz';
      const key = `${orchardName}_${fruitName}`.toUpperCase().replace(/\s+/g, '_');
      if (!orchardStatsMap[key]) {
        orchardStatsMap[key] = {
          fruit: 'Cavendish Muz',
          orchardName,
          type: 'Muz',
          sampleCount: 0,
          brixSum: 0,
          hardnessSum: 0,
          defectRatioSum: 0,
          totalKg: 0,
          incidents: 0
        };
      }
      orchardStatsMap[key].sampleCount++;
      orchardStatsMap[key].brixSum += (m.avgBrix || (m.brix || 18));
      orchardStatsMap[key].totalKg += (m.netWeightKg || 0);
    });

    // 4. Badem kayıtları
    bademRecords.forEach(b => {
      const orchardName = b.location || 'Badem Bahçesi 4';
      const fruitName = 'Badem';
      const key = `${orchardName}_${fruitName}`.toUpperCase().replace(/\s+/g, '_');
      if (!orchardStatsMap[key]) {
        orchardStatsMap[key] = {
          fruit: `${b.variety || 'Laurenne / Guara'} Badem`,
          orchardName,
          type: 'Badem',
          sampleCount: 0,
          brixSum: 0,
          hardnessSum: 0,
          defectRatioSum: 0,
          totalKg: 0,
          incidents: 0
        };
      }
      orchardStatsMap[key].sampleCount++;
      orchardStatsMap[key].totalKg += (b.totalLoadKg || 0);
      orchardStatsMap[key].defectRatioSum += (b.totalDefectPercent || 3.5);
    });

    // 5. Standart ve Dinamik Bahçe & Meyve Listesini Sentezle ("Platforma göre versin işlemler boyunca")
    const masterItems = [
      { key: 'ORCHARD-B1-PEACH', orchard: 'Bahçe 1 (Parsel 3-5)', fruit: 'Extreme 314 Şeftali', type: 'Şeftali', targetBrix: '12.5 - 14.5 °Bx', benchmarkBrix: 13.0, defaultQ: 94, defaultB: 95, defaultH: 92 },
      { key: 'ORCHARD-B2-NECTARINE', orchard: 'Bahçe 2 (Parsel 8-10)', fruit: 'Big Top Nektarin', type: 'Nektarin', targetBrix: '12.0 - 13.8 °Bx', benchmarkBrix: 12.8, defaultQ: 92, defaultB: 93, defaultH: 90 },
      { key: 'ORCHARD-S1-BANANA', orchard: 'Sera Bölgesi 1 (Sera 1-6)', fruit: 'Cavendish Muz', type: 'Muz', targetBrix: '18.0 - 22.0 °Bx (Sarı)', benchmarkBrix: 19.5, defaultQ: 96, defaultB: 98, defaultH: 95 },
      { key: 'ORCHARD-B4-ALMOND', orchard: 'Badem Bahçesi 4', fruit: 'Laurenne / Guara Badem', type: 'Badem', targetBrix: 'Nem: <%5.5 (Kuru)', benchmarkBrix: 0, defaultQ: 95, defaultB: 92, defaultH: 97 },
      { key: 'ORCHARD-B3-PLUM', orchard: 'Bahçe 3 (Parsel 1-2)', fruit: 'Black Amber Erik', type: 'Erik', targetBrix: '11.5 - 13.0 °Bx', benchmarkBrix: 12.2, defaultQ: 89, defaultB: 91, defaultH: 87 },
      { key: 'ORCHARD-B5-CHERRY', orchard: 'Bahçe 5 (Dağ Parseli)', fruit: 'Lapins Kiraz', type: 'Kiraz', targetBrix: '16.0 - 19.5 °Bx', benchmarkBrix: 17.5, defaultQ: 93, defaultB: 96, defaultH: 90 }
    ];

    const dynamicOrchardFruitList = masterItems.map(item => {
      // Bu meyve ve bahçeye ilişkin gerçek platform verilerini topla
      const matchedFields = fieldRecords.filter(f => 
        (f.orchard && f.orchard.toLowerCase().includes(item.orchard.toLowerCase().split(' ')[1])) ||
        (f.product && f.product.toLowerCase().includes(item.type.toLowerCase())) ||
        (f.sortVariety && item.fruit.toLowerCase().includes(f.sortVariety.toLowerCase()))
      );

      const matchedHarvests = harvestRecords.filter(h => 
        (h.product && h.product.toLowerCase().includes(item.type.toLowerCase())) ||
        (h.variety && item.fruit.toLowerCase().includes(h.variety.toLowerCase())) ||
        (h.orchard && h.orchard.toLowerCase().includes(item.orchard.toLowerCase().split(' ')[1]))
      );

      const matchedIncidents = incidentRecords.filter(inc => {
        const text = `${inc.incidentType || ''} ${inc.description || ''} ${inc.location || ''} ${inc.lotNo || ''} ${inc.notes || ''}`.toLowerCase();
        return text.includes(item.type.toLowerCase()) || text.includes(item.orchard.toLowerCase().split(' ')[1]);
      });

      const totalFieldTests = matchedFields.length;
      const totalHarvestKg = matchedHarvests.reduce((a, b) => a + (b.dailyTotalKg || 0), 0);
      const avgMeasuredBrix = totalFieldTests > 0 ? (matchedFields.reduce((a, b) => a + (b.avgBrix || 12), 0) / totalFieldTests) : (item.benchmarkBrix || 13);
      const avgMeasuredHardness = totalFieldTests > 0 ? (matchedFields.reduce((a, b) => a + (b.avgHardness || 5.5), 0) / totalFieldTests) : 5.8;
      const avgDefectPct = totalFieldTests > 0 ? (matchedFields.reduce((a, b) => a + (b.defectPercent || 3.5), 0) / totalFieldTests) : 3.8;

      // Platform formülü: Brix uyumu + Hasat zedelenmeme + Kusur toleransı - Tutanaklar
      const brixRatio = item.benchmarkBrix > 0 ? Math.min(1.15, avgMeasuredBrix / item.benchmarkBrix) : 1;
      const calculatedBrixScore = Math.max(70, Math.min(100, Math.round(brixRatio * 92)));
      const calculatedHandlingScore = Math.max(65, Math.min(100, Math.round(96 - (avgDefectPct * 1.8) - (standardDeviationAnalytics.groundFallenPct * 0.8))));
      const calculatedQualityScore = Math.max(60, Math.min(100, Math.round((calculatedBrixScore * 0.52) + (calculatedHandlingScore * 0.48) - (matchedIncidents.length * 3))));

      return {
        ...item,
        totalFieldTests,
        totalHarvestKg: Math.round(totalHarvestKg),
        avgMeasuredBrix: Number(avgMeasuredBrix.toFixed(1)),
        avgMeasuredHardness: Number(avgMeasuredHardness.toFixed(1)),
        avgDefectPct: Number(avgDefectPct.toFixed(1)),
        incidentCount: matchedIncidents.length,
        liveBrixScore: calculatedBrixScore,
        liveHandlingScore: calculatedHandlingScore,
        liveQualityScore: calculatedQualityScore,
        realOpsText: `${totalFieldTests > 0 ? `${totalFieldTests} saha analizi` : 'Standart test'} • ${totalHarvestKg > 0 ? `${Math.round(totalHarvestKg).toLocaleString('tr-TR')} kg hasat` : 'Hasat periyodu'} • ${matchedIncidents.length} tutanak`
      };
    });

    return {
      liveDeptStats,
      orchardStatsMap,
      dynamicOrchardFruitList
    };
  }, [fieldRecords, ambarRecords, muzRecords, bademRecords, freezeDryRecords, harvestRecords, incidentRecords, exportSampleRecords, salesRecords, lojistikRecords, references, incidentAccountability, standardDeviationAnalytics]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      


      {/* 1. ÜST HERO & BAŞLIK BÖLÜMÜ */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 border border-teal-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-800/80 border border-teal-500/30">
                <BrandLogo size={20} showText={false} className="shrink-0" />
                <span className="text-[11px] font-black text-amber-300 font-mono">MIWE HIL QUALITY HUB</span>
              </div>

              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-teal-500/20 text-teal-300 border border-teal-400/40">
                Ayrı Web Platformu &amp; Uluslararası Standartlar
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white mt-2.5 tracking-tight flex items-center gap-3">
              <div className="p-2 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-teal-300 shadow-inner">
                <ShieldCheck className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
              <span>Kalite Bölümü KPI, Süreç Risk Matrisi & 5 Ana Sütun</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 mt-1.5 max-w-3xl leading-relaxed">
              Meyve-sebze akışına dayalı 6 kritik süreç arayüzü ve gelen risk matrisi, 14 operasyonel işlem kütle denkliği & fire izlenebilirliği, 16 interaktif donanım durumu ve 5 sütunlu uluslararası GAP yol haritası.
            </p>
          </div>

          <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0 flex-wrap">
            <button
              type="button"
              onClick={() => setShowFormulaModal(true)}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 text-xs font-bold border border-teal-500/40 transition cursor-pointer"
              title="Reytingler ve hedefler nereden geliyor?"
            >
              <HelpCircle className="w-4 h-4 text-teal-400" />
              <span>Reyting & Hedef Formülü</span>
            </button>

            <button
              type="button"
              onClick={() => window.print()}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
            >
              <Printer className="w-4 h-4 text-teal-400" />
              <span>Raporu Yazdır</span>
            </button>
          </div>
        </div>

        {/* 4 Real-time KPI Göstergesi */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="bg-slate-800/80 backdrop-blur-xs p-3.5 rounded-2xl border border-teal-500/20">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>İstasyon & Süreç Yükü</span>
              <Compass className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-lg sm:text-2xl font-black text-white mt-1">
              %{departmentWorkload.qcPercent} QC / %{departmentWorkload.qpPercent} QP
            </div>
            <div className="text-[11px] text-emerald-400 mt-0.5">14 kritik CCP kontrol noktası</div>
          </div>

          <div className="bg-slate-800/80 backdrop-blur-xs p-3.5 rounded-2xl border border-teal-500/20">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Ölçüm Cihazları</span>
              <Sliders className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-lg sm:text-2xl font-black text-amber-300 mt-1">
              {Object.values(toolStates).filter(s => s === 'ACTIVE').length} / {Object.keys(toolStates).length} Aktif
            </div>
            <div className="text-[11px] text-amber-400/90 mt-0.5">
              {toolsPenalty.unusedCount > 0 ? `${toolsPenalty.unusedCount} cihaz bakımda / pasif` : 'Tüm cihazlar kalibre'}
            </div>
          </div>

          <div className="bg-slate-800/80 backdrop-blur-xs p-3.5 rounded-2xl border border-teal-500/20">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Kusur & Olay Dağılımı</span>
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-lg sm:text-2xl font-black text-white mt-1">
              {incidentAccountability.total} Tutanak
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Hasat: {incidentAccountability.harvestIncidents} • Depo: {incidentAccountability.storageIncidents} • Lojistik: {incidentAccountability.logisticsIncidents}</div>
          </div>

          <div className="bg-slate-800/80 backdrop-blur-xs p-3.5 rounded-2xl border border-teal-500/20">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Sistem & Spark Durumu</span>
              <Wrench className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-lg sm:text-2xl font-black text-purple-300 mt-1">
              Sağlık: 98/100
            </div>
            <div className="text-[11px] text-purple-400 mt-0.5">Worker Aktif • 0 ms Gecikme</div>
          </div>
        </div>
      </div>

      {/* 2. DÖRT ANA SÜTUN & HİYERARŞİK SEKME GEZİNTİSİ */}
      <div className="space-y-2.5">
        {/* SEVİYE 1: 4 ANA FONKSİYONEL SÜTUN (MASTER PILLARS) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl shadow-lg backdrop-blur-xs">
          {visiblePillarGroups.map((grp) => {
            const isGroupActive = grp.id === currentPillarGroup.id;
            return (
              <button
                key={grp.id}
                type="button"
                onClick={() => {
                  if (!grp.tabIds.includes(activeTab)) {
                    setActiveTab(grp.defaultTab);
                  }
                }}
                className={`flex items-center justify-between p-3 rounded-xl text-left transition cursor-pointer ${
                  isGroupActive
                    ? 'bg-gradient-to-r from-teal-700 to-emerald-700 text-white shadow-md ring-1 ring-teal-400/50'
                    : 'bg-slate-950/70 hover:bg-slate-800/90 text-slate-300 hover:text-white border border-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="font-bold text-xs sm:text-sm truncate">{grp.title}</span>
                </div>
                <span
                  className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-full shrink-0 ${
                    isGroupActive
                      ? 'bg-slate-950/40 text-teal-200'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {grp.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* SEVİYE 2: SEÇİLİ ANA SÜTUNA AİT AKTİF ALT ARAÇLAR & HIZLI ATLAYICI */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-1.5 bg-slate-900/80 border border-slate-800/90 rounded-2xl overflow-x-auto shadow-sm">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {currentPillarGroup.tabIds.map((tabId) => {
              const tabMeta = QUALITY_PORTAL_TABS.find(t => t.id === tabId);
              const isTabActive = activeTab === tabId;
              if (!tabMeta) return null;

              return (
                <button
                  key={tabId}
                  type="button"
                  onClick={() => setActiveTab(tabId as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    isTabActive
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/90'
                  }`}
                  title={tabMeta.description}
                >
                  <span>{tabMeta.title}</span>
                  {tabMeta.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-black ${
                        isTabActive
                          ? 'bg-slate-950/30 text-slate-950'
                          : 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                      }`}
                    >
                      {tabMeta.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* TÜM 11 ARACA DOĞRUDAN ATLAYICI AÇILIR LİSTE */}
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 pl-2 pr-1 border-t sm:border-t-0 sm:border-l border-slate-800 pt-1.5 sm:pt-0">
            <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap hidden md:inline">
              Hızlı Atla:
            </span>
            <select
              value={activeTab}
              onChange={(e) => setActiveTab(e.target.value as any)}
              className="bg-slate-950 border border-slate-700 text-teal-300 text-xs font-bold rounded-xl px-2.5 py-1.5 outline-none cursor-pointer focus:border-teal-400"
              title="11 Kalite & Sistem aracından herhangi birine doğrudan atlayın"
            >
              {visiblePillarGroups.map((grp) => (
                <optgroup key={grp.id} label={grp.title} className="bg-slate-900 text-slate-300">
                  {grp.tabIds.map((tid) => {
                    const item = QUALITY_PORTAL_TABS.find(t => t.id === tid);
                    return (
                      <option key={tid} value={tid} className="bg-slate-900 text-white font-medium">
                        {item?.title || tid}
                      </option>
                    );
                  })}
                </optgroup>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SEKME 1: GENEL BAKIŞ & KAYIT DÖKÜMÜ (OPERASYONEL İŞLEM ANALİZİ)            */}
      {/* ========================================================================= */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-6">
          {/* Departman Puanlama Modülü Entegrasyon Kartı (Sadece ADMIN) */}
          {isAdminUser && (
            <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 border border-indigo-500/40 rounded-3xl p-4 sm:p-5 text-white flex items-center justify-between gap-4 flex-wrap shadow-md">
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-2xl bg-indigo-500/30 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shrink-0">
                  <Award className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                      PLATFORM 02 ENTEGRE
                    </span>
                    <span className="text-xs text-indigo-200 font-semibold">Çapraz KPI &amp; Değerlendirme</span>
                  </div>
                  <h4 className="font-bold text-sm sm:text-base text-white mt-1">
                    Departman Puanlama &amp; Sorumluluk Modülü
                  </h4>
                  <p className="text-xs text-indigo-200/80 mt-0.5">
                    Kalite, Üretim, Agronomi ve Satış departmanları için rol kartları, 3 aylık Recharts KPI trend grafikleri ve PDF raporlama.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('DEPT_SCORING')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition cursor-pointer active:scale-95"
              >
                <Award className="w-4 h-4 text-amber-400" />
                <span>Departman Puanlama Modülünü Aç →</span>
              </button>
            </div>
          )}

          {/* Dinamik Ağırlık Dağılım Kartı */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                    Kalite Bölümü Şirket İçinde Nereye İlerliyor?
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Operasyonel ağırlık ve departman gelişim konjonktürü analizi
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-700">
                Ağırlık: {departmentWorkload.dominantArea}
              </span>
            </div>

            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Operasyonel İşlem Dağılımı ({departmentWorkload.totalActions} Toplam İşlem Analizi)</span>
                <span className="font-mono text-teal-600 dark:text-teal-400">{departmentWorkload.interpretation}</span>
              </div>
              <div className="w-full h-4 rounded-full overflow-hidden flex shadow-inner bg-slate-100 dark:bg-slate-800">
                <div style={{ width: `${departmentWorkload.qcPercent}%` }} className="bg-emerald-500 hover:bg-emerald-400 transition-all flex items-center justify-center text-[10px] font-bold text-slate-950">
                  QC %{departmentWorkload.qcPercent}
                </div>
                <div style={{ width: `${departmentWorkload.qpPercent}%` }} className="bg-teal-500 hover:bg-teal-400 transition-all flex items-center justify-center text-[10px] font-bold text-slate-950">
                  QP %{departmentWorkload.qpPercent}
                </div>
                <div style={{ width: `${departmentWorkload.rdPercent}%` }} className="bg-amber-500 hover:bg-amber-400 transition-all flex items-center justify-center text-[10px] font-bold text-slate-950">
                  Ar-Ge %{departmentWorkload.rdPercent}
                </div>
                <div style={{ width: `${departmentWorkload.labPercent}%` }} className="bg-sky-500 hover:bg-sky-400 transition-all flex items-center justify-center text-[10px] font-bold text-slate-950">
                  Lab %{departmentWorkload.labPercent}
                </div>
              </div>
            </div>

            {/* Gerçek Kayıtların Şeffaf Döküm Tablosu */}
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-teal-500" />
                  <span>Operasyonel İşlemlerin Sistemdeki Gerçek Kayıt Kaynakları ({departmentWorkload.totalActions} Toplam Kayıt)</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setShowRecordsBreakdown(!showRecordsBreakdown)}
                  className="px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-700 dark:text-teal-300 border border-teal-300 dark:border-teal-700 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition"
                >
                  <Eye className="w-3 h-3" />
                  <span>{showRecordsBreakdown ? 'Listeyi Gizle' : 'Kayıt Listesini Denetle'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60">
                  <div className="font-bold text-emerald-800 dark:text-emerald-300">Kalite Kontrol (QC): {departmentWorkload.qcCount}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 space-y-0.5">
                    <div>• Saha Testleri: {fieldRecords.length} adet</div>
                    <div>• Ambar Tartımları: {ambarRecords.length} adet</div>
                    <div>• Badem Randıman: {bademRecords.length} adet</div>
                    <div>• Şahit Numune: {exportSampleRecords.length} adet</div>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/60">
                  <div className="font-bold text-teal-800 dark:text-teal-300">Kalite Proses (QP): {departmentWorkload.qpCount}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 space-y-0.5">
                    <div>• Muz Kurdele/MAP: {muzRecords.length} adet</div>
                    <div>• Günlük Hasat: {harvestRecords.length} adet</div>
                    <div>• Frigo Lojistik: {lojistikRecords.length} adet</div>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60">
                  <div className="font-bold text-amber-800 dark:text-amber-300">Ar-Ge & Kurtarma: {departmentWorkload.rdCount}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 space-y-0.5">
                    <div>• Barlag Akty: {incidentRecords.length} adet</div>
                    <div>• Freeze-Dry Liyo: {freezeDryRecords.length} adet</div>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/60">
                  <div className="font-bold text-sky-800 dark:text-sky-300">Dış Akredite Lab: {departmentWorkload.labCount}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 space-y-0.5">
                    <div>• MRL / Çoklu Analiz: 6 kütük</div>
                    <div>• İhracat Şahit: {exportSampleRecords.length} adet</div>
                  </div>
                </div>
              </div>

              {/* Açılabilir Detaylı Kayıt Dökümü */}
              {showRecordsBreakdown && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 animate-in fade-in duration-200">
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                    <span>Sistem Veritabanındaki Aktif Kayıtların Detaylı Dökümü:</span>
                    <span className="text-[11px] font-mono text-teal-600 dark:text-teal-400">Canlı IndexedDB & Bulut Senkronu</span>
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1 text-[11px] font-mono">
                    {fieldRecords.map(r => (
                      <div key={r.id} className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-emerald-600 font-bold">[QC - Saha] {r.product || 'Meyve'}</span>
                        <span className="text-slate-500">Konum: {r.location || r.orchard || '-'} • Brix: {r.avgBrix ?? '-'}° • Sertlik: {r.avgHardness ?? '-'} kg</span>
                        <span className="text-slate-400 text-[10px]">{r.timestamp ? new Date(r.timestamp).toLocaleDateString('tr-TR') : '-'}</span>
                      </div>
                    ))}
                    {muzRecords.map(r => (
                      <div key={r.id} className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-teal-600 font-bold">[QP - Muz/MAP] {r.product || 'Cavendish Muz'}</span>
                        <span className="text-slate-500">Sera: {r.greenhouseNo || '-'} • Kurdele: {r.ribbonColor || '-'} • Kalibre: {r.calibrationMm ?? '-'} mm</span>
                        <span className="text-slate-400 text-[10px]">{r.timestamp ? new Date(r.timestamp).toLocaleDateString('tr-TR') : '-'}</span>
                      </div>
                    ))}
                    {incidentRecords.map(r => (
                      <div key={r.id} className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-rose-600 font-bold">[Ar-Ge - Barlag Akty] {r.incidentType || 'Kusur'}</span>
                        <span className="text-slate-500 truncate max-w-xs">{r.description || r.rootCause || '-'}</span>
                        <span className="text-slate-400 text-[10px]">{r.incidentDate || r.timestamp ? new Date(r.incidentDate || r.timestamp).toLocaleDateString('tr-TR') : '-'}</span>
                      </div>
                    ))}
                    {freezeDryRecords.map(r => (
                      <div key={r.id} className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-amber-600 font-bold">[Ar-Ge - FreezeDry] {r.product || 'Meyve Dilimi'}</span>
                        <span className="text-slate-500">Parti: {r.lotNo || '-'} • Çıkış: {r.finalDryWeightKg ?? '-'} kg</span>
                        <span className="text-slate-400 text-[10px]">{r.timestamp ? new Date(r.timestamp).toLocaleDateString('tr-TR') : '-'}</span>
                      </div>
                    ))}
                    {departmentWorkload.totalActions === 0 && (
                      <div className="text-center py-4 text-slate-400 font-sans text-xs">
                        Sistemde henüz kayıt açılmadı (Cold-Start Modu). İlk veriler girildiğinde burada anlık listelenecektir.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Hedefler Nereden Geliyor & Mevcut Neye Göre Hesaplanıyor Paneli */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-teal-500/30 text-white space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-teal-400" />
                    <h5 className="font-bold text-xs sm:text-sm text-teal-300">
                      Hedefler Nereden Geliyor? & Mevcut Neye Göre Hesaplanıyor? (Resmi Metodoloji)
                    </h5>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 font-mono">
                    2026-2027 Şirket Kalite Pasaportu & Uluslararası Standartlar
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs leading-relaxed">
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                    <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-emerald-400" />
                      <span>1. Hedefler Nereden Belirlenir?</span>
                    </div>
                    <ul className="space-y-1 text-slate-300 text-[11px] list-disc list-inside">
                      <li><strong>Yıllık Kalite Pasaportu (SLA):</strong> Yönetim, Bahçe Şefliği ve Satış arasında imzalanan yıllık tolerans sınırları (%95 kurdele uyumu, maks %4 çıkış firesi).</li>
                      <li><strong>UNECE & OECD Standartları:</strong> Şeftali/Nektarin (FFV-26), Muz (FFV-06), Badem dünya kalite normları.</li>
                      <li><strong>Hedef Pazar Karantina Kuralları:</strong> Rusya EAC (TR CU 021), Kazakistan Birlik Transit, Dubai ESMA raf ömrü (min 21 gün).</li>
                    </ul>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                    <div className="font-bold text-amber-300 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-amber-400" />
                      <span>2. Mevcut Değerler Neye Göre Hesaplanır?</span>
                    </div>
                    <ul className="space-y-1 text-slate-300 text-[11px] list-disc list-inside">
                      <li><strong>Operasyonel Ağırlık Yüzdeleri:</strong> Sistemdeki gerçek kayıt sayısı (QC: {departmentWorkload.qcCount}, QP: {departmentWorkload.qpCount}, Ar-Ge: {departmentWorkload.rdCount}) üzerinden anlık hesaplanır.</li>
                      <li><strong>Performans & Reyting Skoru:</strong> 100 baz puan - (Barlag Akty akt cezası) - (İhmal edilen alet cezası × 3) - (Arızalı tesis cezası × 6).</li>
                      <li><strong>Sorumluluk Ayrımı:</strong> Doğrudan kaliteye ait olmayan hatalar (işçi azlığı, soğuk oda arızası vb.) ilgili departmana yazılır, Kalite Bölümünden haksız puan kesilmez!</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}



      {/* ========================================================================= */}
      {/* SEKME 3: KEY TOOLS & İNTERAKTİF DURUM SEÇİCİ (AKTİF / İHMAL / ARIZALI)      */}
      {/* ========================================================================= */}
      {activeTab === 'KEY_TOOLS' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-teal-500" />
                  <span>Key Tools & Proses İnteraktif Durum Matrisi</span>
                </h3>
                <p className="text-xs text-slate-500">
                  "Cihaz var ama kullanmıyoruz", "Soğuk oda var ama arızalandı" durumlarını seçin; aylık puan anında güncellensin!
                </p>
              </div>

              {/* Özet Durum Butonları */}
              <div className="flex items-center gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                  {Object.values(toolStates).filter(s => s === 'ACTIVE').length} Aktif
                </span>
                <span className="px-2.5 py-1 rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
                  {Object.values(toolStates).filter(s => s === 'UNUSED').length} İhmal Edilen (-{toolsPenalty.unusedCount * 3} Puan)
                </span>
                <span className="px-2.5 py-1 rounded-xl bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-bold">
                  {Object.values(toolStates).filter(s => s === 'BROKEN').length} Arızalı (-{toolsPenalty.brokenCount * 6} Puan)
                </span>
              </div>
            </div>

            {/* Cihaz ve Proses Kartları */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-2">
              {[
                {
                  id: 'TOOL-1',
                  category: 'FIELD',
                  name: 'Dijital Refraktometre (0-53° Brix)',
                  brand: 'Atago PAL-1',
                  impact: 'Hasat zamanı ve tat doygunluğu'
                },
                {
                  id: 'TOOL-2',
                  category: 'FIELD',
                  name: 'Meyve Penetrometresi (Sertlik Ölçer)',
                  brand: 'FT-327 (8mm & 11mm)',
                  impact: 'Meyve eti direnci & raf ömrü'
                },
                {
                  id: 'TOOL-3',
                  category: 'FIELD',
                  name: 'Dijital Kumpas & Kalibrasyon Halkaları',
                  brand: 'Mitutoyo 150mm',
                  impact: 'Ekstra vs 1. Sınıf boylama ayrımı'
                },
                {
                  id: 'TOOL-4',
                  category: 'COLD',
                  name: 'NDIR CO₂ & Etilen Portatif Gaz Dedektörü',
                  brand: 'Felix F-950',
                  impact: 'Muz olgunlaşma ve CA depo atmosferi'
                },
                {
                  id: 'TOOL-5',
                  category: 'COLD',
                  name: 'Çekirdek Sıcaklık Probu (Pull-Down)',
                  brand: 'Testo 106',
                  impact: 'Tarladan depoya giriş çekirdek sıcaklığı'
                },
                {
                  id: 'TOOL-6',
                  category: 'LAB',
                  name: 'Halojen Nem Tayin Cihazı (Moisture Analyzer)',
                  brand: 'Mettler Toledo HE53',
                  impact: 'Badem ve Freeze-Dry çıtırlık nemi'
                },
                {
                  id: 'TOOL-7',
                  category: 'COLD',
                  name: 'USB / BLE Palet İçi Sıcaklık Data Logger',
                  brand: 'Sensitech TempTale',
                  impact: 'İhracat tırında yolda sıcaklık kaydı'
                },
                {
                  id: 'TOOL-8',
                  category: 'COLD',
                  name: 'Soğuk Hava Odası Kompresör & Soğutma Grubu',
                  brand: 'Datly Miwe 1000T Tesisleri',
                  impact: 'Ana depo soğutma ve nem rejimi'
                },
                {
                  id: 'TOOL-9',
                  category: 'COLD',
                  name: 'MAP Torba & KMnO4 Etilen Emici Şase',
                  brand: 'Modifiye Atmosfer Poşetleri',
                  impact: 'Uzun ihracat yolculuğunda yeşil kalma'
                },
                {
                  id: 'TOOL-10',
                  category: 'FIELD',
                  name: 'Kantar Tartım & Daralama İstasyonu',
                  brand: 'Elektronik Platform Kantarı',
                  impact: 'Brüt-net kantar fişi ve fire hesaplama'
                }
              ].map((tool) => {
                const currentState = toolStates[tool.id] || 'ACTIVE';
                return (
                  <div
                    key={tool.id}
                    className={`p-4 rounded-2xl border transition-all space-y-3 flex flex-col justify-between ${
                      currentState === 'ACTIVE'
                        ? 'bg-white dark:bg-slate-900 border-emerald-500/40 shadow-xs'
                        : currentState === 'UNUSED'
                        ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-400 shadow-xs'
                        : currentState === 'BROKEN'
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-400 shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-400">{tool.id} • {tool.category}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                          currentState === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' :
                          currentState === 'UNUSED' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          currentState === 'BROKEN' ? 'bg-rose-500/20 text-rose-700 dark:text-rose-300' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {currentState === 'ACTIVE' && 'AKTİF KULLANILIYOR'}
                          {currentState === 'UNUSED' && 'VAR AMA KULLANILMIYOR'}
                          {currentState === 'BROKEN' && 'ARIZALI / BAKIMDA'}
                          {currentState === 'PLANNED' && 'YATIRIM BEKLİYOR'}
                        </span>
                      </div>

                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1">
                        {tool.name}
                      </h4>
                      <div className="text-[11px] text-teal-600 dark:text-teal-400 font-mono">
                        {tool.brand}
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                        🎯 {tool.impact}
                      </div>
                    </div>

                    {/* İnteraktif 4 Durum Butonu */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800/60">
                      <div className="text-[10px] font-bold text-slate-500 mb-1">Durumu Değiştir:</div>
                      <div className="grid grid-cols-2 gap-1 text-[10px] font-bold">
                        <button
                          type="button"
                          onClick={() => toggleToolStatus(tool.id, 'ACTIVE')}
                          className={`py-1 px-1.5 rounded-lg border transition cursor-pointer flex items-center justify-center gap-1 ${
                            currentState === 'ACTIVE'
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-emerald-100 dark:hover:bg-emerald-950'
                          }`}
                        >
                          <CheckSquare className="w-3 h-3" />
                          <span>Aktif</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleToolStatus(tool.id, 'UNUSED')}
                          className={`py-1 px-1.5 rounded-lg border transition cursor-pointer flex items-center justify-center gap-1 ${
                            currentState === 'UNUSED'
                              ? 'bg-amber-600 text-white border-amber-600'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-amber-100 dark:hover:bg-amber-950'
                          }`}
                        >
                          <Ban className="w-3 h-3" />
                          <span>İhmal / Boşta</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleToolStatus(tool.id, 'BROKEN')}
                          className={`py-1 px-1.5 rounded-lg border transition cursor-pointer flex items-center justify-center gap-1 ${
                            currentState === 'BROKEN'
                              ? 'bg-rose-600 text-white border-rose-600'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-rose-100 dark:hover:bg-rose-950'
                          }`}
                        >
                          <Wrench className="w-3 h-3" />
                          <span>Arızalı</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleToolStatus(tool.id, 'PLANNED')}
                          className={`py-1 px-1.5 rounded-lg border transition cursor-pointer flex items-center justify-center gap-1 ${
                            currentState === 'PLANNED'
                              ? 'bg-slate-700 text-white border-slate-700'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="w-3 h-3" />
                          <span>Planlanan</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SEKME 4: QC / QP / AR-GE / LAB DERİNLEMESİNE İNTERAKTİF DENETİM MATRİSİ   */}
      {/* ========================================================================= */}
      {activeTab === 'QC_QP_AUDIT' && (
        <div className="space-y-6">
          {/* Üst Denetim Kontrol Barı & Otomatik Ağırlık Hesaplama Paneli */}
          <div className="bg-gradient-to-r from-teal-950/70 via-slate-900 to-slate-900 border-2 border-teal-500/40 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base sm:text-lg text-white flex items-center gap-2">
                    <Sliders className="w-5 h-5 text-teal-400" />
                    <span>Yetkinlik Denetim Matrisi & Anlık Ağırlık Hesaplama</span>
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-400/40">
                    4 Alan • Canlı Katsayı Motoru
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                  Penetrometre, MAP gazı, 5-Why kök neden veya dış lab analizlerini <strong>"Aktif / İhmal / Arızalı / Hedef"</strong> olarak işaretleyin; sistemin anlık ağırlık yüzdesi (%QC, %QP, %Ar-Ge, %Lab) ve yetkinlik radarı canlı olarak otomatik hesaplansın!
                </p>
              </div>

              {/* Dönem Seçici & Hızlı Bilgi */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-slate-400 font-bold">Denetim Dönemi:</span>
                <select
                  value={auditMonth}
                  onChange={(e) => setAuditMonth(e.target.value)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-teal-300 border border-teal-500/40 text-xs font-bold cursor-pointer outline-none shadow-sm"
                >
                  <option value="Ekim 2026">Ekim 2026 (Hasat & Sezon Zirvesi)</option>
                  <option value="Kasım 2026">Kasım 2026 (Muz & Soğuk Muhafaza)</option>
                  <option value="Aralık 2026">Aralık 2026 (İhracat & Frigo Sevk)</option>
                </select>
              </div>
            </div>

            {/* SİSTEMİN ANLIK AĞIRLIK YÜZDESİ VE UYUM GÖSTERGESİ (4 ALAN) */}
            <div className="bg-slate-950/70 border border-teal-500/30 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-teal-400" />
                  <span>Sistemin Anlık Ağırlık Yüzdeleri Dağılımı (Otomatik Hesaplanır):</span>
                </span>
                <span className="font-mono text-[11px] px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-400/30 font-bold">
                  ⚡ Güncel Ağırlık Merkezi: {departmentWorkload.dominantArea}
                </span>
              </div>

              {/* 4 Alanın Ağırlık ve Uyum Kartları */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                {/* 1. QC */}
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-left space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-emerald-300 uppercase tracking-wider">1. Kalite Kontrol (QC)</span>
                    <span className="font-mono text-emerald-400 font-bold">{departmentWorkload.qcCapScore}/6.0 Puan</span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-xl font-black text-emerald-400 font-mono">%{departmentWorkload.qcPercent}</span>
                    <span className="text-[10px] text-slate-300 font-medium">Uyum: %{auditCompliance.qcScore}</span>
                  </div>
                  <div className="text-[10px] text-emerald-300/80 truncate">
                    Brix, penetrometre, kumpas, kusur cetveli
                  </div>
                </div>

                {/* 2. QP */}
                <div className="p-3 rounded-xl bg-teal-950/40 border border-teal-500/40 text-left space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-teal-300 uppercase tracking-wider">2. Kalite Proses (QP)</span>
                    <span className="font-mono text-teal-400 font-bold">{departmentWorkload.qpCapScore}/6.0 Puan</span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-xl font-black text-teal-300 font-mono">%{departmentWorkload.qpPercent}</span>
                    <span className="text-[10px] text-slate-300 font-medium">Uyum: %{auditCompliance.qpScore}</span>
                  </div>
                  <div className="text-[10px] text-teal-300/80 truncate">
                    MAP gaz ölçümü, kurdele, pull-down, logger
                  </div>
                </div>

                {/* 3. Ar-Ge */}
                <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-left space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-amber-300 uppercase tracking-wider">3. Kalite Ar-Ge</span>
                    <span className="font-mono text-amber-400 font-bold">{departmentWorkload.rdCapScore}/5.0 Puan</span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-xl font-black text-amber-400 font-mono">%{departmentWorkload.rdPercent}</span>
                    <span className="text-[10px] text-slate-300 font-medium">Uyum: %{auditCompliance.rdScore}</span>
                  </div>
                  <div className="text-[10px] text-amber-300/80 truncate">
                    5-Why kök neden, raf ömrü, liyofilizasyon
                  </div>
                </div>

                {/* 4. Laboratuvar & MRL */}
                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/40 text-left space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-indigo-300 uppercase tracking-wider">4. Laboratuvar & MRL</span>
                    <span className="font-mono text-indigo-400 font-bold">{departmentWorkload.labCapScore}/5.0 Puan</span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-xl font-black text-indigo-300 font-mono">%{departmentWorkload.labPercent}</span>
                    <span className="text-[10px] text-slate-300 font-medium">Uyum: %{auditCompliance.labScore}</span>
                  </div>
                  <div className="text-[10px] text-indigo-300/80 truncate">
                    Dış MRL (650+), ağır metal, mikrobiyoloji
                  </div>
                </div>
              </div>

              {/* Çok Renkli Anlık Ağırlık İlerleme Çubuğu */}
              <div className="space-y-1 pt-1">
                <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden flex shadow-inner">
                  <div
                    style={{ width: `${departmentWorkload.qcPercent}%` }}
                    className="bg-emerald-500 transition-all duration-300 relative group cursor-pointer"
                    title={`Kalite Kontrol (QC): %${departmentWorkload.qcPercent}`}
                  />
                  <div
                    style={{ width: `${departmentWorkload.qpPercent}%` }}
                    className="bg-teal-400 transition-all duration-300 relative group cursor-pointer"
                    title={`Kalite Proses (QP): %${departmentWorkload.qpPercent}`}
                  />
                  <div
                    style={{ width: `${departmentWorkload.rdPercent}%` }}
                    className="bg-amber-400 transition-all duration-300 relative group cursor-pointer"
                    title={`Ar-Ge & Sürdürülebilirlik: %${departmentWorkload.rdPercent}`}
                  />
                  <div
                    style={{ width: `${departmentWorkload.labPercent}%` }}
                    className="bg-indigo-500 transition-all duration-300 relative group cursor-pointer"
                    title={`Laboratuvar & MRL: %${departmentWorkload.labPercent}`}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> QC (%{departmentWorkload.qcPercent})</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-teal-400 inline-block" /> QP (%{departmentWorkload.qpPercent})</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400 inline-block" /> Ar-Ge (%{departmentWorkload.rdPercent})</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-indigo-500 inline-block" /> Lab (%{departmentWorkload.labPercent})</span>
                </div>
              </div>
            </div>
          </div>

          {/* BÖLÜM A: KALİTE KONTROL (QC) DENETİMLERİ */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/10 text-emerald-600 rounded-xl">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    Kalite Kontrol (QC) İçerik ve Saha Denetim Kriterleri
                  </h3>
                  <p className="text-xs text-slate-500">Meyve kabul, şeker, sertlik, kalibrasyon ve iç muayene testleri</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-400 font-mono">
                QC Skoru: %{auditCompliance.qcScore}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {[
                {
                  id: 'QC-BRIX',
                  parameter: 'Meyve Şeker Doygunluğu (Brix Ölçümü)',
                  tool: 'Dijital Refraktometre (Atago PAL-1, 0-53° Bx)',
                  check: 'Her 5 tonda en az 10 tekil meyve test ediliyor mu? Prizma saf suyla sıfırlanıyor mu?',
                  action: 'Hasat öncesi şeker düzeyi ve tat doygunluğu resmi kayıt altına alınır.'
                },
                {
                  id: 'QC-PENETRO',
                  parameter: 'Meyve Eti Sertliği (Penetrometre Direnci)',
                  tool: 'FT-327 Penetrometre (8mm & 11mm kalibre uç)',
                  check: 'Meyvenin güneş ve gölge yanaklarından kabuk soyularak batırma testi yapılıyor mu?',
                  action: 'Soğuk depoda kaç ay dayanabileceği ve nakliye mukavemeti tayin edilir.'
                },
                {
                  id: 'QC-KUMPAS',
                  parameter: 'Meyve Çap Kalibrasyonu & Boylama',
                  tool: 'Dijital Kumpas & Çap Kalibrasyon Halkaları',
                  check: 'Ekstra Sınıf (55mm+) ile 1. Sınıf (45-54mm) kasaları sahada net ayrıştırılıyor mu?',
                  action: 'İhracat ve yerel pazar boylama standartlarına tam uyum sağlanır.'
                },
                {
                  id: 'QC-KESIT',
                  parameter: 'Çekirdek Çatlağı & İç Et Bozulması Muayenesi',
                  tool: 'Paslanmaz Laboratuvar Bıçağı & Büyüteç',
                  check: 'Şeftali ve nektarinde çekirdek çatlağı ve iç et kararması kesiti alınıyor mu?',
                  action: 'Gizli fizyolojik bozuklukların ihracat kolisine girmesi engellenir.'
                },
                {
                  id: 'QC-DEFECT',
                  parameter: 'Dış Kabuk Kusur & Tolerans Muayenesi',
                  tool: 'UNECE / EAC Standart Kusur Cetveli',
                  check: 'Güneş yanığı, trips lekesi ve rüzgar çiziği tolerans sınırları (%5) kontrol ediliyor mu?',
                  action: 'Kusurlu ürünler derhal Freeze-Dry veya 2. Sınıf hattına yönlendirilir.'
                },
                {
                  id: 'QC-NITRAT',
                  parameter: 'Hızlı Nitrat & Kimyasal İyon Taraması',
                  tool: 'Portatif Dijital Nitrat Ölçer (Greentest)',
                  check: 'Aşırı azotlu gübreleme kaynaklı meyve eti yumuşaması sahada taranıyor mu?',
                  action: 'Depo ömrünü tehdit eden yüksek nitratlı partiler ayrıştırılır.'
                }
              ].map((item) => {
                const st = auditStates[item.id] || 'ACTIVE';
                return (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between space-y-2.5 ${
                      st === 'ACTIVE'
                        ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                        : st === 'UNUSED'
                        ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-400'
                        : st === 'BROKEN'
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-400'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 flex-wrap">
                        <span className="font-mono text-[10px] font-bold text-slate-400">{item.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          st === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' :
                          st === 'UNUSED' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          st === 'BROKEN' ? 'bg-rose-500/20 text-rose-700 dark:text-rose-300' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st === 'ACTIVE' && '✅ AKTİF & UYGULANIYOR'}
                          {st === 'UNUSED' && '⚠️ VAR AMA KULLANILMIYOR (İHMAL)'}
                          {st === 'BROKEN' && '🚨 ARIZALI / KULLANILAMADI'}
                          {st === 'PLANNED' && '⏳ BİZDE YOK (HEDEF)'}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1">
                        {item.parameter}
                      </h4>
                      <div className="text-[11px] text-teal-600 dark:text-teal-400 font-mono mt-0.5">
                        🛠️ {item.tool}
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        🔍 <strong>Denetim:</strong> {item.check}
                      </p>
                    </div>

                    {/* 4 Durum Butonu */}
                    <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800">
                      <div className="text-[10px] font-bold text-slate-500 mb-1">Operasyonel Durum:</div>
                      <div className="grid grid-cols-4 gap-1 text-[9px] font-bold">
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(item.id, 'ACTIVE')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'ACTIVE' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5" />
                          <span>Aktif</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(item.id, 'UNUSED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'UNUSED' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Ban className="w-2.5 h-2.5" />
                          <span>İhmal</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(item.id, 'BROKEN')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'BROKEN' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Wrench className="w-2.5 h-2.5" />
                          <span>Arızalı</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(item.id, 'PLANNED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'PLANNED' ? 'bg-slate-700 text-white border-slate-700' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>Hedef</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* BÖLÜM B: KALİTE PROSES (QP) - MUZ KURDELE, MAP & SOĞUK ZİNCİR */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-teal-500/10 text-teal-600 rounded-xl">
                  <Wind className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    Kalite Proses (QP): Muz Kurdele Disiplini, MAP Torba & Soğuk Zincir
                  </h3>
                  <p className="text-xs text-slate-500">Muz kurdelesi, ihracat MAP şaseleri ve pull-down ön soğutma denetimleri</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-400 font-mono">
                QP Skoru: %{auditCompliance.qpScore}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {[
                {
                  id: 'QP-RIBBON',
                  processName: 'Muz 12-Haftalık Kurdele Hasat Uyum Denetimi',
                  rule: '12. hafta kurdele rengi gelmeden hevenk kesilemez! Erken kesilen muz depoda sararmaz.',
                  fieldIssue: 'Bazen tonaj baskısıyla 10. haftalık yeşil kurdele kesilmek istenebiliyor.'
                },
                {
                  id: 'QP-MAP',
                  processName: 'MAP Torba Sızdırmazlık & KMnO4 Şase Denetimi',
                  rule: 'MAP torba sadece ihracatta kullanılır; içine mutlaka mor KMnO4 gaz emici şase konmalıdır.',
                  fieldIssue: 'Her partide kullanılmıyor; kullanıldığında şase yerleşimi bazen unutuluyor.'
                },
                {
                  id: 'QP-PULLDOWN',
                  processName: 'Hasat Sonrası Çekirdek Isı Düşürme (Pull-Down)',
                  rule: 'Hasat edilen meyve maks 3 saatte gölgeye ve +12°C soğuk odaya çekilmelidir.',
                  fieldIssue: 'Tarlada traktör kasasında güneşte bekleme süresi uzarsa raf ömrü 10 gün kısalır.'
                },
                {
                  id: 'QP-GAS',
                  processName: 'NDIR Portatif Gaz Dedektörü ile CO₂ / Etilen Takibi',
                  rule: 'Muz sarartma ve soğuk hava depolarında CO₂ < %1 ve etilen kontrol edilmelidir.',
                  fieldIssue: 'Cihaz depoda var ama sahada rutin ölçüm yerine göz kararı havalandırma yapılabiliyor.'
                },
                {
                  id: 'QP-COLDCHAMBER',
                  processName: 'Soğuk Depo Kompresör & Bağıl Nem Rejimi (%90-95)',
                  rule: 'Nem kaybı meyvede buruşmaya neden olur; kompresör rejimi 24 saat izlenmelidir.',
                  fieldIssue: 'Kompresör gaz kaçırdığında sıcaklık anında yükselir; tesis ekibi sorumludur.'
                },
                {
                  id: 'QP-LOGGER',
                  processName: 'Frigorifik Tır Palet İçi Çift Data Logger Kaydı',
                  rule: 'İhracat tırında ön ve arka palete çift kalibre logger yerleştirilir.',
                  fieldIssue: 'Gümrük beklemesinde termoking mazotu biterse soğuk zincir kırılır.'
                }
              ].map((qp) => {
                const st = auditStates[qp.id] || 'ACTIVE';
                return (
                  <div
                    key={qp.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between space-y-2.5 ${
                      st === 'ACTIVE'
                        ? 'bg-teal-50/40 dark:bg-teal-950/20 border-teal-300 dark:border-teal-800'
                        : st === 'UNUSED'
                        ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-400'
                        : st === 'BROKEN'
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-400'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-400">{qp.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          st === 'ACTIVE' ? 'bg-teal-500/20 text-teal-700 dark:text-teal-300' :
                          st === 'UNUSED' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          st === 'BROKEN' ? 'bg-rose-500/20 text-rose-700 dark:text-rose-300' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st === 'ACTIVE' && 'AKTİF'}
                          {st === 'UNUSED' && 'İHMAL EDİLDİ'}
                          {st === 'BROKEN' && 'ARIZALI'}
                          {st === 'PLANNED' && 'HEDEF'}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 leading-tight">
                        {qp.processName}
                      </h4>
                      <p className="text-[11px] text-rose-600 dark:text-rose-400 font-bold mt-1">
                        🚨 Kural: {qp.rule}
                      </p>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        ⚠️ <strong>Saha Durumu:</strong> {qp.fieldIssue}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800">
                      <div className="grid grid-cols-4 gap-1 text-[9px] font-bold">
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(qp.id, 'ACTIVE')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'ACTIVE' ? 'bg-teal-600 text-white border-teal-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5" />
                          <span>Aktif</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(qp.id, 'UNUSED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'UNUSED' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Ban className="w-2.5 h-2.5" />
                          <span>İhmal</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(qp.id, 'BROKEN')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'BROKEN' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Wrench className="w-2.5 h-2.5" />
                          <span>Arıza</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(qp.id, 'PLANNED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'PLANNED' ? 'bg-slate-700 text-white border-slate-700' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>Hedef</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* BÖLÜM C: KALİTE AR-GE & İLERİ SÜRDÜRÜLEBİLİRLİK KRİTERLERİ */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 text-amber-600 rounded-xl">
                  <Microscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    Kalite Ar-Ge, Kök Neden & Sürdürülebilirlik Denetimi
                  </h3>
                  <p className="text-xs text-slate-500">Barlag Akty 5-Why kök neden analizi, simüle raf ömrü ve Freeze-Dry sıfır atık</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-400 font-mono">
                Ar-Ge Skoru: %{auditCompliance.rdScore}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {[
                {
                  id: 'RD-5WHY',
                  title: 'Barlag Akty 5-Why Derin Kök Neden Analizi',
                  desc: 'Hataları şahsa yıkmak yerine sistemsel arızayı 5 kez "Neden?" sorarak çözme disiplini.',
                  scope: 'Ezilme, çürüme veya erken sararma olduğunda kök neden tutanağı zorunludur.'
                },
                {
                  id: 'RD-SHELFLIFE',
                  title: 'Simüle Raf Ömrü (Shelf-Life) Test Odası',
                  desc: 'İhracat rotasındaki ortam sıcaklığı (+20°C pazar şartları) simüle edilerek kaç günde bozulduğu izlenir.',
                  scope: 'Dubai/Rusya sevkiyatları öncesi parti güvenilirliğini kanıtlar.'
                },
                {
                  id: 'RD-FREEZEDRY',
                  title: 'Freeze-Dry Liyofilizasyon Sıfır Atık Köprüsü',
                  desc: 'Görsel kusurlu ama lezzeti yüksek meyvelerin -40°C süblimasyonla 2 yıl ömürlü süper gıdaya dönüştürülmesi.',
                  scope: 'FAO Gıda Kaybı (FLW) oranını sıfıra indirir, katma değer sağlar.'
                },
                {
                  id: 'RD-BOTRYTIS',
                  title: 'Mantari Enfeksiyon & Botrytis Çürüme Yayılım Modeli',
                  desc: 'Hasat sonrası şeftali ve nektarinde monilinia ve gri küf sporlarının yayılma hızının takibi.',
                  scope: 'Soğuk depoda partiler arası bulaşmayı engelleyen erken karantina bariyeri.'
                },
                {
                  id: 'RD-DCA',
                  title: 'Dinamik Kontrollü Atmosfer (DCA) Simülasyonu',
                  desc: 'Oksijen seviyesini klorofil floresans sensörüyle sınıra kadar düşürerek meyve solunumunu durdurma.',
                  scope: 'Gelecek dönem Ar-Ge yatırımı (2027 vizyon hedefi).'
                }
              ].map((rd) => {
                const st = auditStates[rd.id] || 'ACTIVE';
                return (
                  <div
                    key={rd.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between space-y-2.5 ${
                      st === 'ACTIVE'
                        ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                        : st === 'UNUSED'
                        ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-400'
                        : st === 'BROKEN'
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-400'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-400">{rd.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          st === 'ACTIVE' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          st === 'UNUSED' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          st === 'BROKEN' ? 'bg-rose-500/20 text-rose-700 dark:text-rose-300' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st === 'ACTIVE' && 'AKTİF'}
                          {st === 'UNUSED' && 'İHMAL EDİLDİ'}
                          {st === 'BROKEN' && 'ARIZALI'}
                          {st === 'PLANNED' && 'HEDEF'}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 leading-tight">
                        {rd.title}
                      </h4>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        {rd.desc}
                      </p>
                      <p className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold mt-1">
                        🎯 Kapsam: {rd.scope}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800">
                      <div className="grid grid-cols-4 gap-1 text-[9px] font-bold">
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(rd.id, 'ACTIVE')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'ACTIVE' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5" />
                          <span>Aktif</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(rd.id, 'UNUSED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'UNUSED' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Ban className="w-2.5 h-2.5" />
                          <span>İhmal</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(rd.id, 'BROKEN')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'BROKEN' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Wrench className="w-2.5 h-2.5" />
                          <span>Arıza</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(rd.id, 'PLANNED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'PLANNED' ? 'bg-slate-700 text-white border-slate-700' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>Hedef</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* BÖLÜM D: LABORATUVAR & MRL - DIŞ AKREDİTE LAB & RESMİ ANALİZLER */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 text-indigo-600 rounded-xl">
                  <FlaskConical className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    Laboratuvar & MRL: Dış Akredite Lab & Resmi Analiz Yetkinlik Denetimi
                  </h3>
                  <p className="text-xs text-slate-500">
                    Pestisit kalıntı (650+ MRL), ağır metal, mikrobiyoloji ve ihraç sertifikasyon testleri
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-400 font-mono">
                Lab Skoru: %{auditCompliance.labScore} (Ağırlık: %{departmentWorkload.labPercent})
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {[
                {
                  id: 'LAB-MRL',
                  title: 'Dış Akredite Lab Pestisit MRL Taraması (650+ Etken Madde)',
                  tool: 'LC-MS/MS & GC-MS/MS Çoklu Kalıntı Taraması (Türkak / GOST Akredite)',
                  check: 'Her ihracat partisi öncesi meyve numuneleri mühürlü torbayla akredite dış laboratuvara gönderiliyor mu?',
                  action: 'Rusya Rosselkhoznadzor ve AB/Körfez MRL limitleri aşımı 0 tolerans ile engellenir.'
                },
                {
                  id: 'LAB-HEAVYMETAL',
                  title: 'Ağır Metal Analizleri (Kurşun Pb, Kadmiyum Cd, Arsenik As)',
                  tool: 'ICP-MS / Atomik Absorpsiyon Spektroskopisi',
                  check: 'Sulama suyu ve toprak kaynaklı ağır metal birikimi yılda en az 2 kez resmi dış laboratuvarda test ediliyor mu?',
                  action: 'EAC TR CU 021/2011 gıda güvenliği sınırlarına tam uygunluk garanti edilir.'
                },
                {
                  id: 'LAB-MICROBIO',
                  title: 'Patojen Mikrobiyoloji Testleri (Salmonella, E. coli O157, Listeria)',
                  tool: 'Klasik Kültür & Real-Time PCR Taraması',
                  check: 'Taze meyve yıkama havuzu ve ambalaj yüzeyinden hijyen swap ve meyve mikrobiyoloji analizi alınıyor mu?',
                  action: 'Uluslararası süpermarket zincirleri ve ihracat kabul kriterleri karşılanır.'
                },
                {
                  id: 'LAB-NITRATE_CONFIRM',
                  title: 'Nitrat Spektrofotometrik Dış Lab Doğrulama Testi',
                  tool: 'UV-Vis Spektrofotometre / İyon Kromatografisi',
                  check: 'Sahada portatif ölçülen nitrat değerleri dış akredite lab analiz sonuçları ile çapraz doğrulanıyor mu?',
                  action: 'Şeftali ve kavun/karpuzda aşırı nitrat birikimi resmi sertifikalandırılır.'
                },
                {
                  id: 'LAB-GMO',
                  title: 'GDO Tarama & Moleküler Biyoloji Dış Uygunluk Testi',
                  tool: 'Real-Time PCR 35S/NOS/FMV Promotor Taraması',
                  check: 'GDO-Free ve temiz tohum/fidan ihracat sertifikası dosyasında güncel mi?',
                  action: 'Yerel ve uluslararası pazarlar için "GDO İçermez" resmi ihracat pasaportu sağlanır.'
                }
              ].map((lab) => {
                const st = auditStates[lab.id] || 'ACTIVE';
                return (
                  <div
                    key={lab.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between space-y-2.5 ${
                      st === 'ACTIVE'
                        ? 'bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-300 dark:border-indigo-800'
                        : st === 'UNUSED'
                        ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-400'
                        : st === 'BROKEN'
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-400'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-400">{lab.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          st === 'ACTIVE' ? 'bg-indigo-500/20 text-indigo-700 dark:text-indigo-300' :
                          st === 'UNUSED' ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                          st === 'BROKEN' ? 'bg-rose-500/20 text-rose-700 dark:text-rose-300' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st === 'ACTIVE' && 'AKTİF & DIŞ LABDA'}
                          {st === 'UNUSED' && 'İHMAL EDİLDİ'}
                          {st === 'BROKEN' && 'İPTAL / KULLANILAMADI'}
                          {st === 'PLANNED' && 'HEDEF / PLAN'}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 leading-tight">
                        {lab.title}
                      </h4>
                      <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-mono mt-0.5">
                        🔬 {lab.tool}
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        🔍 <strong>Denetim:</strong> {lab.check}
                      </p>
                      <p className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold mt-1">
                        🎯 Aksiyon: {lab.action}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800">
                      <div className="grid grid-cols-4 gap-1 text-[9px] font-bold">
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(lab.id, 'ACTIVE')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'ACTIVE' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5" />
                          <span>Aktif</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(lab.id, 'UNUSED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'UNUSED' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Ban className="w-2.5 h-2.5" />
                          <span>İhmal</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(lab.id, 'BROKEN')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'BROKEN' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Wrench className="w-2.5 h-2.5" />
                          <span>İptal</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleAuditStatus(lab.id, 'PLANNED')}
                          className={`py-1 rounded border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                            st === 'PLANNED' ? 'bg-slate-700 text-white border-slate-700' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>Hedef</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}



      {/* ========================================================================= */}
      {/* SEKME 6: YETKİNLİK RADARI (RADAR MATRİSİ)                                 */}
      {/* ========================================================================= */}
      {activeTab === 'RADAR' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    Kalite Yetkinlik Dağılım Radarı (Mevcut vs 2027 Hedef)
                  </h3>
                  <p className="text-xs text-slate-500">Mevcut Seviye (Yeşil) ile 2027 Hedef Açığı (Mavi Çizgi)</p>
                </div>
                <span className="text-xs font-mono font-bold text-teal-600">6 Eksenli Matris</span>
              </div>

              <div className="w-full h-80 min-w-0">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                    <PolarGrid stroke="#cbd5e1" strokeDasharray="3 3" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Radar name="Mevcut Yetkinlik Seviyesi" dataKey="mevcut" stroke="#0d9488" fill="#14b8a6" fillOpacity={0.45} />
                    <Radar name="2027 Hedef Seviye" dataKey="hedef" stroke="#3b82f6" fill="#60a5fa" fillOpacity={0.2} strokeDasharray="4 4" />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '1rem', color: '#fff', fontSize: '11px' }} />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3 flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mb-2">
                  Yetkinlik Kırılımları ve Hedef Boşlukları (Gaps)
                </h4>
                <div className="space-y-2.5">
                  {radarData.map((item, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-200">
                        <span>{item.subject}</span>
                        <span className="font-mono text-[11px] text-teal-600 dark:text-teal-400">
                          Mevcut: %{item.mevcut} | Hedef: %{item.hedef}
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden flex">
                        <div style={{ width: `${item.mevcut}%` }} className="bg-teal-500 h-full rounded-full" />
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">{item.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-2xl text-[11px] text-teal-900 dark:text-teal-200 font-medium">
                💡 <strong>Yönetim Notu:</strong> Kalite bölümünün en büyük gelişim alanı %62 ile Barlag Akty kök-neden analizleridir. Saha personeline 5-Why eğitimi verildiğinde hedef %85 seviyesine ulaşacaktır.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SEKME 7: DEPARTMANLAR ARASI KARŞILIKLI İŞBİRLİĞİ & KALİTE PUANLAMASI       */}
      {/* ========================================================================= */}
      {activeTab === 'DEPT_COLLAB' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>Kalite & Diğer Departmanlar Arası Çift Yönlü Puanlama Matrisi</span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-emerald-500 text-white uppercase tracking-wider">
                      Platform Verileriyle Senkronize
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Platformumuzda gerçekleşen gerçek saha, hasat, depo, lojistik ve laboratuvar işlemlerine göre otomatik puanlama & interaktif SLA yönetimi
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setAutoSyncDeptScores(prev => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer ${
                    autoSyncDeptScores
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700'
                  }`}
                  title="Platformdaki tüm işlemler boyunca canlı otomatik puanlama"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>{autoSyncDeptScores ? '⚡ Platform Canlı Senkron (AÇIK)' : 'Manuel Ayar Modu (Pasif)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    // Platform canlı değerlerini tüm departmanlara uygula
                    const updated: Record<string, { qualityScore: number; deptScore: number; note?: string }> = {};
                    Object.entries(platformOperationMetrics.liveDeptStats).forEach(([k, v]) => {
                      updated[k] = { qualityScore: v.qualityScore, deptScore: v.deptScore, note: v.realOpsText };
                    });
                    setDeptCollaborationScores(updated);
                    setAutoSyncDeptScores(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-slate-700 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 text-xs font-bold transition shadow-xs cursor-pointer"
                  title="Platformdaki tüm gerçek işlem ve tutanaklara göre puanları canlı güncelle"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Platform Verilerine Göre Sıfırla</span>
                </button>
                <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700">
                  Karşılıklı SLA & Süreç Puanı
                </span>
              </div>
            </div>

            {/* Platform Operasyon Bilgi Notu */}
            <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 rounded-2xl flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Platform Entegrasyonu Aktif ({autoSyncDeptScores ? 'Canlı Senkronize' : 'Manuel Özelleştirilmiş'}):</strong> Puanlar; sistemdeki <strong>{harvestRecords.length} hasat</strong>, <strong>{fieldRecords.length} saha analizi</strong>, <strong>{ambarRecords.length} depo kabulü</strong>, <strong>{lojistikRecords.length} lojistik sevk</strong>, <strong>{freezeDryRecords.length} freeze-dry</strong> ve <strong>{incidentAccountability.total} barlag akty</strong> üzerinden işlemler boyunca canlı türetilmektedir.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {[
                { id: 'DEPT-HARVEST', name: 'Hasat & Toplama Şefliği', icon: '🌱', task: 'Dalında seçme, ezmeden toplama ve kasa gölgeleme', defaultQ: 92, defaultD: 88 },
                { id: 'DEPT-FIELD', name: 'Saha Ziraat & İlaçlama', icon: '🚜', task: 'Hasat öncesi Brix kontrolü ve PHI kalıntı bekleme süresi', defaultQ: 94, defaultD: 91 },
                { id: 'DEPT-COLD', name: 'Soğuk Depo & Tesis Bakım', icon: '❄️', task: 'Pull-down hızlı soğutma (<3 saat), SCADA nem (%90-95)', defaultQ: 96, defaultD: 93 },
                { id: 'DEPT-SORTING', name: 'Boylama & Paketleme Hattı', icon: '📦', task: 'Optik/kumpas boylama, düşme yüksekliği <15cm, darasız koli', defaultQ: 91, defaultD: 89 },
                { id: 'DEPT-LOGISTICS', name: 'Frigorifik Lojistik & Sevk', icon: '🚛', task: 'Dorse ön soğutma, çift logger ve transit soğuk zincir', defaultQ: 95, defaultD: 90 },
                { id: 'DEPT-FREEZEDRY', name: 'Freeze-Dry Liyofilizasyon', icon: '🫐', task: 'Sıfır atık, standart dışı ve kabuk kusurlu meyve kurtarma', defaultQ: 98, defaultD: 96 },
                { id: 'DEPT-SALES', name: 'Satış & İhracat Operasyon', icon: '🌐', task: 'Hedef pazar karantina toleransları ve müşteri geri bildirimi', defaultQ: 93, defaultD: 92 }
              ].map(dept => {
                const liveStat = platformOperationMetrics.liveDeptStats[dept.id];
                const stored = deptCollaborationScores[dept.id];
                const current = autoSyncDeptScores && liveStat ? {
                  qualityScore: liveStat.qualityScore,
                  deptScore: liveStat.deptScore,
                  note: liveStat.realOpsText
                } : (stored || {
                  qualityScore: liveStat ? liveStat.qualityScore : dept.defaultQ,
                  deptScore: liveStat ? liveStat.deptScore : dept.defaultD,
                  note: liveStat ? liveStat.realOpsText : ''
                });
                const avg = Math.round((current.qualityScore + current.deptScore) / 2);
                return (
                  <div
                    key={dept.id}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800 space-y-3 flex flex-col justify-between hover:border-emerald-500/50 transition-all shadow-xs"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span className="text-base">{dept.icon}</span>
                          <span>{dept.name}</span>
                        </span>
                        <span className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black ${
                          avg >= 90 ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          avg >= 80 ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                          'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}>
                          Ort: %{avg}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                        🎯 <strong>Süreç Görevi:</strong> {dept.task}
                      </p>
                      
                      {/* Platform Verisi Canlı İpucu */}
                      {liveStat && (
                        <div className="mt-2 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[10px] text-emerald-700 dark:text-emerald-300 font-medium">
                          📊 <strong>Platform Canlı Verisi:</strong> {liveStat.realOpsText}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-slate-200/80 dark:border-slate-800">
                      {/* 1. Kalitenin Bu Departmana Verdiği Puan */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                          <span className="flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
                            <span>Kalite ➔ {dept.name.split(' ')[0]} Puanı:</span>
                          </span>
                          <span className="font-mono text-teal-600 dark:text-teal-400">%{current.qualityScore}</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="100"
                          value={current.qualityScore}
                          onChange={(e) => {
                            setAutoSyncDeptScores(false);
                            updateDeptScore(dept.id, 'qualityScore', Number(e.target.value));
                          }}
                          className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
                        />
                      </div>

                      {/* 2. Bu Departmanın Kaliteye Verdiği Puan */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                          <span className="flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-emerald-500" />
                            <span>{dept.name.split(' ')[0]} ➔ Kalite Puanı:</span>
                          </span>
                          <span className="font-mono text-emerald-600 dark:text-emerald-400">%{current.deptScore}</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="100"
                          value={current.deptScore}
                          onChange={(e) => {
                            setAutoSyncDeptScores(false);
                            updateDeptScore(dept.id, 'deptScore', Number(e.target.value));
                          }}
                          className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                        />
                      </div>

                      {/* Hızlı Butonlar */}
                      <div className="flex items-center gap-1.5 pt-1 text-[10px]">
                        {liveStat && (
                          <button
                            type="button"
                            onClick={() => {
                              updateDeptScore(dept.id, 'qualityScore', liveStat.qualityScore);
                              updateDeptScore(dept.id, 'deptScore', liveStat.deptScore);
                            }}
                            className="flex-1 py-1 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-bold transition cursor-pointer text-center"
                            title="Bu departmanı platformdaki gerçek kayıtlara göre ayarla"
                          >
                            Platforma Uyarla ({liveStat.qualityScore})
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => { setAutoSyncDeptScores(false); updateDeptScore(dept.id, 'qualityScore', 95); updateDeptScore(dept.id, 'deptScore', 95); }}
                          className="flex-1 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-emerald-50 text-slate-700 dark:text-slate-300 font-bold transition cursor-pointer text-center"
                        >
                          Mükemmel (95)
                        </button>
                        <button
                          type="button"
                          onClick={() => { setAutoSyncDeptScores(false); updateDeptScore(dept.id, 'qualityScore', 85); updateDeptScore(dept.id, 'deptScore', 85); }}
                          className="flex-1 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-amber-50 text-slate-700 dark:text-slate-300 font-bold transition cursor-pointer text-center"
                        >
                          İyileşmeli (85)
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SEKME 8: MEYVE VE BAHÇEYE GÖRE ÖZEL KALİTE PUANLAMASI                     */}
      {/* ========================================================================= */}
      {activeTab === 'ORCHARD_FRUIT' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  <TreeDeciduous className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>Bahçe, Parsel & Meyve Türüne Göre Kalite Puanlama Panosu</span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500 text-white uppercase tracking-wider">
                      Platform İşlemleri Boyunca
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Hasat ve saha test kayıtlarımızdaki gerçek Brix (°Bx), sertlik, kusur toleransı ve toplam hasat tonajına göre hesaplanan canlı kalite puanları
                  </p>
                </div>
              </div>

              {/* Filtre ve Arama & Senkronize Buton */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setAutoSyncOrchardScores(prev => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer ${
                    autoSyncOrchardScores
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700'
                  }`}
                  title="Platformdaki tüm hasat ve saha testleri boyunca otomatik puanlama"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>{autoSyncOrchardScores ? '⚡ Platform Canlı Senkron (AÇIK)' : 'Manuel Ayar Modu (Pasif)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    // Platformdaki tüm bahçe/meyve verilerini canlı senkronize et
                    const updated: Record<string, { qualityScore: number; brixRating: number; handlingRating: number; note?: string }> = {};
                    platformOperationMetrics.dynamicOrchardFruitList.forEach(item => {
                      updated[item.key] = {
                        qualityScore: item.liveQualityScore,
                        brixRating: item.liveBrixScore,
                        handlingRating: item.liveHandlingScore,
                        note: item.realOpsText
                      };
                    });
                    setOrchardFruitScores(updated);
                    setAutoSyncOrchardScores(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-slate-700 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700 text-xs font-bold transition shadow-xs cursor-pointer"
                  title="Sistemdeki tüm hasat ve saha test kayıtlarına göre bahçe puanlarını güncelle"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Platform Verilerine Göre Sıfırla</span>
                </button>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={orchardFilterSearch}
                    onChange={(e) => setOrchardFilterSearch(e.target.value)}
                    placeholder="Bahçe veya meyve ara..."
                    className="pl-8 pr-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
                  />
                </div>
              </div>
            </div>

            {/* Tür Filtre Hapları */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {['ALL', 'Şeftali', 'Nektarin', 'Muz', 'Badem', 'Erik', 'Kiraz'].map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedFruitCategory(cat)}
                  className={`px-3 py-1 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedFruitCategory === cat
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat === 'ALL' ? 'Tüm Bahçeler & Meyveler' : cat}
                </button>
              ))}
            </div>

            {/* Platform Operasyon Bilgi Şeridi */}
            <div className="p-3 bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-2xl flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
              <div className="flex items-center gap-2">
                <TreeDeciduous className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>Platform Hasat & Saha Verisi Aktif ({autoSyncOrchardScores ? 'Canlı Senkronize' : 'Manuel Özelleştirilmiş'}):</strong> Toplam <strong>{fieldRecords.length} saha test protokolü</strong> ve <strong>{harvestRecords.length} hasat partisi</strong> taranmaktadır. Gerçek ölçülen Brix (°Bx), penetrometre sertliği ve hasat darbe oranına göre bahçe vizeleri işlemler boyunca otomatik hesaplanmaktadır.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {platformOperationMetrics.dynamicOrchardFruitList
                .filter(item => {
                  if (selectedFruitCategory !== 'ALL' && !item.type.toLowerCase().includes(selectedFruitCategory.toLowerCase())) {
                    return false;
                  }
                  if (!orchardFilterSearch) return true;
                  const q = orchardFilterSearch.toLowerCase();
                  return item.orchard.toLowerCase().includes(q) || item.fruit.toLowerCase().includes(q) || item.type.toLowerCase().includes(q);
                })
                .map(item => {
                  const stored = orchardFruitScores[item.key];
                  const current = autoSyncOrchardScores ? {
                    qualityScore: item.liveQualityScore,
                    brixRating: item.liveBrixScore,
                    handlingRating: item.liveHandlingScore,
                    note: item.realOpsText
                  } : (stored || {
                    qualityScore: item.liveQualityScore,
                    brixRating: item.liveBrixScore,
                    handlingRating: item.liveHandlingScore,
                    note: item.realOpsText
                  });
                  
                  return (
                    <div
                      key={item.key}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800 space-y-3 flex flex-col justify-between hover:border-amber-500/50 transition-all shadow-xs"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-mono font-bold text-amber-600 dark:text-amber-400">
                            {item.orchard}
                          </span>
                          <span className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black ${
                            current.qualityScore >= 92 ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                            current.qualityScore >= 82 ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300' :
                            'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}>
                            {current.qualityScore >= 92 ? 'A+ Ekstra' : current.qualityScore >= 82 ? 'A Standart' : 'B Sınıfı'} (%{current.qualityScore})
                          </span>
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">
                          {item.fruit}
                        </h4>
                        <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                          <span>Hedef Eşik: {item.targetBrix}</span>
                          {item.totalHarvestKg > 0 && (
                            <span className="font-mono text-emerald-600 font-bold">{item.totalHarvestKg.toLocaleString('tr-TR')} kg hasat</span>
                          )}
                        </div>

                        {/* Canlı Platform İpucu */}
                        <div className="mt-2 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[10px] text-amber-800 dark:text-amber-300 font-medium">
                          📊 <strong>Platform Canlı Verisi:</strong> {item.realOpsText}
                          <div className="text-[9px] text-slate-500 mt-0.5">
                            Ölçülen Ort: {item.avgMeasuredBrix}°Bx • Sertlik: {item.avgMeasuredHardness} kg/cm² • Kusur: %{item.avgDefectPct}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-slate-200/80 dark:border-slate-800 text-xs">
                        {/* Genel Kalite Puanı */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between font-bold text-slate-700 dark:text-slate-300">
                            <span>Genel Kalite Vizesi:</span>
                            <span className="font-mono text-teal-600">%{current.qualityScore}</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="100"
                            value={current.qualityScore}
                            onChange={(e) => {
                              setAutoSyncOrchardScores(false);
                              updateOrchardScore(item.key, 'qualityScore', Number(e.target.value));
                            }}
                            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
                          />
                        </div>

                        {/* Şeker / Brix & Tat Doygunluğu */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between font-bold text-slate-700 dark:text-slate-300">
                            <span>Brix / Şeker & Olgunluk Notu:</span>
                            <span className="font-mono text-amber-600">%{current.brixRating}</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="100"
                            value={current.brixRating}
                            onChange={(e) => {
                              setAutoSyncOrchardScores(false);
                              updateOrchardScore(item.key, 'brixRating', Number(e.target.value));
                            }}
                            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                          />
                        </div>

                        {/* Hasat & Kasa Hassasiyeti */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between font-bold text-slate-700 dark:text-slate-300">
                            <span>Toplama & Kasa Darbe Notu:</span>
                            <span className="font-mono text-emerald-600">%{current.handlingRating}</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="100"
                            value={current.handlingRating}
                            onChange={(e) => {
                              setAutoSyncOrchardScores(false);
                              updateOrchardScore(item.key, 'handlingRating', Number(e.target.value));
                            }}
                            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                          />
                        </div>

                        {/* Hızlı Butonlar */}
                        <div className="flex items-center gap-1.5 pt-1 text-[10px]">
                          <button
                            type="button"
                            onClick={() => {
                              updateOrchardScore(item.key, 'qualityScore', item.liveQualityScore);
                              updateOrchardScore(item.key, 'brixRating', item.liveBrixScore);
                              updateOrchardScore(item.key, 'handlingRating', item.liveHandlingScore);
                            }}
                            className="flex-1 py-1 rounded bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 font-bold transition cursor-pointer text-center"
                            title="Bu bahçeyi platformdaki gerçek saha ve hasat testlerine göre ayarla"
                          >
                            Platforma Uyarla ({item.liveQualityScore})
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setAutoSyncOrchardScores(false);
                              updateOrchardScore(item.key, 'qualityScore', 95);
                              updateOrchardScore(item.key, 'brixRating', 95);
                              updateOrchardScore(item.key, 'handlingRating', 95);
                            }}
                            className="flex-1 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-amber-50 text-slate-700 dark:text-slate-300 font-bold transition cursor-pointer text-center"
                          >
                            Ekstra (95)
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setAutoSyncOrchardScores(false);
                              updateOrchardScore(item.key, 'qualityScore', 88);
                              updateOrchardScore(item.key, 'brixRating', 88);
                              updateOrchardScore(item.key, 'handlingRating', 88);
                            }}
                            className="flex-1 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-slate-700 dark:text-slate-300 font-bold transition cursor-pointer text-center"
                          >
                            Standart (88)
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SEKME 9: STANDART DIŞI, YERE DÜŞEN, BOYLAMA & KARIŞIK SAPMALAR VE TOLERANS */}
      {/* ========================================================================= */}
      {activeTab === 'STANDARD_DEVIATION' && (
        <div className="space-y-4">
          <div className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl ${isDeviationScreenFit ? 'p-3.5 sm:p-4.5 space-y-3' : 'p-5 sm:p-6 space-y-4'} shadow-sm transition-all`}>
            
            {/* ÜST BAŞLIK VE EKRANA SIĞDIR KONTROLÜ */}
            <div className="flex items-center justify-between flex-wrap gap-2.5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 shrink-0">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 flex-wrap">
                    <span>Standart Dışı Meyve Sapmaları &amp; Tolerans Matrisi</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-700">
                      Canlı Sapma
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Yere düşen, boylanmamış ve karışık hasat oranları, sıfır toleranslı kırmızı hatlar ve Freeze-Dry kurtarma gücü
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setIsDeviationScreenFit(prev => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition border cursor-pointer ${
                    isDeviationScreenFit
                      ? 'bg-teal-600 text-white border-teal-500 shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                  }`}
                  title="Paneli ekrana tam sığdır veya dikey genişlet"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>{isDeviationScreenFit ? '🖥️ Ekrana Sığdırıldı' : '📜 Geniş Görünüm'}</span>
                </button>
              </div>
            </div>

            {/* 4 Canlı Sapma Göstergesi */}
            <div className={`grid grid-cols-2 lg:grid-cols-4 ${isDeviationScreenFit ? 'gap-2.5 pt-0.5' : 'gap-3.5 pt-2'}`}>
              <div className={`${isDeviationScreenFit ? 'p-2.5 sm:p-3 space-y-1' : 'p-4 space-y-1.5'} rounded-2xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-800/60 transition`}>
                <div className="flex items-center justify-between text-[11px] font-bold text-rose-800 dark:text-rose-300">
                  <span className="truncate">Yere Düşen Meyve</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-rose-200 dark:bg-rose-900 text-rose-900 dark:text-rose-100 shrink-0">ZORUNLU</span>
                </div>
                <div className={`${isDeviationScreenFit ? 'text-lg sm:text-xl' : 'text-2xl'} font-black text-rose-700 dark:text-rose-400`}>
                  %{standardDeviationAnalytics.groundFallenPct} <span className="text-[10px] font-normal text-slate-500">({standardDeviationAnalytics.groundFallenWeightKg} kg)</span>
                </div>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 leading-tight">
                  Toprağa temas eden meyve taze sofralık koliye KESİNLİKLE giremez (mikrobiyel risk).
                </p>
              </div>

              <div className={`${isDeviationScreenFit ? 'p-2.5 sm:p-3 space-y-1' : 'p-4 space-y-1.5'} rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/60 transition`}>
                <div className="flex items-center justify-between text-[11px] font-bold text-amber-800 dark:text-amber-300">
                  <span className="truncate">Boylanmamış (Unsorted)</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 shrink-0">ESNEK</span>
                </div>
                <div className={`${isDeviationScreenFit ? 'text-lg sm:text-xl' : 'text-2xl'} font-black text-amber-700 dark:text-amber-400`}>
                  %{standardDeviationAnalytics.unsortedPct} <span className="text-[10px] font-normal text-slate-500">({standardDeviationAnalytics.unsortedWeightKg} kg)</span>
                </div>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 leading-tight">
                  Boylanmamış kasalar tesiste optik eleğe girer veya iç pazar kasalamasına yönlendirilir.
                </p>
              </div>

              <div className={`${isDeviationScreenFit ? 'p-2.5 sm:p-3 space-y-1' : 'p-4 space-y-1.5'} rounded-2xl bg-orange-50/60 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800/60 transition`}>
                <div className="flex items-center justify-between text-[11px] font-bold text-orange-800 dark:text-orange-300">
                  <span className="truncate">Karışık Toplama (Mix)</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-orange-200 dark:bg-orange-900 text-orange-900 dark:text-orange-100 shrink-0">KONTROLLÜ</span>
                </div>
                <div className={`${isDeviationScreenFit ? 'text-lg sm:text-xl' : 'text-2xl'} font-black text-orange-700 dark:text-orange-400`}>
                  %{standardDeviationAnalytics.mixedHarvestPct} <span className="text-[10px] font-normal text-slate-500">({standardDeviationAnalytics.mixedHarvestWeightKg} kg)</span>
                </div>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 leading-tight">
                  Farklı parsel/çeşit karışımında parti kodu bölünür, Freeze-Dry veya sanayiye sevk edilir.
                </p>
              </div>

              <div className={`${isDeviationScreenFit ? 'p-2.5 sm:p-3 space-y-1' : 'p-4 space-y-1.5'} rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 transition`}>
                <div className="flex items-center justify-between text-[11px] font-bold text-emerald-800 dark:text-emerald-300">
                  <span className="truncate">Freeze-Dry Kurtarma</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-200 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-100 shrink-0">SIFIR ATIK</span>
                </div>
                <div className={`${isDeviationScreenFit ? 'text-lg sm:text-xl' : 'text-2xl'} font-black text-emerald-700 dark:text-emerald-400`}>
                  %{standardDeviationAnalytics.rescueRatePct} <span className="text-[10px] font-normal text-slate-500">({standardDeviationAnalytics.rescuedViaFreezeDryKg} kg)</span>
                </div>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 leading-tight">
                  Kusurlu meyvelerin liyofilizasyonla yüksek katma değerli süper gıdaya dönüştürülme oranı.
                </p>
              </div>
            </div>

            {/* İNTERAKTİF YÜZDELERİ YÜRÜTME GÜCÜ & SENARYO SİMÜLATÖRÜ */}
            {(() => {
              const activeGroundPct = simulatedGroundFallenPct ?? standardDeviationAnalytics.groundFallenPct;
              const activeUnsortedPct = simulatedUnsortedPct ?? standardDeviationAnalytics.unsortedPct;
              const activeMixedPct = simulatedMixedHarvestPct ?? standardDeviationAnalytics.mixedHarvestPct;
              const activeRescueEff = simulatedRescueEfficiency;

              const totalAssessed = standardDeviationAnalytics.totalAssessedKg;
              if (totalAssessed === 0) {
                return (
                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-500 text-xs text-center space-y-1">
                    <p className="font-semibold text-slate-700 dark:text-slate-300">Henüz Kayıtlı Ürün veya Hasat Verisi Yok</p>
                    <p className="text-[11px] text-slate-400">Gerçek hasat veya ambar kabul kayıtları girildiğinde standart dışı meyve sapmaları ve senaryo motoru otomatik olarak aktifleşecektir.</p>
                  </div>
                );
              }
              const simGroundKg = Math.round((totalAssessed * activeGroundPct) / 100);
              const simUnsortedKg = Math.round((totalAssessed * activeUnsortedPct) / 100);
              const simMixedKg = Math.round((totalAssessed * activeMixedPct) / 100);
              
              // Kurtarma tonajı: Boylanmamışın %45'i + karışığın %60'ı + standart dışının %80'i Freeze-Dry ve sanayiye aktarılır
              const simRescuedKg = Math.round(((simUnsortedKg * 0.45) + (simMixedKg * 0.60) + (totalAssessed * 0.08)) * (activeRescueEff / 100));
              const simFreshExportableKg = Math.max(0, Math.round(totalAssessed - simGroundKg - (simUnsortedKg * 0.55) - (simMixedKg * 0.4)));
              const simQualityIndex = Math.max(50, Math.min(100, Math.round(98 - (activeGroundPct * 2.8) - (activeUnsortedPct * 0.35) - (activeMixedPct * 0.45) + ((activeRescueEff - 80) * 0.12))));

              const isZeroToleranceBreached = activeGroundPct > 3.0;

              return (
                <div className={`${isDeviationScreenFit ? 'p-3.5 sm:p-4 space-y-2.5' : 'p-5 space-y-4'} rounded-2xl bg-slate-900 text-white border border-slate-700/60 shadow-lg mt-1 transition-all`}>
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-teal-500/20 text-teal-400 border border-teal-500/30 shrink-0">
                        <Sliders className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                          <span>Yüzdeleri Yürütme Gücü &amp; Senaryo Simülatörü</span>
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-teal-500 text-slate-950 uppercase tracking-wider">
                            Canlı Motor
                          </span>
                        </h4>
                        <p className="text-[10px] text-slate-400">
                          Kaydırıcılarla anlık kurtarma tonajını ve kalite endeksini yürütün
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          setSimulatedGroundFallenPct(null);
                          setSimulatedUnsortedPct(null);
                          setSimulatedMixedHarvestPct(null);
                          setSimulatedRescueEfficiency(92);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold transition border border-slate-700 cursor-pointer flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Sıfırla</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSimulatedGroundFallenPct(1.2);
                          setSimulatedUnsortedPct(4.0);
                          setSimulatedMixedHarvestPct(2.5);
                          setSimulatedRescueEfficiency(98);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-[11px] font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Sıfır Atık Hedefi</span>
                      </button>
                    </div>
                  </div>

                  {/* 4 İnteraktif Simülatör Kaydırıcısı */}
                  <div className={`grid grid-cols-2 lg:grid-cols-4 ${isDeviationScreenFit ? 'gap-2.5 p-2.5' : 'gap-4 p-4'} rounded-xl bg-slate-800 border border-slate-800 text-xs`}>
                    {/* Kaydırıcı 1: Yere Düşen Meyve */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between font-bold text-[11px]">
                        <span className="text-rose-400 truncate">Yere Düşen:</span>
                        <span className="font-mono text-rose-300 text-xs font-black">%{activeGroundPct} ({simGroundKg}kg)</span>
                      </div>
                      <input
                        type="range"
                        min="0.2"
                        max="12.0"
                        step="0.1"
                        value={activeGroundPct}
                        onChange={(e) => setSimulatedGroundFallenPct(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-rose-500"
                      />
                      <div className="text-[9px] text-slate-400 truncate">
                        {isZeroToleranceBreached ? (
                          <span className="text-rose-400 font-bold">🔴 CCP İhlali! Yasak</span>
                        ) : (
                          <span className="text-emerald-400 font-bold">🟢 Güvenli (&lt;%3)</span>
                        )}
                      </div>
                    </div>

                    {/* Kaydırıcı 2: Boylama Yapılmayan */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between font-bold text-[11px]">
                        <span className="text-amber-400 truncate">Boylanmamış:</span>
                        <span className="font-mono text-amber-300 text-xs font-black">%{activeUnsortedPct} ({simUnsortedKg}kg)</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="30"
                        step="0.5"
                        value={activeUnsortedPct}
                        onChange={(e) => setSimulatedUnsortedPct(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                      />
                      <div className="text-[9px] text-slate-400 truncate">
                        Optik elek &amp; iç pazar kasalama
                      </div>
                    </div>

                    {/* Kaydırıcı 3: Karışık Toplama */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between font-bold text-[11px]">
                        <span className="text-orange-400 truncate">Karışık (Mix):</span>
                        <span className="font-mono text-orange-300 text-xs font-black">%{activeMixedPct} ({simMixedKg}kg)</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="25"
                        step="0.5"
                        value={activeMixedPct}
                        onChange={(e) => setSimulatedMixedHarvestPct(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                      />
                      <div className="text-[9px] text-slate-400 truncate">
                        Parti ayırma &amp; Freeze-Dry
                      </div>
                    </div>

                    {/* Kaydırıcı 4: Freeze-Dry Kurtarma Gücü */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between font-bold text-[11px]">
                        <span className="text-emerald-400 truncate">FD Gücü:</span>
                        <span className="font-mono text-emerald-300 text-xs font-black">%{activeRescueEff}</span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="100"
                        step="1"
                        value={activeRescueEff}
                        onChange={(e) => setSimulatedRescueEfficiency(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                      />
                      <div className="text-[9px] text-slate-400 truncate">
                        Liyofilizasyon sıfır atık
                      </div>
                    </div>
                  </div>

                  {/* Simülasyon Yürütme Canlı Çıktı Kartları */}
                  <div className={`grid grid-cols-2 lg:grid-cols-4 ${isDeviationScreenFit ? 'gap-2 pt-0.5' : 'gap-3 pt-1'}`}>
                    <div className={`${isDeviationScreenFit ? 'p-2 space-y-0.5' : 'p-3 space-y-1'} rounded-xl bg-slate-800/80 border border-slate-700`}>
                      <div className="text-[10px] text-slate-400 font-semibold truncate">Kurtarılan Net Tonaj</div>
                      <div className={`${isDeviationScreenFit ? 'text-sm sm:text-base' : 'text-lg'} font-black text-emerald-400 font-mono`}>
                        {simRescuedKg.toLocaleString('tr-TR')} kg
                      </div>
                      <div className="text-[9px] text-slate-400 truncate">FD + sanayi geri kazanımı</div>
                    </div>

                    <div className={`${isDeviationScreenFit ? 'p-2 space-y-0.5' : 'p-3 space-y-1'} rounded-xl bg-slate-800/80 border border-slate-700`}>
                      <div className="text-[10px] text-slate-400 font-semibold truncate">Taze Sofralık İhracat</div>
                      <div className={`${isDeviationScreenFit ? 'text-sm sm:text-base' : 'text-lg'} font-black text-teal-300 font-mono`}>
                        {simFreshExportableKg.toLocaleString('tr-TR')} kg
                      </div>
                      <div className="text-[9px] text-slate-400 truncate">Darasız sofralık 1. sınıf</div>
                    </div>

                    <div className={`${isDeviationScreenFit ? 'p-2 space-y-0.5' : 'p-3 space-y-1'} rounded-xl bg-slate-800/80 border border-slate-700`}>
                      <div className="text-[10px] text-slate-400 font-semibold truncate">Kalite Vize Endeksi</div>
                      <div className={`${isDeviationScreenFit ? 'text-sm sm:text-base' : 'text-lg'} font-black text-amber-300 font-mono`}>
                        %{simQualityIndex}
                      </div>
                      <div className="text-[9px] text-slate-400 truncate">Toleranslar dahil</div>
                    </div>

                    <div className={`${isDeviationScreenFit ? 'p-2 space-y-0.5' : 'p-3 space-y-1'} rounded-xl bg-slate-800/80 border border-slate-700`}>
                      <div className="text-[10px] text-slate-400 font-semibold truncate">Gıda Güvenliği CCP</div>
                      <div className={`text-[11px] font-bold leading-tight ${isZeroToleranceBreached ? 'text-rose-400' : 'text-emerald-400'} truncate`}>
                        {isZeroToleranceBreached ? '🔴 ALARM: CCP İhlali' : '✅ ONAY: Standart Uygun'}
                      </div>
                      <div className="text-[9px] text-slate-400 truncate">
                        {isZeroToleranceBreached ? 'Toprak teması sofralığa yasak' : 'Tolerans CCP sınırında'}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Zorunlu vs Esnek Yerler Karşılaştırma Matrisi */}
            <div className={`grid grid-cols-1 md:grid-cols-2 ${isDeviationScreenFit ? 'gap-3 pt-2.5' : 'gap-4 pt-4'} border-t border-slate-100 dark:border-slate-800`}>
              <div className={`${isDeviationScreenFit ? 'p-3 space-y-2' : 'p-4 space-y-3'} rounded-2xl bg-rose-50/40 dark:bg-rose-950/10 border border-rose-200 dark:border-rose-900/40`}>
                <div className="flex items-center gap-2 text-rose-800 dark:text-rose-300 font-bold text-xs sm:text-sm">
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>🔴 ZORUNLU OLAN YERLER (Sıfır Tolerans - Geçit Yok)</span>
                </div>
                <ul className={`${isDeviationScreenFit ? 'space-y-1.5 text-[11px]' : 'space-y-2 text-xs'} text-slate-700 dark:text-slate-300`}>
                  <li className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold">•</span>
                    <span><strong>MRL ve Pestisit Kalıntısı:</strong> Yasal limiti aşan ürün sofralık veya ihracata KESİNLİKLE verilemez.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold">•</span>
                    <span><strong>Yere Düşen Meyve (Toprak Teması):</strong> Çamurlu veya toprağa temas etmiş meyveler taze sofralık koliye giremez.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold">•</span>
                    <span><strong>Küf, Maya &amp; Patojen Çürüklük:</strong> Tek bir çürük meyve tüm koliyi enfekte edeceğinden derhal imha edilir.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold">•</span>
                    <span><strong>Muz 12. Hafta Kurdele Kuralı:</strong> 10. haftalık yeşil kurdele tonaj için erken kesilemez, sararmaz.</span>
                  </li>
                </ul>
              </div>

              <div className={`${isDeviationScreenFit ? 'p-3 space-y-2' : 'p-4 space-y-3'} rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/10 border border-emerald-200 dark:border-emerald-900/40`}>
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs sm:text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>🟢 ESNEK OLAN YERLER (Kurtarılabilir &amp; Alternatif Kanallar)</span>
                </div>
                <ul className={`${isDeviationScreenFit ? 'space-y-1.5 text-[11px]' : 'space-y-2 text-xs'} text-slate-700 dark:text-slate-300`}>
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold">•</span>
                    <span><strong>Boylama &amp; Kalibre Çapı:</strong> Küçük kalibre meyveler ihracata gitmese bile yerel pazara veya püre/reçele uygundur.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold">•</span>
                    <span><strong>Hafif Rüzgar Çiziği &amp; Kabuk Kusuru:</strong> Meyve eti sağlamsa Freeze-Dry süblimasyonda dilimlenerek %100 kurtarılır.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold">•</span>
                    <span><strong>Renk Tonu &amp; Güneş Yanığı:</strong> Tam kızarmamış meyveler iç piyasa toptancı haline esnek toleransla verilebilir.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold">•</span>
                    <span><strong>Karışık Toplama (Mix):</strong> Tesiste optik tasnif ile sınıflara bölünüp çift sayım engellenerek sevk edilebilir.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SEKME 10: DEPARTMAN PUANLAMA MODÜLÜ & 3 AYLIK KPI TRENDLERİ (P2 ENTEGRE)  */}
      {/* ========================================================================= */}
      {activeTab === 'DEPT_SCORING' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                <Award className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-indigo-950 dark:text-indigo-200">
                  Departman Puanlama &amp; Sorumluluk Modülü (Platform 02 Entegre)
                </h4>
                <p className="text-xs text-indigo-700 dark:text-indigo-300">
                  Departmanlar arası çapraz KPI puanlama matrisi, Recharts ile son 3 aylık eğilim grafikleri ve formatlı PDF raporlama.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('OVERVIEW')}
              className="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-700 text-xs font-bold hover:bg-indigo-100 transition cursor-pointer shadow-xs"
            >
              ← Platform 02 Genel Bakışa Dön
            </button>
          </div>

          {isAdminUser && (
            <DepartmentScoringPortal
              onBackToMainApp={() => setActiveTab('OVERVIEW')}
              currentUser={currentUser}
            />
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SAYFA EN ALTI (PAGE FOOTER AREA): SÜRDÜRÜLEBİLİRLİK & TREND RAPORLARI */}
      {/* ========================================================================= */}
      <div id="sustainability-footer-section" className="pt-6 border-t-2 border-slate-300 dark:border-slate-800 space-y-6">
        
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-600 text-white shadow-md">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                Sürdürülebilirlik, Trend ve Gelişim Raporları (Canlı Panolar)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Yönetim ve Paydaşlar İçin Açıklamalı Görsel Analizler (PDF Harici Canlı Göstergeler)
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-xl text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
            Page Footer Analytics
          </span>
        </div>

        {/* CANLI GRAFİK 1: YETKİNLİK DAĞILIMI VE HATA ÖNLEME */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
              Grafik 1: Kalite Bölümü Yetkinlik ve Olgunluk Analizi
            </h3>
            <span className="text-xs text-teal-600 dark:text-teal-400 font-semibold font-mono">Radar & Gap Dağılımı</span>
          </div>

          <div className="w-full h-72 min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid stroke="#cbd5e1" strokeDasharray="3 3" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 10, fontWeight: 700 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 9 }} />
                <Radar name="Mevcut Seviye" dataKey="mevcut" stroke="#0d9488" fill="#14b8a6" fillOpacity={0.4} />
                <Radar name="2027 Hedef" dataKey="hedef" stroke="#3b82f6" fill="#60a5fa" fillOpacity={0.15} strokeDasharray="3 3" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#fff', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
              <Info className="w-4 h-4" />
              <span>Grafik Açıklama Kutusu (Yönetim & Paydaş Özeti)</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">🎯 Bu Grafik Ne İçin Var?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  Kalite Bölümünün 6 ana disiplindeki yetkinliğini ve 2027 hedef açığını tek bakışta göstermek için vardır.
                </span>
              </div>
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">📢 Yönetime / Abonelere Ne Söyler?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  Saha meyve kontrolü ve depo proseslerimizin (%85+) güçlü olduğunu; Barlag Akty kök neden analizi (%62) alanında gelişim gerektiğini nesnel kanıtlarla açıklar.
                </span>
              </div>
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">🚀 Gelecek Yıl Stratejisine Etkisi Nedir?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  Milyon dolarlık kurum içi kromatografi cihazı almak yerine; bütçenin dijital refraktometre, IoT soğuk hava sensörleri ve 5-Why eğitimine aktarılmasını doğrular.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* CANLI GRAFİK 2: MEYVE KALİTE SINIFLANDIRMASI VE FREEZE-DRY SIFIR ATIK KÖPRÜSÜ */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
              Grafik 2: Meyve Sınıflandırma ve Freeze-Dry Sıfır Atık Trendi
            </h3>
            <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold font-mono">FAO FLW Gıda Kaybı Önleme</span>
          </div>

          {!hasGrafik2Records ? (
            <div className="w-full h-64 flex flex-col items-center justify-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800 p-6 text-center">
              <BarChart3 className="w-10 h-10 text-slate-400 mb-2" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">Veri yok</p>
              <p className="text-xs text-slate-500 mt-1">
                Kayıtlı ambar kabul veya freeze-dry verisi bulunmadığından sınıflandırma grafiği oluşturulamadı.
              </p>
            </div>
          ) : (
            <div className="w-full h-64 min-w-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={grafik2Data}
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" opacity={0.5} />
                  <XAxis dataKey="category" tick={{ fill: '#64748b', fontSize: 11 }} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 10 }} unit="%" />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#fff', fontSize: '11px' }} />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="ekstra" name="Ekstra Sınıf (İhracat %)" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="birinci" name="1. Sınıf (Yerel %)" fill="#0d9488" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="freezeDry" name="Freeze & Dry Kurtarma %" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="fire" name="Çöp / Fire %" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              <Info className="w-4 h-4" />
              <span>Grafik Açıklama Kutusu (Sıfır Atık & Katma Değer Analizi)</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">🎯 Bu Grafik Ne İçin Var?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  Bahçeden gelen meyvenin ne kadarının Ekstra İhracata, ne kadarının yerel pazara gittiğini ve standart dışı ürünlerin Freeze-Dry ile nasıl kurtarıldığını belgeler.
                </span>
              </div>
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">📢 Yönetime / Abonelere Ne Söyler?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  "Kabuk kusurlu meyve çöptür" algısını yıkarak, Freeze-Dry tesisinin sağladığı %70+ katma değerli geri kazanım oranını kanıtlar.
                </span>
              </div>
              <div>
                <strong className="text-slate-900 dark:text-white block mb-0.5">🚀 Gelecek Yıl Stratejisine Etkisi Nedir?</strong>
                <span className="text-slate-600 dark:text-slate-300">
                  FAO Gıda Kaybı ve İsrafı (FLW) hedeflerine uyumu garanti eder; pazar dalgalanmalarında satış riskini minimize eder.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 5. MIWE HIL KALİTE & İZLENEBİLİRLİK KILAVUZU */}
        <div className="bg-gradient-to-r from-teal-950/60 via-slate-900 to-slate-900 border border-teal-500/30 rounded-3xl p-5 sm:p-7 text-white space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-500/40">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white">
                MIWE HIL Kalite & İzlenebilirlik Kılavuzu (Neden & Nasıl?)
              </h3>
              <p className="text-xs text-slate-300">
                Saha uzmanları ve yöneticiler için yapılan testlerin pratik amaçları
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2 text-xs">
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1">
              <div className="font-bold text-teal-300">1. Brix ve Penetrometre Neden Yapılır?</div>
              <p className="text-slate-300 leading-relaxed">
                Meyvenin sadece görünüşüne bakılarak hasat edilmesini engeller. Şeker oranı (Brix) lezzeti, penetrometre sertliği ise soğuk hava deposunda kaç ay bozulmadan kalabileceğini bilimsel olarak tayin eder.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1">
              <div className="font-bold text-amber-300">2. Muz Kurdele ve MAP Torba Neden Takip Edilir?</div>
              <p className="text-slate-300 leading-relaxed">
                Muzda 12-haftalık kurdele takvimiyle aynı olgunluktaki hevenkler aynı gün kesilir. MAP torba solunumu yavaşlatıp etilen gazını absorbe ederek tarladan Rusya/Dubai'ye kadar yeşil kalmayı garanti eder.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1">
              <div className="font-bold text-rose-300">3. Barlag Akty ve 5-Why Kök Neden Neden Tutulur?</div>
              <p className="text-slate-300 leading-relaxed">
                Hataları kişilere yıkmak yerine sistemsel arızayı bulmak için tutulur. "Şeftali neden ezildi?" sorusuna 5 kez "Neden?" sorularak kasa tipinin veya yol sarsıntısının düzeltilmesi sağlanır.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1">
              <div className="font-bold text-emerald-300">4. Freeze-Dry Neden En Büyük Sürdürülebilirlik Bariyeridir?</div>
              <p className="text-slate-300 leading-relaxed">
                Şekli bozuk, hafif rüzgar çiziği olan veya pazarda satılmayıp depoda yumuşayan meyvelerin çöpe gitmesini önler. -40°C şok dondurma ve vakumla 2 yıl raf ömürlü süper gıdaya dönüştürerek çiftçiye kazandırır.
              </p>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SEKME: 2026 GAP VİZYONU & 5 KRİTİK EKSİK YOL HARİTASI                      */}
        {/* ========================================================================= */}
        {activeTab === 'GAP_VISION_2026' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-900 border border-amber-500/40 rounded-3xl p-5 sm:p-6 text-white space-y-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h3 className="text-base sm:text-lg font-black tracking-tight text-white">
                  FoodReady.ai 2026 Vizyonu: 5 Kritik GAP Analizi &amp; KPI Eylem Planı
                </h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
                Dünya lideri taze gıda yazılımları (Clarifruit, Silo, Produce Pro, Croptracker) ile aramızdaki farkları kapatmak ve Avrasya koridorunun tartışmasız 1 numaralı platformu olmak için sisteme entegre edilen 5 stratejik bileşen.
              </p>
            </div>

            {/* 5 Critical GAP Cards */}
            <div className="space-y-4">
              
              {/* GAP 1 */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-500 font-black text-xs flex items-center justify-center font-mono">
                      01
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      🔴 Gerçek Zamanlı IoT Sensör &amp; Otomatik Telemetri Entegrasyonu
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    CANLI KULLANIMA ALINDI
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <strong className="text-slate-800 dark:text-slate-200 block mb-1">Mevcut Durum &amp; Saha Riski:</strong>
                    Frigo tır dereceleri ve CA soğuk oda gaz değerleri manuel girildiğinde insan hatasına açıktır; yolda meydana gelen 2 saatlik ani soğuk zincir kırılması dorse açılana kadar fark edilemez.
                  </div>
                  <div className="bg-emerald-50/60 dark:bg-emerald-950/30 p-3 rounded-xl border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
                    <strong className="text-emerald-950 dark:text-emerald-300 block mb-1">Sistemdeki Aktif Çözüm:</strong>
                    Sisteme eklenen <strong>IoT Sensör Telemetri Paneli</strong> ile WebSocket üzerinden 2.5 saniyede bir sıcaklık, nem, CO₂ ve etilen akışı izlenmekte; limit aşımında otomatik sesli/görsel alarm tetiklenmektedir.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                  <span>Sensör Protokolü: Sensitech TempTale Ultra BLE / Emerson GO Real-Time</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">KPI Hedefi: %100 Kesintisiz Soğuk Zincir</span>
                </div>
              </div>

              {/* GAP 2 */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-500 font-black text-xs flex items-center justify-center font-mono">
                      02
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      🔴 Blockchain Tabanlı Dağıtık Defter &amp; FSMA 204 Kuralı (KDE / CTE)
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    SHA-256 DEFTERİ ENTEGRE
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <strong className="text-slate-800 dark:text-slate-200 block mb-1">Mevcut Durum &amp; Regülasyon Riski:</strong>
                    Parti kayıtları veritabanında saklansa da FDA FSMA Bölüm 204 kuralı uyarınca 24 saat içinde sunulabilen kriptografik olarak değiştirilemez bir KDE/CTE denetim zinciri gereklidir.
                  </div>
                  <div className="bg-emerald-50/60 dark:bg-emerald-950/30 p-3 rounded-xl border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
                    <strong className="text-emerald-950 dark:text-emerald-300 block mb-1">Sistemdeki Aktif Çözüm:</strong>
                    Her operasyonel adımda (hasat, lojistik, kabul) otomatik SHA-256 hash zinciri oluşturan <strong>Traceability Ledger</strong> bileşeni geliştirildi. Tek tıkla JSON ve RFC-6962 denetim çıktısı üretilmektedir.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                  <span>Standart: US FDA FSMA 204 KDE/CTE &amp; GS1 EPCIS v2.0</span>
                  {onNavigateToView && (
                    <button
                      type="button"
                      onClick={() => onNavigateToView('TRACEABILITY_LEDGER')}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                    >
                      Kriptografik Ledger'a Git →
                    </button>
                  )}
                </div>
              </div>

              {/* GAP 3 */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-500 font-black text-xs flex items-center justify-center font-mono">
                      03
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      🟡 Mobil Kamera Destekli AI Bilgisayarlı Görü (Computer Vision)
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                    SİMÜLASYON HAZIR
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <strong className="text-slate-800 dark:text-slate-200 block mb-1">Mevcut Durum &amp; Sübjektiflik:</strong>
                    Renklenme yüzdesi ve kabuk paslanması müfettişin gözlemiyle girildiğinde vardiyalar arasında %10-15 sübjektif değerlendirme farkı doğabilmektedir.
                  </div>
                  <div className="bg-cyan-50/60 dark:bg-cyan-950/30 p-3 rounded-xl border border-cyan-200 dark:border-cyan-800 text-cyan-900 dark:text-cyan-200">
                    <strong className="text-cyan-950 dark:text-cyan-300 block mb-1">2026 Eylem Planı:</strong>
                    Kasa fotoğrafı üzerinden meyve kalibre çapını ve renklenme yüzdesini 1 saniyede çıkaran hafif WebGL/TensorFlow Lite modeli entegrasyonu.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                  <span>Referans Rakip: Clarifruit AI Optik Boylama Motoru</span>
                  <span className="font-mono text-cyan-600 dark:text-cyan-400 font-bold">KPI: 1 Saniyede Otomatik Kalibre</span>
                </div>
              </div>

              {/* GAP 4 */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-500 font-black text-xs flex items-center justify-center font-mono">
                      04
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      🟡 Dinamik FEFO (First-Expired, First-Out) Akıllı Depo &amp; Satış
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-amber-500/20 text-amber-400 border border-amber-500/40">
                    STREIF İNDEKSİ PROTOKOLÜ
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <strong className="text-slate-800 dark:text-slate-200 block mb-1">Mevcut Durum &amp; Fire Riski:</strong>
                    Geleneksel FIFO (İlk Giren İlk Çıkar) uygulandığında transit sırasında ısı şoku yaşamış parti ile ideal saklanan parti aynı muameleyi görebilir.
                  </div>
                  <div className="bg-amber-50/60 dark:bg-amber-950/30 p-3 rounded-xl border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                    <strong className="text-amber-950 dark:text-amber-300 block mb-1">Sistemdeki Aktif Çözüm:</strong>
                    Streif indeksi &lt;0.12 olan veya telemetride ısı şoku gören partiler depoda bekletilmez; algoritma otomatik olarak "Acil En Yakın Perakendeye Sevk" statüsü atar.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                  <span>Formül: SI = Sertlik / (Brix × WSU Nişasta Skoru)</span>
                  <span className="font-mono text-amber-600 dark:text-amber-400 font-bold">KPI: Depo Fire Kaybı &lt;%1.5</span>
                </div>
              </div>

              {/* GAP 5 */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-500 font-black text-xs flex items-center justify-center font-mono">
                      05
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      🟡 Kurumsal ERP / EDI (SAP, NetSuite, Dynamics) Otomatik Konnektörü
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-purple-500/20 text-purple-400 border border-purple-500/40">
                    REST API &amp; EXCEL AKTİF
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-300">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <strong className="text-slate-800 dark:text-slate-200 block mb-1">Mevcut Durum:</strong>
                    Platform iki yönlü Excel/CSV ve Google Sheets veri köprüsüne sahiptir; ancak süpermarketler anlık EDIFACT/XML irsaliye aktarımı talep etmektedir.
                  </div>
                  <div className="bg-purple-50/60 dark:bg-purple-950/30 p-3 rounded-xl border border-purple-200 dark:border-purple-800 text-purple-900 dark:text-purple-200">
                    <strong className="text-purple-950 dark:text-purple-300 block mb-1">2026 Eylem Planı:</strong>
                    Ambar kabul onay kararı verildiği anda alıcının SAP veya Microsoft Dynamics ERP sisteminde otomatik irsaliye oluşturan Webhook köprüsü.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                  <span>Protokol: EDIFACT DESADV &amp; OpenOData REST API</span>
                  <span className="font-mono text-purple-600 dark:text-purple-400 font-bold">KPI: 0 Manuel Veri Girişi</span>
                </div>
              </div>

            </div>

            {/* Overall Maturity Radar Summary */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                  Genel 2026 Olgunluk Derecesi
                </span>
                <p className="text-sm font-black text-white mt-0.5">
                  MIWE HIL 2026 Vizyon Uyum Skoru: 94 / 100
                </p>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  IoT Canlı Telemetri ve SHA-256 Ledger entegrasyonu ile küresel ilk 3 platform içerisine girilmiştir.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="px-3 py-1.5 rounded-xl font-mono font-black text-emerald-400 bg-emerald-950 border border-emerald-500/40 text-sm">
                  KÜRESEL #2 DERECE
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SEKME 10: BLOCKCHAIN & FSMA 204 DAĞITIK DEFTER (KDE / CTE)                */}
        {/* ========================================================================= */}
        {activeTab === 'FSMA_BLOCKCHAIN_LEDGER' && (
          <div className="space-y-6">
            
            {/* Regulatory & Educational Explanation Banner: "Bu Defter Ne İçin Gerekli?" */}
            <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 p-5 sm:p-6 rounded-3xl border border-emerald-500/40 text-white space-y-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      FDA FSMA 204 &amp; GS1 EPCIS STANDARDI
                    </span>
                    <span className="text-xs text-emerald-300 font-mono font-bold">2026 Küresel Uyumluluk</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-white mt-0.5">
                    Blockchain Tabanlı Dağıtık Defter &amp; Kriptografik İzlenebilirlik Ne İçin Gereklidir?
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-2 text-xs">
                
                {/* Reason 1: FDA FSMA 204 Law */}
                <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/20 space-y-1.5">
                  <div className="font-extrabold text-emerald-300 flex items-center gap-1.5">
                    <span>🏛️ 1. FDA FSMA 204 Zorunluluğu:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11.5px]">
                    ABD FDA Gıda Güvenliği Modernizasyon Yasası Madde 204 gereğince, taze meyve sevkiyatlarında <strong>KDE (Key Data Elements)</strong> ve <strong>CTE (Critical Tracking Events)</strong> formatında <strong>24 saat içinde</strong> doğrulanabilir dijital izlenebilirlik sunulması zorunludur.
                  </p>
                </div>

                {/* Reason 2: Cryptographic Immutability */}
                <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/20 space-y-1.5">
                  <div className="font-extrabold text-cyan-300 flex items-center gap-1.5">
                    <span>🔒 2. Kriptografik Değiştirilemezlik:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11.5px]">
                    Standart veritabanlarında yöneticiler veya operatörler geçmiş hasat tarihi, ilaçlama/ilaç kalıntısı veya soğuk zincir kırılma verilerini değiştirebilir. <strong>SHA-256 hash zinciri</strong> ile her operasyonel adım mühürlenir ve matematiksel olarak geriye dönük tahrifat imkansız hale gelir.
                  </p>
                </div>

                {/* Reason 3: Rapid Recall & Supermarket Trust */}
                <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/20 space-y-1.5">
                  <div className="font-extrabold text-amber-300 flex items-center gap-1.5">
                    <span>⚡ 3. 1 Saniyede Geri Çağırma (Recall):</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11.5px]">
                    Süpermarket reyonundaki bir muz veya elma kolisinde pestisit veya kalite uygunsuzluğu çıktığında, palet üzerindeki kriptografik hash ile hasat yapılan ağaç, sera kurdelesi ve tır sıcaklık geçmişi saniyeler içinde kanıtlanır.
                  </p>
                </div>

              </div>
            </div>

            {/* Embedded Traceability Ledger View */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm">
              <TraceabilityLedgerView
                references={references}
                harvestRecords={harvestRecords}
                fieldRecords={fieldRecords}
                lojistikRecords={lojistikRecords}
                ambarRecords={ambarRecords}
              />
            </div>

          </div>
        )}

        {/* SEKME 11: ADMIN SISTEM & SPARK DENETIMI (ENTEGRE) */}
        {activeTab === 'ADMIN_SYSTEM' && (
          <div className="space-y-4">
            <AdminSystemPortal
              onBackToMainApp={onBackToMainApp}
              onBackToPortals={onBackToPortals}
              onBackToDashboard={onBackToDashboard}
              onSwitchPortal={onSwitchPortal}
              currentUser={currentUser}
              onForceServerSync={onForceServerSync}
              dataState={{
                references: references || [],
                harvestRecords: harvestRecords || [],
                fieldRecords: fieldRecords || [],
                muzRecords: muzRecords || [],
                bademRecords: bademRecords || [],
                lojistikRecords: lojistikRecords || [],
                ambarRecords: ambarRecords || [],
                exportSampleRecords: exportSampleRecords || [],
                salesRecords: salesRecords || [],
                incidentRecords: incidentRecords || [],
                freezeDryRecords: freezeDryRecords || [],
                feedbacks: feedbacks || [],
                customFields: customFields || []
              }}
            />
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* 6. MODAL: REYTİNG VE HEDEF FORMÜLÜ AÇIKLAMA PENCERESİ                     */}
      {/* ========================================================================= */}
      {showFormulaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <h3 className="font-black text-base sm:text-lg text-slate-900 dark:text-white">
                  Reytingler Neye Göre Değişir? Hedef ve Mevcut Nasıl Belirlenir?
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowFormulaModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg font-bold p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <div className="p-3 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800 space-y-1">
                <div className="font-bold text-teal-800 dark:text-teal-300 text-xs">
                  🎯 1. Hedefler Nereden Geliyor?
                </div>
                <p>
                  Hedefler rastgele konulmaz. Her sezon başında Yönetim Kurulu, Üretici Bahçe Şefliği ve Satış Departmanı arasında imzalanan <strong>Yıllık Kalite Pasaportu (SLA)</strong> sözleşmesinden ve uluslararası <strong>UNECE / EAC / OECD</strong> tolerans sınırlarından gelir.
                </p>
                <div className="font-mono text-[11px] text-teal-700 dark:text-teal-400 pt-1">
                  Örnek: %95 Kurdele Takvimine Uyum, Maksimum %4 Çıkış Firesi, Sıfır Karantina Cezası.
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 space-y-1">
                <div className="font-bold text-amber-800 dark:text-amber-300 text-xs">
                  📊 2. Mevcut Puanlar Neye Göre Hesaplanıyor?
                </div>
                <p>
                  Mevcut reyting 100 baz puan üzerinden başlar. Sistemdeki gerçek işlem sayısı, başarıyla tamamlanan testler ve <strong>Barlag Akty akt cezaları</strong> ile anlık formüle edilir:
                </p>
                <div className="p-2 rounded-xl bg-slate-900 text-amber-300 font-mono text-[11px]">
                  Mevcut Puan = 100 - (Barlag Akty Akt Cezası) - (İhmal Edilen Alet Cezası × 3) - (Arızalı Tesis Cezası × 6)
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 space-y-1">
                <div className="font-bold text-rose-800 dark:text-rose-300 text-xs">
                  ⚖️ 3. Doğrudan Kaliteye Ait Olmayan Sorunların Ayrımı (Adalet Kuralı)
                </div>
                <p>
                  Örneğin hasatta işçi az geldi ve toplama 4 gün geciktiyse, bu durum bir <strong>Saha Hasat Ekibi kusurudur</strong>. Kalite Bölümünün puanından DÜŞMEZ; Barlag Akty kaydı doğrudan Hasat Ekibine ceza olarak işlenir. Soğuk hava kompresörü bozulursa ceza puanı Soğuk Depo Ekibine yazılır.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowFormulaModal(false)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Anladım, Kapat
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
