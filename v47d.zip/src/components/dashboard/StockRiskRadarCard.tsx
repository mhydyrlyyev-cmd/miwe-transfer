import React, { useMemo } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Warehouse,
  Scale,
  PackageCheck,
  TrendingDown,
  Info
} from 'lucide-react';
import { ReferenceItem, AmbarRecord } from '../../types';

interface StockRiskRadarCardProps {
  references?: ReferenceItem[];
  ambarRecords?: AmbarRecord[];
  thresholds?: Record<string, number>;
  onOpenThresholdSettings?: () => void;
}

export interface ProductStockRisk {
  product: string;
  stockKg: number;
  batchCount: number;
  threshold: number;
  riskStatus: 'critical' | 'warning' | 'safe';
  percentage: number;
}

const DEFAULT_THRESHOLDS: Record<string, number> = {
  'Muz (Cavendish)': 1500,
  'Nonpareil Badem': 300,
  'Extreme 314 Şeftali': 1000,
  'Big Top Nektarin': 800,
  'Elma (Gala / Fuji)': 1200,
};

export const StockRiskRadarCard: React.FC<StockRiskRadarCardProps> = ({
  references = [],
  ambarRecords = [],
  thresholds = DEFAULT_THRESHOLDS,
  onOpenThresholdSettings
}) => {
  // Compute real dynamic stock & risk levels strictly from ambar/references records
  const riskData = useMemo(() => {
    const productMap = new Map<string, { product: string; stockKg: number; batchCount: number }>();

    // 1. Process actual Ambar kabul records
    if (ambarRecords.length > 0) {
      ambarRecords.forEach((amb) => {
        const weight = Number(amb.acceptedWeightKg) || 0;
        if (weight <= 0) return;

        const ref = references.find(r => r.refId === amb.refId);
        const prod = ref?.product || amb.notes?.split(' ')?.[0] || 'Genel Meyve';

        const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
        existing.stockKg += weight;
        existing.batchCount += 1;
        productMap.set(prod, existing);
      });
    }

    // 2. Supplement ONLY from verified RECEIVED references
    if (references.length > 0) {
      references.forEach((ref) => {
        if (ref.status !== 'RECEIVED') return;
        let kg = Number(ref.quantity) || 0;
        if (kg <= 0) return;

        const u = (ref.unit || '').toLowerCase();
        if (u.includes('ton')) kg *= 1000;
        if (u.includes('kasa') || u.includes('box')) kg *= 15;

        if (!ambarRecords.some(a => a.refId === ref.refId)) {
          const prod = ref.product || 'Genel Meyve';
          const existing = productMap.get(prod) || { product: prod, stockKg: 0, batchCount: 0 };
          existing.stockKg += kg;
          existing.batchCount += 1;
          productMap.set(prod, existing);
        }
      });
    }

    const items = Array.from(productMap.values()).filter(p => p.stockKg > 0);

    return items.map((item): ProductStockRisk => {
      const th = thresholds[item.product] ?? 500;
      let riskStatus: 'critical' | 'warning' | 'safe' = 'safe';

      if (item.stockKg < th) {
        riskStatus = 'critical';
      } else if (item.stockKg <= th * 1.5) {
        riskStatus = 'warning';
      }

      // Percentage relative to target capacity (threshold * 2)
      const percentage = Math.min(100, Math.round((item.stockKg / Math.max(1, th * 2)) * 100));

      return {
        ...item,
        threshold: th,
        riskStatus,
        percentage
      };
    }).sort((a, b) => {
      // Sort critical first, then warning, then safe
      const rank = { critical: 0, warning: 1, safe: 2 };
      if (rank[a.riskStatus] !== rank[b.riskStatus]) {
        return rank[a.riskStatus] - rank[b.riskStatus];
      }
      return b.stockKg - a.stockKg;
    });
  }, [references, ambarRecords, thresholds]);

  const summary = useMemo(() => {
    const totalKg = riskData.reduce((acc, curr) => acc + curr.stockKg, 0);
    const criticalCount = riskData.filter(r => r.riskStatus === 'critical').length;
    const warningCount = riskData.filter(r => r.riskStatus === 'warning').length;
    const safeCount = riskData.filter(r => r.riskStatus === 'safe').length;

    return {
      totalKg,
      totalTon: (totalKg / 1000).toFixed(1),
      criticalCount,
      warningCount,
      safeCount,
      productCount: riskData.length
    };
  }, [riskData]);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 rounded-2xl shadow-sm overflow-hidden text-slate-900 dark:text-white flex flex-col justify-between transition-all">
      
      {/* HEADER ROW */}
      <div className="p-4 sm:p-5 flex items-center justify-between gap-3 flex-wrap border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border shrink-0 ${
            summary.criticalCount > 0
              ? 'bg-rose-50 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-500/40 animate-pulse'
              : summary.warningCount > 0
              ? 'bg-amber-50 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/40'
              : 'bg-teal-50 dark:bg-teal-500/20 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-500/40'
          }`}>
            <ShieldAlert className="w-5 h-5" />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white tracking-tight">
                Stok Risk Radarı (Stock Risk Radar)
              </h3>
              {summary.criticalCount > 0 ? (
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase font-mono tracking-wider border bg-rose-50 dark:bg-rose-500/20 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/40">
                  ⚠️ {summary.criticalCount} Ürün Kritik
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase font-mono tracking-wider border bg-emerald-50 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/40">
                  ✓ Stok Seviyeleri Stabil
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Gerçek ambar kabul ve depo kayıtlarına dayalı ürün risk sınıflandırması
            </p>
          </div>
        </div>

        {/* Quick Action Button */}
        {onOpenThresholdSettings && (
          <button
            type="button"
            onClick={onOpenThresholdSettings}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 transition flex items-center gap-1.5 cursor-pointer shrink-0"
            title="Kritik Stok Eşiklerini Düzenle"
          >
            <Sliders className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span className="hidden sm:inline">Eşik Ayarları</span>
          </button>
        )}
      </div>

      {/* KPI METRIC BADGES */}
      <div className="grid grid-cols-3 gap-2 p-3 sm:p-4 bg-slate-50/80 dark:bg-slate-950/60 text-xs border-b border-slate-200 dark:border-slate-800/80">
        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-0.5">
          <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-medium">Takip Edilen Meyve</span>
          <p className="font-extrabold text-sm font-mono text-teal-700 dark:text-teal-300">
            {summary.productCount} Çeşit
          </p>
        </div>

        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-0.5">
          <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-medium">Kritik / Riskli</span>
          <p className={`font-extrabold text-sm font-mono ${
            summary.criticalCount > 0 ? 'text-rose-600 dark:text-rose-400' : summary.warningCount > 0 ? 'text-amber-600 dark:text-amber-300' : 'text-emerald-600 dark:text-emerald-400'
          }`}>
            {summary.criticalCount + summary.warningCount} Ürün
          </p>
        </div>

        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-0.5">
          <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-medium">Toplam Depo Stok</span>
          <p className="font-extrabold text-sm font-mono text-emerald-700 dark:text-emerald-400">
            {summary.totalTon} Ton
          </p>
        </div>
      </div>

      {/* PRODUCT RISK METER LIST / ZERO DATA STATE */}
      <div className="p-3 sm:p-4 space-y-2.5 flex-1 max-h-[280px] overflow-y-auto custom-scrollbar">
        {riskData.length === 0 ? (
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/80 border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-2">
            <Warehouse className="w-6 h-6 text-slate-400 dark:text-slate-600 mx-auto" />
            <div>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Veri Kaydı Yok (Cold-Start Modu)
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed max-w-sm mx-auto">
                Meyve Kalite, Hasat veya Ambar Kabul modallarından yeni parti kaydı eklendiğinde Stok Risk Radarı anlık olarak ürün stok seviyelerini ve risk durumunu hesaplayacaktır.
              </p>
            </div>
            <span className="inline-flex items-center gap-1 text-[10px] text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800/60 px-2 py-0.5 rounded-md font-mono">
              <Info className="w-3 h-3" />
              100% Gerçek Veri Tabanlı - Sahte/Simülasyon Verisi Barındırmaz
            </span>
          </div>
        ) : (
          riskData.map((item) => {
            const isCritical = item.riskStatus === 'critical';
            const isWarning = item.riskStatus === 'warning';

            return (
              <div
                key={item.product}
                className={`p-3 rounded-xl border transition-all ${
                  isCritical
                    ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-500/40 text-rose-900 dark:text-rose-100'
                    : isWarning
                    ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-500/40 text-amber-900 dark:text-amber-100'
                    : 'bg-slate-50 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                }`}
              >
                {/* Item Row Top */}
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${
                      isCritical ? 'bg-rose-500 animate-ping' : isWarning ? 'bg-amber-400' : 'bg-emerald-500'
                    }`} />
                    <span className="font-bold text-xs truncate text-slate-900 dark:text-white" title={item.product}>
                      {item.product}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono shrink-0">
                      ({item.batchCount} parti)
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase font-mono border ${
                      isCritical
                        ? 'bg-rose-100 dark:bg-rose-500/20 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/40'
                        : isWarning
                        ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-500/40'
                        : 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/40'
                    }`}>
                      {isCritical ? '🔴 Kritik Eşik Altı' : isWarning ? '🟡 Dikkat / Düşük' : '🟢 Güvenli'}
                    </span>
                  </div>
                </div>

                {/* Meter Progress Bar */}
                <div className="w-full bg-slate-200 dark:bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-300 dark:border-slate-800">
                  <div
                    className={`h-full transition-all duration-500 rounded-full ${
                      isCritical ? 'bg-rose-500' : isWarning ? 'bg-amber-400' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${Math.max(5, item.percentage)}%` }}
                  />
                </div>

                {/* Item Details Footer */}
                <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-1.5">
                  <span>
                    Mevcut: <strong className="text-slate-900 dark:text-white font-extrabold">{item.stockKg.toLocaleString('tr-TR')} kg</strong>
                  </span>
                  <span>
                    Eşik: <strong className="text-slate-700 dark:text-slate-300">{item.threshold.toLocaleString('tr-TR')} kg</strong>
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* FOOTER GUARANTEE */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950/90 border-t border-slate-200 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span className="flex items-center gap-1 text-teal-700 dark:text-teal-400 font-medium">
          <CheckCircle2 className="w-3.5 h-3.5" />
          Anlık Otomatik Hesaplama
        </span>
      </div>

    </div>
  );
};
