import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  SalesRecord,
  IncidentRecord,
  ExportSampleRecord,
  FreezeDryRecord,
  ModuleKey
} from '../types';
import { DataStoreState, validateConsistency } from './consistency';

export type IssueSeverity = 'CRITICAL' | 'WARNING' | 'INFO';

export type IssueCategory =
  | 'BROKEN_CHAIN'
  | 'ORPHAN_RECORD'
  | 'COLD_CHAIN'
  | 'WEIGHT_MISMATCH'
  | 'DATA_INCOMPLETE'
  | 'STATUS_DESYNC'
  | 'SECURITY_COMPLIANCE'
  | 'QUALITY_DEFECT';

export interface TracingIssue {
  id: string;
  refId: string;
  moduleKey?: ModuleKey | string;
  category: IssueCategory;
  severity: IssueSeverity;
  title: string;
  description: string;
  rootCause: string; // Neden Durumu
  recommendation: string; // İyileştirme Tavsiyesi ve Eylemi
  canAutoFix: boolean;
  affectedRecordId?: string;
}

export interface TracingAuditReport {
  overallScore: number; // 0 - 100
  grade: 'A+' | 'A' | 'B' | 'C' | 'D';
  complianceStatus: 'EXCELLENT' | 'GOOD' | 'NEEDS_ATTENTION' | 'CRITICAL_RISK';
  timestamp: string;
  summary: {
    totalReferences: number;
    perfectChainsCount: number;
    inProgressChainsCount: number;
    brokenChainsCount: number;
    orphanedRecordsCount: number;
    coldChainBreachCount: number;
    weightDiscrepancyCount: number;
    missingFieldCount: number;
    qualityDefectCount: number;
    quarantineBreachCount: number;
  };
  pipelineStats: {
    harvestRecords: number;
    fieldTests: number;
    bananaTests: number;
    almondTests: number;
    logisticsRecords: number;
    warehouseAcceptances: number;
    freezeDryBatches: number;
    exportSamples: number;
    salesOrders: number;
    incidents: number;
  };
  issues: TracingIssue[];
}

/**
 * Runs a deep, holistic audit across all 10 modules, data pipelines,
 * traceability linkages, cold-chain safety rules, and form completeness.
 */
export function runTracingAudit(state: DataStoreState): TracingAuditReport {
  const {
    references,
    harvestRecords,
    fieldRecords,
    muzRecords,
    bademRecords,
    lojistikRecords,
    ambarRecords,
    exportSampleRecords,
    salesRecords,
    incidentRecords,
    freezeDryRecords
  } = state;

  const issues: TracingIssue[] = [];
  const refMap = new Map<string, ReferenceItem>();
  references.forEach(r => refMap.set(r.refId, r));

  // 1. Traceability Pipeline Maps
  const harvestMap = new Map<string, HarvestRecord[]>();
  const fieldMap = new Map<string, FieldRecord[]>();
  const muzMap = new Map<string, MuzRecord[]>();
  const bademMap = new Map<string, BademRecord[]>();
  const lojistikMap = new Map<string, LojistikRecord[]>();
  const ambarMap = new Map<string, AmbarRecord[]>();
  const freezeDryMap = new Map<string, FreezeDryRecord[]>();
  const exportMap = new Map<string, ExportSampleRecord[]>();
  const salesMap = new Map<string, SalesRecord[]>();
  const incidentMap = new Map<string, IncidentRecord[]>();

  harvestRecords.forEach(r => {
    const list = harvestMap.get(r.refId) || [];
    list.push(r);
    harvestMap.set(r.refId, list);
  });
  fieldRecords.forEach(r => {
    const list = fieldMap.get(r.refId) || [];
    list.push(r);
    fieldMap.set(r.refId, list);
  });
  muzRecords.forEach(r => {
    const list = muzMap.get(r.refId) || [];
    list.push(r);
    muzMap.set(r.refId, list);
  });
  bademRecords.forEach(r => {
    const list = bademMap.get(r.refId) || [];
    list.push(r);
    bademMap.set(r.refId, list);
  });
  lojistikRecords.forEach(r => {
    const list = lojistikMap.get(r.refId) || [];
    list.push(r);
    lojistikMap.set(r.refId, list);
  });
  ambarRecords.forEach(r => {
    const list = ambarMap.get(r.refId) || [];
    list.push(r);
    ambarMap.set(r.refId, list);
  });
  freezeDryRecords.forEach(r => {
    const list = freezeDryMap.get(r.refId) || [];
    list.push(r);
    freezeDryMap.set(r.refId, list);
  });
  exportSampleRecords.forEach(r => {
    const list = exportMap.get(r.refId) || [];
    list.push(r);
    exportMap.set(r.refId, list);
  });
  salesRecords.forEach(r => {
    const list = salesMap.get(r.refId) || [];
    list.push(r);
    salesMap.set(r.refId, list);
  });
  incidentRecords.forEach(r => {
    const list = incidentMap.get(r.refId) || [];
    list.push(r);
    incidentMap.set(r.refId, list);
  });

  let perfectChainsCount = 0;
  let inProgressChainsCount = 0;
  let brokenChainsCount = 0;
  let orphanedRecordsCount = 0;
  let coldChainBreachCount = 0;
  let weightDiscrepancyCount = 0;
  let missingFieldCount = 0;
  let qualityDefectCount = 0;
  let quarantineBreachCount = 0;

  // ----------------------------------------------------
  // CHECK 1: Reference Pipeline Integrity (Hasat -> Test -> Lojistik -> Ambar -> Çıkış)
  // ----------------------------------------------------
  references.forEach(ref => {
    const rId = ref.refId;
    const hasHarvest = (harvestMap.get(rId)?.length || 0) > 0;
    const hasQuality =
      (fieldMap.get(rId)?.length || 0) > 0 ||
      (muzMap.get(rId)?.length || 0) > 0 ||
      (bademMap.get(rId)?.length || 0) > 0;
    const hasLojistik = (lojistikMap.get(rId)?.length || 0) > 0;
    const hasAmbar = (ambarMap.get(rId)?.length || 0) > 0;
    const hasDownstream =
      (freezeDryMap.get(rId)?.length || 0) > 0 ||
      (exportMap.get(rId)?.length || 0) > 0 ||
      (salesMap.get(rId)?.length || 0) > 0;

    // Check broken flow (e.g. Lojistik exists but no Harvest or Quality record)
    if (hasLojistik && !hasHarvest && ref.moduleKey === 'HARVEST') {
      brokenChainsCount++;
      issues.push({
        id: `broken-harvest-${rId}`,
        refId: rId,
        moduleKey: 'HARVEST',
        category: 'BROKEN_CHAIN',
        severity: 'CRITICAL',
        title: `Hasat Tartımı Olmadan Sevkiyat Yapılmış (${rId})`,
        description: `Bu referans için lojistik sevkiyat kaydı mevcut ancak saha hasat tartım verisi sistemde bulunamadı.`,
        rootCause: `Saha hasat operatörü tartım formunu onaylamadan önce kamyon/araç çıkışı yapılmış veya irsaliyeye farklı parti barkodu girilmiş.`,
        recommendation: `Hasat & Saha Tartım modülüne girerek ${rId} için kasa ve brüt/net kilo girişini kaydedin veya sevk irsaliyesindeki barkodu doğrulayın.`,
        canAutoFix: true
      });
    }

    if (hasAmbar && !hasLojistik) {
      brokenChainsCount++;
      issues.push({
        id: `broken-lojistik-${rId}`,
        refId: rId,
        moduleKey: 'LOJISTIK',
        category: 'BROKEN_CHAIN',
        severity: 'WARNING',
        title: `Sevk İrsaliyesi Olmadan Depo Kabulü Yapılmış (${rId})`,
        description: `Merkez soğuk hava deposuna kabul kaydı işlenmiş ancak sahaya ait lojistik nakliye formu bulunmuyor.`,
        rootCause: `Lojistik şoförü veya sevk sorumlusu nakliye fişini sisteme işlemeden ambar kabul operatörü doğrudan tartım yapmış.`,
        recommendation: `Lojistik & Sevkiyat modülüne giderek araç plakası ve varış saatini içeren sevk kaydını oluşturun.`,
        canAutoFix: false
      });
    }

    if (hasDownstream && !hasAmbar) {
      brokenChainsCount++;
      issues.push({
        id: `broken-downstream-${rId}`,
        refId: rId,
        moduleKey: 'AMBAR',
        category: 'BROKEN_CHAIN',
        severity: 'WARNING',
        title: `Depo Girişi Olmadan Satış / İşleme Yapılmış (${rId})`,
        description: `Ürün satışa veya Freeze Dry fırınlarına sevk edilmiş ancak merkez soğuk hava deposu kabul ve oda yerleşim kaydı yok.`,
        rootCause: `Ürün depoya girmeden sahada doğrudan müşteriye teslim edilmiş ya da ara depo kabul kaydı atlanmış.`,
        recommendation: `Soğuk Hava Depo & Ambar modülünden ilgili oda ve kabul kaydını işleyin veya doğrudan satış notuna 'Saha Teslimi' ibaresi ekleyin.`,
        canAutoFix: false
      });
    }

    // Status Desync Check
    if (hasDownstream && ref.status === 'CREATED') {
      issues.push({
        id: `status-desync-${rId}`,
        refId: rId,
        moduleKey: ref.moduleKey,
        category: 'STATUS_DESYNC',
        severity: 'INFO',
        title: `Parti Statüsü Güncel Değil (${rId})`,
        description: `Parti son aşamaya (Satış/İşleme) ulaştığı halde sistem künyesinde statü 'Oluşturuldu' olarak görünüyor.`,
        rootCause: `İşlem modülleri doldurulurken ana referansın özet statü bayrağı senkronize edilmemiş.`,
        recommendation: `'Otomatik Onar & Senkronize Et' butonuna tıklayarak parti statülerini anında güncelleyin.`,
        canAutoFix: true
      });
    }

    // Chain status
    if (hasHarvest && hasQuality && hasLojistik && hasAmbar && hasDownstream) {
      perfectChainsCount++;
    } else if (hasHarvest || hasQuality || hasLojistik || hasAmbar) {
      inProgressChainsCount++;
    }
  });

  // ----------------------------------------------------
  // CHECK 2: Orphaned Records Check (Yetim Kayıtlar)
  // ----------------------------------------------------
  const checkOrphans = (list: any[], moduleKey: ModuleKey, moduleName: string) => {
    list.forEach(rec => {
      if (!rec.refId || !refMap.has(rec.refId)) {
        orphanedRecordsCount++;
        issues.push({
          id: `orphan-${moduleKey}-${rec.id || Math.random()}`,
          refId: rec.refId || 'TANIMSIZ',
          moduleKey,
          category: 'ORPHAN_RECORD',
          severity: 'WARNING',
          title: `Sahipsiz ${moduleName} Kaydı Tespit Edildi`,
          description: `${moduleName} modülünde yer alan kaydın referans künyesi (${rec.refId}) sistemde bulunamadı.`,
          rootCause: `Ana referans listesi filtrelenirken veya silinirken bu modüle bağlı alt kayıt veritabanında kalmış.`,
          recommendation: `Otomatik onarım motoru bu kayıt için eksik künyeyi otomatik olarak üretebilir.`,
          canAutoFix: true,
          affectedRecordId: rec.id
        });
      }
    });
  };

  checkOrphans(harvestRecords, 'HARVEST', 'Hasat');
  checkOrphans(fieldRecords, 'FIELD', 'Saha Test');
  checkOrphans(muzRecords, 'MUZ', 'Muz Olgunluk');
  checkOrphans(bademRecords, 'BADEM', 'Badem Randıman');
  checkOrphans(lojistikRecords, 'LOJISTIK', 'Lojistik');
  checkOrphans(ambarRecords, 'AMBAR', 'Ambar Kabul');
  checkOrphans(freezeDryRecords, 'FREEZE_DRY', 'Freeze Dry');
  checkOrphans(exportSampleRecords, 'EXPORT_SAMPLE', 'İhracat Numunesi');
  checkOrphans(salesRecords, 'SALES', 'Satış & Sipariş');

  // ----------------------------------------------------
  // CHECK 3: Cold-Chain & Temperature Compliance (HACCP / ISO 22000)
  // ----------------------------------------------------
  lojistikRecords.forEach(l => {
    const departureTemp = Number(l.departureTemperature);
    const arrivalTemp = Number(l.transitTemperature);

    if (isNaN(departureTemp) || isNaN(arrivalTemp) || (l.departureTemperature === undefined && l.transitTemperature === undefined)) {
      missingFieldCount++;
      coldChainBreachCount++;
      issues.push({
        id: `coldchain-missing-${l.id || l.refId}`,
        refId: l.refId,
        moduleKey: 'LOJISTIK',
        category: 'COLD_CHAIN',
        severity: 'CRITICAL',
        title: `Soğuk Zincir Sıcaklık Verisi Eksik (${l.refId})`,
        description: `Lojistik sevk kaydında araç çıkış veya varış sıcaklığı girilmemiş.`,
        rootCause: `Şoför veya saha sevk görevlisi araç datalogger cihazını kontrol etmeden formu hızlıca kaydetmiş.`,
        recommendation: `Lojistik formunu açarak araç termometre değerini (+2°C ile +6°C aralığında) işleyin.`,
        canAutoFix: false,
        affectedRecordId: l.id
      });
    } else if (departureTemp > 8 || arrivalTemp > 8) {
      coldChainBreachCount++;
      issues.push({
        id: `coldchain-high-${l.id || l.refId}`,
        refId: l.refId,
        moduleKey: 'LOJISTIK',
        category: 'COLD_CHAIN',
        severity: 'CRITICAL',
        title: `Kritik Soğuk Zincir İhlali: Sıcaklık > 8°C (${l.refId})`,
        description: `Taşıma sıcaklığı limitlerin üzerinde ölçüldü (Çıkış: ${l.departureTemperature}°C, Varış: ${l.transitTemperature}°C).`,
        rootCause: `Araç soğutma ünitesi arızası, kapakların uzun süre açık kalması veya ön soğutma yapılmadan yükleme yapılması.`,
        recommendation: `Derhal Olay / Barlag Akty modülünden 5-Why kök sebep analizi başlatın ve ürün kalite kontrolünü tekrarlayın.`,
        canAutoFix: false,
        affectedRecordId: l.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 4: Weight Discrepancy & Wastage (Tartım Tutarlılığı)
  // ----------------------------------------------------
  references.forEach(ref => {
    const rId = ref.refId;
    const harvests = harvestMap.get(rId) || [];
    const lojistiks = lojistikMap.get(rId) || [];
    const ambars = ambarMap.get(rId) || [];

    const totalHarvestKg = harvests.reduce((acc, h) => acc + (Number(h.dailyTotalKg) || 0), 0);
    const totalLojistikKg = lojistiks.reduce((acc, l) => acc + (Number(l.weightKg) || 0), 0);
    const totalAmbarKg = ambars.reduce((acc, a) => acc + (Number(a.acceptedWeightKg) || 0), 0);

    if (totalLojistikKg > 0 && totalAmbarKg > 0) {
      const diff = Math.abs(totalLojistikKg - totalAmbarKg);
      const ratio = diff / totalLojistikKg;

      if (ratio > 0.08) { // > %8 discrepancy
        weightDiscrepancyCount++;
        issues.push({
          id: `weight-diff-${rId}`,
          refId: rId,
          moduleKey: 'AMBAR',
          category: 'WEIGHT_MISMATCH',
          severity: 'WARNING',
          title: `Sevkiyat ve Depo Tartımı Arasında Yüksek Fark (%${Math.round(ratio * 100)})`,
          description: `Sevk edilen: ${totalLojistikKg.toLocaleString('tr-TR')} kg, Depo kabulü: ${totalAmbarKg.toLocaleString('tr-TR')} kg (Fark: ${diff.toLocaleString('tr-TR')} kg).`,
          rootCause: `Yol fire oranı yüksek gerçekleşmiş, kantar kalibrasyon hatası oluşmuş veya kısmi boşaltma yapılmış.`,
          recommendation: `Tartım fişlerini karşılaştırın, sapma meşru fire ise Ambar notlarına 'Fire Kabulü' olarak işleyin.`,
          canAutoFix: false
        });
      }
    }
  });

  // ----------------------------------------------------
  // CHECK 5: Mandatory Field Completeness (Doldurma Kontrolleri)
  // ----------------------------------------------------
  fieldRecords.forEach(f => {
    if (!f.avgBrix && !f.colorationPercent) {
      missingFieldCount++;
      issues.push({
        id: `missing-field-${f.id || f.refId}`,
        refId: f.refId,
        moduleKey: 'FIELD',
        category: 'DATA_INCOMPLETE',
        severity: 'INFO',
        title: `Saha Kalite Ölçüm Parametreleri Eksik (${f.refId})`,
        description: `Saha test kaydında ortalama Brix (şeker) veya renk skalası boş bırakılmış.`,
        rootCause: `Operatör refraktometre ölçümü yapmadan formu hızlıca onaylamış.`,
        recommendation: `Meyve refraktometre Brix ölçüm sonucunu forma ekleyin.`,
        canAutoFix: false,
        affectedRecordId: f.id
      });
    }
  });

  lojistikRecords.forEach(l => {
    if (!l.driver || !l.vehiclePlate) {
      missingFieldCount++;
      issues.push({
        id: `missing-driver-${l.id || l.refId}`,
        refId: l.refId,
        moduleKey: 'LOJISTIK',
        category: 'DATA_INCOMPLETE',
        severity: 'INFO',
        title: `Sürücü veya Plaka Bilgisi Eksik (${l.refId})`,
        description: `Lojistik formunda araç plakası veya sürücü adı belirtilmemiş.`,
        rootCause: `Hızlı sevk esnasında nakliye şirketi bilgisi atlanmış.`,
        recommendation: `İzlenebilirlik ve güvenlik denetimleri için araç plakasını forma kaydedin.`,
        canAutoFix: false,
        affectedRecordId: l.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 6: Food Safety & Quarantine Traceability Lock
  // Partide açık kritik olay/karantina varken satış veya ihracat sevk kontrolü
  // ----------------------------------------------------
  references.forEach(ref => {
    const rId = ref.refId;
    const openCriticalIncidents = (incidentMap.get(rId) || []).filter(
      i => (i.status === 'OPEN' || i.status === 'IN_PROGRESS') && (i.priority === 'CRITICAL' || i.actDegree === 1)
    );
    const sales = salesMap.get(rId) || [];
    const exports = exportMap.get(rId) || [];

    if (openCriticalIncidents.length > 0 && (sales.length > 0 || exports.length > 0 || ref.status === 'SOLD')) {
      quarantineBreachCount++;
      issues.push({
        id: `quarantine-breach-${rId}`,
        refId: rId,
        moduleKey: 'INCIDENT',
        category: 'SECURITY_COMPLIANCE',
        severity: 'CRITICAL',
        title: `Karantina İhlali: Açık Kritik Olayı Olan Parti Satışa/İhracata Sevk Edilmiş (${rId})`,
        description: `Bu partide çözülmemiş 1. Derece Kritik Barlag Akty / DÖFİ bulunmasına rağmen satış (${sales.length} işlem) veya ihracat (${exports.length} işlem) kaydı tespit edildi.`,
        rootCause: `Kalite Güvence birimi parti blokajını kaldırmadan önce ticari birimlerce çıkış emri verilmiş.`,
        recommendation: `İlgili sevkıyatı derhal durdurun, partiyi karantina ambarına çekin ve Olay / Barlag Akty modülünden DÖFİ aksiyonunu tamamlayarak onaylayın.`,
        canAutoFix: false
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 7: Muz (Banana) Kalite ve Soğuk Zincir Denetimi
  // ----------------------------------------------------
  muzRecords.forEach(m => {
    // 1. Meyve eti sıcaklık sapması (< 12°C chilling injury; > 15°C erken olgunlaşma)
    if (m.pulpTemperatureC !== undefined && m.pulpTemperatureC !== null) {
      if (m.pulpTemperatureC < 12.0 || m.pulpTemperatureC > 15.0) {
        coldChainBreachCount++;
        issues.push({
          id: `muz-temp-${m.id || m.refId}`,
          refId: m.refId,
          moduleKey: 'MUZ',
          category: 'COLD_CHAIN',
          severity: 'CRITICAL',
          title: `Muz Meyve Eti Sıcaklık Sapması (${m.refId}: ${m.pulpTemperatureC}°C)`,
          description: `Sera muzlarında kabul edilen güvenli meyve eti sıcaklığı 13.0°C - 14.5°C'dir. Ölçülen ${m.pulpTemperatureC}°C değeri ${m.pulpTemperatureC < 12 ? 'üşüme ve kabuk kararması (chilling injury)' : 'kontrolsüz etilen salınımı ve erken sararma'} riskine neden olur.`,
          rootCause: `Depo ön-soğutma veya sera taşıma tüneli havalandırma regülasyonu yetersiz kalmış.`,
          recommendation: `Klima ünitesini derhal 13.5°C'ye kalibre edin ve parti olgunlaşma skalasını gözlemleyin.`,
          canAutoFix: false,
          affectedRecordId: m.id
        });
      }
    }

    // 2. Olgunluk Skalası Sapması (Hasatta yeşil skala 1-2 beklenir)
    if (m.ripenessScale && m.ripenessScale > 3) {
      qualityDefectCount++;
      issues.push({
        id: `muz-ripeness-${m.id || m.refId}`,
        refId: m.refId,
        moduleKey: 'MUZ',
        category: 'QUALITY_DEFECT',
        severity: 'WARNING',
        title: `Muz Hasat/Kabul Olgunluk Skalası Yüksek (${m.refId}: Skala ${m.ripenessScale})`,
        description: `Yeşil hasat normunda olgunluk skalası 1 (Koyu Yeşil) veya 2 (Açık Yeşil) olmalıdır. Skala ${m.ripenessScale} (Sarı/Yarı Sarı) yeşil muz raf ömrünü kritik oranda tüketmiştir.`,
        rootCause: `Sera hasat periyodu gecikmiş veya hasat sonrası bekletme süresi uzamış.`,
        recommendation: `Bu partiyi standart yeşil sevkiyat yerine derhal sarartma odasına sevk edin veya taze yerel pazara yönlendirin.`,
        canAutoFix: false,
        affectedRecordId: m.id
      });
    }

    // 3. Kalibrasyon kontrolü
    if (m.calibrationMm && m.calibrationMm < 27.0) {
      qualityDefectCount++;
      issues.push({
        id: `muz-calib-${m.id || m.refId}`,
        refId: m.refId,
        moduleKey: 'MUZ',
        category: 'QUALITY_DEFECT',
        severity: 'INFO',
        title: `Muz kalınlığı UNECE asgarisinin altında (${m.refId}: ${m.calibrationMm} mm)`,
        description: `UNECE FFV-35 / Codex 205: tüm sınıflarda asgari kalınlık 27 mm (dış sıranın orta parmağı, ortadan ölçülür). Ölçülen: ${m.calibrationMm} mm.`,
        rootCause: `Erken hasat veya parmak seyreltme hatası.`,
        recommendation: `Ölçümü tekrarlayın; doğrulanırsa partiyi standart dışı (sanayi) olarak ayırın.`,
        canAutoFix: false,
        affectedRecordId: m.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 8: Badem (Almond) Kalite ve Randıman Denetimi
  // ----------------------------------------------------
  bademRecords.forEach(b => {
    if (b.kernelYieldPercent !== undefined && b.kernelYieldPercent !== null) {
      if (b.kernelYieldPercent < 22 || b.kernelYieldPercent > 58) {
        qualityDefectCount++;
        issues.push({
          id: `badem-yield-${b.id || b.refId}`,
          refId: b.refId,
          moduleKey: 'BADEM',
          category: 'QUALITY_DEFECT',
          severity: 'WARNING',
          title: `Badem İç Randıman Sapması (${b.refId}: %${b.kernelYieldPercent})`,
          description: `Kabuklu badem kırma testinde elde edilen randıman (%${b.kernelYieldPercent}) standart aralık dışındadır (%24 - %42 standart).`,
          rootCause: `Kırma makinesi ayarı bozuk, numune kabuk oranı yüksek veya tartım hatası var.`,
          recommendation: `100 adetlik numune kırımı ile randıman testini tekrarlayın.`,
          canAutoFix: false,
          affectedRecordId: b.id
        });
      }
    }

    const defectVal = b.totalDefectPercent || b.seriousDefectPercent;
    if (defectVal && defectVal > 8.0) {
      qualityDefectCount++;
      issues.push({
        id: `badem-defect-${b.id || b.refId}`,
        refId: b.refId,
        moduleKey: 'BADEM',
        category: 'QUALITY_DEFECT',
        severity: 'CRITICAL',
        title: `Kritik Badem Kusur Oranı (%${defectVal} > %8.0 Üst Limit - ${b.refId})`,
        description: `UNECE DDP-05 standardına göre kabuklu ve iç bademde toplam kusur (kurtlu, delikli, leke, küf) %8'i geçemez.`,
        rootCause: `Hasat öncesi kurbağa/zararlı ilaçlama takvimi aksamış veya nemli koşullarda depolanmış.`,
        recommendation: `Optik ayırıcı veya elle seçme masası üzerinden ikinci bir ayıklama işlemi uygulayın.`,
        canAutoFix: false,
        affectedRecordId: b.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 9: Freeze-Dry (Liyofilizasyon) Gıda Güvenliği Denetimi
  // ----------------------------------------------------
  freezeDryRecords.forEach(fd => {
    // Son nem oranı %4.0 üstü küf/mikrobiyolojik üreme ve çıtırlık kaybı demektir
    if (fd.finalMoisturePercent !== undefined && fd.finalMoisturePercent !== null && fd.finalMoisturePercent > 4.0) {
      qualityDefectCount++;
      issues.push({
        id: `fd-moisture-${fd.id || fd.refId}`,
        refId: fd.refId,
        moduleKey: 'FREEZE_DRY',
        category: 'QUALITY_DEFECT',
        severity: 'CRITICAL',
        title: `Freeze Dry Kritik Son Nem Sapması (%${fd.finalMoisturePercent} > %4.0 - ${fd.refId})`,
        description: `Liyofilize dondurularak kurutulmuş meyvede son nem oranı maksimum %4.0 olmalıdır. %${fd.finalMoisturePercent} nem su aktivitesini yükseltir ve mikrobiyolojik bozulmaya yol açar.`,
        rootCause: `Kondansatör süblimasyon süresi yetersiz kalmış veya vakum çevrimi erken kesilmiş.`,
        recommendation: `Partiyi nemsiz azot atmosferli fırına veya 2 saatlik ek desorpsiyon kurutma çevrimine alın.`,
        canAutoFix: false,
        affectedRecordId: fd.id
      });
    }

    if (fd.yieldRatioPercent !== undefined && fd.yieldRatioPercent !== null && (fd.yieldRatioPercent < 6 || fd.yieldRatioPercent > 28)) {
      qualityDefectCount++;
      issues.push({
        id: `fd-yield-${fd.id || fd.refId}`,
        refId: fd.refId,
        moduleKey: 'FREEZE_DRY',
        category: 'WEIGHT_MISMATCH',
        severity: 'WARNING',
        title: `Freeze Dry Kuru Madde Verim Anomalisi (%${fd.yieldRatioPercent} - ${fd.refId})`,
        description: `Taze meyveden kuru meyveye geçişte beklenen kuru randıman %8 - %18 aralığındadır. Ölçülen: %${fd.yieldRatioPercent}.`,
        rootCause: `Giriş yaş meyve tartımı veya çıkış paket tartımında kantar darası hatası.`,
        recommendation: `Hammadde yükleme terazisini ve kuru ürün çıkış fişlerini çapraz kontrol edin.`,
        canAutoFix: false,
        affectedRecordId: fd.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 10: Saha Kalite ve Nitrat / Kusur Kontrolleri
  // ----------------------------------------------------
  fieldRecords.forEach(f => {
    if (f.nitrateMgKg && f.nitrateLimitMgKg && f.nitrateMgKg > f.nitrateLimitMgKg) {
      qualityDefectCount++;
      issues.push({
        id: `field-nitrate-${f.id || f.refId}`,
        refId: f.refId,
        moduleKey: 'FIELD',
        category: 'SECURITY_COMPLIANCE',
        severity: 'CRITICAL',
        title: `Yasal Nitrat Eşiği Aşımı (${f.refId}: ${f.nitrateMgKg} mg/kg > ${f.nitrateLimitMgKg} mg/kg)`,
        description: `Meyve laboratuvar analizinde nitrat konsantrasyonu gıda güvenliği tolerans sınırının üzerindedir. Taze ihracat veya doğrudan tüketime uygun değildir.`,
        rootCause: `Aşırı azotlu gübreleme veya hasat öncesi bekleme süresine uyulmaması.`,
        recommendation: `Partiyi karantina ambarına yönlendirin, akredite laboratuvardan yeniden analiz talep edin.`,
        canAutoFix: false,
        affectedRecordId: f.id
      });
    }

    if (f.defectPercent && f.defectPercent > 10.0) {
      qualityDefectCount++;
      issues.push({
        id: `field-defect-${f.id || f.refId}`,
        refId: f.refId,
        moduleKey: 'FIELD',
        category: 'QUALITY_DEFECT',
        severity: 'WARNING',
        title: `Yüksek Saha Kusur Oranı (%${f.defectPercent} - ${f.refId})`,
        description: `Bahçe kalite kabulünde toplam leke, mekanik hasar ve şekil bozukluğu %10'un üzerindedir.`,
        rootCause: `Kötü hasat işçiliği, aşırı rüzgar sürtünmesi veya kasalama hataları.`,
        recommendation: `Depoya girişte boylama ve ayıklama hattını zorunlu tutun.`,
        canAutoFix: false,
        affectedRecordId: f.id
      });
    }
  });

  // ----------------------------------------------------
  // CHECK 11: Tarih Kronolojisi Denetimi (Traceability Timeline)
  // Hasat tarihi sevk tarihinden sonra olamaz; Lojistik ambar kabulünden sonra olamaz
  // ----------------------------------------------------
  references.forEach(ref => {
    const rId = ref.refId;
    const harvs = harvestMap.get(rId) || [];
    const lojs = lojistikMap.get(rId) || [];
    const ambs = ambarMap.get(rId) || [];

    if (harvs.length > 0 && lojs.length > 0) {
      const hDate = harvs[0].recordDate || harvs[0].timestamp;
      const lDate = lojs[0].shipmentDate || lojs[0].timestamp;
      if (hDate && lDate && new Date(lDate) < new Date(hDate)) {
        brokenChainsCount++;
        issues.push({
          id: `timeline-harv-loj-${rId}`,
          refId: rId,
          moduleKey: 'LOJISTIK',
          category: 'STATUS_DESYNC',
          severity: 'WARNING',
          title: `Kronolojik Tarih Tutarsızlığı: Sevk Hasattan Önce (${rId})`,
          description: `Sevk tarihi (${lDate.slice(0, 10)}), hasat tarihinden (${hDate.slice(0, 10)}) daha eski bir zamana ayarlanmış.`,
          rootCause: `Kullanıcı veya cihaz tarih/saat ayarlarının yanlış olması veya geriye dönük hatalı veri girişi.`,
          recommendation: `Lojistik sevkiyat formunu açarak doğru sevk irsaliye tarihini güncelleyin.`,
          canAutoFix: false
        });
      }
    }

    if (lojs.length > 0 && ambs.length > 0) {
      const lDate = lojs[0].shipmentDate || lojs[0].timestamp;
      const aDate = ambs[0].acceptanceDate || ambs[0].timestamp;
      if (lDate && aDate && new Date(aDate) < new Date(lDate)) {
        brokenChainsCount++;
        issues.push({
          id: `timeline-loj-amb-${rId}`,
          refId: rId,
          moduleKey: 'AMBAR',
          category: 'STATUS_DESYNC',
          severity: 'WARNING',
          title: `Kronolojik Tarih Tutarsızlığı: Depo Kabulü Sevkiyat Öncesi (${rId})`,
          description: `Ambar kabul tarihi (${aDate.slice(0, 10)}), araç sevk tarihinden (${lDate.slice(0, 10)}) daha önce girilmiş.`,
          rootCause: `Kantar kabul operatörü fiş tarihini sehven geriye dönük girmiş.`,
          recommendation: `Ambar formundan kantar tartım tarihini düzeltin.`,
          canAutoFix: false
        });
      }
    }
  });

  // ----------------------------------------------------
  // CALCULATION OF OVERALL HEALTH SCORE & GRADE
  // ----------------------------------------------------
  // Score starts at 100, penalties for defects
  let score = 100;
  score -= quarantineBreachCount * 20; // Critical food safety breach
  score -= brokenChainsCount * 10;
  score -= coldChainBreachCount * 8;
  score -= qualityDefectCount * 4;
  score -= orphanedRecordsCount * 5;
  score -= weightDiscrepancyCount * 3;
  score -= missingFieldCount * 1.5;

  if (score < 0) score = 0;
  if (score > 100) score = 100;

  let grade: TracingAuditReport['grade'] = 'A+';
  let complianceStatus: TracingAuditReport['complianceStatus'] = 'EXCELLENT';

  if (score >= 95) {
    grade = 'A+';
    complianceStatus = 'EXCELLENT';
  } else if (score >= 85) {
    grade = 'A';
    complianceStatus = 'GOOD';
  } else if (score >= 70) {
    grade = 'B';
    complianceStatus = 'NEEDS_ATTENTION';
  } else if (score >= 50) {
    grade = 'C';
    complianceStatus = 'NEEDS_ATTENTION';
  } else {
    grade = 'D';
    complianceStatus = 'CRITICAL_RISK';
  }

  return {
    overallScore: Math.round(score),
    grade,
    complianceStatus,
    timestamp: new Date().toISOString(),
    summary: {
      totalReferences: references.length,
      perfectChainsCount,
      inProgressChainsCount,
      brokenChainsCount,
      orphanedRecordsCount,
      coldChainBreachCount,
      weightDiscrepancyCount,
      missingFieldCount,
      qualityDefectCount,
      quarantineBreachCount
    },
    pipelineStats: {
      harvestRecords: harvestRecords.length,
      fieldTests: fieldRecords.length,
      bananaTests: muzRecords.length,
      almondTests: bademRecords.length,
      logisticsRecords: lojistikRecords.length,
      warehouseAcceptances: ambarRecords.length,
      freezeDryBatches: freezeDryRecords.length,
      exportSamples: exportSampleRecords.length,
      salesOrders: salesRecords.length,
      incidents: incidentRecords.length
    },
    issues
  };
}

/**
 * Executes an automated self-healing repair on the database state:
 * - Creates missing reference master headers for orphaned records
 * - Reconciles status codes across the entire lifecycle
 * - Cleans broken pointers
 */
export function autoRepairDataState(state: DataStoreState): {
  repairedState: DataStoreState;
  repairedCount: number;
} {
  const result = validateConsistency(state);
  return {
    repairedState: result,
    repairedCount: result.repairedCount
  };
}
