import { SpecialCropType, SpecialCropTestResult } from '../types';

export interface CropPresetDefinition {
  type: SpecialCropType;
  cropNameTr: string;
  badge: string;
  metric1Label: string;
  metric1Unit: string;
  metric1Default: number;
  metric1Min: number;
  metric1Max: number;
  metric1Step: number;
  metric2Label?: string;
  metric2Unit?: string;
  metric2Default?: number;
  metric2Min?: number;
  metric2Max?: number;
  metric2Step?: number;
  description: string;
  calculate: (val1: number, val2?: number) => { interpretation: string; statusBadge: string };
}

export const CROP_PRESETS: Record<SpecialCropType, CropPresetDefinition | null> = {
  NONE: null,
  APPLE_PEAR: {
    type: 'APPLE_PEAR',
    cropNameTr: 'Elma / Armut (Nişasta & Streif)',
    badge: '🍎 Elma/Armut',
    metric1Label: 'Nişasta-İyot Skalası (CTIFL)',
    metric1Unit: '1-10',
    metric1Default: 5,
    metric1Min: 1,
    metric1Max: 10,
    metric1Step: 0.5,
    metric2Label: 'Hedef Depo Türü',
    metric2Unit: 'Tip',
    metric2Default: 1,
    description: 'İç hedef: nişasta hidrolizi ve Streif indeksi ile CA/ULO ve normal soğuk depo hasat penceresi (UNECE elmada sayısal olgunluk şartı koymaz).',
    calculate: (val1) => {
      if (val1 <= 3.5) return { interpretation: 'CA/ULO Çok Uzun Dönem Soğuk Depolama için İdeal', statusBadge: 'bg-cyan-100 text-cyan-900 border-cyan-300' };
      if (val1 <= 6.5) return { interpretation: 'Optimum Standart Soğuk Hava Depolama Hasadı', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 <= 8.5) return { interpretation: 'Kısa Süreli Depo / Taze Pazara Hızlı Sevk', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      return { interpretation: 'Aşırı Olgun (Freeze-Dry veya Sanayi Tüketim)', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
    }
  },
  AVOCADO: {
    type: 'AVOCADO',
    cropNameTr: 'Avokado (Kuru Madde & Durofel)',
    badge: '🥑 Avokado',
    metric1Label: 'Kuru Madde Oranı (Dry Matter)',
    metric1Unit: '%',
    metric1Default: 22.5,
    metric1Min: 15,
    metric1Max: 35,
    metric1Step: 0.1,
    metric2Label: 'Yumuşama Aşaması (1-Sert, 2-Kırılma, 3-Yemeye Hazır)',
    metric2Unit: 'Skala',
    metric2Default: 1,
    metric2Min: 1,
    metric2Max: 3,
    metric2Step: 1,
    description: 'UNECE FFV-42: kuru madde Hass ≥%21; Fuerte, Pinkerton, Reed, Edranol ≥%20; diğer çeşitler ≥%19.',
    calculate: (val1, val2) => {
      if (val1 < 21.0) {
        return { interpretation: 'Kuru Madde Yetersiz (<%21) — Hasat Edilemez, Olgunlaşmaz!', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      }
      if (val1 >= 21.0 && val1 < 23.5) {
        return { interpretation: 'Minimum Hasat Standardı Geçildi — İhracat ve Uzak Sevkiyat için Uygun', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      }
      if (val1 >= 23.5 && val1 <= 28.0) {
        return { interpretation: 'Optimum Lezzet & Yağ Dengesi — Mükemmel Yeme Kalitesi', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      }
      return { interpretation: 'Yüksek Kuru Madde / İleri Olgunluk — Hızlı Tüketim Sevk', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  TOMATO: {
    type: 'TOMATO',
    cropNameTr: 'Domates (Likopen & Asitlik)',
    badge: '🍅 Domates',
    metric1Label: 'USDA Likopen / Renk Skalası (1-Yeşil, 2-Dönüm, 3-Alaca, 4-Pembe, 5-Açık Kırmızı, 6-Kırmızı)',
    metric1Unit: '1-6 Skala',
    metric1Default: 3,
    metric1Min: 1,
    metric1Max: 6,
    metric1Step: 1,
    metric2Label: 'Titre Edilebilir Asitlik (TA)',
    metric2Unit: '% Sitrik',
    metric2Default: 0.42,
    metric2Min: 0.2,
    metric2Max: 1.0,
    metric2Step: 0.01,
    description: 'USDA 1–6 renk skalası (olgunluk evresi). TA asitlik iç hedeftir.',
    calculate: (val1) => {
      if (val1 <= 2) return { interpretation: 'Dönüm Aşaması (Breaker) — Uzun Mesafe İhracat için İdeal', statusBadge: 'bg-cyan-100 text-cyan-900 border-cyan-300' };
      if (val1 === 3 || val1 === 4) return { interpretation: 'Alaca / Pembe (Turning/Pink) — Bölgesel Dağıtım ve Süpermarket', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Tam Kırmızı (Red) — Doğrudan Perakende Satış veya Salça/İşleme', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  GRAPE: {
    type: 'GRAPE',
    cropNameTr: 'Üzüm (Brix/Asit & Sap Tutunma)',
    badge: '🍇 Üzüm',
    metric1Label: 'Brix / Titre Edilebilir Asit Oranı',
    metric1Unit: 'Oran',
    metric1Default: 20.5,
    metric1Min: 10,
    metric1Max: 35,
    metric1Step: 0.5,
    metric2Label: 'Tane Sap Tutunma Direnci (Shatter Resistance)',
    metric2Unit: 'g (Gram)',
    metric2Default: 260,
    metric2Min: 50,
    metric2Max: 500,
    metric2Step: 10,
    description: 'UNECE FFV-19: ≥16 °Bx; 14–16 °Bx ise şeker/asit ≥18:1, 12,5–14 °Bx ise ≥20:1. Tane tutunma (≥200 g) iç hedeftir.',
    calculate: (val1, val2 = 250) => {
      if (val1 < 16.0) return { interpretation: 'Şeker/Asit Dengesi Ham — Hasat İçin Erken', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      if (val2 < 180) return { interpretation: 'Sap Tutunma Zayıf (<180g) — Salkım Dökülme Riski Yüksek!', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      return { interpretation: 'Optimum Hasat Kalitesi & Sağlam Salkım Tutunması', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
    }
  },
  POTATO: {
    type: 'POTATO',
    cropNameTr: 'Patates (Özgül Ağırlık & İndirgen Şeker)',
    badge: '🥔 Patates',
    metric1Label: 'Özgül Ağırlık (Tuzlu Su Yüzdürme)',
    metric1Unit: 'SG (1.0xx)',
    metric1Default: 1.082,
    metric1Min: 1.050,
    metric1Max: 1.110,
    metric1Step: 0.001,
    metric2Label: 'İndirgen Şeker (Glukoz)',
    metric2Unit: '% Glukoz',
    metric2Default: 0.08,
    metric2Min: 0.01,
    metric2Max: 0.5,
    metric2Step: 0.01,
    description: 'İç hedef: özgül ağırlık kuru madde ve nişastayı gösterir (>1,080 cips/kızartmalık); glukoz <%0,1 kızartmada kararmayı önler.',
    calculate: (val1, val2 = 0.08) => {
      if (val1 >= 1.080 && val2 <= 0.1) return { interpretation: 'Mükemmel Cips & Parmak Patates Kalitesi (Yüksek Kuru Madde)', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 >= 1.070) return { interpretation: 'Taze Yemeklik / Haşlamalık Kalite Standardı', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
      return { interpretation: 'Düşük Kuru Madde / Yüksek Şeker Kararma Riski', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  ONION: {
    type: 'ONION',
    cropNameTr: 'Soğan (Boyun Kuruluğu & Kuru Madde)',
    badge: '🧅 Soğan',
    metric1Label: 'Boyun Kapanma & Kuruluk Oranı',
    metric1Unit: '%',
    metric1Default: 95,
    metric1Min: 50,
    metric1Max: 100,
    metric1Step: 1,
    metric2Label: 'Kuru Madde Oranı (Refraktometre)',
    metric2Unit: '%',
    metric2Default: 14.5,
    metric2Min: 8,
    metric2Max: 20,
    metric2Step: 0.5,
    description: 'İç hedef: boyun kuruluğu Botrytis depo çürümesini önler; kuru madde depolama dayanıklılığını gösterir.',
    calculate: (val1, val2 = 14) => {
      if (val1 < 85) return { interpretation: 'Boyun Islak / Açık — Soğuk Depoya Giremez, Kurutma Gerekli!', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      if (val2 >= 13) return { interpretation: 'Tam Kuru Boyun & Yüksek Kuru Madde — 6-9 Ay Uzun Depoluk', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Orta Depoluk / 2-4 Ay İçinde Tüketime Sevk', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  MELON_WATERMELON: {
    type: 'MELON_WATERMELON',
    cropNameTr: 'Kavun & Karpuz (Sap Ayrılma & Kabuk Kalınlığı)',
    badge: '🍉 Kavun / Karpuz',
    metric1Label: 'Sap Çatlağı / Sarı Zemin Lekesi (1-Ham, 2-Yarım Çatlak, 3-Tam Ayrılma / Sarı Leke)',
    metric1Unit: 'Skala',
    metric1Default: 3,
    metric1Min: 1,
    metric1Max: 3,
    metric1Step: 1,
    metric2Label: 'Kabuk Kalınlığı (Rind Thickness)',
    metric2Unit: 'mm',
    metric2Default: 12,
    metric2Min: 4,
    metric2Max: 25,
    metric2Step: 1,
    description: 'UNECE: kavun ve karpuzda ≥8 °Bx. Sap ayrılması (full-slip) ve zemin lekesi rengi iç göstergedir.',
    calculate: (val1) => {
      if (val1 === 1) return { interpretation: 'Ham / Sap Ayrılmamış — Şeker Gelişimi Tamamlanmamış', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      if (val1 === 2) return { interpretation: 'Yarım Ayrılma (Half-Slip) — Uzun Mesafe İhracat Sevkiyatı', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
      return { interpretation: 'Tam Olgun (Full-Slip / Sarı Leke) — Yüksek Şeker & Taze Pazar', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
    }
  },
  PINEAPPLE: {
    type: 'PINEAPPLE',
    cropNameTr: 'Ananas (İç Şeffaflık & Kabuk Gözü)',
    badge: '🍍 Ananas',
    metric1Label: 'İç Şeffaflık / Camsılaşma (Translucency 1: <10%, 2: 10-25%, 3: 25-50%, 4: >50%)',
    metric1Unit: '1-4 Skala',
    metric1Default: 2,
    metric1Min: 1,
    metric1Max: 4,
    metric1Step: 1,
    metric2Label: 'Kabuk Göz Renk Skalası (0: Yeşil, 5: Turuncu)',
    metric2Unit: '0-5 Skala',
    metric2Default: 2,
    metric2Min: 0,
    metric2Max: 5,
    metric2Step: 1,
    description: 'UNECE FFV-49: ≥12 °Bx. İç şeffaflık (camsılaşma) 2–3 iç hedeftir; 4 aşırı olgunluk göstergesidir.',
    calculate: (val1) => {
      if (val1 === 1) return { interpretation: 'Düşük Şeffaflık (<%10) — Uzun Deniz Aşırı Nakliye İhracatı', statusBadge: 'bg-cyan-100 text-cyan-900 border-cyan-300' };
      if (val1 === 2 || val1 === 3) return { interpretation: 'Optimum İç Doku & Tatlı Şeker Dengesi', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Aşırı Şeffaflık (>%50) — Fermentasyon / Hızlı Tüketim veya Freeze-Dry', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  MANGO: {
    type: 'MANGO',
    cropNameTr: 'Mango (Kuru Madde & Yanak Sertliği)',
    badge: '🥭 Mango',
    metric1Label: 'Kuru Madde Oranı (Dry Matter %)',
    metric1Unit: '%',
    metric1Default: 16.5,
    metric1Min: 10,
    metric1Max: 24,
    metric1Step: 0.1,
    metric2Label: 'Yanak Sertliği (Cheek Firmness)',
    metric2Unit: 'kg/cm²',
    metric2Default: 6.8,
    metric2Min: 1,
    metric2Max: 12,
    metric2Step: 0.1,
    description: 'İç hedef: kuru madde %14–16, omuz dolgunluğu ile birlikte değerlendirilir (UNECE FFV-45 sayısal değeri doğrulanacak).',
    calculate: (val1) => {
      if (val1 < 14.0) return { interpretation: 'Kuru Madde Yetersiz (<%14) — Ham Hasat Riski', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      if (val1 >= 16.0) return { interpretation: 'Yüksek Kuru Madde & Üst Düzey Yeme Kalitesi', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Standart İhracat Olgunluğu Uygun', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
    }
  },
  PISTACHIO: {
    type: 'PISTACHIO',
    cropNameTr: 'Antep Fıstığı (Çıtlaklık & Nem)',
    badge: '🥜 Antep Fıstığı',
    metric1Label: 'Doğal Çıtlaklık Oranı (Split Shell)',
    metric1Unit: '%',
    metric1Default: 88.0,
    metric1Min: 50,
    metric1Max: 100,
    metric1Step: 0.5,
    metric2Label: 'Depolama Nemi (Moisture % - Kritik Sınır: <%7)',
    metric2Unit: '% Nem',
    metric2Default: 5.5,
    metric2Min: 3,
    metric2Max: 12,
    metric2Step: 0.1,
    description: 'UNECE DDP-09: nem ≤%6,5. Doğal çıtlaklık >%85 iç hedeftir (aflatoksin riskini azaltmak için nem düşük tutulur).',
    calculate: (val1, val2 = 5.5) => {
      if (val2 > 7.0) return { interpretation: 'DİKKAT: Nem >%7 — Aflatoksin / Küflenme Riski! Acil Kurutma!', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
      if (val1 >= 85.0) return { interpretation: 'Ekstra 1. Sınıf Doğal Çıtlak & Güvenli Kuru Nem Depoluk', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Kavurma / Mekanik Çıtlatma Ayrımı Gerekli', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  POMEGRANATE: {
    type: 'POMEGRANATE',
    cropNameTr: 'Nar (Aril Rengi & Meyve Suyu Randımanı)',
    badge: '🔴 Nar',
    metric1Label: 'Meyve Suyu Randımanı (Juice Yield)',
    metric1Unit: '%',
    metric1Default: 45.0,
    metric1Min: 25,
    metric1Max: 60,
    metric1Step: 0.5,
    metric2Label: 'Aril Rengi Skalası (1-Pembe, 2-Yakut, 3-Koyu Kırmızı)',
    metric2Unit: 'Skala',
    metric2Default: 3,
    metric2Min: 1,
    metric2Max: 3,
    metric2Step: 1,
    description: 'İç hedef: Hicaz narda %40–45 meyve suyu randımanı ve koyu kırmızı aril rengi.',
    calculate: (val1) => {
      if (val1 < 38.0) return { interpretation: 'Düşük Meyve Suyu Randımanı — Yetersiz Sululuk', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      return { interpretation: 'Optimum Meyve Suyu Randımanı & Zengin Antosiyanin Rengi', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
    }
  },
  CORN: {
    type: 'CORN',
    cropNameTr: 'Mısır (Nem & Süt Olumu)',
    badge: '🌽 Mısır',
    metric1Label: 'Tane Nem Oranı (Tatlı Mısır: %70-75, Tane Mısır: %14-15)',
    metric1Unit: '% Nem',
    metric1Default: 72.0,
    metric1Min: 10,
    metric1Max: 85,
    metric1Step: 0.5,
    metric2Label: 'Olum Aşaması (1-Süt/Milk, 2-Hamur/Dough, 3-Sert Diş/Dent)',
    metric2Unit: 'Evre',
    metric2Default: 1,
    metric2Min: 1,
    metric2Max: 3,
    metric2Step: 1,
    description: 'İç hedef: tatlı mısırda süt olumu (~%72 nem); depoluk mısırda %14 nem.',
    calculate: (val1) => {
      if (val1 >= 68 && val1 <= 76) return { interpretation: 'Tatlı Mısır İdeal Hasat (Maksimum Şeker & Gevrek Tane)', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 <= 15) return { interpretation: 'Tane Mısır Güvenli Silo Depolama Nemi (≤%15)', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
      return { interpretation: 'Kurutma Gerekli veya Aşırı Olgunlaşmış Şeker Kaybı', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  PERSIMMON: {
    type: 'PERSIMMON',
    cropNameTr: 'Hurma / Trabzon Hurması (Tanen & Nem)',
    badge: '🟠 Hurma',
    metric1Label: 'Çözünür Tanen / Burukluk Skalası (1-Tatlı, 2-Hafif, 3-Orta, 4-Yüksek Buruk)',
    metric1Unit: '1-4 Skala',
    metric1Default: 1,
    metric1Min: 1,
    metric1Max: 4,
    metric1Step: 1,
    metric2Label: 'Kuru Hurma Nem Oranı (Kurutulmuş ise)',
    metric2Unit: '%',
    metric2Default: 20.0,
    metric2Min: 12,
    metric2Max: 30,
    metric2Step: 0.5,
    description: 'İç hedef: buruk çeşitlerde tanen giderme (CO₂/etanol) kontrolü; kuru hurmada %18–24 nem.',
    calculate: (val1) => {
      if (val1 === 1) return { interpretation: 'Burukluk Yok (Tatlı) — Doğrudan Tüketim ve Sofralık Sevk', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 === 2) return { interpretation: 'Hafif Buruk — Soğuk Depoda Olgunlaşma Devam Ediyor', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
      return { interpretation: 'Yüksek Tanen (Buruk) — Gazlama / Tanen Giderme İşlemi Gerekli', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  PEACH_NECTARINE: {
    type: 'PEACH_NECTARINE',
    cropNameTr: 'Şeftali / Nektarin (Sertlik & Çekirdek Çatlağı)',
    badge: '🍑 Şeftali / Nektarin',
    metric1Label: 'Penetrometre Sertlik (8 mm Uç)',
    metric1Unit: 'kg/cm²',
    metric1Default: 5.4,
    metric1Min: 1.5,
    metric1Max: 9.0,
    metric1Step: 0.1,
    metric2Label: 'Çekirdek Çatlaması Oranı (Split Pit)',
    metric2Unit: '%',
    metric2Default: 2.0,
    metric2Min: 0,
    metric2Max: 20,
    metric2Step: 0.5,
    description: 'UNECE FFV-26: ≥8 °Bx. Sertlik 4,5–6,5 kg/cm² ve çekirdek çatlağı <%5 iç hedeftir.',
    calculate: (val1, val2 = 2) => {
      if (val1 < 3.0) return { interpretation: 'Yumuşamış Meyve — Taze Tüketim veya Freeze-Dry Hattına Sevk', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      if (val1 >= 4.5 && val1 <= 6.5 && val2 < 5) return { interpretation: 'İhracat ve Soğuk Hava Depolama için Mükemmel Hasat Sertliği', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Standart Muayene Uygun', statusBadge: 'bg-blue-100 text-blue-900 border-blue-300' };
    }
  },
  PLUM: {
    type: 'PLUM',
    cropNameTr: 'Erik (Mumsu Pus & Sertlik)',
    badge: '🟣 Erik',
    metric1Label: 'Doğal Mumsu Pus Tabakası (Bloom Wax)',
    metric1Unit: '% Örtü',
    metric1Default: 90.0,
    metric1Min: 40,
    metric1Max: 100,
    metric1Step: 5,
    metric2Label: 'Et Sertliği (Penetrometre)',
    metric2Unit: 'kg/cm²',
    metric2Default: 4.8,
    metric2Min: 2,
    metric2Max: 8,
    metric2Step: 0.1,
    description: 'İç hedef: doğal pus örtüsü >%80 (su kaybını azaltır).',
    calculate: (val1) => {
      if (val1 >= 80.0) return { interpretation: 'Kusursuz Mumsu Pus Örtüsü — Üstün Raf Ömrü ve Tazelik', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      return { interpretation: 'Kısmi Pus Kaybı — Hızlı Soğutma ve Sevk Önerilir', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
    }
  },
  CARROT: {
    type: 'CARROT',
    cropNameTr: 'Havuç (Kırılganlık/Gevreklik & Odunlaşma)',
    badge: '🥕 Havuç',
    metric1Label: 'Merkez Silindir (Ksilem) Odunlaşma / Çatlak Oranı',
    metric1Unit: '% Odunlaşma',
    metric1Default: 3.0,
    metric1Min: 0,
    metric1Max: 30,
    metric1Step: 0.5,
    metric2Label: 'Yeşil Omuz (Green Shoulder) Oranı',
    metric2Unit: '%',
    metric2Default: 2.0,
    metric2Min: 0,
    metric2Max: 25,
    metric2Step: 0.5,
    description: 'UNECE FFV-10: çatallanma ve odunlaşma kusur sayılır. 8,5 °Bx tatlılık iç hedeftir (standartta Brix şartı yok).',
    calculate: (val1, val2 = 2.0) => {
      if (val1 <= 5.0 && val2 <= 4.0) return { interpretation: 'Ekstra / Sınıf I Gevrek Tatlı Havuç — İhracat, Yıkama & Uzun Soğuk Depoluk', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 <= 12.0) return { interpretation: 'Sınıf II Pazar Kalitesi veya Küp/Dilim Freeze & Dry İşleme Uygun', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      return { interpretation: 'Yüksek Odunlaşma / Çatlak — Meyve Suyu / Püre & Konsantre Sanayi Hattı', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
    }
  },
  KIWI: {
    type: 'KIWI',
    cropNameTr: 'Kivi (Kuru Madde % & Brix)',
    badge: '🥝 Kivi',
    metric1Label: 'Kuru Madde (Dry Matter)',
    metric1Unit: '%',
    metric1Default: 16.0,
    metric1Min: 10,
    metric1Max: 25,
    metric1Step: 0.1,
    metric2Label: 'Suda Çözünür Katı Madde (Brix)',
    metric2Unit: '°Bx',
    metric2Default: 6.5,
    metric2Min: 3,
    metric2Max: 20,
    metric2Step: 0.1,
    description: 'UNECE FFV-46 / OECD: paketlemede en az 6,2 °Bx VEYA ortalama kuru madde en az %15; dağıtım zincirine girişte en az 9,5 °Bx.',
    calculate: (val1, val2 = 6.5) => {
      if (val1 >= 15.0 || val2 >= 6.2) return { interpretation: 'UNECE/OECD olgunluk şartı karşılanıyor (≥6,2 °Bx veya KM ≥%15) — paketleme ve depolama uygun', statusBadge: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      if (val1 >= 14.0 || val2 >= 5.5) return { interpretation: 'Sınırda — 3–5 gün sonra yeniden ölçün; hasada başlamayın', statusBadge: 'bg-amber-100 text-amber-900 border-amber-300' };
      return { interpretation: 'Olgunluk şartı karşılanmıyor — hasat edilmez (UNECE FFV-46)', statusBadge: 'bg-rose-100 text-rose-900 border-rose-300' };
    }
  }
};

/**
 * Automatically detects crop type from product name
 */
export function detectSpecialCropType(productName: string): SpecialCropType {
  const p = (productName || '').toLowerCase();
  
  if (p.includes('alma') || p.includes('elma') || p.includes('apple') || p.includes('armut') || p.includes('pear')) {
    return 'APPLE_PEAR';
  }
  if (p.includes('avakado') || p.includes('avokado') || p.includes('avocado')) {
    return 'AVOCADO';
  }
  if (p.includes('pomidor') || p.includes('domates') || p.includes('tomato')) {
    return 'TOMATO';
  }
  if (p.includes('üzüm') || p.includes('uzum') || p.includes('grape')) {
    return 'GRAPE';
  }
  if (p.includes('kartoska') || p.includes('kartoşka') || p.includes('patates') || p.includes('potato')) {
    return 'POTATO';
  }
  if (p.includes('sogan') || p.includes('soğan') || p.includes('onion')) {
    return 'ONION';
  }
  if (p.includes('käşir') || p.includes('kasir') || p.includes('havuç') || p.includes('havuc') || p.includes('carrot')) {
    return 'CARROT';
  }
  if (p.includes('gawun') || p.includes('kavun') || p.includes('garpyz') || p.includes('karpuz') || p.includes('melon') || p.includes('watermelon')) {
    return 'MELON_WATERMELON';
  }
  if (p.includes('ananas') || p.includes('pineapple')) {
    return 'PINEAPPLE';
  }
  if (p.includes('kivi') || p.includes('kiwi') || p.includes('aktinidi')) {
    return 'KIWI';
  }
  if (p.includes('mango')) {
    return 'MANGO';
  }
  if (p.includes('piste') || p.includes('fıstık') || p.includes('fistik') || p.includes('pistachio')) {
    return 'PISTACHIO';
  }
  if (p.includes('nar') || p.includes('pomegranate')) {
    return 'POMEGRANATE';
  }
  if (p.includes('meke') || p.includes('mısır') || p.includes('misir') || p.includes('corn') || p.includes('maize')) {
    return 'CORN';
  }
  if (p.includes('hurma') || p.includes('trabzon') || p.includes('persimmon') || p.includes('date')) {
    return 'PERSIMMON';
  }
  if (p.includes('şeftali') || p.includes('seftali') || p.includes('peach') || p.includes('nektarin') || p.includes('nectarine')) {
    return 'PEACH_NECTARINE';
  }
  if (p.includes('erik') || p.includes('plum')) {
    return 'PLUM';
  }

  return 'NONE';
}
