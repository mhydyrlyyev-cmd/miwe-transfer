/**
 * MIWE HIL — Tek KPI hesaplama modülü (v2.2)
 * ------------------------------------------------------------------
 * Kural: her gösterge YALNIZCA kayıtlardan hesaplanır.
 *  - Math.random, sabit "örnek" değer veya tahmini katsayı yok.
 *  - n = 0 ise value = null ("Veri yok").
 *  - Her sonuç; birim, n, formül ve dayanak kayıtları taşır (ekranda tıklanınca listelenir).
 * Dashboard, PDF ve dışa aktarım aynı fonksiyonları kullanmalıdır.
 */
import { KPI_TARGETS } from '../config/kpiTargets';

export interface KpiPeriod { from: Date; to: Date; }

export interface KpiSourceRow {
  id: string;
  refId?: string;
  date?: string;
  label: string;
}

export interface KpiResult {
  key: string;
  title: string;
  value: number | null;
  unit: string;
  n: number;
  formula: string;
  target: number | null;
  /** 'max' = değer hedefin altında kalmalı, 'min' = üstünde */
  targetDirection: 'min' | 'max' | null;
  status: 'OK' | 'WARN' | 'NO_TARGET' | 'NO_DATA';
  detail?: string;
  sources: KpiSourceRow[];
}

export interface KpiData {
  references?: any[];
  harvestRecords?: any[];
  fieldRecords?: any[];
  ambarRecords?: any[];
  lojistikRecords?: any[];
  freezeDryRecords?: any[];
  salesRecords?: any[];
  incidentRecords?: any[];
}

// ---------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------
const num = (v: any): number | null => {
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

/** Yalnız tarih ("2026-11-02") yerel gün olarak; ISO zaman damgası olduğu gibi */
export function parseDate(v: any): Date | null {
  if (!v) return null;
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  const s = String(v);
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

const inPeriod = (d: Date | null, p?: KpiPeriod) => !p || (!!d && d >= p.from && d <= p.to);
const round = (v: number, digits = 1) => Number(v.toFixed(digits));
const short = (v: any) => (v === undefined || v === null ? '' : String(v));

function evaluate(value: number | null, target: number | null, dir: 'min' | 'max' | null): KpiResult['status'] {
  if (value === null) return 'NO_DATA';
  if (target === null || dir === null) return 'NO_TARGET';
  return dir === 'max' ? (value <= target ? 'OK' : 'WARN') : (value >= target ? 'OK' : 'WARN');
}

function result(r: Omit<KpiResult, 'status'>): KpiResult {
  return { ...r, sources: r.sources.slice(0, 200), status: evaluate(r.value, r.target, r.targetDirection) };
}

const harvestDate = (h: any) => parseDate(h.recordDate || h.timestamp);
const ambarDate = (a: any) => parseDate(a.acceptanceDate || a.timestamp);
const fieldDate = (f: any) => parseDate(f.harvestDate || f.date || f.timestamp);
const lojistikDate = (l: any) => parseDate(l.shipmentDate || l.timestamp);
const fdDate = (f: any) => parseDate(f.processDate || f.timestamp);
const salesDate = (s: any) => parseDate(s.salesDate || s.timestamp);
const incidentDate = (i: any) => parseDate(i.incidentDate || i.recordDate || i.timestamp);

/** Kalite sınıfı anahtarları: 'EXTRA (V-20)' ve 'I (V-22) EXC' premium sayılır */
export function isPremiumClass(k: any): boolean {
  const s = String(k || '').trim().toUpperCase();
  return s.startsWith('EXTRA') || s.startsWith('I (') || s === 'I' || s.startsWith('EKSTRA') || s === 'SINIF 1' || s === '1. SINIF';
}

// ---------------------------------------------------------------
// 1. Premium (Ekstra + I. sınıf) payı — depo kabulü, kg
// ---------------------------------------------------------------
export function premiumShare(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p) && (num(a.acceptedWeightKg) ?? 0) > 0 && a.kaliteSinifi);
  const total = rows.reduce((s, a) => s + (num(a.acceptedWeightKg) || 0), 0);
  const prem = rows.filter(a => isPremiumClass(a.kaliteSinifi)).reduce((s, a) => s + (num(a.acceptedWeightKg) || 0), 0);
  return result({
    key: 'premiumShare', title: 'Ekstra + I. sınıf payı', unit: '%', n: rows.length,
    value: total > 0 ? round((prem / total) * 100) : null,
    formula: 'Ekstra ve I. sınıf kabul kg / sınıfı girilmiş toplam kabul kg × 100',
    target: KPI_TARGETS.premiumSharePctMin, targetDirection: 'min',
    detail: total > 0 ? `${Math.round(prem).toLocaleString('tr-TR')} / ${Math.round(total).toLocaleString('tr-TR')} kg` : undefined,
    sources: rows.map(a => ({ id: a.id, refId: a.refId, date: short(a.acceptanceDate), label: `${a.kaliteSinifi} · ${num(a.acceptedWeightKg)} kg` }))
  });
}

// ---------------------------------------------------------------
// 2. Aşamalara göre gıda kaybı (FAO SDG 12.3.1(a) yaklaşımı)
// ---------------------------------------------------------------
export type LossStage = 'Hasat' | 'Kabul (tartı farkı)' | 'Kabulde çürük' | 'Paketleme' | 'Depolama' | 'Lojistik' | 'Müşteri';

const STAGE_OF_DETECTION: Record<string, LossStage> = {
  'Sera İçi': 'Hasat',
  'Hasat / Kesim': 'Hasat',
  'Yıkama & Paketleme': 'Paketleme',
  'Soğuk Depo / Gazlama Odası': 'Depolama',
  'Yükleme / Lojistik': 'Lojistik',
  'Müşteri / Varış Noktası': 'Müşteri'
};

export interface LossBreakdown {
  baseKg: number;
  baseSource: 'Hasat kayıtları' | 'Depo beklenen ağırlığı' | 'Yok';
  stages: Array<{ stage: LossStage; kg: number; pct: number | null }>;
  /** v45: olay kayıtlarındaki "etkilenen kg" kayıp değildir (ürün ayıklanıp satılabilir); ayrı gösterilir */
  incidentAffectedKg: number;
}

export function lossBreakdown(d: KpiData, p?: KpiPeriod): LossBreakdown {
  const harvestKg = (d.harvestRecords || []).filter(h => inPeriod(harvestDate(h), p)).reduce((s, h) => s + (num(h.dailyTotalKg) || 0), 0);
  const ambar = (d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p));
  const expectedKg = ambar.reduce((s, a) => s + (num(a.expectedWeightKg) || 0), 0);
  const baseKg = harvestKg > 0 ? harvestKg : expectedKg;
  const baseSource: LossBreakdown['baseSource'] = harvestKg > 0 ? 'Hasat kayıtları' : expectedKg > 0 ? 'Depo beklenen ağırlığı' : 'Yok';

  const kg: Record<LossStage, number> = { 'Hasat': 0, 'Kabul (tartı farkı)': 0, 'Kabulde çürük': 0, 'Paketleme': 0, 'Depolama': 0, 'Lojistik': 0, 'Müşteri': 0 };
  ambar.forEach(a => {
    const exp = num(a.expectedWeightKg), acc = num(a.acceptedWeightKg);
    if (exp !== null && acc !== null && exp > acc) kg['Kabul (tartı farkı)'] += exp - acc;
    kg['Kabulde çürük'] += num(a.rotKg) || 0;
  });
  let incidentAffectedKg = 0;
  (d.incidentRecords || []).filter(i => inPeriod(incidentDate(i), p)).forEach(i => {
    incidentAffectedKg += num(i.affectedQuantityKg) || 0;
  });
  void STAGE_OF_DETECTION;

  const stages = (Object.keys(kg) as LossStage[]).map(stage => ({
    stage, kg: Math.round(kg[stage]), pct: baseKg > 0 ? round((kg[stage] / baseKg) * 100, 2) : null
  }));
  return { baseKg: Math.round(baseKg), baseSource, stages, incidentAffectedKg: Math.round(incidentAffectedKg) };
}

export function foodLoss(d: KpiData, p?: KpiPeriod): KpiResult {
  const b = lossBreakdown(d, p);
  // FAO gıda kaybı endeksi perakende/tüketici aşamasını kapsamaz → "Müşteri" hariç
  const lossKg = b.stages.filter(s => s.stage !== 'Müşteri').reduce((s, x) => s + x.kg, 0);
  const n = (d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p)).length + (d.incidentRecords || []).filter(i => inPeriod(incidentDate(i), p)).length;
  return result({
    key: 'foodLoss', title: 'Gıda kaybı (müşteri öncesi)', unit: '%', n,
    value: b.baseKg > 0 ? round((lossKg / b.baseKg) * 100, 2) : null,
    formula: 'Tartı farkı + kabulde çürük (müşteri hariç) / hasat kg × 100. Olay kayıtlarındaki etkilenen kg kayıp sayılmaz.',
    target: KPI_TARGETS.foodLossPctMax, targetDirection: 'max',
    detail: b.baseKg > 0 ? `${lossKg.toLocaleString('tr-TR')} / ${b.baseKg.toLocaleString('tr-TR')} kg${b.incidentAffectedKg ? ` · olaylarda etkilenen ${b.incidentAffectedKg.toLocaleString('tr-TR')} kg (kayıp sayılmaz)` : ''}` : undefined,
    sources: [
      ...(d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p) && ((num(a.rotKg) || 0) > 0 || ((num(a.expectedWeightKg) || 0) > (num(a.acceptedWeightKg) || 0))))
        .map(a => ({ id: a.id, refId: a.refId, date: short(a.acceptanceDate), label: `Kabul: beklenen ${num(a.expectedWeightKg) ?? '-'} / kabul ${num(a.acceptedWeightKg) ?? '-'} kg, çürük ${num(a.rotKg) ?? 0} kg` })),
      ...(d.incidentRecords || []).filter(i => inPeriod(incidentDate(i), p) && (num(i.affectedQuantityKg) || 0) > 0)
        .map(i => ({ id: i.id, refId: i.refId, date: short(i.incidentDate || i.recordDate), label: `Olay (${i.detectionStage || 'aşama yok'}): ${num(i.affectedQuantityKg)} kg` }))
    ]
  });
}

// ---------------------------------------------------------------
// 3. Hasattan depo kabulüne süre (gün, medyan) — RefID ile eşleşen partiler
// ---------------------------------------------------------------
export function harvestToCooling(d: KpiData, p?: KpiPeriod): KpiResult {
  const firstHarvest = new Map<string, Date>();
  (d.harvestRecords || []).forEach(h => {
    const dt = harvestDate(h);
    if (!h.refId || !dt) return;
    const prev = firstHarvest.get(h.refId);
    if (!prev || dt < prev) firstHarvest.set(h.refId, dt);
  });
  const pairs: Array<{ a: any; days: number }> = [];
  (d.ambarRecords || []).forEach(a => {
    const dt = ambarDate(a);
    const hv = a.refId ? firstHarvest.get(a.refId) : undefined;
    if (!dt || !hv || !inPeriod(dt, p)) return;
    const days = Math.round((dt.getTime() - hv.getTime()) / 86400000);
    if (days >= 0) pairs.push({ a, days });
  });
  const sorted = pairs.map(x => x.days).sort((x, y) => x - y);
  const median = sorted.length ? (sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2) : null;
  return result({
    key: 'harvestToCooling', title: 'Hasattan depoya süre', unit: 'gün', n: pairs.length,
    value: median, formula: 'Aynı RefID için depo kabul tarihi − ilk hasat tarihi (medyan, gün)',
    target: KPI_TARGETS.harvestToCoolingDaysMax, targetDirection: 'max',
    detail: pairs.length ? `en uzun ${sorted[sorted.length - 1]} gün` : 'RefID ile eşleşen hasat–kabul çifti yok',
    sources: pairs.map(x => ({ id: x.a.id, refId: x.a.refId, date: short(x.a.acceptanceDate), label: `${x.days} gün` }))
  });
}

// ---------------------------------------------------------------
// 4. Nitrat limit aşımı (%)
// ---------------------------------------------------------------
export function nitrateExceedance(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.fieldRecords || []).filter(f => inPeriod(fieldDate(f), p) && f.hasNitrateTest !== false && num(f.nitrateMgKg) !== null && typeof f.nitratePass === 'boolean');
  const bad = rows.filter(f => f.nitratePass === false);
  return result({
    key: 'nitrate', title: 'Nitrat limiti aşan numune', unit: '%', n: rows.length,
    value: rows.length ? round((bad.length / rows.length) * 100) : null,
    formula: 'Limit üstü numune / nitrat testi yapılan numune × 100',
    target: KPI_TARGETS.nitrateExceedPctMax, targetDirection: 'max',
    detail: rows.length ? `${bad.length} / ${rows.length} numune` : undefined,
    sources: rows.map(f => ({ id: f.id, refId: f.refId, date: short(f.timestamp).slice(0, 10), label: `${num(f.nitrateMgKg)} mg/kg (limit ${num(f.nitrateLimitMgKg) ?? '-'})${f.nitratePass === false ? ' · AŞIM' : ''}` }))
  });
}

// ---------------------------------------------------------------
// 5. DÖF / Barlag Akty (CAPA) — gecikmiş açık kayıtlar
// ---------------------------------------------------------------
export function capaOverdue(d: KpiData, now: Date = new Date()): KpiResult {
  const open = (d.incidentRecords || []).filter(i => String(i.status || 'OPEN') !== 'RESOLVED');
  const overdue = open.filter(i => {
    const t = parseDate(i.targetResolutionDate);
    return !!t && t < now;
  });
  const noDeadline = open.filter(i => !parseDate(i.targetResolutionDate)).length;
  return result({
    key: 'capaOverdue', title: 'Gecikmiş açık DÖF', unit: 'adet', n: (d.incidentRecords || []).length,
    value: (d.incidentRecords || []).length ? overdue.length : null,
    formula: 'Durumu çözülmedi ve hedef çözüm tarihi geçmiş olay sayısı',
    target: KPI_TARGETS.overdueCapaMax, targetDirection: 'max',
    detail: `${open.length} açık${noDeadline ? ` · ${noDeadline} tanesinde hedef tarih yok` : ''}`,
    sources: open.map(i => ({ id: i.id, refId: i.refId, date: short(i.targetResolutionDate), label: `${i.incidentType || 'Olay'} · ${i.priority || ''} · hedef ${short(i.targetResolutionDate) || 'yok'}` }))
  });
}

// ---------------------------------------------------------------
// 6. Gelir / kg (para birimi ayrı) ve kalitesizlik maliyeti
// ---------------------------------------------------------------
export function revenuePerKg(d: KpiData, p?: KpiPeriod, currency: 'TMT' | 'USD' = 'TMT'): KpiResult {
  const items: Array<{ s: any; it: any }> = [];
  (d.salesRecords || []).filter(s => inPeriod(salesDate(s), p)).forEach(s => (s.items || []).forEach((it: any) => {
    if ((it.currency || 'TMT') === currency && (num(it.unitPriceTmt) || 0) > 0 && (num(it.weightKg) || 0) > 0) items.push({ s, it });
  }));
  const kg = items.reduce((a, x) => a + (num(x.it.weightKg) || 0), 0);
  const amount = items.reduce((a, x) => a + (num(x.it.totalPriceTmt) || 0), 0);
  return result({
    key: `revenuePerKg_${currency}`, title: `Gelir / kg (${currency})`, unit: `${currency}/kg`, n: items.length,
    value: kg > 0 ? round(amount / kg, 2) : null,
    formula: `Fiyatı girilmiş ${currency} kalemlerinin tutarı / ağırlığı`,
    target: null, targetDirection: null,
    detail: kg > 0 ? `${Math.round(amount).toLocaleString('tr-TR')} ${currency} / ${Math.round(kg).toLocaleString('tr-TR')} kg` : 'Fiyatlı satış kalemi yok',
    sources: items.map(x => ({ id: x.s.id, refId: x.s.refId, date: short(x.s.salesDate), label: `${x.it.qualityGrade || ''} · ${num(x.it.weightKg)} kg × ${num(x.it.unitPriceTmt)} ${currency}` }))
  });
}

export function costOfPoorQuality(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.incidentRecords || []).filter(i => inPeriod(incidentDate(i), p) && (num(i.estimatedLossTmt) || 0) > 0);
  const total = rows.reduce((s, i) => s + (num(i.estimatedLossTmt) || 0), 0);
  return result({
    key: 'copq', title: 'Kalitesizlik maliyeti (olaylar)', unit: 'TMT', n: rows.length,
    value: rows.length ? Math.round(total) : null,
    formula: 'Olay kayıtlarındaki tahmini maddi zarar toplamı',
    target: null, targetDirection: null,
    sources: rows.map(i => ({ id: i.id, refId: i.refId, date: short(i.incidentDate || i.recordDate), label: `${i.incidentType || 'Olay'} · ${num(i.estimatedLossTmt)} TMT` }))
  });
}

// ---------------------------------------------------------------
// 7. Freeze-Dry: randıman ve nem uygunluğu
// ---------------------------------------------------------------
export function freezeDryMoistureCompliance(d: KpiData, p?: KpiPeriod): KpiResult {
  const limit = KPI_TARGETS.freezeDryMoisturePctMax;
  const rows = (d.freezeDryRecords || []).filter(f => inPeriod(fdDate(f), p) && num(f.finalMoisturePercent) !== null);
  const ok = limit === null ? [] : rows.filter(f => (num(f.finalMoisturePercent) as number) <= limit);
  return result({
    key: 'fdMoisture', title: `Freeze-Dry nem ≤ %${limit ?? '-'}`, unit: '%', n: rows.length,
    value: rows.length && limit !== null ? round((ok.length / rows.length) * 100) : null,
    formula: 'Son nemi eşiğin altında kalan parti / ölçülen parti × 100',
    target: limit === null ? null : 100, targetDirection: 'min',
    sources: rows.map(f => ({ id: f.id, refId: f.refId, date: short(f.processDate), label: `nem %${num(f.finalMoisturePercent)} · randıman %${num(f.yieldRatioPercent) ?? '-'}` }))
  });
}

export function freezeDryYield(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.freezeDryRecords || []).filter(f => inPeriod(fdDate(f), p) && (num(f.rawWeightKg) || 0) > 0 && num(f.finalDryWeightKg) !== null);
  const raw = rows.reduce((s, f) => s + (num(f.rawWeightKg) || 0), 0);
  const dry = rows.reduce((s, f) => s + (num(f.finalDryWeightKg) || 0), 0);
  return result({
    key: 'fdYield', title: 'Freeze-Dry randımanı', unit: '%', n: rows.length,
    value: raw > 0 ? round((dry / raw) * 100, 2) : null,
    formula: 'Toplam kuru ürün kg / toplam yaş hammadde kg × 100',
    target: null, targetDirection: null,
    sources: rows.map(f => ({ id: f.id, refId: f.refId, date: short(f.processDate), label: `${num(f.rawWeightKg)} → ${num(f.finalDryWeightKg)} kg` }))
  });
}

// ---------------------------------------------------------------
// 8. Hasat verimliliği ve soğuk zincir
// ---------------------------------------------------------------
export function harvestProductivity(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.harvestRecords || []).filter(h => inPeriod(harvestDate(h), p) && (num(h.workerCount) || 0) > 0 && (num(h.dailyTotalKg) || 0) > 0);
  const kg = rows.reduce((s, h) => s + (num(h.dailyTotalKg) || 0), 0);
  const workerDays = rows.reduce((s, h) => s + (num(h.workerCount) || 0), 0);
  return result({
    key: 'productivity', title: 'Hasat verimi', unit: 'kg/işçi-gün', n: rows.length,
    value: workerDays > 0 ? Math.round(kg / workerDays) : null,
    formula: 'Toplam hasat kg / toplam işçi-gün (işçi sayısı girilmiş günler)',
    target: null, targetDirection: null,
    sources: rows.map(h => ({ id: h.id, refId: h.refId, date: short(h.recordDate), label: `${num(h.dailyTotalKg)} kg / ${num(h.workerCount)} işçi` }))
  });
}

export function coldChainTransit(d: KpiData, p?: KpiPeriod): KpiResult {
  const { transitTempMaxC: max, transitTempMinC: min } = KPI_TARGETS;
  const rows = (d.lojistikRecords || []).filter(l => inPeriod(lojistikDate(l), p) && num(l.transitTemperature) !== null);
  const hasRange = max !== null || min !== null;
  const inRange = rows.filter(l => {
    const t = num(l.transitTemperature) as number;
    return (max === null || t <= max) && (min === null || t >= min);
  });
  return result({
    key: 'coldChain', title: 'Soğuk zincire uygun sefer', unit: '%', n: rows.length,
    value: rows.length && hasRange ? round((inRange.length / rows.length) * 100) : null,
    formula: 'Nakliye sıcaklığı hedef aralıkta olan sefer / sıcaklığı girilmiş sefer × 100',
    target: hasRange ? 100 : null, targetDirection: hasRange ? 'min' : null,
    detail: hasRange ? undefined : 'Hedef sıcaklık aralığı henüz tanımlanmadı',
    sources: rows.map(l => ({ id: l.id, refId: l.refId, date: short(l.shipmentDate), label: `${num(l.transitTemperature)} °C · ${l.vehiclePlate || ''}` }))
  });
}

// ---------------------------------------------------------------
// 12. Kabul Talep / Red Oranı
// ---------------------------------------------------------------
export function intakeClaimRate(d: KpiData, p?: KpiPeriod): KpiResult {
  const rows = (d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p) && (a.intakeDecision || a.acceptanceStatus));
  const claims = rows.filter(a => a.intakeDecision === 'TALEP' || a.intakeDecision === 'RED' || a.acceptanceStatus === 'REJECTED');
  return result({
    key: 'intakeClaimRate',
    title: 'Kabul talep / red oranı',
    unit: '%',
    n: rows.length,
    value: rows.length > 0 ? round((claims.length / rows.length) * 100) : null,
    formula: 'Talep veya red kararı verilen kabul sayısı / kararı girilmiş toplam kabul × 100',
    target: 0,
    targetDirection: 'max',
    detail: rows.length > 0 ? `${claims.length} / ${rows.length} parti talep/red` : undefined,
    sources: rows.map(a => ({
      id: a.id,
      refId: a.refId,
      date: short(a.acceptanceDate),
      label: `${a.intakeDecision || a.acceptanceStatus} · ${a.supplier || a.countryOfOrigin || ''}`
    }))
  });
}

// ---------------------------------------------------------------
// 13. Datalogger Eşik Dışı Süre (Saat)
// ---------------------------------------------------------------
export function loggerExcursionHours(d: KpiData, p?: KpiPeriod): KpiResult {
  const shipments = (d.lojistikRecords || []).filter(l => inPeriod(lojistikDate(l), p));
  const loggers = shipments.flatMap(l => (l.dataloggers || []).map((dl: any) => ({ ...dl, refId: l.refId, shipmentDate: l.shipmentDate })));
  const totalMinutes = loggers.reduce((sum, dl) => {
    const stats = dl.fullStats || dl.tripStats;
    const above = stats?.minutesAboveUpper || 0;
    const below = stats?.minutesBelowLower || 0;
    return sum + above + below;
  }, 0);
  const hours = round(totalMinutes / 60, 1);
  return result({
    key: 'loggerExcursionHours',
    title: 'Datalogger eşik dışı süre',
    unit: 'saat',
    n: loggers.length,
    value: loggers.length > 0 ? hours : null,
    formula: 'Tüm logger kayıtlarındaki limit aşım dakikaları toplamı / 60',
    target: 0,
    targetDirection: 'max',
    detail: loggers.length > 0 ? `${totalMinutes} dakika (${loggers.length} cihaz)` : undefined,
    sources: loggers.map(dl => {
      const stats = dl.fullStats || dl.tripStats;
      const m = (stats?.minutesAboveUpper || 0) + (stats?.minutesBelowLower || 0);
      return {
        id: dl.id,
        refId: dl.refId,
        date: short(dl.shipmentDate),
        label: `${dl.deviceId} · ${m} dk eşik dışı`
      };
    })
  });
}

// ---------------------------------------------------------------
// 14. Tedarikçi Bazlı Kusur Dağılımı
// ---------------------------------------------------------------
export function supplierDefectBreakdown(
  d: KpiData,
  p?: KpiPeriod
): Array<{ supplier: string; defectRatePct: number; n: number; sampleFruits: number }> {
  const rows = (d.ambarRecords || []).filter(a => inPeriod(ambarDate(a), p));
  const groups: Record<string, { totalDefects: number; totalFruits: number; count: number }> = {};

  rows.forEach(a => {
    const supp = a.supplier || a.countryOfOrigin || 'Bilinmeyen Tedarikçi';
    if (!groups[supp]) {
      groups[supp] = { totalDefects: 0, totalFruits: 0, count: 0 };
    }
    groups[supp].count += 1;

    if (a.sampleBoxes && a.sampleBoxes.length > 0) {
      a.sampleBoxes.forEach((b: any) => {
        const count = b.countSize || 0;
        const defects = (b.mechanical || 0) + (b.rotten || 0) + (b.soft || 0) + (b.internal || 0) + (b.mold || 0) + (b.coldDamage || 0) + (b.anthracnose || 0);
        groups[supp].totalFruits += count;
        groups[supp].totalDefects += defects;
      });
    } else if (a.sampleWeightKg && a.sampleWeightKg > 0) {
      const sampleKg = a.sampleWeightKg;
      const wasteKg = (a.rotKg || 0) + (a.nonStandardKg || 0) + (a.mechanicsKg || 0);
      groups[supp].totalFruits += Math.round(sampleKg * 10);
      groups[supp].totalDefects += Math.round(wasteKg * 10);
    }
  });

  return Object.entries(groups)
    .filter(([_, v]) => v.totalFruits > 0)
    .map(([supplier, v]) => ({
      supplier,
      defectRatePct: round((v.totalDefects / v.totalFruits) * 100, 1),
      n: v.count,
      sampleFruits: v.totalFruits
    }))
    .sort((a, b) => b.defectRatePct - a.defectRatePct);
}

// ---------------------------------------------------------------
// Dönem ve trend
// ---------------------------------------------------------------
export function monthPeriod(year: number, monthIndex0: number): KpiPeriod {
  return { from: new Date(year, monthIndex0, 1), to: new Date(year, monthIndex0 + 1, 0, 23, 59, 59, 999) };
}

export function lastMonths(count: number, now: Date = new Date()): Array<{ label: string; period: KpiPeriod }> {
  const out: Array<{ label: string; period: KpiPeriod }> = [];
  for (let i = count - 1; i >= 0; i--) {
    const dt = new Date(now.getFullYear(), now.getMonth() - i, 1);
    out.push({ label: `${String(dt.getMonth() + 1).padStart(2, '0')}.${String(dt.getFullYear()).slice(2)}`, period: monthPeriod(dt.getFullYear(), dt.getMonth()) });
  }
  return out;
}

export function monthlySeries(fn: (d: KpiData, p?: KpiPeriod) => KpiResult, d: KpiData, months = 12, now: Date = new Date()) {
  return lastMonths(months, now).map(m => ({ label: m.label, value: fn(d, m.period).value }));
}

/** Özet ekranının ana göstergeleri (sıra = ekrandaki sıra) */
export const SUMMARY_KPIS: Array<(d: KpiData, p?: KpiPeriod) => KpiResult> = [
  premiumShare,
  foodLoss,
  harvestToCooling,
  nitrateExceedance,
  (d) => capaOverdue(d),
  (d, p) => revenuePerKg(d, p, 'TMT')
];

export const SECONDARY_KPIS: Array<(d: KpiData, p?: KpiPeriod) => KpiResult> = [
  (d, p) => revenuePerKg(d, p, 'USD'),
  costOfPoorQuality,
  freezeDryYield,
  freezeDryMoistureCompliance,
  harvestProductivity,
  coldChainTransit,
  intakeClaimRate,
  loggerExcursionHours
];
