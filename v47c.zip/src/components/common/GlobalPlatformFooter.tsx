import React, { useState, useMemo } from 'react';
import { computePeriodReport, periodRange } from '../../utils/periodReport';
import { MapPin, BarChart3, ChevronDown, ChevronUp, Layers, AlertTriangle, ShieldAlert, LayoutGrid } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { ActiveFieldContext, ReferenceItem, AmbarRecord, FieldRecord } from '../../types';
import { QualityInsightCard } from '../dashboard/QualityInsightCard';

interface GlobalPlatformFooterProps {
  activeFieldContext: ActiveFieldContext | null;
  onSelectFieldContext: (ctx: ActiveFieldContext | null) => void;
  references: ReferenceItem[];
  ambarRecords: AmbarRecord[];
  fieldRecords?: FieldRecord[];
  /** v47c: stok, Rapor merkezi ile aynı hesaptan gelir (giriş − sevk − satış) */
  harvestRecords?: any[];
  lojistikRecords?: any[];
  salesRecords?: any[];
  incidentRecords?: any[];
  onOpenSystemView: (view: 'HARVEST_PORTAL' | 'QUALITY_ROADMAP' | 'ANALYTICS' | 'REFERENCES' | any) => void;
  currentView?: string;
  onSearchRef?: (refId: string) => void;
  onRerouteToFreezeDry?: (refId: string, reason: string) => void;
  onOpenTraceability?: (ref: ReferenceItem) => void;
  onOpenFieldTest?: (refId: string) => void;
}

export const GlobalPlatformFooter: React.FC<GlobalPlatformFooterProps> = ({
  activeFieldContext,
  onSelectFieldContext,
  references = [],
  ambarRecords = [],
  fieldRecords = [],
  harvestRecords = [],
  lojistikRecords = [],
  salesRecords = [],
  incidentRecords = [],
  onOpenSystemView,
  currentView,
  onSearchRef,
  onRerouteToFreezeDry,
  onOpenTraceability,
  onOpenFieldTest
}) => {
  const [showStockChart, setShowStockChart] = useState<boolean>(true);

  // Compute stock quantities (kg) by product
  const stockChartData = useMemo(() => {
    // v47c: eski hesap tüm partileri (sevk edilmiş, depoya girmemiş, kasa×15 kg tahmini) stoğa ekliyordu.
    // Artık Rapor merkezi "Depo durumu" ile aynı: depoya giriş − sevk − satış.
    const rep = computePeriodReport({ references, harvestRecords, fieldRecords, ambarRecords, lojistikRecords, salesRecords, incidentRecords } as any, periodRange('THIS_WEEK').current);
    const palette = ['#10b981', '#0d9488', '#0284c7', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6', '#14b8a6'];
    return rep.stock.byProduct
      .filter(p => p.kg > 0)
      .sort((a, b) => b.kg - a.kg)
      .slice(0, 8)
      .map((p, idx) => ({ product: p.product, stockKg: p.kg, batchCount: 0, fill: palette[idx % palette.length] }));
  }, [references, ambarRecords, harvestRecords, fieldRecords, lojistikRecords, salesRecords, incidentRecords]);

  const totalStockKg = useMemo(() => {
    return stockChartData.reduce((acc, curr) => acc + curr.stockKg, 0);
  }, [stockChartData]);
  return (
    <div className="w-full space-y-5 pt-6 pb-4 border-t border-slate-200 dark:border-slate-800">
      
      {/* ------------------------------------------------------------------------- */}
      {/* MEVCUT ÜRÜN STOK DAĞILIMI & KALİTE ÖNGÖRÜ RİSK RADARI                     */}
      {/* ------------------------------------------------------------------------- */}
      <div className="space-y-4">

        {/* MEVCUT ÜRÜN STOK DAĞILIMI (KG) & RECHARTS GRAFİK */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/70 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800">
                <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100">
                    Depodaki stok (kg)
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-700 tabular-nums">
                    {(totalStockKg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t toplam
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Depoya giriş − sevk − satış · Rapor merkezi "Depo durumu" ile aynı hesap
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowStockChart(!showStockChart)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-slate-950 dark:hover:text-white bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl transition cursor-pointer"
            >
              <span>{showStockChart ? 'Grafiği Gizle' : 'Grafiği Göster'}</span>
              {showStockChart ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {showStockChart && (
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              {stockChartData.length === 0 ? (
                <div className="py-6 px-4 text-center bg-slate-50 dark:bg-slate-800 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    ⏳ Sıfır Veri / Veri Bekleniyor (Cold-Start Modu)
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    İlk gerçek Ambar Kabul veya Hasat partisi girildiğinde ürün bazlı stok grafiği otomatik hesaplanacaktır.
                  </p>
                </div>
              ) : (
                <>
                  <div className="w-full h-44 sm:h-52 min-w-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stockChartData} margin={{ top: 10, right: 10, left: -15, bottom: 25 }}>
                        <XAxis
                          dataKey="product"
                          tick={{ fontSize: 10, fill: '#64748b' }}
                          interval={0}
                          angle={-15}
                          textAnchor="end"
                          tickLine={false}
                        />
                        <YAxis
                          tick={{ fontSize: 10, fill: '#64748b' }}
                          tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
                          tickLine={false}
                          axisLine={false}
                        />
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-xl border border-slate-700">
                                  <p className="font-bold text-teal-300">{data.product}</p>
                                  <p className="text-slate-200 mt-1 flex items-center gap-2">
                                    <span>Stok Miktarı:</span>
                                    <strong className="font-mono text-emerald-400">
                                      {data.stockKg.toLocaleString('tr-TR')} kg
                                    </strong>
                                  </p>
                                  <p className="text-[10px] text-slate-400 mt-0.5">
                                    {(data.stockKg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 2 })} t
                                  </p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar
                          dataKey="stockKg"
                          radius={[6, 6, 0, 0]}
                          maxBarSize={45}
                        >
                          {stockChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill || '#10b981'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Quick summary product badges */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-1 mt-2 text-xs">
                    {stockChartData.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 dark:bg-slate-800 rounded-lg shrink-0 border border-slate-200 dark:border-slate-700"
                      >
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.fill }} />
                        <span className="font-medium text-slate-700 dark:text-slate-300">{item.product}:</span>
                        <strong className="font-mono text-slate-900 dark:text-white">{item.stockKg.toLocaleString('tr-TR')} kg</strong>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------------------- */}
      {/* KALİTE ÖNGÖRÜ RİSK RADARI & RAF ÖMRÜ MATRİSİ                              */}
      {/* ------------------------------------------------------------------------- */}
      <div className="w-full">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">Kalite riskleri ve raf ömrü</h2>
        </div>
        <QualityInsightCard
          fieldRecords={fieldRecords}
          references={references}
          onSelectReference={onSearchRef}
          onRerouteToFreezeDry={onRerouteToFreezeDry}
          onOpenTraceability={onOpenTraceability}
          onOpenFieldTest={onOpenFieldTest}
          isCompact={true}
          defaultExpanded={false}
          onNavigateToAnalytics={() => onOpenSystemView('ANALYTICS')}
          onNavigateToRecords={() => onOpenSystemView('REFERENCES')}
        />
      </div>

    </div>
  );
};

