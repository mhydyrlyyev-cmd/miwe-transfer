# v47c — Standart kataloğu geri yükleme + yanlış stok/uyarı düzeltmeleri

## Neden
- Canlıdaki standart kataloğu eski (v42) sürüm: muz "MIWE iç standardı", 7 "Doğrulanacak". Doğrusu v45 sürümü: 16 doğrulandı, 8 iç değer, muz UNECE FFV-35. Dosya yeniden gönderiliyor.
- Ana sayfa stok grafiği 30,5 t gösteriyordu; gerçek depo 4.478 kg. Eski hesap tüm partileri (sevk edilmiş, depoya girmemiş, kasa×15 kg tahmini) stok sayıyordu. Artık Rapor merkezi "Depo durumu" ile aynı hesap.
- "Kritik stok" bildirimi kaldırıldı: 5 t altındaki her ürün için "DÖF gerekir" diyordu; kalite olayı değil, yanlış alarm.
- Görsel standartlar penceresi açık tasarıma geçti; reklam metinleri ve gerçek olmayan "ERP konnektörü hazır" gibi sekmeler kaldırıldı. WSU nişasta ve muz/badem skalaları kaldı.
- Bildirim başlıklarında emoji ve BÜYÜK HARF gösterimde sadeleşti.
- Hasat kaydı ürün seçilmeden kaydedilmiyor (önceden "Meyve / Genel Ürün" yazıyordu).
- Rapor merkezi başlığı telefonda düğmelere sıkışmıyor.

## TAM_LISTE.txt
Projedeki 202 kaynak dosyanın beklenen SHA-256 (ilk 16 hane). Yalnız KARŞILAŞTIRMA için; dosya değiştirme.

## SHA-256 (8 dosya)
996f758e56097073776b685a51335cde5eee23e3bff2fd280120c78ca4cbe9d2  src/App.tsx
5f078cd12cfd18f94ba3ffb66d0330c15ce25cb0156cfb718813d9ab3efbfc53  src/components/Header.tsx
91855853538e58430127aa8a5964ba51db801f16d3c1d1255a4982f24346049d  src/components/common/GlobalPlatformFooter.tsx
8ac7b1f8bfdbb4957ee0c1f626d51586163c5928fc3b09a946e20d419a33e9bf  src/components/common/VisualStandardsProofModal.tsx
f57d71bfa0ab93bd748d94ea314e6c34452e284aefdda8961914459597c2c941  src/components/forms/DailyHarvestForm.tsx
9d4a5c0503dad453c93c22ef02af4e13b9041a4b72f366db2348120e183a8e96  src/components/ui/PageHeader.tsx
8cab7564a3bf4e5f4add6f7501ace1bab30947370d7a0a48f08ee2ab0b56df8b  src/components/views/PeriodStatusView.tsx
afb6a037d72d511bd9bc899b53348df4c8200c8259116f31754a966736850ed8  src/config/standardsCatalog.ts
