# v40 — QR 2. bölüm: herkese açık kart · toplu tarama · A4 etiket

Uygulama sırası: v39.2'den SONRA. Dosyaları AYNEN (byte-identical) kopyala.
**firestore.rules DEĞİŞTİ → DeployRules GEREKİR** (yalnız yeni `publicRefs` bloğu eklendi; diğer kurallar aynı).

## 1) Herkese açık QR kartı (yalnız bilgi)
- Giriş yapmamış biri QR okutunca giriş ekranı yerine **Ürün izlenebilirlik kartı** açılır:
  ürün · çeşit, bahçe/sera, hasat tarihi, kalite sınıfı, bağlı test sayısı, durum ve
  "Ürünün yolculuğu" (Hasat → Ön soğutma → Soğuk depo → Sevk → Satış, tarihleriyle).
- Kişi adı, kg, fiyat, müşteri, not ve fotoğraf YAYINLANMAZ (kural da bu alanları reddeder).
- "Personel girişi" → giriş ekranı → girişten sonra aynı partinin işlem menüsü açılır (v39.2).
- Kartlar `publicRefs` koleksiyonunda; **yönetici veya müdür** platformu açtığında değişen
  kartlar arka planda (8 sn sonra) yayınlanır. Son 240 günün partileri. Kural yayınlanmamışsa
  kayıt akışı etkilenmez, 6 saat sonra yeniden dener.

## 2) Toplu QR tarama (muz paletleri)
- Ana menü → Hızlı kayıt → **Toplu QR tarama**. Kamera açık kalır; her palet listeye eklenir,
  aynı kod tekrar sayılmaz. Liste sera/bahçe bazında sayar, farklı ürün varsa uyarır.
- "Depo kabul (n)" veya "Sevk (n)" → form ilk paletle açılır; her kayıttan sonra başarı ekranında
  **"Sıradaki palet (2/n)"** düğmesi. Altta "Toplu depo kabul: 2/8 · Forma dön · Bitir" şeridi.

## 3) QR etiket sayfası (A4)
- Ana menü → Raporlar ve kayıtlar → **QR etiket sayfası (A4)**.
- Partileri seç (arama, son 1/3/7/30 gün), düzen: 3×8 (70×37 mm) veya 2×7 (99×38 mm),
  her partiden adet → **Yazdır**. Etikette QR (platform linki), ürün · çeşit, RefID, yer, tarih.
- Tarayıcı açılır pencere iznini isteyebilir.

## Dosyalar
- src/services/publicRefs.ts (YENİ) · src/components/qr/PublicRefView.tsx (YENİ)
- src/components/qr/BatchScanModal.tsx (YENİ) · src/components/qr/LabelSheetModal.tsx (YENİ)
- src/components/common/QRScannerModal.tsx — continuous / title / subtitle / footer (eski kullanım aynı)
- src/components/common/SaveSuccessScreen.tsx — next / queueNote
- src/components/portal/HomeMenu.tsx — 2 yeni kutu
- src/App.tsx — kuyruk, modallar, herkese açık kart, yayın
- firestore.rules — publicRefs bloğu

## Kabul testleri
1. Yönetici girişi yap, 10 sn bekle → Firestore'da `publicRefs` koleksiyonu oluşur.
2. Çıkış yap, `<site>/?ref=<var olan RefID>` aç → Ürün izlenebilirlik kartı (giriş ekranı değil).
3. Kartta kişi adı / kg / fiyat yok; "Personel girişi" → giriş → işlem menüsü açılır.
4. Toplu QR tarama: 3 RefID'yi elle gir → listede 3; aynısını tekrar gir → yine 3.
5. "Depo kabul (3)" → Ambar formu 1. RefID ile; kaydet → "Sıradaki palet (2/3)" → 2. RefID ile açılır.
   3. kayıttan sonra "Toplu işlem tamamlandı: 3/3".
6. QR etiket sayfası: 2 parti seç → Yazdır → A4 önizlemede etiketler 3×8 düzende.
7. Header'daki normal QR tarayıcı eskisi gibi tek okutmada kapanıyor.
8. TypeScript derleme hatası yok.
