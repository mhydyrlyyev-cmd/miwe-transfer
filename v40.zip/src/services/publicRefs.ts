/**
 * v4.0 — Herkese açık parti kartı (QR vitrini).
 *
 * Telefon kamerasıyla QR okutan herkes (giriş yapmadan) yalnızca bu özet bilgiyi görür:
 * ürün, çeşit, bahçe/sera, hasat tarihi, süreç adımlarının tarihleri, kalite sınıfı.
 * Kişi adı, kg, fiyat, müşteri, not ve fotoğraf YAYINLANMAZ.
 *
 * Veriler `publicRefs/{refId}` koleksiyonunda tutulur (Firestore kuralı: herkes okur,
 * yalnız aktif personel yazar; alan listesi kuralda sabittir).
 * Yönetici / müdür cihazı referans listesi değiştikçe değişen kartları arka planda yayınlar.
 */
import { doc, getDoc, writeBatch } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ReferenceItem } from '../types';

export const PUBLIC_COLLECTION = 'publicRefs';
const SIG_KEY = 'miwe_public_sig_v1';
const PAUSE_KEY = 'miwe_public_pause_until';
const MAX_AGE_DAYS = 240;      // daha eski partiler yayınlanmaz
const CHUNK = 400;             // Firestore toplu yazma sınırının altında

export interface PublicRef {
  refId: string;
  product: string;
  variety: string;
  place: string;
  kind: string;          // LOT | TEST | ''
  status: string;
  qualityClass: string;
  testCount: number;
  harvestAt: string;     // YYYY-MM-DD
  precoolAt: string;
  storeAt: string;
  shipAt: string;
  soldAt: string;
  updatedAt: string;     // ISO
  v: number;
}

const day = (v?: string): string => {
  if (!v) return '';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : '';
};

function firstStatusAt(ref: ReferenceItem, statuses: string[], modules: string[] = []): string {
  const hist = Array.isArray(ref.statusHistory) ? [...ref.statusHistory] : [];
  hist.sort((a, b) => String(a.at).localeCompare(String(b.at)));
  const hit = hist.find(h => statuses.includes(String(h.to)) || modules.includes(String(h.module)));
  return hit ? day(hit.at) : '';
}

/** Referanstan yayınlanacak özet (yalnız izinli alanlar). */
export function toPublicRef(ref: ReferenceItem): PublicRef {
  const r: any = ref;
  const slips: any[] = Array.isArray(ref.precoolingSlips) ? ref.precoolingSlips : [];
  const precool = slips.map(s => day(s.endAt) || day(s.date) || day(s.startAt)).filter(Boolean).sort()[0] || '';
  return {
    refId: String(ref.refId),
    product: String(ref.product || ''),
    variety: String(ref.sortVariety || ref.variety || ''),
    place: String(ref.orchard || ref.greenhouse || ref.location || ''),
    kind: String(ref.refKind || ''),
    status: String(ref.status || ''),
    qualityClass: String(r.kaliteSinifi || ''),
    testCount: Array.isArray(ref.linkedTestRefIds) ? ref.linkedTestRefIds.length : 0,
    harvestAt: day(ref.createdAt),
    precoolAt: precool,
    storeAt: firstStatusAt(ref, ['RECEIVED'], ['AMBAR']),
    shipAt: firstStatusAt(ref, ['SHIPPED', 'IN_TRANSIT'], ['LOJISTIK']),
    soldAt: firstStatusAt(ref, ['SOLD'], ['SALES']),
    updatedAt: new Date().toISOString(),
    v: 1,
  };
}

function signature(p: PublicRef): string {
  const { updatedAt, ...rest } = p;
  return JSON.stringify(rest);
}

function loadSigs(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(SIG_KEY) || '{}') || {}; } catch { return {}; }
}
function saveSigs(m: Record<string, string>) {
  try { localStorage.setItem(SIG_KEY, JSON.stringify(m)); } catch { /* dolu: yok say */ }
}

/** Herkese açık kartı okur (giriş gerekmez). Bulunamazsa null. */
export async function fetchPublicRef(refId: string): Promise<PublicRef | null> {
  try {
    const snap = await getDoc(doc(db, PUBLIC_COLLECTION, refId));
    return snap.exists() ? (snap.data() as PublicRef) : null;
  } catch {
    return null;
  }
}

let running = false;

/**
 * Değişen kartları yayınlar. Hata (ör. kural henüz yayınlanmadıysa permission-denied)
 * kayıt akışını ETKİLEMEZ; 6 saat bekleyip yeniden dener.
 */
export async function syncPublicRefs(refs: ReferenceItem[]): Promise<{ written: number; skipped?: string }> {
  if (running) return { written: 0, skipped: 'busy' };
  try {
    const pause = Number(localStorage.getItem(PAUSE_KEY) || 0);
    if (pause && Date.now() < pause) return { written: 0, skipped: 'paused' };
  } catch { /* yok say */ }

  running = true;
  try {
    const cutoff = Date.now() - MAX_AGE_DAYS * 864e5;
    const sigs = loadSigs();
    const changed: PublicRef[] = [];
    for (const ref of refs) {
      if (!ref?.refId || (ref as any).archived) continue;
      const t = Date.parse(ref.updatedAt || ref.createdAt || '');
      if (!isNaN(t) && t < cutoff) continue;
      const p = toPublicRef(ref);
      const sig = signature(p);
      if (sigs[p.refId] !== sig) changed.push(p);
    }
    let written = 0;
    for (let i = 0; i < changed.length; i += CHUNK) {
      const part = changed.slice(i, i + CHUNK);
      const batch = writeBatch(db);
      part.forEach(p => batch.set(doc(db, PUBLIC_COLLECTION, p.refId), p));
      await batch.commit();
      part.forEach(p => { sigs[p.refId] = signature(p); });
      saveSigs(sigs);
      written += part.length;
    }
    return { written };
  } catch (err: any) {
    try { localStorage.setItem(PAUSE_KEY, String(Date.now() + 6 * 36e5)); } catch { /* yok say */ }
    console.warn('[publicRefs] yayınlanamadı (kural yayınlandı mı?):', err?.code || err);
    return { written: 0, skipped: String(err?.code || 'error') };
  } finally {
    running = false;
  }
}
