import React, { useEffect } from 'react';
import { CheckCircle2, FileEdit, Home, RotateCcw, ListChecks, Eye, ArrowRight, Layers } from 'lucide-react';
import { moduleActionLabel } from '../../utils/refLifecycle';
import { getStatusConfig } from '../../utils/statusStyles';

/**
 * v3.4 (Madde 2) — Kayıt sonrası başarı ekranı.
 * "Tamam / Kaydet" veya "Taslak kaydet" sonrası gösterilir; kullanıcı nereye döneceğini seçer:
 *   • Ana sayfa  • Aynı işlem sayfası (yeni kayıt)  • Referansı aç  • Referans listesi
 * 25 sn içinde seçim yapılmazsa ana sayfaya döner (isteğe bağlı otomatik dönüş).
 */
export interface SaveSuccessInfo {
  module: string;
  refId?: string;
  isDraft?: boolean;
  status?: string;
  summary?: string; // ör. "Gök Bulut · Elma · 5.000 kg"
}

interface Props {
  info: SaveSuccessInfo;
  onHome: () => void;
  onNewInModule: () => void;
  onContinueEditing?: () => void;
  onOpenReference?: () => void;
  onOpenReferences: () => void;
  autoHomeSeconds?: number;
  /** v4.0: toplu QR işlemi — sıradaki paleti aynı forma getirir */
  next?: { label: string; onNext: () => void };
  /** v4.0: toplu işlem bilgi satırı (ör. "Toplu işlem tamamlandı: 8/8") */
  queueNote?: string;
}

export const SaveSuccessScreen: React.FC<Props> = ({
  info, onHome, onNewInModule, onContinueEditing, onOpenReference, onOpenReferences, autoHomeSeconds = 0, next, queueNote,
}) => {
  const [left, setLeft] = React.useState(autoHomeSeconds);
  useEffect(() => {
    if (!autoHomeSeconds) return;
    const t = setInterval(() => setLeft(v => (v <= 1 ? 0 : v - 1)), 1000);
    return () => clearInterval(t);
  }, [autoHomeSeconds]);
  useEffect(() => { if (autoHomeSeconds && left === 0) onHome(); }, [left, autoHomeSeconds, onHome]);

  const draft = !!info.isDraft;
  const st = info.status ? getStatusConfig(info.status) : null;

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-xs p-0 sm:p-4" role="dialog" aria-modal="true" aria-labelledby="save-success-title">
      <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        <div className="flex flex-col items-center text-center">
          <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-3 ${draft ? 'bg-amber-100 dark:bg-amber-900/40' : 'bg-emerald-100 dark:bg-emerald-900/40'}`}>
            {draft ? <FileEdit className="w-7 h-7 text-amber-600" /> : <CheckCircle2 className="w-8 h-8 text-emerald-600" />}
          </div>
          <h2 id="save-success-title" className="text-lg font-black text-slate-900 dark:text-white">
            {draft ? 'Taslak kaydedildi' : 'Kayıt başarılı'}
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            {moduleActionLabel(info.module)}
            {info.refId && <> · <span className="font-mono font-bold">{info.refId}</span></>}
          </p>
          {info.summary && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{info.summary}</p>}
          {st && !draft && (
            <span className={`mt-2 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${st.badgeClass}`}>
              Durum: {st.label}
            </span>
          )}
          {draft && (
            <p className="mt-2 text-[11px] text-amber-700 dark:text-amber-300">Taslak stok ve sevkiyat hesaplarına kesinleşmiş olarak girmez; tamamlamak için tekrar açın.</p>
          )}
        </div>

        {queueNote && (
          <div className="mt-3 flex items-center justify-center gap-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 text-xs font-bold py-2">
            <Layers className="w-4 h-4" /> {queueNote}
          </div>
        )}
        {next && (
          <button type="button" onClick={next.onNext} autoFocus className="mt-3 w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black py-3.5 text-sm cursor-pointer">
            {next.label} <ArrowRight className="w-4 h-4" />
          </button>
        )}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button type="button" onClick={onHome} className="col-span-2 flex items-center justify-center gap-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 text-sm cursor-pointer">
            <Home className="w-4 h-4" /> Ana sayfa{autoHomeSeconds ? ` (${left})` : ''}
          </button>
          {draft && onContinueEditing ? (
            <button type="button" onClick={onContinueEditing} className="flex items-center justify-center gap-1.5 rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 font-bold py-2.5 text-xs cursor-pointer">
              <FileEdit className="w-4 h-4" /> Taslağa devam
            </button>
          ) : (
            <button type="button" onClick={onNewInModule} className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold py-2.5 text-xs cursor-pointer">
              <RotateCcw className="w-4 h-4" /> İşlem sayfası (yeni)
            </button>
          )}
          {onOpenReference && info.refId ? (
            <button type="button" onClick={onOpenReference} className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold py-2.5 text-xs cursor-pointer">
              <Eye className="w-4 h-4" /> Referansı aç
            </button>
          ) : (
            <button type="button" onClick={onOpenReferences} className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold py-2.5 text-xs cursor-pointer">
              <ListChecks className="w-4 h-4" /> Referanslar
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
