import React from 'react';
import {
  Home, ListChecks, AlertTriangle, Leaf, Snowflake, Warehouse, Truck, FlaskConical, Globe2,
  ShieldAlert, BarChart3, Clock, LayoutGrid,
} from 'lucide-react';
import type { StageKey } from '../../config/processStages';

/**
 * v3.7 — Masaüstü yan menü (lg ve üstü). Tasarım önerisi "Masaüstü · Ana panel".
 * Gruplar: Genel · Süreç (1–4, aşama renkleriyle) · Kalite · Analiz.
 * Mobilde gizlidir; mobilde alt menü kullanılır.
 */
interface Props {
  activeView: string;
  onNavigate: (view: string) => void;
  alertCount?: number;
  stageBadges?: Partial<Record<StageKey, number>>;
}

type Item = { view: string; label: string; icon: React.ReactNode; badge?: number; match?: string[] };

const STAGE_ITEMS: { key: StageKey; no: number; view: string; label: string; icon: React.ReactNode; on: string; soft: string; match: string[] }[] = [
  { key: 'HASAT', no: 1, view: 'HARVEST', label: 'Hasat', icon: <Leaf className="w-4 h-4" />, on: 'bg-emerald-600 text-white', soft: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300', match: ['HARVEST'] },
  { key: 'ON_SOGUTMA', no: 2, view: 'PRECOOLING', label: 'Ön soğutma', icon: <Snowflake className="w-4 h-4" />, on: 'bg-sky-600 text-white', soft: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300', match: ['PRECOOLING'] },
  { key: 'SOGUK_DEPO', no: 3, view: 'COLD_STORAGE', label: 'Soğuk depo', icon: <Warehouse className="w-4 h-4" />, on: 'bg-indigo-600 text-white', soft: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300', match: ['COLD_STORAGE', 'AMBAR'] },
  { key: 'SEVK', no: 4, view: 'TRANSIT', label: 'Sevk', icon: <Truck className="w-4 h-4" />, on: 'bg-amber-600 text-white', soft: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', match: ['TRANSIT', 'LOJISTIK'] },
];

export default function AppSidebar({ activeView, onNavigate, alertCount = 0, stageBadges = {} }: Props) {
  const general: Item[] = [
    { view: 'DASHBOARD', label: 'Ana panel', icon: <Home className="w-4 h-4" /> },
    { view: 'REFERENCES', label: 'Referanslar', icon: <ListChecks className="w-4 h-4" /> },
    { view: 'ALERTS', label: 'Uyarılar', icon: <AlertTriangle className="w-4 h-4" />, badge: alertCount },
  ];
  const quality: Item[] = [
    { view: 'FIELD', label: 'Saha testleri', icon: <FlaskConical className="w-4 h-4" /> },
    { view: 'EXPORT_SAMPLE', label: 'İhracat numunesi', icon: <Globe2 className="w-4 h-4" /> },
    { view: 'INCIDENT', label: 'Incident / akt', icon: <ShieldAlert className="w-4 h-4" /> },
  ];
  const analysis: Item[] = [
    { view: 'REPORT_CENTER', label: 'Rapor merkezi', icon: <BarChart3 className="w-4 h-4" /> },
    { view: 'PENDING', label: 'Bekleyen işlemler', icon: <Clock className="w-4 h-4" /> },
    { view: 'PORTAL_LAUNCHER', label: 'Portallar', icon: <LayoutGrid className="w-4 h-4" /> },
  ];

  const group = (title: string) => (
    <div className="px-2.5 pt-4 pb-1.5 text-[10px] font-black tracking-[0.1em] text-slate-500 dark:text-slate-400">{title}</div>
  );
  const item = (it: Item) => {
    const on = activeView === it.view || (it.match || []).includes(activeView);
    return (
      <button key={it.view} type="button" onClick={() => onNavigate(it.view)} aria-current={on ? 'page' : undefined}
        className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm text-left cursor-pointer transition min-h-[40px] ${on ? 'bg-teal-50 text-slate-900 font-bold dark:bg-teal-950/40 dark:text-white' : 'text-slate-700 hover:bg-slate-50 font-medium dark:text-slate-300 dark:hover:bg-slate-800/60'}`}>
        <span className={on ? 'text-teal-700 dark:text-teal-300' : 'text-slate-500 dark:text-slate-400'}>{it.icon}</span>
        <span className="truncate">{it.label}</span>
        {!!it.badge && <span className="ml-auto min-w-5 h-5 px-1.5 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center">{it.badge}</span>}
      </button>
    );
  };

  return (
    <aside aria-label="Ana menü"
      className="hidden lg:flex flex-col w-60 shrink-0 sticky top-0 self-start max-h-screen overflow-y-auto border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-2.5 py-3 print:hidden">
      {group('GENEL')}
      {general.map(item)}
      {group('SÜREÇ')}
      {STAGE_ITEMS.map(s => {
        const on = s.match.includes(activeView);
        const badge = stageBadges[s.key];
        return (
          <button key={s.key} type="button" onClick={() => onNavigate(s.view)} aria-current={on ? 'page' : undefined}
            className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-sm text-left cursor-pointer transition min-h-[40px] ${on ? 'bg-slate-100 dark:bg-slate-800 font-bold text-slate-900 dark:text-white' : 'text-slate-700 hover:bg-slate-50 font-medium dark:text-slate-300 dark:hover:bg-slate-800/60'}`}>
            <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${on ? s.on : s.soft}`}>{s.icon}</span>
            <span className="text-[11px] font-black text-slate-500">{s.no}</span>
            <span className="truncate">{s.label}</span>
            {!!badge && <span className="ml-auto min-w-5 h-5 px-1.5 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center">{badge}</span>}
          </button>
        );
      })}
      {group('KALİTE')}
      {quality.map(item)}
      {group('ANALİZ')}
      {analysis.map(item)}
    </aside>
  );
}
