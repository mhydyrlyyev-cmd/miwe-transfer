import React from 'react';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord, BalanceAdjustment } from '../../types';
import ColdChainPanel from '../coldchain/ColdChainPanel';
import { PageHeader } from '../ui';

/**
 * v3.7 — Tüm uyarılar tek sayfada (ana panel "Tümü" ve mobil alt menü "Uyarılar").
 * Her uyarı kendi aşama etiketini taşır; ayrıntılı işlem kendi aşama sayfasında yapılır.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  currentUserName: string;
  isReadOnly?: boolean;
  onOpenRecord: (refId: string) => void;
  onOpenPrecooling: (ref: ReferenceItem) => void;
  onAddBalanceAdjustment?: (refId: string, adj: BalanceAdjustment) => Promise<boolean | void>;
  onBack: () => void;
}

export default function AlertsView(p: Props) {
  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader onBack={p.onBack} title="Uyarılar" subtitle="Tüm aşamaların uyarıları; en acil olan üstte. Etiket, uyarının hangi aşamaya ait olduğunu gösterir." />
      <ColdChainPanel
        references={p.references} harvestRecords={p.harvestRecords} ambarRecords={p.ambarRecords}
        lojistikRecords={p.lojistikRecords} salesRecords={p.salesRecords}
        currentUserName={p.currentUserName} isReadOnly={p.isReadOnly}
        onOpenRecord={p.onOpenRecord} onOpenPrecooling={p.onOpenPrecooling}
        onAddBalanceAdjustment={p.onAddBalanceAdjustment}
      />
    </div>
  );
}
