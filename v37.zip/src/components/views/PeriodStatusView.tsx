import React, { useMemo, useState } from 'react';
import { Printer, ChevronDown, AlertTriangle, Download } from 'lucide-react';
import { computePeriodReport, computeOrchardRows, computeColdStatus, computeMassBalance, computeColdChainDeviations, computeStorageAging, computeTrace, toCsv, periodRange, baseProduct, type PeriodKey, type Item, type ReportInput } from '../../utils/periodReport';
import { INSPECTION_CLASSES } from '../../config/inspection';
import { Badge, Button, Card, PageHeader, Tabs } from '../ui';
import ColdChainReport from '../reports/ColdChainReport';

/**
 * v2.9 — Haftalık / aylık durum: hareketler, depo durumu, kalite, eksik kayıtlar.
 * Her sayının altında onu oluşturan kayıtlar açılabilir; RefID'ye dokununca parti zinciri açılır.
 * Fiyat / gelir bu raporda yoktur.
 */
export type ReportTab = 'status' | 'orchards' | 'cold' | 'quality' | 'targets' | 'trace' | 'official';

interface Props extends ReportInput {
  onOpenRef: (refId: string) => void;
  onBack: () => void;
  /** v3.2 Rapor Merkezi: açılış sekmesi */
  initialTab?: ReportTab;
  /** Hedefler / KPI sekmesinin içeriği (Özet ekranı, gömülü) */
  targetsNode?: React.ReactNode;
  /** Resmi aylık yönetim raporunu (PDF) açar */
  onOpenMonthlyReport?: () => void;
  /** v3.3 izlenebilirlik testi sonucunu partinin kaydına yazar */
  onSaveTraceTest?: (refId: string, test: import('../../types').TraceTest) => Promise<boolean | void>;
  currentUserName?: string;
}

const fmtKg = (v?: number | null) => (v == null ? '—' : `${Math.round(v).toLocaleString('tr-TR')} kg`);
const fmtNum = (v?: number | null, d = 1) => (v == null ? '—' : v.toLocaleString('tr-TR', { maximumFractionDigits: d }));
const delta = (cur: number, prev: number) => {
  if (!prev && !cur) return null;
  if (!prev) return 'önceki dönemde yok';
  const p = ((cur - prev) / prev) * 100;
  return `önceki: ${Math.round(prev).toLocaleString('tr-TR')} (${p >= 0 ? '+' : ''}${p.toFixed(0)}%)`;
};

function ItemList({ items, onOpenRef }: { items: Item[]; onOpenRef: (id: string) => void }) {
  if (!items.length) return <p className="text-xs text-slate-500">Kayıt yok.</p>;
  return (
    <ul className="divide-y divide-slate-100 dark:divide-slate-800">
      {items.slice(0, 50).map((it, k) => (
        <li key={k} className="py-1.5 flex items-center justify-between gap-2 text-xs">
          <button type="button" onClick={() => onOpenRef(it.refId)} className="font-mono font-semibold text-teal-800 dark:text-teal-300 underline-offset-2 hover:underline min-h-[32px] text-left">{it.refId}</button>
          <span className="text-slate-600 dark:text-slate-400 text-right">{it.date}{it.kg != null ? ` · ${fmtKg(it.kg)}` : ''}{it.note ? ` · ${it.note}` : ''}</span>
        </li>
      ))}
      {items.length > 50 && <li className="py-1.5 text-xs text-slate-500">+{items.length - 50} kayıt daha</li>}
    </ul>
  );
}

function Stat({ label, value, sub, items, onOpenRef }: { label: string; value: string; sub?: string | null; items: Item[]; onOpenRef: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-3">
      <div className="text-xs text-slate-600 dark:text-slate-400">{label}</div>
      <div className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open}
        className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-teal-800 dark:text-teal-300 min-h-[32px] print:hidden">
        {items.length} kayıt <ChevronDown className={`w-3 h-3 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="mt-1"><ItemList items={items} onOpenRef={onOpenRef} /></div>}
    </div>
  );
}

export default function PeriodStatusView({ onOpenRef, onBack, initialTab = 'status', targetsNode, onOpenMonthlyReport, onSaveTraceTest, currentUserName = '', ...input }: Props) {
  const [tab, setTab] = useState<ReportTab>(initialTab);
  const [period, setPeriod] = useState<PeriodKey>('THIS_WEEK');
  const [product, setProduct] = useState('ALL');
  const ranges = useMemo(() => periodRange(period), [period]);
  const products = useMemo(() => {
    const s = new Set<string>();
    input.references.forEach(r => { const b = baseProduct(r.product); if (b) s.add(b); });
    input.fieldRecords.forEach(f => { const b = baseProduct(f.product); if (b) s.add(b); });
    return [...s].sort((a, b) => a.localeCompare(b, 'tr'));
  }, [input.references, input.fieldRecords]);
  const cur = useMemo(() => computePeriodReport(input, ranges.current, product), [input, ranges, product]);
  const prev = useMemo(() => computePeriodReport(input, ranges.previous, product), [input, ranges, product]);
  // v3.0: bahçe bazında satırlar (dönem) ve soğuk depo durumu (şu an)
  const orchards = useMemo(() => computeOrchardRows(input, ranges.current, product), [input, ranges, product]);
  const cold = useMemo(() => computeColdStatus(input, product), [input, product]);
  // v3.3 yeni raporlar
  const balance = useMemo(() => computeMassBalance(input, ranges.current, product), [input, ranges, product]);
  const chain = useMemo(() => computeColdChainDeviations(input, ranges.current, product), [input, ranges, product]);
  const aging = useMemo(() => computeStorageAging(input, product), [input, product]);
  // İzlenebilirlik testi
  const [traceRef, setTraceRef] = useState('');
  const [traceStart, setTraceStart] = useState<string | null>(null);
  const [traceSaved, setTraceSaved] = useState<string | null>(null);
  const trace = useMemo(() => (traceRef && input.references.some(r => r.refId === traceRef) ? computeTrace(input, traceRef) : null), [input, traceRef]);
  const [openOrchard, setOpenOrchard] = useState<string | null>(null);
  const [openCold, setOpenCold] = useState<number | null>(null);
  const hasBanana = orchards.some(o => o.ribbons.length > 0) || cold.some(c => c.banana);
  const pct = (v: number | null) => (v == null ? '—' : v.toLocaleString('tr-TR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }));

  const exportExcel = () => {
    const rows: (string | number | null)[][] = [];
    rows.push([`Miwe Hil — Haftalık / Aylık Durum`, ranges.current.label, product === 'ALL' ? 'Tüm ürünler' : product]);
    rows.push([]);
    rows.push(['HAREKETLER', 'kg', 'açıklama']);
    rows.push(['Hasat', Math.round(cur.harvest.kg), `${cur.harvest.days} gün · ${cur.harvest.workers} kişi-gün · ${cur.harvest.unweighedDays} gün tartılmadı`]);
    rows.push(['Şoklanan', Math.round(cur.precooling.netKg), `${cur.precooling.slips} fiş`]);
    rows.push(['Depoya giriş', Math.round(cur.depotIn.kg), `dış alım ${Math.round(cur.depotIn.externalKg)} kg`]);
    rows.push(['Çıkış (sevk + satış)', Math.round(cur.out.kg), `sevk ${Math.round(cur.out.shipKg)} · satış ${Math.round(cur.out.saleKg)}`]);
    rows.push(['Fire hasat → şoklama %', cur.fire ? cur.fire.pct : null, cur.fire ? `${Math.round(cur.fire.lossKg)} kg` : '']);
    rows.push([]);
    rows.push(['BAHÇE BAZINDA', 'Ürün', 'Hasat kg', 'Kişi-gün', 'kg / kişi-gün', 'Şoklanan kg', 'Fire %', 'Pack-out %', ...INSPECTION_CLASSES.map(c => `${c} %`), 'Depoda kg', 'Kurdele', 'Hasat haftası']);
    orchards.forEach(o => rows.push([o.orchard, o.products.join(', '), Math.round(o.harvestKg), o.workers, o.kgPerWorkerDay, Math.round(o.shockKg), o.firePct, o.packOutPct, ...o.quality.map(q => q.pct), Math.round(o.stockKg), o.ribbons.join(', '), o.weeks.join(', ')]));
    rows.push([]);
    rows.push(['KÜTLE DENGESİ', 'Açılış', 'Giriş kendi', 'Giriş dış', 'Sevk', 'Satış', 'Kapanış', 'Fark', 'Fark %']);
    balance.rows.forEach(b => rows.push([b.product, Math.round(b.opening), Math.round(b.inOwn), Math.round(b.inExternal), Math.round(b.outShip), Math.round(b.outSale), Math.round(b.closing), Math.round(b.diff), b.diffPct]));
    balance.flags.forEach(f => rows.push(['Düzeltilecek kayıt', f.refId, f.date, f.kg != null ? Math.round(f.kg) : null, f.note || '']));
    rows.push([]);
    rows.push(['SOĞUK ZİNCİR SAPMALARI', 'Tarih', 'Parti', 'Açıklama']);
    chain.deviations.forEach(d => rows.push([d.kind, d.date, d.refId, d.text]));
    rows.push([]);
    rows.push(['ÖNCE ÇIKACAKLAR', 'Ürün', 'Bahçe', 'Oda', 'Gün', 'Kalan kg', 'Sertlik', 'Sertlik değişimi', 'Brix']);
    aging.forEach(a => rows.push([a.refId, a.product, a.orchard, a.rooms, a.days, Math.round(a.remainingKg), a.firmness ?? null, a.firmnessDelta ?? null, a.brix ?? null]));
    rows.push([]);
    rows.push(['SOĞUK DEPO DURUMU (şu an)', 'Bahçe', 'Ürün', 'Görünüş', 'Durum', 'Miktar kg', 'Partiler', 'Muz: sera · kurdele · hafta']);
    cold.forEach(c => rows.push([c.room, c.orchard, c.product, c.appearance, c.status, Math.round(c.kg), c.refIds.join(', '), c.banana || '']));
    const blob = new Blob([toCsv(rows)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `miwe-durum-${ranges.current.start}_${ranges.current.end}${product === 'ALL' ? '' : '-' + product}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <PageHeader
        onBack={onBack}
        title="Rapor Merkezi"
        subtitle={tab === 'trace' ? 'İzlenebilirlik testi (geri çağırma tatbikatı)' : tab === 'targets' || tab === 'official' ? 'Hedefler ve resmi rapor' : tab === 'cold' ? 'Şu anki durum' : ranges.current.label}
        actions={<div className="flex gap-2 print:hidden">
          <Button variant="soft" tone="emerald" size="sm" icon={<Download />} onClick={exportExcel}>Excel'e aktar</Button>
          <Button variant="soft" tone="slate" size="sm" icon={<Printer />} onClick={() => window.print()}>Yazdır</Button>
        </div>}
      />

      <div className="overflow-x-auto -mx-3 px-3 print:hidden">
        <Tabs ariaLabel="Rapor bölümü" variant="underline" value={tab} onChange={(k) => setTab(k as ReportTab)}
          items={[{ key: 'status', label: 'Durum' }, { key: 'orchards', label: 'Bahçeler' }, { key: 'cold', label: 'Soğuk zincir' }, { key: 'quality', label: 'Kalite' }, { key: 'targets', label: 'Hedefler' }, { key: 'trace', label: 'İzlenebilirlik' }, { key: 'official', label: 'Resmi rapor' }]} />
      </div>

      {(tab !== 'targets' && tab !== 'official' && tab !== 'trace') && <div className="space-y-2 print:hidden">
        {tab !== 'cold' && <Tabs ariaLabel="Dönem" fullWidth value={period} onChange={(k) => setPeriod(k as PeriodKey)}
          items={[{ key: 'THIS_WEEK', label: 'Bu hafta' }, { key: 'LAST_WEEK', label: 'Geçen hafta' }, { key: 'THIS_MONTH', label: 'Bu ay' }, { key: 'LAST_MONTH', label: 'Geçen ay' }]} />}
        <select value={product} onChange={e => setProduct(e.target.value)} aria-label="Ürün"
          className="w-full sm:w-72 min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100">
          <option value="ALL">Tüm ürünler</option>
          {products.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>}

      {tab === 'status' && cur.warnings.length > 0 && (
        <Card title="Eksik kayıtlar" subtitle="Bugün itibarıyla tamamlanması gerekenler" actions={<AlertTriangle className="w-4 h-4 text-amber-600" />}>
          <div className="space-y-3">
            {cur.warnings.map(w => (
              <details key={w.key} className="group">
                <summary className="cursor-pointer text-sm text-slate-800 dark:text-slate-200 min-h-[36px] flex items-center justify-between gap-2">
                  <span>{w.text}</span><Badge tone="warn">{w.items.length}</Badge>
                </summary>
                <div className="mt-1"><ItemList items={w.items} onOpenRef={onOpenRef} /></div>
              </details>
            ))}
          </div>
        </Card>
      )}

      {tab === 'status' && <Card title="Hareketler" subtitle={`${ranges.current.start} – ${ranges.current.end}`}>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5">
          <Stat label="Hasat" value={fmtKg(cur.harvest.kg)}
            sub={`${cur.harvest.days} gün · ${cur.harvest.lots} parti · ${cur.harvest.workers} kişi-gün${cur.harvest.unweighedDays ? ` · ${cur.harvest.unweighedDays} gün tartılmadı` : ''}`}
            items={cur.harvest.items} onOpenRef={onOpenRef} />
          <Stat label="Şoklanan (ön soğutma)" value={fmtKg(cur.precooling.netKg)}
            sub={`${cur.precooling.slips} fiş · %5 inspeksiyon ${cur.precooling.fivePercent} · sorting ${cur.precooling.sorting}${delta(cur.precooling.netKg, prev.precooling.netKg) ? ` · ${delta(cur.precooling.netKg, prev.precooling.netKg)}` : ''}`}
            items={cur.precooling.items} onOpenRef={onOpenRef} />
          <Stat label="Depoya giriş" value={fmtKg(cur.depotIn.kg)}
            sub={`${cur.depotIn.records} kabul${cur.depotIn.externalKg ? ` · dış alım ${fmtKg(cur.depotIn.externalKg)}` : ''}`}
            items={cur.depotIn.items} onOpenRef={onOpenRef} />
          <Stat label="Çıkış (sevk + satış)" value={fmtKg(cur.out.kg)}
            sub={`sevk ${fmtKg(cur.out.shipKg)} · satış ${fmtKg(cur.out.saleKg)}${delta(cur.out.kg, prev.out.kg) ? ` · ${delta(cur.out.kg, prev.out.kg)}` : ''}`}
            items={cur.out.items} onOpenRef={onOpenRef} />
          <Stat label="Fire (hasat → şoklama)" value={cur.fire ? `%${fmtNum(cur.fire.pct, 2)}` : '—'}
            sub={cur.fire ? `${fmtKg(cur.fire.lossKg)} · yalnızca hasatta ayrıca tartılan günler` : 'Hasatta ayrıca tartılmış gün yok'}
            items={cur.fire?.items || []} onOpenRef={onOpenRef} />
        </div>
        <p className="text-[11px] text-slate-500 mt-2">Hasat sayısında "önceki dönem" karşılaştırması: {delta(cur.harvest.kg, prev.harvest.kg) || '—'}</p>
      </Card>}

      {tab === 'status' && <Card title="Kütle dengesi" subtitle="Açılış + giriş = çıkış + kapanış (depo düzeyinde, kg)">
        {balance.rows.length ? (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[620px]">
              <thead><tr className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                <th className="py-1.5 px-1">Ürün</th><th className="py-1.5 px-1 text-right">Açılış</th><th className="py-1.5 px-1 text-right">Giriş (kendi)</th><th className="py-1.5 px-1 text-right">Giriş (dış)</th>
                <th className="py-1.5 px-1 text-right">Sevk</th><th className="py-1.5 px-1 text-right">Satış</th><th className="py-1.5 px-1 text-right">Kapanış</th><th className="py-1.5 px-1 text-right">Fark</th>
              </tr></thead>
              <tbody>{balance.rows.map(b => (
                <tr key={b.product} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="py-1.5 px-1 font-semibold">{b.product}</td>
                  {[b.opening, b.inOwn, b.inExternal, b.outShip, b.outSale, b.closing].map((v, k) => <td key={k} className="py-1.5 px-1 text-right tabular-nums">{v ? Math.round(v).toLocaleString('tr-TR') : '—'}</td>)}
                  <td className={`py-1.5 px-1 text-right tabular-nums font-semibold ${Math.abs(b.diff) > 0.5 ? 'text-rose-700 dark:text-rose-300' : 'text-emerald-700 dark:text-emerald-300'}`}>
                    {Math.abs(b.diff) > 0.5 ? `${Math.round(b.diff).toLocaleString('tr-TR')}${b.diffPct != null ? ` (%${b.diffPct.toLocaleString('tr-TR')})` : ''}` : 'denk'}
                  </td>
                </tr>))}
              </tbody>
            </table>
          </div>
        ) : <p className="text-sm text-slate-500">Bu dönemde depo hareketi yok.</p>}
        <div className="mt-3 text-xs text-slate-700 dark:text-slate-300 space-y-0.5">
          <p className="font-semibold">Kendi üretimimizin aşamaları (bu dönem)</p>
          <p>Hasat {fmtKg(balance.stages.harvestKg)} → şoklanan {fmtKg(balance.stages.shockKg)} → depoya giren {fmtKg(balance.stages.depotOwnKg)}{balance.stages.notInDepotKg ? ` · henüz depoya girmeyen ${fmtKg(balance.stages.notInDepotKg)}` : ''}</p>
        </div>
        {balance.flags.length > 0 && (
          <div className="mt-3 rounded-xl border border-rose-200 bg-rose-50 dark:bg-rose-950/30 dark:border-rose-900 p-2.5">
            <p className="text-xs font-semibold text-rose-800 dark:text-rose-200 mb-1">Düzeltilmesi gereken kayıtlar ({balance.flags.length})</p>
            <ItemList items={balance.flags} onOpenRef={onOpenRef} />
          </div>
        )}
        <p className="text-[11px] text-slate-500 mt-2">Stok kayıtlardan hesaplandığı için fark yalnızca kayıt tutarsızlığında oluşur: girişten fazla çıkış veya depo girişi olmadan satış.</p>
      </Card>}

      {tab === 'orchards' && <Card title="Bahçe bazında" subtitle={product === 'ALL' ? 'Her bahçe ayrı; kalite yüzdeleri o bahçenin %5 inspeksiyonlarından' : `Yalnızca ${product} yetişen bahçeler; yüzdeler yalnızca ${product} için`}>
        {orchards.length ? (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[760px]">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <th className="py-1.5 px-1">Bahçe</th><th className="py-1.5 px-1">Ürün</th><th className="py-1.5 px-1 text-right">Hasat kg</th>
                  <th className="py-1.5 px-1 text-right">Kişi-gün</th><th className="py-1.5 px-1 text-right">kg / kişi-gün</th><th className="py-1.5 px-1 text-right">Şoklanan kg</th><th className="py-1.5 px-1 text-right">Fire %</th><th className="py-1.5 px-1 text-right">Pack-out %</th>
                  {INSPECTION_CLASSES.map(c => <th key={c} className="py-1.5 px-1 text-right">{c} %</th>)}
                  <th className="py-1.5 px-1 text-right">Depoda kg</th>
                  {hasBanana && <th className="py-1.5 px-1">Kurdele / hafta</th>}
                </tr>
              </thead>
              <tbody>
                {orchards.map(o => (
                  <React.Fragment key={o.orchard}>
                    <tr className="border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50" onClick={() => setOpenOrchard(v => v === o.orchard ? null : o.orchard)} aria-expanded={openOrchard === o.orchard}>
                      <td className="py-1.5 px-1 font-semibold">{o.orchard}</td>
                      <td className="py-1.5 px-1">{o.products.join(', ')}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.harvestKg ? Math.round(o.harvestKg).toLocaleString('tr-TR') : (o.unweighedDays ? 'tartılmadı' : '—')}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.workers || '—'}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums font-semibold">{o.kgPerWorkerDay != null ? o.kgPerWorkerDay.toLocaleString('tr-TR') : '—'}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.shockKg ? Math.round(o.shockKg).toLocaleString('tr-TR') : '—'}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{pct(o.firePct)}</td>
                      <td className="py-1.5 px-1 text-right tabular-nums">{pct(o.packOutPct)}</td>
                      {o.quality.map(q => <td key={q.cls} className="py-1.5 px-1 text-right tabular-nums">{q.kg ? pct(q.pct) : '—'}</td>)}
                      <td className="py-1.5 px-1 text-right tabular-nums">{o.stockKg ? Math.round(o.stockKg).toLocaleString('tr-TR') : '—'}</td>
                      {hasBanana && <td className="py-1.5 px-1">{[o.ribbons.join(', '), o.weeks.length ? `${o.weeks.join(', ')}. hafta` : ''].filter(Boolean).join(' · ') || '—'}</td>}
                    </tr>
                    {openOrchard === o.orchard && (
                      <tr><td colSpan={10 + INSPECTION_CLASSES.length + (hasBanana ? 1 : 0)} className="py-1.5 px-1">
                        <div className="flex flex-wrap gap-1.5">{o.refIds.map(id => (
                          <button key={id} type="button" onClick={() => onOpenRef(id)} className="font-mono text-[11px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 rounded-full px-2 min-h-[28px]">{id}</button>
                        ))}</div>
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="text-sm text-slate-500">Bu dönemde bahçe kaydı yok.</p>}
        <p className="text-[11px] text-slate-500 mt-2">Kişi-gün: günlük hasat kayıtlarındaki kişi sayılarının toplamı. kg / kişi-gün yalnızca hem kg hem kişi sayısı girilmiş günlerden hesaplanır. Pack-out: ön soğutma fişindeki paketlenen / (paketlenen + ıskarta). Satıra dokununca partiler açılır.</p>
      </Card>}

      {/* v3.7: soğuk zincir grafikleri (kütle dengesi, ıskarta, hasat→ön soğutma, durum dağılımı) */}
      {tab === 'cold' && <ColdChainReport references={input.references} harvestRecords={input.harvestRecords} ambarRecords={input.ambarRecords} lojistikRecords={input.lojistikRecords} salesRecords={input.salesRecords} />}

      {tab === 'cold' && <Card title="Soğuk Depo Durumu" subtitle="Şu an: hangi bahçenin ürünü hangi odada, hangi görünüşte, ne durumda">
        {cold.length ? (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[640px]">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <th className="py-1.5 px-1">Oda</th><th className="py-1.5 px-1">Bahçe</th><th className="py-1.5 px-1">Ürün</th><th className="py-1.5 px-1">Görünüş</th>
                  <th className="py-1.5 px-1">Durum</th><th className="py-1.5 px-1 text-right">Miktar kg</th>{hasBanana && <th className="py-1.5 px-1">Sera / kurdele / hafta</th>}
                </tr>
              </thead>
              <tbody>
                {cold.map((c, k) => (
                  <React.Fragment key={k}>
                    <tr className="border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50" onClick={() => setOpenCold(v => v === k ? null : k)} aria-expanded={openCold === k}>
                      <td className="py-1.5 px-1 font-semibold">{c.room}</td><td className="py-1.5 px-1">{c.orchard}</td><td className="py-1.5 px-1">{c.product}</td>
                      <td className="py-1.5 px-1">{c.appearance}</td>
                      <td className="py-1.5 px-1"><Badge tone={/Sevke hazır/.test(c.status) ? 'ok' : /soğut|Şokla/i.test(c.status) ? 'info' : 'neutral'}>{c.status}</Badge></td>
                      <td className="py-1.5 px-1 text-right tabular-nums font-semibold">{Math.round(c.kg).toLocaleString('tr-TR')}</td>
                      {hasBanana && <td className="py-1.5 px-1">{c.banana || '—'}</td>}
                    </tr>
                    {openCold === k && (
                      <tr><td colSpan={hasBanana ? 7 : 6} className="py-1.5 px-1">
                        <div className="flex flex-wrap gap-1.5">{c.refIds.map(id => (
                          <button key={id} type="button" onClick={() => onOpenRef(id)} className="font-mono text-[11px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 rounded-full px-2 min-h-[28px]">{id}</button>
                        ))}</div>
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
                <tr><td colSpan={5} className="py-1.5 px-1 font-semibold">Toplam</td><td className="py-1.5 px-1 text-right tabular-nums font-bold">{Math.round(cold.reduce((a, c) => a + c.kg, 0)).toLocaleString('tr-TR')}</td>{hasBanana && <td />}</tr>
              </tbody>
            </table>
          </div>
        ) : <p className="text-sm text-slate-500">Şu an depoda veya ön soğutmada parti yok.</p>}
        <p className="text-[11px] text-slate-500 mt-2">Durum, Soğuk Depo ekranından her parti için seçilir. Görünüş, depo kabulde seçilir; aynı parti farklı görünüşte farklı odalara ayrı kabul kaydıyla konabilir.</p>
      </Card>}

      {tab === 'cold' && <Card title="Önce çıkacaklar (depo yaşlanması)" subtitle="Sertliği en çok düşen ve en uzun bekleyen partiler üstte">
        {aging.length ? (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {aging.slice(0, 30).map(a => (
              <li key={a.refId} className="py-2 flex items-start justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <button type="button" onClick={() => onOpenRef(a.refId)} className="font-mono font-semibold text-teal-800 dark:text-teal-300 hover:underline min-h-[28px]">{a.refId}</button>
                  <div className="text-slate-600 dark:text-slate-400 truncate">{a.product} · {a.orchard} · {a.rooms}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-semibold">{a.days} gün · {fmtKg(a.remainingKg)}</div>
                  <div className="text-slate-600 dark:text-slate-400">{a.firmness != null ? `sertlik ${a.firmness}${a.firmnessDelta != null ? ` (${a.firmnessDelta > 0 ? '+' : ''}${a.firmnessDelta})` : ''}` : 'kontrol yok'}{a.brix != null ? ` · Brix ${a.brix}` : ''}</div>
                </div>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-slate-500">Depoda bekleyen parti yok.</p>}
      </Card>}

      {tab === 'status' && <Card title="Depo durumu" subtitle={`${ranges.current.end} sonu itibarıyla depoda kalan`}>
        <div className="text-2xl font-bold tabular-nums">{fmtKg(cur.stock.totalKg)}</div>
        {cur.stock.byProduct.length > 0 ? (
          <div className="grid sm:grid-cols-2 gap-3 mt-3">
            <div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Ürüne göre</p>
              <ul className="text-sm space-y-0.5">{cur.stock.byProduct.map(p => <li key={p.product} className="flex justify-between"><span>{p.product}</span><span className="tabular-nums font-semibold">{fmtKg(p.kg)}</span></li>)}</ul>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Depo / oda</p>
              <ul className="text-sm space-y-0.5">{cur.stock.byRoom.map(r => <li key={r.place} className="flex justify-between gap-2"><span className="truncate">{r.place}</span><span className="tabular-nums font-semibold whitespace-nowrap">{fmtKg(r.kg)} · {r.lots} parti</span></li>)}</ul>
            </div>
          </div>
        ) : <p className="text-sm text-slate-500 mt-1">Depoda kayıtlı parti yok.</p>}
        <details className="mt-2 print:hidden"><summary className="cursor-pointer text-xs font-semibold text-teal-800 dark:text-teal-300 min-h-[32px]">{cur.stock.items.length} parti</summary><ItemList items={cur.stock.items} onOpenRef={onOpenRef} /></details>
      </Card>}

      {tab === 'quality' && <Card title="Soğuk zincir sapmaları" subtitle={`${chain.evaluated} ölçüm değerlendirildi · ${chain.deviations.length} sapma`}>
        {chain.deviations.length ? (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {chain.deviations.slice(0, 50).map((d, k) => (
              <li key={k} className="py-1.5 flex items-start justify-between gap-2 text-xs">
                <span><Badge tone="warn">{d.kind}</Badge> <span className="text-slate-800 dark:text-slate-200">{d.text}</span></span>
                <button type="button" onClick={() => onOpenRef(d.refId)} className="font-mono text-teal-800 dark:text-teal-300 whitespace-nowrap min-h-[28px]">{d.date} · {d.refId}</button>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-slate-500">{chain.evaluated ? 'Sapma yok.' : 'Bu dönemde değerlendirilecek sıcaklık ölçümü yok.'}</p>}
        {chain.productsWithoutSpec.length > 0 && (
          <p className="text-[11px] text-slate-500 mt-2">Hedef aralığı tanımlı olmayan ürünler: {chain.productsWithoutSpec.join(', ')}. Bunlarda oda sıcaklığı, kontrolde girilen ayar sıcaklığına göre (±1 °C) değerlendirildi. Ürün hedefleri productSpecs.ts dosyasında kalite departmanınca girilir.</p>
        )}
      </Card>}

      {tab === 'quality' && <Card title="Kalite">
        <div className="space-y-4">
          <section>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">%5 inspeksiyon sınıf dağılımı (kg ağırlıklı)</p>
            {cur.inspectionSampleKg > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-xs text-slate-500 border-b border-slate-200 dark:border-slate-700"><th className="py-1 pr-2">Sınıf</th><th className="py-1 pr-2">Numune kg</th><th className="py-1">%</th></tr></thead>
                  <tbody>{cur.inspection.map(r => <tr key={r.cls} className="border-b border-slate-100 dark:border-slate-800"><td className="py-1 pr-2">{r.cls}</td><td className="py-1 pr-2 tabular-nums">{r.kg ? fmtNum(r.kg, 3) : '—'}</td><td className="py-1 tabular-nums">{r.pct != null && r.kg ? r.pct.toLocaleString('tr-TR', { minimumFractionDigits: 3, maximumFractionDigits: 3 }) : '—'}</td></tr>)}</tbody>
                </table>
              </div>
            ) : <p className="text-xs text-slate-500">Bu dönemde %5 inspeksiyon yok.</p>}
          </section>
          <section>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Testler (ürün bazında)</p>
            {cur.tests.length ? (
              <ul className="text-sm space-y-0.5">{cur.tests.map(t => <li key={t.product} className="flex justify-between gap-2"><span>{t.product} · {t.n} test</span><span className="tabular-nums text-slate-700 dark:text-slate-300">Brix {fmtNum(t.avgBrix, 2)} · sertlik {fmtNum(t.avgHardness, 2)}</span></li>)}</ul>
            ) : <p className="text-xs text-slate-500">Bu dönemde test yok.</p>}
          </section>
          <div className="grid grid-cols-2 gap-2.5">
            <Stat label="Depo kontrolleri" value={String(cur.checks.n)} items={cur.checks.items} onOpenRef={onOpenRef} />
            <Stat label="DÖF" value={`${cur.incidents.opened} yeni`} sub={`açık toplam: ${cur.incidents.openNow}`} items={cur.incidents.items} onOpenRef={onOpenRef} />
          </div>
        </div>
      </Card>}

      {tab === 'targets' && (targetsNode || <p className="text-sm text-slate-500">Hedef göstergeleri yüklenemedi.</p>)}

      {tab === 'trace' && (
        <Card title="İzlenebilirlik testi" subtitle="Bir parti seçin: kaynak → işlem/depo → alıcılar ve miktar mutabakatı">
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row gap-2">
              <input list="trace-refs" value={traceRef} onChange={e => { setTraceRef(e.target.value.trim()); setTraceSaved(null); }}
                placeholder="Parti numarası (HARV-…, AMB-…)" aria-label="Parti numarası"
                className="flex-1 min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm font-mono text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100" />
              <datalist id="trace-refs">{input.references.filter(r => r.refKind !== 'TEST').slice(0, 300).map(r => <option key={r.refId} value={r.refId}>{r.product}</option>)}</datalist>
              <Button variant="primary" disabled={!trace || !!traceStart} onClick={() => { setTraceStart(new Date().toISOString()); setTraceSaved(null); }}>Testi başlat</Button>
            </div>
            {traceStart && <p className="text-xs text-slate-600 dark:text-slate-400">Başlangıç: {new Date(traceStart).toLocaleTimeString('tr-TR')} — hedef: 4 saat içinde tamamlamak.</p>}
            {trace && (
              <div className="space-y-3">
                <p className="text-sm"><strong className="font-mono">{traceRef}</strong> · {trace.product} · {trace.orchard}</p>
                {[['Geri: kaynak (bahçe / tedarikçi, hasat, testler)', trace.back], ['İç: ön soğutma, depo', trace.inside], ['İleri: sevk ve satış (alıcılar)', trace.forward]].map(([title, items]) => (
                  <section key={title as string}><p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">{title as string}</p><ItemList items={items as Item[]} onOpenRef={onOpenRef} /></section>
                ))}
                <div className="rounded-xl border border-slate-200 dark:border-slate-700 p-3 text-sm grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div><span className="block text-xs text-slate-500">Giriş</span><strong>{fmtKg(trace.inKg)}</strong></div>
                  <div><span className="block text-xs text-slate-500">Çıkış</span><strong>{fmtKg(trace.outKg)}</strong></div>
                  <div><span className="block text-xs text-slate-500">Depoda kalan</span><strong>{fmtKg(trace.remainingKg)}</strong></div>
                  <div><span className="block text-xs text-slate-500">Mutabakat</span><strong className={trace.reconciliationPct != null && Math.abs(trace.reconciliationPct - 100) > 0.5 ? 'text-rose-700' : 'text-emerald-700'}>{trace.reconciliationPct != null ? `%${trace.reconciliationPct.toLocaleString('tr-TR')}` : '—'}</strong></div>
                </div>
                {trace.harvestKg > 0 && trace.inKg > 0 && trace.harvestKg !== trace.inKg && <p className="text-xs text-slate-600 dark:text-slate-400">Hasattan depoya kayıp: {fmtKg(trace.harvestKg - trace.inKg)} (%{(((trace.harvestKg - trace.inKg) / trace.harvestKg) * 100).toFixed(1)})</p>}
                {traceStart && onSaveTraceTest && (
                  <Button variant="primary" onClick={async () => {
                    const end = new Date();
                    const test = { id: `tt-${end.getTime()}`, startedAt: traceStart, finishedAt: end.toISOString(), durationMin: Math.max(1, Math.round((end.getTime() - new Date(traceStart).getTime()) / 60000)),
                      by: currentUserName || '—', inKg: trace.inKg, outKg: trace.outKg, remainingKg: trace.remainingKg, reconciliationPct: trace.reconciliationPct, customers: trace.customers };
                    const ok = await onSaveTraceTest(traceRef, test);
                    if (ok !== false) { setTraceSaved(`Kaydedildi · süre ${test.durationMin} dk`); setTraceStart(null); }
                  }}>Testi bitir ve kaydet</Button>
                )}
                {traceSaved && <p className="text-xs text-emerald-700">{traceSaved}</p>}
                {(trace.ref?.traceTests?.length || 0) > 0 && (
                  <div className="text-xs text-slate-600 dark:text-slate-400">
                    <p className="font-semibold">Önceki testler</p>
                    {trace.ref!.traceTests!.map(t => <p key={t.id}>{new Date(t.finishedAt).toLocaleString('tr-TR')} · {t.by} · {t.durationMin} dk · mutabakat {t.reconciliationPct != null ? `%${t.reconciliationPct}` : '—'}</p>)}
                  </div>
                )}
              </div>
            )}
            <p className="text-[11px] text-slate-500">BRCGS ve GLOBALG.A.P. izlenebilirlik testini en az yılda bir ister; hedef 4 saattir. "Yazdır" ile çıktı alınabilir.</p>
          </div>
        </Card>
      )}

      {tab === 'official' && (
        <Card title="Resmi aylık yönetim raporu" subtitle="Yazdırılabilir / PDF olarak kaydedilebilir aylık rapor">
          <p className="text-sm text-slate-700 dark:text-slate-300 mb-3">Aylık kalite ve izlenebilirlik raporu; yönetim ve denetim için resmi belge olarak kullanılır.</p>
          {onOpenMonthlyReport && <Button variant="primary" onClick={onOpenMonthlyReport}>Aylık raporu aç</Button>}
        </Card>
      )}

      <p className="text-[11px] text-slate-500">
        Hesaplar kayıtlardan yapılır: çıkış = depo girişinden sonraki sevkler + satışlar; depo durumu = giriş − çıkış.
        Fiyat ve gelir bu raporda yer almaz.
      </p>
    </div>
  );
}
