import React, { useMemo } from 'react';
import { ArrowRight, AlertTriangle, Leaf, Snowflake, Warehouse, Truck, ChevronRight } from 'lucide-react';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { analyzeColdChain, ColdChainAlert } from '../../utils/coldChainEngine';
import { ALERT_STAGE, STAGE_BY_KEY, StageKey } from '../../config/processStages';
import { lifecycleCounts, lifecycleStage } from '../../utils/refLifecycle';
import { findProfile, useLocationProfiles } from '../../services/locationProfiles';

/**
 * v3.7 — Operasyon ana paneli (tasarım önerisi "Masaüstü · Ana panel" / "Mobil · Ana").
 *  1) 4 aşama kartı: Hasat → Ön soğutma → Soğuk depo → Sevk (parti, kg, uyarı)
 *  2) Dikkat gerektirenler: en acil uyarılar, aşama etiketiyle, tek dokunuşla ilgili sayfa
 *  3) Oda doluluğu (kapasite yer profilinden) ve referans durum sayıları
 * Renk tek anlam taşır: aşama rengi sabit, uyarı rengi seviyeyi gösterir.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
  onNavigate: (view: string) => void;
  onOpenRecord: (refId: string) => void;
}

const STAGE_ICON: Record<StageKey, React.ReactNode> = {
  HASAT: <Leaf className="w-5 h-5" />,
  ON_SOGUTMA: <Snowflake className="w-5 h-5" />,
  SOGUK_DEPO: <Warehouse className="w-5 h-5" />,
  SEVK: <Truck className="w-5 h-5" />,
};
/** Sabit sınıflar — aşama rengi (tasarım sözlüğü) */
const TONE: Record<StageKey, { chip: string; text: string; bar: string }> = {
  HASAT: { chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300', text: 'text-emerald-700 dark:text-emerald-300', bar: 'bg-emerald-600' },
  ON_SOGUTMA: { chip: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300', text: 'text-sky-700 dark:text-sky-300', bar: 'bg-sky-600' },
  SOGUK_DEPO: { chip: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300', text: 'text-indigo-700 dark:text-indigo-300', bar: 'bg-indigo-600' },
  SEVK: { chip: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', text: 'text-amber-800 dark:text-amber-300', bar: 'bg-amber-600' },
};
const LEVEL: Record<ColdChainAlert['level'], { chip: string; label: string }> = {
  critical: { chip: 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300', label: 'Kritik' },
  warning: { chip: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', label: 'Uyarı' },
  info: { chip: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300', label: 'Bilgi' },
};

const t = (kg: number) => (kg >= 10000 ? `${(kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t` : `${Math.round(kg).toLocaleString('tr-TR')} kg`);

export default function OpsDashboard(p: Props) {
  useLocationProfiles(); // oda kapasitesi profilden okunur
  const summary = useMemo(() => analyzeColdChain({
    references: p.references, harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords,
    lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords,
  }), [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);

  const stages = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const field = summary.lots.filter(l => l.ref.status === 'CREATED');
    const notPre = field.filter(l => l.precooledKg <= 0);
    const inPre = field.filter(l => l.precooledKg > 0);
    const depo = p.references.filter(r => !r.archived && lifecycleStage(r) === 'DEPODA');
    const yolda = p.references.filter(r => !r.archived && lifecycleStage(r) === 'YOLDA');
    const alertCount = (k: StageKey, lv: ColdChainAlert['level']) => summary.alerts.filter(a => ALERT_STAGE[a.kind] === k && a.level === lv).length;
    const note = (k: StageKey, fallback: string) => {
      const c = alertCount(k, 'critical'); const w = alertCount(k, 'warning');
      if (c) return { text: `${c} kritik uyarı`, cls: LEVEL.critical.chip };
      if (w) return { text: `${w} uyarı`, cls: LEVEL.warning.chip };
      return { text: fallback, cls: '' };
    };
    return [
      { key: 'HASAT' as StageKey, lots: notPre.length, kg: notPre.reduce((a, l) => a + l.harvestKg, 0), note: note('HASAT', `Bugün ${p.harvestRecords.filter(h => (h.recordDate || h.timestamp || '').slice(0, 10) === today).length} hasat kaydı`) },
      { key: 'ON_SOGUTMA' as StageKey, lots: inPre.length, kg: inPre.reduce((a, l) => a + l.precooledKg, 0), note: note('ON_SOGUTMA', 'Uyarı yok') },
      { key: 'SOGUK_DEPO' as StageKey, lots: depo.length, kg: depo.reduce((a, r) => a + (Number(r.quantity) || 0), 0), note: note('SOGUK_DEPO', 'Kontroller zamanında') },
      { key: 'SEVK' as StageKey, lots: yolda.length, kg: yolda.reduce((a, r) => a + (Number(r.quantity) || 0), 0), note: note('SEVK', yolda.length ? 'Hepsi zamanında' : 'Yolda yük yok') },
    ];
  }, [summary, p.references, p.harvestRecords]);

  const urgent = summary.alerts.slice(0, 6);
  const rooms = summary.byRoom.slice(0, 6).map(r => {
    const prof = findProfile('ROOM', r.room);
    const capKg = Number(prof?.fields?.capacityKg);
    const pct = Number.isFinite(capKg) && capKg > 0 ? Math.min(100, Math.round((r.kg / capKg) * 100)) : null;
    return { ...r, pct };
  });
  const maxKg = Math.max(1, ...rooms.map(r => r.kg));

  const go = (k: StageKey) => {
    const s = STAGE_BY_KEY[k];
    p.onNavigate(s.monitorView || s.entryView);
  };

  return (
    <section aria-label="Operasyon özeti" className="space-y-4">
      {/* 1) Aşama kartları */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        {stages.map(s => {
          const def = STAGE_BY_KEY[s.key];
          const tone = TONE[s.key];
          return (
            <button key={s.key} type="button" onClick={() => go(s.key)}
              className="group relative text-left rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 sm:p-4 hover:border-slate-300 hover:shadow-sm transition cursor-pointer min-w-0">
              <div className="flex items-center gap-2.5">
                <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${tone.chip}`}>{STAGE_ICON[s.key]}</span>
                <div className="min-w-0">
                  <div className={`text-[10px] font-black tracking-wider ${tone.text}`}>ADIM {def.no}</div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white truncate">{def.label}</div>
                </div>
                <ArrowRight className="hidden lg:block w-4 h-4 ml-auto text-slate-300 group-hover:text-slate-500" aria-hidden="true" />
              </div>
              <div className="mt-2.5 flex items-baseline gap-1.5">
                <span className="font-display text-3xl font-bold text-slate-900 dark:text-white tabular-nums">{s.lots}</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">parti · {t(s.kg)}</span>
              </div>
              <div className="mt-2">
                {s.note.cls
                  ? <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-bold ${s.note.cls}`}>{s.note.text}</span>
                  : <span className="text-[11px] text-slate-500 dark:text-slate-400">{s.note.text}</span>}
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        {/* 2) Dikkat gerektirenler */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">Dikkat gerektirenler</h2>
            {summary.alerts.length > urgent.length && (
              <button type="button" onClick={() => p.onNavigate('ALERTS')} className="text-xs font-bold text-teal-700 dark:text-teal-300 cursor-pointer">Tümü ({summary.alerts.length})</button>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">En acil olan üstte · her uyarı kendi aşamasının etiketini taşır</p>
          {urgent.length === 0 && <p className="py-6 text-center text-sm text-slate-500">Şu an dikkat gerektiren bir şey yok.</p>}
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {urgent.map(a => {
              const sk = ALERT_STAGE[a.kind];
              const def = STAGE_BY_KEY[sk];
              return (
                <li key={a.id}>
                  <button type="button" onClick={() => go(sk)} className="w-full flex items-start gap-3 py-3 text-left cursor-pointer">
                    <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${LEVEL[a.level].chip}`}><AlertTriangle className="w-4 h-4" aria-label={LEVEL[a.level].label} /></span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold text-slate-900 dark:text-white">{a.title}</span>
                      <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-ref font-bold text-slate-800 dark:text-slate-200">{a.refId}</span>
                        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${TONE[sk].chip}`}>{def.short}</span>
                        <span className="truncate">{a.detail}</span>
                      </span>
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400 mt-2 shrink-0" aria-hidden="true" />
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="space-y-4 min-w-0">
          {/* 3a) Oda doluluğu */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <div className="flex items-center gap-2 mb-3">
              <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${TONE.SOGUK_DEPO.chip}`}><Warehouse className="w-4 h-4" /></span>
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">Oda doluluğu</h2>
            </div>
            {rooms.length === 0 && <p className="text-sm text-slate-500">Depoda aktif parti yok.</p>}
            <ul className="space-y-3">
              {rooms.map(r => {
                const w = r.pct ?? Math.round((r.kg / maxKg) * 100);
                return (
                  <li key={r.key}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">{r.warehouse} · {r.room}</span>
                      <span className="font-bold text-slate-600 dark:text-slate-300 tabular-nums">{r.pct !== null ? `%${r.pct}` : t(r.kg)}</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div className={`h-full rounded-full ${r.pct !== null && r.pct >= 90 ? 'bg-rose-600' : 'bg-indigo-600'}`} style={{ width: `${w}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
            <p className="mt-3 text-[11px] text-slate-500 dark:text-slate-400">Kırmızı: %90 üstü. Yüzde için oda profiline kg kapasitesi girin; yoksa kg gösterilir.</p>
          </div>

          {/* 3b) Referans durumu */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white mb-2.5">Referans durumu</h2>
            <div className="grid grid-cols-2 gap-2">
              {[
                { l: 'Sahada', v: life.SAHADA, c: 'text-emerald-700 dark:text-emerald-300' },
                { l: 'Yolda', v: life.YOLDA, c: 'text-amber-800 dark:text-amber-300' },
                { l: 'Soğuk depoda', v: life.DEPODA, c: 'text-indigo-700 dark:text-indigo-300' },
                { l: 'Aktif incident', v: life.INCIDENT, c: 'text-rose-700 dark:text-rose-300' },
                { l: 'Tamamlandı', v: life.TAMAMLANDI, c: 'text-slate-600 dark:text-slate-300' },
              ].map(x => (
                <button key={x.l} type="button" onClick={() => p.onNavigate('REFERENCES')} className="text-left rounded-xl border border-slate-200 dark:border-slate-800 px-3 py-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">{x.l}</div>
                  <div className={`font-display text-xl font-bold tabular-nums ${x.c}`}>{x.v}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
