import React, { useMemo } from 'react';
import { Leaf, Snowflake, Warehouse, Truck } from 'lucide-react';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { analyzeLot } from '../../utils/coldChainEngine';
import { STORAGE_TERMS } from '../../config/coldChain';
import { getStatusConfig } from '../../utils/statusStyles';
import { moduleActionLabel } from '../../utils/refLifecycle';

/**
 * v3.7 — PDF "Soğuk zincir izlenebilirlik" sayfası (tasarım: "PDF · Parti raporu").
 * Yazdırmaya uygun: açık zemin, renkler yalnızca aşama ve uyarı için, 11 px altı yazı yok.
 *  1) Süreç zaman çizelgesi (hasat → ön soğutma → depo → sevk)
 *  2) Kütle dengesi şeridi ve rakamlar
 *  3) Ön soğutma + 1-MCP, soğuk depo (son kontrol, O₂/CO₂)
 *  4) Durum geçmişi: hangi işlemde, kim, ne zaman
 *  5) Uyarılar ve bakiye kapatma kayıtları
 */
interface Props {
  reference: ReferenceItem;
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
}

const C = { hasat: '#2F7D3A', on: '#1F6FB2', depo: '#4338CA', sevk: '#A04A00', kritik: '#B42318', uyari: '#8A5300', gri: '#9AA59F' };
const kg = (v?: number | null) => (v === undefined || v === null ? '—' : `${Math.round(v).toLocaleString('tr-TR')} kg`);
const dt = (iso?: string) => {
  if (!iso) return '—';
  const d = new Date(iso.length === 10 ? `${iso}T00:00:00` : iso);
  return Number.isFinite(d.getTime()) ? d.toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : iso;
};
const hrs = (h: number | null) => (h === null ? '—' : h < 48 ? `${Math.round(h)} sa` : `${Math.round(h / 24)} gün`);

function Sec({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="break-inside-avoid">
      <h3 className="text-xs font-black tracking-wider text-slate-900 uppercase mb-2">{title}</h3>
      {children}
    </div>
  );
}
function KV({ rows }: { rows: [string, React.ReactNode][] }) {
  return (
    <div className="grid grid-cols-3 border border-slate-300 rounded-lg overflow-hidden">
      {rows.map(([k, v]) => (
        <div key={k} className="px-2.5 py-1.5 border-r border-b border-slate-200">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">{k}</div>
          <div className="text-xs font-bold text-slate-900">{v}</div>
        </div>
      ))}
    </div>
  );
}

export default function PdfColdChainSection(p: Props) {
  const lot = useMemo(() => analyzeLot(p.reference, {
    references: [p.reference], harvestRecords: p.harvestRecords, ambarRecords: p.ambarRecords,
    lojistikRecords: p.lojistikRecords, salesRecords: p.salesRecords,
  }), [p.reference, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);

  const ref = p.reference;
  const slips = [...(ref.precoolingSlips || [])].sort((a, b) => (a.startAt || a.date).localeCompare(b.startAt || b.date));
  const ambars = p.ambarRecords.filter(a => a.refId === ref.refId);
  const ships = p.lojistikRecords.filter(l => l.refId === ref.refId);
  const lastAmbar = ambars[ambars.length - 1];
  const lastCheck = lastAmbar ? [...(lastAmbar.storageChecks || [])].sort((a, b) => a.at.localeCompare(b.at)).pop() : undefined;
  const mcpSlip = slips.find(s => s.mcpDecision);
  const history = ref.statusHistory || [];
  const adj = ref.balanceAdjustments || [];

  const steps = [
    { key: 'h', label: 'Hasat', icon: <Leaf className="w-4 h-4" />, color: C.hasat, at: lot.harvestAt, sub: kg(lot.harvestKg) },
    { key: 'o', label: 'Ön soğutma', icon: <Snowflake className="w-4 h-4" />, color: C.on, at: slips[0]?.startAt, sub: slips.length ? `${hrs(lot.harvestToPrecoolH)} sonra · ${hrs(lot.precoolH)} sürdü` : 'kayıt yok' },
    { key: 'd', label: 'Soğuk depo', icon: <Warehouse className="w-4 h-4" />, color: C.depo, at: lastAmbar?.acceptanceDate || lastAmbar?.timestamp, sub: lastAmbar ? `${lastAmbar.warehouse || ''} · ${lastAmbar.roomNo || ''}` : 'kayıt yok' },
    { key: 's', label: 'Sevk', icon: <Truck className="w-4 h-4" />, color: C.sevk, at: ships[0]?.shipmentDate || ships[0]?.timestamp, sub: ships.length ? `${ships.length} sevk · ${kg(ships.reduce((a, s) => a + (Number(s.weightKg) || 0), 0))}` : 'henüz yok' },
  ];

  // Kütle dengesi şeridi: depoda kalan / çıkış / ıskarta / fire / bekleyen
  const H = Math.max(1, lot.harvestKg);
  const segs = [
    { l: 'Çıkış', v: lot.outKg, c: C.sevk },
    { l: 'Depoda', v: lot.remainingKg ?? 0, c: C.depo },
    { l: 'Iskarta', v: lot.culledKg, c: C.uyari },
    { l: 'Fire', v: lot.lossKg, c: C.kritik },
    { l: 'Bekleyen', v: Math.max(0, lot.openBalanceKg), c: C.on },
  ].filter(s => s.v > 0);

  return (
    <div className="space-y-5">
      <Sec title="Süreç zaman çizelgesi">
        <div className="grid grid-cols-4">
          {steps.map((s, i) => {
            const done = !!s.at;
            return (
              <div key={s.key}>
                <div className="flex items-center">
                  <span className="w-8 h-8 rounded-full flex items-center justify-center border-2 shrink-0"
                    style={{ borderColor: s.color, background: done ? s.color : '#fff', color: done ? '#fff' : s.color }}>{s.icon}</span>
                  {i < steps.length - 1 && <span className="flex-1 h-0.5" style={{ background: done ? s.color : '#E1E6E2' }} />}
                </div>
                <div className="mt-1.5 text-xs font-black text-slate-900">{s.label}</div>
                <div className="text-[11px] font-semibold text-slate-800">{dt(s.at)}</div>
                <div className="text-[11px] text-slate-600">{s.sub}</div>
              </div>
            );
          })}
        </div>
      </Sec>

      <Sec title="Kütle dengesi">
        <div className="flex h-6 rounded-md overflow-hidden border border-slate-200">
          {segs.map(s => <span key={s.l} style={{ width: `${(s.v / H) * 100}%`, background: s.c }} title={`${s.l} ${kg(s.v)}`} />)}
        </div>
        <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-700">
          <span>Hasat <strong>{kg(lot.harvestKg)}</strong></span>
          <span>Ön soğutma <strong>{kg(lot.precooledKg)}</strong></span>
          {lot.directToStoreKg > 0 && <span>Doğrudan depo <strong>{kg(lot.directToStoreKg)}</strong></span>}
          {segs.map(s => <span key={s.l} className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: s.c }} />{s.l} <strong>{kg(s.v)}</strong></span>)}
          {lot.lossPct.sortingCull !== null && <span>Iskarta oranı <strong>%{lot.lossPct.sortingCull}</strong></span>}
        </div>
      </Sec>

      <Sec title="Ön soğutma ve 1-MCP">
        {slips.length ? (
          <KV rows={[
            ['Fiş', slips.map(s => s.slipNo).join(', ')],
            ['Tünel / oda', slips[slips.length - 1].tunnel || '—'],
            ['Süre', `${hrs(lot.precoolH)} (hedef ${lot.rule.precoolMinH}–${lot.rule.precoolMaxH} sa)`],
            ['Meyve içi önce / sonra', `${slips[0].pulpBeforeC ?? '—'} → ${slips[0].pulpAfterC ?? '—'} °C`],
            ['Iskarta / paketlenen', `${kg(lot.culledKg)} / ${kg(lot.packedKg)}`],
            ['1-MCP', !lot.mcp.required ? 'Gerekmez' : lot.mcp.appliedAt ? `Uygulandı · ${dt(lot.mcp.appliedAt)}` : mcpSlip?.mcpDecision === 'NO' ? 'Hayır' : mcpSlip?.mcpDecision === 'YES' ? `Evet · plan ${dt(mcpSlip.mcpPlannedAt)}` : 'Karar yok'],
          ]} />
        ) : <p className="text-xs text-slate-500 italic">Bu parti için ön soğutma fişi yok.</p>}
      </Sec>

      <Sec title="Soğuk depo">
        {lastAmbar ? (
          <KV rows={[
            ['Depo / oda', `${lastAmbar.warehouse || '—'} · ${lastAmbar.roomNo || '—'}`],
            ['Süre sınıfı', STORAGE_TERMS.find(t => t.key === (lastAmbar.storageTerm || lot.storage[0]?.term))?.label || '—'],
            ['Depoda', lot.storage[0] ? `${lot.storage[0].days} gün` : '—'],
            ['Son kontrol', lastCheck ? `${dt(lastCheck.at)} · set ${lastCheck.setpointC ?? '—'} °C` : 'yok'],
            ['Oda / meyve içi · RH', lastCheck ? `${lastCheck.roomTemperatureC ?? '—'} / ${lastCheck.pulpTemperatureC ?? '—'} °C · %${lastCheck.humidityPercent ?? '—'}` : '—'],
            ['O₂ / CO₂', lastCheck && (lastCheck.o2Percent !== undefined || lastCheck.co2Percent !== undefined) ? `%${lastCheck.o2Percent ?? '—'} / %${lastCheck.co2Percent ?? '—'}` : '—'],
          ]} />
        ) : <p className="text-xs text-slate-500 italic">Bu parti henüz depoya kabul edilmedi.</p>}
      </Sec>

      <Sec title="Durum geçmişi — hangi işlemde değişti">
        {history.length ? (
          <table className="w-full text-[11px] border-collapse">
            <thead><tr className="bg-slate-100">{['Zaman', 'Önce', 'Sonra', 'İşlem', 'Kişi'].map(h => <th key={h} className="text-left px-2 py-1.5 border-b border-slate-300">{h}</th>)}</tr></thead>
            <tbody>
              {history.map((h, i) => (
                <tr key={i}>
                  <td className="px-2 py-1.5 border-b border-slate-200">{dt(h.at)}</td>
                  <td className="px-2 py-1.5 border-b border-slate-200">{getStatusConfig(h.from).label}</td>
                  <td className="px-2 py-1.5 border-b border-slate-200 font-bold">{getStatusConfig(h.to).label}</td>
                  <td className="px-2 py-1.5 border-b border-slate-200">{moduleActionLabel(h.module)}{h.note ? ` · ${h.note}` : ''}</td>
                  <td className="px-2 py-1.5 border-b border-slate-200">{h.by || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : <p className="text-xs text-slate-500 italic">Durum geçmişi v3.4 sonrası kayıtlarda tutulur.</p>}
      </Sec>

      {(lot.alerts.length > 0 || adj.length > 0) && (
        <Sec title="Uyarılar ve bakiye kayıtları">
          <ul className="space-y-1 text-xs">
            {lot.alerts.map(a => (
              <li key={a.id} className="flex gap-2 items-start">
                <span className="px-1.5 py-0.5 rounded text-[10px] font-black text-white shrink-0" style={{ background: a.level === 'critical' ? C.kritik : a.level === 'warning' ? C.uyari : C.on }}>
                  {a.level === 'critical' ? 'KRİTİK' : a.level === 'warning' ? 'UYARI' : 'BİLGİ'}
                </span>
                <span><strong>{a.title}</strong> — {a.detail}</span>
              </li>
            ))}
            {adj.map(x => (
              <li key={x.id} className="flex gap-2 items-start">
                <span className="px-1.5 py-0.5 rounded text-[10px] font-black text-white shrink-0" style={{ background: C.hasat }}>KAYIT</span>
                <span>{dt(x.at)} · {({ LOSS: 'Fire', LATE_HARVEST: 'Geç gelen hasat', DIRECT_TO_STORE: 'Doğrudan depoya', CORRECTION: 'Hasat düzeltmesi' } as Record<string, string>)[x.kind]} <strong>{kg(x.kg)}</strong>{x.reason ? ` · ${x.reason}` : ''} · {x.by}</span>
              </li>
            ))}
          </ul>
        </Sec>
      )}
    </div>
  );
}
