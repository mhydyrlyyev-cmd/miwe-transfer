import React, { useMemo } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, ReferenceLine, Cell, CartesianGrid, LabelList,
} from 'recharts';
import type { AmbarRecord, HarvestRecord, LojistikRecord, ReferenceItem, SalesRecord } from '../../types';
import { analyzeColdChain } from '../../utils/coldChainEngine';
import { lifecycleCounts } from '../../utils/refLifecycle';
import { OPEN_BALANCE_ALERT_H } from '../../config/coldChain';

/**
 * v3.7 — Rapor merkezi "Soğuk zincir" görselleri (tasarım: "Masaüstü · Rapor merkezi").
 *  • Özet kutuları  • Kütle dengesi (hasat → ön soğutma → depo → sevk)
 *  • Iskarta % ürüne göre (beklenen çizgisi)  • Hasat→ön soğutma süresi bahçeye göre (hedef çizgisi)
 *  • Durum dağılımı (5 aşama)
 * Renkler aşama sözlüğüyle aynı: hasat yeşil, ön soğutma mavi, depo lacivert, sevk turuncu.
 */
interface Props {
  references: ReferenceItem[];
  harvestRecords: HarvestRecord[];
  ambarRecords: AmbarRecord[];
  lojistikRecords: LojistikRecord[];
  salesRecords: SalesRecord[];
}

const C = { hasat: '#2F7D3A', on: '#1F6FB2', depo: '#4338CA', sevk: '#A04A00', kritik: '#B42318', gri: '#9AA59F', ink: '#142019' };
const tons = (kg: number) => (kg >= 10000 ? `${(kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t` : `${Math.round(kg).toLocaleString('tr-TR')} kg`);

function Box({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 min-w-0">
      <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">{title}</h3>
      {sub && <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">{sub}</p>}
      {children}
    </section>
  );
}

export default function ColdChainReport(p: Props) {
  const s = useMemo(() => analyzeColdChain(p), [p.references, p.harvestRecords, p.ambarRecords, p.lojistikRecords, p.salesRecords]);
  const life = useMemo(() => lifecycleCounts(p.references), [p.references]);

  const totals = useMemo(() => {
    const harvest = s.lots.reduce((a, l) => a + l.harvestKg, 0);
    const pre = s.lots.reduce((a, l) => a + l.precooledKg + l.directToStoreKg, 0);
    const stored = s.lots.reduce((a, l) => a + l.storedKg, 0);
    const out = s.lots.reduce((a, l) => a + l.outKg, 0);
    const cull = s.lots.reduce((a, l) => a + l.culledKg, 0);
    const preOnly = s.lots.reduce((a, l) => a + l.precooledKg, 0);
    const h2p = s.lots.map(l => l.harvestToPrecoolH).filter((x): x is number => x !== null);
    return {
      harvest, pre, stored, out,
      cullPct: preOnly > 0 ? Math.round((cull / preOnly) * 1000) / 10 : null,
      avgH2P: h2p.length ? Math.round((h2p.reduce((a, b) => a + b, 0) / h2p.length) * 10) / 10 : null,
      critical: s.alerts.filter(a => a.level === 'critical').length,
      open: s.alerts.filter(a => a.level !== 'info').length,
    };
  }, [s]);

  const funnel = [
    { name: 'Hasat', kg: totals.harvest, color: C.hasat },
    { name: 'Ön soğutma', kg: totals.pre, color: C.on },
    { name: 'Soğuk depo', kg: totals.stored, color: C.depo },
    { name: 'Sevk / satış', kg: totals.out, color: C.sevk },
  ].map(x => ({ ...x, pct: totals.harvest > 0 ? Math.round((x.kg / totals.harvest) * 100) : 0, label: tons(x.kg) }));

  const cullRows = s.byProductLoss.filter(x => x.cullPct !== null).slice(0, 8).map(x => ({ name: x.product, v: x.cullPct as number, exp: x.expectedCullPct ?? null }));
  const expected = cullRows.find(r => r.exp !== null)?.exp ?? null;
  const h2pRows = s.byOrchard.filter(o => o.avgHarvestToPrecoolH !== null).slice(0, 10).map(o => ({ name: o.orchard, v: o.avgHarvestToPrecoolH as number }));

  const dist = [
    { k: 'Sahada', v: life.SAHADA, c: C.hasat },
    { k: 'Yolda', v: life.YOLDA, c: C.sevk },
    { k: 'Soğuk depoda', v: life.DEPODA, c: C.depo },
    { k: 'Incident', v: life.INCIDENT, c: C.kritik },
    { k: 'Tamamlandı', v: life.TAMAMLANDI, c: C.gri },
  ];
  const distTotal = Math.max(1, dist.reduce((a, d) => a + d.v, 0));

  const tiles = [
    { l: 'Hasat', v: tons(totals.harvest), s: `${s.lots.length} parti` },
    { l: 'Sevk / satış', v: tons(totals.out), s: totals.harvest ? `%${Math.round((totals.out / totals.harvest) * 100)} akış` : '—' },
    { l: 'Ort. hasat→ön soğutma', v: totals.avgH2P !== null ? `${totals.avgH2P.toLocaleString('tr-TR')} sa` : '—', s: 'hedef ≤ 12 sa' },
    { l: 'Iskarta', v: totals.cullPct !== null ? `%${totals.cullPct.toLocaleString('tr-TR')}` : '—', s: 'ön soğutma fişlerinden' },
    { l: 'Açık uyarı', v: String(totals.open), s: `${totals.critical} kritik` },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {tiles.map(t => (
          <div key={t.l} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2.5">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">{t.l}</div>
            <div className="font-display text-xl font-bold text-slate-900 dark:text-white tabular-nums">{t.v}</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">{t.s}</div>
          </div>
        ))}
      </div>

      <Box title="Kütle dengesi — hasattan sevke" sub="Her çubuk o aşamadan geçen toplam kg. Aradaki fark: fire, ıskarta veya henüz sonraki aşamaya geçmeyen miktar.">
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={funnel} layout="vertical" margin={{ left: 8, right: 64, top: 4, bottom: 4 }}>
              <XAxis type="number" hide domain={[0, Math.max(1, totals.harvest)]} />
              <YAxis type="category" dataKey="name" width={96} tick={{ fontSize: 12, fill: '#33403A' }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v: any) => tons(Number(v))} />
              <Bar dataKey="kg" radius={[6, 6, 6, 6]} barSize={26} isAnimationActive={false}>
                {funnel.map(f => <Cell key={f.name} fill={f.color} />)}
                <LabelList dataKey="label" position="right" style={{ fontSize: 12, fontWeight: 700, fill: C.ink }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Box>

      <div className="grid gap-4 lg:grid-cols-2">
        <Box title="Iskarta % — ürüne göre" sub={expected !== null ? `Siyah çizgi: beklenen oran (%${expected}). Kırmızı: beklenenin üstü.` : 'Ön soğutma fişinde ıskarta kg girilince hesaplanır.'}>
          {cullRows.length ? (
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={cullRows} margin={{ left: -16, right: 8, top: 16, bottom: 4 }}>
                  <CartesianGrid vertical={false} stroke="#EEF0EE" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} />
                  <YAxis tick={{ fontSize: 11 }} unit="%" />
                  <Tooltip formatter={(v: any) => `%${v}`} />
                  {expected !== null && <ReferenceLine y={expected} stroke={C.ink} strokeWidth={2} />}
                  <Bar dataKey="v" radius={[6, 6, 0, 0]} isAnimationActive={false}>
                    {cullRows.map(r => <Cell key={r.name} fill={r.exp !== null && r.v > r.exp ? C.kritik : C.on} />)}
                    <LabelList dataKey="v" position="top" formatter={(v: any) => `%${v}`} style={{ fontSize: 11, fontWeight: 700, fill: C.ink }} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <p className="text-sm text-slate-500 py-6 text-center">Henüz ıskarta verisi yok.</p>}
        </Box>

        <Box title="Hasat → ön soğutma süresi — bahçeye göre" sub="Ortalama saat. Siyah çizgi: hedef 12 sa. Kırmızı: hedefin üstü.">
          {h2pRows.length ? (
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={h2pRows} margin={{ left: -16, right: 8, top: 16, bottom: 4 }}>
                  <CartesianGrid vertical={false} stroke="#EEF0EE" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} />
                  <YAxis tick={{ fontSize: 11 }} unit=" sa" />
                  <Tooltip formatter={(v: any) => `${v} sa`} />
                  <ReferenceLine y={OPEN_BALANCE_ALERT_H} stroke={C.ink} strokeWidth={2} />
                  <Bar dataKey="v" radius={[6, 6, 0, 0]} isAnimationActive={false}>
                    {h2pRows.map(r => <Cell key={r.name} fill={r.v > OPEN_BALANCE_ALERT_H ? C.kritik : C.hasat} />)}
                    <LabelList dataKey="v" position="top" style={{ fontSize: 11, fontWeight: 700, fill: C.ink }} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <p className="text-sm text-slate-500 py-6 text-center">Ön soğutma fişinde başlangıç saati girilince hesaplanır.</p>}
        </Box>
      </div>

      <Box title="Durum dağılımı" sub="Arşiv ve test referansları hariç">
        <div className="flex h-7 rounded-lg overflow-hidden" role="img" aria-label={dist.map(d => `${d.k} ${d.v}`).join(', ')}>
          {dist.filter(d => d.v > 0).map(d => <span key={d.k} style={{ width: `${(d.v / distTotal) * 100}%`, background: d.c }} />)}
        </div>
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          {dist.map(d => (
            <span key={d.k} className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: d.c }} />{d.k} <strong className="tabular-nums">{d.v}</strong>
            </span>
          ))}
        </div>
      </Box>
    </div>
  );
}
