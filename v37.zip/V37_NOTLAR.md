# v37 — v36 üzerine yama (görsel yenileme + rapor + PDF)

Proje köküne aynı yollarla kopyalayın. Firestore kuralı değişmedi.

- Ana panel: 4 aşama kartı (Hasat → Ön soğutma → Soğuk depo → Sevk), "Dikkat gerektirenler", oda doluluğu, referans durumu
- Masaüstü yan menü (lg+): Genel · Süreç 1–4 · Kalite · Analiz, uyarı rozetleri
- Mobil alt menü: Ana · Referans · (+) · Uyarılar · Senk — açık tema, büyük dokunma alanı
- Yeni Uyarılar sayfası (tüm aşamalar, aşama etiketiyle)
- Rapor merkezi > "Soğuk zincir" sekmesi: özet kutuları, kütle dengesi, ıskarta % (beklenen çizgisi),
  hasat→ön soğutma süresi (12 sa hedef çizgisi), durum dağılımı
- PDF: yeni "Soğuk zincir izlenebilirlik özeti" sayfası — zaman çizelgesi, kütle dengesi, ön soğutma/1-MCP,
  soğuk depo son kontrol, durum geçmişi (hangi işlemde, kim), uyarılar ve bakiye kayıtları
- Yazı tipleri: başlık Space Grotesk (font-display), RefID JetBrains Mono (font-ref)
