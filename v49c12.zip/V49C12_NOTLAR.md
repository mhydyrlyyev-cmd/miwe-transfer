# v49c12 — Akt durumu (giderildi / açık) · kısa listeler · firmaya göre ağaç · zil kaldırıldı

1. Akt durumu (YENİ services/aktStatus.ts, AktRows.tsx): 2026 arşiv aktlarında her satırda "Açık" düğmesi → dokununca "Giderildi" (geri alınabilir).
   Kayıt ayrı tutulur (ganttParcels, calV 'AKT'); arşiv dosyası değişmez; kural değişmez.
   Platformda açılan yeni aktlar (Incident) aynı listeye kendiliğinden girer; durumları kendi kaydından okunur (Çözüldü / Kapandı = giderildi).
   Yönetim analizi › Kritik noktalar: "Aktlar · n · konuya göre" — her konuda "x açık / hepsi giderildi". Bahçe ve sera profillerinde "Aktlar · n · x açık".
   Konu sınıflaması Türkçe kelimeleri de tanır (soğuk zincir, çürüme, ambalaj, kemirgen, fiziksel hasar …).
2. Bahçe profili › çeşit › Dikimler kısa liste: firma · anaç · dikim yılı grupları (parsel sayısı, ağaç, ha); "Tüm parseller (n)" ile ayrıntı.
3. Bahçe profili › çeşit › 2026 arşivi kısa liste: aşamaya (test türü) göre — test sayısı, ölçülen meyve, tarih aralığı, ortalama (sertlik/brix; bademde kabuk açma/nem); Toplam satırı; aşamaya dokun → testler.
4. Bahçe profili › "Firmaya göre ağaç" (firma bilgisi olan bahçede, ör. Garahan 1600: MU, ED, IG, TE, LI — ağaç, ha, parsel, çeşitler).
5. Üst çubuktaki zil (bildirim merkezi) kaldırıldı; işler Bugün yapılacaklar'da.
6. Yönetici masası › Veri sağlığı: "Aynı kişi birden çok kayıtlı (e-posta ya da ad)" — ad yazımı farkları (ý/y) da yakalanır.

Firestore kuralı DEĞİŞMEDİ — DeployRules ÇALIŞTIRMA.

## SHA-256 (7 dosya)
6d2d5c9a4355fe9be8f697b863e367c543547733a81ac04e38286bbbf2535cfd  src/App.tsx
4ecae5c881375837fbfb8f10fd309fe4540ed65f5c520bf8bb3bb27654103751  src/services/aktStatus.ts
213eeadb4b4e1d178978f8664be9ead1b322311cdd4ce86e54de1b1e31d9f5e5  src/services/archive2026.ts
274a911b7e8c590b4a4cba92799b2fbb8b4cab584d6664688f44f0c7a784690f  src/components/Header.tsx
adce240130ceba6a1216396d4aa5d82865468f712f5cfea0025b06184911df7b  src/components/views/AktRows.tsx
f5650f63e6997083a87cbe30b9a17cdf231beaec6f6ac670cd9b11a788988165  src/components/views/ManagementViews.tsx
cf7718004a995d3e7fa9d373c3f627934c50de588c3e06026a1c9a6a2ac38524  src/components/views/OrchardCardsView.tsx
