/**
 * v49c12 — Akt durumu: 2026 arşiv aktları için "Giderildi / Açık" işareti + platformda açılan yeni aktlar tek listede.
 *  · Arşiv aktının durumu ayrı kayıt olarak saklanır (ganttParcels koleksiyonu, calV: 'AKT'; kural değişmez). Arşiv dosyası değişmez.
 *  · Platformdaki akt (Incident) kendi durum alanını kullanır (Çözüldü / Kapandı = giderildi).
 */
import { useEffect, useMemo, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveRecordToFirestore } from '../lib/firestoreService';
import type { IncidentRecord } from '../types';
import { ARCHIVE_AKTS_2026, type ArchiveAkt } from '../config/archive2026';
import { canonicalOrchard } from './locationProfiles';

export interface AktStatus { id: string; calV: 'AKT'; no: string; done: boolean; at: string; by?: string; note?: string }
const LS = 'miwe_akt_status_v1';
let store: AktStatus[] = (() => { try { return JSON.parse(localStorage.getItem(LS) || '[]'); } catch { return []; } })();
const listeners = new Set<() => void>();
const emit = () => { try { localStorage.setItem(LS, JSON.stringify(store)); } catch { /* yoksay */ } listeners.forEach(l => l()); };
let loaded = false;
async function load() {
  if (loaded) return; loaded = true;
  try {
    const snap = await getDocs(collection(db, 'ganttParcels'));
    const remote: AktStatus[] = [];
    snap.forEach(d => { const v = d.data() as any; if (v?.calV === 'AKT') remote.push({ ...v, id: d.id }); });
    if (!remote.length) return;
    const m = new Map(store.map(s => [s.id, s]));
    for (const r of remote) { const l = m.get(r.id); if (!l || r.at > l.at) m.set(r.id, r); }
    store = [...m.values()]; emit();
  } catch { /* çevrimdışı */ }
}
export function useAktStatuses(): AktStatus[] {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f(x => x + 1); listeners.add(l); load(); return () => { listeners.delete(l); }; }, []);
  return store;
}
export async function setAktStatus(no: string, done: boolean, by?: string): Promise<boolean> {
  const id = `akt26-${no}`;
  const next: AktStatus = { id, calV: 'AKT', no, done, at: new Date().toISOString(), by };
  store = [...store.filter(s => s.id !== id), next]; emit();
  try { return await saveRecordToFirestore('GANTT', next); } catch { return false; }
}

/** Tek liste: arşiv + platform aktları. done: giderildi mi */
export interface AktRow extends ArchiveAkt { source: 'arşiv' | 'platform'; done: boolean; doneAt?: string }
const DONE_RE = /çözül|cozul|kapan|resolved|closed|tamam|giderildi/i;
export function useAllAkts(incidents: IncidentRecord[] = []): AktRow[] {
  const st = useAktStatuses();
  return useMemo(() => {
    const m = new Map(st.map(s => [s.no, s]));
    const arch: AktRow[] = ARCHIVE_AKTS_2026.map(a => ({ ...a, source: 'arşiv', done: !!m.get(a.no)?.done, doneAt: m.get(a.no)?.done ? m.get(a.no)!.at : undefined }));
    const plat: AktRow[] = incidents.filter(i => !/dfsd|deneme|test/i.test(`${i.description} ${i.notes}`)).map(i => ({
      no: i.incidentId || i.id, d: String(i.incidentDate || i.timestamp || '').slice(0, 10) || null,
      place: canonicalOrchard(i.location || (i as any).orchard || '') || i.location || '—', placeRaw: i.location || '',
      summary: [i.incidentType, i.description].filter(Boolean).join(' — '), product: (i as any).product || '', name: i.actNumber || i.incidentId || '',
      source: 'platform', done: DONE_RE.test(String(i.status || '')),
    }));
    return [...plat, ...arch].sort((a, b) => String(b.d).localeCompare(String(a.d)));
  }, [st, incidents]);
}
