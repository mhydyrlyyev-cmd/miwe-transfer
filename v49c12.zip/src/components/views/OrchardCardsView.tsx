import React, { useEffect, useMemo, useState } from 'react';
import { ChevronDown, TreeDeciduous, AlertTriangle, Flower2, Check, FlaskConical, Plus, RefreshCw, CalendarRange } from 'lucide-react';
import type { FieldRecord, HarvestRecord, IncidentRecord } from '../../types';
import { ORCHARD_CARDS, ORCHARD_SOURCES, type VarietyRow, type ParcelRow } from '../../config/orchardCards';
import { CAL_SEED_ROWS } from '../../config/harvestCalendarSeed';
import { UNIT_PLANS, UNIT_PLAN_SOURCE } from '../../config/unitPlans';
import { EXTERNAL_VISITS, EXTERNAL_SOURCE } from '../../config/externalOrchards';
import { actual2026, vkey, matchCardVariety } from '../../services/orchardOverview';
import { archiveTestsFor } from '../../services/archive2026';
import type { ArchiveTest } from '../../config/archive2026';
import { useAllAkts } from '../../services/aktStatus';
import AktRows from './AktRows';
import { buildCalendar, useCalOverrides, saveCalOverride, expectedBbch, bbchVerdict, BBCH_LABEL, type CalItem, type BbchStage } from '../../services/harvestCalendar';
import { canonicalOrchard, findProfile, upsertProfile, useLocationProfiles } from '../../services/locationProfiles';

/**
 * v49c7 — Bahçe profili (tüm bahçeler).
 *  Hasat pencereleri 2026 · 2027 (tek zaman çizgisi) · BBCH adımları (2026 · 2027 beklenen · 2027 gözlenen) ·
 *  hasat rasatları (saha testleri) · tonaj (2026 gerçekleşen · 2027 plan) · parseller · profile işleme.
 *  Veri kaynakları ayrı tutulur: parseller/ağaç = bütçe Excel'i; 2026 = hasat fişleri (yoksa Gantt); 2027 plan = tonaj Excel'i;
 *  BBCH/çiçeklenme = hasat takvimi kaydı (girilen). Hiçbiri birbirinin yerine yazılmaz.
 */
const DAY = 86400000;
const t1 = (kg: number) => (kg / 1000).toLocaleString('tr-TR', { maximumFractionDigits: kg >= 100000 ? 0 : 1 });
const n0 = (v: number) => Math.round(v).toLocaleString('tr-TR');
const dm = (s?: string | null) => (s ? s.slice(5, 10).split('-').reverse().join('.') : '');
const dmT = (t?: number) => (t ? new Date(t).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }) : '—');
const MON = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
const GRADE_CLS: Record<string, string> = { Extra: '#0f766e', Exclusive: '#14b8a6', Premium: '#5eead4', Classic: '#a7f3d0', Mix: '#cbd5e1', Ballyk: '#94a3b8', 'Off-grade': '#64748b' };
const FRUIT_ORDER = ['Kiraz', 'Erik', 'Şeftali', 'Nektarin', 'Elma', 'Armut', 'Nashi', 'Hurma', 'Badem'];
const FRUIT_NORM = (f: string) => /alma|elma/i.test(f) ? 'Elma' : /şet|seft|şeft/i.test(f) ? 'Şeftali' : /çer|cer|kiraz/i.test(f) ? 'Kiraz' : f;
/** gün-of-year → 2027 eksenine (yıl farkı atılır) */
const doy = (t: number) => { const d = new Date(t); return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / DAY); };

interface VarietyModel {
  key: string; fruit: string; name: string;
  card?: VarietyRow; seedVariety?: string; seedVarieties: string[];
  it26?: CalItem; it27?: CalItem;
  a26: ReturnType<typeof actual2026>;
  plan27: number;
}

function buildModels(orchard: string, items26: CalItem[], items27: CalItem[]): VarietyModel[] {
  const card = ORCHARD_CARDS[orchard];
  const map = new Map<string, VarietyModel>();
  const add = (key: string, fruit: string, name: string) => { if (!map.has(key)) map.set(key, { key, fruit: FRUIT_NORM(fruit), name, seedVarieties: [], a26: { kg: 0, src: null }, plan27: 0 }); return map.get(key)!; };
  const keyOf = (v: string) => (card ? matchCardVariety(orchard, v) : null) || vkey(v);
  /** aynı çeşidin birden çok takvim satırı (firmalara bölünmüş) tek pencereye birleşir: en erken başlangıç – en geç bitiş */
  const merge = (a: CalItem | undefined, b: CalItem): CalItem => {
    if (!a) return b;
    const mn = (x?: number, y?: number) => (x && y ? Math.min(x, y) : x || y), mx = (x?: number, y?: number) => (x && y ? Math.max(x, y) : x || y);
    return { ...a, windowStart: mn(a.windowStart, b.windowStart), windowEnd: mx(a.windowEnd, b.windowEnd), start: mn(a.start, b.start), end: mx(a.end, b.end), ov: a.ov || b.ov };
  };
  for (const v of card?.varieties || []) { const m = add(vkey(v.cesit), v.tur, v.cesit); m.card = v; m.plan27 = v.plan2027Kg; }
  for (const it of items27.filter(i => i.orchard === orchard)) {
    const k = keyOf(it.variety);
    const m = map.get(k) || add(k, it.fruit, it.variety.split('(')[0].trim());
    m.it27 = merge(m.it27, it); m.seedVariety = m.seedVariety || it.variety;
    if (!m.seedVarieties.includes(it.variety)) m.seedVarieties.push(it.variety);
    if (!card) m.plan27 += (it.targetTon || 0) * 1000;
  }
  for (const it of items26.filter(i => i.orchard === orchard)) { const m = map.get(keyOf(it.variety)); if (m) m.it26 = merge(m.it26, it); }
  for (const m of map.values()) m.a26 = actual2026(orchard, m.card ? m.card.cesit : (m.seedVariety || m.name));
  // ne 2026 hasadı ne 2027 planı olan satırlar (ör. Gantt'ta başlanmamış not satırı) gösterilmez
  return [...map.values()].filter(m => m.a26.kg > 0 || m.plan27 > 0).sort((a, b) => (FRUIT_ORDER.indexOf(a.fruit) - FRUIT_ORDER.indexOf(b.fruit)) || ((a.it27?.windowStart || 9e15) - (b.it27?.windowStart || 9e15)));
}

function Delta({ a, b }: { a: number; b: number }) {
  if (!a && !b) return null;
  if (!a) return <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">2026 yok</span>;
  if (!b) return <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">plan yok</span>;
  const p = Math.round(((b - a) / a) * 100);
  return <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border tabular-nums ${p >= 0 ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'}`}>{p >= 0 ? '+' : ''}{p}%</span>;
}

function GradeBar({ g }: { g: Record<string, number> }) {
  const tot = Object.values(g).reduce((s, v) => s + v, 0);
  if (!tot) return null;
  return (
    <div>
      <div className="flex h-2.5 rounded-full overflow-hidden">{Object.entries(g).map(([k, v]) => <div key={k} style={{ width: `${(v / tot) * 100}%`, background: GRADE_CLS[k] || '#94a3b8' }} />)}</div>
      <div className="flex flex-wrap gap-x-2.5 gap-y-0.5 mt-1">{Object.entries(g).map(([k, v]) => (
        <span key={k} className="text-[10px] text-slate-600 dark:text-slate-400 flex items-center gap-1"><span className="w-2 h-2 rounded-sm inline-block" style={{ background: GRADE_CLS[k] || '#94a3b8' }} />{k} %{Math.round((v / tot) * 100)}</span>))}</div>
    </div>
  );
}

/** Tek satırlık zaman çizgisi: gri = 2026 gerçek hasat, çerçeveli yeşil = 2027 tahmini pencere, pembe nokta = 2027 çiçeklenme */
function Track({ m, axis }: { m: VarietyModel; axis: { a: number; b: number } }) {
  const x = (t?: number) => (t === undefined ? undefined : Math.max(0, Math.min(100, ((doy(t) - axis.a) / (axis.b - axis.a)) * 100)));
  const s26 = x(m.it26?.start), e26 = x(m.it26?.end ?? m.it26?.start);
  const w26s = x(m.it26?.windowStart), w26e = x(m.it26?.windowEnd);
  const s27 = x(m.it27?.windowStart), e27 = x(m.it27?.windowEnd);
  const b27 = m.it27?.ov?.bbch?.['65'] ? x(Date.parse(`${m.it27.ov.bbch['65']}T00:00:00`)) : undefined;
  return (
    <div className="relative h-5 mt-1" aria-hidden>
      <div className="absolute inset-x-0 top-1/2 h-px bg-slate-200 dark:bg-slate-700" />
      {w26s !== undefined && w26e !== undefined && <div className="absolute top-0.5 h-1 rounded-full bg-slate-300 dark:bg-slate-600" style={{ left: `${w26s}%`, width: `${Math.max(1, w26e - w26s)}%` }} title="2026 penceresi" />}
      {s26 !== undefined && e26 !== undefined && <div className="absolute top-[7px] h-1.5 rounded-full bg-slate-600 dark:bg-slate-300" style={{ left: `${s26}%`, width: `${Math.max(1.2, e26 - s26)}%` }} title="2026 gerçek hasat" />}
      {s27 !== undefined && e27 !== undefined && <div className="absolute bottom-0 h-1.5 rounded-full border border-teal-600 bg-teal-100 dark:bg-teal-900" style={{ left: `${s27}%`, width: `${Math.max(1.2, e27 - s27)}%` }} title="2027 tahmini pencere" />}
      {b27 !== undefined && <div className="absolute top-1/2 -mt-1 w-2 h-2 rounded-full bg-pink-500" style={{ left: `${b27}%` }} title="2027 çiçeklenme" />}
    </div>
  );
}

function BbchTable({ m, orchard, by, readOnly }: { m: VarietyModel; orchard: string; by: string; readOnly: boolean }) {
  const it = m.it27;
  const [vals, setVals] = useState<Partial<Record<BbchStage, string>>>(it?.ov?.bbch || {});
  const [state, setState] = useState<'idle' | 'ok' | 'err'>('idle');
  const stored = JSON.stringify(it?.ov?.bbch || {});
  useEffect(() => { setVals(JSON.parse(stored)); }, [stored]);
  if (!it || !m.seedVariety) return <p className="text-[11px] text-slate-500">Bu çeşit hasat takviminde yok — BBCH ve hasat penceresi izlenemiyor.</p>;
  const dirty = JSON.stringify(vals) !== stored;
  const save = async () => { const clean = Object.fromEntries(Object.entries(vals).filter(([, v]) => v)); let ok = true; for (const sv of m.seedVarieties) ok = (await saveCalOverride(2027, orchard, sv, { bbch: clean }, by)) && ok; setState(ok ? 'ok' : 'err'); };
  const seed = it.seed as any;
  return (
    <div>
      <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1"><Flower2 className="w-3.5 h-3.5" />BBCH adımları</div>
      <div className="grid grid-cols-[minmax(0,1fr)_52px_52px_112px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Aşama</span><span className="text-right">2026</span><span className="text-right">2027 bekl.</span><span className="text-right">2027 gözlenen</span></div>
      {(['65', '71', '81', '85'] as BbchStage[]).map(st => {
        const exp = expectedBbch(it, st);
        const v = bbchVerdict(vals[st], exp);
        return (
          <div key={st} className="grid grid-cols-[minmax(0,1fr)_52px_52px_112px] gap-1 items-center text-xs py-1 border-b border-slate-100 dark:border-slate-700 last:border-0">
            <span className="min-w-0"><span className="block font-semibold">BBCH {st}</span><span className="block text-[10px] text-slate-500 truncate">{BBCH_LABEL[st]}{v ? <b className={`ml-1 ${v.tone === 'ok' ? 'text-emerald-700' : v.tone === 'late' ? 'text-amber-700' : 'text-sky-700'}`}>· {v.label}</b> : null}</span></span>
            <span className="text-right tabular-nums">{dm(seed[`bbch${st}`]) || '—'}</span>
            <span className="text-right tabular-nums text-slate-500">{exp ? dmT(exp) : '—'}</span>
            {readOnly ? <span className="text-right tabular-nums">{dm(vals[st]) || '—'}</span> : (
              <input type="date" aria-label={`2027 BBCH ${st}`} value={vals[st] || ''} min="2027-01-15" max="2027-12-15" onChange={e => { setVals({ ...vals, [st]: e.target.value }); setState('idle'); }}
                className="min-h-[36px] w-full rounded-lg border border-slate-300 px-1 text-xs bg-white dark:bg-slate-900" />)}
          </div>
        );
      })}
      {!readOnly && (
        <div className="flex items-center justify-end gap-2 mt-1.5">
          {state === 'err' && <span className="text-[11px] text-amber-800">Telefonda kaydedildi, internet gelince gönderilecek.</span>}
          {state === 'ok' && !dirty && <span className="text-[11px] text-emerald-700 flex items-center gap-1"><Check className="w-3.5 h-3.5" />Kaydedildi · hasat takvimi güncellendi</span>}
          <button type="button" disabled={!dirty} onClick={save} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
        </div>
      )}
    </div>
  );
}

/** v49c10: seyreltme (2026 tarihleri → 2027) ve meyve sayımı → tonaj rasadı */
function ThinAndCount({ m, orchard, trees, by, readOnly }: { m: VarietyModel; orchard: string; trees: number; by: string; readOnly: boolean }) {
  const it = m.it27;
  const fc = it?.ov?.fruitCount;
  const [thin, setThin] = useState(it?.ov?.thinDoneAt || '');
  const [cnt, setCnt] = useState({ date: fc?.date || new Date().toISOString().slice(0, 10), trees: String(fc?.trees || trees || ''), fruits: String(fc?.fruitsPerTree || ''), g: String(fc?.weightG || '') });
  const [msg, setMsg] = useState('');
  if (!it || !m.seedVarieties.length) return null;
  const seed = it.seed;
  const nTrees = Number(cnt.trees.replace(',', '.')) || 0, nF = Number(cnt.fruits.replace(',', '.')) || 0, nG = Number(cnt.g.replace(',', '.')) || 0;
  const est = nTrees * nF * nG / 1000;
  const saveAll = async (patch: Record<string, unknown>) => { let ok = true; for (const sv of m.seedVarieties) ok = (await saveCalOverride(2027, orchard, sv, patch as any, by)) && ok; setMsg(ok ? 'Kaydedildi' : 'Telefonda kaydedildi, internet gelince gönderilecek'); };
  const inp = 'min-h-[36px] w-full rounded-lg border border-slate-300 px-2 text-xs bg-white dark:bg-slate-900';
  return (
    <div className="space-y-2">
      <div>
        <div className="text-[11px] font-semibold text-slate-500 mb-1">Seyreltme</div>
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 shrink-0">2026: {seed.thinStart ? `${dm(seed.thinStart)}–${dm(seed.thinEnd || seed.thinStart)}` : '—'}</span>
          {readOnly ? <span className="ml-auto">{it.ov?.thinDoneAt ? `yapıldı ${dm(it.ov.thinDoneAt)}` : 'girilmedi'}</span> : (<>
            <input type="date" aria-label="2027 seyreltme yapıldı" value={thin} onChange={e => setThin(e.target.value)} className={`${inp} ml-auto max-w-[150px]`} />
            <button type="button" disabled={!thin || thin === it.ov?.thinDoneAt} onClick={() => saveAll({ thinDoneAt: thin })} className="min-h-[36px] px-2.5 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer shrink-0">Yapıldı</button>
          </>)}
        </div>
      </div>
      <div>
        <div className="text-[11px] font-semibold text-slate-500 mb-1">Meyve sayımı → tonaj rasadı (meyve tutumundan sonra)</div>
        {readOnly ? <p className="text-xs">{fc ? `${dm(fc.date)} · ${n0(fc.trees)} ağaç × ${fc.fruitsPerTree} meyve × ${fc.weightG} g ≈ ${t1(fc.estKg)} t` : 'girilmedi'}</p> : (
          <>
            <div className="grid grid-cols-4 gap-1.5">
              <label className="text-[10px] text-slate-500">Tarih<input type="date" value={cnt.date} onChange={e => setCnt({ ...cnt, date: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Ağaç<input inputMode="numeric" value={cnt.trees} onChange={e => setCnt({ ...cnt, trees: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Meyve/ağaç<input inputMode="decimal" value={cnt.fruits} onChange={e => setCnt({ ...cnt, fruits: e.target.value })} className={inp} /></label>
              <label className="text-[10px] text-slate-500">Hasatta g<input inputMode="decimal" value={cnt.g} onChange={e => setCnt({ ...cnt, g: e.target.value })} className={inp} /></label>
            </div>
            <div className="flex items-center justify-between gap-2 mt-1.5 text-xs">
              <span>Tahmin: <b className="tabular-nums">{est ? `${t1(est)} t` : '—'}</b>{est && m.plan27 ? <span className="text-slate-500"> · plan {t1(m.plan27)} t · {est >= m.plan27 ? '+' : ''}{Math.round(((est - m.plan27) / m.plan27) * 100)}%</span> : null}</span>
              <button type="button" disabled={!est} onClick={() => saveAll({ fruitCount: { date: cnt.date, trees: nTrees, fruitsPerTree: nF, weightG: nG, estKg: Math.round(est) } })} className="min-h-[36px] px-3 rounded-lg bg-teal-700 text-white text-xs font-semibold disabled:opacity-40 cursor-pointer">Kaydet</button>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Örnek ağaçlarda ortalama meyve sayısı; hasattaki ortalama meyve ağırlığı (g). Ağaç sayısı parsellerden gelir.</p>
          </>
        )}
        {msg && <p className="text-[11px] text-emerald-700 mt-1">{msg}</p>}
      </div>
    </div>
  );
}

function Rasatlar({ m, orchard, fieldRecords, onStartTest, readOnly }: { m: VarietyModel; orchard: string; fieldRecords: FieldRecord[]; onStartTest?: (c: { orchard: string; product: string; variety: string }) => void; readOnly: boolean }) {
  const rows = fieldRecords
    .filter(r => canonicalOrchard(r.orchard) === orchard && (vkey(r.sortVariety) === m.key || matchCardVariety(orchard, r.sortVariety) === m.key))
    .sort((a, b) => String(b.timestamp).localeCompare(String(a.timestamp))).slice(0, 6);
  const arch = archiveTestsFor(orchard, m.key);
  const [showArch, setShowArch] = useState(false);
  const almond = m.fruit === 'Badem' || arch.some(t => t.rh !== undefined || t.hull !== undefined);
  const firstT = arch.filter(t => !/^ýygym-?\d/i.test(t.type.replace(/\s/g, ''))).map(t => t.d).sort()[0];
  const h26 = m.it26?.start;
  const lead = firstT && h26 ? Math.round((h26 - Date.parse(`${firstT}T00:00:00`)) / 86400000) : undefined;
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1"><FlaskConical className="w-3.5 h-3.5" />Hasat rasatları (saha testleri)</span>
        {onStartTest && !readOnly && <button type="button" onClick={() => onStartTest({ orchard, product: m.fruit, variety: m.seedVariety || m.name })} className="text-[11px] font-semibold text-teal-700 flex items-center gap-0.5 cursor-pointer"><Plus className="w-3.5 h-3.5" />Rasat ekle</button>}
      </div>
      {rows.length === 0 ? <p className="text-[11px] text-slate-500">Bu çeşit için saha testi yok.</p> : (
        <>
          <div className="grid grid-cols-[52px_minmax(0,1fr)_44px_40px_40px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Tarih</span><span>Test</span><span className="text-right">Sertlik</span><span className="text-right">Brix</span><span className="text-right">Nişasta</span><span className="text-right">Çap</span></div>
          {rows.map(r => (
            <div key={r.id} className="grid grid-cols-[52px_minmax(0,1fr)_44px_40px_40px_40px] gap-1 text-xs tabular-nums py-0.5">
              <span>{new Date(r.timestamp).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit' })}</span><span className="truncate">{r.testType}</span>
              <span className="text-right">{r.avgHardness ? r.avgHardness.toFixed(1) : '—'}</span><span className="text-right">{r.avgBrix ? r.avgBrix.toFixed(1) : '—'}</span>
              <span className="text-right">{r.starchIndex ? r.starchIndex.toFixed(1) : '—'}</span><span className="text-right">{r.avgDiameter ? Math.round(r.avgDiameter) : '—'}</span>
            </div>))}
        </>
      )}
      {arch.length > 0 && (
        <div className="mt-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2">
          <button type="button" onClick={() => setShowArch(v => !v)} className="w-full flex items-center justify-between text-left cursor-pointer">
            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">2026 arşivi · {arch.length} test{lead !== undefined ? ` · ilk test hasattan ${lead} gün önce` : ''}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 ${showArch ? 'rotate-180' : ''}`} />
          </button>
          {showArch && <ArchiveStages arch={arch} almond={almond} />}
        </div>
      )}
    </div>
  );
}

/** v49c12: dikimler kısa liste — firma · dikim yılı · anaç grupları; istenirse tüm parseller */
function ParcelSummary({ ps }: { ps: ParcelRow[] }) {
  const [all, setAll] = useState(false);
  const groups = useMemo(() => {
    const m = new Map<string, { firma: string; yil: string; anac: string; n: number; agac: number; ha: number; kg: number }>();
    for (const p of ps) {
      const k = `${p.firma || ''}|${p.yil}|${p.anac || ''}`;
      const g = m.get(k) || { firma: p.firma || '', yil: String(p.yil ?? '—'), anac: p.anac || '', n: 0, agac: 0, ha: 0, kg: 0 };
      g.n++; g.agac += p.agac; g.ha += p.ha; g.kg += p.planKg || 0; m.set(k, g);
    }
    return [...m.values()].sort((a, b) => a.firma.localeCompare(b.firma) || a.yil.localeCompare(b.yil));
  }, [ps]);
  const trees = ps.reduce((s, p) => s + p.agac, 0), ha = ps.reduce((s, p) => s + p.ha, 0);
  const hasF = groups.some(g => g.firma);
  return (
    <div>
      <div className="text-[11px] font-semibold text-slate-500 mb-1">Dikimler · {n0(trees)} ağaç · {ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha · {ps.length} parsel</div>
      <div className="grid grid-cols-[minmax(0,1fr)_40px_30px_60px_44px] gap-1 text-[10px] text-slate-500 font-semibold"><span>{hasF ? 'Firma · anaç' : 'Anaç'}</span><span className="text-right">Dikim</span><span className="text-right">Prs</span><span className="text-right">Ağaç</span><span className="text-right">ha</span></div>
      {groups.map((g, i) => (
        <div key={i} className="grid grid-cols-[minmax(0,1fr)_40px_30px_60px_44px] gap-1 text-xs tabular-nums py-0.5">
          <span className="truncate">{[g.firma, g.anac].filter(Boolean).join(' · ') || '—'}</span><span className="text-right">{g.yil}</span><span className="text-right">{g.n}</span><span className="text-right">{n0(g.agac)}</span><span className="text-right">{g.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}</span>
        </div>))}
      {ps.length > groups.length && (
        <>
          <button type="button" onClick={() => setAll(v => !v)} className="text-[11px] font-semibold text-teal-700 mt-1 cursor-pointer">{all ? 'Kısa liste' : `Tüm parseller (${ps.length})`}</button>
          {all && <div className="mt-1 max-h-64 overflow-y-auto">{ps.map((p, i) => (
            <div key={i} className="grid grid-cols-[minmax(0,1fr)_40px_60px_44px_44px] gap-1 text-[11px] tabular-nums py-0.5">
              <span className="truncate">{[p.parsel, p.anac].filter(Boolean).join(' · ') || '—'}</span><span className="text-right">{p.yil}</span><span className="text-right">{n0(p.agac)}</span><span className="text-right">{p.ha.toLocaleString('tr-TR', { maximumFractionDigits: 2 })}</span><span className="text-right">{p.kgAgac || '—'}</span>
            </div>))}</div>}
        </>
      )}
    </div>
  );
}

/** v49c12: 2026 testleri kısa liste — aşamaya (test türüne) göre toplam; dokununca o aşamanın testleri */
function ArchiveStages({ arch, almond }: { arch: ArchiveTest[]; almond: boolean }) {
  const [open, setOpen] = useState<string | null>(null);
  const norm = (t: string) => t.replace(/\s+/g, ' ').replace(/\s*-\s*/g, ' - ').trim();
  const stages = useMemo(() => {
    const m = new Map<string, ArchiveTest[]>();
    for (const t of arch) m.set(norm(t.type), [...(m.get(norm(t.type)) || []), t]);
    const avg = (xs: (number | undefined)[]) => { const v = xs.filter((x): x is number => typeof x === 'number'); return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : undefined; };
    return [...m.entries()].map(([type, ts]) => ({ type, ts, n: ts.reduce((s, t) => s + t.n, 0), from: ts[0].d, to: ts[ts.length - 1].d,
      a: avg(ts.map(t => (almond ? t.hull : t.hard))), b: avg(ts.map(t => (almond ? t.rh : t.brix))) })).sort((x, y) => x.from.localeCompare(y.from));
  }, [arch, almond]);
  const d = (s: string) => `${s.slice(8, 10)}.${s.slice(5, 7)}`;
  return (
    <div className="mt-1">
      <div className="grid grid-cols-[minmax(0,1fr)_26px_30px_74px_40px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Aşama</span><span className="text-right">Test</span><span className="text-right">n</span><span className="text-right">Tarih</span><span className="text-right">{almond ? 'Kabuk%' : 'Sertlik'}</span><span className="text-right">{almond ? 'Nem%' : 'Brix'}</span></div>
      {stages.map(st => (
        <div key={st.type}>
          <button type="button" onClick={() => setOpen(open === st.type ? null : st.type)} className="w-full grid grid-cols-[minmax(0,1fr)_26px_30px_74px_40px_40px] gap-1 text-[11px] tabular-nums py-1 text-left cursor-pointer border-t border-slate-100 dark:border-slate-800">
            <span className="truncate font-semibold">{st.type}</span><span className="text-right">{st.ts.length}</span><span className="text-right">{st.n}</span><span className="text-right">{d(st.from)}{st.to !== st.from ? `–${d(st.to)}` : ''}</span><span className="text-right">{st.a ?? '—'}</span><span className="text-right">{st.b ?? '—'}</span>
          </button>
          {open === st.type && st.ts.map((t, i) => (
            <div key={i} className="grid grid-cols-[minmax(0,1fr)_26px_30px_74px_40px_40px] gap-1 text-[10px] tabular-nums text-slate-600 dark:text-slate-400 pl-2" title={[t.by, t.parcel, t.phen, t.note].filter(Boolean).join(' · ')}>
              <span className="truncate">{t.by}{t.parcel ? ` · ${t.parcel}` : ''}</span><span /><span className="text-right">{t.n}</span><span className="text-right">{d(t.d)}</span><span className="text-right">{(almond ? t.hull : t.hard) ?? '—'}</span><span className="text-right">{(almond ? t.rh : t.brix) ?? '—'}</span>
            </div>))}
        </div>))}
      <div className="grid grid-cols-[minmax(0,1fr)_26px_30px_74px_40px_40px] gap-1 text-[11px] tabular-nums py-1 font-bold border-t border-slate-200 dark:border-slate-700"><span>Toplam</span><span className="text-right">{arch.length}</span><span className="text-right">{arch.reduce((s, t) => s + t.n, 0)}</span><span /><span /><span /></div>
      <p className="text-[10px] text-slate-400 mt-1">Salt okunur · Aktlar_List › Test (2026) · aşama ortalaması; aşamaya dokun → testler</p>
    </div>
  );
}

function VarietyItem({ m, orchard, parcels, axis, ctx, focus }: { m: VarietyModel; orchard: string; parcels: ParcelRow[]; axis: { a: number; b: number }; ctx: { by: string; readOnly: boolean; fieldRecords: FieldRecord[]; onStartTest?: (c: { orchard: string; product: string; variety: string }) => void }; focus?: boolean }) {
  const [open, setOpen] = useState(!!focus);
  const ref = React.useRef<HTMLLIElement>(null);
  useEffect(() => { if (focus) setTimeout(() => ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300); }, [focus]);
  const ps = parcels.filter(p => vkey(p.cesit) === m.key);
  const trees = ps.reduce((s, p) => s + p.agac, 0), ha = ps.reduce((s, p) => s + p.ha, 0);
  const v = m.card;
  const maxM = v ? Math.max(...v.plan2027Months, 1) : 1;
  const late26 = m.it26?.start && m.it26?.windowStart ? Math.round((m.it26.start - m.it26.windowStart) / DAY) : undefined;
  return (
    <li ref={ref} className={`py-2 ${focus ? 'scroll-mt-4' : ''}`}>
      <button type="button" onClick={() => setOpen(o => !o)} className="w-full text-left cursor-pointer">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">{m.name}</span>
          <span className="flex items-center gap-1.5 shrink-0 text-xs tabular-nums">
            <span className="text-slate-500">{m.a26.kg ? t1(m.a26.kg) : '—'} →</span><b>{m.plan27 ? `${t1(m.plan27)} t` : '—'}</b>
            <Delta a={m.a26.kg} b={m.plan27} />
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
          </span>
        </div>
        <Track m={m} axis={axis} />
        <div className="text-[10px] text-slate-500 flex flex-wrap gap-x-2">
          {m.it26?.start ? <span>2026: {dmT(m.it26.start)}–{dmT(m.it26.end)}</span> : <span>2026: —</span>}
          {m.it27?.windowStart ? <span className="text-teal-800 dark:text-teal-300">2027 ≈ {dmT(m.it27.windowStart)}–{dmT(m.it27.windowEnd)}</span> : null}
          {m.it27?.ov?.bbch?.['65'] ? <span className="text-pink-700">çiçek {dm(m.it27.ov.bbch['65'])}</span> : m.it27 ? <span className="text-amber-700">çiçek girilmedi</span> : null}
        </div>
      </button>
      {open && (
        <div className="mt-2 space-y-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 p-2">
              <div className="text-[10px] text-slate-500">2026 hasat</div>
              <div className="font-semibold tabular-nums">{m.it26?.start ? `${dmT(m.it26.start)}–${dmT(m.it26.end)}` : '—'}</div>
              <div className="text-[10px] text-slate-500">{m.a26.kg ? `${t1(m.a26.kg)} t · ${m.a26.src === 'Gantt' ? 'Gantt' : 'hasat fişi'}` : 'kayıt yok'}{late26 !== undefined ? ` · pencereye göre ${late26 === 0 ? 'zamanında' : late26 > 0 ? `${late26} gün geç` : `${-late26} gün erken`}` : ''}</div>
            </div>
            <div className="rounded-lg bg-white dark:bg-slate-900 border border-teal-200 p-2">
              <div className="text-[10px] text-slate-500">2027 tahmini pencere</div>
              <div className="font-semibold tabular-nums text-teal-800 dark:text-teal-300">{m.it27?.windowStart ? `${dmT(m.it27.windowStart)}–${dmT(m.it27.windowEnd)}` : '—'}</div>
              <div className="text-[10px] text-slate-500 truncate">{m.it27?.windowSource || ''}{m.plan27 ? ` · plan ${t1(m.plan27)} t` : ''}</div>
            </div>
          </div>
          <BbchTable m={m} orchard={orchard} by={ctx.by} readOnly={ctx.readOnly} />
          <ThinAndCount m={m} orchard={orchard} trees={trees} by={ctx.by} readOnly={ctx.readOnly} />
          <Rasatlar m={m} orchard={orchard} fieldRecords={ctx.fieldRecords} onStartTest={ctx.onStartTest} readOnly={ctx.readOnly} />
          {ps.length > 0 && <ParcelSummary ps={ps} />}
          {v && v.actual2026Kg > 0 && <div><div className="text-[11px] font-semibold text-slate-500 mb-1">2026 sınıf dağılımı (hasat fişleri)</div><GradeBar g={v.grades2026} /></div>}
          {v && v.plan2027Kg > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">2027 plan · ay</div>
              <div className="grid grid-cols-12 gap-0.5 items-end h-10">{v.plan2027Months.map((x, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: x ? `${Math.max(8, (x / maxM) * 100)}%` : 2, opacity: x ? 1 : 0.15 }} />)}</div>
              <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mt-0.5">{MON.map(x => <span key={x}>{x[0]}</span>)}</div>
              <div className="mt-2"><GradeBar g={v.plan2027Grades} /></div>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

/** Kart verisinden profile yazılacak alanlar (yalnız Bahçe kartı olan bahçe) */
function profilePatch(orchard: string, models: VarietyModel[]) {
  const card = ORCHARD_CARDS[orchard];
  if (!card) return null;
  const byTur = new Map<string, string[]>();
  for (const v of card.varieties) if (!/belirsiz/i.test(v.cesit)) byTur.set(v.tur, [...(byTur.get(v.tur) || []), v.cesit]);
  const years = card.parcels.map(p => Number(p.yil)).filter(Number.isFinite);
  const anac = [...new Set(card.parcels.map(p => p.anac).filter(Boolean))];
  const codes = [...new Set(card.parcels.map(p => p.parsel).filter(Boolean))];
  const hasP = card.parcels.length > 0;
  const out: Record<string, string | number> = {
    products: [...byTur.entries()].map(([t, vs]) => `${t}: ${vs.join(', ')}`).join(' · '),
    actual2026Ton: Math.round(models.reduce((s, m) => s + m.a26.kg, 0) / 100) / 10,
    plan2027Ton: Math.round(card.varieties.reduce((s, v) => s + v.plan2027Kg, 0) / 100) / 10,
  };
  if (hasP) Object.assign(out, {
    treeCount: card.parcels.reduce((s, p) => s + p.agac, 0),
    areaHa: Math.round(card.parcels.reduce((s, p) => s + p.ha, 0) * 100) / 100,
    sections: card.parcels.some(p => p.firma)
      ? [...new Set(card.parcels.map(p => p.firma!))].map(fm => { const ps = card.parcels.filter(p => p.firma === fm); return `${fm} ${Math.round(ps.reduce((s, p) => s + p.ha, 0))} ha · ${ps.reduce((s, p) => s + p.agac, 0).toLocaleString('tr-TR')} ağaç · ${[...new Set(ps.map(p => p.cesit))].join(' + ')}`; }).join(' | ')
      : codes.length ? `${codes.length} parsel (${codes.slice(0, 12).join(', ')}${codes.length > 12 ? '…' : ''})` : `${card.parcels.length} parsel satırı`,
    plantYears: years.length ? `${Math.min(...years)}–${Math.max(...years)}` : '',
    ...(anac.length ? { rootstock: anac.join(', ') } : {}),
  });
  return out;
}
const PATCH_LABEL: Record<string, string> = { treeCount: 'Ağaç sayısı', areaHa: 'Alan (ha)', products: 'Ürünler / çeşitler', sections: 'Bölümler / parseller', plantYears: 'Dikim yılı', rootstock: 'Anaç', actual2026Ton: '2026 gerçekleşen (t)', plan2027Ton: '2027 plan (t)' };

function ProfileSync({ orchard, models, by }: { orchard: string; models: VarietyModel[]; by: string }) {
  useLocationProfiles('ORCHARD');
  const pr = findProfile('ORCHARD', orchard);
  const patch = profilePatch(orchard, models);
  const [done, setDone] = useState(false);
  if (!patch || !pr) return null;
  const diff = Object.entries(patch).filter(([k, v]) => v !== '' && String(pr.fields[k] ?? '') !== String(v));
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><RefreshCw className="w-4 h-4 text-teal-700" />Profil bilgisi</h2>
      {diff.length === 0 ? <p className="text-xs text-emerald-700 mt-1">Profil bu sayfadaki verilerle aynı.</p> : (
        <>
          <p className="text-[11px] text-slate-500 mt-0.5">Yer profilinde değişecek alanlar (yalnız bunlar; koordinat, not ve diğer alanlara dokunulmaz):</p>
          <ul className="mt-1.5 space-y-1">{diff.map(([k, v]) => (
            <li key={k} className="text-xs"><span className="font-semibold">{PATCH_LABEL[k] || k}</span>: <span className="text-slate-400 line-through">{String(pr.fields[k] ?? '—').slice(0, 40)}</span> → <span className="text-teal-800 dark:text-teal-300">{String(v).slice(0, 120)}</span></li>))}</ul>
          <button type="button" disabled={done} onClick={async () => { await upsertProfile({ ...pr, fields: { ...pr.fields, ...Object.fromEntries(diff) }, updatedBy: by }); setDone(true); }}
            className="mt-2 min-h-[40px] px-3 rounded-xl bg-teal-700 text-white text-sm font-semibold disabled:opacity-50 cursor-pointer">{done ? 'Profile işlendi' : `Profile işle (${diff.length} alan)`}</button>
        </>
      )}
    </section>
  );
}

type Props = {
  onBack: () => void; initial?: string; focusVariety?: string; harvestRecords?: HarvestRecord[]; incidentRecords?: IncidentRecord[]; fieldRecords?: FieldRecord[]; currentUserName?: string; isReadOnly?: boolean; isAdmin?: boolean;
  onStartTest?: (c: { orchard: string; product: string; variety: string }) => void; onOpenCalendar?: () => void; onOpenProfiles?: () => void;
};
type UnitKind = 'ORCHARD' | 'GREENHOUSE' | 'FIELD' | 'EXTERNAL';
const KIND_LABEL: Record<UnitKind, string> = { ORCHARD: 'Bahçeler', GREENHOUSE: 'Seralar', FIELD: 'Açık tarla', EXTERNAL: 'C proje' };
const isC = (fields?: Record<string, unknown>) => /^C proje/i.test(String(fields?.ownership || ''));

/** v49c8 — Bahçe profili: Bahçeler · Seralar · Açık tarla. Yer profillerine eklenen yeni bahçe / sera / tarla burada kendiliğinden görünür. */
export default function OrchardCardsView(p0: Props) {
  const [initOrchard, focusVariety] = (p0.initial || '').split('|');
  const p = { ...p0, initial: initOrchard || undefined, focusVariety: focusVariety || undefined };
  useLocationProfiles();
  const orchardProfiles = useLocationProfiles('ORCHARD'), ghProfiles = useLocationProfiles('GREENHOUSE'), fieldProfiles = useLocationProfiles('FIELD');
  const lists = useMemo(() => {
    const plan = new Map<string, number>();
    for (const r of CAL_SEED_ROWS) if (r.orchard && r.orchard !== '—' && !/ýyladyş/i.test(r.orchard)) plan.set(r.orchard, (plan.get(r.orchard) || 0) + (r.plan2027Ton || 0) + (r.soldTon || 0));
    for (const [n, c] of Object.entries(ORCHARD_CARDS)) plan.set(n, (plan.get(n) || 0) + c.varieties.reduce((s, v) => s + v.plan2027Kg, 0) / 1000);
    for (const pr of orchardProfiles) if (!plan.has(pr.name) && !isC(pr.fields)) plan.set(pr.name, 0);
    const orch = [...plan.entries()].sort((a, b) => b[1] - a[1]).map(([n]) => n);
    const byPlan = (names: string[]) => names.sort((a, b) => ((UNIT_PLANS[b]?.rows.reduce((s, r) => s + r.kg, 0) || 0) - (UNIT_PLANS[a]?.rows.reduce((s, r) => s + r.kg, 0) || 0)) || a.localeCompare(b, 'tr'));
    const gh = byPlan([...new Set([...ghProfiles.map(x => x.name), ...Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'GREENHOUSE').map(([n]) => n)])]);
    const fl = byPlan([...new Set([...fieldProfiles.filter(x => !isC(x.fields)).map(x => x.name), ...Object.entries(UNIT_PLANS).filter(([, u]) => u.kind === 'FIELD').map(([n]) => n)])]);
    const ext = [...new Set([...EXTERNAL_VISITS.map(v => v.name), ...[...orchardProfiles, ...fieldProfiles].filter(x => isC(x.fields)).map(x => x.name)])];
    return { ORCHARD: orch, GREENHOUSE: gh, FIELD: fl, EXTERNAL: ext } as Record<UnitKind, string[]>;
  }, [orchardProfiles, ghProfiles, fieldProfiles]);
  const initKind = (Object.keys(lists) as UnitKind[]).find(k => p.initial && lists[k].includes(p.initial)) || 'ORCHARD';
  const [kind, setKind] = useState<UnitKind>(initKind);
  const [sel, setSel] = useState(p.initial && lists[initKind].includes(p.initial) ? p.initial : lists.ORCHARD[0]);
  const names = lists[kind];
  const cur = names.includes(sel) ? sel : names[0];
  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={p.onBack} aria-label="Geri" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center cursor-pointer">←</button>
        <div className="min-w-0"><h1 className="text-lg font-bold text-slate-900 dark:text-white">Bahçe profili</h1><p className="text-xs text-slate-500">{kind === 'ORCHARD' ? 'Hasat pencereleri · BBCH · rasatlar · tonaj' : kind === 'EXTERNAL' ? 'Bize ait olmayan · sipariş üzerine değerlendirme' : '2027 plan · ay · sınıf'}</p></div>
      </div>
      <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">{(Object.keys(KIND_LABEL) as UnitKind[]).map(k => (
        <button key={k} type="button" onClick={() => { setKind(k); setSel(lists[k][0]); }} className={`min-h-[36px] rounded-lg text-xs font-semibold cursor-pointer ${kind === k ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'}`}>{KIND_LABEL[k]}<span className="hidden sm:inline"> · {lists[k].length}</span></button>))}</div>
      <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">{names.map(n => (
        <button key={n} type="button" onClick={() => setSel(n)} className={`shrink-0 px-3 min-h-[36px] rounded-full text-xs border cursor-pointer ${cur === n ? 'bg-teal-700 text-white border-teal-700' : 'border-slate-300 text-slate-700 bg-white dark:bg-slate-900 dark:text-slate-300'}`}>{n}</button>))}</div>
      {!cur ? <p className="text-sm text-slate-500">Bu türde birim yok. Yer profillerinden ekleyin.</p>
        : kind === 'ORCHARD' ? <OrchardBody key={cur} sel={cur} {...p} /> : kind === 'EXTERNAL' ? <ExternalBody key={cur} name={cur} onOpenProfiles={p.onOpenProfiles} /> : <UnitBody key={cur} name={cur} kind={kind} onOpenProfiles={p.onOpenProfiles} incidentRecords={p.incidentRecords} by={p.currentUserName} readOnly={p.isReadOnly} />}
    </div>
  );
}

function ExternalBody({ name, onOpenProfiles }: { name: string; onOpenProfiles?: () => void }) {
  const pr = findProfile('ORCHARD', name) || findProfile('FIELD', name);
  const f = pr?.fields || {};
  const visits = EXTERNAL_VISITS.filter(v => v.name === name);
  const items = visits.flatMap(v => v.items);
  const trees = items.reduce((s, i) => s + (i.trees || 0), 0), ha = items.reduce((s, i) => s + (i.ha || 0), 0) || Number(f.areaHa) || 0;
  const planT = items.reduce((s, i) => s + (i.planT || 0), 0);
  const hasGeo = Number(f.lat) && Number(f.lon);
  const [open, setOpen] = useState<number | null>(null);
  return (
    <>
      <div className="rounded-2xl border border-violet-200 bg-violet-50 dark:bg-violet-950/30 px-4 py-2.5 text-xs text-violet-900 dark:text-violet-200">
        <b>C proje</b> — bize ait değil; sipariş üzerine değerlendirildi. Plan tonu bahçe sorumlusunun beyanı, kalite tonu bizim tahminimiz (−%30).
      </div>
      <div className="grid grid-cols-2 gap-2">
        {([['Yer', String(f.region || visits[0]?.region || '—'), String(f.contact || visits[0]?.responsible || '')],
          [trees ? 'Ağaç' : 'Alan', trees ? n0(trees) : ha ? `${ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha` : '—', `${visits.length} ziyaret · ${visits.flatMap(v => v.dates).join(', ') || '—'}`],
          ['Beyan edilen plan', planT ? `${n0(planT)} t` : '—', 'bahçe sorumlusu'],
          ['Konum', hasGeo ? `${Number(f.lat).toFixed(4)}, ${Number(f.lon).toFixed(4)}` : 'girilmedi', hasGeo ? 'yer profilinden' : 'Yer profili › Konumumu al']] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 min-w-0"><div className="text-xs text-slate-500">{a}</div><div className={`text-sm font-bold text-slate-900 dark:text-white ${a === 'Konum' && !hasGeo ? 'text-amber-700' : ''}`}>{b}</div><div className="text-[11px] text-slate-500 truncate">{c}</div></div>))}
      </div>
      {!hasGeo && onOpenProfiles && <button type="button" onClick={onOpenProfiles} className="w-full text-left rounded-2xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 cursor-pointer">Konum yok — sahada Yer profilleri › {name} › <b>Konumumu al</b> ile ekleyin ›</button>}
      {visits.map(v => (
        <section key={v.code} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-slate-900 dark:text-white">Ziyaret raporu · {v.dates.join(' / ')}</h2><span className="text-[10px] text-slate-400">{v.code}</span></div>
          <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">{v.basis}</div>
          <div className="text-[11px] text-slate-500">Ekip: {v.team.join(' · ')}</div>
          <div className="text-[11px] text-slate-500">Bahçe sorumlusu: {v.responsible || '—'}</div>
          <div className="grid grid-cols-[minmax(0,1fr)_56px_48px_48px_64px] gap-1 text-[10px] text-slate-500 font-semibold mt-2 border-b border-slate-100 dark:border-slate-800 pb-1"><span>Ürün · çeşit</span><span className="text-right">Ağaç/ha</span><span className="text-right">Plan t</span><span className="text-right">Kalite t</span><span className="text-right">Hasat</span></div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">{v.items.map((it, i) => {
            const k = EXTERNAL_VISITS.indexOf(v) * 100 + i;
            const more = it.note || it.suitability || it.checks;
            return (
              <li key={i}>
                <button type="button" disabled={!more} onClick={() => setOpen(open === k ? null : k)} className="w-full grid grid-cols-[minmax(0,1fr)_56px_48px_48px_64px] gap-1 text-xs tabular-nums py-1.5 text-left cursor-pointer disabled:cursor-default">
                  <span className="min-w-0 truncate"><b>{it.fruit}</b> · {it.variety || '—'}{more ? <ChevronDown className={`w-3 h-3 inline ml-0.5 text-slate-400 ${open === k ? 'rotate-180' : ''}`} /> : null}</span>
                  <span className="text-right">{it.trees ? n0(it.trees) : it.ha ? `${it.ha} ha` : '—'}</span><span className="text-right">{it.planT ?? '—'}</span><span className="text-right">{it.qualityT ?? '—'}</span><span className="text-right truncate">{it.harvest || '—'}</span>
                </button>
                {open === k && (
                  <div className="text-[11px] space-y-1 pb-2 text-slate-700 dark:text-slate-300">
                    {it.note && <p><span className="font-semibold text-slate-500">Gözlem: </span>{it.note}</p>}
                    {it.suitability && <p><span className="font-semibold text-slate-500">Uygunluk / saklama: </span>{it.suitability}</p>}
                    {it.checks && <p className="whitespace-pre-line"><span className="font-semibold text-slate-500">Yapılacak kontroller: </span>{it.checks}</p>}
                  </div>
                )}
              </li>);
          })}</ul>
        </section>
      ))}
      {visits.length === 0 && <p className="text-sm text-slate-500">Bu birim için ziyaret raporu yok. Bilgileri yer profiline girin.</p>}
      <p className="text-[11px] text-slate-500 px-1">Kaynak: {EXTERNAL_SOURCE}. Telefon numaraları uygulamaya yazılmadı; gerekirse yer profilindeki "Sorumlu / iletişim" alanına girin.</p>
    </>
  );
}

function AktList({ place, also, incidents = [], by = '', readOnly }: { place: string; also?: string; incidents?: IncidentRecord[]; by?: string; readOnly?: boolean }) {
  const all = useAllAkts(incidents);
  const list = all.filter(a => a.place === place || (also && a.place === also));
  if (!list.length) return null;
  const openN = list.filter(a => !a.done).length;
  return (
    <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
      <div className="flex items-center justify-between"><h2 className="text-sm font-bold text-slate-900 dark:text-white">Aktlar · {list.length}</h2><span className={`text-[11px] font-semibold ${openN ? 'text-amber-700' : 'text-emerald-700'}`}>{openN ? `${openN} açık` : 'hepsi giderildi'}</span></div>
      <div className="mt-1"><AktRows list={list} by={by} readOnly={readOnly} showPlace={false} /></div>
      <p className="text-[10px] text-slate-400 mt-1">2026 arşivi + platform. Konuya göre özet: Yönetim analizi › Kritik noktalar.</p>
    </section>
  );
}

function UnitBody({ name, kind, onOpenProfiles, incidentRecords = [], by = '', readOnly }: { name: string; kind: UnitKind; onOpenProfiles?: () => void; incidentRecords?: IncidentRecord[]; by?: string; readOnly?: boolean }) {
  const u = UNIT_PLANS[name];
  const pr = findProfile(kind as 'GREENHOUSE' | 'FIELD', name);
  const f = pr?.fields || {};
  const kg = u ? u.rows.reduce((s, r) => s + r.kg, 0) : 0;
  const months = Array.from({ length: 12 }, (_, i) => (u ? u.rows.reduce((s, r) => s + (r.months[i] || 0), 0) : 0));
  const maxM = Math.max(...months, 1);
  const grades: Record<string, number> = {};
  for (const r of u?.rows || []) for (const [g, v] of Object.entries(r.grades)) grades[g] = (grades[g] || 0) + v;
  const ha = Number(f.areaHa) || (u?.crops ? u.crops.reduce((s, c) => s + c.ha, 0) : 0);
  const products = [...new Set((u?.rows || []).map(r => r.product))];
  return (
    <>
      <div className="grid grid-cols-2 gap-2">
        {([['Alan', ha ? `${ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha` : '—', String(f.company || f.region || '')], ['2027 plan', kg ? `${t1(kg)} t` : '—', ha && kg ? `${(kg / 1000 / ha).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} t/ha` : '']] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div></div>))}
      </div>
      {!u && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
          Bu birim için plan verisi yok. {kind === 'GREENHOUSE' ? 'Ürün, alan ve 2027 planını' : 'Ekinleri, alanı ve 2027 planını'} yer profiline girin; Excel ile gelirse sonraki pakette buraya işlenir.
          {onOpenProfiles && <button type="button" onClick={onOpenProfiles} className="block mt-1.5 font-semibold text-teal-800 cursor-pointer">Yer profillerini aç ›</button>}
        </div>
      )}
      {u && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-3">
          <div>
            <div className="text-[11px] font-semibold text-slate-500 mb-1">2027 plan · ay (toplam {t1(kg)} t)</div>
            <div className="grid grid-cols-12 gap-0.5 items-end h-16">{months.map((x, i) => <div key={i} className="bg-teal-600 rounded-sm" style={{ height: x ? `${Math.max(6, (x / maxM) * 100)}%` : 2, opacity: x ? 1 : 0.15 }} title={`${MON[i]} ${t1(x)} t`} />)}</div>
            <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-500 text-center mt-0.5">{MON.map(x => <span key={x}>{x.slice(0, 3)}</span>)}</div>
            <div className="grid grid-cols-12 gap-0.5 text-[9px] text-slate-600 text-center tabular-nums">{months.map((x, i) => <span key={i}>{x ? Math.round(x / 1000) : ''}</span>)}</div>
          </div>
          <div><div className="text-[11px] font-semibold text-slate-500 mb-1">Sınıf dağılımı (plan)</div><GradeBar g={grades} /></div>
          {(products.length > 1 || kind === 'FIELD') && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">Ürün · ekiş (plan)</div>
              {(u.rows || []).sort((a, b) => b.kg - a.kg).map((r, i) => (
                <div key={i} className="flex items-center justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800 last:border-0">
                  <span className="min-w-0 truncate"><b>{r.product}</b> · {r.variety}</span>
                  <span className="tabular-nums shrink-0">{t1(r.kg)} t · {r.months.map((x, mi) => (x ? MON[mi] : '')).filter(Boolean).join(', ')}</span>
                </div>))}
            </div>
          )}
          {u.crops && u.crops.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-500 mb-1">Ekin tablosu (bütçe)</div>
              <div className="grid grid-cols-[minmax(0,1fr)_44px_52px_56px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Ekin</span><span className="text-right">ha</span><span className="text-right">t/ha</span><span className="text-right">Toplam</span></div>
              {u.crops.map((c, i) => (
                <div key={i} className="grid grid-cols-[minmax(0,1fr)_44px_52px_56px] gap-1 text-xs tabular-nums py-0.5"><span className="truncate">{c.name}</span><span className="text-right">{c.ha}</span><span className="text-right">{c.yieldT}</span><span className="text-right">{t1(c.totalKg)} t</span></div>))}
            </div>
          )}
          <p className="text-[11px] text-slate-500">Kaynak: {UNIT_PLAN_SOURCE}{u.crops ? '; ekin tablosu: Açyk ekin býujet 2027' : ''}.</p>
        </section>
      )}
      <AktList place={name} also={kind === 'GREENHOUSE' ? 'Muz seraları' : undefined} incidents={incidentRecords} by={by} readOnly={readOnly} />
    </>
  );
}

function OrchardBody({ sel, focusVariety, harvestRecords = [], fieldRecords = [], incidentRecords = [], currentUserName = '', isReadOnly = false, isAdmin = false, onStartTest, onOpenCalendar }: Props & { sel: string }) {
  const ovs = useCalOverrides();
  const items26 = useMemo(() => buildCalendar(2026, ovs, harvestRecords), [ovs, harvestRecords]);
  const items27 = useMemo(() => buildCalendar(2027, ovs, harvestRecords), [ovs, harvestRecords]);
  const card = ORCHARD_CARDS[sel];
  const models = useMemo(() => buildModels(sel, items26, items27), [sel, items26, items27]);
  const axis = useMemo(() => {
    const ts = models.flatMap(m => [m.it26?.start, m.it26?.end, m.it26?.windowStart, m.it26?.windowEnd, m.it27?.windowStart, m.it27?.windowEnd]).filter((t): t is number => !!t).map(doy);
    if (!ts.length) return { a: 120, b: 320 };
    return { a: Math.max(0, Math.min(...ts) - 7), b: Math.min(366, Math.max(...ts) + 7) };
  }, [models]);
  const months = useMemo(() => { const out: { l: string; x: number }[] = []; for (let mo = 0; mo < 12; mo++) { const d = doy(Date.UTC(2027, mo, 1)); if (d >= axis.a && d <= axis.b) out.push({ l: MON[mo], x: ((d - axis.a) / (axis.b - axis.a)) * 100 }); } return out; }, [axis]);
  const tot = useMemo(() => {
    const a = models.reduce((s, m) => s + m.a26.kg, 0), p = models.reduce((s, m) => s + m.plan27, 0);
    const withCal = models.filter(m => m.it27), bloom = withCal.filter(m => m.it27?.ov?.bbch?.['65']).length;
    const agac = card?.parcels.reduce((s, x) => s + x.agac, 0) || 0, ha = card?.parcels.reduce((s, x) => s + x.ha, 0) || 0;
    const noActual = models.filter(m => !m.a26.kg && m.plan27 > 5000);
    return { a, p, bloom, cal: withCal.length, agac, ha, noActual };
  }, [models, card]);
  const fruits = [...new Set(models.map(m => m.fruit))];
  const ctx = { by: currentUserName, readOnly: isReadOnly, fieldRecords, onStartTest };
  return (
    <>

      <div className="grid grid-cols-2 gap-2">
        {([
          ['Ağaç · alan', card?.parcels.length ? n0(tot.agac) : '—', card?.parcels.length ? `${tot.ha.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} ha · ${card.parcels.length} parsel satırı` : 'parsel bilgisi yok'],
          ['Çeşit', String(models.length), `${tot.cal} çeşit hasat takviminde`],
          ['2026 gerçekleşen', `${t1(tot.a)} t`, card?.varieties.some(v => v.actual2026Kg > 0) ? 'hasat fişleri + Gantt' : 'Gantt (satylan)'],
          ['2027 plan', `${t1(tot.p)} t`, tot.a ? `${tot.p >= tot.a ? '+' : ''}${Math.round(((tot.p - tot.a) / tot.a) * 100)}% 2026'ya göre` : ''],
        ] as const).map(([a, b, c]) => (
          <div key={a} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3"><div className="text-xs text-slate-500">{a}</div><div className="text-lg font-bold tabular-nums text-slate-900 dark:text-white">{b}</div><div className="text-[11px] text-slate-500">{c}</div></div>))}
      </div>

      {card?.parcels.some(x => x.firma) && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-1">Firmaya göre ağaç</h2>
          <div className="grid grid-cols-[minmax(0,1fr)_64px_52px_40px] gap-1 text-[10px] text-slate-500 font-semibold"><span>Firma · çeşit</span><span className="text-right">Ağaç</span><span className="text-right">ha</span><span className="text-right">Prs</span></div>
          {[...new Set(card.parcels.map(x => x.firma || '—'))].map(fm => { const ps = card.parcels.filter(x => (x.firma || '—') === fm); return (
            <div key={fm} className="grid grid-cols-[minmax(0,1fr)_64px_52px_40px] gap-1 text-xs tabular-nums py-0.5"><span className="truncate"><b>{fm}</b> · {[...new Set(ps.map(x => x.cesit))].join(', ')}</span><span className="text-right">{n0(ps.reduce((s, x) => s + x.agac, 0))}</span><span className="text-right">{Math.round(ps.reduce((s, x) => s + x.ha, 0))}</span><span className="text-right">{ps.length}</span></div>); })}
        </section>
      )}
      <div className={`rounded-2xl border px-4 py-2.5 text-xs flex gap-2 ${tot.bloom < tot.cal ? 'border-pink-200 bg-pink-50 text-pink-900' : 'border-emerald-200 bg-emerald-50 text-emerald-900'}`}><Flower2 className="w-4 h-4 shrink-0 mt-0.5" />
        <span>2027 çiçeklenme (BBCH 65) girildi: <b className="tabular-nums">{tot.bloom} / {tot.cal}</b> çeşit. Girilen çeşitte pencere "BBCH 65 + gün" ile, girilmeyende geçmiş yılların ortalamasıyla hesaplanır.</span></div>
      {tot.noActual.length > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>2027 planı olup 2026 hasadı bulunmayan: <b>{tot.noActual.map(m => m.name).join(', ')}</b></span></div>
      )}

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3">
        <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><CalendarRange className="w-4 h-4 text-teal-700" />Hasat pencereleri 2026 · 2027</h2>
          {onOpenCalendar && <button type="button" onClick={onOpenCalendar} className="text-[11px] font-semibold text-teal-700 cursor-pointer">Hasat takvimi ›</button>}</div>
        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-slate-500">
          <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-slate-300 inline-block" />2026 penceresi</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-full bg-slate-600 inline-block" />2026 gerçek hasat</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-full border border-teal-600 bg-teal-100 inline-block" />2027 tahmini</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-pink-500 inline-block" />2027 çiçek</span>
        </div>
        <div className="relative h-4 mt-2 text-[9px] text-slate-400">{months.map(mo => <span key={mo.l} className="absolute -translate-x-1/2" style={{ left: `${mo.x}%` }}>{mo.l}</span>)}</div>
        {fruits.map(f => (
          <div key={f} className="mt-1">
            <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 pt-1.5 border-t border-slate-100 dark:border-slate-800"><TreeDeciduous className="w-3.5 h-3.5 text-teal-700" />{f}</div>
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">{models.filter(m => m.fruit === f).map(m => <VarietyItem key={sel + m.key} m={m} orchard={sel} parcels={card?.parcels || []} axis={axis} ctx={ctx} focus={!!focusVariety && vkey(focusVariety) === m.key} />)}</ul>
          </div>
        ))}
      </section>

      <AktList place={sel} incidents={incidentRecords} by={currentUserName} readOnly={isReadOnly} />
      {isAdmin && !isReadOnly && <ProfileSync orchard={sel} models={models} by={currentUserName} />}

      <p className="text-[11px] text-slate-500 px-1">Kaynaklar ayrı tutulur: parseller/ağaç — {ORCHARD_SOURCES.parcels}; 2026 — {ORCHARD_SOURCES.actual2026}, yoksa Gantt "satylan"; 2027 plan — {ORCHARD_SOURCES.plan2027}; BBCH ve pencereler — hasat takvimi (girdiğiniz tarihler). Bir çeşide dokun: BBCH adımları, rasatlar, parseller, sınıf dağılımı.</p>
    </>
  );
}
