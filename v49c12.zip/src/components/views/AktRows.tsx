import React, { useState } from 'react';
import { Check, CircleDot } from 'lucide-react';
import { setAktStatus, type AktRow } from '../../services/aktStatus';

/** v49c12 — akt satırı: tarih · yer · konu · durum (arşiv aktında "Giderildi" işaretlenebilir) */
export default function AktRows({ list, by, readOnly, showPlace = true }: { list: AktRow[]; by: string; readOnly?: boolean; showPlace?: boolean }) {
  const [busy, setBusy] = useState<string | null>(null);
  return (
    <ul className="space-y-1">{list.map(a => (
      <li key={a.source + a.no} className="flex items-start gap-2 text-[11px] text-slate-700 dark:text-slate-300">
        <span className="tabular-nums text-slate-500 shrink-0 w-10 pt-0.5">{a.d ? `${a.d.slice(8, 10)}.${a.d.slice(5, 7)}` : '—'}</span>
        <span className="min-w-0 flex-1 pt-0.5">{showPlace && <b>{a.place}</b>}{a.product ? `${showPlace ? ' · ' : ''}${a.product}` : ''}{showPlace || a.product ? ' — ' : ''}{a.summary || a.name}{a.source === 'platform' ? <span className="ml-1 text-[10px] text-sky-700">(platform)</span> : null}</span>
        {a.source === 'arşiv' && !readOnly ? (
          <button type="button" disabled={busy === a.no} onClick={async () => { setBusy(a.no); await setAktStatus(a.no, !a.done, by); setBusy(null); }}
            className={`shrink-0 inline-flex items-center gap-1 px-2 min-h-[28px] rounded-full border text-[10px] font-semibold cursor-pointer ${a.done ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-white text-amber-800 border-amber-300 dark:bg-slate-900'}`}>
            {a.done ? <><Check className="w-3 h-3" />Giderildi</> : <><CircleDot className="w-3 h-3" />Açık</>}
          </button>
        ) : (
          <span className={`shrink-0 px-2 py-0.5 rounded-full border text-[10px] font-semibold ${a.done ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'}`}>{a.done ? 'Giderildi' : 'Açık'}</span>
        )}
      </li>))}</ul>
  );
}
