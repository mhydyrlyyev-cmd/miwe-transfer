import React, { useState, useMemo } from 'react';
import DemoBadge from '../common/DemoBadge';
import {
  Award,
  BarChart3,
  CheckCircle2,
  ChevronRight,
  Filter,
  Layers,
  LayoutGrid,
  RotateCcw,
  Search,
  ShieldCheck,
  Star,
  UserCheck,
  Users,
  AlertTriangle,
  ArrowUpRight,
  Sliders,
  X,
  Save,
  Check,
  TrendingUp,
  FileText,
  Building2,
  Briefcase,
  Target,
  Sparkles,
  RefreshCw,
  Info,
  Download,
  Calendar
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { useTranslation } from '../../context/LanguageContext';
import { recordCentralAuditLog } from '../../utils/syncService';
import { useToast } from '../../context/ToastContext';

export interface DepartmentScoringPortalProps {
  onBackToMainApp: () => void;
  currentUser?: any;
}

export type DeptCategory = 'QUALITY' | 'PRODUCTION' | 'AGRONOMY' | 'SALES' | 'MANAGEMENT';

export interface QualityKPI {
  id: string;
  nameKey: string;
  defaultName: string;
  score: number; // 0 - 100
  targetScore: number;
  weight: number; // e.g. 0.25
  unit: string;
  description: string;
}

export interface DepartmentRoleCard {
  id: string;
  department: DeptCategory;
  roleTitleKey: string;
  defaultRoleTitle: string;
  personName: string;
  overallScore: number;
  kpis: QualityKPI[];
  peerScores: Record<DeptCategory, number>; // Scores assigned by peer departments
  lastEvaluated: string;
  evaluatorNotes: string;
  status: 'EXCELLENT' | 'OPTIMAL' | 'NEEDS_IMPROVEMENT';
}

const INITIAL_ROLE_CARDS: DepartmentRoleCard[] = [
  {
    id: 'ROLE-QC-01',
    department: 'QUALITY',
    roleTitleKey: 'dept.role.qaLead',
    defaultRoleTitle: 'Kalite Güvence & Lab Lideri',
    personName: 'Sistem Sorumlusu',
    overallScore: 94,
    status: 'EXCELLENT',
    lastEvaluated: '2026-10-07',
    evaluatorNotes: 'Laboratuvar Brix ve kalıntı analiz hassasiyeti %99.2 seviyesinde. Soğuk zincir ihlal raporlaması anlık yapıldı.',
    peerScores: {
      QUALITY: 96,
      PRODUCTION: 92,
      AGRONOMY: 95,
      SALES: 93,
      MANAGEMENT: 94
    },
    kpis: [
      { id: 'kpi-1', nameKey: 'kpi.brixPrecision', defaultName: 'Brix & Sertlik Ölçüm İsabeti', score: 96, targetScore: 95, weight: 0.3, unit: '%', description: 'Fabrika ve saha refraktometre doğruluk toleransı' },
      { id: 'kpi-2', nameKey: 'kpi.shelfLifePredict', defaultName: 'Raf Ömrü Tahmin Doğruluğu', score: 92, targetScore: 90, weight: 0.25, unit: '%', description: 'Depolama simülasyonu ile reel raf ömrü uyumu' },
      { id: 'kpi-3', nameKey: 'kpi.defectAnalysisSpeed', defaultName: 'Fire & İade Analiz Hızı', score: 95, targetScore: 90, weight: 0.25, unit: 'dk', description: 'Gelen uyumsuz parti inceleme ve kök neden raporlama süresi' },
      { id: 'kpi-4', nameKey: 'kpi.certCompliance', defaultName: 'GlobalGAP & ISO Standart Uyumu', score: 93, targetScore: 95, weight: 0.2, unit: '%', description: 'Uluslararası denetim ve pestisit kalıntı uygunluğu' }
    ]
  },
  {
    id: 'ROLE-PROD-01',
    department: 'PRODUCTION',
    roleTitleKey: 'dept.role.lineChief',
    defaultRoleTitle: 'Paketleme & Tasnif Şefi',
    personName: 'Ahmet Kaya',
    overallScore: 89,
    status: 'OPTIMAL',
    lastEvaluated: '2026-10-06',
    evaluatorNotes: 'Kasa içi kalibre homojenliği yüksek. İkinci kalite meyve ayırma hızı beklentileri karşıladı.',
    peerScores: {
      QUALITY: 88,
      PRODUCTION: 92,
      AGRONOMY: 87,
      SALES: 90,
      MANAGEMENT: 88
    },
    kpis: [
      { id: 'kpi-5', nameKey: 'kpi.sortingAccuracy', defaultName: 'Boylama & Kalibre Doğruluğu', score: 90, targetScore: 92, weight: 0.3, unit: '%', description: 'Elektronik ve manuel boylama tolerans oranı' },
      { id: 'kpi-6', nameKey: 'kpi.crateDamageRate', defaultName: 'Ambalaj & Kasa Hasar Kontrolü', score: 94, targetScore: 95, weight: 0.25, unit: '%', description: 'Paketleme hattındaki meyve zedelenme sıfırlaması' },
      { id: 'kpi-7', nameKey: 'kpi.lineThroughput', defaultName: 'Hat Saatlik Tonaj Verimi', score: 87, targetScore: 85, weight: 0.25, unit: 'ton/saat', description: 'Birim zamanda işlenen onaylı paketli meyve tonajı' },
      { id: 'kpi-8', nameKey: 'kpi.salvageYield', defaultName: 'Fire/Salvage Ayrıştırma Oranı', score: 85, targetScore: 88, weight: 0.2, unit: '%', description: 'İkinci kalite meyvenin püre/Freeze-Dry hattına iletim oranı' }
    ]
  },
  {
    id: 'ROLE-AGRO-01',
    department: 'AGRONOMY',
    roleTitleKey: 'dept.role.fieldEngineer',
    defaultRoleTitle: 'Saha Sorumlu Ziraat Mühendisi',
    personName: 'Mehmet Demir',
    overallScore: 91,
    status: 'OPTIMAL',
    lastEvaluated: '2026-10-07',
    evaluatorNotes: 'Parsel Brix takibi ve optimum hasat penceresi zamanlaması başarıyla uygulandı.',
    peerScores: {
      QUALITY: 93,
      PRODUCTION: 89,
      AGRONOMY: 94,
      SALES: 88,
      MANAGEMENT: 91
    },
    kpis: [
      { id: 'kpi-9', nameKey: 'kpi.harvestTiming', defaultName: 'Optimum Hasat Zamanlaması', score: 94, targetScore: 92, weight: 0.3, unit: '%', description: 'Meyve olgunlaşma eğrisi ile toplama günü çakışması' },
      { id: 'kpi-10', nameKey: 'kpi.pesticideSafety', defaultName: 'Pestisit & Kalıntı Güvenliği', score: 96, targetScore: 98, weight: 0.3, unit: '%', description: 'Son ilaçlama ile hasat arası bekleme süresi disiplini' },
      { id: 'kpi-11', nameKey: 'kpi.yieldPrecision', defaultName: 'Parsel Tonaj Tahmin İsabeti', score: 86, targetScore: 90, weight: 0.2, unit: '%', description: 'Saha tahmini ile kantar kabul tonajı sapma oranı' },
      { id: 'kpi-12', nameKey: 'kpi.soilIrrigation', defaultName: 'Sulama & Besleme Uyumu', score: 88, targetScore: 88, weight: 0.2, unit: '%', description: 'Toprak nem ve besin elementi yönetim performansı' }
    ]
  },
  {
    id: 'ROLE-SALES-01',
    department: 'SALES',
    roleTitleKey: 'dept.role.exportManager',
    defaultRoleTitle: 'İhracat & Müşteri Şartname Yöneticisi',
    personName: 'Zeynep Arslan',
    overallScore: 90,
    status: 'OPTIMAL',
    lastEvaluated: '2026-10-05',
    evaluatorNotes: 'Dubai ve Rusya sevkiyat şartnameleri eksiksiz iletildi. Müşteri geri bildirim süresi çok hızlı.',
    peerScores: {
      QUALITY: 91,
      PRODUCTION: 88,
      AGRONOMY: 89,
      SALES: 95,
      MANAGEMENT: 87
    },
    kpis: [
      { id: 'kpi-13', nameKey: 'kpi.orderSpecMatch', defaultName: 'Müşteri Şartname Uyum Oranı', score: 92, targetScore: 95, weight: 0.35, unit: '%', description: 'Sipariş spesifikasyonu ile paketlenen ürün eşleşmesi' },
      { id: 'kpi-14', nameKey: 'kpi.otifDelivery', defaultName: 'Zamanında & Eksiksiz Sevkiyat (OTIF)', score: 90, targetScore: 92, weight: 0.25, unit: '%', description: 'Müşteriye varış süresi ve koli adedi tutarlılığı' },
      { id: 'kpi-15', nameKey: 'kpi.claimResolution', defaultName: 'Müşteri Kalite İtiraz Çözüm Hızı', score: 88, targetScore: 85, weight: 0.2, unit: 'saat', description: 'Kalite itirazlarının incelenip sonuca bağlanma süresi' },
      { id: 'kpi-16', nameKey: 'kpi.stockRotation', defaultName: 'Soğuk Depo Stok Yaşlandırma Kontrolü', score: 89, targetScore: 90, weight: 0.2, unit: '%', description: 'FIFO prensibiyle ilk giren ürünün ilk satılması' }
    ]
  },
  {
    id: 'ROLE-MGMT-01',
    department: 'MANAGEMENT',
    roleTitleKey: 'dept.role.opsDirector',
    defaultRoleTitle: 'Operasyon & Sürdürülebilirlik Direktörü',
    personName: 'Engin Öztürk',
    overallScore: 93,
    status: 'EXCELLENT',
    lastEvaluated: '2026-10-08',
    evaluatorNotes: 'Bölümler arası koordinasyon yüksek. Freeze-Dry ve ikincil ürün dönüştürme stratejisi kârlılığı artırdı.',
    peerScores: {
      QUALITY: 94,
      PRODUCTION: 91,
      AGRONOMY: 92,
      SALES: 93,
      MANAGEMENT: 95
    },
    kpis: [
      { id: 'kpi-17', nameKey: 'kpi.crossDeptComm', defaultName: 'Bölümler Arası İletişim & Veri Akışı', score: 95, targetScore: 90, weight: 0.3, unit: '%', description: 'Anlık portal kullanımı ve veri doğrulama disiplini' },
      { id: 'kpi-18', nameKey: 'kpi.salvageInnovation', defaultName: 'Dönüştürme & Freeze-Dry Stratejisi', score: 94, targetScore: 88, weight: 0.3, unit: '%', description: 'Fire meyvenin katma değerli işleme yönlendirilmesi' },
      { id: 'kpi-19', nameKey: 'kpi.targetAttainment', defaultName: 'Genel Kalite & Bütçe Hedef Uyumu', score: 90, targetScore: 92, weight: 0.2, unit: '%', description: 'Yıllık kalite KPI ve maliyet hedeflerine ulaşma' },
      { id: 'kpi-20', nameKey: 'kpi.sustainabilityScore', defaultName: 'Karbon Ayak İzi & Sıfır Atık Skoru', score: 92, targetScore: 90, weight: 0.2, unit: '%', description: 'Atık geri dönüşüm ve ambalaj sürdürülebilirliği' }
    ]
  }
];

export const DepartmentScoringPortal: React.FC<DepartmentScoringPortalProps> = ({
  onBackToMainApp,
  currentUser
}) => {
  const { t } = useTranslation();
  const { showSuccess, showWarning, showInfo } = useToast();

  const [roleCards, setRoleCards] = useState<DepartmentRoleCard[]>(() => {
    const saved = localStorage.getItem('miwe_dept_role_cards');
    return saved ? JSON.parse(saved) : INITIAL_ROLE_CARDS;
  });

  const [selectedDeptFilter, setSelectedDeptFilter] = useState<DeptCategory | 'ALL'>('ALL');
  const [activeViewMode, setActiveViewMode] = useState<'GRID' | 'CROSS_MATRIX' | 'COMPARISON'>('GRID');
  const [searchTerm, setSearchTerm] = useState('');

  // Editing state for 'Update' and 'Cancel' operations
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [draftCardState, setDraftCardState] = useState<DepartmentRoleCard | null>(null);

  // New Cross-Department Evaluation Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [evaluatorDept, setEvaluatorDept] = useState<DeptCategory>('QUALITY');
  const [targetRoleId, setTargetRoleId] = useState<string>(roleCards[0]?.id || '');
  const [evalScoreInput, setEvalScoreInput] = useState<number>(90);
  const [evalNotesInput, setEvalNotesInput] = useState<string>('');

  // Persist roleCards changes
  const saveCards = (updated: DepartmentRoleCard[]) => {
    setRoleCards(updated);
    try {
      localStorage.setItem('miwe_dept_role_cards', JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save role cards:', e);
    }
  };

  // Start editing a card
  const handleStartEdit = (card: DepartmentRoleCard) => {
    setEditingCardId(card.id);
    setDraftCardState(JSON.parse(JSON.stringify(card))); // deep clone draft
  };

  // Cancel edit operation
  const handleCancelEdit = () => {
    setEditingCardId(null);
    setDraftCardState(null);
    showInfo(t('dept.cancelMsg') || 'Düzenleme iptal edildi, değişiklikler geri alındı.', 'İptal Edildi');
  };

  // Update KPI score in draft
  const handleKPIChangeInDraft = (kpiId: string, newScore: number) => {
    if (!draftCardState) return;
    const updatedKPIs = draftCardState.kpis.map((k) =>
      k.id === kpiId ? { ...k, score: Math.min(100, Math.max(0, newScore)) } : k
    );

    // Recalculate weighted overall score
    let weightedSum = 0;
    let totalWeight = 0;
    updatedKPIs.forEach((k) => {
      weightedSum += k.score * k.weight;
      totalWeight += k.weight;
    });
    const newOverall = totalWeight > 0 ? Math.round(weightedSum / totalWeight) : draftCardState.overallScore;

    let newStatus: 'EXCELLENT' | 'OPTIMAL' | 'NEEDS_IMPROVEMENT' = 'OPTIMAL';
    if (newOverall >= 92) newStatus = 'EXCELLENT';
    else if (newOverall < 85) newStatus = 'NEEDS_IMPROVEMENT';

    setDraftCardState({
      ...draftCardState,
      kpis: updatedKPIs,
      overallScore: newOverall,
      status: newStatus
    });
  };

  // Save/Update edit operation
  const handleSaveEdit = () => {
    if (!draftCardState) return;

    const updated = roleCards.map((card) => (card.id === draftCardState.id ? { ...draftCardState, lastEvaluated: new Date().toISOString().split('T')[0] } : card));
    saveCards(updated);

    recordCentralAuditLog(
      currentUser?.name || 'Operatör',
      currentUser?.role || 'Kullanıcı',
      'DEPARTMENT_SCORING',
      `Departman KPI Puanı Güncellendi: ${draftCardState.defaultRoleTitle} (Skor: ${draftCardState.overallScore})`,
      draftCardState.id
    );

    showSuccess(
      `${draftCardState.defaultRoleTitle} skoru ${draftCardState.overallScore}/100 olarak güncellendi ve kaydedildi.`,
      'Güncelleme Başarılı'
    );

    setEditingCardId(null);
    setDraftCardState(null);
  };

  // Submit cross-department evaluation
  const handleAddCrossEvaluation = (e: React.FormEvent) => {
    e.preventDefault();
    const target = roleCards.find((r) => r.id === targetRoleId);
    if (!target) return;

    const newPeerScores = {
      ...target.peerScores,
      [evaluatorDept]: evalScoreInput
    };

    // Recalculate peer average
    const vals = Object.values(newPeerScores);
    const avgPeer = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);

    // Combine with KPI score for overall
    const updatedOverall = Math.round(target.overallScore * 0.6 + avgPeer * 0.4);

    const updatedCard: DepartmentRoleCard = {
      ...target,
      peerScores: newPeerScores,
      overallScore: updatedOverall,
      lastEvaluated: new Date().toISOString().split('T')[0],
      evaluatorNotes: evalNotesInput || target.evaluatorNotes
    };

    const updatedList = roleCards.map((c) => (c.id === targetRoleId ? updatedCard : c));
    saveCards(updatedList);

    recordCentralAuditLog(
      currentUser?.name || 'Operatör',
      currentUser?.role || 'Kullanıcı',
      'DEPARTMENT_SCORING',
      `Çapraz Puanlama: ${evaluatorDept} -> ${target.defaultRoleTitle} (${evalScoreInput} Puan)`,
      targetRoleId
    );

    showSuccess('Çapraz departman değerlendirmesi başarıyla sisteme işlendi.', 'Puan Kaydedildi');
    setIsModalOpen(false);
    setEvalNotesInput('');
  };

  // Reset all scores to default baseline
  const handleResetToBaseline = () => {
    if (window.confirm('Tüm departman performans puanlarını varsayılan fabrika ayarlarına sıfırlamak istediğinize emin misiniz?')) {
      saveCards(INITIAL_ROLE_CARDS);
      showInfo('Tüm departman yetenek ve KPI puanları varsayılan başlangıç seviyesine döndürüldü.', 'Sıfırlandı');
    }
  };

  // Filtered Cards
  const filteredCards = useMemo(() => {
    return roleCards.filter((card) => {
      const matchDept = selectedDeptFilter === 'ALL' || card.department === selectedDeptFilter;
      const matchSearch =
        card.defaultRoleTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
        card.personName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        card.kpis.some((k) => k.defaultName.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchDept && matchSearch;
    });
  }, [roleCards, selectedDeptFilter, searchTerm]);

  // High level KPIs
  const overallAgroIndex = useMemo(() => {
    if (roleCards.length === 0) return 0;
    const sum = roleCards.reduce((acc, c) => acc + c.overallScore, 0);
    return (sum / roleCards.length).toFixed(1);
  }, [roleCards]);

  const topDept = useMemo<DepartmentRoleCard | null>(() => {
    if (roleCards.length === 0) return null;
    const sorted = [...roleCards].sort((a, b) => b.overallScore - a.overallScore);
    return sorted[0] || null;
  }, [roleCards]);

  const deptColorMap: Record<DeptCategory, { bg: string; text: string; border: string; badge: string }> = {
    QUALITY: { bg: 'bg-emerald-500/10 dark:bg-emerald-950/30', text: 'text-emerald-700 dark:text-emerald-400', border: 'border-emerald-200 dark:border-emerald-800', badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300' },
    PRODUCTION: { bg: 'bg-amber-500/10 dark:bg-amber-950/30', text: 'text-amber-700 dark:text-amber-400', border: 'border-amber-200 dark:border-amber-800', badge: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300' },
    AGRONOMY: { bg: 'bg-lime-500/10 dark:bg-lime-950/30', text: 'text-lime-700 dark:text-lime-400', border: 'border-lime-200 dark:border-lime-800', badge: 'bg-lime-100 text-lime-800 dark:bg-lime-900/50 dark:text-lime-300' },
    SALES: { bg: 'bg-sky-500/10 dark:bg-sky-950/30', text: 'text-sky-700 dark:text-sky-400', border: 'border-sky-200 dark:border-sky-800', badge: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-300' },
    MANAGEMENT: { bg: 'bg-indigo-500/10 dark:bg-indigo-950/30', text: 'text-indigo-700 dark:text-indigo-400', border: 'border-indigo-200 dark:border-indigo-800', badge: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/50 dark:text-indigo-300' }
  };

  const getDeptTitle = (dept: DeptCategory) => {
    switch (dept) {
      case 'QUALITY': return t('dept.quality') || 'Kalite Güvence & Lab';
      case 'PRODUCTION': return t('dept.production') || 'Üretim & Paketleme';
      case 'AGRONOMY': return t('dept.agronomy') || 'Agronomi & Saha';
      case 'SALES': return t('dept.sales') || 'Satış & Sevkiyat';
      case 'MANAGEMENT': return t('dept.management') || 'Yönetim & Ar-Ge';
      default: return dept;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 p-4 md:p-6 lg:p-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* HEADER BAR */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200/80 dark:border-slate-700/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                PLATFORM #03
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                {t('dept.badgeSubtitle') || 'Bölümler Arası Kalite & Operasyonel Değerlendirme'}
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
              {t('dept.portalTitle') || 'Sorumluluk Puanlama & Departman Değerlendirme Modülü'}
              <DemoBadge note="örnek puanlar" />
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-3xl">
              {t('dept.portalSubtitle') || 'Kalite, Üretim, Agronomi, Satış ve Yönetim departmanlarının birbirlerinin performansını meyve kalitesi, Brix hassasiyeti ve şartname uyum KPI’ları üzerinden ölçtüğü taktiksel değerlendirme matrisi.'}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap self-start md:self-auto">
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium shadow-sm transition-all hover:shadow duration-150"
            >
              <Sparkles className="w-4 h-4" />
              {t('dept.btnNewEval') || 'Çapraz Puan Ekle'}
            </button>

            <button
              onClick={() => window.print()}
              title="Departman Performans Raporunu PDF Olarak Yazdır / İndir"
              className="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 rounded-xl text-sm font-medium shadow-sm transition-all duration-150"
            >
              <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>PDF Rapor İndir</span>
            </button>
            
            <button
              onClick={handleResetToBaseline}
              title="Skorları Başlangıca Sıfırla"
              className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors border border-slate-200 dark:border-slate-700"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            <button
              onClick={onBackToMainApp}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-xl text-sm font-medium transition-colors"
            >
              ← {t('btn.back') || 'Ana Panele Dön'}
            </button>
          </div>
        </div>

        {/* TOP KPI OVERVIEW CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {t('dept.kpiOverallIndex') || 'Agrologistics Yetkinlik Endeksi'}
              </span>
              <div className="text-2xl font-bold text-slate-900 dark:text-white flex items-baseline gap-1">
                <span>{overallAgroIndex}</span>
                <span className="text-xs text-slate-400">/ 100</span>
              </div>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> %2.4 Hedef Üstü Performans
              </p>
            </div>
            <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Award className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {t('dept.kpiTopRole') || 'En Yüksek Skora Sahip Lider'}
              </span>
              <div className="text-lg font-bold text-slate-900 dark:text-white truncate max-w-[180px]">
                {topDept?.personName || '-'}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {topDept ? `${topDept.defaultRoleTitle} (${topDept.overallScore} Puan)` : '-'}
              </p>
            </div>
            <div className="p-3 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl">
              <Star className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {t('dept.kpiTotalRoles') || 'Aktif Değerlendirilen Birimler'}
              </span>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {roleCards.length} <span className="text-xs font-normal text-slate-500">Departman</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                5 Temel Operasyonel Rol
              </p>
            </div>
            <div className="p-3 bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-xl">
              <Users className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {t('dept.kpiAuditStatus') || 'Kalite Onay & Uyum Statusu'}
              </span>
              <div className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> %100 Çapraz Denetlendi
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Son Güncelleme: Bugun
              </p>
            </div>
            <div className="p-3 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* CONTROLS & FILTER TABS */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 shadow-sm border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Department Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            <button
              onClick={() => setSelectedDeptFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'ALL'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Tüm Departmanlar ({roleCards.length})
            </button>
            <button
              onClick={() => setSelectedDeptFilter('QUALITY')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'QUALITY'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Kalite & Lab
            </button>
            <button
              onClick={() => setSelectedDeptFilter('PRODUCTION')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'PRODUCTION'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Üretim & Paketleme
            </button>
            <button
              onClick={() => setSelectedDeptFilter('AGRONOMY')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'AGRONOMY'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Agronomi & Saha
            </button>
            <button
              onClick={() => setSelectedDeptFilter('SALES')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'SALES'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Satış & Sevkiyat
            </button>
            <button
              onClick={() => setSelectedDeptFilter('MANAGEMENT')}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedDeptFilter === 'MANAGEMENT'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Yönetim & Ar-Ge
            </button>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 md:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={t('dept.searchPlaceholder') || 'Rol veya KPI ara...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setActiveViewMode('GRID')}
                className={`p-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                  activeViewMode === 'GRID'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="Taktiksel Matris Grid"
              >
                <LayoutGrid className="w-4 h-4" />
                <span className="hidden sm:inline">Grid</span>
              </button>
              <button
                onClick={() => setActiveViewMode('CROSS_MATRIX')}
                className={`p-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                  activeViewMode === 'CROSS_MATRIX'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="Çapraz Değerlendirme Matrisi"
              >
                <Layers className="w-4 h-4" />
                <span className="hidden sm:inline">Matris</span>
              </button>
              <button
                onClick={() => setActiveViewMode('COMPARISON')}
                className={`p-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                  activeViewMode === 'COMPARISON'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="KPI Performans Kıyaslama"
              >
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">Kıyas</span>
              </button>
            </div>

          </div>
        </div>

        {/* MAIN VIEW CONTENT */}
        {activeViewMode === 'GRID' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCards.map((card) => {
              const style = deptColorMap[card.department];
              const isEditing = editingCardId === card.id;
              const activeCardState = isEditing && draftCardState ? draftCardState : card;

              return (
                <div
                  key={card.id}
                  className={`bg-white dark:bg-slate-800 rounded-2xl border transition-all duration-200 shadow-sm hover:shadow-md flex flex-col justify-between overflow-hidden ${
                    isEditing ? 'ring-2 ring-emerald-500 border-emerald-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {/* CARD HEADER */}
                  <div className={`p-5 border-b ${style.border} ${style.bg} space-y-3`}>
                    <div className="flex items-start justify-between gap-2">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${style.badge}`}>
                        {getDeptTitle(card.department)}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <span className={`text-2xl font-black ${style.text}`}>
                          {activeCardState.overallScore}
                        </span>
                        <span className="text-xs text-slate-400 font-normal">/100</span>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Briefcase className="w-4 h-4 text-slate-500" />
                        {activeCardState.defaultRoleTitle}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        Sorumlu: <span className="text-slate-800 dark:text-slate-200 font-semibold">{activeCardState.personName}</span>
                      </p>
                    </div>
                  </div>

                  {/* CARD BODY: QUALITY KPIS & PROGRESS BARS */}
                  <div className="p-5 space-y-4 flex-1">
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                      <span>Kalite & Operasyonel KPI'lar</span>
                      {isEditing && <span className="text-emerald-600 dark:text-emerald-400 animate-pulse">Düzenleme Modu</span>}
                    </div>

                    <div className="space-y-3">
                      {activeCardState.kpis.map((kpi) => (
                        <div key={kpi.id} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-medium text-slate-700 dark:text-slate-300 truncate max-w-[200px]" title={kpi.description}>
                              {kpi.defaultName}
                            </span>
                            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                              {kpi.score} {kpi.unit}
                            </span>
                          </div>

                          {isEditing ? (
                            <div className="flex items-center gap-2 pt-1">
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={kpi.score}
                                onChange={(e) => handleKPIChangeInDraft(kpi.id, Number(e.target.value))}
                                className="w-full accent-emerald-600 h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                              />
                              <input
                                type="number"
                                min="0"
                                max="100"
                                value={kpi.score}
                                onChange={(e) => handleKPIChangeInDraft(kpi.id, Number(e.target.value))}
                                className="w-12 px-1 py-0.5 text-xs text-center border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-900 font-mono"
                              />
                            </div>
                          ) : (
                            <div className="w-full bg-slate-100 dark:bg-slate-700/60 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-full transition-all duration-300 rounded-full ${
                                  kpi.score >= kpi.targetScore
                                    ? 'bg-emerald-500'
                                    : kpi.score >= 80
                                    ? 'bg-amber-500'
                                    : 'bg-rose-500'
                                }`}
                                style={{ width: `${Math.min(100, kpi.score)}%` }}
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* INTER-DEPARTMENT PEER REVIEWS */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 space-y-2">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Bölümler Arası Değerlendirme Puanları
                      </span>
                      <div className="grid grid-cols-5 gap-1 text-center">
                        {Object.entries(card.peerScores).map(([dept, score]) => (
                          <div key={dept} className="bg-slate-50 dark:bg-slate-900/60 p-1.5 rounded-lg border border-slate-100 dark:border-slate-800">
                            <span className="text-[10px] text-slate-400 font-mono block truncate">
                              {dept.substring(0, 3)}
                            </span>
                            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                              {score}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* EVALUATOR NOTES */}
                    {activeCardState.evaluatorNotes && (
                      <div className="bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 italic">
                        "{activeCardState.evaluatorNotes}"
                      </div>
                    )}
                  </div>

                  {/* CARD FOOTER WITH 'UPDATE' & 'CANCEL' ACTIONS */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-2">
                    {isEditing ? (
                      <>
                        <button
                          onClick={handleCancelEdit}
                          className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                          {t('btn.cancel') || 'İptal'}
                        </button>

                        <button
                          onClick={handleSaveEdit}
                          className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-colors shadow-sm"
                        >
                          <Save className="w-3.5 h-3.5" />
                          {t('btn.update') || 'Güncelle'}
                        </button>
                      </>
                    ) : (
                      <>
                        <span className="text-[11px] text-slate-400">
                          Değerlendirme: {activeCardState.lastEvaluated}
                        </span>

                        <button
                          onClick={() => handleStartEdit(card)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-medium transition-colors shadow-xs"
                        >
                          <Sliders className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          {t('btn.updateScores') || 'Puanları Düzenle'}
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* CROSS EVALUATION HEAT MATRIX VIEW */}
        {activeViewMode === 'CROSS_MATRIX' && (
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                {t('dept.matrixTitle') || 'Bölümler Arası Çapraz Puanlama Matrisi'}
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Satırdaki değerlendiren departmanın, sütundaki hedef departmana verdiği operasyonel kalite puanları.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-semibold">
                    <th className="p-3 rounded-tl-xl border border-slate-200 dark:border-slate-700">Değerlendiren \ Hedef</th>
                    <th className="p-3 border border-slate-200 dark:border-slate-700 text-center">Kalite</th>
                    <th className="p-3 border border-slate-200 dark:border-slate-700 text-center">Üretim</th>
                    <th className="p-3 border border-slate-200 dark:border-slate-700 text-center">Agronomi</th>
                    <th className="p-3 border border-slate-200 dark:border-slate-700 text-center">Satış</th>
                    <th className="p-3 rounded-tr-xl border border-slate-200 dark:border-slate-700 text-center">Yönetim</th>
                  </tr>
                </thead>
                <tbody>
                  {(['QUALITY', 'PRODUCTION', 'AGRONOMY', 'SALES', 'MANAGEMENT'] as DeptCategory[]).map((evalDept) => (
                    <tr key={evalDept} className="border-b border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-900/50">
                      <td className="p-3 font-semibold text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/30">
                        {getDeptTitle(evalDept)}
                      </td>
                      {(['QUALITY', 'PRODUCTION', 'AGRONOMY', 'SALES', 'MANAGEMENT'] as DeptCategory[]).map((targetDept) => {
                        const targetCard = roleCards.find((r) => r.department === targetDept);
                        const score = targetCard ? targetCard.peerScores[evalDept] || 90 : 0;
                        
                        let heatClass = 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300';
                        if (score >= 93) heatClass = 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-200 font-bold';
                        else if (score < 88) heatClass = 'bg-amber-100 dark:bg-amber-900/30 text-amber-900 dark:text-amber-200 font-bold';

                        return (
                          <td key={targetDept} className={`p-3 text-center border border-slate-200 dark:border-slate-700 font-mono ${heatClass}`}>
                            {score}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* COMPARISON VIEW */}
        {activeViewMode === 'COMPARISON' && (
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                {t('dept.comparisonTitle') || 'Departman Performans Kıyaslaması'}
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Tüm departmanların genel kalite skoru ve hedef gerçekleşme oranlarının yatay kıyaslama grafiği.
              </p>
            </div>

            <div className="space-y-4">
              {roleCards.map((card) => (
                <div key={card.id} className="space-y-1.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {card.defaultRoleTitle} ({getDeptTitle(card.department)})
                    </span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {card.overallScore} / 100
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${card.overallScore}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* HISTORICAL 3-MONTH KPI SCORING TRENDS (RECHARTS LINE CHART)              */}
        {/* ========================================================================= */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Departmanlar Bazında Son 3 Aylık KPI Trend & Skor Gelişimi
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kalite (QC/QA), Üretim, Agronomi, Satış ve Yönetim birimlerinin son 90 gündeki kalite uyum ve hedef gerçekleştirme trendi
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <Calendar className="w-3.5 h-3.5 text-emerald-500" />
              <span>Son 3 Ay (Ağustos - Ekim)</span>
            </div>
          </div>

          <div className="w-full h-72 sm:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={[
                  { month: '1. Hafta (Ağu)', Kalite: 88, Uretim: 82, Agronomi: 85, Satis: 84, Yonetim: 90 },
                  { month: '3. Hafta (Ağu)', Kalite: 89, Uretim: 83, Agronomi: 87, Satis: 85, Yonetim: 91 },
                  { month: '1. Hafta (Eyl)', Kalite: 91, Uretim: 86, Agronomi: 88, Satis: 87, Yonetim: 92 },
                  { month: '3. Hafta (Eyl)', Kalite: 93, Uretim: 87, Agronomi: 90, Satis: 88, Yonetim: 93 },
                  { month: '1. Hafta (Eki)', Kalite: 94, Uretim: 89, Agronomi: 91, Satis: 90, Yonetim: 94 },
                  { month: 'Güncel (Eki)', Kalite: 95, Uretim: 91, Agronomi: 92, Satis: 92, Yonetim: 95 }
                ]}
                margin={{ top: 10, right: 20, left: -10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" opacity={0.2} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} />
                <YAxis domain={[75, 100]} tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} unit="p" />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl border border-slate-700 shadow-xl text-xs space-y-1.5">
                          <p className="font-bold text-slate-300 border-b border-slate-700 pb-1">{label}</p>
                          {payload.map((entry, idx) => (
                            <div key={idx} className="flex items-center justify-between gap-4 font-mono">
                              <span style={{ color: entry.color }} className="font-bold">{entry.name}:</span>
                              <span className="font-bold text-white">{entry.value} Puan</span>
                            </div>
                          ))}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
                <Line type="monotone" dataKey="Kalite" name="Kalite (QC/Lab)" stroke="#10b981" strokeWidth={2.5} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="Uretim" name="Üretim & Paketleme" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="Agronomi" name="Agronomi & Saha" stroke="#84cc16" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="Satis" name="Satış & Sevkiyat" stroke="#0ea5e9" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="Yonetim" name="Yönetim & Ar-Ge" stroke="#6366f1" strokeWidth={2} strokeDasharray="4 4" dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* MODAL FOR NEW CROSS EVALUATION */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
              <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Yeni Çapraz Puanlama
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddCrossEvaluation} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Değerlendiren Departman
                  </label>
                  <select
                    value={evaluatorDept}
                    onChange={(e) => setEvaluatorDept(e.target.value as DeptCategory)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="QUALITY">Kalite Güvence & Lab</option>
                    <option value="PRODUCTION">Üretim & Paketleme</option>
                    <option value="AGRONOMY">Agronomi & Saha</option>
                    <option value="SALES">Satış & Sevkiyat</option>
                    <option value="MANAGEMENT">Yönetim & Ar-Ge</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Hedef Değerlendirilecek Birim / Rol
                  </label>
                  <select
                    value={targetRoleId}
                    onChange={(e) => setTargetRoleId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {roleCards.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.defaultRoleTitle} ({r.personName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Operasyonel Kalite Skoru (1 - 100)
                    </label>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {evalScoreInput} Puan
                    </span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="100"
                    value={evalScoreInput}
                    onChange={(e) => setEvalScoreInput(Number(e.target.value))}
                    className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Değerlendirme Notu / Saha İncelemesi
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Örn: Brix toleransı tutarlıydı, fakat ambalaj etiketi ambar kontrolünde geç onaylandı..."
                    value={evalNotesInput}
                    onChange={(e) => setEvalNotesInput(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl text-sm font-semibold transition-colors"
                  >
                    {t('btn.cancel') || 'İptal'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-sm"
                  >
                    {t('btn.save') || 'Güncelle & Kaydet'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default DepartmentScoringPortal;
