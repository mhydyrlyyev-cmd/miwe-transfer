import React, { useState, useEffect, useRef } from 'react';
import { 
  Leaf, 
  Search, 
  FileSpreadsheet, 
  Plus, 
  Wifi, 
  WifiOff, 
  Sliders, 
  Share2, 
  MessageSquarePlus,
  BookOpen,
  Menu,
  X,
  Sparkles,
  FileBarChart,
  Gauge,
  Smartphone,
  ChevronDown,
  Layers,
  Sprout,
  TestTube,
  Truck,
  Warehouse,
  Flame,
  Plane,
  ShoppingCart,
  AlertTriangle,
  ExternalLink,
  ShieldCheck,
  Camera,
  LogOut,
  UserCheck,
  Sun,
  Moon,
  QrCode,
  Bell,
  Check,
  CheckCircle2,
  Terminal,
  ClipboardList,
  Clock,
  ArrowRight,
  Download,
  CalendarDays,
  MapPin,
  Lock,
  LayoutGrid,
  Home
} from 'lucide-react';
import { ModuleKey, ActiveFieldContext } from '../types';
import { AppUser } from '../types/auth';
import { BrandLogo } from './common/BrandLogo';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../context/ToastContext';
import { QRScannerModal } from './common/QRScannerModal';
import { SyncProgressBar, SyncProcessStatus } from './SyncProgressBar';
import { addDebugLog } from '../utils/debugLogger';
import { 
  getNotifications, 
  markAsRead, 
  markAllAsRead, 
  clearNotifications, 
  AppNotification, 
  subscribeToNotifications,
  resolveIncidentNotification 
} from '../utils/notificationService';

interface HeaderProps {
  onSearchRef: (refId: string) => void;
  onOpenGasModal: () => void;
  onOpenQuickNew: () => void;
  onSelectModule?: (moduleKey: ModuleKey, action?: 'NEW' | 'EXISTING') => void;
  onOpenCustomFields: () => void;
  onOpenShareModal: () => void;
  onOpenFeedback: () => void;
  onOpenDiagnostics?: () => void;
  onOpenGuide: () => void;
  onOpenMonthlyReport?: () => void;
  onOpenSummary?: () => void;
  onOpenGantt?: () => void;
  onOpenPwaModal?: () => void;
  onOpenGallery?: () => void;
  onResolveIncident?: (incidentId?: string, refId?: string, notifId?: string) => void;
  onNavigateToView?: (view: any) => void;
  isSyncing?: boolean;
  isOnline?: boolean;
  offlineQueueCount?: number;
  lastSyncTime?: string | null;
  syncStatus?: SyncProcessStatus;
  lastSyncError?: string | null;
  onSyncOfflineQueue?: () => void;
  onOpenSyncModal?: () => void;
  totalRefsCount: number;
  completedRefsCount?: number;
  spreadsheetUrl?: string;
  onPullFromSheets?: () => void;
  onNavigateToDashboard?: () => void;
  currentUser?: AppUser | null;
  onOpenAdminModal?: () => void;
  onLogout?: () => void;
  pendingApprovalsCount?: number;
  pendingTasksCount?: number;
  pendingTasksBreakdown?: {
    approvals: number;
    dispatches: number;
    receipts: number;
    incidents: number;
    offlineSync: number;
  };
  onOpenProfile?: () => void;
  onOpenCreateNotification?: () => void;
  onDownloadBackup?: () => void;
  activeFieldContext?: ActiveFieldContext | null;
  onSelectFieldContext?: (ctx: ActiveFieldContext | null) => void;
  onOpenAdminPortal?: () => void;
  activeView?: string;
  activePortalBreadcrumb?: {
    portalId: string;
    subId: string;
    portalTitle: string;
    subTitle: string;
  } | null;
}

export const Header: React.FC<HeaderProps> = ({
  onSearchRef,
  onOpenGasModal,
  onOpenQuickNew,
  onSelectModule,
  onOpenCustomFields,
  onOpenShareModal,
  onOpenFeedback,
  onOpenDiagnostics,
  onOpenGuide,
  onOpenMonthlyReport,
  onOpenSummary,
  onOpenGantt,
  onOpenPwaModal,
  onOpenGallery,
  onOpenCreateNotification,
  onDownloadBackup,
  isSyncing,
  isOnline = true,
  offlineQueueCount = 0,
  lastSyncTime,
  syncStatus = 'SUCCESS',
  lastSyncError,
  onSyncOfflineQueue,
  onOpenSyncModal,
  totalRefsCount,
  completedRefsCount,
  spreadsheetUrl,
  onPullFromSheets,
  onNavigateToDashboard,
  currentUser,
  onOpenAdminModal,
  onLogout,
  pendingApprovalsCount = 0,
  pendingTasksCount,
  pendingTasksBreakdown,
  onOpenProfile,
  onResolveIncident,
  onNavigateToView,
  activeFieldContext,
  onSelectFieldContext,
  onOpenAdminPortal,
  activeView,
  activePortalBreadcrumb
}) => {
  const { theme, toggleTheme } = useTheme();
  const { showSuccess, showError, showWarning, showInfo } = useToast();
  const [searchInput, setSearchInput] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isToolsDropdownOpen, setIsToolsDropdownOpen] = useState(false);
  const [isPendingTasksOpen, setIsPendingTasksOpen] = useState(false);
  const [isNewRecordDropdownOpen, setIsNewRecordDropdownOpen] = useState(false);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isCommandCenterOpen, setIsCommandCenterOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const toolsDropdownRef = useRef<HTMLDivElement>(null);
  const pendingTasksDropdownRef = useRef<HTMLDivElement>(null);
  const newRecordDropdownRef = useRef<HTMLDivElement>(null);
  const notificationsDropdownRef = useRef<HTMLDivElement>(null);
  const commandCenterRef = useRef<HTMLDivElement>(null);

  // Total pending tasks count for today
  const totalPendingTasks = pendingTasksCount !== undefined
    ? pendingTasksCount
    : (pendingTasksBreakdown
        ? (pendingTasksBreakdown.approvals + pendingTasksBreakdown.dispatches + pendingTasksBreakdown.receipts + pendingTasksBreakdown.incidents + pendingTasksBreakdown.offlineSync)
        : (pendingApprovalsCount + offlineQueueCount));

  // Load and refresh notifications periodically & on events
  useEffect(() => {
    const loadNotif = () => {
      const list = getNotifications(currentUser?.id || 'anonymous');
      setNotifications(list);
    };

    loadNotif();
    const unsubscribe = subscribeToNotifications(loadNotif);
    const interval = setInterval(loadNotif, 30000); // 30s fallback poll instead of 4s aggressive poll

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, [currentUser]);

  // Click outside listener for dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (toolsDropdownRef.current && !toolsDropdownRef.current.contains(event.target as Node)) {
        setIsToolsDropdownOpen(false);
      }
      if (pendingTasksDropdownRef.current && !pendingTasksDropdownRef.current.contains(event.target as Node)) {
        setIsPendingTasksOpen(false);
      }
      if (newRecordDropdownRef.current && !newRecordDropdownRef.current.contains(event.target as Node)) {
        setIsNewRecordDropdownOpen(false);
      }
      if (notificationsDropdownRef.current && !notificationsDropdownRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearchRef(searchInput.trim());
    }
  };

  const handleSafeAction = (actionName: string, actionFn?: () => void) => {
    if (!actionFn) return;
    try {
      actionFn();
      setIsToolsDropdownOpen(false);
      setIsMobileMenuOpen(false);
    } catch (err: any) {
      showError(`"${actionName}" işlemi başlatılırken hata oluştu: ${err?.message || 'Bilinmeyen hata'}`, 'İşlem Başarısız');
      addDebugLog('SYSTEM', 'ERROR', `İşlem çalıştırma hatası: ${actionName}`, err);
    }
  };

  const handleSafePullFromSheets = async () => {
    if (!onPullFromSheets) return;
    try {
      showInfo('Google Sheets tablosundan veriler çekiliyor...', 'Veri Senkronizasyonu');
      addDebugLog('GAS_SYNC', 'INFO', 'Kullanıcı Google Sheets tablosundan veri güncelleme (pull) başlattı.');
      await onPullFromSheets();
      setIsToolsDropdownOpen(false);
    } catch (err: any) {
      showError(`Google Sheets senkronizasyonu sırasında hata oluştu: ${err?.message || 'Bağlantı hatası'}`, 'Senkronizasyon Hatası');
      addDebugLog('GAS_SYNC', 'ERROR', 'Google Sheets pull istisna', err);
    }
  };

  const handleSafeSyncOfflineQueue = async () => {
    if (!onSyncOfflineQueue) return;
    try {
      showInfo('Kuyruktaki çevrimdışı işlemler eşitleniyor...', 'Kuyruk Eşitleme');
      addDebugLog('STORAGE', 'INFO', 'Kullanıcı kuyruk eşitleme işlemi başlattı.');
      await onSyncOfflineQueue();
    } catch (err: any) {
      showError(`Kuyruk eşitlenirken hata oluştu: ${err?.message || 'Ağ hatası'}`, 'Eşitleme Hatası');
      addDebugLog('STORAGE', 'ERROR', 'Kuyruk eşitleme istisna', err);
    }
  };

  const handleSelectModuleItem = (modKey: ModuleKey) => {
    setIsNewRecordDropdownOpen(false);
    setIsMobileMenuOpen(false);
    if (onSelectModule) {
      onSelectModule(modKey, 'NEW');
    } else {
      onOpenQuickNew();
    }
  };

  return (
    <header className="bg-white/95 backdrop-blur-md text-slate-900 border-b border-slate-200/90 shadow-xs sticky top-0 z-50 transition-all w-full overflow-visible">
      <div className="w-full max-w-[1600px] mx-auto px-2 sm:px-4 lg:px-8 py-2 sm:py-2.5 overflow-visible">
        
        {/* TOP ROW: Brand + Search + Clean Grouped Dropdowns */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-4 w-full min-w-0">
          
          {/* 1. BRAND & IDENTITY (STRICT SHRINK-0 TO PREVENT OVERLAPPING) */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0 min-w-0">
            <button 
              type="button"
              onClick={onNavigateToDashboard}
              className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl shadow-xs shrink-0 overflow-hidden relative group cursor-pointer border flex items-center justify-center p-0.5 transition-all ${
                activeView === 'DASHBOARD'
                  ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-500/30'
                  : 'border-slate-200 hover:border-emerald-400 bg-slate-50 hover:scale-105'
              }`}
              title="Dashboard / Ana Sayfaya Dön"
            >
              <BrandLogo size="100%" className="w-full h-full object-contain" showText={false} />
            </button>
            
            <div className="shrink-0 min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  type="button"
                  onClick={onNavigateToDashboard}
                  className="font-black text-xs sm:text-base md:text-lg tracking-tight text-slate-900 whitespace-nowrap hover:text-emerald-600 transition-colors text-left cursor-pointer hidden xs:inline-block sm:inline-block"
                  title="Dashboard'a Git"
                >
                  MIWE HIL
                </button>
                <span className="hidden lg:inline-block px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-2xs whitespace-nowrap">
                  Quality &amp; Traceability
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-500 truncate max-w-[170px] lg:max-w-xs">
                Muz, Badem &amp; Meyve Platformu
              </p>
            </div>

            {/* AŞAMA 22: TEK BİR '🏠 Portallar' BUTONU (Gizli mobilde, md ve üstü görünür) */}
            {activeView !== 'PORTAL_LAUNCHER' && (
              <button
                type="button"
                onClick={() => {
                  if (onNavigateToView) onNavigateToView('PORTAL_LAUNCHER');
                }}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 transition cursor-pointer shadow-xs whitespace-nowrap shrink-0 ml-1"
                title="Portallar Menüsüne Dön"
              >
                <LayoutGrid className="w-4 h-4 text-white" />
                <span>🏠 Portallar</span>
              </button>
            )}
          </div>

          {/* 2. RESPONSIVE SEARCH BAR (Visible on md and up, hidden on mobile) */}
          {activeView !== 'PORTAL_LAUNCHER' && (
            <div className="hidden md:flex items-center justify-end flex-1 min-w-0 px-2">
              <form onSubmit={handleSearchSubmit} className="relative flex-1 min-w-0 max-w-sm">
                <input
                  type="text"
                  placeholder="🔍 Ref Ara..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded-xl pl-8 pr-8 py-1.5 focus:outline-none focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500 placeholder-slate-400 font-mono transition-all"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <button
                  type="button"
                  onClick={() => setIsQrScannerOpen(true)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-emerald-600 hover:text-emerald-700 transition-all cursor-pointer"
                  title="QR Kod / Barkod Tarat"
                >
                  <QrCode className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}


          {/* 3. RIGHT HEADER STATUS & CLEAN CONSOLIDATED MENUS (STRICT SHRINK-0) */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* PWA Install Button */}
            {onOpenPwaModal && (
              <button
                type="button"
                onClick={onOpenPwaModal}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition cursor-pointer shrink-0 hover:scale-105 active:scale-95 shadow-2xs"
                title="Uygulamayı mobil cihaza veya bilgisayara yükle"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Uygulamayı Ekle</span>
              </button>
            )}
            
            {/* Status & Sync Indicator Badge (Hidden on mobile, sm:flex) */}
            <button
              type="button"
              onClick={onOpenSyncModal}
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer hover:scale-105 active:scale-95 shadow-2xs shrink-0 ${
                isOnline
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                  : 'bg-amber-50 border-amber-300 text-amber-800 animate-pulse hover:bg-amber-100'
              }`}
              title="Senkronizasyon durumu ve çevrimdışı bekleyen kayıtları görüntüle"
            >
              <span className={`w-2 h-2 rounded-full shrink-0 ${isOnline ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]' : 'bg-amber-400'}`}></span>
              <span className="text-[11px] hidden xs:inline sm:inline">{isOnline ? 'Online' : 'Offline'}</span>
              
              {offlineQueueCount > 0 ? (
                <span className="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-mono text-[9px] font-black">
                  {offlineQueueCount}
                </span>
              ) : (
                <span className="text-[9px] text-teal-700 font-mono">Senk</span>
              )}
            </button>

            {/* Dark / Light Mode Toggle Button (Hidden on mobile, sm:flex) */}
            <button
              type="button"
              onClick={toggleTheme}
              className="hidden sm:flex p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-200 transition cursor-pointer items-center justify-center shrink-0"
              title={theme === 'dark' ? 'Aydınlık Moda Geç' : 'Karanlık Moda Geç'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-teal-600" />
              )}
            </button>
 
            {/* ========================================== */}
            {/* NOTIFICATION CENTER (Bildirim Merkezi)     */}
            {/* ========================================== */}
            {currentUser && (
              <div className="relative shrink-0" ref={notificationsDropdownRef}>
                <button
                  type="button"
                  onClick={() => {
                    setIsNotificationsOpen(prev => !prev);
                    setIsToolsDropdownOpen(false);
                    setIsNewRecordDropdownOpen(false);
                    setIsPendingTasksOpen(false);
                  }}
                  className="p-1.5 sm:p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-200 transition cursor-pointer flex items-center justify-center relative hover:scale-105 active:scale-95 shrink-0"
                  title="Bildirimler ve Atanan Görevler"
                >
                  <Bell className={`w-4 h-4 ${notifications.some(n => !n.isRead) ? 'animate-bounce text-amber-500' : 'text-slate-600'}`} />
                  {notifications.some(n => !n.isRead) && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 border border-white text-[9px] font-black font-mono flex items-center justify-center text-white shadow-xs animate-pulse">
                      {notifications.filter(n => !n.isRead).length}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown Card */}
                {isNotificationsOpen && (
                  <>
                    {/* Mobile backdrop for easy tap-to-close */}
                    <div 
                      className="fixed inset-0 bg-slate-950/40 z-[90] sm:hidden backdrop-blur-2xs"
                      onClick={() => setIsNotificationsOpen(false)}
                    />

                    <div className="fixed inset-x-2 top-14 sm:inset-x-auto sm:absolute sm:top-full sm:right-0 sm:mt-2 w-auto sm:w-96 max-w-[calc(100vw-1rem)] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden z-[100] animate-in fade-in slide-in-from-top-2 duration-150 text-slate-900 dark:text-slate-100">
                      
                      {/* Dropdown Header: Sadece Kritik Kalite Alarmları */}
                      <div className="p-3 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Bell className="w-4 h-4 text-rose-500 shrink-0" />
                          <div>
                            <span className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider block truncate">
                              Kritik Kalite Alarm Paneli
                            </span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                              &lt;11°C Soğuk Zararı • Yüksek CO₂ • Bekleyen Offline Sync
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {onOpenCreateNotification && (
                            <button
                              onClick={() => {
                                onOpenCreateNotification();
                                setIsNotificationsOpen(false);
                              }}
                              className="px-2 py-0.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                              title="Kritik Kalite Alarmı Yayınla"
                            >
                              <span>+ Alarm</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              markAllAsRead(currentUser.id);
                              setNotifications(getNotifications(currentUser.id));
                            }}
                            className="text-[10px] font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                          >
                            Tümü Oku
                          </button>
                          <span className="text-slate-300 dark:text-slate-700 text-xs">|</span>
                          <button
                            onClick={() => {
                              clearNotifications(currentUser.id);
                              setNotifications(getNotifications(currentUser.id));
                            }}
                            className="text-[10px] font-bold text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer"
                          >
                            Temizle
                          </button>
                          <button
                            onClick={() => setIsNotificationsOpen(false)}
                            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition cursor-pointer ml-0.5"
                            title="Kapat"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Kritik Kalite Alarmları Durum Şeridi (<11°C Soğuk Zararı, Yüksek CO2, Bekleyen Offline Sync) */}
                      <div className="px-3 py-2 bg-slate-100/70 dark:bg-slate-950/60 border-b border-slate-200/80 dark:border-slate-800 grid grid-cols-3 gap-1.5 text-[10px]">
                        <div className="px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col">
                          <span className="font-bold text-rose-600 dark:text-rose-400 truncate">🌡️ &lt;11°C Soğuk</span>
                          <span className="text-[9px] text-slate-500 font-mono">Chilling İzleme</span>
                        </div>
                        <div className="px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col">
                          <span className="font-bold text-amber-600 dark:text-amber-400 truncate">💨 Yüksek CO₂</span>
                          <span className="text-[9px] text-slate-500 font-mono">MAP & Oda Gazı</span>
                        </div>
                        <div
                          onClick={() => {
                            if (offlineQueueCount > 0) handleSafeSyncOfflineQueue();
                          }}
                          className={`px-2 py-1 rounded-lg border flex flex-col cursor-pointer ${
                            offlineQueueCount > 0
                              ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-700'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                          }`}
                        >
                          <span className="font-bold text-teal-600 dark:text-teal-400 truncate">🔄 Offline Sync</span>
                          <span className="text-[9px] text-slate-600 dark:text-slate-300 font-mono font-bold">
                            {offlineQueueCount > 0 ? `${offlineQueueCount} Bekleyen` : '0 Bekleyen'}
                          </span>
                        </div>
                      </div>

                    {/* Dropdown Body */}
                    <div className="max-h-[350px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center gap-1.5">
                          <Bell className="w-6 h-6 text-slate-300 dark:text-slate-700" />
                          <span>Okunmamış veya yeni bildiriminiz bulunmuyor.</span>
                        </div>
                      ) : (
                        notifications.map((notif) => {
                          const isCritical = notif.type === 'CRITICAL_ALERT' || notif.actDegree === 1 || notif.priority === 'CRITICAL' || notif.title.includes('KRİTİK') || notif.title.includes('1. DERECE');
                          const isIncident = notif.actionLink === 'INCIDENT' || Boolean(notif.incidentId) || Boolean(notif.refId) || notif.title.toLowerCase().includes('barlag akty') || notif.title.toLowerCase().includes('incident') || notif.title.toLowerCase().includes('olay') || notif.title.toLowerCase().includes('sapma');
                          const isNonCriticalIncident = isIncident && !isCritical;

                          return (
                            <div 
                              key={notif.id}
                              onClick={() => {
                                markAsRead(notif.id);
                                if (currentUser?.id) {
                                  setNotifications(getNotifications(currentUser.id));
                                }
                              }}
                              className={`p-3.5 flex items-start gap-3 transition-colors cursor-pointer ${
                                !notif.isRead 
                                  ? isCritical 
                                    ? 'bg-rose-500/5 dark:bg-rose-950/10' 
                                    : 'bg-teal-500/5 dark:bg-teal-950/10'
                                  : 'hover:bg-slate-50 dark:hover:bg-slate-950/40'
                              }`}
                            >
                              <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                                notif.isResolved
                                  ? 'bg-emerald-500'
                                  : !notif.isRead 
                                    ? isCritical ? 'bg-rose-500' : 'bg-teal-500'
                                    : 'bg-transparent'
                              }`} />
                              
                              <div className="flex-1 space-y-1">
                                <div className="flex items-center justify-between gap-2">
                                  <span className={`text-xs font-bold leading-tight ${
                                    notif.isResolved
                                      ? 'text-emerald-700 dark:text-emerald-400'
                                      : isCritical 
                                        ? 'text-rose-600 dark:text-rose-400' 
                                        : 'text-slate-900 dark:text-slate-100'
                                  }`}>
                                    {notif.title}
                                  </span>
                                  <span className="text-[9px] text-slate-400 font-mono shrink-0">
                                    {new Date(notif.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-normal font-medium text-left">
                                  {notif.message}
                                </p>

                                {/* Resolved status badge */}
                                {notif.isResolved && (
                                  <div className="flex items-center gap-1.5 pt-1">
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                                      <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600 dark:text-emerald-400" /> Çözüldü Olarak İşaretlendi
                                    </span>
                                  </div>
                                )}

                                {/* Action Buttons for Non-Critical Incidents */}
                                {isNonCriticalIncident && !notif.isResolved && (
                                  <div className="flex flex-wrap items-center gap-2 mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-800/80">
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        resolveIncidentNotification(notif.id, notif.incidentId, notif.refId);
                                        if (onResolveIncident) {
                                          onResolveIncident(notif.incidentId, notif.refId, notif.id);
                                        }
                                        if (currentUser?.id) {
                                          setNotifications(getNotifications(currentUser.id));
                                        }
                                      }}
                                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-xs transition-all active:scale-95 cursor-pointer"
                                      title="Kritik olmayan bu Barlag Akty / Incident kaydını doğrudan çözüldü olarak işaretle"
                                    >
                                      <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                                      <span>Çözüldü Olarak İşaretle</span>
                                    </button>

                                    {notif.refId && onSearchRef && (
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onSearchRef(notif.refId!);
                                          setIsNotificationsOpen(false);
                                        }}
                                        className="text-[10px] font-bold text-teal-600 dark:text-teal-400 hover:underline"
                                      >
                                        {notif.refId} İncele →
                                      </button>
                                    )}

                                    {!notif.isRead && (
                                      <button 
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          markAsRead(notif.id);
                                          if (currentUser?.id) {
                                            setNotifications(getNotifications(currentUser.id));
                                          }
                                        }}
                                        className="text-[9px] font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 ml-auto"
                                      >
                                        Okundu
                                      </button>
                                    )}
                                  </div>
                                )}

                                {/* Warning & Review button for Critical Incidents */}
                                {isCritical && !notif.isResolved && (
                                  <div className="flex items-center justify-between gap-2 mt-2 pt-1.5 border-t border-rose-100 dark:border-rose-900/40">
                                    <span className="text-[9px] font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1">
                                      <AlertTriangle className="w-3 h-3 text-rose-500 shrink-0" /> 1. Derece Kritik: DÖF İncelemesi Gerekir
                                    </span>
                                    {onNavigateToView && (
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onNavigateToView('ANALYTICS');
                                          setIsNotificationsOpen(false);
                                        }}
                                        className="text-[9px] font-bold text-rose-700 dark:text-rose-300 hover:underline shrink-0"
                                      >
                                        Olay Analitiği →
                                      </button>
                                    )}
                                  </div>
                                )}

                                {/* Standard Non-incident Unread Toggle */}
                                {!isIncident && !notif.isRead && (
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      markAsRead(notif.id);
                                      if (currentUser?.id) {
                                        setNotifications(getNotifications(currentUser.id));
                                      }
                                    }}
                                    className="text-[9px] font-bold text-teal-600 dark:text-teal-400 flex items-center gap-1 hover:underline mt-1"
                                  >
                                    <Check className="w-2.5 h-2.5" /> Okundu İşaretle
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Dropdown Footer */}
                    <div className="p-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40 text-center">
                      <span className="text-[10px] text-slate-400">
                        Toplam {notifications.filter(n => !n.isRead).length} okunmamış bildiriminiz var
                      </span>
                    </div>

                    </div>
                  </>
                )}
              </div>
            )}

            {/* BUGÜN YAPILACAKLAR (Pending Tasks & Approvals Badge) */}
            {currentUser && activeView !== 'PORTAL_LAUNCHER' && (
              <div className="relative shrink-0 hidden sm:block" ref={pendingTasksDropdownRef}>
                <button
                  type="button"
                  onClick={() => {
                    setIsPendingTasksOpen(prev => !prev);
                    setIsToolsDropdownOpen(false);
                    setIsNewRecordDropdownOpen(false);
                    setIsNotificationsOpen(false);
                  }}
                  className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer shadow-2xs shrink-0 ${
                    isPendingTasksOpen
                      ? 'bg-amber-50 text-amber-800 border-amber-300 ring-1 ring-amber-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border-slate-200'
                  }`}
                  title="Bugün Yapılacaklar: Onay bekleyen kullanıcılar, sevkler, ambar kabulleri ve çözülmemiş olaylar"
                >
                  <ClipboardList className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span className="hidden 2xl:inline">Bugün Yapılacaklar</span>
                  <span className="hidden sm:inline 2xl:hidden">İşler</span>
                  {totalPendingTasks > 0 ? (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-slate-950 font-mono font-black animate-pulse">
                      {totalPendingTasks}
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono font-bold">
                      0
                    </span>
                  )}
                </button>

                {/* Pending Tasks Popover Window */}
                {isPendingTasksOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-[90] bg-black/20 sm:hidden" 
                      onClick={() => setIsPendingTasksOpen(false)} 
                    />
                    <div className="absolute right-0 sm:right-auto sm:left-0 top-full mt-2 w-72 sm:w-80 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-[100] animate-in fade-in slide-in-from-top-2 duration-150 max-h-[85vh] overflow-y-auto text-slate-900">
                      <div className="px-3 py-2 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                        <div className="flex items-center gap-1.5">
                          <ClipboardList className="w-4 h-4 text-amber-600" />
                          <span className="text-xs font-bold text-slate-900">Bugün Yapılacaklar</span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                          {totalPendingTasks} İşlem Bekliyor
                        </span>
                      </div>

                      <div className="p-2 space-y-1.5">
                        {/* 1. Admin Onayları */}
                        {currentUser.role === 'ADMIN' && (
                          <div 
                            onClick={() => {
                              onOpenAdminModal?.();
                              setIsPendingTasksOpen(false);
                            }}
                            className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/80 transition cursor-pointer flex items-center justify-between group"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-base">👤</span>
                              <div>
                                <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                                  Kullanıcı Onayları
                                </div>
                                <div className="text-[10px] text-slate-500">Yeni personel kayıt yetkilendirmesi</div>
                              </div>
                            </div>
                            <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                              (pendingTasksBreakdown?.approvals || pendingApprovalsCount) > 0
                                ? 'bg-amber-500 text-white font-black'
                                : 'bg-slate-200 text-slate-600'
                            }`}>
                              {pendingTasksBreakdown?.approvals || pendingApprovalsCount || 0}
                            </span>
                          </div>
                        )}

                        {/* 2. Sevk Bekleyenler */}
                        <div 
                          onClick={() => {
                            onNavigateToView?.('PENDING');
                            setIsPendingTasksOpen(false);
                          }}
                          className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/80 transition cursor-pointer flex items-center justify-between group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">📦</span>
                            <div>
                              <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                                Sevk Bekleyen Hasatlar
                              </div>
                              <div className="text-[10px] text-slate-500">Hasadı tamamlanmış partiler</div>
                            </div>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                            (pendingTasksBreakdown?.dispatches || 0) > 0
                              ? 'bg-blue-600 text-white font-black'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {pendingTasksBreakdown?.dispatches || 0}
                          </span>
                        </div>

                        {/* 3. Ambar Kabulü Bekleyenler */}
                        <div 
                          onClick={() => {
                            onNavigateToView?.('PENDING');
                            setIsPendingTasksOpen(false);
                          }}
                          className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/80 transition cursor-pointer flex items-center justify-between group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">🚚</span>
                            <div>
                              <div className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                                Yoldaki / Kabul Bekleyen Yükler
                              </div>
                              <div className="text-[10px] text-slate-500">Depoya giriş & kantar kabulü</div>
                            </div>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                            (pendingTasksBreakdown?.receipts || 0) > 0
                              ? 'bg-emerald-600 text-white font-black'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {pendingTasksBreakdown?.receipts || 0}
                          </span>
                        </div>

                        {/* 4. Açık Kalite Uygunsuzlukları */}
                        <div 
                          onClick={() => {
                            onNavigateToView?.('PENDING');
                            setIsPendingTasksOpen(false);
                          }}
                          className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/80 transition cursor-pointer flex items-center justify-between group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">⚠️</span>
                            <div>
                              <div className="text-xs font-bold text-slate-800 group-hover:text-rose-700">
                                Açık Barlag Akty & DÖF
                              </div>
                              <div className="text-[10px] text-slate-500">Kök sebep analizi ve aksiyon bekleyen</div>
                            </div>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                            (pendingTasksBreakdown?.incidents || 0) > 0
                              ? 'bg-rose-600 text-white font-black'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {pendingTasksBreakdown?.incidents || 0}
                          </span>
                        </div>

                        {/* 5. Senkronizasyon Kuyruğu */}
                        {(pendingTasksBreakdown?.offlineSync || offlineQueueCount) > 0 && (
                          <div 
                            onClick={() => {
                              onSyncOfflineQueue?.();
                              setIsPendingTasksOpen(false);
                            }}
                            className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 transition cursor-pointer flex items-center justify-between group"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-base">📡</span>
                              <div>
                                <div className="text-xs font-bold text-amber-900 group-hover:text-amber-950">
                                  Çevrimdışı Kayıtları Eşitle
                                </div>
                                <div className="text-[10px] text-amber-700">İnternet bağlantısı ile senkronize et</div>
                              </div>
                            </div>
                            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500 text-white font-black">
                              {pendingTasksBreakdown?.offlineSync || offlineQueueCount}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Footer: Tüm Bekleyenleri Aç */}
                      <div className="p-2 border-t border-slate-100 bg-slate-50">
                        <button
                          type="button"
                          onClick={() => {
                            onNavigateToView?.('PENDING');
                            setIsPendingTasksOpen(false);
                          }}
                          className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                        >
                          <span>Tüm Bekleyen İşlemleri Gör</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* 1. MİWE SPARK PAROLA KORUMALI YÖNETİCİ PORTALI BUTONU */}
            {activeView !== 'PORTAL_LAUNCHER' && (
              <div className="relative hidden sm:block" ref={toolsDropdownRef}>
              <button
                type="button"
                onClick={() => {
                  if (onOpenAdminPortal) {
                    onOpenAdminPortal();
                  } else {
                    onNavigateToView?.('DEPARTMENT_SCORING');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition shadow-2xs bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border-slate-200 cursor-pointer shrink-0"
                title="Miwe Spark Yönetici Portalı: Parola korumalı entegrasyonlar, kılavuzlar, kullanıcı rolleri ve sistem araçları"
              >
                <Lock className="w-3.5 h-3.5 text-amber-500" />
                <span className="hidden sm:inline">Admin Portalı</span>
              </button>

              {/* Tools Dropdown Menu with Backdrop */}
              {isToolsDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-[90] bg-black/20 sm:hidden" 
                    onClick={() => setIsToolsDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-2 w-80 sm:w-[420px] max-w-[calc(100vw-1.5rem)] bg-white border border-slate-200 rounded-2xl shadow-xl py-3 z-[100] animate-in fade-in slide-in-from-top-2 duration-150 max-h-[85vh] overflow-y-auto space-y-3 text-slate-900">
                    
                    {/* Window Header */}
                    <div className="px-3.5 pb-2 border-b border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-800">
                        <Layers className="w-4 h-4 text-emerald-600" />
                        <span>İşlemler & Sistem Araçları</span>
                      </div>
                      <span className="text-[10px] text-emerald-700 font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200">
                        MIWE HIL v2.4
                      </span>
                    </div>

                    {/* 1. Real-time Background Sync Status & Progress Bar */}
                    <div className="px-3">
                      <SyncProgressBar
                        isSyncing={!!isSyncing}
                        isOnline={isOnline}
                        pendingCount={offlineQueueCount}
                        lastSyncTime={lastSyncTime}
                        lastStatus={syncStatus}
                        errorMessage={lastSyncError}
                        onSyncNow={handleSafeSyncOfflineQueue}
                      />
                    </div>

                    {/* 2. Tools & Actions Section */}
                    <div className="px-2 space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 pt-1 pb-0.5">
                        Ayrı Web Platformu & Planlama
                      </div>

                      {onNavigateToView && (
                        <button
                          type="button"
                          onClick={() => handleSafeAction('Hasat & Planlama Portalı', () => onNavigateToView('HARVEST_PORTAL'))}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-emerald-900 hover:bg-emerald-100/60 bg-emerald-50/70 transition text-left cursor-pointer rounded-xl border border-emerald-200"
                        >
                          <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <div className="font-bold text-emerald-800">🚀 Hasat & Planlama Portalı (Gantt Stüdyosu)</div>
                            <div className="text-[10px] text-slate-500">Ayrı web platformu: 12-ay muz kurdele, 2027 meyve planı ve çoklu veri girişi</div>
                          </div>
                        </button>
                      )}

                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 pt-1 pb-0.5">
                        Raporlar & Fonksiyonlar
                      </div>

                      {onOpenMonthlyReport && (
                        <button
                          type="button"
                          onClick={() => handleSafeAction('Aylık Kalite Raporu', onOpenMonthlyReport)}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                        >
                          <FileBarChart className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-900">Aylık Kalite Raporu</div>
                            <div className="text-[10px] text-slate-500">Tüm test & depo verileri özeti</div>
                          </div>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleSafeAction('Tavsiye & Şikayet Kutusu', onOpenFeedback)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                      >
                        <MessageSquarePlus className="w-4 h-4 text-amber-500 shrink-0" />
                        <div>
                          <div className="font-bold text-slate-900">Tavsiye & Şikayet Kutusu</div>
                          <div className="text-[10px] text-slate-500">Gizli & anonim öneri bildirimi</div>
                        </div>
                      </button>

                      {onOpenDiagnostics && (
                        <button
                          type="button"
                          onClick={() => handleSafeAction('Sistem Tanılama', onOpenDiagnostics)}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                        >
                          <Terminal className="w-4 h-4 text-teal-600 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-900">Sistem Tanılama (Diagnostics)</div>
                            <div className="text-[10px] text-slate-500">Detaylı hata ve performans konsolu</div>
                          </div>
                        </button>
                      )}

                      {onDownloadBackup && (
                        <button
                          type="button"
                          onClick={() => handleSafeAction('Sistem Verilerini İndir', onDownloadBackup)}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                        >
                          <Download className="w-4 h-4 text-sky-600 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-900">Sistem Verilerini İndir</div>
                            <div className="text-[10px] text-slate-500">Tüm veritabanı JSON yedeği (Backup)</div>
                          </div>
                        </button>
                      )}

                      {onOpenPwaModal && (
                        <button
                          type="button"
                          onClick={() => handleSafeAction('Ekrana Yükle', onOpenPwaModal)}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                        >
                          <Smartphone className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-900">Ekrana Yükle (Logo)</div>
                            <div className="text-[10px] text-slate-500">Telefona & PC'ye uygulama ikonu</div>
                          </div>
                        </button>
                      )}

                      <div className="my-1.5 border-t border-slate-100"></div>

                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 pt-1 pb-0.5">
                        Kılavuz & Entegrasyonlar
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSafeAction('Kullanım Kılavuzu', onOpenGuide)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                      >
                        <BookOpen className="w-4 h-4 text-teal-600 shrink-0" />
                        <span>Kullanım Kılavuzu & Rehber</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSafeAction('Özel Alan Ekle', onOpenCustomFields)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                      >
                        <Sliders className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>Özel Alan / Sütun Ekle</span>
                      </button>

                      <a
                        href={spreadsheetUrl || 'https://docs.google.com/spreadsheets/'}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => {
                          if (!spreadsheetUrl) {
                            e.preventDefault();
                            handleSafeAction('Google E-Tablo Kurulumu', onOpenGasModal);
                          } else {
                            setIsToolsDropdownOpen(false);
                          }
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-50 transition text-left rounded-xl"
                      >
                        <div className="flex items-center gap-2.5">
                          <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <div className="font-bold">Google Sheets Tablosu</div>
                            <div className="text-[10px] text-emerald-600/80">Yeni sekmede direkt aç</div>
                          </div>
                        </div>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-600 opacity-80" />
                      </a>

                      {onPullFromSheets && (
                        <button
                          type="button"
                          onClick={handleSafePullFromSheets}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                        >
                          <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
                          <div>
                            <div className="font-bold">Google Sheets Raporu (otomatik)</div>
                            <div className="text-[10px] text-slate-500">Son verileri anında içeri çek (Pull)</div>
                          </div>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleSafeAction('Google Sheets Entegrasyon Ayarları', onOpenGasModal)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition text-left cursor-pointer rounded-xl"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-teal-600 shrink-0" />
                        <span>Google Sheets Entegrasyon Ayarları</span>
                      </button>

                      <div className="my-1.5 border-t border-slate-100"></div>

                      <button
                        type="button"
                        onClick={() => { setIsQrScannerOpen(true); setIsToolsDropdownOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-teal-700 hover:bg-teal-50 transition text-left cursor-pointer rounded-xl"
                      >
                        <QrCode className="w-4 h-4 text-teal-600 shrink-0 animate-pulse" />
                        <span>📷 Canlı QR / Barkod Tarayıcı</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
            )}

            {/* 2. YENİ TEST / KAYIT DROPDOWN MENU */}
            {activeView !== 'PORTAL_LAUNCHER' && (
              <div className="relative hidden sm:block" ref={newRecordDropdownRef}>
              <div className="flex items-center rounded-xl bg-emerald-600 hover:bg-emerald-700 shadow-xs border border-emerald-600 p-0.5 transition">
                <button
                  type="button"
                  onClick={onOpenQuickNew}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-white hover:text-emerald-100 text-xs font-bold transition active:scale-95 cursor-pointer"
                  title="Hızlı Yeni Kayıt Başlat"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="whitespace-nowrap">Yeni Test / Kayıt</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsNewRecordDropdownOpen(!isNewRecordDropdownOpen);
                    setIsToolsDropdownOpen(false);
                  }}
                  className="px-1.5 py-1.5 text-white/80 hover:text-white border-l border-white/20 transition cursor-pointer"
                  title="Test & Form Modülü Seç"
                >
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isNewRecordDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
              </div>

              {/* Module Selection Dropdown */}
              {isNewRecordDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-[90] bg-black/20 sm:hidden" 
                    onClick={() => setIsNewRecordDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-[100] animate-in fade-in slide-in-from-top-2 duration-150 text-slate-900">
                  <div className="px-3.5 py-1.5 border-b border-slate-100 text-[10px] font-bold uppercase tracking-wider text-emerald-700 flex items-center justify-between">
                    <span>Modül Seçimi (10 Entegre İstasyon)</span>
                    <span className="text-slate-400 font-normal">MIWE HIL</span>
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                    <button
                      onClick={() => handleSelectModuleItem('HARVEST')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <Sprout className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-emerald-700">🍏 Günlük Saha Hasadı</div>
                        <div className="text-[10px] text-slate-500">Bahçe, tonaj, parçalı sevk (Freeze & Dry)</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('FIELD')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <TestTube className="w-4 h-4 text-rose-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-rose-700">🔬 Saha Meyve Kalite Testi</div>
                        <div className="text-[10px] text-slate-500">Brix, sertlik, nitrat, kalite sınıflandırma</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('MUZ')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <span className="text-sm shrink-0">🍌</span>
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-amber-700">Muz Sera Kalite & MAP</div>
                        <div className="text-[10px] text-slate-500">Hemsaýa serası, kalibre, MAP torba, etilen</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('BADEM')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <span className="text-sm shrink-0">🥜</span>
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-orange-700">Badem Kalite & Laboratuvar</div>
                        <div className="text-[10px] text-slate-500">Miweli Atyz, iç randıman, nem, su aktivitesi</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('LOJISTIK')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <Truck className="w-4 h-4 text-blue-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-blue-700">🚚 Lojistik & Delilnama</div>
                        <div className="text-[10px] text-slate-500">Delilnama No, parçalı yük (split) & soğuk zincir</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('AMBAR')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <Warehouse className="w-4 h-4 text-teal-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-teal-700">🏭 Ambar & Soğuk Depo Kabul</div>
                        <div className="text-[10px] text-slate-500">Datly Miwe, kabul testleri, fire, oda atama</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('FREEZE_DRY')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <Flame className="w-4 h-4 text-purple-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-purple-700">❄️ Freeze & Dry Liyofilizasyon</div>
                        <div className="text-[10px] text-slate-500">Erem™ tesisi, şok dondurma, çıtırlık, vakum</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('EXPORT_SAMPLE')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <Plane className="w-4 h-4 text-cyan-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-cyan-700">✈️ Eksport Şahit Numune</div>
                        <div className="text-[10px] text-slate-500">Hedef ülke, raf ömrü, mikro testler</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('SALES')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <ShoppingCart className="w-4 h-4 text-amber-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-amber-700">📦 Satış & Sevkiyat Çıkış</div>
                        <div className="text-[10px] text-slate-500">Müşteri, sevk fişi, parti çıkış kütüğü</div>
                      </div>
                    </button>

                    <button
                      onClick={() => handleSelectModuleItem('INCIDENT')}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-slate-50 transition group cursor-pointer"
                    >
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-slate-900 group-hover:text-rose-700">⚠️ Kalite Uygunsuzluk / Akt</div>
                        <div className="text-[10px] text-slate-500">Barlag akty, 5-Why kök sebep, karantina</div>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        onOpenGallery?.();
                        setIsNewRecordDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs text-left hover:bg-emerald-50 border-t border-slate-100 transition group cursor-pointer"
                    >
                      <Camera className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-bold text-emerald-800">📸 Saha Galeri & Fotoğraf Arşivi</div>
                        <div className="text-[10px] text-slate-500">Tüm istasyonlardan çekilen saha fotoğrafları</div>
                      </div>
                    </button>
                  </div>
                </div>
                </>
              )}
            </div>
            )}



            {/* AUDIT TRAIL QUICK LINK */}
            {onNavigateToView && (
              <button
                type="button"
                onClick={() => onNavigateToView('AUDIT_TRAIL')}
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-bold transition shadow-2xs cursor-pointer shrink-0"
                title="Dikey Zaman Çizelgesi & Denetim İzleri (Audit Trail)"
              >
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden xl:inline">Denetim İzleri</span>
              </button>
            )}

            {/* USER PROFILE & ADMIN CONSOLE & LOGOUT (Desktop) */}
            {currentUser && (
              <div className="hidden sm:flex items-center gap-1.5 pl-2 border-l border-slate-200 shrink-0">
                {currentUser.role === 'ADMIN' && onOpenAdminModal && (
                  <button
                    type="button"
                    onClick={onOpenAdminModal}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-bold transition shadow-2xs cursor-pointer relative shrink-0"
                    title="Yönetici Paneli: Kullanıcı onayları, yetkilendirmeler ve hareket izleme (Audit Trail)"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span className="hidden 2xl:inline">Yönetici Paneli</span>
                    <span className="hidden sm:inline 2xl:hidden">Panel</span>
                    {pendingApprovalsCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-mono font-black animate-pulse">
                        {pendingApprovalsCount}
                      </span>
                    )}
                  </button>
                )}

                {currentUser.status === 'PASIF_READER' && (
                  <button
                    type="button"
                    onClick={() => alert('Sistem yöneticisi tarafından yetkilendirilmediğiniz için sadece görüntüleme modundasınız.')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 text-xs font-black transition cursor-pointer shrink-0 animate-pulse"
                    title="Sistem yöneticisi tarafından yetkilendirilmediğiniz için sadece görüntüleme modundasınız."
                  >
                    <span>🟡</span>
                    <span className="hidden md:inline">Ziyaretçi Modu</span>
                  </button>
                )}

                {/* User Info Label (Click to edit profile & password) */}
                <button
                  type="button"
                  onClick={onOpenProfile}
                  className="hidden xl:flex flex-col text-right leading-tight max-w-[130px] hover:text-emerald-700 transition-colors cursor-pointer focus:outline-none relative shrink-0"
                  title="Profil Bilgilerini Güncelle & Şifre Değiştir"
                >
                  <span className="text-xs font-bold text-slate-900 truncate w-full flex items-center justify-end gap-1" title={currentUser.fullName}>
                    <span className="truncate">{currentUser.fullName}</span>
                    <span className="shrink-0 text-slate-400">⚙️</span>
                    {currentUser.requiresPasswordChange && (
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" title="Şifre Güncellemesi Önerilir" />
                    )}
                  </span>
                  <span className="text-[10px] text-emerald-700 font-semibold truncate w-full" title="Profil & Şifre Ayarları">
                    {currentUser.company.split(' ')[0]}
                  </span>
                </button>

                {/* Logout Button */}
                {onLogout && (
                  <button
                    type="button"
                    onClick={onLogout}
                    className="p-1.5 rounded-xl bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-500 border border-slate-200 transition cursor-pointer shrink-0"
                    title="Çıkış Yap / Sign Out"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            {/* Mobile User Profile Avatar / Initial Button */}
            {currentUser && (
              <div className="sm:hidden flex items-center gap-1 shrink-0">
                {currentUser.status === 'PASIF_READER' && (
                  <button
                    type="button"
                    onClick={() => alert('Sistem yöneticisi tarafından yetkilendirilmediğiniz için sadece görüntüleme modundasınız.')}
                    className="px-1.5 py-1 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 text-xs font-black shadow-2xs"
                    title="Ziyaretçi Modu: Sadece görüntüleme yetkiniz var."
                  >
                    🟡
                  </button>
                )}
                <button
                  type="button"
                  onClick={onOpenProfile}
                  className="flex items-center justify-center w-8 h-8 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs shadow-2xs transition active:scale-95 cursor-pointer shrink-0"
                  title={`${currentUser.fullName} (${currentUser.role}) - Profili Düzenle`}
                >
                  <span>{currentUser.fullName ? currentUser.fullName.charAt(0).toUpperCase() : '👤'}</span>
                </button>
              </div>
            )}

            {/* Mobile Search Toggle Icon */}
            {activeView !== 'PORTAL_LAUNCHER' && (
              <button
                type="button"
                onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
                className={`p-1.5 rounded-xl border transition cursor-pointer md:hidden flex items-center justify-center shrink-0 ${
                  isMobileSearchOpen
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                }`}
                title="Arama Çubuğunu Aç/Kapat"
              >
                <Search className="w-4 h-4" />
              </button>
            )}

            {/* Mobile / Tablet Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-1.5 rounded-xl bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-200 sm:hidden transition cursor-pointer flex items-center justify-center shrink-0 relative"
              aria-label="Menüyü Aç"
            >
              {isMobileMenuOpen ? <X className="w-4 h-4 text-rose-500" /> : <Menu className="w-4 h-4 text-slate-700" />}
              {notifications.some(n => !n.isRead) && !isMobileMenuOpen && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white animate-pulse" />
              )}
            </button>

          </div>

        </div>

        {/* ========================================================================= */}
        {/* ANA PORTAL AÇILIR KOMUT MERKEZİ & BENTO MENÜ PANELİ (RESPONSIVE MEGAMENU) */}
        {/* ========================================================================= */}
        {isCommandCenterOpen && (
          <>
            {/* Backdrop for click outside & dimming */}
            <div 
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 transition-opacity"
              onClick={() => setIsCommandCenterOpen(false)}
            />

            {/* Responsive Mega Panel: Full screen drawer on mobile, centered modal or sub-header panel on monitor */}
            <div className="fixed inset-x-2 top-14 bottom-2 sm:inset-x-4 sm:top-16 sm:bottom-4 md:inset-auto md:left-1/2 md:-translate-x-1/2 md:top-16 md:w-[96vw] md:max-w-6xl md:max-h-[calc(100dvh-5rem)] z-50 flex flex-col bg-slate-950/98 border-2 border-teal-500/50 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-3 duration-200">
              <div className="p-3.5 sm:p-5 md:p-6 overflow-y-auto space-y-4 flex-1">
                
                {/* Header: Title + Close Button */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 sticky top-0 bg-slate-950/95 z-10 pt-1">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-500 text-slate-950 shadow-md shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                        <span>MIWE HIL Ana Portal Komut Merkezi</span>
                        <span className="hidden xs:inline-block px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-500/20 text-teal-300 border border-teal-500/40">
                          Monitor &amp; Mobil Uyumlu
                        </span>
                      </h2>
                      <p className="text-[11px] text-slate-400">
                        Tüm bağımsız portallar, 10 kalite &amp; hasat istasyonu, kılavuzlar ve sistem araçları
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsCommandCenterOpen(false)}
                    className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer flex items-center gap-1 text-xs font-bold shrink-0"
                    title="Komut Merkezini Kapat"
                  >
                    <X className="w-4 h-4 text-rose-400" />
                    <span className="hidden sm:inline">Kapat</span>
                  </button>
                </div>

                {/* Bento Grid Layout (4 Kolon) */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 text-xs">
                
                {/* 1. SÜTUN: BAĞIMSIZ WEB PLATFORMLARI & PORTALLAR */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/30 space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-black uppercase text-amber-400 pb-1.5 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <CalendarDays className="w-3.5 h-3.5" />
                        1. Portallar &amp; Stüdyolar
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">Hub</span>
                    </div>

                    <div className="mt-2 space-y-2">
                      {onNavigateToView && (
                        <button
                          type="button"
                          onClick={() => {
                            onNavigateToView('HARVEST_PORTAL');
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2.5 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 text-left transition cursor-pointer group"
                        >
                          <div className="font-black text-amber-300 group-hover:text-white flex items-center justify-between">
                            <span>🚀 Miwe Plan &amp; Hasat Portalı</span>
                            <ArrowRight className="w-3.5 h-3.5 text-amber-400 group-hover:translate-x-0.5 transition-transform" />
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Muz 12-ay kurdele takvimi, 2026 fiili hasat &amp; 2027 planlama stüdyosu
                          </div>
                        </button>
                      )}

                      {onNavigateToView && (
                        <button
                          type="button"
                          onClick={() => {
                            onNavigateToView('QUALITY_ROADMAP');
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2.5 rounded-xl bg-teal-950/40 hover:bg-teal-900/60 border border-teal-500/40 text-left transition cursor-pointer group"
                        >
                          <div className="font-black text-teal-300 group-hover:text-white flex items-center justify-between">
                            <span>🎯 Platform 02: Kalite KPI &amp; Departman Puanlama</span>
                            <ArrowRight className="w-3.5 h-3.5 text-teal-400 group-hover:translate-x-0.5 transition-transform" />
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            QC/QP radarı, Key Tools envanteri, Departman Puanlama Modülü ve 3 aylık KPI trendleri
                          </div>
                        </button>
                      )}

                      {onNavigateToView && (
                        <button
                          type="button"
                          onClick={() => {
                            onNavigateToView('DEPARTMENT_SCORING');
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2.5 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/40 text-left transition cursor-pointer group"
                        >
                          <div className="font-black text-indigo-300 group-hover:text-amber-300 flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                              <span>Platform 03: Miwe Spark (Admin &amp; Performans)</span>
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Canlı RAM (heap) &amp; DOM denetimi, Web Worker mimarisi ve onay havuzu
                          </div>
                        </button>
                      )}

                      {onNavigateToView && (
                        <button
                          type="button"
                          onClick={() => {
                            onNavigateToView('ANALYTICS');
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-left transition cursor-pointer group"
                        >
                          <div className="font-bold text-slate-200 group-hover:text-emerald-300 flex items-center justify-between">
                            <span>📊 Analitik &amp; FAO FLW Paneli</span>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-400" />
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Gıda kaybı önleme, stok hacmi ve eğilim grafikleri
                          </div>
                        </button>
                      )}
                    </div>
                  </div>

                  {onOpenMonthlyReport && (
                    <button
                      type="button"
                      onClick={() => {
                        onOpenMonthlyReport();
                        setIsCommandCenterOpen(false);
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-1.5 transition"
                    >
                      <FileBarChart className="w-3.5 h-3.5 text-teal-400" />
                      <span>Aylık Kalite Raporunu Aç</span>
                    </button>
                  )}
                </div>

                {/* 2. SÜTUN: 10 ENTEGRE İSTASYON & HIZLI KAYIT BAŞLATMA */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-black uppercase text-emerald-400 pb-1.5 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <Plus className="w-3.5 h-3.5" />
                        2. 10 İstasyon Hızlı Kayıt
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Yeni Form</span>
                    </div>

                    <div className="mt-2 grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
                      {[
                        { key: 'HARVEST', label: '🍏 Hasat Girişi', color: 'hover:text-emerald-300' },
                        { key: 'FIELD', label: '🔬 Saha Testi', color: 'hover:text-teal-300' },
                        { key: 'MUZ', label: '🍌 Muz MAP', color: 'hover:text-yellow-300' },
                        { key: 'BADEM', label: '🌰 Badem Randıman', color: 'hover:text-amber-300' },
                        { key: 'AMBAR', label: '🏢 Ambar Kabul', color: 'hover:text-blue-300' },
                        { key: 'LOJISTIK', label: '🚚 Frigo Lojistik', color: 'hover:text-indigo-300' },
                        { key: 'INCIDENT', label: '⚠️ Barlag Akty / DÖF', color: 'hover:text-rose-300' },
                        { key: 'SATIS', label: '🛒 Satış Sevkiyat', color: 'hover:text-cyan-300' },
                        { key: 'FREEZEDRY', label: '❄️ Freeze & Dry', color: 'hover:text-sky-300' },
                        { key: 'LABORATORY', label: '🧪 Dış Lab MRL', color: 'hover:text-purple-300' }
                      ].map((item) => (
                        <button
                          key={item.key}
                          type="button"
                          onClick={() => handleSelectModuleItem(item.key as ModuleKey)}
                          className={`p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700/80 text-[11px] font-bold text-slate-200 text-left transition truncate cursor-pointer ${item.color}`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onOpenQuickNew();
                      setIsCommandCenterOpen(false);
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 shadow-md"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Hızlı Yeni Kayıt Sihirbazı</span>
                  </button>
                </div>

                {/* 3. SÜTUN: KILAVUZ & SORU BANKASI (PORTAL REHBERLERİ) */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-teal-500/30 space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-black uppercase text-teal-400 pb-1.5 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5" />
                        3. Kılavuz &amp; Soru Bankası
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-300">Rehber</span>
                    </div>

                    <div className="mt-2 space-y-2">
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Tüm portalların ortak operasyonel rehberleri, saha talimatları ve soru bankası bölüm aitliğine göre tek çatı altında toplanmıştır:
                      </p>

                      <div className="space-y-1.5 text-[11px]">
                        <button
                          type="button"
                          onClick={() => {
                            onOpenGuide();
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2.5 rounded-xl bg-teal-950/50 hover:bg-teal-900/70 border border-teal-500/40 text-left transition cursor-pointer group"
                        >
                          <div className="font-bold text-teal-300 group-hover:text-white flex items-center justify-between">
                            <span>📖 Portallar Rehberi &amp; Soru Bankası</span>
                            <ArrowRight className="w-3.5 h-3.5 text-teal-400 group-hover:translate-x-0.5 transition-transform" />
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Muz, badem, hasat, ambar, lojistik, MRL ve barlag akty talimatları
                          </div>
                        </button>

                        <div className="grid grid-cols-2 gap-1 pt-1 text-[10px]">
                          <div className="p-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-slate-300">
                            🌱 Hasat &amp; Meyve
                          </div>
                          <div className="p-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-slate-300">
                            🍌 Muz &amp; MAP
                          </div>
                          <div className="p-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-slate-300">
                            🌰 Badem Kırım
                          </div>
                          <div className="p-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-slate-300">
                            🏢 Soğuk Ambar
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onOpenGuide();
                      setIsCommandCenterOpen(false);
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 shadow-md cursor-pointer mt-2"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Tüm Kılavuz &amp; Rehberleri Aç</span>
                  </button>
                </div>

                {/* 4. SÜTUN: SENKRONİZASYON & SİSTEM ARAÇLARI */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-black uppercase text-purple-400 pb-1.5 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <Sliders className="w-3.5 h-3.5" />
                        4. Senk &amp; Sistem Araçları
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">Bulut</span>
                    </div>

                    <div className="mt-2 space-y-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setIsQrScannerOpen(true);
                          setIsCommandCenterOpen(false);
                        }}
                        className="w-full p-2 rounded-xl bg-slate-800/90 hover:bg-slate-750 border border-slate-700 text-left font-bold text-teal-300 flex items-center justify-between cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          <QrCode className="w-4 h-4 text-teal-400" />
                          <span>📷 Canlı QR / Barkod Oku</span>
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">Kamera</span>
                      </button>

                      {onPullFromSheets && (
                        <button
                          type="button"
                          onClick={() => {
                            handleSafePullFromSheets();
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2 rounded-xl bg-slate-800/90 hover:bg-slate-750 border border-slate-700 text-left font-bold text-emerald-300 flex items-center justify-between cursor-pointer"
                        >
                          <span className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-emerald-400" />
                            <span>Google Sheets'ten Çek</span>
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">Pull</span>
                        </button>
                      )}

                      {onDownloadBackup && (
                        <button
                          type="button"
                          onClick={() => {
                            onDownloadBackup();
                            setIsCommandCenterOpen(false);
                          }}
                          className="w-full p-2 rounded-xl bg-slate-800/90 hover:bg-slate-750 border border-slate-700 text-left font-bold text-sky-300 flex items-center justify-between cursor-pointer"
                        >
                          <span className="flex items-center gap-2">
                            <Download className="w-4 h-4 text-sky-400" />
                            <span>Veri Yedeği İndir (JSON)</span>
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">Backup</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span>Durum: {isOnline ? '🟢 Online' : '🟠 Offline'}</span>
                    <span>{totalRefsCount} Aktif Kayıt</span>
                  </div>
                </div>

                </div>
              </div>
            </div>
          </>
        )}
        {/* Mobile Search Input (Only rendered when user taps the search icon button) */}
        {isMobileSearchOpen && activeView !== 'PORTAL_LAUNCHER' && (
          <form onSubmit={handleSearchSubmit} className="mt-2 flex md:hidden relative w-full animate-in fade-in slide-in-from-top-1 duration-150">
            <input
              type="text"
              placeholder="RefID Ara (örn: MUZ-20260901-001)..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded-xl pl-8 pr-8 py-2 focus:outline-none focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500 placeholder-slate-400 font-mono"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            {searchInput ? (
              <button 
                type="button" 
                onClick={() => setSearchInput('')}
                className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-700 text-base leading-none cursor-pointer"
              >
                &times;
              </button>
            ) : (
              <button 
                type="button" 
                onClick={() => setIsQrScannerOpen(true)}
                className="absolute right-2.5 top-2 p-0.5 text-emerald-600 hover:text-emerald-700 transition-all cursor-pointer"
                title="QR Kod / Barkod Tarat"
              >
                <QrCode className="w-4 h-4" />
              </button>
            )}
          </form>
        )}

        {/* MOBILE EXPANDABLE TOOLS MENU */}
        {isMobileMenuOpen && (
          <div className="mt-3 pt-3 border-t border-slate-200 space-y-2.5 sm:hidden animate-in slide-in-from-top-2 duration-150">
            {/* Mobile User Status Card & Pending Tasks */}
            {currentUser && (
              <div className="space-y-2">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => { onOpenProfile?.(); setIsMobileMenuOpen(false); }}
                    className="truncate text-left hover:text-emerald-700 focus:outline-none cursor-pointer"
                    title="Profil Bilgilerini Düzenle / Edit Profile"
                  >
                    <div className="text-xs font-bold text-slate-900 truncate">{currentUser.fullName} ⚙️</div>
                    <div className="text-[10px] text-emerald-700 font-semibold truncate">{currentUser.company} • {currentUser.jobTitle}</div>
                  </button>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {currentUser.role === 'ADMIN' && onOpenAdminModal && (
                      <button
                        onClick={() => { onOpenAdminModal(); setIsMobileMenuOpen(false); }}
                        className="px-2 py-1 rounded-lg bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold"
                      >
                        Admin ({pendingApprovalsCount})
                      </button>
                    )}
                    {onLogout && (
                      <button
                        onClick={() => { onLogout(); setIsMobileMenuOpen(false); }}
                        className="px-2 py-1 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <LogOut className="w-3 h-3" />
                        <span>Çıkış</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Mobil Bugün Yapılacaklar Hızlı Butonu */}
                <button
                  type="button"
                  onClick={() => {
                    onNavigateToView?.('PENDING');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-900 hover:bg-amber-100 transition shadow-2xs cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <ClipboardList className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Bugün Yapılacaklar</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white font-mono text-[11px] font-bold">
                    {totalPendingTasks} Bekleyen İşlem
                  </span>
                </button>

                {/* Mobil Kritik Kalite Alarmları & Bildirimler */}
                <button
                  type="button"
                  onClick={() => {
                    setIsNotificationsOpen(true);
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-900 hover:bg-rose-100 transition shadow-2xs cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Kritik Kalite Alarmları & Bildirimler</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-mono text-[11px] font-bold">
                    {notifications.filter(n => !n.isRead).length} Yeni
                  </span>
                </button>

                {/* Mobil Hızlı Portallar & Tema Çubuğu */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onNavigateToView?.('PORTAL_LAUNCHER');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                  >
                    <LayoutGrid className="w-4 h-4" />
                    <span>🏠 Portallar</span>
                  </button>

                  <button
                    type="button"
                    onClick={toggleTheme}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition cursor-pointer"
                  >
                    {theme === 'dark' ? (
                      <>
                        <Sun className="w-4 h-4 text-amber-500" />
                        <span>Aydınlık Mod</span>
                      </>
                    ) : (
                      <>
                        <Moon className="w-4 h-4 text-teal-600" />
                        <span>Karanlık Mod</span>
                      </>
                    )}
                  </button>
                </div>


              </div>
            )}

            {/* Mobile Real-time Background Sync Status */}
            <div className="pt-1">
              <SyncProgressBar
                isSyncing={!!isSyncing}
                isOnline={isOnline}
                pendingCount={offlineQueueCount}
                lastSyncTime={lastSyncTime}
                lastStatus={syncStatus}
                errorMessage={lastSyncError}
                onSyncNow={handleSafeSyncOfflineQueue}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
            {onOpenSummary && (
              <button
                onClick={() => handleSafeAction('Özet', onOpenSummary)}
                className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                <Gauge className="w-4 h-4 text-teal-700" />
                <span>Özet (KPI)</span>
              </button>
            )}
            {onOpenMonthlyReport && (
              <button
                onClick={() => handleSafeAction('Aylık Rapor', onOpenMonthlyReport)}
                className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                <FileBarChart className="w-4 h-4 text-emerald-600" />
                <span>Aylık Rapor</span>
              </button>
            )}

            <button
              onClick={() => handleSafeAction('Tavsiye & Şikayet', onOpenFeedback)}
              className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
            >
              <MessageSquarePlus className="w-4 h-4 text-amber-600" />
              <span>Tavsiye & Şikayet</span>
            </button>

            {onDownloadBackup && (
              <button
                onClick={() => handleSafeAction('Sistem Verilerini İndir', onDownloadBackup)}
                className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                <Download className="w-4 h-4 text-sky-600" />
                <span>Verileri İndir (JSON)</span>
              </button>
            )}

            {onOpenPwaModal && (
              <button
                onClick={() => handleSafeAction('Ekrana Yükle', onOpenPwaModal)}
                className="flex items-center gap-2 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>Ekrana Yükle (Logo)</span>
              </button>
            )}

            <button
              onClick={() => handleSafeAction('Saha Galeri', onOpenGallery)}
              className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 cursor-pointer"
            >
              <Camera className="w-4 h-4 text-emerald-600" />
              <span>Saha Galeri</span>
            </button>

            <button
              onClick={() => handleSafeAction('Kılavuz & Rehber', onOpenGuide)}
              className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-teal-600" />
              <span>Kılavuz & Rehber</span>
            </button>

            <button
              onClick={() => handleSafeAction('Özel Alan Ekle', onOpenCustomFields)}
              className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-amber-600" />
              <span>Alan Ekle</span>
            </button>

            {onPullFromSheets && (
              <button
                onClick={handleSafePullFromSheets}
                className="col-span-2 flex items-center justify-center gap-2 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>Google Sheets Raporu (otomatik)</span>
              </button>
            )}

            <a
              href={spreadsheetUrl || 'https://docs.google.com/spreadsheets/'}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                if (!spreadsheetUrl) {
                  e.preventDefault();
                  handleSafeAction('Google E-Tablo Kurulumu', onOpenGasModal);
                }
                setIsMobileMenuOpen(false);
              }}
              className="col-span-2 flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>📊 Google Sheets Tablosu (Yeni Sekme)</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400 opacity-80" />
            </a>

            <button
              onClick={() => handleSafeAction('Google Sheets Entegrasyon Ayarları', onOpenGasModal)}
              className="col-span-2 flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-teal-600" />
              <span>Google Sheets Entegrasyon Ayarları</span>
            </button>
            </div>
          </div>
        )}

      </div>

      {/* Modern Canvas QR Code Scanner */}
      {isQrScannerOpen && (
        <QRScannerModal
          isOpen={isQrScannerOpen}
          onClose={() => setIsQrScannerOpen(false)}
          onScanSuccess={(scannedValue) => {
            setSearchInput(scannedValue);
            onSearchRef(scannedValue);
          }}
        />
      )}
    </header>
  );
};
