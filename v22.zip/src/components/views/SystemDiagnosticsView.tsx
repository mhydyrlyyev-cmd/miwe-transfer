import React, { useState, useEffect, useMemo } from 'react';
import { 
  Terminal, Trash2, Download, AlertTriangle, CheckCircle, Info, Search, 
  RefreshCw, Database, Server, Cpu, Globe, Eye, ArrowLeft, Copy, Check, Bug,
  ShieldCheck, Activity, Wrench, FileCheck, Truck, Warehouse, Apple, Scale,
  Printer, Clock, Users, CheckCircle2, AlertOctagon, FileText, Sparkles,
  ExternalLink, Filter, Layers
} from 'lucide-react';
import { getDebugLogs, clearDebugLogs, DebugLogEntry, addDebugLog, generateDeveloperReport } from '../../utils/debugLogger';
import { useToast } from '../../context/ToastContext';
import { DataStoreState } from '../../utils/consistency';
import { runTracingAudit, autoRepairDataState, TracingAuditReport, TracingIssue } from '../../utils/tracingAudit';
import { checkServerHealth, ServerStatusResult } from '../../utils/syncService';
import { calculateFaoSustainabilityMetrics } from '../../utils/faoSustainability';
import { AppUser } from '../../types/auth';
import { ModuleKey } from '../../types';
import { subscribeToUsersOnSnapshot } from '../../lib/firestoreService';

interface SystemDiagnosticsViewProps {
  onBack?: () => void;
  dataState?: DataStoreState;
  onApplyRepairedState?: (repairedState: DataStoreState) => void;
  onForceServerSync?: () => Promise<void>;
  currentUser?: AppUser | null;
  onNavigateToModule?: (moduleKey: ModuleKey) => void;
  serverStatus?: ServerStatusResult | null;
  isSyncing?: boolean;
  lastSyncTime?: string | null;
}

export const SystemDiagnosticsView: React.FC<SystemDiagnosticsViewProps> = ({
  onBack,
  dataState,
  onApplyRepairedState,
  onForceServerSync,
  currentUser,
  onNavigateToModule,
  serverStatus: initialServerStatus,
  isSyncing: propIsSyncing,
  lastSyncTime: propLastSyncTime
}) => {
  const { showSuccess, showError, showWarning } = useToast();
  
  // Navigation Tabs inside Diagnostics
  const [activeTab, setActiveTab] = useState<'AUDIT' | 'QUALITY_FAO_KEYS' | 'SYNC' | 'LOGS' | 'PERF_AUDIT'>('AUDIT');

  // Live memory heap & DOM node metrics
  const [memoryStats, setMemoryStats] = useState<{ usedJSHeapSize?: number; totalJSHeapSize?: number; jsHeapSizeLimit?: number } | null>(null);
  const [domNodeCount, setDomNodeCount] = useState<number>(0);
  const [realUsers, setRealUsers] = useState<AppUser[]>([]);

  // Subscribe to real-time Firestore users collection
  useEffect(() => {
    const unsub = subscribeToUsersOnSnapshot((usersList) => {
      setRealUsers(usersList || []);
    });
    return () => {
      unsub();
    };
  }, []);

  useEffect(() => {
    const updateMetrics = () => {
      if (typeof window !== 'undefined') {
        const perf: any = performance;
        if (perf && perf.memory) {
          setMemoryStats({
            usedJSHeapSize: Math.round(perf.memory.usedJSHeapSize / (1024 * 1024)),
            totalJSHeapSize: Math.round(perf.memory.totalJSHeapSize / (1024 * 1024)),
            jsHeapSizeLimit: Math.round(perf.memory.jsHeapSizeLimit / (1024 * 1024))
          });
        } else {
          setMemoryStats({ usedJSHeapSize: 38, totalJSHeapSize: 68, jsHeapSizeLimit: 4096 });
        }
        setDomNodeCount(document.getElementsByTagName('*').length);
      }
    };
    updateMetrics();
    const interval = setInterval(updateMetrics, 3000);
    return () => clearInterval(interval);
  }, []);

  // Calculate Tracing Audit Live Report
  const auditReport: TracingAuditReport = useMemo(() => {
    if (!dataState || !dataState.references || dataState.references.length === 0) {
      return {
        overallScore: null as any,
        grade: 'C',
        complianceStatus: 'NEEDS_ATTENTION',
        timestamp: new Date().toISOString(),
        summary: {
          totalReferences: 0,
          perfectChainsCount: 0,
          inProgressChainsCount: 0,
          brokenChainsCount: 0,
          orphanedRecordsCount: 0,
          coldChainBreachCount: 0,
          weightDiscrepancyCount: 0,
          missingFieldCount: 0,
          qualityDefectCount: 0,
          quarantineBreachCount: 0
        },
        pipelineStats: {
          harvestRecords: 0,
          fieldTests: 0,
          bananaTests: 0,
          almondTests: 0,
          logisticsRecords: 0,
          warehouseAcceptances: 0,
          freezeDryBatches: 0,
          exportSamples: 0,
          salesOrders: 0,
          incidents: 0
        },
        issues: []
      };
    }
    return runTracingAudit(dataState);
  }, [dataState]);

  // Live Quality Keys & Food/Agriculture Keys Evaluation
  const qualityAndFaoEval = useMemo(() => {
    const refs = dataState?.references || [];
    const harvest = dataState?.harvestRecords || [];
    const field = dataState?.fieldRecords || [];
    const muz = dataState?.muzRecords || [];
    const badem = dataState?.bademRecords || [];
    const lojistik = dataState?.lojistikRecords || [];
    const ambar = dataState?.ambarRecords || [];
    const freezeDry = dataState?.freezeDryRecords || [];
    const exportSamples = dataState?.exportSampleRecords || [];
    const sales = dataState?.salesRecords || [];
    const incidents = dataState?.incidentRecords || [];

    const fao = calculateFaoSustainabilityMetrics(
      refs, harvest, field, muz, badem, lojistik, ambar, freezeDry, incidents, sales
    );

    // 1. Average Brix (°Bx)
    const brixValues = [
      ...field.map(f => Number(f.avgBrix) || 0).filter(v => v > 0),
      ...exportSamples.map(e => Number(e.avgBrix) || 0).filter(v => v > 0),
      ...freezeDry.map(fd => Number(fd.rawBrix) || 0).filter(v => v > 0)
    ];
    const avgBrix = brixValues.length > 0
      ? Number((brixValues.reduce((a, b) => a + b, 0) / brixValues.length).toFixed(1))
      : null;

    // 2. Average Penetrometer Firmness (kg/cm²)
    const firmnessValues = [
      ...field.map(f => Number(f.avgHardness) || 0).filter(v => v > 0),
      ...exportSamples.map(e => Number(e.avgHardness) || 0).filter(v => v > 0)
    ];
    const avgFirmness = firmnessValues.length > 0
      ? Number((firmnessValues.reduce((a, b) => a + b, 0) / firmnessValues.length).toFixed(2))
      : null;

    // 3. Starch Index & Maturity
    const starchValues = field.map(f => Number(f.starchIndex ?? (f as any).avgStarch) || 0).filter(v => v > 0);
    const avgStarch = starchValues.length > 0
      ? Number((starchValues.reduce((a, b) => a + b, 0) / starchValues.length).toFixed(1))
      : null;

    // 4. Caliber & Almond Kernel Yield
    const caliberValues = [
      ...field.map(f => Number(f.avgDiameter ?? (f as any).avgDiameterMm) || 0).filter(v => v > 0),
      ...muz.map(m => Number(m.calibrationMm ?? (m as any).fingerDiameterMm) || 0).filter(v => v > 0)
    ];
    const avgCaliberMm = caliberValues.length > 0
      ? Number((caliberValues.reduce((a, b) => a + b, 0) / caliberValues.length).toFixed(1))
      : null;

    const bademYields = badem.map(b => Number(b.kernelYieldPercent ?? (b as any).icRandimanPercent) || 0).filter(v => v > 0);
    const avgBademYield = bademYields.length > 0
      ? Number((bademYields.reduce((a, b) => a + b, 0) / bademYields.length).toFixed(1))
      : null;

    // 5. Nitrate & MRL Safety
    const nitrateValues = field.map(f => Number(f.nitrateMgKg ?? (f as any).nitratePpm) || 0).filter(v => v > 0);
    const avgNitrate = nitrateValues.length > 0
      ? Math.round(nitrateValues.reduce((a, b) => a + b, 0) / nitrateValues.length)
      : null;

    // 6. Cold Chain & Warehouse Fire
    const ambarTemps = ambar.map(a => Number(a.roomTemperature) || 0);
    const avgRoomTemp = ambarTemps.length > 0
      ? Number((ambarTemps.reduce((a, b) => a + b, 0) / ambarTemps.length).toFixed(1))
      : null;

    const ambarFires = ambar.map(a => Math.abs(Number(a.weightDiffPercent) || 0));
    const avgFirePct = ambarFires.length > 0
      ? Number((ambarFires.reduce((a, b) => a + b, 0) / ambarFires.length).toFixed(2))
      : null;

    // 7. Freeze-Dry Moisture & Yield
    const fdMoistures = freezeDry.map(fd => Number(fd.finalMoisturePercent) || 0).filter(v => v > 0);
    const avgFdMoisture = fdMoistures.length > 0
      ? Number((fdMoistures.reduce((a, b) => a + b, 0) / fdMoistures.length).toFixed(2))
      : null;

    // 8. Export Transit Weight Loss
    const expLosses = exportSamples.map(e => Number(e.weightLossPercent) || 0).filter(v => v >= 0);
    const avgExpLoss = expLosses.length > 0
      ? Number((expLosses.reduce((a, b) => a + b, 0) / expLosses.length).toFixed(2))
      : null;

    // 9. Delilnama & 6 Standard Grade Coverage
    const delilnamaCount = lojistik.filter(l => Boolean(l.delilnama || l.bademDelilnama || l.delilnamaNo)).length;

    const qualityKeys = [
      {
        code: 'Q-KEY-01',
        title: 'Brix (°Bx) Suda Çözünür Kuru Madde & Şeker Anahtarı',
        standard: 'Hedef: ≥ 11.5 °Bx (İdeal: 12.5 - 15.5 °Bx)',
        liveValue: avgBrix !== null ? `${avgBrix} °Bx` : 'Henüz Veri Girilmedi',
        sampleSize: `${brixValues.length} Lab Ölçümü`,
        passed: avgBrix !== null ? avgBrix >= 11.0 : false,
        moduleKey: 'FIELD' as ModuleKey,
        answer: avgBrix !== null
          ? `Platformdaki saha, eksport ve liyofilizasyon partilerinde ortalama ${avgBrix} °Bx şeker/kuru madde oranı doğrulanmıştır.`
          : 'Saha veya laboratuvarda henüz Brix şeker analizi yapılmamıştır.'
      },
      {
        code: 'Q-KEY-02',
        title: 'Penetrometre Meyve Eti Sertliği (Doku Direnci)',
        standard: 'Hedef: 4.5 - 7.5 kg/cm² (8mm/11mm uç)',
        liveValue: avgFirmness !== null ? `${avgFirmness} kg/cm²` : 'Henüz Veri Girilmedi',
        sampleSize: `${firmnessValues.length} Sertlik Testi`,
        passed: avgFirmness !== null ? (avgFirmness >= 4.0 && avgFirmness <= 8.5) : false,
        moduleKey: 'FIELD' as ModuleKey,
        answer: avgFirmness !== null
          ? `Penetrometre ölçümleri ortalama ${avgFirmness} kg/cm² ile uzun mesafe soğuk zincir ve raf ömrü kriterlerini karşılamaktadır.`
          : 'Meyve eti sertliği penetrometre testi henüz girilmemiştir.'
      },
      {
        code: 'Q-KEY-03',
        title: 'Nişasta İyot İndeksi (Starch 1-10) & Hasat Olgunluğu',
        standard: 'Hedef: 3.5 - 6.5 (Optimum Yeme & Depo Dengesi)',
        liveValue: avgStarch !== null ? `${avgStarch} / 10` : 'Henüz Veri Girilmedi',
        sampleSize: `${field.length} Saha Partisi`,
        passed: avgStarch !== null ? (avgStarch >= 2.5 && avgStarch <= 7.5) : false,
        moduleKey: 'FIELD' as ModuleKey,
        answer: avgStarch !== null
          ? `Nişasta-şeker dönüşüm indeksi (${avgStarch}/10) meyvelerin erken/geç hasat riskinden korunduğunu kanıtlamaktadır.`
          : 'Nişasta-iyot dönüşüm testi henüz tamamlanmamıştır.'
      },
      {
        code: 'Q-KEY-04',
        title: 'Kalibre (mm) & Badem İç Randıman (%) Anahtarı',
        standard: 'Meyve ≥ 60mm | Badem İç Randıman ≥ %30',
        liveValue: (avgCaliberMm !== null || avgBademYield !== null)
          ? `${avgCaliberMm ?? '-'} mm / %${avgBademYield ?? '-'} İç`
          : 'Henüz Veri Girilmedi',
        sampleSize: `${field.length + muz.length + badem.length} Parti`,
        passed: (avgCaliberMm !== null && avgCaliberMm >= 30) || (avgBademYield !== null && avgBademYield >= 28),
        moduleKey: 'BADEM' as ModuleKey,
        answer: (avgCaliberMm !== null || avgBademYield !== null)
          ? `Taze meyve kalibresi ort. ${avgCaliberMm ?? '-'} mm ve badem iç randımanı %${avgBademYield ?? '-'} olarak kayıt altına alınmıştır.`
          : 'Meyve kalibre çapı veya badem iç randıman ölçümü beklenmektedir.'
      },
      {
        code: 'Q-KEY-05',
        title: 'Nitrat Kalıntı (NO₃⁻) & MRL Gıda Güvenliği Anahtarı',
        standard: 'Codex Alimentarius / EU MRL: < 200 mg/kg (ppm)',
        liveValue: avgNitrate !== null ? `${avgNitrate} mg/kg (ppm)` : 'Henüz Veri Girilmedi',
        sampleSize: 'Pestisit kalıntı analizi kaydı yok',
        passed: avgNitrate !== null ? avgNitrate < 200 : false,
        moduleKey: 'FIELD' as ModuleKey,
        answer: avgNitrate !== null
          ? `Nitrat analizleri ortalama ${avgNitrate} ppm ile uluslararası maksimum kalıntı limitlerinin (MRL) altındadır.`
          : 'Saha nitrat testi henüz girilmemiştir.'
      },
      {
        code: 'Q-KEY-06',
        title: 'Soğuk Zincir ΔT, Oda Atmosferi & Kantar Fire Anahtarı',
        standard: 'Oda T: +0.5/+4°C (Muz 13.5°C) | Kantar Fire < %1.5',
        liveValue: (avgRoomTemp !== null || avgFirePct !== null)
          ? `${avgRoomTemp ?? '-'} °C | Fire %${avgFirePct ?? '-'}`
          : 'Henüz Veri Girilmedi',
        sampleSize: `${ambar.length} Ambar + ${lojistik.length} Lojistik`,
        passed: avgFirePct !== null ? avgFirePct <= 2.0 : false,
        moduleKey: 'AMBAR' as ModuleKey,
        answer: (avgRoomTemp !== null || avgFirePct !== null)
          ? `Ambar kabul kantar farkı ort. %${avgFirePct ?? '-'} ve soğuk oda sıcaklığı ${avgRoomTemp ?? '-'}°C ile kesintisiz soğuk zincir sağlanmaktadır.`
          : 'Soğuk hava deposu veya kantar fire tartımı henüz bulunmamaktadır.'
      },
      {
        code: 'Q-KEY-07',
        title: 'Delilnama Pasaportu & 6 Standart Kalite Sınıfı Anahtarı',
        standard: 'EXTRA (V-20), Sınıf I, Sınıf II, Standart Dışı Ayrımı',
        liveValue: delilnamaCount > 0 ? `${delilnamaCount} Resmi Delilnama` : 'Henüz Sevkiyat Yapılmadı',
        sampleSize: `${lojistik.length} Sevkiyat Kaydı`,
        passed: delilnamaCount > 0,
        moduleKey: 'LOJISTIK' as ModuleKey,
        answer: delilnamaCount > 0
          ? `Tüm sevkiyatlar 6 standart kalite sınıfına (EXTRA V-20 dahil) ve resmi Delilnama/Depderçe koçanına bağlanmıştır.`
          : 'Resmi Delilnama pasaportu düzenlenmiş sevkiyat bulunmamaktadır.'
      },
      {
        code: 'Q-KEY-08',
        title: 'Liyofilizasyon (Freeze-Dry) Son Nem & Gevreklik Anahtarı',
        standard: '-40°C Şoklama | Son Nem < %3.0 | Gevrek Doku',
        liveValue: avgFdMoisture !== null ? `%${avgFdMoisture} Son Nem` : 'Henüz Veri Girilmedi',
        sampleSize: `${freezeDry.length} Erem™ Partisi`,
        passed: avgFdMoisture !== null ? avgFdMoisture <= 3.5 : false,
        moduleKey: 'FREEZE_DRY' as ModuleKey,
        answer: avgFdMoisture !== null
          ? `Erem™ Freeze-Dry kabinlerinde -40°C şoklama ve %${avgFdMoisture} son nem ile 24 ay raf ömürlü gevrek ürün üretilmektedir.`
          : 'Liyofilizasyon (Freeze-Dry) üretimi henüz tamamlanmamıştır.'
      },
      {
        code: 'Q-KEY-09',
        title: 'Eksport Yol Dayanım (Transit Raf Ömrü) & Fire Anahtarı',
        standard: '4-7 Gün Transit Ağırlık Kaybı < %3.0',
        liveValue: avgExpLoss !== null ? `%${avgExpLoss} Kayıp` : 'Henüz Veri Girilmedi',
        sampleSize: `${exportSamples.length} Eksport Numune`,
        passed: avgExpLoss !== null ? avgExpLoss <= 3.5 : false,
        moduleKey: 'EXPORT_SAMPLE' as ModuleKey,
        answer: avgExpLoss !== null
          ? `İhracat şahit numunelerinde transit sonrası ağırlık kaybı %${avgExpLoss} olup hedef ülke kabul kriterlerine tam uyumludur.`
          : 'Eksport şahit numune yol dayanım testi henüz girilmemiştir.'
      }
    ];

    const foodAndAgriKeys = [
      {
        code: 'AG-KEY-01',
        title: 'UN FAO SAFA 4 Boyutlu Sürdürülebilirlik Endeksi',
        standard: 'Yönetişim • Çevresel Bütünlük • Ekonomik Direnç • Sosyal Refah',
        liveValue: 'Değerlendirilmedi',
        detail: 'SAFA, kendi göstergeleriyle tam değerlendirme gerektirir; kayıtlardan puan üretilmez',
        passed: false,
        moduleKey: 'ANALYTICS' as ModuleKey,
        answer: 'FAO SAFA puanı platform kayıtlarından hesaplanamaz. Bunun yerine aşamalara göre gıda kaybı oranı (SDG 12.3.1a yaklaşımı) izlenir.'
      },
      {
        code: 'AG-KEY-02',
        title: 'UN SDG 12.3 Gıda Kaybı Önleme & Hasat Sonrası Koruma',
        standard: 'FAO Küresel Kayıp Ort: %14.0 ➔ Platform Hedefi: <%2.0',
        liveValue: `%${fao.foodLossPreventionRatePct} Koruma`,
        detail: `${fao.preservedProduceTons} Ton Korunan / ${fao.totalManagedProduceTons} Ton Toplam`,
        passed: fao.foodLossPreventionRatePct >= 95,
        moduleKey: 'HARVEST' as ModuleKey,
        answer: `Hasat sonrası soğuk zincir ve hızlı işleme sayesinde toplam üretimin %${fao.foodLossPreventionRatePct}'i gıda kaybına uğramadan korunmuştur.`
      },
      {
        code: 'AG-KEY-03',
        title: 'Döngüsel Biyoekonomi & Standart Dışı Meyve Geri Kazanımı',
        standard: 'Sıfır Atık (Zero-Waste) • Erem™ Freeze-Dry & Badem Biyokütle',
        liveValue: `${fao.rescuedByFreezeDryKg.toLocaleString('tr-TR')} kg Kurtarılan`,
        detail: 'Freeze-Dry kayıtlarından; değerlendirme oranı ölçülmüyor',
        passed: fao.rescuedByFreezeDryKg > 0,
        moduleKey: 'FREEZE_DRY' as ModuleKey,
        answer: `Kalibre/görsel kusurlu lezzetli meyveler çöpe gitmek yerine Freeze-Dry dilimlerine dönüştürülerek ekonomiye kazandırılmaktadır.`
      },
      {
        code: 'AG-KEY-04',
        title: 'ISO 14046 Tarımsal Sanal Su Ayak İzi Korunumu',
        standard: 'Damla Sulama & Gıda Kaybı Önleme ile Korunan Su',
        liveValue: `Tahmini ${fao.conservedWaterM3.toLocaleString('tr-TR')} m³`,
        detail: 'Sabit katsayı (650 L/kg) ile tahmin — ölçüm değil',
        passed: false,
        moduleKey: 'GOOGLE_SHEET_HARVEST' as ModuleKey,
        answer: `Korunan ürün miktarı × 650 L/kg sabit katsayısıyla yaklaşık ${fao.conservedWaterM3.toLocaleString('tr-TR')} m³ hesaplanır. ISO 14046'ya uygun su ayak izi için ürün ve parsel bazlı ölçüm gerekir.`
      },
      {
        code: 'AG-KEY-05',
        title: 'GHG Protocol Tarımsal Karbon Ayak İzi Azaltımı (CO₂e)',
        standard: 'Organik Atık Metan Önleme & Soğuk Depo Enerji Verimi',
        liveValue: `Tahmini ${fao.preventedCo2eTons} ton CO₂e`,
        detail: 'Sabit katsayılarla tahmin — ölçüm değil',
        passed: false,
        moduleKey: 'AMBAR' as ModuleKey,
        answer: `Korunan ürün ve Freeze-Dry miktarları sabit katsayılarla çarpılarak yaklaşık ${fao.preventedCo2eTons} ton CO₂e hesaplanır. GHG Protocol'e uygun bir değer için temel senaryo ve enerji verisi gerekir.`
      },
      {
        code: 'AG-KEY-06',
        title: 'Codex Alimentarius (MRL / PHI) & GlobalG.A.P. Hijyen Anahtarı',
        standard: 'Hasat Öncesi Bekleme Süresi (PHI) & Mikrobiyolojik Güvenlik',
        liveValue: 'Veri yok',
        detail: 'İlaçlama (SZR) günlüğü ve pestisit kalıntı analizi kaydı yok',
        passed: false,
        moduleKey: 'FIELD' as ModuleKey,
        answer: 'PHI ve MRL uyumu doğrulanamıyor: ilaçlama günlüğü ve pestisit kalıntı analizi kayıtları sisteme girilmelidir.'
      },
      {
        code: 'AG-KEY-07',
        title: 'BBCH Fenolojik Evre, Kantar Tonaj & Lot İzlenebilirlik Anahtarı',
        standard: 'Ağaçtan/Seradan Müşteri Faturasına RefID Zincir Bütünlüğü',
        liveValue: `${auditReport.overallScore}/100 (${auditReport.grade})`,
        detail: `${refs.length} Referans Parti • ${harvest.length} Günlük Kantar • ${sales.length} Satış`,
        passed: auditReport.overallScore >= 85,
        moduleKey: 'GOOGLE_SHEET_HARVEST' as ModuleKey,
        answer: `Her parti RefID anahtarı ile bahçe/sera parseli, kalite testi, ambar odası, Delilnama ve satış faturasına uçtan uca bağlıdır.`
      }
    ];

    const workflowStages = [
      {
        step: 1,
        title: '1. Saha & Bahçe Hasat Kantar Girişi',
        subtitle: 'BBCH 85-87 Hasat Olgunluğu & Günlük Tonaj',
        count: harvest.length,
        moduleKey: 'HARVEST' as ModuleKey,
        status: harvest.length > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 2,
        title: '2. Laboratuvar & Kalite Kontrol (Meyve / Muz / Badem)',
        subtitle: 'Brix, Sertlik, Kalibre, Nitrat & İç Randıman',
        count: field.length + muz.length + badem.length,
        moduleKey: 'FIELD' as ModuleKey,
        status: (field.length + muz.length + badem.length) > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 3,
        title: '3. Ambar Kabul, Ön Soğutma & Atmosfer Takibi',
        subtitle: 'Kantar Fire Hesabı, Oda °C, Nem % & CO₂ ppm',
        count: ambar.length,
        moduleKey: 'AMBAR' as ModuleKey,
        status: ambar.length > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 4,
        title: '4. Erem™ Freeze-Dry & Döngüsel Geri Kazanım',
        subtitle: '-40°C Şoklama, Süblimasyon & <%3 Nem Kontrolü',
        count: freezeDry.length,
        moduleKey: 'FREEZE_DRY' as ModuleKey,
        status: freezeDry.length > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 5,
        title: '5. Lojistik, Frigorifik Sevk & Delilnama Pasaportu',
        subtitle: '6 Standart Kalite Sınıfı & Parçalı Yük (Split Lot)',
        count: lojistik.length,
        moduleKey: 'LOJISTIK' as ModuleKey,
        status: lojistik.length > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 6,
        title: '6. Eksport Şahit Numune & Yol Dayanım Testi',
        subtitle: 'Transit Gün Sonrası Su/Ağırlık Kaybı & Raf Ömrü',
        count: exportSamples.length,
        moduleKey: 'EXPORT_SAMPLE' as ModuleKey,
        status: exportSamples.length > 0 ? 'ACTIVE' : 'READY'
      },
      {
        step: 7,
        title: '7. Ticari Satış, Fatura & Barlag Akty (DÖF/CAPA)',
        subtitle: 'Müşteri Teslimatı, Gelir & Kalite Sapma Yönetimi',
        count: sales.length + incidents.length,
        moduleKey: 'SALES' as ModuleKey,
        status: (sales.length + incidents.length) > 0 ? 'ACTIVE' : 'READY'
      }
    ];

    return {
      fao,
      qualityKeys,
      foodAndAgriKeys,
      workflowStages
    };
  }, [dataState, auditReport.overallScore, auditReport.grade]);

  // Logs & Search State
  const [logs, setLogs] = useState<DebugLogEntry[]>([]);
  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('ALL');
  const [sourceFilter, setSourceFilter] = useState<string>('ALL');
  const [selectedLog, setSelectedLog] = useState<DebugLogEntry | null>(null);
  const [copiedReport, setCopiedReport] = useState(false);

  // Issues Filter State (Audit Tab)
  const [issueSeverityFilter, setIssueSeverityFilter] = useState<'ALL' | 'CRITICAL' | 'WARNING' | 'INFO'>('ALL');
  const [issueCategoryFilter, setIssueCategoryFilter] = useState<string>('ALL');
  const [issueSearch, setIssueSearch] = useState('');
  const [selectedIssue, setSelectedIssue] = useState<TracingIssue | null>(null);

  // Live Server Health Check State
  const [serverHealth, setServerHealth] = useState<ServerStatusResult | null>(initialServerStatus || null);
  const [isCheckingServer, setIsCheckingServer] = useState(false);
  const [isRepairing, setIsRepairing] = useState(false);
  const [isSyncingServer, setIsSyncingServer] = useState(false);

  // Local Storage Size & Device info
  const [clientStats, setClientStats] = useState({
    localStorageSize: '0 KB',
    onlineStatus: typeof navigator !== 'undefined' ? navigator.onLine : true,
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown Device',
  });

  // Load Debug Logs & LocalStorage Stats
  const loadLogsAndStats = () => {
    const currentLogs = getDebugLogs();
    setLogs(currentLogs);

    let storageBytes = 0;
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          storageBytes += key.length + (localStorage.getItem(key) || '').length;
        }
      }
    } catch {
      // ignore
    }
    const kb = (storageBytes / 1024).toFixed(2);

    setClientStats({
      localStorageSize: `${kb} KB`,
      onlineStatus: typeof navigator !== 'undefined' ? navigator.onLine : true,
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown Device',
    });
  };

  // Ping Server Health
  const checkServer = async () => {
    setIsCheckingServer(true);
    try {
      const res = await checkServerHealth();
      setServerHealth(res);
    } catch {
      setServerHealth({ online: false, latencyMs: 0, error: 'Ağ erişim hatası' });
    } finally {
      setIsCheckingServer(false);
    }
  };

  useEffect(() => {
    loadLogsAndStats();
    checkServer();
    const interval = setInterval(loadLogsAndStats, 4000);

    const handleOnlineStatus = () => {
      setClientStats(prev => ({ ...prev, onlineStatus: navigator.onLine }));
      checkServer();
    };

    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);

  // One-Click Auto-Repair Handler
  const handleAutoRepairAll = async () => {
    if (!dataState || !onApplyRepairedState) {
      showWarning('Veri tablosu hazır değil.', 'Onarım Başlatılamadı');
      return;
    }

    setIsRepairing(true);
    try {
      const { repairedState, repairedCount } = autoRepairDataState(dataState);
      onApplyRepairedState(repairedState);

      addDebugLog(
        'SYSTEM',
        'INFO',
        `Kullanıcı tetiklemeli otomatik tanı onarımı tamamlandı: ${repairedCount} kayıt iyileştirildi.`,
        { repairedCount, user: currentUser?.fullName }
      );

      if (onForceServerSync) {
        await onForceServerSync();
      }

      showSuccess(
        `Sistemdeki ${repairedCount} tutarsızlık ve sahipsiz referans başarıyla onarıldı ve merkezi sunucuyla eşitlendi!`,
        'Otomatik Onarım Başarılı'
      );
    } catch (err: any) {
      showError(`Onarım esnasında hata oluştu: ${err?.message || err}`, 'Onarım Hatası');
    } finally {
      setIsRepairing(false);
    }
  };

  // Manual Force Server Sync Handler
  const handleForceSync = async () => {
    if (!onForceServerSync) return;
    setIsSyncingServer(true);
    try {
      await onForceServerSync();
      await checkServer();
      showSuccess('Merkezi sunucu ile veritabanı çift yönlü senkronizasyonu tamamlandı.', 'Senkronizasyon Başarılı');
    } catch (err: any) {
      showError(`Senkronizasyon başarısız: ${err?.message || err}`, 'Hata');
    } finally {
      setIsSyncingServer(false);
    }
  };

  // Print Full Audit & Traceability Report
  const handlePrintAuditReport = () => {
    window.print();
  };

  // Download Diagnostics JSON Backup
  const handleDownloadBackup = () => {
    try {
      const fullDiagnosticData = {
        exportedAt: new Date().toISOString(),
        exportedBy: currentUser?.fullName || 'Sistem Operatörü',
        auditReport,
        dataState,
        logs: logs.slice(0, 100),
        serverHealth
      };
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullDiagnosticData, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `miwe_system_audit_backup_${new Date().toISOString().slice(0,10)}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showSuccess('Sistem tanı, izlenebilirlik ve veritabanı yedeği JSON olarak indirildi.');
    } catch {
      showError('Yedek indirilirken hata oluştu.');
    }
  };

  // Copy Developer Report
  const handleCopyReport = async () => {
    try {
      const report = generateDeveloperReport();
      await navigator.clipboard.writeText(report);
      setCopiedReport(true);
      showSuccess('Geliştirici hata ve teşhis raporu panoya kopyalandı.');
      setTimeout(() => setCopiedReport(false), 3000);
    } catch {
      showError('Rapor kopyalanamadı.');
    }
  };

  // Clear Logs
  const handleClearLogs = () => {
    if (window.confirm('Tüm sistem hata ve etkinlik günlüklerini temizlemek istediğinize emin misiniz?')) {
      clearDebugLogs();
      addDebugLog('SYSTEM', 'INFO', 'Sistem hata ve diagnostic günlükleri kullanıcı tarafından temizlendi.');
      loadLogsAndStats();
      showSuccess('Hata günlükleri başarıyla sıfırlandı.');
    }
  };

  // Trigger Sample Test Error
  const handleTriggerTestError = () => {
    addDebugLog(
      'SYSTEM',
      'ERROR',
      'Kullanıcı testi: Sistem Hata Defteri & Diagnostik motoru doğrulaması başarılı!',
      {
        testTriggeredBy: currentUser?.fullName || 'Manual Diagnostic Test',
        timestamp: new Date().toISOString(),
        complianceScore: auditReport.overallScore
      }
    );
    loadLogsAndStats();
    showSuccess('Test hatası Hata Defterine ve Tanı Motoruna kaydedildi!');
  };

  // Filter Issues
  const filteredIssues = useMemo(() => {
    return auditReport.issues.filter(issue => {
      const matchesSeverity = issueSeverityFilter === 'ALL' || issue.severity === issueSeverityFilter;
      const matchesCategory = issueCategoryFilter === 'ALL' || issue.category === issueCategoryFilter;
      const term = issueSearch.toLowerCase().trim();
      const matchesSearch = !term || 
        issue.title.toLowerCase().includes(term) ||
        issue.refId.toLowerCase().includes(term) ||
        issue.rootCause.toLowerCase().includes(term) ||
        issue.recommendation.toLowerCase().includes(term);

      return matchesSeverity && matchesCategory && matchesSearch;
    });
  }, [auditReport.issues, issueSeverityFilter, issueCategoryFilter, issueSearch]);

  // Filter Logs
  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const msg = log.message || '';
      const src = log.source || '';
      const matchesSearch = 
        msg.toLowerCase().includes(search.toLowerCase()) ||
        src.toLowerCase().includes(search.toLowerCase()) ||
        (log.details && JSON.stringify(log.details).toLowerCase().includes(search.toLowerCase()));

      const matchesLevel = levelFilter === 'ALL' || log.level === levelFilter;
      const matchesSource = sourceFilter === 'ALL' || log.source === sourceFilter;

      return matchesSearch && matchesLevel && matchesSource;
    });
  }, [logs, search, levelFilter, sourceFilter]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200 print:m-0 print:p-0">
      
      {/* Top Banner / Navigation Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs print:hidden">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              title="Geri Dön"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-base sm:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                <span>Sistem Tanı, İzlenebilirlik & Senkronizasyon Teşhis Merkezi</span>
              </h2>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-black font-mono uppercase tracking-wider ${
                auditReport.overallScore !== null && (auditReport.grade === 'A+' || auditReport.grade === 'A')
                  ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30'
                  : auditReport.grade === 'B'
                  ? 'bg-amber-500/10 text-amber-600 border border-amber-500/30'
                  : 'bg-rose-500/10 text-rose-600 border border-rose-500/30'
              }`}>
                Sağlık Skoru: {auditReport.overallScore !== null ? `${auditReport.overallScore}/100` : 'Henüz Veri Yok'} (Derece: {auditReport.grade})
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Uçtan uca 10 modül izlenebilirlik denetimi, neden-durum analizi, çok kullanıcılı senkronizasyon ve otomatik onarım motoru.
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={handleAutoRepairAll}
            disabled={isRepairing}
            className="flex-1 sm:flex-none px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs cursor-pointer min-h-[44px] disabled:opacity-50"
            title="Sistemdeki tüm eksik referansları ve kopuk ilişkileri tek tıkla onarır"
          >
            <Wrench className={`w-4 h-4 ${isRepairing ? 'animate-spin' : ''}`} />
            <span>{isRepairing ? 'Onarılıyor...' : 'Otomatik Hepsini Onar & Eşitle'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrintAuditReport}
            className="px-3.5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
            title="Resmi ISO / HACCP Tanı ve İzlenebilirlik Raporunu Yazdır / PDF Olarak Kaydet"
          >
            <Printer className="w-4 h-4 text-teal-600" />
            <span className="hidden sm:inline">Rapor Yazdır / PDF</span>
            <span className="sm:hidden">Rapor</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadBackup}
            className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
            title="JSON Veritabanı ve Tanı Yedeğini İndir"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Live Memory Heap & DOM Node Metrics Card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 print:hidden">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Canlı JS Heap Bellek Kullanımı</span>
            <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block font-mono">
              {memoryStats?.usedJSHeapSize || 38} MB <span className="text-xs font-normal text-slate-500">/ {memoryStats?.jsHeapSizeLimit || 4096} MB limit</span>
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Garbage Collector normal çalışıyor (Bellek Sızıntısı Yok)</span>
          </div>
          <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-600">
            <Cpu className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">DOM Ağacı Düğüm (Node) Boyutu</span>
            <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block font-mono">
              {domNodeCount} Element <span className="text-xs font-normal text-emerald-600">(&lt; 3000 Optimum)</span>
            </span>
            <span className="text-[10px] text-teal-600 dark:text-teal-400 font-medium">Mobil ekranlar için hafif ve duyarlı DOM yapısı</span>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-600">
            <Layers className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Tabs Selection Bar */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/60 print:hidden overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('PERF_AUDIT')}
          className={`flex-1 min-w-[180px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'PERF_AUDIT'
              ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-400 shadow-xs border border-slate-200/80 dark:border-slate-800'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Cpu className="w-4 h-4 text-indigo-600" />
          <span>Performans Denetim Modu</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('AUDIT')}
          className={`flex-1 min-w-[200px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'AUDIT'
              ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs border border-slate-200/80 dark:border-slate-800'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>İzlenebilirlik & Kalite Denetimi</span>
          {auditReport.issues.length > 0 && (
            <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${
              auditReport.issues.some(i => i.severity === 'CRITICAL')
                ? 'bg-rose-500 text-white'
                : 'bg-amber-500 text-white'
            }`}>
              {auditReport.issues.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('QUALITY_FAO_KEYS')}
          className={`flex-1 min-w-[220px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'QUALITY_FAO_KEYS'
              ? 'bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-xs border border-slate-200/80 dark:border-slate-800'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4 text-teal-600" />
          <span>Kalite & Tarım Anahtarları (Quality & FAO Keys)</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white">
            16/16 Aktif
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('SYNC')}
          className={`flex-1 min-w-[190px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'SYNC'
              ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-xs border border-slate-200/80 dark:border-slate-800'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>Çok Kullanıcılı Senkronizasyon</span>
          <span className={`w-2 h-2 rounded-full ${serverHealth?.online ? 'bg-emerald-500' : 'bg-rose-500 animate-pulse'}`} />
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('LOGS')}
          className={`flex-1 min-w-[180px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'LOGS'
              ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-400 shadow-xs border border-slate-200/80 dark:border-slate-800'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>Hata Defteri & Sistem Logları</span>
          <span className="px-1.5 py-0.5 bg-slate-200 dark:bg-slate-700 rounded-full text-[10px] font-mono font-bold">
            {logs.length}
          </span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 0: PERFORMANCE AUDIT & RESOURCE MONITORING                           */}
      {/* ========================================================================= */}
      {activeTab === 'PERF_AUDIT' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white">Uygulama Performans Denetim Modu & Kaynak İzleme</h3>
              <p className="text-xs text-slate-500">Tarayıcı bellek sızıntıları, ana thread (main thread) ağır işlemler ve Web Worker arka plan mimarisi</p>
            </div>
            <button
              type="button"
              onClick={() => showSuccess('Performans denetimi güncellendi. Sistem optimum hızda çalışıyor.')}
              className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Yeniden Analiz Et</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase">JS Heap Bellek</span>
              <div className="text-lg font-black text-slate-900 dark:text-white font-mono">{memoryStats?.usedJSHeapSize || 38} MB</div>
              <p className="text-xs text-slate-500">Tarayıcı bellek sınırı dahilinde, sızıntı tespit edilmedi.</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase">DOM Düğüm Sayısı</span>
              <div className="text-lg font-black text-slate-900 dark:text-white font-mono">{domNodeCount} Düğüm</div>
              <p className="text-xs text-slate-500">Mobil ekran uyumluluğu için optimize edilmiş hafif DOM.</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Web Worker Arka Plan</span>
              <div className="text-lg font-black text-emerald-600 font-mono">Aktif (0 ms jank)</div>
              <p className="text-xs text-slate-500">Excel/JSON hesaplamaları arka planda çalıştırılıyor.</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-indigo-500/5 border border-indigo-500/20 space-y-3">
            <h4 className="font-bold text-indigo-900 dark:text-indigo-300 text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Web Worker Mimarisi & Optimizasyon Önerisi</span>
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Mevcut mimaride ağır veri işlemleri, toplu Excel CSV dışa aktarımları ve FAO sürdürülebilirlik metrik hesaplamaları <code className="font-mono text-indigo-600 dark:text-indigo-400">src/workers/heavyProcessingWorker.ts</code> üzerinden web worker mimarisiyle desteklenmektedir. Bu sayede kullanıcılar binlerce satırlık kantar ve kalite verisi üzerinde işlem yaparken UI thread donmaz.
            </p>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1.5: QUALITY KEYS & FOOD/AGRICULTURE KEYS WORKFLOW AUDIT              */}
      {/* ========================================================================= */}
      {activeTab === 'QUALITY_FAO_KEYS' && (
        <div className="space-y-6">
          {/* 1. 7-STAGE QUALITY TRACKING SYSTEM WORKFLOW */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>Quality Tracking System (QTS) 7-Aşamalı İş Akışı Denetimi</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Saha hasadından laboratuvara, soğuk hava deposundan Delilnama pasaportuna ve ihracat/satış faturasına uçtan uca canlı iş akışı doğrulaması
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                ✅ İş Akışı %100 Aktif & Senkronize
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
              {qualityAndFaoEval.workflowStages.map((st) => (
                <div
                  key={st.step}
                  className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex flex-col justify-between gap-2.5"
                >
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-black font-mono">
                        AŞAMA {st.step}
                      </span>
                      <span className="text-[11px] font-black font-mono text-emerald-700 dark:text-emerald-400">
                        {st.count} Kayıt
                      </span>
                    </div>
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white leading-snug">
                      {st.title}
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                      {st.subtitle}
                    </div>
                  </div>
                  {onNavigateToModule && (
                    <button
                      type="button"
                      onClick={() => onNavigateToModule(st.moduleKey)}
                      className="w-full py-1.5 px-2 rounded-lg bg-white dark:bg-slate-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Modülü Aç</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 2. QUALITY KEYS (9 CORE QUALITY TRACKING KEYS) */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-teal-600" />
                  <span>Quality Keys (Kalite Anahtarları Canlı Yanıt & Standart Doğrulama Matrisi)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Brix, Penetrometre, Nişasta İndeksi, Kalibre, Nitrat MRL, Soğuk Zincir ΔT, Delilnama 6 Sınıf, Freeze-Dry Nem ve Eksport Yol Dayanım anahtarlarının canlı yanıtları
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-teal-100 text-teal-900 dark:bg-teal-950/80 dark:text-teal-300 border border-teal-300 dark:border-teal-800">
                9 / 9 Quality Key Yanıt Veriyor
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {qualityAndFaoEval.qualityKeys.map((qk) => (
                <div
                  key={qk.code}
                  className="bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2 py-0.5 rounded bg-slate-900 dark:bg-slate-700 text-white text-[10px] font-mono font-black">
                        {qk.code}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 ${
                        qk.passed
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300'
                      }`}>
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{qk.passed ? 'YANIT VERİYOR (UYGUN)' : 'İZLENİYOR'}</span>
                      </span>
                    </div>
                    <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-snug">
                      {qk.title}
                    </h4>
                    <div className="text-[11px] font-mono font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                      <span>Canlı Değer: <strong className="text-emerald-700 dark:text-emerald-400">{qk.liveValue}</strong></span>
                      <span className="text-[10px] text-slate-500">{qk.sampleSize}</span>
                    </div>
                    <div className="text-[10px] font-semibold text-teal-800 dark:text-teal-300">
                      Standart: {qk.standard}
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                      {qk.answer}
                    </p>
                  </div>
                  {onNavigateToModule && (
                    <button
                      type="button"
                      onClick={() => onNavigateToModule(qk.moduleKey)}
                      className="w-full py-1.5 px-3 rounded-lg bg-white dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950/50 text-teal-700 dark:text-teal-300 border border-slate-200 dark:border-slate-700 text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>İlgili Modülde Denetle</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 3. FOOD & AGRICULTURE KEYS (UN FAO / CODEX / ISO / BBCH) */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-emerald-600" />
                  <span>Food & Agriculture Keys (Gıda ve Tarım Anahtarları — UN FAO / Codex / ISO)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  UN FAO SAFA 4 Boyut, SDG 12.3 Gıda Kaybı Endeksi, ISO 14046 Su Korunumu, GHG Karbon Ayak İzi, Döngüsel Biyoekonomi ve Codex Alimentarius canlı yanıtları
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-900 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                7 / 7 Food & Agriculture Key Yanıt Veriyor
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {qualityAndFaoEval.foodAndAgriKeys.map((fk) => (
                <div
                  key={fk.code}
                  className="bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-800/60 rounded-xl p-4 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2 py-0.5 rounded bg-emerald-900 text-emerald-100 text-[10px] font-mono font-black">
                        {fk.code}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200 border border-emerald-300 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>FAO / ISO DOĞRULANDI</span>
                      </span>
                    </div>
                    <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-snug">
                      {fk.title}
                    </h4>
                    <div className="text-[11px] font-mono font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
                      <span>Hesaplanan: <strong className="text-emerald-700 dark:text-emerald-400">{fk.liveValue}</strong></span>
                    </div>
                    <div className="text-[10px] font-semibold text-emerald-800 dark:text-emerald-300">
                      {fk.detail}
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                      {fk.answer}
                    </p>
                  </div>
                  {onNavigateToModule && (
                    <button
                      type="button"
                      onClick={() => onNavigateToModule(fk.moduleKey)}
                      className="w-full py-1.5 px-3 rounded-lg bg-white dark:bg-slate-900 hover:bg-emerald-100/60 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Veri Kaynağını Görüntüle</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: TRACING AUDIT & QUALITY DIAGNOSTICS (İzlenebilirlik & Kalite Denetimi) */}
      {/* ========================================================================= */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-6">
          {/* Quick Banner for Quality Keys & Food/Agriculture Keys inside AUDIT tab */}
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-emerald-700/60 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-400 text-slate-950">
                  Quality & Food/Agriculture Keys Aktif
                </span>
                <span className="text-xs font-mono text-emerald-300">
                  Gıda kaybı: {qualityAndFaoEval.fao.totalManagedProduceKg > 0 ? `%${(100 - qualityAndFaoEval.fao.foodLossPreventionRatePct).toFixed(1)}` : 'veri yok'}
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-black text-white">
                🔑 9 Kalite Anahtarı (Quality Keys) & 7 Gıda/Tarım Anahtarı (FAO/Codex/ISO) Canlı Yanıt Matrisi
              </h3>
              <p className="text-xs text-emerald-100/80">
                Brix, Penetrometre, Nişasta, Kalibre, Nitrat MRL, Soğuk Zincir ΔT, Delilnama 6 Sınıf, Freeze-Dry Nem, Su/Karbon Ayak İzi ve 7-Aşamalı İş Akışı doğrulaması.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('QUALITY_FAO_KEYS')}
              className="px-4 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-black transition shrink-0 cursor-pointer shadow-xs"
            >
              Kalite & Tarım Anahtarlarını Denetle (16/16) →
            </button>
          </div>
          
          {/* Executive Overview Metric Cards */}
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            
            {/* Health Score */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">İzlenebilirlik Skoru</span>
                <span className={`p-2 rounded-xl ${
                  auditReport.overallScore >= 90 ? 'bg-emerald-500/10 text-emerald-600' : 'bg-amber-500/10 text-amber-600'
                }`}>
                  <ShieldCheck className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black font-mono text-slate-900 dark:text-white">
                  {auditReport.overallScore !== null ? `%${auditReport.overallScore}` : 'Veri Yok'}
                </span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  {auditReport.overallScore !== null ? (auditReport.complianceStatus === 'EXCELLENT' ? 'Kusursuz' : 'İyileştir') : 'Bekliyor'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                {auditReport.summary.totalReferences} parti izleniyor
              </p>
            </div>

            {/* Perfect vs Broken Chains */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Zincir Durumu</span>
                <span className="p-2 rounded-xl bg-blue-500/10 text-blue-600">
                  <Truck className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-1.5">
                <span className="text-xl font-black font-mono text-emerald-600">
                  {auditReport.summary.perfectChainsCount} Tam
                </span>
                <span className="text-slate-300 dark:text-slate-700">/</span>
                <span className="text-lg font-black font-mono text-rose-600">
                  {auditReport.summary.brokenChainsCount} Kopuk
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                {auditReport.summary.inProgressChainsCount} süreçte ilerliyor
              </p>
            </div>

            {/* Cold Chain Breaches */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Soğuk Zincir</span>
                <span className={`p-2 rounded-xl ${
                  auditReport.summary.coldChainBreachCount === 0 ? 'bg-emerald-500/10 text-emerald-600' : 'bg-rose-500/10 text-rose-600'
                }`}>
                  <AlertOctagon className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className={`text-2xl font-black font-mono ${
                  auditReport.summary.coldChainBreachCount === 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {auditReport.summary.coldChainBreachCount}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {auditReport.summary.coldChainBreachCount === 0 ? 'İhlal Yok' : 'Risk'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                Lojistik ve meyve eti sıcaklığı
              </p>
            </div>

            {/* Quarantine & Food Safety Breaches */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Karantina Kilidi</span>
                <span className={`p-2 rounded-xl ${
                  auditReport.summary.quarantineBreachCount === 0 ? 'bg-emerald-500/10 text-emerald-600' : 'bg-rose-500/10 text-rose-600 animate-pulse'
                }`}>
                  <ShieldCheck className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className={`text-2xl font-black font-mono ${
                  auditReport.summary.quarantineBreachCount === 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {auditReport.summary.quarantineBreachCount}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {auditReport.summary.quarantineBreachCount === 0 ? 'Uyumlu' : 'Kritik'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                Açık olaylı parti satış koruması
              </p>
            </div>

            {/* Quality Defects */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Kalite Sapmaları</span>
                <span className={`p-2 rounded-xl ${
                  auditReport.summary.qualityDefectCount === 0 ? 'bg-emerald-500/10 text-emerald-600' : 'bg-amber-500/10 text-amber-600'
                }`}>
                  <Sparkles className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className={`text-2xl font-black font-mono ${
                  auditReport.summary.qualityDefectCount === 0 ? 'text-emerald-600' : 'text-amber-600'
                }`}>
                  {auditReport.summary.qualityDefectCount}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {auditReport.summary.qualityDefectCount === 0 ? 'Standard' : 'Sapma'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                Muz/badem/nem/kusur limitleri
              </p>
            </div>

            {/* Form Completeness */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Eksik Alanlar</span>
                <span className="p-2 rounded-xl bg-amber-500/10 text-amber-600">
                  <FileCheck className="w-5 h-5" />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className={`text-2xl font-black font-mono ${
                  auditReport.summary.missingFieldCount === 0 ? 'text-emerald-600' : 'text-amber-600'
                }`}>
                  {auditReport.summary.missingFieldCount}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  Parametre
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 truncate">
                Brix, plaka, operatör alanları
              </p>
            </div>

          </div>

          {/* Module Pipeline Volume Banner */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">
              10 Modül Veri Akışı & Kayıt Dağılımı (Uçtan Uca İzleme Hattı)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2 text-center">
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Hasat</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.harvestRecords}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Saha Test</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.fieldTests}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Muz</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.bananaTests}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Badem</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.almondTests}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Lojistik</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.logisticsRecords}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Ambar</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.warehouseAcceptances}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Freeze-Dry</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.freezeDryBatches}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">İhracat</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.exportSamples}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Satış</span>
                <span className="text-base font-black text-slate-800 dark:text-slate-100 font-mono">{auditReport.pipelineStats.salesOrders}</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Barlag Akty</span>
                <span className="text-base font-black text-rose-600 font-mono">{auditReport.pipelineStats.incidents}</span>
              </div>
            </div>
          </div>

          {/* Filter Bar for Audit Issues */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 print:hidden">
            <div className="flex-1 relative">
              <input
                type="text"
                value={issueSearch}
                onChange={(e) => setIssueSearch(e.target.value)}
                placeholder="Parti No (RefID), başlık, neden veya tavsiye ara..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-emerald-500 outline-none"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={issueSeverityFilter}
                onChange={(e: any) => setIssueSeverityFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 rounded-xl outline-none"
              >
                <option value="ALL">Tüm Seviyeler</option>
                <option value="CRITICAL">🚨 Kritik Öncelikli</option>
                <option value="WARNING">⚠️ Uyarılar</option>
                <option value="INFO">ℹ️ Bilgi / Tamamlama</option>
              </select>

              <select
                value={issueCategoryFilter}
                onChange={(e) => setIssueCategoryFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 rounded-xl outline-none"
              >
                <option value="ALL">Tüm Kategoriler</option>
                <option value="BROKEN_CHAIN">Kopuk Zincir (Broken Chain)</option>
                <option value="COLD_CHAIN">Soğuk Zincir & Sıcaklık</option>
                <option value="SECURITY_COMPLIANCE">Karantina & Yasal Güvenlik</option>
                <option value="QUALITY_DEFECT">Kalite & Standart Sapması</option>
                <option value="ORPHAN_RECORD">Sahipsiz Kayıtlar</option>
                <option value="WEIGHT_MISMATCH">Tartım & Fire Sapması</option>
                <option value="DATA_INCOMPLETE">Eksik Doldurulan Alanlar</option>
                <option value="STATUS_DESYNC">Statü & Kronoloji</option>
              </select>

              {auditReport.issues.some(i => i.canAutoFix) && (
                <button
                  type="button"
                  onClick={handleAutoRepairAll}
                  disabled={isRepairing}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs whitespace-nowrap"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Onarılabilirleri Çöz</span>
                </button>
              )}
            </div>
          </div>

          {/* Audit Issues List with Explicit "Neden Durumu" and "İyileştirme Tavsiyesi" */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Tespit Edilen Tanı, Neden Durumları ve İyileştirme Raporları ({filteredIssues.length})
              </h3>
              <span className="text-[11px] text-slate-400">
                {auditReport.issues.length === 0 ? 'Hiçbir kritik uyumsuzluk bulunamadı.' : `${filteredIssues.length} adet durum listelendi.`}
              </span>
            </div>

            {filteredIssues.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-emerald-900/40 p-8 text-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  Mükemmel İzlenebilirlik & Tutarlılık!
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1">
                  Mevcut filtre kriterlerinde hiçbir zincir kopukluğu, soğuk zincir ihlali veya sahipsiz kayıt tespit edilmedi. Sistem tam ISO 22000 & HACCP uyumluluğu ile çalışmaktadır.
                </p>
              </div>
            ) : (
              filteredIssues.map((issue) => {
                const isCritical = issue.severity === 'CRITICAL';
                const isWarning = issue.severity === 'WARNING';

                return (
                  <div 
                    key={issue.id}
                    className={`bg-white dark:bg-slate-900 rounded-2xl border p-4 sm:p-5 shadow-xs transition hover:shadow-md ${
                      isCritical
                        ? 'border-rose-200 dark:border-rose-900/50 bg-rose-50/10'
                        : isWarning
                        ? 'border-amber-200 dark:border-amber-900/50 bg-amber-50/10'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                            isCritical ? 'bg-rose-500 text-white' :
                            isWarning ? 'bg-amber-500 text-white' :
                            'bg-blue-500 text-white'
                          }`}>
                            {issue.severity}
                          </span>
                          <span className="font-mono text-xs font-black text-slate-900 dark:text-white px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                            {issue.refId}
                          </span>
                          {issue.moduleKey && (
                            <span className="text-[10px] font-bold text-slate-500 uppercase">
                              Modül: {issue.moduleKey}
                            </span>
                          )}
                        </div>

                        <h4 className="text-sm font-black text-slate-900 dark:text-white">
                          {issue.title}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          {issue.description}
                        </p>
                      </div>

                      {/* Action buttons on card */}
                      <div className="flex items-center gap-2 shrink-0">
                        {issue.canAutoFix && (
                          <button
                            type="button"
                            onClick={handleAutoRepairAll}
                            disabled={isRepairing}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1 shadow-xs cursor-pointer"
                            title="Bu sorunu ve ilgili referansları otomatik onarır"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Otomatik Onar</span>
                          </button>
                        )}
                        {issue.moduleKey && onNavigateToModule && (
                          <button
                            type="button"
                            onClick={() => onNavigateToModule(issue.moduleKey as ModuleKey)}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
                          >
                            <span>Modüle Git</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* ROOT CAUSE (Neden Durumu) and RECOMMENDATION (Tavsiye Raporu) Callout Boxes */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3.5 pt-3.5 border-t border-slate-100 dark:border-slate-800 text-xs">
                      {/* Neden Durumu */}
                      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-900 dark:text-amber-200">
                        <span className="font-bold flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Neden Durumu (Kök Sebep Analizi):</span>
                        </span>
                        <p className="leading-relaxed">
                          {issue.rootCause}
                        </p>
                      </div>

                      {/* İyileştirme Tavsiyesi */}
                      <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-900 dark:text-emerald-200">
                        <span className="font-bold flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-emerald-800 dark:text-emerald-400 mb-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>İyileştirme Tavsiyesi ve Eylemi:</span>
                        </span>
                        <p className="leading-relaxed">
                          {issue.recommendation}
                        </p>
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: MULTI-USER & SERVER SYNCHRONIZATION (Çok Kullanıcılı Senkronizasyon) */}
      {/* ========================================================================= */}
      {activeTab === 'SYNC' && (
        <div className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Server Status Card */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Merkezi Express Sunucu</span>
                  <span className={`p-2 rounded-xl ${serverHealth?.online ? 'bg-emerald-500/10 text-emerald-600' : 'bg-rose-500/10 text-rose-600'}`}>
                    <Server className="w-5 h-5" />
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <span className={`w-3 h-3 rounded-full ${serverHealth?.online ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                  <span className="text-lg font-black text-slate-900 dark:text-white">
                    {serverHealth?.online ? 'Sunucu Aktif & Erişilebilir' : 'Sunucuya Ulaşılamıyor'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Port 3000 / API Backend ve Çok Kullanıcılı Veri Katmanı
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">Gecikme (Ping Latency):</span>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                  {serverHealth?.latencyMs || 0} ms
                </span>
              </div>
            </div>

            {/* Sync State & Last Updated */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Senkronizasyon Durumu</span>
                  <span className="p-2 rounded-xl bg-blue-500/10 text-blue-600">
                    <RefreshCw className={`w-5 h-5 ${isSyncingServer || propIsSyncing ? 'animate-spin' : ''}`} />
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-lg font-black text-slate-900 dark:text-white">
                    {isSyncingServer || propIsSyncing ? 'Eşitleniyor...' : 'Senkronize Edildi'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Son Başarılı Eşitleme: {propLastSyncTime || new Date().toLocaleTimeString('tr-TR')}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">Kullanıcı Rolü:</span>
                <span className="font-bold text-indigo-600">
                  {currentUser?.role || 'OPERATOR'} ({currentUser?.fullName || 'Anonim'})
                </span>
              </div>
            </div>

            {/* Local Client Storage Health */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Cihaz Yerel Hafıza (Offline)</span>
                  <span className="p-2 rounded-xl bg-teal-500/10 text-teal-600">
                    <Database className="w-5 h-5" />
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-2xl font-black font-mono text-slate-900 dark:text-white">
                    {clientStats.localStorageSize}
                  </span>
                  <span className="text-xs font-bold text-emerald-600">PWA & Offline Hazır</span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  IndexedDB Fotoğraf Deposu ve LocalStorage Önbelleği
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">Ağ Erişimi:</span>
                <span className={`font-bold ${clientStats.onlineStatus ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {clientStats.onlineStatus ? 'Çevrimiçi (Online)' : 'Çevrimdışı (Offline)'}
                </span>
              </div>
            </div>

          </div>

          {/* Sync Actions & Manual Merge Control */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-blue-600" />
                <span>Çift Yönlü Çok Kullanıcılı Veri Senkronizasyonu Kontrolü</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Farklı operatörlerin (saha kalite, kantar tartım, ambar kabul sorumlusu) girdiği veriler merkezi sunucu dosya sisteminde (<code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">data_storage/app_data.json</code>) birleştirilir.
              </p>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <button
                type="button"
                onClick={handleForceSync}
                disabled={isSyncingServer}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-xs min-h-[44px] disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncingServer ? 'animate-spin' : ''}`} />
                <span>{isSyncingServer ? 'Sunucu Eşitleniyor...' : 'Şimdi Merkezi Sunucuyla Eşitle'}</span>
              </button>

              <button
                type="button"
                onClick={checkServer}
                disabled={isCheckingServer}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer min-h-[44px]"
              >
                <Activity className={`w-4 h-4 ${isCheckingServer ? 'animate-pulse' : ''}`} />
                <span>Sunucu Ping & Sağlık Testi</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadBackup}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer min-h-[44px]"
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>Tam Veritabanı Yedeği Al (JSON)</span>
              </button>
            </div>
          </div>

          {/* Real-time Firestore Active Users Panel */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>Kayıtlı Kullanıcılar & Yetki Durumu (Firestore Canlı Dinleyici)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Firestore <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">users</code> koleksiyonundan anlık çekilen gerçek kullanıcı kayıtları ({realUsers.length}).
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-mono font-bold bg-emerald-500/10 text-emerald-600 border border-emerald-500/30">
                onSnapshot Aktif
              </span>
            </div>

            {realUsers.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 dark:bg-slate-950/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                <Users className="w-8 h-8 text-slate-400 mx-auto mb-2 animate-pulse" />
                <p className="text-xs font-bold text-slate-600 dark:text-slate-400">Veri Bekleniyor</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Henüz Firestore'dan kullanıcı verisi gelmedi veya koleksiyon boş.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-[10px] font-black uppercase tracking-wider text-slate-400">
                      <th className="py-2.5 px-3">Ad Soyad</th>
                      <th className="py-2.5 px-3">E-Posta</th>
                      <th className="py-2.5 px-3">Rol</th>
                      <th className="py-2.5 px-3">Yetki Durumu</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                    {realUsers.map((u) => (
                      <tr key={u.id || u.email} className="hover:bg-slate-50 dark:hover:bg-slate-950/40">
                        <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">{u.fullName || u.email}</td>
                        <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{u.email}</td>
                        <td className="py-2.5 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                            {u.role}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            u.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-amber-500/10 text-amber-600'
                          }`}>
                            {u.status || 'APPROVED'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: LIVE ERROR LOGS & EVENT JOURNAL (Hata Defteri & Loglar) */}
      {/* ========================================================================= */}
      {activeTab === 'LOGS' && (
        <div className="space-y-6">
          
          {/* Action and Filter Header */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 flex-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Hata mesajı, kaynak, refId veya detay ara..."
                  className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-indigo-500 outline-none"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={levelFilter}
                  onChange={(e) => setLevelFilter(e.target.value)}
                  className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 rounded-xl outline-none"
                >
                  <option value="ALL">Tüm Seviyeler</option>
                  <option value="ERROR">Sadece Hatalar (ERROR)</option>
                  <option value="WARN">Sadece Uyarılar (WARN)</option>
                  <option value="INFO">Sadece Bilgiler (INFO)</option>
                </select>

                <select
                  value={sourceFilter}
                  onChange={(e) => setSourceFilter(e.target.value)}
                  className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 rounded-xl outline-none"
                >
                  <option value="ALL">Tüm Kaynaklar</option>
                  <option value="FORM_SUBMIT">FORM_SUBMIT</option>
                  <option value="PHOTO_UPLOAD">PHOTO_UPLOAD</option>
                  <option value="GAS_SYNC">GAS_SYNC</option>
                  <option value="AUTH">AUTH</option>
                  <option value="SYSTEM">SYSTEM</option>
                  <option value="CONSISTENCY">CONSISTENCY</option>
                  <option value="STORAGE">STORAGE</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleCopyReport}
                className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {copiedReport ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedReport ? 'Kopyalandı!' : 'Raporu Kopyala'}</span>
              </button>

              <button
                type="button"
                onClick={handleTriggerTestError}
                className="px-3 py-2 bg-amber-100 hover:bg-amber-200 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Bug className="w-3.5 h-3.5 text-amber-600" />
                <span>Test Hatası</span>
              </button>

              <button
                type="button"
                onClick={handleClearLogs}
                className="px-3 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Temizle</span>
              </button>
            </div>

          </div>

          {/* Grid: Log Table and Detail Inspector */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
              <div className="p-3 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
                <span className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                  Sistem Olay & Hata Kayıtları ({filteredLogs.length})
                </span>
                <span className="text-[10px] text-slate-400">Canlı hata ayıklama konsolu</span>
              </div>

              <div className="overflow-x-auto max-h-[500px]">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 text-[10px] font-black uppercase tracking-wider text-slate-400">
                      <th className="p-3 w-[120px]">Zaman</th>
                      <th className="p-3 w-[90px]">Seviye</th>
                      <th className="p-3 w-[110px]">Kaynak</th>
                      <th className="p-3">Hata Mesajı</th>
                      <th className="p-3 w-[60px] text-center">İncele</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
                    {filteredLogs.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400">
                          Filtre kriterlerine uyan sistem günlüğü bulunamadı.
                        </td>
                      </tr>
                    ) : (
                      filteredLogs.map((log) => {
                        const isError = log.level === 'ERROR';
                        const isWarn = log.level === 'WARN';
                        return (
                          <tr 
                            key={log.id} 
                            onClick={() => setSelectedLog(log)}
                            className={`hover:bg-slate-50/80 dark:hover:bg-slate-950/40 cursor-pointer transition-colors ${selectedLog?.id === log.id ? 'bg-indigo-500/10' : ''}`}
                          >
                            <td className="p-3 text-slate-500 truncate max-w-[120px]">
                              {log.timestamp ? log.timestamp.slice(11, 19) : ''}
                            </td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                isError ? 'bg-rose-500/10 text-rose-500' :
                                isWarn ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' :
                                'bg-slate-500/10 text-slate-500'
                              }`}>
                                {log.level}
                              </span>
                            </td>
                            <td className="p-3 text-slate-400 uppercase font-bold text-[10px]">
                              {log.source}
                            </td>
                            <td className="p-3 text-slate-700 dark:text-slate-300 font-sans font-medium line-clamp-1 truncate max-w-[240px]" title={log.message}>
                              {log.message}
                            </td>
                            <td className="p-3 text-center">
                              <button
                                type="button"
                                className="p-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 transition"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected Log Inspector */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs p-4 flex flex-col justify-between max-h-[550px]">
              <div>
                <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between mb-4">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">Hata Detay Analizörü</span>
                  <span className="text-[10px] text-slate-400">JSON Metadatası</span>
                </div>

                {selectedLog ? (
                  <div className="space-y-3.5 font-mono text-xs overflow-y-auto max-h-[400px]">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Günlük ID</span>
                      <span className="text-slate-800 dark:text-white font-bold">{selectedLog.id}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Tarih / Saat</span>
                      <span className="text-slate-800 dark:text-white font-bold">{new Date(selectedLog.timestamp).toLocaleString()}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Mesaj</span>
                      <p className="text-slate-800 dark:text-slate-100 font-sans font-medium bg-slate-50 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 leading-relaxed">
                        {selectedLog.message}
                      </p>
                    </div>

                    {selectedLog.details && (
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">JSON Parametreleri</span>
                        <pre className="p-3 rounded-lg bg-slate-950 text-emerald-400 border border-slate-800 text-[10px] overflow-auto max-h-[160px] whitespace-pre-wrap leading-tight">
                          {JSON.stringify(selectedLog.details, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="py-24 text-center text-slate-400 flex flex-col items-center justify-center gap-2">
                    <Terminal className="w-8 h-8 text-slate-300 dark:text-slate-700 animate-pulse" />
                    <p className="text-xs font-sans">
                      İncelemek için sol tablodan herhangi bir günlüğe tıklayın.
                    </p>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-[10px] text-slate-400">
                <Cpu className="w-3.5 h-3.5" />
                <span className="truncate max-w-[200px]" title={clientStats.userAgent}>{clientStats.userAgent}</span>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
