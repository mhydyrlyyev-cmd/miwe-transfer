import React, { useMemo, useState } from 'react';
import { ArrowLeft, X, Info } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, ReferenceLine, YAxis, BarChart, Bar, XAxis, Tooltip, Cell } from 'recharts';
import {
  KpiData,
  KpiPeriod,
  KpiResult,
  SUMMARY_KPIS,
  SECONDARY_KPIS,
  lossBreakdown,
  monthlySeries
} from '../../utils/kpiEngine';

/**
 * Özet ekranı (v2.2) — yönetici ve yatırımcı için tek ekran.
 * Her sayı kpiEngine.ts içinden gelir; burada hesaplama yapılmaz.
 */

type PeriodKey = 'THIS_MONTH' | 'LAST_3' | 'LAST_12' | 'ALL';

const PERIODS: Array<{ key: PeriodKey; label: string }> = [
  { key: 'THIS_MONTH', label: 'Bu ay' },
  { key: 'LAST_3', label: 'Son 3 ay' },
  { key: 'LAST_12', label: 'Son 12 ay' },
  { key: 'ALL', label: 'Tümü' }
];

function periodOf(key: PeriodKey, now = new Date()): KpiPeriod | undefined {
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  if (key === 'THIS_MONTH') return { from: new Date(now.getFullYear(), now.getMonth(), 1), to: end };
  if (key === 'LAST_3') return { from: new Date(now.getFullYear(), now.getMonth() - 2, 1), to: end };
  if (key === 'LAST_12') return { from: new Date(now.getFullYear(), now.getMonth() - 11, 1), to: end };
  return undefined;
}

const STATUS_STYLE: Record<KpiResult['status'], { text: string; chip: string; bar: string }> = {
  OK: { text: 'Hedefte', chip: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300', bar: 'bg-emerald-500' },
  WARN: { text: 'Hedef dışı', chip: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300', bar: 'bg-rose-500' },
  NO_TARGET: { text: 'Hedef yok', chip: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300', bar: 'bg-slate-300 dark:bg-slate-600' },
  NO_DATA: { text: 'Veri yok', chip: 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300', bar: 'bg-amber-300' }
};

const fmt = (v: number | null, unit: string) => {
  if (v === null) return '—';
  const digits = unit === '%' ? 1 : unit.includes('/kg') ? 2 : 0;
  return v.toLocaleString('tr-TR', { minimumFractionDigits: 0, maximumFractionDigits: digits });
};

interface SummaryViewProps extends KpiData {
  onBack: () => void;
}

export default function SummaryView({ onBack, ...data }: SummaryViewProps) {
  const [periodKey, setPeriodKey] = useState<PeriodKey>('LAST_3');
  const [openKpi, setOpenKpi] = useState<KpiResult | null>(null);
  const period = useMemo(() => periodOf(periodKey), [periodKey]);

  const main = useMemo(() => SUMMARY_KPIS.map(fn => ({ r: fn(data, period), series: monthlySeries(fn, data, 12) })), [data, period]);
  const secondary = useMemo(() => SECONDARY_KPIS.map(fn => fn(data, period)), [data, period]);
  const losses = useMemo(() => lossBreakdown(data, period), [data, period]);
  const lossRows = losses.stages.filter(s => s.kg > 0);

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-5">
      {/* Başlık */}
      <div className="flex items-start gap-3">
        <button
          onClick={onBack}
          className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 min-h-[44px] min-w-[44px] flex items-center justify-center"
          aria-label="Geri"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">Özet</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Her sayı platform kayıtlarından hesaplanır. Bir göstergeye dokunarak dayandığı kayıtları görün.
          </p>
        </div>
      </div>

      {/* Dönem */}
      <div className="flex gap-1.5 overflow-x-auto pb-1" role="tablist" aria-label="Dönem">
        {PERIODS.map(p => (
          <button
            key={p.key}
            role="tab"
            aria-selected={periodKey === p.key}
            onClick={() => setPeriodKey(p.key)}
            className={`px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap min-h-[40px] border ${
              periodKey === p.key
                ? 'bg-teal-700 text-white border-teal-700'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Ana göstergeler */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3">
        {main.map(({ r, series }) => {
          const st = STATUS_STYLE[r.status];
          const isSnapshot = r.key === 'capaOverdue'; // dönemden bağımsız anlık durum
          const hasSeries = !isSnapshot && series.some(s => s.value !== null);
          return (
            <button
              key={r.key}
              onClick={() => setOpenKpi(r)}
              className="relative text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 overflow-hidden focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-500"
            >
              <span className={`absolute left-0 top-0 bottom-0 w-1 ${st.bar}`} aria-hidden="true" />
              <div className="flex items-start justify-between gap-2">
                <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 leading-tight">{r.title}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold whitespace-nowrap ${st.chip}`}>{st.text}</span>
              </div>
              <div className="mt-1.5 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">{fmt(r.value, r.unit)}</span>
                {r.value !== null && <span className="text-xs text-slate-500">{r.unit}</span>}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                {r.detail || (r.value === null ? 'Bu dönemde kayıt yok' : '')}
              </div>
              <div className="h-10 mt-1.5" aria-hidden="true">
                {hasSeries ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={series} margin={{ top: 4, right: 2, bottom: 0, left: 2 }}>
                      <YAxis hide domain={['auto', 'auto']} />
                      {r.target !== null && <ReferenceLine y={r.target} stroke="#94a3b8" strokeDasharray="3 3" />}
                      <Line type="monotone" dataKey="value" stroke="#0f766e" strokeWidth={1.75} dot={false} connectNulls isAnimationActive={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center text-[10px] text-slate-400">{isSnapshot ? 'Anlık durum, dönemden bağımsız' : '12 aylık eğilim için veri yok'}</div>
                )}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                <span>n = {r.n}</span>
                {r.target !== null && <span>hedef {r.targetDirection === 'max' ? '≤' : '≥'} {fmt(r.target, r.unit)}</span>}
              </div>
            </button>
          );
        })}
      </div>

      {/* Aşamalara göre kayıp */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 sm:p-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">Kayıp nerede oluşuyor</h2>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
          {losses.baseKg > 0
            ? `Taban: ${losses.baseKg.toLocaleString('tr-TR')} kg (${losses.baseSource}). Müşteri aşaması FAO kayıp endeksine dahil değildir.`
            : 'Bu dönemde hasat veya depo kabul kaydı yok.'}
        </p>
        {lossRows.length > 0 ? (
          <div className="mt-3" style={{ height: Math.max(120, lossRows.length * 36) }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lossRows} layout="vertical" margin={{ top: 0, right: 48, bottom: 0, left: 0 }}>
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="stage" width={130} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  formatter={(v: any, _n: any, item: any) => [`${Number(v).toLocaleString('tr-TR')} kg${item?.payload?.pct !== null ? ` (%${item.payload.pct})` : ''}`, 'Kayıp']}
                  cursor={{ fill: 'rgba(148,163,184,0.12)' }}
                />
                <Bar dataKey="kg" radius={[0, 4, 4, 0]} isAnimationActive={false} label={{ position: 'right', fontSize: 11, fill: '#475569', formatter: (v: any) => `${Number(v).toLocaleString('tr-TR')} kg` }}>
                  {lossRows.map(s => <Cell key={s.stage} fill={s.stage === 'Müşteri' ? '#cbd5e1' : '#0f766e'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="mt-3 text-xs text-slate-500">Kayıtlı kayıp yok. Depo kabulünde beklenen ve kabul edilen ağırlık ile çürük kg girildiğinde burada görünür.</p>
        )}
      </section>

      {/* Diğer göstergeler */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-100 dark:divide-slate-800">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white px-3 sm:px-4 pt-3 pb-2">Diğer göstergeler</h2>
        {secondary.map(r => {
          const st = STATUS_STYLE[r.status];
          return (
            <button
              key={r.key}
              onClick={() => setOpenKpi(r)}
              className="w-full flex items-center justify-between gap-3 px-3 sm:px-4 py-2.5 text-left min-h-[48px]"
            >
              <span className="min-w-0">
                <span className="block text-xs font-semibold text-slate-800 dark:text-slate-200">{r.title}</span>
                <span className="block text-[10px] text-slate-500 truncate">{r.detail || `n = ${r.n}`}</span>
              </span>
              <span className="flex items-center gap-2 flex-shrink-0">
                <span className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                  {fmt(r.value, r.unit)}{r.value !== null ? ` ${r.unit}` : ''}
                </span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${st.chip}`}>{st.text}</span>
              </span>
            </button>
          );
        })}
      </section>

      <p className="text-[10px] text-slate-400 flex items-start gap-1.5">
        <Info className="w-3.5 h-3.5 flex-shrink-0" aria-hidden="true" />
        Hedefleri kalite departmanı belirler; tanımlanmamış hedef için “Hedef yok” görünür.
      </p>

      {/* Dayanak kayıtlar */}
      {openKpi && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setOpenKpi(null)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-label={openKpi.title}
            className="bg-white dark:bg-slate-900 w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl max-h-[85vh] flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">{openKpi.title}</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">{openKpi.formula}</p>
              </div>
              <button onClick={() => setOpenKpi(null)} className="p-2 rounded-lg text-slate-500 min-h-[40px] min-w-[40px] flex items-center justify-center" aria-label="Kapat">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="px-4 py-2 text-xs text-slate-600 dark:text-slate-300 flex gap-4">
              <span>Değer: <strong className="text-slate-900 dark:text-white">{fmt(openKpi.value, openKpi.unit)}{openKpi.value !== null ? ` ${openKpi.unit}` : ''}</strong></span>
              <span>n = {openKpi.n}</span>
            </div>
            <ul className="overflow-y-auto px-4 pb-4 divide-y divide-slate-100 dark:divide-slate-800">
              {openKpi.sources.length === 0 && <li className="py-3 text-xs text-slate-500">Bu dönemde dayanak kayıt yok.</li>}
              {openKpi.sources.map((s, i) => (
                <li key={`${s.id}-${i}`} className="py-2 text-xs">
                  <div className="flex justify-between gap-2">
                    <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">{s.refId || s.id}</span>
                    <span className="text-slate-400">{s.date}</span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-400">{s.label}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
