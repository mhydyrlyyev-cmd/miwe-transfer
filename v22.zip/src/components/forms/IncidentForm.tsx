import React, { useState, useRef } from 'react';
import { AlertOctagon, ArrowLeft, Save, Camera, AlertTriangle, ShieldAlert, CheckCircle2, UserCheck, Flame, DollarSign, Calendar, Layers, Upload, Trash2, Image as ImageIcon, Plus, X, Info } from 'lucide-react';
import { IncidentRecord, ReferenceItem, IncidentPriority, IncidentStatus } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { generateRefId } from '../../utils/calculations';
import { getUsers } from '../../utils/authService';
import { addNotification } from '../../utils/notificationService';

interface IncidentFormProps {
  onSave: (record: IncidentRecord, refId: string) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: IncidentRecord;
  isReadOnly?: boolean;
}

export const IncidentForm: React.FC<IncidentFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  isReadOnly = false
}) => {
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId || ''));
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Kalite Denetim Uzmanı');
  const [assignedTo, setAssignedTo] = useState<string>(initialRecord?.assignedTo || 'Mehmet Demir (Depo Amiri)');

  // Build list of assignable staff members (system users + operational leads)
  const systemUsers = getUsers();
  const staffOptions = React.useMemo(() => {
    const list = [
      'Mehmet Demir (Depo Amiri)',
      'Ahmet Yılmaz (Saha Kalite Sorumlusu)',
      'Canan Kaya (Lojistik Müdürü)',
      'Serkan Yıldız (İhracat & İade Uzmanı)',
      'Ayşe Çelik (Sera Toplama Lideri)'
    ];
    systemUsers.forEach(u => {
      const nameRole = `${u.fullName} (${u.role === 'ADMIN' ? 'Sistem Yöneticisi' : 'Saha Personeli'})`;
      if (!list.includes(nameRole)) list.push(nameRole);
    });
    return list;
  }, [systemUsers]);

  // Selected reference context
  const selectedRef = existingRefs.find(r => r.refId === selectedRefId);

  // Auto-generated Incident ID & Act Number
  const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const [incidentId] = useState(initialRecord?.incidentId || `INC-${todayStr}-${String(Math.floor(100 + Math.random() * 900))}`);
  const [actNumber, setActNumber] = useState(initialRecord?.actNumber || `AKT-${todayStr.slice(2, 6)}-${String(Math.floor(10 + Math.random() * 90))}`);
  const [incidentDate, setIncidentDate] = useState(initialRecord?.incidentDate || new Date().toISOString().split('T')[0]);
  const [incidentType, setIncidentType] = useState(initialRecord?.incidentType || 'Fiziksel Hasar / Kalite Sapması');
  const [detectionStage, setDetectionStage] = useState<'Sera İçi' | 'Hasat / Kesim' | 'Yıkama & Paketleme' | 'Soğuk Depo / Gazlama Odası' | 'Yükleme / Lojistik' | 'Müşteri / Varış Noktası'>((initialRecord?.detectionStage as any) || 'Soğuk Depo / Gazlama Odası');
  const [priority, setPriority] = useState<IncidentPriority>((initialRecord?.priority as any) || 'HIGH');
  const [actDegree, setActDegree] = useState<1 | 2 | 3>((initialRecord?.actDegree as any) || 2); // Akt Dereje: 1, 2, 3
  const [affectedQuantityKg, setAffectedQuantityKg] = useState<number>(initialRecord?.affectedQuantityKg ?? 0);
  const [rootCauseCategory, setRootCauseCategory] = useState<'İnsan / Operatör Hatası' | 'Ekipman / Makine Arızası' | 'Sıcaklık / Soğuk Zincir İhlali' | 'Ambalaj / Malzeme Kusuru' | 'Doğal / Biyolojik Etken'>((initialRecord?.rootCauseCategory as any) || 'İnsan / Operatör Hatası');
  
  // Investigation & Actions
  const [description, setDescription] = useState(initialRecord?.description || '');
  const [rootCause, setRootCause] = useState(initialRecord?.rootCause || '');
  const [immediateAction, setImmediateAction] = useState(initialRecord?.immediateAction || '');
  const [correctiveAction, setCorrectiveAction] = useState(initialRecord?.correctiveAction || '');
  const [responsible, setResponsible] = useState(initialRecord?.responsible || '');
  const [evidence, setEvidence] = useState(initialRecord?.evidence || '');
  const [status, setStatus] = useState<IncidentStatus>((initialRecord?.status as any) || 'OPEN');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  
  // Real Photo Upload State (Cold-Start: no sample photos)
  const [photos, setPhotos] = useState<string[]>(
    initialRecord?.photos && initialRecord.photos.length > 0
      ? initialRecord.photos
      : []
  );
  const [isDragging, setIsDragging] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // File Upload Handlers
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
      e.target.value = '';
    }
  };

  const processFiles = (files: File[]) => {
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const addPresetPhoto = (url: string) => {
    setPhotos(prev => [...prev, url]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let finalRefId = selectedRefId.trim() || initialRecord?.refId || '';
    if (!finalRefId) {
      finalRefId = generateRefId('INCIDENT', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Kalite Denetim Uzmanı';
    const finalDescription = description.trim() || `${detectionStage} aşamasında ${incidentType || 'kalite sapması'} tespit edildi (${affectedQuantityKg} kg).`;

    const incidentRecord: IncidentRecord = {
      id: initialRecord?.id || `inc-${Date.now()}`,
      refId: finalRefId,
      incidentId: incidentId.trim() || '',
      actNumber,
      actDegree,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      assignedTo,
      incidentDate,
      incidentType: incidentType.trim() || 'Fiziksel Hasar / Kalite Sapması',
      detectionStage,
      priority,
      affectedQuantityKg,
      rootCauseCategory,
      description: finalDescription,
      rootCause,
      immediateAction,
      correctiveAction,
      responsible,
      evidence,
      status,
      notes,
      photos
    };

    // Automatically create a task notification for the assigned staff member
    if (assignedTo) {
      addNotification(
        'ALL',
        `🚨 GÖREV ATANDI: ${incidentId}`,
        `Atanan Sorumlu: ${assignedTo} | Barlag Akty No: ${actNumber || 'N/A'}. ${detectionStage} aşamasında ${incidentType} (${affectedQuantityKg} kg). DÖF Aksiyonu: ${correctiveAction || 'Saha incelemesi bekleniyor'}.`,
        'TASK_ASSIGNED',
        '/incidents',
        { incidentId, refId: finalRefId, priority: priority as any }
      );
    }

    onSave(incidentRecord, finalRefId);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      {/* Modern Header */}
      <div className="bg-slate-900 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shadow-inner shrink-0">
            <AlertOctagon className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                Kalite Sapması, Hasar & Barlag Akty (Incident Protokolü)
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-extrabold uppercase bg-amber-950 text-amber-300 border border-amber-800">
                Resmi Kalite Tutanağı
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 line-clamp-2 sm:line-clamp-none">
              Kusur tespiti, Akt derecelendirmesi (1, 2, 3), kök neden analizi ve DÖF aksiyonları
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="self-end sm:self-center shrink-0 flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Hızlı Yardımcı Notlar & Standartlar Kutusu */}
        <div className="bg-rose-50/90 border border-rose-200 rounded-2xl p-4 text-xs text-rose-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-rose-900">
            <Info className="w-4 h-4 text-rose-700 shrink-0" />
            <span>💡 Uygunsuzluk & DÖF (Düzeltici Önleyici Faaliyet) Kılavuzu:</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px] text-rose-900/90 leading-relaxed">
            <div className="bg-white/70 p-2 rounded-lg border border-rose-200/60">
              <strong>Kritik Hata (Karantina):</strong> Yüksek mikrobiyolojik yük, bozulma, çürüme veya kimyasal/nitrat aşımında parti derhal karantinaya alınır.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-rose-200/60">
              <strong>Kök Neden Analizi:</strong> Hatanın kaynağı (Hammadde, Soğuk Zincir Kesintisi, Personel Eğitimi, Ekipman Arızası) net belirlenmelidir.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-rose-200/60">
              <strong>DÖF Takibi:</strong> Belirlenen aksiyon ve sorumlu kişi takibi kapatılana kadar parti sevk edilemez.
            </div>
          </div>
        </div>

        {/* Selected Reference Badge / Selector */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1">
              Olayın Bağlı Olduğu Parti / Referans (RefID Seçin veya Yazın)
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                list="incident-ref-list"
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                placeholder="Örn: REF-101 veya genel olay için boş bırakın..."
                className="w-full md:w-96 text-xs font-mono font-bold bg-white border border-rose-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-rose-500"
              />
              <datalist id="incident-ref-list">
                {existingRefs.map(r => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} — {r.product} [{r.quantity} {r.unit}]
                  </option>
                ))}
              </datalist>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 text-xs flex-wrap">
            <div className="bg-white px-3 py-2 rounded-lg border border-rose-200">
              <span className="text-[10px] text-slate-500 block">Sistem Incident ID</span>
              <strong className="font-mono text-rose-900">{incidentId}</strong>
            </div>

            <div className="bg-white px-3 py-2 rounded-lg border border-rose-200">
              <span className="text-[10px] text-slate-500 block">Resmi Barlag Akty No</span>
              <input
                type="text"
                value={actNumber}
                onChange={(e) => setActNumber(e.target.value)}
                className="text-xs font-mono font-bold text-slate-900 bg-transparent border-b border-rose-300 focus:outline-none"
                placeholder="Örn: AKT-2026-08"
              />
            </div>
          </div>
        </div>

        {/* Section 1: Classification & Severity */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Raporlayan / Müfettiş *
            </label>
            <input
              type="text"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
             
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-teal-800 block mb-1 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-teal-600" />
              <span>Görevlendirilen Sorumlu (Assign To) *</span>
            </label>
            <select
              value={assignedTo}
              onChange={(e) => setAssignedTo(e.target.value)}
              className="w-full text-xs bg-white border border-teal-300 font-bold text-teal-900 rounded-lg px-3 py-2 focus:ring-2 focus:ring-teal-500 shadow-xs"
            >
              {staffOptions.map(staff => (
                <option key={staff} value={staff}>{staff}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Olay / Sapma Tarihi
            </label>
            <input
              type="date"
              value={incidentDate}
              onChange={(e) => setIncidentDate(e.target.value)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Olay / Kusur Türü *
            </label>
            <select
              value={incidentType}
              onChange={(e) => setIncidentType(e.target.value)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-semibold text-slate-900"
            >
              {AUTOCOMPLETE_LISTS.incidentTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Tespit Aşaması / Lokasyon *
            </label>
            <select
              value={detectionStage}
              onChange={(e) => setDetectionStage(e.target.value as any)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-semibold"
            >
              <option value="Sera İçi">Sera İçi / Parsel</option>
              <option value="Hasat / Kesim">Hasat / Kesim Aşaması</option>
              <option value="Yıkama & Paketleme">Yıkama & Paketleme Tesisi</option>
              <option value="Soğuk Depo / Gazlama Odası">Soğuk Depo / Gazlama Odası</option>
              <option value="Yükleme / Lojistik">Yükleme / Lojistik & Araç</option>
              <option value="Müşteri / Varış Noktası">Müşteri / Varış Noktası</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Öncelik / Risk Seviyesi *
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as any)}
              className={`w-full text-xs border rounded-lg px-3 py-2 font-bold ${
                priority === 'CRITICAL' ? 'bg-rose-100 text-rose-950 border-rose-400' :
                priority === 'HIGH' ? 'bg-orange-100 text-orange-950 border-orange-400' :
                priority === 'MEDIUM' ? 'bg-amber-100 text-amber-950 border-amber-400' :
                'bg-blue-100 text-blue-950 border-blue-400'
              }`}
            >
              <option value="LOW">Düşük (Tolerans İçi)</option>
              <option value="MEDIUM">Orta (İnceleme Gerektirir)</option>
              <option value="HIGH">Yüksek (Acil Aksiyon Gerekli)</option>
              <option value="CRITICAL">KRİTİK (Hemen Durdurma & Bloke)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Etkilenen Miktar (kg)
            </label>
            <input
              type="number"
              value={affectedQuantityKg}
              onChange={(e) => setAffectedQuantityKg(Number(e.target.value))}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold text-rose-800"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Akt Dereje *
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              {[1, 2, 3].map((deg) => (
                <button
                  key={deg}
                  type="button"
                  onClick={() => setActDegree(deg as 1 | 2 | 3)}
                  className={`py-2 rounded-lg text-xs font-mono font-black transition border ${
                    actDegree === deg
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm ring-1 ring-slate-900'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {deg}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Kök Neden Kategorisi
            </label>
            <select
              value={rootCauseCategory}
              onChange={(e) => setRootCauseCategory(e.target.value as any)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-semibold"
            >
              <option value="İnsan / Operatör Hatası">İnsan / Operatör Hatası</option>
              <option value="Ekipman / Makine Arızası">Ekipman / Makine Arızası</option>
              <option value="Sıcaklık / Soğuk Zincir İhlali">Sıcaklık / Soğuk Zincir İhlali</option>
              <option value="Ambalaj / Malzeme Kusuru">Ambalaj / Malzeme Kusuru</option>
              <option value="Doğal / Biyolojik Etken">Doğal / Biyolojik Etken</option>
            </select>
          </div>
        </div>

        {/* Section 2: 5-Why & CAPA Root Cause Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              1. Olayın Detaylı Açıklaması (Ne Oldu?) *
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:ring-1 focus:ring-rose-500"
              placeholder="Olayın nasıl ve nerede gerçekleştiğini ayrıntılı yazın..."
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              2. Kök Neden Analizi (5-Why: Neden Oldu?) *
            </label>
            <textarea
              rows={3}
              value={rootCause}
              onChange={(e) => setRootCause(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:ring-1 focus:ring-rose-500"
              placeholder="Operasyonel hata, ekipman arızası, hava şartları veya yöntem eksikliği..."
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              3. Acil Alınan Müdahale / İlk Aksiyon *
            </label>
            <textarea
              rows={3}
              value={immediateAction}
              onChange={(e) => setImmediateAction(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:ring-1 focus:ring-rose-500"
              placeholder="Hemen sahada veya ambarda alınan ilk karantina / ayırma önlemi..."
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              4. Düzeltici & Kalıcı Önleyici Faaliyet (DÖF / CAPA) *
            </label>
            <textarea
              rows={3}
              value={correctiveAction}
              onChange={(e) => setCorrectiveAction(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:ring-1 focus:ring-rose-500"
              placeholder="Bu olayın bir daha tekrarlanmaması için alınacak kalıcı eğitim / bakım / kural önlemi..."
            />
          </div>
        </div>

        {/* Section 3: Responsible & Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sorumlu Kişi / Departman *
            </label>
            <input
              type="text"
              value={responsible}
              onChange={(e) => setResponsible(e.target.value)}
             
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium focus:ring-1 focus:ring-slate-900"
              placeholder="Örn: Lojistik Şefi & Kalite Müdürü"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Olay Statüsü *
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-900 focus:ring-1 focus:ring-slate-900"
            >
              <option value="OPEN">🔴 AÇIK (İnceleme & DÖF Başlatıldı)</option>
              <option value="IN_PROGRESS">🟡 DEVAM EDİYOR (Aksiyon Aşamasında)</option>
              <option value="RESOLVED">🟢 ÇÖZÜLDÜ (Aksiyon Tamamlandı & Kapatıldı)</option>
            </select>
          </div>
        </div>

        {/* Section 4: Fotoğraf, Numune & Olay Kanıt Belgeleri (File Upload / Drag & Drop / Camera) */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-700" />
              <label className="text-xs font-black uppercase tracking-wider text-slate-900">
                Hadysa / Hasar Şaýatlyk Suratlary (Fotoğraf & Delil Dosyaları)
              </label>
            </div>
            <span className="text-[11px] font-bold text-slate-600 bg-white px-2.5 py-0.5 rounded-full border border-slate-200">
              {photos.filter(p => p && p.length > 20).length} Fotoğraf Eklendi
            </span>
          </div>

          {/* Drag & Drop / Upload Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-4 transition text-center flex flex-col sm:flex-row items-center justify-between gap-3 ${
              isDragging
                ? 'border-amber-500 bg-amber-50/70'
                : 'border-slate-300 bg-white hover:border-slate-400'
            }`}
          >
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">
                  Fotoğrafları buraya sürükleyip bırakın veya cihazınızdan seçin
                </p>
                <p className="text-[11px] text-slate-500">
                  PNG, JPG, WebP desteklenir. Mobil cihazlarda doğrudan kamera ile çekilebilir.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-amber-300" />
                <span>Fotoğraf Çek</span>
              </button>

              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Galeriden Seç</span>
              </button>

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />

              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>

          {/* Quick Preset Samples for Testing */}
          <div className="flex items-center gap-2 flex-wrap text-[11px] pt-1">
            <span className="text-slate-500 font-semibold">Hızlı Örnek Hasar Fotoğrafları Ekle:</span>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-amber-600" />
              <span>📦 Palet / Kasa Hasarı</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-amber-600" />
              <span>🍌 Muz Soğuk / Üşüme Sapması</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-amber-600" />
              <span>🍎 Meyve Ezilme / Leke</span>
            </button>
          </div>

          {/* Uploaded Photos Grid */}
          {photos.filter(p => p && p.length > 20).length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
              {photos.filter(p => p && p.length > 20).map((p, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shadow-sm aspect-square"
                >
                  <img
                    src={p}
                    alt={`Incident Evidence ${idx + 1}`}
                    className="w-full h-full object-cover transition duration-200 group-hover:scale-105"
                  />
                  <div className="absolute top-1 left-1 bg-black/60 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    #{idx + 1}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(idx)}
                    title="Fotoğrafı Kaldır"
                    className="absolute top-1 right-1 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-md shadow-md opacity-90 group-hover:opacity-100 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 rounded-lg bg-white border border-slate-200 text-center text-xs text-slate-400">
              Henüz fotoğraf eklenmedi. Yukarıdaki butona basarak veya sürükleyerek fotoğraf yükleyebilirsiniz.
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800 text-white shadow-md active:scale-95'} text-xs font-extrabold transition`}
          >
            <Save className="w-4 h-4 text-amber-300" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'Barlag Akty Tutanağını Kaydet & Sisteme İşle'}</span>
          </button>
        </div>
        </fieldset>

      </form>
    </div>
  );
};

