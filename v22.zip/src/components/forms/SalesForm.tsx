import React, { useState, useEffect, useRef } from 'react';
import {
  ShoppingBag,
  ArrowLeft,
  Save,
  Plus,
  Trash2,
  Camera,
  Image as ImageIcon,
  Upload,
  Layers,
  Calendar,
  Building,
  Receipt,
  Truck,
  CheckCircle2,
  DollarSign,
  PackageCheck,
  TrendingUp,
  Tag,
  Boxes,
  Info
} from 'lucide-react';
import { SalesRecord, SalesVarietyItem, ReferenceItem } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { generateRefId } from '../../utils/calculations';
import { SmartCreatableSelect } from '../common/SmartField';

interface SalesFormProps {
  onSave: (record: SalesRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: SalesRecord;
  isReadOnly?: boolean;
}

export const SalesForm: React.FC<SalesFormProps> = ({
  onSave,
  onCancel,
  existingRefs = [],
  initialRefId,
  initialRecord,
  isReadOnly = false
}) => {
  const [isNewRef, setIsNewRef] = useState<boolean>(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState<string>(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId ?? 'SALE-REF-01'));
  
  // Custom new Ref
  const [customRefId, setCustomRefId] = useState<string>(() => {
    if (initialRecord?.refId) return initialRecord.refId;
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    return `SALE-${today}-${rand}`;
  });

  // Sales Meta
  const [salesDate, setSalesDate] = useState(initialRecord?.salesDate || new Date().toISOString().slice(0, 10));
  const [salesTime, setSalesTime] = useState(() => {
    if (initialRecord?.salesTime) return initialRecord.salesTime;
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  });
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Ticari Satış Uzmanı');
  const [customer, setCustomer] = useState(initialRecord?.customer || '');
  const [salesChannel, setSalesChannel] = useState(initialRecord?.salesChannel || 'İhracat (Eksport)');
  // v2.2: fatura numarası uydurulmaz; gerçek belge numarası girilir
  const [invoiceNo, setInvoiceNo] = useState(initialRecord?.invoiceNo || '');
  const [product, setProduct] = useState(initialRecord?.product || '');
  const [destination, setDestination] = useState(initialRecord?.destination || '');
  const [vehiclePlate, setVehiclePlate] = useState(initialRecord?.vehiclePlate || '');
  const [paymentStatus, setPaymentStatus] = useState<'PAID' | 'PENDING' | 'PARTIAL'>(initialRecord?.paymentStatus || 'PENDING');
  const [overallQualityGrade, setOverallQualityGrade] = useState(initialRecord?.overallQualityGrade || '');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [totalPallets, setTotalPallets] = useState<number>(initialRecord?.totalPallets ?? 0);
  const [notes, setNotes] = useState(initialRecord?.notes || '');

  // Dynamic Variety / Sort Items
  const [items, setItems] = useState<SalesVarietyItem[]>(
    initialRecord?.items && initialRecord.items.length > 0
      ? initialRecord.items
      : [
          // v2.2: yeni satışta örnek değer YOK — operatör gerçek değerleri girer
          { variety: '', qualityGrade: 'Sınıf 1', caliberSize: '', caseCount: 0, weightKg: 0, currency: 'TMT' }
        ]
  );

  // Photo uploads (Cold-Start: no sample photos)
  const [photos, setPhotos] = useState<string[]>(
    initialRecord?.photos && initialRecord.photos.length > 0
      ? initialRecord.photos
      : []
  );
  const [isDragging, setIsDragging] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Sync when selecting existing ref
  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      const found = existingRefs.find(r => r.refId === selectedRefId);
      if (found) {
        setProduct(found.product || '');
        if (found.destination) setDestination(found.destination);
      }
    }
  }, [isNewRef, selectedRefId, existingRefs]);

  // Item modifications
  const handleAddItem = () => {
    setItems(prev => [
      ...prev,
      { variety: '', qualityGrade: 'Sınıf 1', caliberSize: '', caseCount: 0, weightKg: 0, currency: prev[prev.length - 1]?.currency || 'TMT' }
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateItem = (index: number, field: keyof SalesVarietyItem, value: any) => {
    setItems(prev => {
      const next = [...prev];
      const updated = { ...next[index], [field]: value };
      
      // Auto recalculate row total price if weight or unitPrice changes
      if (field === 'weightKg' || field === 'unitPriceTmt') {
        const w = field === 'weightKg' ? Number(value) : updated.weightKg;
        const p = field === 'unitPriceTmt' ? Number(value) : (updated.unitPriceTmt || 0);
        updated.totalPriceTmt = Number((w * p).toFixed(2));
      }
      
      next[index] = updated;
      return next;
    });
  };

  // Totals calculations
  const totalQuantityKg = items.reduce((sum, item) => sum + (Number(item.weightKg) || 0), 0);
  const totalCases = items.reduce((sum, item) => sum + (Number(item.caseCount) || 0), 0);
  const totalAmountTmt = items.reduce((sum, item) => sum + ((item.currency || 'TMT') === 'TMT' ? (Number(item.totalPriceTmt) || 0) : 0), 0);
  // v2.2: farklı para birimleri toplanmaz; her biri ayrı gösterilir
  const totalsByCurrency = items.reduce<Record<string, number>>((acc, item) => {
    const cur = item.currency || 'TMT';
    if (item.unitPriceTmt && item.unitPriceTmt > 0) acc[cur] = (acc[cur] || 0) + (Number(item.totalPriceTmt) || 0);
    return acc;
  }, {});
  const totalsLabel = Object.keys(totalsByCurrency).length
    ? Object.entries(totalsByCurrency).map(([cur, v]) => `${v.toLocaleString()} ${cur}`).join(' + ')
    : 'Fiyat girilmedi';

  // File Upload Handlers
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
      e.target.value = '';
    }
  };

  const processFiles = (files: File[]) => {
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const addPresetPhoto = (url: string) => {
    setPhotos(prev => [...prev, url]);
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let effectiveRefId = isNewRef ? customRefId.trim() : (selectedRefId.trim() || initialRecord?.refId || '');
    if (!effectiveRefId) {
      effectiveRefId = generateRefId('SALES', existingRefs.map(r => r.refId));
    }

    // v2.2: varsayılan "örnek" değerlerle kayıt oluşturulmaz
    const finalProduct = product.trim();
    if (!finalProduct) {
      window.alert('Ürün adını girin.');
      return;
    }
    if (!items.some(it => Number(it.weightKg) > 0)) {
      window.alert('En az bir kalemde net ağırlık (kg) girin.');
      return;
    }
    const missingPrice = items.filter(it => Number(it.weightKg) > 0 && !(Number(it.unitPriceTmt) > 0)).length;
    if (missingPrice > 0 && !window.confirm(`${missingPrice} kalemde fiyat girilmedi; bu kalemler gelir raporuna dahil edilmeyecek. Yine de kaydedilsin mi?`)) {
      return;
    }
    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Belirtilmedi';
    const finalCustomer = customer.trim() || 'Belirtilmedi';
    const finalDestination = destination.trim() || 'Belirtilmedi';

    const record: SalesRecord = {
      id: initialRecord?.id || `sale-${Date.now()}`,
      refId: effectiveRefId,
      salesDate,
      salesTime,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      customer: finalCustomer,
      salesChannel: salesChannel.trim() || 'İç Pazar / İhracat',
      invoiceNo,
      product: finalProduct,
      items: items.map(it => ({ ...it, currency: it.currency || 'TMT' })),
      totalQuantityKg,
      totalCases,
      totalPallets,
      overallQualityGrade: overallQualityGrade.trim() || items[0]?.qualityGrade || 'Belirtilmedi',
      kaliteSinifi,
      vehiclePlate,
      paymentStatus,
      destination: finalDestination,
      notes,
      photos
    };

    onSave(record, isNewRef, isNewRef ? {
      product: finalProduct,
      location: `Satış & Sevkiyat (${salesChannel.trim() || 'Genel'})`,
      destination: `${finalCustomer} - ${finalDestination}`,
      quantity: totalQuantityKg,
      unit: 'kg',
      notes: `Ticari Satış Çıkışı: Fatura ${invoiceNo}, Toplam ${totalQuantityKg} kg, ${totalCases} kasa, ${totalsLabel}.`
    } : undefined);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      
      {/* Header */}
      <div className="bg-slate-900 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shrink-0">
            <ShoppingBag className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-extrabold tracking-wide text-white">
                SATIŞ & SEVKİYAT ÇIKIŞ KÜTÜĞÜ
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-black uppercase bg-amber-400 text-slate-950">
                Ticari Çıkış • Erem™
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 line-clamp-2 sm:line-clamp-none">
              Ne zaman, hangi müşteriye, hangi çeşit ve sortlarda kaç kg ve kasa gittiğinin detaylı kayıt ve karşılaştırma kütüğü
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="self-end sm:self-center shrink-0 flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Hızlı Yardımcı Notlar & Standartlar Kutusu */}
        <div className="bg-purple-50/90 border border-purple-200 rounded-2xl p-4 text-xs text-purple-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-purple-900">
            <Info className="w-4 h-4 text-purple-700 shrink-0" />
            <span>💡 Satış & Ticari Sevkiyat Rehberi (Operasyon Standartları):</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px] text-purple-900/90 leading-relaxed">
            <div className="bg-white/80 p-2 rounded-lg border border-purple-200/60">
              <strong>Çeşit & Sort Dağılımı:</strong> Her palet ve kamyondaki çeşit kırılımı (Ekstra, Sınıf 1, Sınıf 2) ve kasa adetleri eksiksiz girilmelidir.
            </div>
            <div className="bg-white/80 p-2 rounded-lg border border-purple-200/60">
              <strong>Müşteri & Fatura Eşleşmesi:</strong> Fatura/İrsaliye no ve alıcı firma ismi resmi taşıma evraklarıyla (Delilnama) birebir örtüşmelidir.
            </div>
            <div className="bg-white/80 p-2 rounded-lg border border-purple-200/60">
              <strong>Kasa & Palet Kilogramı:</strong> Kasa darası düşüldükten sonra net kg tutarı ile kantar fişi karşılaştırılmalıdır.
            </div>
          </div>
        </div>

        {/* Reference Selector */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
            <label className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-amber-600" />
              <span>İzlenebilirlik Referansı (RefID)</span>
            </label>
            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => setIsNewRef(false)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  !isNewRef
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                Mevcut Ref'e Bağla (Depo / Hasat Partisi)
              </button>
              <button
                type="button"
                onClick={() => setIsNewRef(true)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  isNewRef
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                + Yeni Satış Ref Aç
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {isNewRef ? (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Yeni Satış RefID (Yazılabilir veya Otomatik)</label>
                <input
                  type="text"
                  value={customRefId}
                  onChange={(e) => setCustomRefId(e.target.value)}
                  placeholder="örn: SALE-20260907-001"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-amber-700"
                />
              </div>
            ) : (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Referans Seç veya Serbestçe Yaz (RefID)</label>
                <input
                  type="text"
                  list="sales-existing-refs-list"
                  value={selectedRefId}
                  onChange={(e) => setSelectedRefId(e.target.value)}
                  placeholder="Listeden seçin veya RefID yazın..."
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:ring-1 focus:ring-amber-500"
                />
                <datalist id="sales-existing-refs-list">
                  {existingRefs.map((r) => (
                    <option key={r.refId} value={r.refId}>
                      {r.product} ({r.quantity} {r.unit}) [{r.status}]
                    </option>
                  ))}
                </datalist>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Sevkiyat & Satış Sorumlusu</label>
              <input
                type="text"
                list="operators-list"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>
          </div>
        </div>

        {/* Section 1: Satış, Müşteri & Fatura Bilgileri */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <Building className="w-4 h-4 text-amber-600" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
              1. Satış Tarihi, Müşteri & İrsaliye Bilgileri
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Satış / Çıkış Tarihi *</label>
              <input
                type="date"
                value={salesDate}
                onChange={(e) => setSalesDate(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Çıkış Saati</label>
              <input
                type="time"
                value={salesTime}
                onChange={(e) => setSalesTime(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <SmartCreatableSelect
                label="Alıcı Müşteri / Firma"
                categoryKey="customers"
                options={AUTOCOMPLETE_LISTS.customers}
                value={customer}
                onChange={setCustomer}
               
              />
            </div>

            <div>
              <SmartCreatableSelect
                label="Satış Kanalı"
                categoryKey="salesChannels"
                options={AUTOCOMPLETE_LISTS.salesChannels}
                value={salesChannel}
                onChange={setSalesChannel}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Fatura / İrsaliye No *</label>
              <input
                type="text"
                value={invoiceNo}
                onChange={(e) => setInvoiceNo(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold text-slate-900"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Teslimat Noktası / Şehir</label>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                placeholder="Örn: Moskwa Food City Lojistik Merkezi"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Ana Ürün Başlığı</label>
              <input
                type="text"
                list="products-list"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>
          </div>
        </div>

        {/* Section 2: Çeşit / Sort, Kalibre, Görünüş & Miktar Kırılım Tablosu */}
        <div className="p-4 bg-amber-50/40 rounded-xl border border-amber-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200 pb-2">
            <div className="flex items-center gap-2">
              <Boxes className="w-4 h-4 text-amber-700" />
              <h3 className="text-xs font-black uppercase tracking-wider text-amber-950">
                2. Çeşit / Sort, Meyve Görünüş (Kalite Sınıfı) & Miktar Kırılımı
              </h3>
            </div>
            
            <button
              type="button"
              onClick={handleAddItem}
              className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Yeni Çeşit / Sort Ekle</span>
            </button>
          </div>

          {/* Desktop Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-amber-100 text-amber-950 font-extrabold uppercase text-[10px]">
                  <th className="py-2.5 px-3 rounded-l-lg">Çeşit / Sort</th>
                  <th className="py-2.5 px-3">Görünüş / Kalite Sınıfı</th>
                  <th className="py-2.5 px-3">Kalibre / Boy</th>
                  <th className="py-2.5 px-3">Koli/Kasa</th>
                  <th className="py-2.5 px-3">Net Kg</th>
                  <th className="py-2.5 px-3">Birim Fiyat (TMT)</th>
                  <th className="py-2.5 px-3">Toplam Tutar</th>
                  <th className="py-2.5 px-3 rounded-r-lg text-center">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-200/70 font-medium">
                {items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-white/80">
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={item.variety}
                        onChange={(e) => handleUpdateItem(idx, 'variety', e.target.value)}
                        placeholder="Örn: Extreme 314"
                        className="w-32 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold text-slate-900 min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <select
                        value={item.qualityGrade}
                        onChange={(e) => handleUpdateItem(idx, 'qualityGrade', e.target.value as any)}
                        className="bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold min-h-[40px]"
                      >
                        <option value="Ekstra">✨ EXTRA (V-20): Ekstra Kalite</option>
                        <option value="Sınıf 1">🟢 I (V-22) EXC: 1. Sınıf Mükemmel</option>
                        <option value="Sınıf 2">🟡 II (V-24) PRM: 2. Sınıf Premium</option>
                        <option value="Sınıf 3">🟠 III (V26-28) CLS: 3. Sınıf Klasik</option>
                        <option value="Mix">🔀 Mix: Karışık / Sanayi Sınıfı</option>
                        <option value="Sanayi / Iskarta">⚙️ Standart Dışı: Freeze-Dry / Sanayi</option>
                      </select>
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={item.caliberSize || ''}
                        onChange={(e) => handleUpdateItem(idx, 'caliberSize', e.target.value)}
                        placeholder="Örn: 70-75mm"
                        className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-xs min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="1"
                        value={item.caseCount}
                        onChange={(e) => handleUpdateItem(idx, 'caseCount', Number(e.target.value))}
                        className="w-20 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold text-center min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="1"
                        value={item.weightKg}
                        onChange={(e) => handleUpdateItem(idx, 'weightKg', Number(e.target.value))}
                        className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-black text-amber-900 min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          placeholder="—"
                          value={item.unitPriceTmt ?? ''}
                          onChange={(e) => handleUpdateItem(idx, 'unitPriceTmt', e.target.value === '' ? undefined : Number(e.target.value))}
                          className="w-20 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-medium min-h-[40px]"
                        />
                        <select
                          value={item.currency || 'TMT'}
                          onChange={(e) => handleUpdateItem(idx, 'currency', e.target.value)}
                          className="bg-white border border-slate-300 rounded px-1 py-1 text-xs font-bold min-h-[40px]"
                          aria-label="Para birimi"
                        >
                          <option value="TMT">TMT</option>
                          <option value="USD">USD</option>
                        </select>
                      </div>
                    </td>
                    <td className="py-2 px-3 font-mono font-bold text-slate-900">
                      {item.unitPriceTmt ? `${(item.totalPriceTmt || 0).toLocaleString()} ${item.currency || 'TMT'}` : '—'}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="text-rose-600 hover:text-rose-800 p-2 rounded-lg hover:bg-rose-50 transition min-h-[40px] min-w-[40px] flex items-center justify-center mx-auto"
                        title="Satırı Kaldır"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View (sm:hidden) */}
          <div className="block sm:hidden space-y-3">
            {items.map((item, idx) => (
              <div key={idx} className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-amber-100 pb-2">
                  <span className="font-bold text-xs text-amber-900">Çeşit / Sort Kalemi #{idx + 1}</span>
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-rose-600 hover:text-rose-800 text-xs font-bold flex items-center gap-1 bg-rose-50 px-2 py-1 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Sil</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div className="col-span-2">
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Çeşit / Sort Adı</label>
                    <input
                      type="text"
                      value={item.variety}
                      onChange={(e) => handleUpdateItem(idx, 'variety', e.target.value)}
                      placeholder="Örn: Extreme 314"
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 min-h-[44px]"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Görünüş / Kalite Sınıfı</label>
                    <select
                      value={item.qualityGrade}
                      onChange={(e) => handleUpdateItem(idx, 'qualityGrade', e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 min-h-[44px]"
                    >
                      <option value="Ekstra">✨ EXTRA (V-20): Ekstra Kalite</option>
                      <option value="Sınıf 1">🟢 I (V-22) EXC: 1. Sınıf Mükemmel</option>
                      <option value="Sınıf 2">🟡 II (V-24) PRM: 2. Sınıf Premium</option>
                      <option value="Sınıf 3">🟠 III (V26-28) CLS: 3. Sınıf Klasik</option>
                      <option value="Mix">🔀 Mix: Karışık / Sanayi</option>
                      <option value="Sanayi / Iskarta">⚙️ Standart Dışı: Freeze-Dry / Sanayi</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Kalibre / Boy</label>
                    <input
                      type="text"
                      value={item.caliberSize || ''}
                      onChange={(e) => handleUpdateItem(idx, 'caliberSize', e.target.value)}
                      placeholder="Örn: 70-75mm"
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Kasa Adedi</label>
                    <input
                      type="number"
                      value={item.caseCount}
                      onChange={(e) => handleUpdateItem(idx, 'caseCount', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-center min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Net Kg</label>
                    <input
                      type="number"
                      value={item.weightKg}
                      onChange={(e) => handleUpdateItem(idx, 'weightKg', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-black text-amber-900 min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Birim fiyat (kg başına)</label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        step="0.1"
                        placeholder="—"
                        value={item.unitPriceTmt ?? ''}
                        onChange={(e) => handleUpdateItem(idx, 'unitPriceTmt', e.target.value === '' ? undefined : Number(e.target.value))}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-teal-800 min-h-[44px]"
                      />
                      <select
                        value={item.currency || 'TMT'}
                        onChange={(e) => handleUpdateItem(idx, 'currency', e.target.value)}
                        className="bg-slate-50 border border-slate-300 rounded-lg px-2 py-2 text-xs font-bold min-h-[44px]"
                        aria-label="Para birimi"
                      >
                        <option value="TMT">TMT</option>
                        <option value="USD">USD</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Tutar:</span>
                  <span className="text-sm font-black text-slate-900 font-mono">
                    {item.unitPriceTmt ? `${(item.totalPriceTmt || 0).toLocaleString()} ${item.currency || 'TMT'}` : 'Fiyat girilmedi'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Totals Summary Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
            <div className="bg-white p-3 rounded-xl border border-amber-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Toplam Çıkış Miktarı:</span>
              <span className="text-sm font-black text-slate-900">{(totalQuantityKg ?? 0).toLocaleString()} kg</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-amber-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Toplam Kasa / Koli:</span>
              <span className="text-sm font-black text-amber-700">{(totalCases ?? 0).toLocaleString()} Kasa</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-amber-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Toplam Palet:</span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  value={totalPallets}
                  onChange={(e) => setTotalPallets(Number(e.target.value))}
                  className="w-16 bg-slate-50 border border-slate-300 rounded px-2 py-0.5 text-xs font-bold text-center"
                />
                <span className="text-xs font-bold text-slate-500">Plt</span>
              </div>
            </div>
            <div className="bg-white p-3 rounded-xl border border-amber-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Toplam Satış Tutarı:</span>
              <span className="text-sm font-black text-teal-700">{totalsLabel}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Araç, Ödeme & Genel Notlar */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <Truck className="w-4 h-4 text-amber-600" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
              3. Taşıyıcı Araç, Ödeme Durumu & Sevkiyat Notu
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Taşıyıcı Araç Plakası</label>
              <input
                type="text"
                value={vehiclePlate}
                onChange={(e) => setVehiclePlate(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-medium"
                placeholder="Örn: 74-92 AGH (Frigo Tır)"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Genel Kalite & Görünüş Özeti</label>
              <input
                type="text"
                value={overallQualityGrade}
                onChange={(e) => setOverallQualityGrade(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                placeholder="Örn: Ekstra & Sınıf 1 (Erem Export Standart)"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Ödeme Durumu</label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as any)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold"
              >
                <option value="PAID">🟢 Ödendi (Peşin / Havale Tamam)</option>
                <option value="PARTIAL">🟡 Kısmi Ödeme (Avans Alındı)</option>
                <option value="PENDING">⚪ Açık Hesap / Beklemede</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Sevkiyat & Sözleşme Notları</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg p-3 font-medium"
              placeholder="Ambalaj tipi, paletleme durumu, özel talepler..."
            />
          </div>
        </div>

        {/* Section 4: Fotoğraf & İrsaliye Belgeleri */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-700" />
              <label className="text-xs font-black uppercase tracking-wider text-slate-900">
                Sevkiyat, Yükleme & İrsaliye Fotoğrafları
              </label>
            </div>
            <span className="text-[11px] font-bold text-slate-600 bg-white px-2.5 py-0.5 rounded-full border border-slate-200">
              {photos.filter(p => p && p.length > 20).length} Fotoğraf
            </span>
          </div>

          {/* Drag & Drop / Upload Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-4 transition text-center flex flex-col sm:flex-row items-center justify-between gap-3 ${
              isDragging
                ? 'border-amber-500 bg-amber-50/70'
                : 'border-slate-300 bg-white hover:border-slate-400'
            }`}
          >
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">
                  Fotoğrafları buraya sürükleyin veya cihazdan seçin
                </p>
                <p className="text-[11px] text-slate-500">
                  Araç yükleme düzeni, kasa barkodları veya ıslak imzalı irsaliye görseli ekleyin.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-amber-300" />
                <span>Fotoğraf Çek</span>
              </button>

              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Galeriden Seç</span>
              </button>

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />

              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-2 flex-wrap text-[11px] pt-1">
            <span className="text-slate-500 font-semibold">Hızlı Fotoğraf Ekle:</span>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-amber-600" />
              <span>🚚 Tır Paletli Yükleme Düzeni</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-amber-600" />
              <span>📦 Erem™ Ambalajlı Kasa Barkodu</span>
            </button>
          </div>

          {/* Uploaded Grid */}
          {photos.filter(p => p && p.length > 20).length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
              {photos.filter(p => p && p.length > 20).map((p, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shadow-sm aspect-square"
                >
                  <img
                    src={p}
                    alt={`Sales Evidence ${idx + 1}`}
                    className="w-full h-full object-cover transition duration-200 group-hover:scale-105"
                  />
                  <div className="absolute top-1 left-1 bg-black/60 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    #{idx + 1}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(idx)}
                    title="Kaldır"
                    className="absolute top-1 right-1 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-md shadow-md opacity-90 group-hover:opacity-100 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons (Top & Bottom Geri Dön options for maximum ergonomic comfort) */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-slate-200 flex-wrap">
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center justify-center gap-1.5 px-5 py-3 min-h-[44px] rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 active:scale-95 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-slate-500" />
            <span>← Geri Dön / İptal</span>
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800 active:scale-95 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition cursor-pointer`}
          >
            <Save className="w-4 h-4 text-amber-300" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'SATIŞ & SEVKİYAT ÇIKIŞINI KAYDET'}</span>
          </button>
        </div>
        </fieldset>

      </form>
    </div>
  );
};
