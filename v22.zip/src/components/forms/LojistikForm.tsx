import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Truck,
  ArrowLeft,
  Save,
  Thermometer,
  FileText,
  CheckCircle2,
  AlertCircle,
  Info,
  Split,
  Plus,
  Trash2,
  Sparkles,
  Printer,
  Scale,
  ShieldCheck,
  ChevronRight,
  Layers,
  Snowflake,
  ExternalLink,
  Edit,
  X,
  Camera,
  Image as ImageIcon,
  Eye,
  UploadCloud,
  BookOpen
} from 'lucide-react';
import {
  LojistikRecord,
  ReferenceItem,
  SplitLotItem,
  DelilnamaPassport,
  DelilnamaGradeRow,
  BademDepderceItem,
  BademDelilnamaPassport,
  StandardQualityClassKey,
  STANDARD_QUALITY_CLASSES
} from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { generateRefId } from '../../utils/calculations';
import { QualityGradeSelect } from '../common/QualityGradeSelect';
import { SmartCreatableSelect } from '../common/SmartField';
import { compressImage, cachePhoto } from '../../utils/photoStorage';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';

interface LojistikFormProps {
  onSave: (record: LojistikRecord, refId: string) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: LojistikRecord;
  onOpenGallery?: () => void;
  isReadOnly?: boolean;
}

export const LojistikForm: React.FC<LojistikFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  onOpenGallery,
  isReadOnly = false
}) => {
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId || ''));
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Lojistik Sevkiyat Uzmanı');

  // Selected reference context
  const selectedRef = existingRefs.find(r => r.refId === selectedRefId);

  // 1. Dinamik Meyve Seçimi (Muz vs Diğer Meyveler vs Badem)
  const initialIsBanana = (initialRecord?.fruitCategory === 'MUZ') || selectedRef?.product?.toLowerCase().includes('muz') || false;
  const initialIsBadem = (initialRecord?.fruitCategory === 'BADEM') || selectedRef?.product?.toLowerCase().includes('badem') || false;
  const [fruitCategory, setFruitCategory] = useState<'MUZ' | 'DIGER' | 'BADEM'>(
    initialRecord?.fruitCategory || (initialIsBadem ? 'BADEM' : (initialIsBanana ? 'MUZ' : 'DIGER'))
  );
  const [customFruit, setCustomFruit] = useState<string>(
    initialRecord?.product || selectedRef?.product || (initialIsBadem ? 'Badem' : (initialIsBanana ? 'Muz' : 'Şeftali'))
  );
  const [customVariety, setCustomVariety] = useState<string>(initialRecord?.variety || 'Extreme 314');

  // Form Fields
  const [shipmentDate, setShipmentDate] = useState(initialRecord?.shipmentDate || new Date().toISOString().split('T')[0]);
  const [source, setSource] = useState(initialRecord?.source || selectedRef?.source || 'Merkez Soğuk Hava Deposu');
  const [destination, setDestination] = useState(initialRecord?.destination || selectedRef?.destination || 'Aşgabat / İhracat');
  const [vehiclePlate, setVehiclePlate] = useState(initialRecord?.vehiclePlate || 'AG 7721 AH');
  const [driver, setDriver] = useState(initialRecord?.driver || 'Merdan Orazow');
  const [driverPhone, setDriverPhone] = useState(initialRecord?.driverPhone || '+993 65 442190');
  const [delilnamaNo, setDelilnamaNo] = useState(initialRecord?.delilnamaNo || '');
  const [transportType, setTransportType] = useState(initialRecord?.transportType || 'Frigorifik Tır (Reefer)');
  const [palletCount, setPalletCount] = useState<number>(initialRecord?.palletCount ?? 0);
  const [caseCount, setCaseCount] = useState<number>(initialRecord?.caseCount ?? 0);
  const [weightKg, setWeightKg] = useState<number>(initialRecord?.weightKg ?? (selectedRef?.quantity || 4500));
  const [departureTemperature, setDepartureTemperature] = useState<number>(
    initialRecord?.departureTemperature ?? (initialIsBadem ? 16.0 : (fruitCategory === 'MUZ' ? 13.5 : 3.8))
  );
  const [transitTemperature, setTransitTemperature] = useState<number>(
    initialRecord?.transitTemperature ?? (initialIsBadem ? 15.5 : (fruitCategory === 'MUZ' ? 13.0 : 3.5))
  );
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [status, setStatus] = useState<'SHIPPED' | 'IN_TRANSIT' | 'DELIVERED'>(initialRecord?.status || 'SHIPPED');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);

  // Saha & Lojistik Kanıt Fotoğrafları (Field & Shipment Verification Photos)
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Look up field & harvest photos related to selectedRefId
  const relatedBatchPhotos = useMemo(() => {
    const found: Array<{ url: string; label: string; date?: string }> = [];
    try {
      if (selectedRefId) {
        // 1. check harvest records
        const hrStr = localStorage.getItem('miwe_harvest_records');
        if (hrStr) {
          const list = JSON.parse(hrStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🌿 Hasat Fotoğrafı #${idx + 1} (${x.orchard || ''})`, date: x.date });
            });
          });
        }
        // 2. check field records
        const frStr = localStorage.getItem('miwe_field_records');
        if (frStr) {
          const list = JSON.parse(frStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🍎 Meyve Kalite Testi #${idx + 1}`, date: x.testDate });
            });
          });
        }
        // 3. check muz records
        const mrStr = localStorage.getItem('miwe_muz_records');
        if (mrStr) {
          const list = JSON.parse(mrStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🍌 Muz Kalite Kontrol #${idx + 1}`, date: x.date });
            });
          });
        }
        // 4. check badem records
        const brStr = localStorage.getItem('miwe_badem_records');
        if (brStr) {
          const list = JSON.parse(brStr);
          list.filter((x: any) => x.refId === selectedRefId).forEach((x: any) => {
            (x.photos || []).forEach((p: string, idx: number) => {
              if (p && p.length > 20) found.push({ url: p, label: `🥜 Badem Randıman Testi #${idx + 1}`, date: x.date });
            });
          });
        }
      }
    } catch (e) {
      console.warn('Could not load related photos', e);
    }
    return found;
  }, [selectedRefId]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsCompressingPhoto(true);
    try {
      const files = Array.from(e.target.files) as File[];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        try {
          const compressedBase64 = await compressImage(file, 1600, 1600, 0.8);
          const photoKey = `photo_lojistik_${Date.now()}_${i}`;
          await cachePhoto(photoKey, compressedBase64);
          setPhotos(prev => [...prev, compressedBase64]);
        } catch (err) {
          const reader = new FileReader();
          reader.onload = (re) => {
            if (re.target?.result) {
              setPhotos(prev => [...prev, re.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        }
      }
    } finally {
      setIsCompressingPhoto(false);
      if (cameraInputRef.current) cameraInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // 2. Parçalı Yük & Kalite Sortları Dağıtımı (Split Lots)
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>([]);

  // 3. Delilnama / Standart Meyve Kalite Pasaportu
  const [enableDelilnama, setEnableDelilnama] = useState(true);
  const [delilnamaPassport, setDelilnamaPassport] = useState<DelilnamaPassport>({
    delilnamaNo: delilnamaNo,
    sene: shipmentDate,
    yeri: source,
    miwe: fruitCategory === 'MUZ' ? 'Muz' : customFruit,
    miweGornusi: customVariety,
    agacSany: 120,
    gabynGornusi: 'Ýaşşik (Plastik Agro Kasa)',
    grades: [
      { gradeKey: 'EXTRA (V-20)', gradeLabelTr: 'Ekstra Kalite', yassikliKg: 1850, hasylNetKg: 1820, satysaBerlenKg: 1820, gapSany: 91 },
      { gradeKey: 'I (V-22) EXC', gradeLabelTr: '1. Sınıf Seçkin', yassikliKg: 1600, hasylNetKg: 1560, satysaBerlenKg: 1560, gapSany: 78 },
      { gradeKey: 'II (V-24) PRM', gradeLabelTr: '2. Sınıf Standart', yassikliKg: 1080, hasylNetKg: 1040, satysaBerlenKg: 1040, gapSany: 52 },
      { gradeKey: 'III (V26-28) CLS', gradeLabelTr: '3. Sınıf Klasik', yassikliKg: 420, hasylNetKg: 416, satysaBerlenKg: 416, gapSany: 21 },
      { gradeKey: 'Mix', gradeLabelTr: 'Gatyşyk / Mix', yassikliKg: 215, hasylNetKg: 208, satysaBerlenKg: 208, gapSany: 10 },
      { gradeKey: 'Standart Däl / Standart Dışı', gradeLabelTr: 'Standart Däl / Sanayi', yassikliKg: 160, hasylNetKg: 156, satysaBerlenKg: 156, gapSany: 8 }
    ],
    jemiNetKg: 5200,
    jemiSatysaKg: 5200,
    jemiGapSany: 260,
    onduriji: 'Orazow R. (Çavuş / Brigadir)',
    hilciHunarmen: 'Saparow M. (Baş Hilçi Hünärmen)',
    satuwHunarmen: 'Mämmetgulyýew M. (Satuw Hünärmen)'
  });

  // 4. RESMİ BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI ("MIWE" AGPJ) - № 0000417 Standardı
  const [bademPassport, setBademPassport] = useState<BademDelilnamaPassport>({
    depderceNo: '№ 0000417',
    sene: shipmentDate,
    ulagBelgisi: vehiclePlate,
    bellik: 'Big Bag gaplanan täze hasyl arassalanan Laurenne maňzy',
    cykysEden: 'Badam zawod (Amanow B.)',
    girisEden: 'Sowuk depo (Myradow G.)',
    tassyklan: 'Hil hünärmen (Kadyrow D.)',
    premiumItems: [
      {
        id: 'bp-1',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '21/22 Premium',
        arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 1162.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      },
      {
        id: 'bp-2',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '25-27 Premium',
        arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 524.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      },
      {
        id: 'bp-3',
        cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
        girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
        badamSorty: 'Laurenne',
        meydany: '29-31 Premium',
        arassalananGornusi: 'Garyşyk maňyz / Şänik/Maňyz',
        agramyKg: 182.5,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'PREMIUM_MANYZ'
      }
    ],
    sortlamaItems: [
      {
        id: 'bs-1',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '33-35 Classic',
        sortlamaGaplama: 'I sort',
        agramyKg: 56.0,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-2',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '38-40 Mix',
        sortlamaGaplama: 'II sort',
        agramyKg: 28.0,
        haltaSany: 'Big Bag 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-3',
        cykysYeri: 'MZ / Sowuk depo / Söwda',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: 'Döwük Mix',
        sortlamaGaplama: 'III sort',
        agramyKg: 50.0,
        haltaSany: 'Halta 1 sany',
        tableType: 'SORTLAMA_GAPLAMA'
      },
      {
        id: 'bs-4',
        cykysYeri: 'MZ / Söwda / Sowuk depo',
        girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
        badamSorty: 'Laurenne',
        meydany: '—',
        sortlamaGaplama: 'Pak we heňli',
        agramyKg: 0,
        haltaSany: '—',
        tableType: 'SORTLAMA_GAPLAMA'
      }
    ],
    jemiAgramKg: 2003.5,
    jemiHaltaSany: 6
  });

  const [showPrintModal, setShowPrintModal] = useState(false);
  const [newGradeKey, setNewGradeKey] = useState<string>('EXTRA (V-20)');

  // Badem Passport Sums (NaN-free)
  const bademSums = useMemo(() => {
    const totalPremium = bademPassport.premiumItems.reduce((acc, curr) => acc + (Number(curr.agramyKg) || 0), 0);
    const totalSortlama = bademPassport.sortlamaItems.reduce((acc, curr) => acc + (Number(curr.agramyKg) || 0), 0);
    const totalKg = totalPremium + totalSortlama;
    return {
      totalPremium: Number(totalPremium.toFixed(2)),
      totalSortlama: Number(totalSortlama.toFixed(2)),
      totalKg: Number(totalKg.toFixed(2)),
      totalRows: bademPassport.premiumItems.length + bademPassport.sortlamaItems.length
    };
  }, [bademPassport]);

  // Keep badem totals synchronized
  useEffect(() => {
    setBademPassport(prev => {
      if (
        prev.jemiAgramKg === bademSums.totalKg &&
        prev.sene === shipmentDate &&
        prev.ulagBelgisi === vehiclePlate
      ) {
        return prev;
      }
      return {
        ...prev,
        jemiAgramKg: bademSums.totalKg,
        sene: shipmentDate,
        ulagBelgisi: vehiclePlate
      };
    });
    if (fruitCategory === 'BADEM' && bademSums.totalKg > 0) {
      setWeightKg(prev => prev === bademSums.totalKg ? prev : bademSums.totalKg);
    }
  }, [bademSums.totalKg, shipmentDate, vehiclePlate, fruitCategory]);

  // Safe tonage calculation
  const safeTotalKg = useMemo(() => {
    return Number.isFinite(weightKg) && weightKg > 0 ? Number(weightKg) : 0;
  }, [weightKg]);

  // Split lots allocated sum (NaN-free)
  const allocatedSplitKg = useMemo(() => {
    return splitLots.reduce((sum, item) => {
      const q = Number(item.quantityKg);
      return sum + (Number.isFinite(q) ? q : 0);
    }, 0);
  }, [splitLots]);

  const rawDiff = safeTotalKg - allocatedSplitKg;
  const remainingSplitKg = isNaN(rawDiff) ? 0 : Math.max(0, Number(rawDiff.toFixed(3)));
  const isOverAllocated = safeTotalKg > 0 && allocatedSplitKg > safeTotalKg + 0.001;

  // Delilnama sums (NaN-free)
  const delilnamaSums = useMemo(() => {
    let totalYassikli = 0;
    let totalNet = 0;
    let totalSatysa = 0;
    let totalGap = 0;

    delilnamaPassport.grades.forEach(g => {
      totalYassikli += Number.isFinite(Number(g.yassikliKg)) ? Number(g.yassikliKg) : 0;
      totalNet += Number.isFinite(Number(g.hasylNetKg)) ? Number(g.hasylNetKg) : 0;
      totalSatysa += Number.isFinite(Number(g.satysaBerlenKg)) ? Number(g.satysaBerlenKg) : 0;
      totalGap += Number.isFinite(Number(g.gapSany)) ? Number(g.gapSany) : 0;
    });

    return {
      totalYassikli: Number(totalYassikli.toFixed(3)),
      totalNet: Number(totalNet.toFixed(3)),
      totalSatysa: Number(totalSatysa.toFixed(3)),
      totalGap: Math.round(totalGap)
    };
  }, [delilnamaPassport.grades]);

  // Keep delilnama totals synchronized
  useEffect(() => {
    setDelilnamaPassport(prev => {
      // Avoid state updates if values are already synchronized to prevent loop
      if (
        prev.jemiNetKg === delilnamaSums.totalNet &&
        prev.jemiSatysaKg === delilnamaSums.totalSatysa &&
        prev.jemiGapSany === delilnamaSums.totalGap
      ) {
        return prev;
      }
      return {
        ...prev,
        jemiNetKg: delilnamaSums.totalNet,
        jemiSatysaKg: delilnamaSums.totalSatysa,
        jemiGapSany: delilnamaSums.totalGap
      };
    });
  }, [delilnamaSums.totalNet, delilnamaSums.totalSatysa, delilnamaSums.totalGap]);

  // Keep delilnama header fields synchronized with form state
  useEffect(() => {
    setDelilnamaPassport(prev => {
      const targetMiwe = fruitCategory === 'MUZ' ? 'Muz' : customFruit;
      if (
        prev.delilnamaNo === delilnamaNo &&
        prev.sene === shipmentDate &&
        prev.yeri === source &&
        prev.miwe === targetMiwe &&
        prev.miweGornusi === customVariety
      ) {
        return prev;
      }
      return {
        ...prev,
        delilnamaNo,
        sene: shipmentDate,
        yeri: source,
        miwe: targetMiwe,
        miweGornusi: customVariety
      };
    });
  }, [delilnamaNo, shipmentDate, source, fruitCategory, customFruit, customVariety]);

  // Update fields when selected Ref changes
  useEffect(() => {
    if (selectedRef) {
      if (selectedRef.source) setSource(selectedRef.source);
      if (selectedRef.destination) setDestination(selectedRef.destination);
      if (selectedRef.quantity) setWeightKg(selectedRef.quantity);
      if (selectedRef.product) {
        if (selectedRef.product.toLowerCase().includes('muz')) {
          setFruitCategory('MUZ');
          setCustomFruit('Muz');
          setCustomVariety('Cavendish (Extra Erem™)');
          setDepartureTemperature(13.5);
          setTransitTemperature(13.0);
        } else if (selectedRef.product.toLowerCase().includes('badem')) {
          setFruitCategory('BADEM');
          setCustomFruit('Badem');
          setCustomVariety('Laurenne');
          setDepartureTemperature(16.0);
          setTransitTemperature(15.5);
          setSource('Miweli Atyz Badam Zawody (Kaka)');
          setDestination('Datly Miwe Sowuk Depo / Sortlama');
        } else {
          setFruitCategory('DIGER');
          setCustomFruit(selectedRef.product);
          setDepartureTemperature(3.8);
          setTransitTemperature(3.5);
        }
      }
    }
  }, [selectedRefId]);

  // Fruit category toggle handler
  const handleFruitCategoryChange = (category: 'MUZ' | 'DIGER' | 'BADEM') => {
    setFruitCategory(category);
    if (category === 'MUZ') {
      setCustomFruit('Muz');
      setCustomVariety('Cavendish (Extra Erem™)');
      setSource('Hemsaýa Sera 12 (Sektör C)');
      setDestination('Hemsaýa Muz Gazlama & Olgunlaşdyryş');
      setDepartureTemperature(13.5);
      setTransitTemperature(13.0);
    } else if (category === 'BADEM') {
      setCustomFruit('Badem');
      setCustomVariety('Laurenne');
      setSource('Miweli Atyz Badam Zawody (Kaka)');
      setDestination('Datly Miwe Sowuk Depo / Sortlama');
      setDepartureTemperature(16.0);
      setTransitTemperature(15.5);
    } else {
      setCustomFruit('Şeftali');
      setCustomVariety('Extreme 314');
      setSource('Gök Bulut Bahçesi (Blok A-4)');
      setDestination('Datly Miwe Merkez Sowuk Depo');
      setDepartureTemperature(3.8);
      setTransitTemperature(3.5);
    }
  };

  // Badem Table 1: Premium / Arassalanan Maňyz Row Handlers
  const handleUpdateBademPremiumRow = (index: number, field: keyof BademDepderceItem, value: any) => {
    setBademPassport(prev => {
      const updated = [...prev.premiumItems];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, premiumItems: updated };
    });
  };

  const handleAddBademPremiumRow = () => {
    setBademPassport(prev => ({
      ...prev,
      premiumItems: [
        ...prev.premiumItems,
        {
          id: `bp-${Date.now()}`,
          cykysYeri: 'MZ / Sowuk depo / Söwda (Badam Zawod)',
          girisYeri: 'MZ / Sowuk depo / Söwda (Sowuk Depo)',
          badamSorty: customVariety || '',
          meydany: '25-27 Premium',
          arassalananGornusi: 'Elde/Tenias H.enjam/Garyşyk maňyz',
          agramyKg: 500,
          haltaSany: 'Big Bag 1 sany',
          tableType: 'PREMIUM_MANYZ'
        }
      ]
    }));
  };

  const handleDeleteBademPremiumRow = (index: number) => {
    if (bademPassport.premiumItems.length <= 1) {
      alert('Iň az 1 sany Esasy Maňyz satary bolmalydyr.');
      return;
    }
    setBademPassport(prev => ({
      ...prev,
      premiumItems: prev.premiumItems.filter((_, i) => i !== index)
    }));
  };

  // Badem Table 2: Sortlama & Gaplama Row Handlers
  const handleUpdateBademSortlamaRow = (index: number, field: keyof BademDepderceItem, value: any) => {
    setBademPassport(prev => {
      const updated = [...prev.sortlamaItems];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, sortlamaItems: updated };
    });
  };

  const handleAddBademSortlamaRow = () => {
    setBademPassport(prev => ({
      ...prev,
      sortlamaItems: [
        ...prev.sortlamaItems,
        {
          id: `bs-${Date.now()}`,
          cykysYeri: 'MZ / Sowuk depo / Söwda',
          girisYeri: 'MZ / Sowuk depo / Söwda / Sortlamak Gaplama',
          badamSorty: customVariety || '',
          meydany: '38-40 Mix',
          sortlamaGaplama: 'II sort',
          agramyKg: 50,
          haltaSany: 'Halta 1 sany',
          tableType: 'SORTLAMA_GAPLAMA'
        }
      ]
    }));
  };

  const handleDeleteBademSortlamaRow = (index: number) => {
    if (bademPassport.sortlamaItems.length <= 1) {
      alert('Iň az 1 sany Sortlama satary bolmalydyr.');
      return;
    }
    setBademPassport(prev => ({
      ...prev,
      sortlamaItems: prev.sortlamaItems.filter((_, i) => i !== index)
    }));
  };

  // Convert Badem Depderce rows into Split Lots
  const handleTransferBademToSplitLots = () => {
    const newLots: SplitLotItem[] = [];
    let charCode = 65; // A

    bademPassport.premiumItems.forEach(item => {
      if (item.agramyKg > 0) {
        newLots.push({
          id: `split-badem-${item.id}`,
          subLotId: `split-badem-${item.id}`,
          subLotCode: `${selectedRefId || ''}-${String.fromCharCode(charCode++)}`,
          kaliteSinifi: `Premium (${item.meydany})`,
          quantityKg: Number(item.agramyKg),
          packageType: item.haltaSany,
          packageCount: 1,
          destination: item.girisYeri || destination,
          targetMarket: 'Eksport & İç Piyasa (Premium Maňyz)',
          temperatureRequirement: 16.0,
          notes: `${item.arassalananGornusi || ''} - ${item.badamSorty}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    bademPassport.sortlamaItems.forEach(item => {
      if (item.agramyKg > 0) {
        newLots.push({
          id: `split-badem-${item.id}`,
          subLotId: `split-badem-${item.id}`,
          subLotCode: `${selectedRefId || ''}-${String.fromCharCode(charCode++)}`,
          kaliteSinifi: `${item.sortlamaGaplama || ''} (${item.meydany})`,
          quantityKg: Number(item.agramyKg),
          packageType: item.haltaSany,
          packageCount: 1,
          destination: item.girisYeri || destination,
          targetMarket: item.sortlamaGaplama === 'Pak we heňli' ? 'Sanayi / İmha' : 'İç Piyasa',
          temperatureRequirement: 16.0,
          notes: `${item.sortlamaGaplama || ''} - ${item.badamSorty}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    setSplitLots(newLots);
    alert(`🥜 Badam Çykyş we Giriş Depderçesinden ${newLots.length} alt-parti (Jemi: ${bademSums.totalKg} kg) Parçalı Yüke aktarıldı.`);
  };

  // ----------------------------------------------------
  // Split Lots: 6 Standart Sınıfa Bölme Şablonları (NaNsız)
  // ----------------------------------------------------
  const handleApplySixClassesPreset = () => {
    const total = safeTotalKg > 0 ? safeTotalKg : 4800;

    // Banana vs Fruit ratios
    const ratios = fruitCategory === 'MUZ'
      ? [0.35, 0.30, 0.20, 0.08, 0.04, 0.03] // Extra %35, Class I %30, Class II %20, Class III %8, Mix %4, Sanayi %3
      : [0.30, 0.35, 0.20, 0.08, 0.04, 0.03]; // General Fruit ratio

    const newLots: SplitLotItem[] = STANDARD_QUALITY_CLASSES.map((qc, i) => {
      const subLotLetter = String.fromCharCode(65 + i);
      const isNonStandard = qc.isProcessingOrNonStandard || qc.key.includes('Standart Däl') || qc.key.includes('Mix');
      const allocated = Number((total * ratios[i]).toFixed(3));

      let targetDestination = destination;
      if (fruitCategory === 'MUZ') {
        targetDestination = isNonStandard
          ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)'
          : 'Hemsaýa Muz Gazlama & Olgunlaşdyryş';
      } else {
        targetDestination = isNonStandard
          ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)'
          : 'Datly Miwe Merkez Sowuk Depo';
      }

      return {
        subLotId: `${selectedRefId || ''}-${subLotLetter}`,
        variety: customVariety,
        qualityGrade: qc.key,
        quantityKg: allocated,
        caseCount: Math.round(allocated / 20),
        palletCount: Math.round(allocated / 360),
        destination: targetDestination,
        notes: `${qc.nameTm} (${qc.nameTr}) standart sınıfı ayrıştırıldı.`,
        timestamp: new Date().toISOString()
      };
    });

    setSplitLots(newLots);
  };

  const handleApplyFreshVsFreezeDryPreset = () => {
    const total = safeTotalKg > 0 ? safeTotalKg : 4500;
    const freshKg = Number((total * 0.85).toFixed(3));
    const freezeDryKg = Number((total * 0.15).toFixed(3));

    const newLots: SplitLotItem[] = [
      {
        subLotId: `${selectedRefId || ''}-A`,
        variety: customVariety,
        qualityGrade: 'I (V-22) EXC',
        quantityKg: freshKg,
        caseCount: Math.round(freshKg / 20),
        palletCount: Math.round(freshKg / 360),
        destination: fruitCategory === 'MUZ' ? 'Hemsaýa Muz Gazlama & Olgunlaşdyryş' : 'Datly Miwe Merkez Sowuk Depo',
        notes: '1. Sınıf Taze Ticari Satış / Soğuk Depo',
        timestamp: new Date().toISOString()
      },
      {
        subLotId: `${selectedRefId || ''}-B`,
        variety: customVariety,
        qualityGrade: 'Standart Däl / Standart Dışı',
        quantityKg: freezeDryKg,
        caseCount: Math.round(freezeDryKg / 20),
        palletCount: Math.round(freezeDryKg / 360),
        destination: 'Erem Freeze-Dry Tesisi (-40°C Şoklama)',
        notes: 'Standart Dışı / Liyofilizasyon & Freeze-Dry Ayrımı',
        timestamp: new Date().toISOString()
      }
    ];

    setSplitLots(newLots);
  };

  const handleDistributeEvenly = () => {
    if (splitLots.length === 0) return;
    const total = safeTotalKg > 0 ? safeTotalKg : 4200;
    const count = splitLots.length;
    const perLot = Number((total / count).toFixed(3));

    const updated = splitLots.map(item => ({
      ...item,
      quantityKg: perLot,
      caseCount: Math.round(perLot / 20)
    }));
    setSplitLots(updated);
  };

  // Distribute remaining kg to the last lot (NaN-safe)
  const handleAssignRemainingToLast = () => {
    if (splitLots.length === 0) return;
    const lastIdx = splitLots.length - 1;
    const updated = [...splitLots];
    const currentLastKg = Number(updated[lastIdx].quantityKg) || 0;
    const newLastKg = Number((currentLastKg + remainingSplitKg).toFixed(3));

    updated[lastIdx] = {
      ...updated[lastIdx],
      quantityKg: newLastKg,
      caseCount: Math.round(newLastKg / 20)
    };
    setSplitLots(updated);
  };

  // Sync Form weightKg from allocated split lots
  const handleSyncFormWeightFromSplit = () => {
    if (allocatedSplitKg > 0) {
      setWeightKg(Number(allocatedSplitKg.toFixed(3)));
    }
  };

  // Add a single custom split row
  const handleAddSplitRow = () => {
    const nextIdx = splitLots.length + 1;
    const subLotLetter = String.fromCharCode(64 + nextIdx);
    const subLotId = `${selectedRefId || ''}-${subLotLetter}`;

    const newLot: SplitLotItem = {
      subLotId,
      variety: customVariety,
      qualityGrade: 'EXTRA (V-20)',
      quantityKg: remainingSplitKg > 0 ? remainingSplitKg : 0,
      caseCount: remainingSplitKg > 0 ? Math.round(remainingSplitKg / 20) : 0,
      palletCount: 1,
      destination: destination,
      notes: '',
      timestamp: new Date().toISOString()
    };

    setSplitLots([...splitLots, newLot]);
  };

  // Update split row
  const handleUpdateSplitRow = (index: number, field: keyof SplitLotItem, val: any) => {
    const updated = [...splitLots];
    let sanitizedVal = val;
    if (field === 'quantityKg') {
      const num = Number(val);
      sanitizedVal = Number.isFinite(num) ? Math.max(0, num) : 0;
    }

    updated[index] = {
      ...updated[index],
      [field]: sanitizedVal
    };

    // Auto-update caseCount if quantity changed
    if (field === 'quantityKg' && (!updated[index].caseCount || updated[index].caseCount === 0)) {
      updated[index].caseCount = Math.round(Number(sanitizedVal) / 20);
    }

    setSplitLots(updated);
  };

  const handleDeleteSplitRow = (index: number) => {
    setSplitLots(splitLots.filter((_, i) => i !== index));
  };

  // ----------------------------------------------------
  // Delilnama Handlers & Row Manipulation
  // ----------------------------------------------------
  const handleUpdateDelilnamaRow = (index: number, field: keyof DelilnamaGradeRow, val: any) => {
    const updatedGrades = [...delilnamaPassport.grades];
    const num = Number(val);
    const sanitizedVal = Number.isFinite(num) ? Math.max(0, num) : 0;

    updatedGrades[index] = {
      ...updatedGrades[index],
      [field]: sanitizedVal
    };

    // Auto-calculate case count if hasylNetKg changed
    if (field === 'hasylNetKg' && (!updatedGrades[index].gapSany || updatedGrades[index].gapSany === 0)) {
      updatedGrades[index].gapSany = Math.round(sanitizedVal / 20);
    }

    setDelilnamaPassport(prev => ({
      ...prev,
      grades: updatedGrades
    }));
  };

  const handleDeleteDelilnamaRow = (index: number) => {
    setDelilnamaPassport(prev => ({
      ...prev,
      grades: prev.grades.filter((_, i) => i !== index)
    }));
  };

  const handleAddDelilnamaRow = () => {
    const matchClass = STANDARD_QUALITY_CLASSES.find(c => c.key === newGradeKey);
    const newRow: DelilnamaGradeRow = {
      gradeKey: newGradeKey,
      gradeLabelTr: matchClass?.nameTr || newGradeKey,
      yassikliKg: 0,
      hasylNetKg: 0,
      satysaBerlenKg: 0,
      gapSany: 0
    };

    setDelilnamaPassport(prev => ({
      ...prev,
      grades: [...prev.grades, newRow]
    }));
  };

  // Transfer Delilnama net kg into Form weight and split lots
  const handleTransferDelilnamaToFormAndSplit = () => {
    if (delilnamaSums.totalNet > 0) {
      setWeightKg(delilnamaSums.totalNet);
      setCaseCount(delilnamaSums.totalGap);

      // Also transfer to split lots
      const newLots: SplitLotItem[] = delilnamaPassport.grades.map((g, i) => {
        const subLotLetter = String.fromCharCode(65 + i);
        const isNonStandard = g.gradeKey.includes('Standart Däl') || g.gradeKey.includes('Mix');
        return {
          subLotId: `${selectedRefId || ''}-${subLotLetter}`,
          variety: customVariety,
          qualityGrade: g.gradeKey,
          quantityKg: g.hasylNetKg,
          caseCount: g.gapSany || Math.round(g.hasylNetKg / 20),
          palletCount: Math.round(g.hasylNetKg / 360) || 1,
          destination: isNonStandard ? 'Erem Freeze-Dry Tesisi (-40°C Şoklama)' : destination,
          notes: `Delilnama pasaportundan aktarıldı (${g.gradeKey}).`,
          timestamp: new Date().toISOString()
        };
      });

      setSplitLots(newLots);
    }
  };

  // Form Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let finalRefId = selectedRefId.trim() || initialRecord?.refId || '';
    if (!finalRefId) {
      finalRefId = generateRefId('LOJISTIK', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Lojistik Sevkiyat Uzmanı';

    const lojistikRecord: LojistikRecord = {
      id: initialRecord?.id || `l-${Date.now()}`,
      refId: finalRefId,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      shipmentDate,
      source: source.trim() || 'Merkez Soğuk Hava Deposu',
      destination: destination.trim() || 'Aşgabat / İhracat',
      vehiclePlate: fruitCategory === 'BADEM' && bademPassport.ulagBelgisi ? bademPassport.ulagBelgisi : (vehiclePlate.trim() || 'AG 7721 AH'),
      driver: driver.trim() || 'Merdan Orazow',
      driverPhone,
      delilnamaNo: fruitCategory === 'BADEM' ? bademPassport.depderceNo : (delilnamaNo.trim() || ''),
      transportType: transportType.trim() || 'Frigorifik Tır (Reefer)',
      palletCount: Math.max(1, palletCount),
      caseCount: Math.max(1, caseCount),
      weightKg: fruitCategory === 'BADEM' && bademSums.totalKg > 0 ? bademSums.totalKg : safeTotalKg,
      departureTemperature,
      transitTemperature,
      kaliteSinifi,
      fruitCategory,
      product: fruitCategory === 'BADEM' ? 'Badem' : (fruitCategory === 'MUZ' ? 'Muz' : (customFruit.trim() || 'Şeftali')),
      variety: customVariety.trim() || 'Extreme 314',
      delilnama: fruitCategory === 'BADEM' ? undefined : (enableDelilnama ? delilnamaPassport : undefined),
      bademDelilnama: fruitCategory === 'BADEM' ? bademPassport : undefined,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      status,
      notes,
      photos: photos.length > 0 ? photos : undefined
    };

    onSave(lojistikRecord, finalRefId);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
      {/* Top Header */}
      <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-500/20 border border-blue-400/30 text-blue-400 shadow-xs">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2 font-serif">
              <span>Lojistik, Sevkiyat & Delilnama Pasaportu</span>
              <span className="text-[11px] font-sans font-bold bg-blue-500/30 text-blue-200 border border-blue-400/40 px-2 py-0.5 rounded-full">
                Tek Yetkili Modül
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Resmi kalite pasaportu koçanı, 6 standart sınıfa bölme şablonu, parçalı yük (split lots) ve soğuk zincir yönetimi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {enableDelilnama && (
            <button
              type="button"
              onClick={() => setShowPrintModal(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-blue-200 hover:text-white bg-blue-800/60 hover:bg-blue-800 border border-blue-400/40 px-3 py-1.5 rounded-lg transition shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Baskılı Koçan Önizle</span>
            </button>
          )}

          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* 1. DİNAMİK MEYVE SEÇİMİ (Muz vs Diğer Meyveler) */}
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50/40 to-slate-50 border-2 border-blue-300/80 rounded-2xl p-4 sm:p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-blue-200/60">
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-blue-900 block font-serif">
                1. Dinamik Meyve ve Standart Seçimi
              </span>
              <p className="text-xs text-slate-600">
                Meyve tipine göre kalite klasları, koçan şablonları ve hedef sevkiyat sıcaklıkları otomatik uyarlanır.
              </p>
            </div>

            {/* Toggle Buttons */}
            <div className="flex items-center bg-white p-1 rounded-xl border border-blue-300 shadow-xs flex-wrap gap-1">
              <button
                type="button"
                onClick={() => handleFruitCategoryChange('MUZ')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-black transition cursor-pointer ${
                  fruitCategory === 'MUZ'
                    ? 'bg-amber-400 text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>🍌 Muz (Cavendish / Sera)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFruitCategoryChange('DIGER')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-black transition cursor-pointer ${
                  fruitCategory === 'DIGER'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>🍎 Diğer Meyveler (Bahçe / Meyve)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFruitCategoryChange('BADEM')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs font-black transition cursor-pointer ${
                  fruitCategory === 'BADEM'
                    ? 'bg-amber-700 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>🥜 Badem (Miweli Atyz / Depderçe)</span>
              </button>
            </div>
          </div>

          {/* Fruit Category Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                {fruitCategory === 'MUZ' ? 'Meyve Adı' : fruitCategory === 'BADEM' ? 'Ürün / Tesis Standardı' : 'Meyve Türü Seçin / Yazın *'}
              </label>
              {fruitCategory === 'MUZ' ? (
                <div className="w-full text-xs font-bold bg-amber-50 border border-amber-300 text-amber-950 rounded-lg px-3 py-2 flex items-center justify-between">
                  <span>🍌 Muz (Hemsaýa Sera Muz)</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded font-mono">STANDART</span>
                </div>
              ) : fruitCategory === 'BADEM' ? (
                <div className="w-full text-xs font-bold bg-amber-50 border border-amber-300 text-amber-950 rounded-lg px-3 py-2 flex items-center justify-between">
                  <span>🥜 Badem (Miweli Atyz Badam Zawod)</span>
                  <span className="text-[10px] bg-amber-700 text-white px-2 py-0.5 rounded font-mono font-bold">RESMİ DEPDERÇE</span>
                </div>
              ) : (
                <select
                  value={customFruit}
                  onChange={(e) => setCustomFruit(e.target.value)}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
                >
                  <option value="Şeftali">🍑 Şeftali</option>
                  <option value="Kiraz">🍒 Kiraz</option>
                  <option value="Nektarin">🍑 Nektarin</option>
                  <option value="Elma">🍎 Elma</option>
                  <option value="Çilek">🍓 Çilek</option>
                  <option value="İncir">🫐 İncir</option>
                  <option value="Erik">🟣 Erik</option>
                </select>
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                {fruitCategory === 'BADEM' ? 'Badamyň Sorty (Çeşit) *' : 'Çeşit / Sort (Görnüşi) *'}
              </label>
              {fruitCategory === 'BADEM' ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customVariety}
                    onChange={(e) => setCustomVariety(e.target.value)}
                    className="w-full text-xs font-bold bg-white border border-amber-300 rounded-lg px-3 py-2 font-mono text-slate-900"
                    placeholder="Laurenne, Nonpareil, Ferragnes..."
                   
                  />
                  <select
                    onChange={(e) => setCustomVariety(e.target.value)}
                    className="text-xs bg-amber-50 border border-amber-300 rounded-lg px-2 font-bold text-amber-900 cursor-pointer"
                    value={customVariety}
                  >
                    <option value="Laurenne">Laurenne</option>
                    <option value="Nonpareil">Nonpareil</option>
                    <option value="Ferragnes">Ferragnes</option>
                    <option value="Guara">Guara</option>
                  </select>
                </div>
              ) : (
                <input
                  type="text"
                  value={customVariety}
                  onChange={(e) => setCustomVariety(e.target.value)}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono text-slate-800"
                  placeholder="Örn: Cavendish, Extreme 314, Lapins..."
                 
                />
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Hedef Taşıma Sıcaklığı Tavsiyesi
              </label>
              <div className="w-full text-xs font-bold bg-white border border-blue-200 rounded-lg px-3 py-2 flex items-center justify-between text-blue-900">
                <span>
                  {fruitCategory === 'MUZ'
                    ? '🍌 Muz İdeal: 13.5°C'
                    : fruitCategory === 'BADEM'
                    ? '🥜 Badem İdeal: 15°C - 18°C (Kuru)'
                    : '🍎 Soğuk Depo: 1°C - 4°C'}
                </span>
                <span className="text-[10px] bg-blue-100 px-2 py-0.5 rounded text-blue-800 font-mono font-bold">TERMO</span>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Reference Badge / Selector */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1">
              Sevkiyat Yapılacak Parti / Referans (RefID Seçin veya Yazın)
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                list="lojistik-ref-list"
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                placeholder="Örn: REF-101 veya listeden seçin..."
                className="w-full md:w-96 text-xs font-mono font-bold bg-white border border-blue-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-blue-500"
              />
              <datalist id="lojistik-ref-list">
                {existingRefs.map(r => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} — {r.product} ({r.quantity} {r.unit}) [{r.status}]
                  </option>
                ))}
              </datalist>
            </div>
          </div>

          <div className="text-xs text-slate-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
            <div>Ürün: <strong className="text-slate-900">{selectedRef?.product || (fruitCategory === 'MUZ' ? 'Muz' : customFruit)}</strong></div>
            <div>Mevcut Durum: <span className="font-mono font-bold text-blue-700">{selectedRef?.status || ''}</span></div>
          </div>
        </div>

        {/* Dispatch & Driver Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Operatör / Sevkiyat Sorumlusu *
            </label>
            <input
              type="text"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Resmi Delilnama No (Baskılı Koçan №) (Opsiyonel)
            </label>
            <div className="relative">
              <input
                type="text"
                value={delilnamaNo}
                onChange={(e) => setDelilnamaNo(e.target.value)}
                placeholder="Örn: 0005421 (İsteğe bağlı)"
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono font-black text-blue-900"
              />
              <FileText className="w-3.5 h-3.5 text-blue-500 absolute right-2.5 top-2.5" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat Tarihi (Sene)
            </label>
            <input
              type="date"
              value={shipmentDate}
              onChange={(e) => setShipmentDate(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Taşıma Tipi / Araç Standardı
            </label>
            <select
              value={transportType}
              onChange={(e) => setTransportType(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-semibold"
            >
              {AUTOCOMPLETE_LISTS.transportTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Çıkış Yeri (Kaynak / Ýeri)
            </label>
            <input
              type="text"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <SmartCreatableSelect
              label="Varış Yeri / Hedef Tesis (Opsiyonel)"
              categoryKey="destinations"
              options={[]}
              value={destination}
              onChange={setDestination}
              placeholder="Hedef tesis seçin veya yeni ekleyin..."
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Araç Plakası *
            </label>
            <input
              type="text"
              value={vehiclePlate}
              onChange={(e) => setVehiclePlate(e.target.value)}
             
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold uppercase"
              placeholder="74 AG 912"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sürücü Adı & Telefon
            </label>
            <div className="flex gap-1">
              <input
                type="text"
                value={driver}
                onChange={(e) => setDriver(e.target.value)}
                className="w-1/2 text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                placeholder="Ad Soyad"
              />
              <input
                type="text"
                value={driverPhone}
                onChange={(e) => setDriverPhone(e.target.value)}
                className="w-1/2 text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 font-mono"
                placeholder="+993..."
              />
            </div>
          </div>
        </div>

        {/* Quantity & Temperature Monitoring (NaN-Safe) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Toplam Net Ağırlık (kg) *
            </label>
            <input
              type="number"
              value={weightKg}
              onChange={(e) => {
                const val = Number(e.target.value);
                setWeightKg(Number.isFinite(val) ? Math.max(0, val) : 0);
              }}
              className="w-full text-xs bg-white border border-blue-300 rounded-lg px-3 py-2 font-mono font-black text-slate-900 shadow-xs"
             
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Palet Adedi
            </label>
            <input
              type="number"
              value={palletCount}
              onChange={(e) => setPalletCount(Number(e.target.value))}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Kasa / Kutu Adedi (Gap Sany)
            </label>
            <input
              type="number"
              value={caseCount}
              onChange={(e) => setCaseCount(Number(e.target.value))}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 block">
                Çıkış Yükleme Isısı (°C)
              </label>
              <button
                type="button"
                onClick={() => setActivePublicationModal(MDPI_ARTICLES.TEMPERATURE_METABOLISM)}
                className="px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-900 hover:bg-blue-500/30 text-[9px] font-mono font-bold border border-blue-400/40 transition cursor-pointer flex items-center gap-1"
                title="Horticulturae (Temmuz 2026) Sıcaklık & Hücre Duvarı Metabolizması Makale Atıfı"
              >
                <BookOpen className="w-2.5 h-2.5 text-blue-700 shrink-0" />
                <span>[MDPI 2026]</span>
              </button>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="number"
                step="0.1"
                value={departureTemperature}
                onChange={(e) => setDepartureTemperature(Number(e.target.value))}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold text-blue-700"
              />
              <Thermometer className="w-4 h-4 text-blue-500" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Transit Hedef Isı (°C)
            </label>
            <div className="flex items-center gap-1">
              <input
                type="number"
                step="0.1"
                value={transitTemperature}
                onChange={(e) => setTransitTemperature(Number(e.target.value))}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold text-blue-700"
              />
              <Thermometer className="w-4 h-4 text-blue-500" />
            </div>
          </div>
        </div>

        {/* Ana Kalite Sınıfı (Hil Derejesi) Seçimi */}
        <div className="bg-blue-50/50 border border-blue-200 rounded-2xl p-4">
          <QualityGradeSelect
            value={kaliteSinifi}
            onChange={setKaliteSinifi}
            label={`Sevkiyat Ana Kalite Sınıfı (${fruitCategory === 'MUZ' ? 'Muz Hil Derejesi' : 'Hil Derejesi'})`}
            subLabel="Araca yüklenen ürünlerin ana kalite klasmanı ve sevk irsaliyesi başlığı"
           
          />
        </div>

        {/* 2. DELILNAMA VEYA BADAM DEPDERÇESİ (Resmi Baskılı Standart) */}
        {fruitCategory === 'BADEM' ? (
          /* BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI (№ 0000417) */
          <div className="bg-gradient-to-br from-amber-50/80 via-orange-50/40 to-slate-50 border-2 border-amber-600 rounded-2xl p-5 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-300">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-800 text-white shadow-xs">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 flex items-center gap-2 font-serif">
                    <span>BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI</span>
                    <span className="text-[10px] font-sans font-black bg-amber-200 text-amber-950 border border-amber-400 px-2 py-0.5 rounded-md">
                      "MIWE" AGPJ Resmi Koçany
                    </span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    Miweli Atyz senagat badam zawodyndan çykyş, arassalanan maňyz, sortlama & gaplama depderçesi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowPrintModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Resmi Badam Depderçesi Yazdır</span>
                </button>
              </div>
            </div>

            {/* Badem Booklet Meta Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-amber-300 text-xs shadow-xs">
              <div>
                <span className="text-slate-500 font-bold block mb-1">Depderçe № (Koçan No):</span>
                <input
                  type="text"
                  value={bademPassport.depderceNo}
                  onChange={(e) => setBademPassport(p => ({ ...p, depderceNo: e.target.value }))}
                  className="w-full font-mono font-black text-amber-950 bg-amber-50 px-2.5 py-1.5 rounded border border-amber-300 text-xs"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Sene (Tarih):</span>
                <input
                  type="date"
                  value={bademPassport.sene}
                  onChange={(e) => setBademPassport(p => ({ ...p, sene: e.target.value }))}
                  className="w-full font-mono font-bold text-slate-800 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200 text-xs"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Ulagyň Belgisi (Plaka):</span>
                <input
                  type="text"
                  value={bademPassport.ulagBelgisi}
                  onChange={(e) => {
                    setBademPassport(p => ({ ...p, ulagBelgisi: e.target.value }));
                    setVehiclePlate(e.target.value);
                  }}
                  className="w-full font-mono font-bold text-blue-900 bg-blue-50 px-2.5 py-1.5 rounded border border-blue-200 text-xs uppercase"
                />
              </div>
              <div>
                <span className="text-slate-500 font-bold block mb-1">Bellik (Açıklama / Not):</span>
                <input
                  type="text"
                  value={bademPassport.bellik}
                  onChange={(e) => setBademPassport(p => ({ ...p, bellik: e.target.value }))}
                  placeholder="Big Bag gaplanan täze hasyl..."
                  className="w-full font-bold text-slate-800 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200 text-xs"
                />
              </div>
            </div>

            {/* TABLISA 1: Arassalanan Görnüşi & Esasy Maňyz (Premium Çykyş) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white font-serif font-black text-xs flex items-center justify-center">
                    1
                  </span>
                  <span className="text-xs font-black uppercase text-amber-950 font-serif tracking-wider">
                    Tablisa 1: Arassalanan Görnüşi & Esasy Maňyz (Premium Çykyş)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-black text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded">
                    Jemi: {bademSums.totalPremium} kg
                  </span>
                  <button
                    type="button"
                    onClick={handleAddBademPremiumRow}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold transition cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Satyr Goş</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto border border-amber-300 rounded-xl shadow-xs bg-white">
                <table className="w-full text-xs text-left">
                  <thead className="bg-amber-900 text-white font-serif uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-2 px-2 text-center w-8">№</th>
                      <th className="py-2 px-3">Çykyş Ýeri</th>
                      <th className="py-2 px-3">Giriş Ýeri</th>
                      <th className="py-2 px-3">Badamyň Sorty</th>
                      <th className="py-2 px-3">Meýdany / Kalibr</th>
                      <th className="py-2 px-3">Arassalanan Görnüşi</th>
                      <th className="py-2 px-3 text-right">Agramy (kg)</th>
                      <th className="py-2 px-3">Halta / Gap</th>
                      <th className="py-2 px-2 text-center w-10">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-100">
                    {bademPassport.premiumItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-amber-50/40 transition">
                        <td className="py-2 px-2 text-center font-mono font-bold text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.cykysYeri}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'cykysYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.girisYeri}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'girisYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.badamSorty}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'badamSorty', e.target.value)}
                            className="w-24 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.meydany}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'meydany', e.target.value)}
                            placeholder="21/22 Premium"
                            className="w-28 text-xs font-bold bg-white border border-amber-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.arassalananGornusi || ''}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'arassalananGornusi', e.target.value)}
                            placeholder="Elde / Garyşyk maňyz / Şänik..."
                            className="w-36 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="number"
                            step="0.1"
                            value={item.agramyKg}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'agramyKg', Number(e.target.value))}
                            className="w-24 text-right font-mono font-black text-amber-950 bg-amber-50 border border-amber-300 rounded px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.haltaSany}
                            onChange={(e) => handleUpdateBademPremiumRow(idx, 'haltaSany', e.target.value)}
                            placeholder="Big Bag 1 sany"
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteBademPremiumRow(idx)}
                            className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* TABLISA 2: Sortlama & Gaplama (Classic, Mix, Döwük, Pak we heňli) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-white font-serif font-black text-xs flex items-center justify-center">
                    2
                  </span>
                  <span className="text-xs font-black uppercase text-slate-900 font-serif tracking-wider">
                    Tablisa 2: Sortlama & Gaplama (Classic, Mix, Döwük, Pak we heňli)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-black text-slate-800 bg-slate-200 border border-slate-300 px-2.5 py-0.5 rounded">
                    Jemi: {bademSums.totalSortlama} kg
                  </span>
                  <button
                    type="button"
                    onClick={handleAddBademSortlamaRow}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Satyr Goş</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-xs bg-white">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-800 text-white font-serif uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-2 px-2 text-center w-8">№</th>
                      <th className="py-2 px-3">Çykyş Ýeri</th>
                      <th className="py-2 px-3">Giriş Ýeri</th>
                      <th className="py-2 px-3">Badamyň Sorty</th>
                      <th className="py-2 px-3">Meýdany / Sınıf</th>
                      <th className="py-2 px-3">Sortlama Gaplama</th>
                      <th className="py-2 px-3 text-right">Agramy (kg)</th>
                      <th className="py-2 px-3">Halta / Gap</th>
                      <th className="py-2 px-2 text-center w-10">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {bademPassport.sortlamaItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-slate-50 transition">
                        <td className="py-2 px-2 text-center font-mono font-bold text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.cykysYeri}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'cykysYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.girisYeri}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'girisYeri', e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.badamSorty}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'badamSorty', e.target.value)}
                            className="w-24 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.meydany}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'meydany', e.target.value)}
                            placeholder="33-35 Classic / Mix"
                            className="w-28 text-xs font-bold bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <select
                            value={item.sortlamaGaplama || ''}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'sortlamaGaplama', e.target.value)}
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1 font-bold"
                          >
                            <option value="I sort">I sort</option>
                            <option value="II sort">II sort</option>
                            <option value="III sort">III sort</option>
                            <option value="Pak we heňli">Pak we heňli</option>
                          </select>
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="number"
                            step="0.1"
                            value={item.agramyKg}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'agramyKg', Number(e.target.value))}
                            className="w-24 text-right font-mono font-black text-slate-900 bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="text"
                            value={item.haltaSany}
                            onChange={(e) => handleUpdateBademSortlamaRow(idx, 'haltaSany', e.target.value)}
                            placeholder="Halta 1 sany"
                            className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteBademSortlamaRow(idx)}
                            className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Grand Totals Bar */}
            <div className="bg-gradient-to-r from-amber-100 via-amber-50 to-orange-100 p-4 rounded-xl border border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-6 flex-wrap">
                <div>
                  <span className="text-[10px] font-bold text-slate-600 block uppercase">Tablisa 1 (Esasy Maňyz):</span>
                  <span className="font-mono font-black text-sm text-amber-950">{bademSums.totalPremium} kg</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-600 block uppercase">Tablisa 2 (Sortlama/Gaplama):</span>
                  <span className="font-mono font-black text-sm text-slate-900">{bademSums.totalSortlama} kg</span>
                </div>
                <div className="border-l-2 border-amber-400 pl-4">
                  <span className="text-[10px] font-bold text-amber-900 block uppercase tracking-wider">JEMI RESMİ NET AGRAM:</span>
                  <span className="font-mono font-black text-lg text-amber-950">{bademSums.totalKg} kg</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleTransferBademToSplitLots}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-900 text-white text-xs font-black shadow-sm transition active:scale-95 cursor-pointer"
              >
                <Split className="w-4 h-4" />
                <span>Depderçeden Parçalı Yüke (Split Lots) Aktar</span>
              </button>
            </div>

            {/* 3 Signatures */}
            <div className="pt-3 border-t border-amber-300">
              <span className="text-xs font-black uppercase tracking-wider text-slate-800 block mb-2 font-serif">
                Resmi 3 Yetkili İmza Koçanı (Badam Zawod - Sowuk Depo - Hil)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold uppercase text-slate-500 block">
                    1. Çykyş Eden (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.cykysEden}
                    onChange={(e) => setBademPassport(p => ({ ...p, cykysEden: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Badam zawod (Amanow B.)"
                  />
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold uppercase text-slate-500 block">
                    2. Giriş Eden (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.girisEden}
                    onChange={(e) => setBademPassport(p => ({ ...p, girisEden: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Sowuk depo (Myradow G.)"
                  />
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold uppercase text-slate-500 block">
                    3. Tassyklan (Ady/Familiýasy)
                  </span>
                  <input
                    type="text"
                    value={bademPassport.tassyklan}
                    onChange={(e) => setBademPassport(p => ({ ...p, tassyklan: e.target.value }))}
                    className="w-full text-xs font-bold bg-amber-50/50 border border-amber-200 rounded px-2.5 py-1.5 text-slate-900"
                    placeholder="Hil hünärmen (Kadyrow D.)"
                  />
                </div>
              </div>
            </div>

          </div>
        ) : (
        /* 2. DELILNAMA / RESMİ KALİTE PASAPORTU (Baskılı Koçan Standardı) */
        <div className="bg-gradient-to-br from-emerald-50/70 via-teal-50/40 to-slate-50 border-2 border-emerald-400/90 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-300/80">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-700 text-white shadow-xs">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2 font-serif">
                  <span>DELILNAMA / RESMİ KALİTE PASAPORTU</span>
                  <span className="text-[10px] font-sans font-black bg-emerald-200 text-emerald-950 border border-emerald-400 px-2 py-0.5 rounded-md">
                    Baskılı Koçan Standardı
                  </span>
                </h3>
                <p className="text-xs text-slate-600">
                  Resmi hasat ve kalite sınıfları dağılım tablosu, net kilo hesabı ve 3 yetkili imza koçanı
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowPrintModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Resmi Koçan Yazdır</span>
              </button>
            </div>
          </div>

          {/* Delilnama Header Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-emerald-200 text-xs">
            <div>
              <span className="text-slate-500 font-bold block mb-1">Delilnama № (Koçan No):</span>
              <span className="font-mono font-black text-emerald-900 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 block">
                {delilnamaPassport.delilnamaNo}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Sene (Tarih):</span>
              <span className="font-mono font-bold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 block">
                {delilnamaPassport.sene}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Ýeri (Sera / Bahçe Lokasyonu):</span>
              <span className="font-bold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 block truncate">
                {delilnamaPassport.yeri}
              </span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block mb-1">Miwe & Görnüşi:</span>
              <span className="font-bold text-emerald-950 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 block truncate">
                {delilnamaPassport.miwe} ({delilnamaPassport.miweGornusi})
              </span>
            </div>
          </div>

          {/* Delilnama Grades Distribution Table */}
          <div className="overflow-x-auto border border-emerald-300/80 rounded-xl shadow-xs bg-white">
            <table className="w-full text-xs text-left">
              <thead className="bg-emerald-800 text-white font-serif uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Kalite Sınıfı (Hil Derejesi)</th>
                  <th className="py-2.5 px-3 text-right">Ýaşşikli Ýygylan (kg)</th>
                  <th className="py-2.5 px-3 text-right">Hasyl Net (kg)</th>
                  <th className="py-2.5 px-3 text-right">Satyşa Berlen (kg)</th>
                  <th className="py-2.5 px-3 text-right">Gap Sany (san)</th>
                  <th className="py-2.5 px-3 text-center">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {delilnamaPassport.grades.map((g, idx) => {
                  return (
                    <tr key={idx} className="hover:bg-emerald-50/40 transition">
                      <td className="py-2 px-3">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span className="font-mono font-black text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[11px]">
                            {g.gradeKey}
                          </span>
                          {g.gradeLabelTr && (
                            <span className="text-slate-500 text-[10px]">({g.gradeLabelTr})</span>
                          )}
                        </div>
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.yassikliKg ?? 0}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'yassikliKg', e.target.value)}
                          className="w-24 text-right font-mono font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.hasylNetKg}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'hasylNetKg', e.target.value)}
                          className="w-24 text-right font-mono font-black text-emerald-900 bg-emerald-50 border border-emerald-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={g.satysaBerlenKg ?? g.hasylNetKg}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'satysaBerlenKg', e.target.value)}
                          className="w-24 text-right font-mono font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          value={g.gapSany ?? 0}
                          onChange={(e) => handleUpdateDelilnamaRow(idx, 'gapSany', e.target.value)}
                          className="w-20 text-right font-mono font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteDelilnamaRow(idx)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          title="Sınıfı Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {/* Delilnama JEMI (Total) Row */}
                <tr className="bg-emerald-100/70 font-black text-slate-900 border-t-2 border-emerald-400">
                  <td className="py-2.5 px-3 uppercase tracking-wider text-emerald-950 font-serif">
                    JEMI (TOPLAM RESMİ HASAT)
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-800">
                    {delilnamaSums.totalYassikli} kg
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-emerald-900 text-sm">
                    {delilnamaSums.totalNet} kg
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-900">
                    {delilnamaSums.totalSatysa} kg
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-900">
                    {delilnamaSums.totalGap} gap
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="text-[10px] bg-emerald-700 text-white px-1.5 py-0.5 rounded font-mono">
                      100%
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Add New Class to Delilnama Row & Action */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-slate-700">+ Täze Klas Goş:</span>
              <select
                value={newGradeKey}
                onChange={(e) => setNewGradeKey(e.target.value)}
                className="text-xs font-bold bg-white border border-emerald-300 rounded-lg px-2.5 py-1.5 text-slate-800"
              >
                {STANDARD_QUALITY_CLASSES.map(c => (
                  <option key={c.key} value={c.key}>
                    {c.key} — {c.nameTr}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={handleAddDelilnamaRow}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Listeye Ekle</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleTransferDelilnamaToFormAndSplit}
              className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-xs font-black shadow-sm transition hover:opacity-95 cursor-pointer"
            >
              <Scale className="w-4 h-4" />
              <span>Delilnama Netini Form Tonajına & Parçalı Yüke Aktar ({delilnamaSums.totalNet} kg)</span>
            </button>
          </div>

          {/* 3 Yetkili İmza Bölümü */}
          <div className="pt-3 border-t border-emerald-200">
            <span className="text-xs font-black uppercase tracking-wider text-slate-800 block mb-2 font-serif">
              Resmi 3 Yetkili İmza Koçanı (Baskı Onayı)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">
                  1. Öndüriji (Üretici / Çavuş)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.onduriji || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, onduriji: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Orazow R. (Çavuş)"
                />
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">
                  2. Hilçi Hünärmen (Kalite Uzmanı)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.hilciHunarmen || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, hilciHunarmen: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Saparow M. (Kalite Uzmanı)"
                />
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">
                  3. Satuw Hünärmen (Satış Uzmanı)
                </span>
                <input
                  type="text"
                  value={delilnamaPassport.satuwHunarmen || ''}
                  onChange={(e) => setDelilnamaPassport(prev => ({ ...prev, satuwHunarmen: e.target.value }))}
                  className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900"
                  placeholder="Mämmetgulyýew M."
                />
              </div>
            </div>
          </div>

        </div>
        )}

        {/* 3. PARÇALI YÜK & KALİTE SORTLARI DAĞITIMI (SPLIT LOGISTICS) */}
        <div className="bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20 border-2 border-blue-300/80 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-blue-200/60">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-700 text-white shadow-xs">
                <Split className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2 font-serif">
                  <span>Parçalı Yük & Kalite Sortları Dağıtımı (Split Logistics)</span>
                  <span className="text-[10px] font-sans font-black bg-blue-100 text-blue-900 border border-blue-300 px-2 py-0.5 rounded-full">
                    Otomatik Kilo Ayrıştırma
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  {fruitCategory === 'MUZ'
                    ? 'Muz için 6 standart kalite sınıfı şablonu (Extra, I-Exc, II-Prm, III-Cls, Mix, Sanayi)'
                    : 'Meyve çeşitleri için 6 standart sınıf dağılımı ve otomatik alt-parti kodlaması'}
                </p>
              </div>
            </div>

            {/* Quick Template Distribution Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleApplySixClassesPreset}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-black shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{fruitCategory === 'MUZ' ? '🍌 6 Standart Muz Sınıfına Dağıt' : '🍎 6 Standart Sınıfa Dağıt'}</span>
              </button>

              <button
                type="button"
                onClick={handleApplyFreshVsFreezeDryPreset}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-700 hover:bg-cyan-800 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Snowflake className="w-3.5 h-3.5" />
                <span>Taze (%85) vs Freeze-Dry (%15)</span>
              </button>

              <button
                type="button"
                onClick={handleDistributeEvenly}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <span>⚖️ Eşit Böl (1/N)</span>
              </button>
            </div>
          </div>

          {/* Allocation & Remaining Balance Stats (NaNsız Tekilleştirilmiş Stok Hesabı) */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-white p-3 rounded-xl border border-blue-200 text-xs">
            <div>
              <span className="text-slate-500 font-bold block">Toplam Sevkiyat Tonajı:</span>
              <span className="text-sm font-black font-mono text-slate-900">{safeTotalKg} kg</span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block">Ayrıştırılan Kilo:</span>
              <span className="text-sm font-black font-mono text-blue-800">{allocatedSplitKg} kg</span>
            </div>
            <div>
              <span className="text-slate-500 font-bold block">Kalan Dağıtılmamış Kilo:</span>
              <span className={`text-sm font-black font-mono ${remainingSplitKg > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                {remainingSplitKg} kg
              </span>
            </div>
            <div className="flex items-center justify-end gap-1">
              {remainingSplitKg > 0 && splitLots.length > 0 && (
                <button
                  type="button"
                  onClick={handleAssignRemainingToLast}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition cursor-pointer"
                >
                  Kalanı Son Sınıfa Aktar
                </button>
              )}
              {isOverAllocated && (
                <button
                  type="button"
                  onClick={handleSyncFormWeightFromSplit}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 border border-rose-300 transition cursor-pointer"
                >
                  Tonajı Eşitle
                </button>
              )}
            </div>
          </div>

          {/* Over-allocation warning */}
          {isOverAllocated && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Aşırı Dağıtım:</strong> Ayrıştırılan kilo ({allocatedSplitKg} kg), toplam tonajdan ({safeTotalKg} kg) fazladır.
                </span>
              </div>
              <button
                type="button"
                onClick={handleSyncFormWeightFromSplit}
                className="px-3 py-1 bg-rose-600 text-white rounded-lg font-bold text-xs hover:bg-rose-700 cursor-pointer"
              >
                Toplamı {allocatedSplitKg} kg Yap
              </button>
            </div>
          )}

          {/* Split Lots Table */}
          {splitLots.length === 0 ? (
            <div className="p-6 text-center bg-white rounded-xl border border-dashed border-slate-300 text-slate-500 space-y-2">
              <p className="text-xs font-semibold">
                Henüz parçalı kalite ayrıştırması yapılmadı.
              </p>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleApplySixClassesPreset}
                  className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-black shadow-xs transition cursor-pointer"
                >
                  {fruitCategory === 'MUZ' ? '🍌 6 Standart Muz Sınıfı Şablonunu Yükle' : '🍎 6 Standart Sınıf Şablonunu Yükle'}
                </button>
                <button
                  type="button"
                  onClick={handleAddSplitRow}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-300 transition cursor-pointer"
                >
                  + Manuel Sınıf Satırı Ekle
                </button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto border border-blue-200 rounded-xl shadow-xs bg-white">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-900 text-white font-serif uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Alt-Parti No (Sub-Lot)</th>
                    <th className="py-2.5 px-3">Kalite Sınıfı (Klas)</th>
                    <th className="py-2.5 px-3">Çeşit / Sort</th>
                    <th className="py-2.5 px-3 text-right">Ağırlık (kg)</th>
                    <th className="py-2.5 px-3 text-right">Kasa Sany</th>
                    <th className="py-2.5 px-3">Hedef Tesis / Lokasyon</th>
                    <th className="py-2.5 px-3 text-center">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {splitLots.map((lot, idx) => (
                    <tr key={idx} className="hover:bg-blue-50/30 transition">
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.subLotId}
                          onChange={(e) => handleUpdateSplitRow(idx, 'subLotId', e.target.value)}
                          className="w-24 font-mono font-bold text-xs bg-slate-50 border border-slate-300 rounded px-2 py-1"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <select
                          value={lot.qualityGrade || ''}
                          onChange={(e) => handleUpdateSplitRow(idx, 'qualityGrade', e.target.value)}
                          className="font-bold text-xs bg-white border border-slate-300 rounded px-2 py-1"
                        >
                          {STANDARD_QUALITY_CLASSES.map(c => (
                            <option key={c.key} value={c.key}>{c.key}</option>
                          ))}
                        </select>
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.variety || ''}
                          onChange={(e) => handleUpdateSplitRow(idx, 'variety', e.target.value)}
                          className="w-28 text-xs bg-white border border-slate-300 rounded px-2 py-1"
                          placeholder="Sort"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={lot.quantityKg}
                          onChange={(e) => handleUpdateSplitRow(idx, 'quantityKg', e.target.value)}
                          className="w-24 text-right font-mono font-black text-blue-900 bg-white border border-blue-300 rounded px-2 py-1 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          value={lot.caseCount ?? 0}
                          onChange={(e) => handleUpdateSplitRow(idx, 'caseCount', Number(e.target.value))}
                          className="w-16 text-right font-mono font-bold bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={lot.destination}
                          onChange={(e) => handleUpdateSplitRow(idx, 'destination', e.target.value)}
                          className="w-full text-xs bg-white border border-slate-300 rounded px-2 py-1"
                        />
                      </td>

                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteSplitRow(idx)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                          title="Satırı Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Add Split Lot Row Button */}
          {splitLots.length > 0 && (
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleAddSplitRow}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 text-xs font-bold transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Yeni Alt-Parti (Sub-Lot) Satırı Ekle</span>
              </button>

              <span className="text-xs text-slate-500">
                Toplam <strong>{splitLots.length}</strong> kalite sortu ve alt-parti tanımlandı.
              </span>
            </div>
          )}

        </div>

        {/* 4. SAHA GALERİ & YÜKLEME KANIT FOTOĞRAFLARI (FIELD & SHIPMENT VERIFICATION) */}
        <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-slate-800 text-white shadow-xs">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2 font-serif">
                  <span>Saha Galeri & Sevkiyat Kanıt Fotoğrafları</span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                    {photos.length + relatedBatchPhotos.length} Görsel
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Partiye ait hasat/bahçe fotoğrafları ve araca yükleme, paletleme, termo sensör ve mühür kanıtları
                </p>
              </div>
            </div>

            {onOpenGallery && (
              <button
                type="button"
                onClick={onOpenGallery}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold transition shadow-xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>🖼️ Saha Galerisine Git</span>
              </button>
            )}
          </div>

          {/* Related Batch Photos (from Harvest / Field Quality) */}
          {relatedBatchPhotos.length > 0 && (
            <div className="space-y-2 bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-200/80">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Seçili Referansa ({selectedRefId}) Ait Saha & Hasat Fotoğrafları ({relatedBatchPhotos.length})</span>
                </span>
                <span className="text-[10px] text-emerald-700 font-mono">Otomatik İlişkilendirildi</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-1">
                {relatedBatchPhotos.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => setPreviewPhotoUrl(item.url)}
                    className="group relative aspect-square rounded-lg overflow-hidden border border-emerald-300 bg-white shadow-2xs hover:shadow-md transition cursor-pointer"
                  >
                    <img
                      src={item.url}
                      alt={item.label}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition p-1.5 flex flex-col justify-end">
                      <span className="text-[10px] text-white font-bold truncate">{item.label}</span>
                      {item.date && <span className="text-[9px] text-emerald-200 font-mono">{item.date}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload New Shipment Verification Photos */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <UploadCloud className="w-4 h-4 text-blue-600" />
                <span>Bu Sevkiyata Özel Kanıt Fotoğrafları (Tır Yükleme, Frigorifik Mühür, Palet Kontrolü)</span>
              </label>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer bg-blue-600 hover:bg-blue-700 text-white disabled:bg-slate-200 disabled:text-slate-500"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{isCompressingPhoto ? 'İşleniyor...' : 'Fotoğraf Çek'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 disabled:bg-slate-100"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Galeriden Seç</span>
                </button>

                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={isCompressingPhoto}
                />

                <input
                  ref={galleryInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={isCompressingPhoto}
                />
              </div>
            </div>

            {/* Uploaded Photos Grid */}
            {photos.length === 0 ? (
              <div className="border border-dashed border-slate-300 rounded-xl p-4 text-center bg-white/60 text-xs text-slate-400">
                Henüz sevkiyat doğrulama fotoğrafı yüklenmedi. Yukarıdaki butona tıklayarak kamera veya galeriden ekleyebilirsiniz.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                {photos.map((url, idx) => (
                  <div
                    key={idx}
                    className="group relative aspect-square rounded-lg overflow-hidden border border-blue-200 bg-white shadow-2xs"
                  >
                    <img
                      src={url}
                      alt={`Sevkiyat Foto #${idx + 1}`}
                      className="w-full h-full object-cover cursor-pointer"
                      onClick={() => setPreviewPhotoUrl(url)}
                    />
                    <div className="absolute top-1 right-1 flex items-center gap-1 opacity-90 group-hover:opacity-100 transition">
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="p-1 rounded-md bg-rose-600/90 text-white hover:bg-rose-700 transition cursor-pointer shadow-xs"
                        title="Fotoğrafı Kaldır"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="absolute bottom-1 left-1 text-[9px] font-mono bg-slate-900/80 text-white px-1.5 py-0.5 rounded">
                      #{idx + 1}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Photo Preview Modal (Lightbox) */}
        {previewPhotoUrl && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
            onClick={() => setPreviewPhotoUrl(null)}
          >
            <div className="relative max-w-4xl max-h-[90vh] bg-slate-900 rounded-2xl overflow-hidden border border-slate-700 shadow-2xl p-2" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between pb-2 px-2 text-white text-xs">
                <span className="font-mono">Fotoğraf Detayı / Önizleme</span>
                <button
                  type="button"
                  onClick={() => setPreviewPhotoUrl(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <img
                src={previewPhotoUrl}
                alt="Büyük Önizleme"
                className="max-h-[80vh] w-auto mx-auto rounded-lg object-contain"
              />
            </div>
          </div>
        )}

        {/* Status & Notes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat Durumu *
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-800"
            >
              <option value="SHIPPED">SHIPPED (Yola Çıktı / Sevk Edildi)</option>
              <option value="IN_TRANSIT">IN_TRANSIT (Yolda / Transit)</option>
              <option value="DELIVERED">DELIVERED (Varış Noktasına Ulaştı)</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Sevkiyat / Delilnama Notları
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2"
              placeholder="Soğutma sensörleri, mühür numarası, rota talimatları..."
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition cursor-pointer"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-blue-700 hover:bg-blue-800 text-white shadow-md'} text-xs font-extrabold transition active:scale-95 cursor-pointer`}
          >
            <Save className="w-4 h-4" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'Delilnamayı Onayla & Sevkiyatı Başlat'}</span>
          </button>
        </div>
        </fieldset>

      </form>

      {/* PRINTABLE DELILNAMA PASSPORT MODAL (Baskılı Koçan Standardı) */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border-4 border-emerald-800 overflow-hidden my-8">
            
            {/* Modal Header */}
            <div className="bg-emerald-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-300" />
                <span className="font-serif font-bold text-sm tracking-wide">
                  TÜRKMENİSTAN AGROSENAGAT RESMİ HASAT DELİLNAMA KOÇANI
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Yazdır / PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="p-1 rounded-lg hover:bg-white/20 text-white transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Body */}
            <div className="p-8 space-y-6 text-slate-900 bg-white" id="printable-delilnama-certificate">
              
              {/* Certificate Title Banner */}
              <div className="text-center border-b-2 border-emerald-800 pb-4 space-y-1">
                <p className="text-[11px] uppercase tracking-widest text-emerald-900 font-bold">
                  TÜRKMENİSTANYŇ OBA HOJALYK WE DAŞKY GURŞAWY GORAMAK MINISTRLIGI
                </p>
                <h1 className="text-2xl font-black font-serif text-emerald-950 tracking-wider">
                  HASYL DELİLNAMA / HİL PASPORTY
                </h1>
                <p className="text-xs font-mono font-bold text-emerald-800">
                  Resmi Baskılı Koçan №: <strong>{delilnamaPassport.delilnamaNo}</strong>
                </p>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl border border-emerald-300 bg-emerald-50/40 text-xs">
                <div>
                  <span className="text-slate-500 font-bold block">Sene (Tarih):</span>
                  <span className="font-mono font-black text-slate-900">{delilnamaPassport.sene}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Ýeri (Lokasyon):</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.yeri}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Miwe (Meyve):</span>
                  <span className="font-black text-emerald-900">{delilnamaPassport.miwe}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Miwe Görnüşi (Çeşit):</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.miweGornusi}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Agaç Sany:</span>
                  <span className="font-mono font-bold text-slate-900">{delilnamaPassport.agacSany} düyp</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Gabyň Görnüşi:</span>
                  <span className="font-bold text-slate-900">{delilnamaPassport.gabynGornusi}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Ulag Belkisi (Plaka):</span>
                  <span className="font-mono font-black text-blue-900 uppercase">{vehiclePlate}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">Sürüji (Şoför):</span>
                  <span className="font-bold text-slate-900">{driver}</span>
                </div>
              </div>

              {/* Grades Table */}
              <div className="border border-emerald-800 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-emerald-900 text-white font-serif uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-2 px-3 border-r border-emerald-800">T/B</th>
                      <th className="py-2 px-3 border-r border-emerald-800">Hil Derejesi (Kalite Sınıfı)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Ýaşşikli Ýygylan (kg)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Hasyl Net (kg)</th>
                      <th className="py-2 px-3 text-right border-r border-emerald-800">Satyşa Berlen (kg)</th>
                      <th className="py-2 px-3 text-right">Gap Sany (san)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-200">
                    {delilnamaPassport.grades.map((g, i) => (
                      <tr key={i} className="odd:bg-white even:bg-emerald-50/30">
                        <td className="py-2 px-3 border-r border-emerald-200 font-mono text-center font-bold text-slate-600">
                          {i + 1}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 font-bold text-slate-900">
                          {g.gradeKey} {g.gradeLabelTr ? `(${g.gradeLabelTr})` : ''}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right font-mono">
                          {g.yassikliKg ?? 0}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right font-mono font-black text-emerald-950">
                          {g.hasylNetKg}
                        </td>
                        <td className="py-2 px-3 border-r border-emerald-200 text-right font-mono">
                          {g.satysaBerlenKg ?? g.hasylNetKg}
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold">
                          {g.gapSany ?? 0}
                        </td>
                      </tr>
                    ))}
                    {/* JEMI */}
                    <tr className="bg-emerald-100 font-black text-emerald-950 border-t-2 border-emerald-800">
                      <td colSpan={2} className="py-2 px-3 border-r border-emerald-800 uppercase font-serif tracking-wider">
                        JEMI (JEMİ HASAT NET):
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right font-mono">
                        {delilnamaSums.totalYassikli} kg
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right font-mono text-sm font-black">
                        {delilnamaSums.totalNet} kg
                      </td>
                      <td className="py-2 px-3 border-r border-emerald-800 text-right font-mono">
                        {delilnamaSums.totalSatysa} kg
                      </td>
                      <td className="py-2 px-3 text-right font-mono">
                        {delilnamaSums.totalGap} gap
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Signatures Section */}
              <div className="pt-6 border-t-2 border-emerald-800 grid grid-cols-3 gap-6 text-xs text-center">
                <div className="space-y-3">
                  <span className="font-serif font-bold text-slate-800 block">
                    ÖNDÜRİJİ (ÜRETİCİ)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="font-mono font-bold text-emerald-950">{delilnamaPassport.onduriji || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Möhür</span>
                </div>

                <div className="space-y-3">
                  <span className="font-serif font-bold text-slate-800 block">
                    HİLÇİ HÜNÄRMEN (KALİTE)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="font-mono font-bold text-emerald-950">{delilnamaPassport.hilciHunarmen || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Hil Barlag Möhür</span>
                </div>

                <div className="space-y-3">
                  <span className="font-serif font-bold text-slate-800 block">
                    SATUW HÜNÄRMEN (SATIŞ)
                  </span>
                  <div className="h-12 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                    <span className="font-mono font-bold text-emerald-950">{delilnamaPassport.satuwHunarmen || ''}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Gol (İmza) / Kabul Möhür</span>
                </div>
              </div>

              {/* Official Seal Mockup */}
              <div className="text-center pt-2 text-[10px] text-slate-400 font-mono">
                Agrosenagat Hil Gözegçiligi Standardy • ISO 22000 & HACCP Protokoly • Şahadatnama № 0002952
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowPrintModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition cursor-pointer"
              >
                Kapat
              </button>
            </div>

          </div>
        </div>
      )}

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
