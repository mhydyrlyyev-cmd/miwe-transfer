import React, { useState, useEffect, useRef } from 'react';
import { Warehouse, ArrowLeft, Save, Scale, Thermometer, Droplets, CheckCircle2, AlertTriangle, ShieldCheck, Wind, Camera, Image as ImageIcon, Info, Globe2, BookOpen } from 'lucide-react';
import { AmbarRecord, ReferenceItem } from '../../types';
import { calculateWarehouseFire, generateRefId } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { GostDefectMatrixWidget } from '../common/GostDefectMatrixWidget';
import { GostDefectInput, GostSpreadsheetMetadata, calculateGostDefects } from '../../utils/gostQualityCalculators';
import { IoTDataloggerConnector } from '../iot/IoTDataloggerConnector';
import { PhotoLightboxModal } from '../common/PhotoLightboxModal';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';

interface AmbarFormProps {
  onSave: (record: AmbarRecord, refId: string) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: AmbarRecord;
  isReadOnly?: boolean;
}

export const AmbarForm: React.FC<AmbarFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  isReadOnly = false
}) => {
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId || ''));
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Depo Kabul Uzmanı');

  // Selected reference context
  const selectedRef = existingRefs.find(r => r.refId === selectedRefId);

  // Form Fields
  const [acceptanceDate, setAcceptanceDate] = useState(initialRecord?.acceptanceDate || new Date().toISOString().split('T')[0]);
  const [warehouse, setWarehouse] = useState(initialRecord?.warehouse || 'Soğuk Hava Deposu A-1');
  const [roomNo, setRoomNo] = useState(initialRecord?.roomNo || 'Oda-01');
  const [treatmentApplied, setTreatmentApplied] = useState(initialRecord?.treatmentApplied || 'Ön Soğutma (Hydrocooling)');
  const [expectedWeightKg, setExpectedWeightKg] = useState<number>(initialRecord?.expectedWeightKg ?? (selectedRef?.quantity || 4500));
  const [acceptedWeightKg, setAcceptedWeightKg] = useState<number>(initialRecord?.acceptedWeightKg ?? (selectedRef ? Math.round(selectedRef.quantity * 0.995) : 4475));
  // v2.2: ölçümler önceden doldurulmaz — boş alan "ölçülmedi" demektir
  const [productTemperature, setProductTemperature] = useState<number | null>(initialRecord?.productTemperature ?? null);
  const [roomTemperature, setRoomTemperature] = useState<number | null>(initialRecord?.roomTemperature ?? null);
  const [humidityPercent, setHumidityPercent] = useState<number | null>(initialRecord?.humidityPercent ?? null);
  const [co2GasLevelPpm, setCo2GasLevelPpm] = useState<number>(initialRecord?.co2GasLevelPpm ?? 450);
  const [packaging, setPackaging] = useState(initialRecord?.packaging || 'Plastik Kasa (IFCO)');
  const [acceptanceStatus, setAcceptanceStatus] = useState<'ACCEPTED' | 'PARTIAL' | 'REJECTED'>(initialRecord?.acceptanceStatus || 'ACCEPTED');
  const [hygieneStatus, setHygieneStatus] = useState<'Uygun' | 'Uygun Değil'>(initialRecord?.hygieneStatus || 'Uygun');
  const [coldChainStatus, setColdChainStatus] = useState<'Uygun' | 'Kritik Sapma' | 'Uygun Değil'>(initialRecord?.coldChainStatus || 'Uygun');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || 'EXTRA (V-20)');
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>(initialRecord?.testStatus || 'COMPLETED');
  const [nextStep, setNextStep] = useState(initialRecord?.nextStep || 'Lojistik / Sevkiyat Hazırlık');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [photos, setPhotos] = useState<string[]>(
    initialRecord?.photos && initialRecord.photos.length > 0
      ? initialRecord.photos
      : []
  );
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);

  // Update when selected Ref changes
  useEffect(() => {
    if (selectedRef) {
      if (selectedRef.quantity) {
        setExpectedWeightKg(selectedRef.quantity);
        setAcceptedWeightKg(Math.round(selectedRef.quantity * 0.995));
      }
    }
  }, [selectedRefId]);

  // Inbound Type & GOST States
  const [inboundType, setInboundType] = useState<'DOMESTIC' | 'IMPORT_EURASIA_GOST' | 'IMPORT_OTHER'>(
    initialRecord?.inboundType || 'DOMESTIC'
  );

  const [gostDefects, setGostDefects] = useState<GostDefectInput>({
    sampleBoxCount: initialRecord?.sampleBoxCount || 16,
    sampleWeightKg: initialRecord?.sampleWeightKg || 58.28,
    internalRotNecrosisKg: initialRecord?.internalRotNecrosisKg || 0,
    obviousRotTheRotIsObviousKg: initialRecord?.obviousRotTheRotIsObviousKg || 0,
    mechanicsKg: initialRecord?.mechanicsKg || 0,
    dilutionTopKg: initialRecord?.dilutionTopKg || 0,
    easyDeformationKg: initialRecord?.easyDeformationKg || 0,
    productName: selectedRef?.product || 'Şeftali'
  });

  const [gostMetadata, setGostMetadata] = useState<GostSpreadsheetMetadata>({
    docTemperature: initialRecord?.docTemperature || '',
    coolingUnitTemperature: initialRecord?.coolingUnitTemperature || '',
    actualTemperature: initialRecord?.actualTemperature || '',
    supplier: initialRecord?.supplier || selectedRef?.source || '',
    transportType: initialRecord?.transportType || 'CPT Frigo Tır',
    batchNumber: initialRecord?.batchNumber || selectedRef?.refId || '',
    category: initialRecord?.category || '1',
    palletCount: initialRecord?.palletCount || 1,
    expertName: initialRecord?.expertName || operator,
    testDate: acceptanceDate
  });

  // Live Fire calculation
  const { diffKg, diffPercent } = calculateWarehouseFire(expectedWeightKg, acceptedWeightKg);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setPhotos(prev => [...prev, event.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
      e.target.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (productTemperature === null || roomTemperature === null || humidityPercent === null) {
      window.alert('Ürün iç sıcaklığı, oda sıcaklığı ve bağıl nem ölçülüp girilmeden kabul kaydı oluşturulamaz.');
      return;
    }
    
    let finalRefId = selectedRefId.trim() || initialRecord?.refId || '';
    if (!finalRefId) {
      finalRefId = generateRefId('AMBAR', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Depo Kabul Uzmanı';
    const gostMetrics = calculateGostDefects(gostDefects);

    const ambarRecord: AmbarRecord = {
      id: initialRecord?.id || `a-${Date.now()}`,
      refId: finalRefId,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      acceptanceDate,
      warehouse: warehouse.trim() || 'Soğuk Hava Deposu A-1',
      roomNo: roomNo.trim() || 'Oda-01',
      treatmentApplied: treatmentApplied.trim() || 'Standart Depolama',
      expectedWeightKg,
      acceptedWeightKg,
      weightDiffKg: diffKg,
      weightDiffPercent: diffPercent,
      productTemperature: productTemperature as number,
      roomTemperature: roomTemperature as number,
      humidityPercent: humidityPercent as number,
      co2GasLevelPpm,
      packaging: packaging.trim() || 'Standart Kasa',
      acceptanceStatus: (inboundType === 'IMPORT_EURASIA_GOST' && gostMetrics.decision === 'REJECTED_INCIDENT') ? 'REJECTED' : acceptanceStatus,
      hygieneStatus,
      coldChainStatus,
      kaliteSinifi,
      testStatus,
      nextStep: nextStep.trim() || 'Sevkiyat Hazırlık',
      notes,
      photos,

      // GOST & Inbound Fields
      inboundType,
      docTemperature: gostMetadata.docTemperature,
      coolingUnitTemperature: gostMetadata.coolingUnitTemperature,
      actualTemperature: gostMetadata.actualTemperature,
      supplier: gostMetadata.supplier,
      transportType: gostMetadata.transportType,
      batchNumber: gostMetadata.batchNumber,
      category: gostMetadata.category,
      palletCount: Number(gostMetadata.palletCount) || undefined,
      sampleBoxCount: gostDefects.sampleBoxCount,
      sampleWeightKg: gostDefects.sampleWeightKg,
      samplePercent: gostMetrics.samplePercent,
      wastePercent: gostMetrics.wastePercent,
      rotKg: gostMetrics.rotKg,
      rotPercent: gostMetrics.rotPercent,
      internalRotNecrosisKg: gostDefects.internalRotNecrosisKg,
      internalRotNecrosisPercent: gostMetrics.internalRotNecrosisPercent,
      obviousRotTheRotIsObviousKg: gostDefects.obviousRotTheRotIsObviousKg,
      obviousRotTheRotIsObviousPercent: gostMetrics.obviousRotTheRotIsObviousPercent,
      nonStandardKg: gostMetrics.nonStandardKg,
      nonStandardPercent: gostMetrics.nonStandardPercent,
      mechanicsKg: gostDefects.mechanicsKg,
      mechanicsPercent: gostMetrics.mechanicsPercent,
      dilutionTopKg: gostDefects.dilutionTopKg,
      dilutionTopPercent: gostMetrics.dilutionTopPercent,
      easyDeformationKg: gostDefects.easyDeformationKg,
      easyDeformationPercent: gostMetrics.easyDeformationPercent,
      expertName: gostMetadata.expertName,
      gostDecision: gostMetrics.decision
    };

    onSave(ambarRecord, finalRefId);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-[#0f4a33] text-white px-6 py-4 flex items-center justify-between border-b border-emerald-950">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
            <Warehouse className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                🏭 Ambar Kabul, Oda Takibi & Soğuk Zincir Modülü
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-900 text-emerald-300 border border-emerald-700">
                Datly Miwe • Depolama
              </span>
            </div>
            <p className="text-xs text-emerald-200/80">
              Kantar tartımı, fire hesabı, oda/ürün sıcaklığı, atmosfer ve uygulama takibi
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-1.5 text-xs font-semibold text-emerald-100 hover:text-white bg-emerald-900/60 hover:bg-emerald-900 px-3 py-1.5 rounded-lg border border-emerald-700 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Hızlı Yardımcı Notlar & Standartlar Kutusu */}
        <div className="bg-emerald-50/90 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-emerald-900">
            <Info className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>💡 Ambar & Soğuk Hava Deposu Rehberi (Kritik Eşikler):</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px] text-emerald-900/90 leading-relaxed">
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Sıcaklık Yönetimi:</strong> Muz ön soğutma 13.5°C - 14.5°C; Badem/Kuru depo 15°C - 18°C; Şoklama -35°C altında tutulmalıdır.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Kantar & Fire Toleransı:</strong> Giriş kantar farkı maksimum ±%1.5 olmalıdır. %2 üzeri sapmalarda fire tutanağı tutulur.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-emerald-200/60">
              <strong>Etilen & Gaz Seviyesi:</strong> Muz depolama odalarında etilen &lt;1 ppm, CO2 seviyesi &lt;5000 ppm olmalıdır.
            </div>
          </div>
        </div>

        {/* Selected Reference Selector */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1">
              Kabulü / Oda Kontrolü Yapılacak Referans (RefID Seçin veya Yazın)
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                list="ambar-ref-list"
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                placeholder="Örn: REF-101 veya listeden seçin..."
                className="w-full md:w-96 text-xs font-mono font-bold bg-white border border-emerald-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="ambar-ref-list">
                {existingRefs.map(r => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} — {r.product} [{r.quantity} {r.unit}] - {r.status}
                  </option>
                ))}
              </datalist>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 block">Seçili Referans Ürünü</span>
              <strong className="text-slate-800">{selectedRef?.product || ''}</strong>
            </div>
            <div className="bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 block">Kayıtlı Miktar</span>
              <strong className="font-mono text-emerald-800">{selectedRef?.quantity || 0} {selectedRef?.unit || ''}</strong>
            </div>
          </div>
        </div>

        {/* Inbound Origin & Inspection Mode Selector */}
        <div className="bg-slate-100 p-2 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 px-2 text-xs font-bold text-slate-700">
            <Globe2 className="w-4 h-4 text-teal-600" />
            <span>Kabul Kaynağı &amp; Denetim Standardı:</span>
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setInboundType('DOMESTIC')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                inboundType === 'DOMESTIC'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🚚 Yurtiçi Standart Ambar Kabulü</span>
            </button>

            <button
              type="button"
              onClick={() => setInboundType('IMPORT_EURASIA_GOST')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                inboundType === 'IMPORT_EURASIA_GOST'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🇷🇺 Yurtdışı / İthalat Kabulü (GOST &amp; Avrasya Matrisi)</span>
            </button>
          </div>
        </div>

        {/* If Inbound GOST is active, render GostDefectMatrixWidget */}
        {inboundType === 'IMPORT_EURASIA_GOST' && (
          <div className="p-4 bg-amber-50/30 rounded-2xl border-2 border-amber-300 shadow-xs space-y-3">
            <GostDefectMatrixWidget
              defects={gostDefects}
              onChangeDefects={(upd) => setGostDefects(upd)}
              metadata={gostMetadata}
              onChangeMetadata={(upd) => setGostMetadata(upd)}
              productName={selectedRef?.product || 'Şeftali'}
            />
          </div>
        )}

        {/* General Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Operatör Adı *
            </label>
            <input
              type="text"
              list="operators-list"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
              placeholder="Adınızı giriniz"
             
              className="w-full text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            <datalist id="operators-list">
              {AUTOCOMPLETE_LISTS.operators.map(op => (
                <option key={op} value={op} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Kabul / Kontrol Tarihi
            </label>
            <input
              type="date"
              value={acceptanceDate}
              onChange={(e) => setAcceptanceDate(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Ambar / Depo Tesisi
            </label>
            <input
              type="text"
              list="warehouses-list"
              value={warehouse}
              onChange={(e) => setWarehouse(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="warehouses-list">
              {AUTOCOMPLETE_LISTS.warehouses.map(w => (
                <option key={w} value={w} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Hangi Oda / Hücre (Yerleşim)
            </label>
            <input
              type="text"
              list="rooms-list"
              value={roomNo}
              onChange={(e) => setRoomNo(e.target.value)}
              placeholder="Oda No giriniz veya seçiniz"
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="rooms-list">
              <option value="Oda 1 (Sowuk Depo - 1.0°C)" />
              <option value="Oda 2 (Ön Soğutma - 2.0°C)" />
              <option value="Oda 3 (Atmosfer Kontrollü CA - 0.5°C)" />
              <option value="Muz Olgunlaştırma / Gazlama Odası (14.0°C)" />
              <option value="Kuru Depo 1 (Badem İklimlendirme)" />
            </datalist>
          </div>
        </div>

        {/* Yapılan Uygulama & İklimlendirme */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Yapılan Uygulama / İşlem (Seçiniz veya yazınız)
            </label>
            <input
              type="text"
              list="treatments-list"
              value={treatmentApplied}
              onChange={(e) => setTreatmentApplied(e.target.value)}
              placeholder="Örn. Ön Soğutma, 1-MCP, Ozonlama..."
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
            <datalist id="treatments-list">
              <option value="Ön Soğutma (Hydrocooling / Zorlamalı Hava)" />
              <option value="1-MCP SmartFresh Uygulaması (Etilen Blokajı)" />
              <option value="Ozonlama & Sterilizasyon" />
              <option value="Etilen Gazlama (Muz Olgunlaştırma)" />
              <option value="Fümigasyon & İlaçlama" />
              <option value="Standart Soğuk Muhafaza (0-2°C)" />
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Ambalaj & Palet Durumu
            </label>
            <input
              type="text"
              value={packaging}
              onChange={(e) => setPackaging(e.target.value)}
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Tartım, Fire & Sıcaklık / Nem Metrikleri */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Scale className="w-4 h-4 text-emerald-700" />
              <span>Kantar Tartımı, Fire & İklim Sensör Değerleri</span>
            </h3>
            <button
              type="button"
              onClick={() => setActivePublicationModal(MDPI_ARTICLES.TEMPERATURE_METABOLISM)}
              className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-900 hover:bg-blue-500/30 text-[10px] font-mono font-bold border border-blue-400/40 transition cursor-pointer flex items-center gap-1"
              title="Horticulturae (Temmuz 2026) Sıcaklık & Hücre Duvarı Metabolizması Makale Atıfı"
            >
              <BookOpen className="w-3 h-3 text-blue-700 shrink-0" />
              <span>[Horticulturae 2026]</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                İrsaliye / Beklenen Ağırlık (kg)
              </label>
              <input
                type="number"
                value={expectedWeightKg}
                onChange={(e) => setExpectedWeightKg(parseFloat(e.target.value) || 0)}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Fiili Kabul Edilen Ağırlık (kg)
              </label>
              <input
                type="number"
                value={acceptedWeightKg}
                onChange={(e) => setAcceptedWeightKg(parseFloat(e.target.value) || 0)}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Ürün İç Sıcaklığı (°C)
              </label>
              <input
                type="number"
                step="0.1"
                value={productTemperature ?? ''}
                placeholder="ölçülmedi"
                onChange={(e) => setProductTemperature(e.target.value === '' ? null : parseFloat(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Oda Sıcaklığı / Nem (% / °C)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  step="0.1"
                  value={roomTemperature ?? ''}
                  onChange={(e) => setRoomTemperature(e.target.value === '' ? null : parseFloat(e.target.value))}
                  placeholder="°C"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="number"
                  value={humidityPercent ?? ''}
                  onChange={(e) => setHumidityPercent(e.target.value === '' ? null : parseFloat(e.target.value))}
                  placeholder="%"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2 py-2 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Gerçek Zamanlı Soğuk Depo IoT Sensör & Datalogger Bağlantısı (İsteğe Bağlı) */}
          <div className="pt-2">
            <IoTDataloggerConnector
              moduleName="AMBAR"
              targetTempMin={0.5}
              targetTempMax={2.5}
              onTelemetryUpdate={(data) => {
                if (data) {
                  setRoomTemperature(data.temperatureC);
                  setHumidityPercent(Math.round(data.humidityPercent));
                  setColdChainStatus(data.isBreached ? 'Kritik Sapma' : 'Uygun');
                }
              }}
            />
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-600">Hesaplanan Fire / Fark:</span>
              <strong className={`font-mono text-sm ${diffKg > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                {diffKg.toFixed(1)} kg (%{diffPercent.toFixed(2)})
              </strong>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-slate-600">Soğuk Zincir Uygunluğu:</span>
              <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                coldChainStatus === 'Uygun' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {coldChainStatus}
              </span>
            </div>
          </div>
        </div>

        {/* Karar, Sonraki Adım & Durum */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Kabul / Muayene Kararı
              </label>
              <select
                value={acceptanceStatus}
                onChange={(e) => setAcceptanceStatus(e.target.value as any)}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="ACCEPTED">Tam Kabul Edildi (Stoklandı)</option>
                <option value="PARTIAL">Şartlı / Kısmi Kabul</option>
                <option value="REJECTED">Red / İade / Karantina</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Sonraki Adım (Seçiniz veya yazınız)
              </label>
              <input
                type="text"
                list="ambar-next-steps"
                value={nextStep}
                onChange={(e) => setNextStep(e.target.value)}
                placeholder="Seçiniz veya yazınız"
               
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="ambar-next-steps">
                <option value="Soğuk Muhafaza & Sevkiyat Planlama" />
                <option value="Gazlama Odasına Transfer" />
                <option value="Boylama & Paketleme Hattına Sevk" />
                <option value="İhracat Yüklemesine Sevk" />
                <option value="Karantina / Numune İnceleme" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Referans İşlem Durumu
              </label>
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setTestStatus('ACTIVE')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'ACTIVE'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Aktif (İşlemde)
                </button>
                <button
                  type="button"
                  onClick={() => setTestStatus('COMPLETED')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'COMPLETED'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Tamamlandı
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Notlar */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Notlar & Depo Gözlemleri
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Kasa durumu, palet şeritleri, forklift istifleme notları..."
            className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-3 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        {/* Fotoğraf Ekle */}
        <div className="border-t border-slate-200 pt-4">
          <label className="block text-xs font-bold text-slate-700 mb-2">
            Fotoğraf / Kantar Fişi Dosyası Ekle
          </label>
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* 1. Kamera Butonu */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer transition shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Fotoğraf Çek</span>
            </button>

            {/* 2. Galeri Butonu */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition shadow-2xs"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>Galeriden Seç</span>
            </button>

            {/* Gizli Kamera Girişi */}
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleAddPhoto}
              className="hidden"
            />

            {/* Gizli Galeri Girişi (multiple destekli) */}
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleAddPhoto}
              className="hidden"
            />

            {photos.filter(p => p && p.length > 20).map((p, idx) => (
              <div
                key={idx}
                onClick={() => setLightboxIndex(idx)}
                className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-300 shadow-sm group cursor-pointer hover:border-emerald-500 transition"
                title="Tam ekran önizlemek veya silmek için dokunun"
              >
                <img src={p} alt={`Ambar Foto ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1">
                  <span className="p-1 bg-white text-slate-800 rounded-md text-[10px] font-bold">Önizle</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition cursor-pointer`}
          >
            <Save className="w-4 h-4" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'KAYDET VE İLERLET'}</span>
          </button>
        </div>
        </fieldset>

      </form>

      {/* Full-Screen Photo Lightbox Modal */}
      <PhotoLightboxModal
        isOpen={lightboxIndex !== null}
        photoUrl={lightboxIndex !== null ? photos[lightboxIndex] : null}
        photoIndex={lightboxIndex ?? 0}
        totalPhotos={photos.length}
        title={`Ambar Kabul Fotoğrafı #${(lightboxIndex ?? 0) + 1}`}
        onClose={() => setLightboxIndex(null)}
        onDelete={(idx) => {
          setPhotos(prev => prev.filter((_, i) => i !== idx));
          if (photos.length <= 1) {
            setLightboxIndex(null);
          } else if (idx >= photos.length - 1) {
            setLightboxIndex(Math.max(0, photos.length - 2));
          }
        }}
        onPrev={lightboxIndex !== null && lightboxIndex > 0 ? () => setLightboxIndex(prev => (prev !== null ? prev - 1 : 0)) : undefined}
        onNext={lightboxIndex !== null && lightboxIndex < photos.length - 1 ? () => setLightboxIndex(prev => (prev !== null ? prev + 1 : 0)) : undefined}
      />

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
