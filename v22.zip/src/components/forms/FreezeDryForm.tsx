import React, { useState, useEffect, useRef } from 'react';
import {
  Snowflake,
  ArrowLeft,
  Save,
  Camera,
  Image as ImageIcon,
  Upload,
  Layers,
  Thermometer,
  Gauge,
  Clock,
  PackageCheck,
  TrendingDown,
  Trash2,
  Plus,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  Flame,
  CheckCircle2,
  Wind,
  Info,
  Lock,
  Unlock,
  KeyRound,
  RotateCcw,
  CheckCheck
} from 'lucide-react';
import { FreezeDryRecord, ReferenceItem, FieldRecord, HarvestRecord, BademRecord, SplitLotItem } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { generateRefId } from '../../utils/calculations';

interface FreezeDryFormProps {
  onSave: (record: FreezeDryRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: FreezeDryRecord;
  fieldRecords?: FieldRecord[];
  harvestRecords?: HarvestRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  bademRecords?: BademRecord[];
  isReadOnly?: boolean;
}

export const FreezeDryForm: React.FC<FreezeDryFormProps> = ({
  onSave,
  onCancel,
  existingRefs = [],
  initialRefId,
  initialRecord,
  fieldRecords = [],
  harvestRecords = [],
  freezeDryRecords = [],
  bademRecords = [],
  isReadOnly = false
}) => {
  const [isNewRef, setIsNewRef] = useState<boolean>(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState<string>(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId ?? 'FD-REF-01'));

  // Section Lock / Unlock States (prevents re-entering completed/tested data)
  const [isTestLocked, setIsTestLocked] = useState<boolean>(!initialRecord);
  const [isShockLocked, setIsShockLocked] = useState<boolean>(false);
  const [isDryingLocked, setIsDryingLocked] = useState<boolean>(false);

  // Custom new Ref
  const [customRefId, setCustomRefId] = useState<string>(() => {
    if (initialRecord?.refId) return initialRecord.refId;
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    return `FD-${today}-${rand}`;
  });

  // Basic Info
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || 'Liyofilizasyon Proses Uzmanı');
  const [processDate, setProcessDate] = useState(initialRecord?.processDate || new Date().toISOString().slice(0, 10));
  const [product, setProduct] = useState(initialRecord?.product || 'Şeftali (Freeze-Dry Dilim)');
  const [variety, setVariety] = useState(initialRecord?.variety || 'Extreme 314');
  const [rawMaterialSource, setRawMaterialSource] = useState(initialRecord?.rawMaterialSource || 'Saha Standart Dışı Seçim');
  const [rawWeightKg, setRawWeightKg] = useState<number>(initialRecord?.rawWeightKg ?? 0);

  // 1. Hammadde & Giriş Testi
  const [rawBrix, setRawBrix] = useState<number>(14.2);
  const [rawMoisturePercent, setRawMoisturePercent] = useState<number>(86.5);
  const [sortingWasteKg, setSortingWasteKg] = useState<number>(110);
  const [sliceThicknessMm, setSliceThicknessMm] = useState<number>(6);

  // 2. Şok Dondurma (-40°C)
  const [shockFreezerRoom, setShockFreezerRoom] = useState('');
  const [shockFreezerTempC, setShockFreezerTempC] = useState<number>(-41.5);
  const [coreTemperatureC, setCoreTemperatureC] = useState<number>(-38.5);
  const [shockDurationHours, setShockDurationHours] = useState<number>(4.5);
  const [shockStatus, setShockStatus] = useState<'COMPLETED' | 'IN_PROGRESS' | 'PENDING'>('COMPLETED');

  // 3. Ara / Donuk Depolama (-25°C)
  const [frozenStorageRoom, setFrozenStorageRoom] = useState('');
  const [frozenStorageTempC, setFrozenStorageTempC] = useState<number>(-25.8);
  const [frozenStoragePalletNo, setFrozenStoragePalletNo] = useState('');
  const [frozenStorageDays, setFrozenStorageDays] = useState<number>(1);

  // 4. Liyofilizasyon Kabini (Kurutma)
  const [dryerChamberNo, setDryerChamberNo] = useState('');
  const [trayCount, setTrayCount] = useState<number>(48);
  const [vacuumPressureMbar, setVacuumPressureMbar] = useState<number>(0.18);
  const [sublimationTimeHours, setSublimationTimeHours] = useState<number>(20.5);
  const [finalDryWeightKg, setFinalDryWeightKg] = useState<number>(104);
  const [finalMoisturePercent, setFinalMoisturePercent] = useState<number>(2.1);
  const [crunchinessTexture, setCrunchinessTexture] = useState<'Gevrek / Çıtır' | 'Yumuşak (Eksik Kuruma)' | 'Kırılgan / Toz'>('Gevrek / Çıtır');

  // 5. Paketleme & Ambalajlama
  const [packagingType, setPackagingType] = useState('');
  const [packageGram, setPackageGram] = useState<number>(30);
  const [nitrogenFlushed, setNitrogenFlushed] = useState<boolean>(true);
  const [lotNo, setLotNo] = useState(() => {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return `LOT-FD-${today}-SH1`;
  });
  const [expiryDate, setExpiryDate] = useState(() => {
    const d = new Date();
    d.setFullYear(d.getFullYear() + 2);
    return d.toISOString().slice(0, 10);
  });
  const [processStatus, setProcessStatus] = useState<'RAW_ACCEPTED' | 'SHOCKED_40C' | 'STORED_25C' | 'DRYING' | 'PACKAGED' | 'COMPLETED'>('COMPLETED');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>('EXTRA (V-20)');
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>([]);
  const [notes, setNotes] = useState('');

  // Photo uploads (Cold-Start: no sample photos)
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);
  const [isDragging, setIsDragging] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Matched records from system
  const activeRefId = isNewRef ? customRefId : selectedRefId;
  const matchedFieldRecord = !isNewRef && selectedRefId ? fieldRecords.find(f => f.refId === selectedRefId) : undefined;
  const matchedHarvestRecord = !isNewRef && selectedRefId ? harvestRecords.find(h => h.refId === selectedRefId) : undefined;
  const matchedRef = !isNewRef && selectedRefId ? existingRefs.find(r => r.refId === selectedRefId) : undefined;
  const matchedExistingFd = !isNewRef && selectedRefId ? freezeDryRecords.find(fd => fd.refId === selectedRefId) : undefined;

  // Auto-fill and lock when selecting an existing reference
  const populateFromSelectedRef = (refId: string) => {
    if (!refId) return;
    const fRec = fieldRecords.find(f => f.refId === refId);
    const hRec = harvestRecords.find(h => h.refId === refId);
    const bRec = bademRecords.find(b => b.refId === refId);
    const rItem = existingRefs.find(r => r.refId === refId);
    const fdRec = freezeDryRecords.find(fd => fd.refId === refId);

    if (fdRec) {
      setOperator(fdRec.operator || operator);
      setProcessDate(fdRec.processDate || processDate);
      setProduct(fdRec.product || product);
      setVariety(fdRec.variety || variety);
      setRawMaterialSource(fdRec.rawMaterialSource || rawMaterialSource);
      setRawWeightKg(fdRec.rawWeightKg || rawWeightKg);
      setRawBrix(fdRec.rawBrix ?? rawBrix);
      setRawMoisturePercent(fdRec.rawMoisturePercent ?? rawMoisturePercent);
      setSortingWasteKg(fdRec.sortingWasteKg ?? sortingWasteKg);
      setSliceThicknessMm(fdRec.sliceThicknessMm ?? sliceThicknessMm);
      setShockFreezerRoom(fdRec.shockFreezerRoom || shockFreezerRoom);
      setShockFreezerTempC(fdRec.shockFreezerTempC ?? shockFreezerTempC);
      setCoreTemperatureC(fdRec.coreTemperatureC ?? coreTemperatureC);
      setShockDurationHours(fdRec.shockDurationHours ?? shockDurationHours);
      setShockStatus(fdRec.shockStatus || shockStatus);
      setFrozenStorageRoom(fdRec.frozenStorageRoom || frozenStorageRoom);
      setFrozenStorageTempC(fdRec.frozenStorageTempC ?? frozenStorageTempC);
      setFrozenStoragePalletNo(fdRec.frozenStoragePalletNo || frozenStoragePalletNo);
      setFrozenStorageDays(fdRec.frozenStorageDays ?? frozenStorageDays);
      setDryerChamberNo(fdRec.dryerChamberNo || dryerChamberNo);
      setTrayCount(fdRec.trayCount ?? trayCount);
      setVacuumPressureMbar(fdRec.vacuumPressureMbar ?? vacuumPressureMbar);
      setSublimationTimeHours(fdRec.sublimationTimeHours ?? sublimationTimeHours);
      setFinalDryWeightKg(fdRec.finalDryWeightKg ?? finalDryWeightKg);
      setFinalMoisturePercent(fdRec.finalMoisturePercent ?? finalMoisturePercent);
      setCrunchinessTexture(fdRec.crunchinessTexture || crunchinessTexture);
      setPackagingType(fdRec.packagingType || packagingType);
      setPackageGram(fdRec.packageGram ?? packageGram);
      setNitrogenFlushed(fdRec.nitrogenFlushed ?? nitrogenFlushed);
      setLotNo(fdRec.lotNo || lotNo);
      setExpiryDate(fdRec.expiryDate || expiryDate);
      setProcessStatus(fdRec.processStatus || processStatus);
      setNotes(fdRec.notes || notes);
      if (fdRec.photos && fdRec.photos.length > 0) {
        setPhotos(fdRec.photos);
      }
      setIsTestLocked(true);
      setIsShockLocked(fdRec.shockStatus === 'COMPLETED');
      setIsDryingLocked(fdRec.finalDryWeightKg > 0);
    } else if (bRec) {
      setProduct(`Badem (Erem™ Freeze-Dry / Kaplama)`);
      setVariety(bRec.variety || '');
      if (bRec.totalLoadKg && bRec.totalLoadKg > 0) {
        setRawWeightKg(bRec.totalLoadKg);
      } else if (bRec.kernelGram) {
        setRawWeightKg(bRec.kernelGram * 10);
      }
      if (bRec.kernelMoisturePercent || bRec.moisturePercent) {
        setRawMoisturePercent(bRec.kernelMoisturePercent || bRec.moisturePercent || 5.2);
      }
      setRawMaterialSource(`Miweli Atyz Badem Sahası (${bRec.location || ''}) • Sınıf: ${bRec.classification || ''}`);
      if (bRec.photos && bRec.photos.length > 0) {
        setPhotos(prev => {
          const combined = [...bRec.photos!, ...prev];
          return Array.from(new Set(combined)).slice(0, 8);
        });
      }
      setIsTestLocked(true);
    } else if (fRec || rItem || hRec) {
      if (rItem?.product) {
        setProduct(`${rItem.product} (Freeze-Dry Dilim)`);
      } else if (fRec?.product) {
        setProduct(`${fRec.product} (Freeze-Dry Dilim)`);
      }

      if (fRec?.sortVariety) {
        setVariety(fRec.sortVariety);
      }

      if (fRec?.avgBrix && fRec.avgBrix > 0) {
        setRawBrix(Number(fRec.avgBrix.toFixed(1)));
      }

      if (rItem?.quantity && rItem.quantity > 0) {
        setRawWeightKg(rItem.quantity);
      } else if (hRec?.dailyTotalKg && hRec.dailyTotalKg > 0) {
        setRawWeightKg(hRec.dailyTotalKg);
      }

      if (fRec?.rejectionReason) {
        setRawMaterialSource(`Saha Standart Dışı Seçim (${fRec.orchard || ''} - ${fRec.rejectionReason})`);
      } else if (fRec?.orchard) {
        setRawMaterialSource(`Saha Standart Dışı Seçim (${fRec.orchard})`);
      }

      if (fRec?.photos && fRec.photos.length > 0) {
        setPhotos(prev => {
          const combined = [...fRec.photos!, ...prev];
          return Array.from(new Set(combined)).slice(0, 8);
        });
      }

      // Lock test data so operator doesn't need to re-type
      setIsTestLocked(true);
    }
  };

  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      populateFromSelectedRef(selectedRefId);
    }
  }, [isNewRef, selectedRefId]);

  const handleResetToFieldTest = () => {
    if (selectedRefId) {
      populateFromSelectedRef(selectedRefId);
      setIsTestLocked(true);
    }
  };

  // Derived Calculations
  const usableRawWeightKg = Math.max(0, rawWeightKg - sortingWasteKg);
  const yieldRatioPercent = rawWeightKg > 0 ? Number(((finalDryWeightKg / rawWeightKg) * 100).toFixed(2)) : 0;
  const calculatedTotalPackages = packageGram > 0 ? Math.floor((finalDryWeightKg * 1000) / packageGram) : 0;

  // File Upload Handlers
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
      e.target.value = '';
    }
  };

  const processFiles = (files: File[]) => {
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const addPresetPhoto = (url: string) => {
    setPhotos(prev => [...prev, url]);
  };

  // Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let effectiveRefId = isNewRef ? customRefId.trim() : (selectedRefId.trim() || initialRecord?.refId || '');
    if (!effectiveRefId) {
      effectiveRefId = customRefId.trim() || generateRefId('FREEZE_DRY', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Liyofilizasyon Proses Uzmanı';
    const finalProduct = product.trim() || 'Şeftali (Freeze-Dry Dilim)';

    const record: FreezeDryRecord = {
      id: initialRecord?.id || matchedExistingFd?.id || `fd-${Date.now()}`,
      refId: effectiveRefId,
      timestamp: new Date().toISOString(),
      operator: finalOperator,
      processDate,
      product: finalProduct,
      variety: variety.trim() || 'Extreme 314',
      rawMaterialSource: rawMaterialSource.trim() || 'Saha Standart Dışı Seçim',
      rawWeightKg,
      rawBrix,
      rawMoisturePercent,
      sortingWasteKg,
      usableRawWeightKg,
      sliceThicknessMm,
      shockFreezerRoom,
      shockFreezerTempC,
      coreTemperatureC,
      shockDurationHours,
      shockStatus,
      frozenStorageRoom,
      frozenStorageTempC,
      frozenStoragePalletNo,
      frozenStorageDays,
      dryerChamberNo,
      trayCount,
      vacuumPressureMbar,
      sublimationTimeHours,
      finalDryWeightKg,
      finalMoisturePercent,
      yieldRatioPercent,
      crunchinessTexture,
      packagingType,
      packageGram,
      totalPackagesProduced: calculatedTotalPackages,
      nitrogenFlushed,
      lotNo,
      expiryDate,
      processStatus,
      kaliteSinifi,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      notes,
      photos
    };

    onSave(record, isNewRef, isNewRef ? {
      product,
      location: 'Erem™ Liyofilizasyon & Freeze-Dry Tesisi',
      destination: '-25°C Donuk Depo / Paketleme Hattı',
      quantity: rawWeightKg,
      unit: 'kg',
      notes: `Freeze-Dry İşlemi: ${rawWeightKg} kg yaş hammadde ➔ -40°C Şoklama ➔ ${finalDryWeightKg} kg kuru ürün (%${yieldRatioPercent} randıman, ${calculatedTotalPackages} paket).`
    } : undefined);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-950 via-slate-900 to-indigo-950 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-sky-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-sky-500/20 border border-sky-400/30 text-sky-300 shrink-0">
            <Snowflake className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-extrabold tracking-wide text-white">
                FREEZE-DRY & LİYOFİLİZASYON İŞLEME MODÜLÜ
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-black uppercase bg-sky-400 text-slate-950">
                -40°C Şoklama • -25°C Donuk Depo • Erem™
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-sky-200/80 line-clamp-2 sm:line-clamp-none">
              Standart dışı lezzetli meyvelerin kabulü, dilimleme, -40°C şoklama, -25°C muhafaza, süblimasyon ve azotlu paketleme kütüğü
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <button
            type="button"
            onClick={() => {
              const allLocked = isTestLocked && isShockLocked && isDryingLocked;
              setIsTestLocked(!allLocked);
              setIsShockLocked(!allLocked);
              setIsDryingLocked(!allLocked);
            }}
            className="flex items-center gap-1.5 text-xs font-bold px-2.5 sm:px-3 py-1.5 rounded-lg border border-sky-400/40 bg-sky-900/70 hover:bg-sky-800 text-sky-100 transition shadow-sm"
            title="Tüm form bölümlerini kilitle veya aç"
          >
            {isTestLocked && isShockLocked && isDryingLocked ? (
              <>
                <Unlock className="w-3.5 h-3.5 text-amber-300" />
                <span className="hidden xs:inline">Tüm Kilitleri Aç</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5 text-emerald-300" />
                <span className="hidden xs:inline">Tüm Formu Kilitle</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Hızlı Yardımcı Notlar & Standartlar Kutusu */}
        <div className="bg-sky-50/90 border border-sky-200 rounded-2xl p-4 text-xs text-sky-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sky-900">
            <Info className="w-4 h-4 text-sky-700 shrink-0" />
            <span>💡 Freeze-Dry Liyofilizasyon Standartları (Üretim İpuçları):</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px] text-sky-900/90 leading-relaxed">
            <div className="bg-white/70 p-2 rounded-lg border border-sky-200/60">
              <strong>Şoklama & Çekirdek Sıcaklığı:</strong> Ürünler -40°C blast freezerda çekirdek sıcaklığı en az -35°C olana kadar şoklanmalıdır.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-sky-200/60">
              <strong>Nihai Nem Kriteri:</strong> Kurutma sonrası nihai nem oranı &lt;%3.0 (tercihen %1.5 - %2.5) olmalıdır.
            </div>
            <div className="bg-white/70 p-2 rounded-lg border border-sky-200/60">
              <strong>Azot Gazı & Paketleme:</strong> Çıtır yapının korunması için nem almayan alüminyum doypack içine N2 (azot) basılarak kapatılır.
            </div>
          </div>
        </div>

        {/* Reference Selector */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
            <label className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-sky-600" />
              <span>İzlenebilirlik Referansı (RefID Bağlantısı veya Yeni Ref)</span>
            </label>
            <div className="flex items-center gap-2 text-xs flex-wrap">
              <button
                type="button"
                onClick={() => setIsNewRef(false)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  !isNewRef
                    ? 'bg-sky-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                Mevcut Ref'e Bağla / Seç
              </button>
              <button
                type="button"
                onClick={() => setIsNewRef(true)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  isNewRef
                    ? 'bg-sky-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                + Yeni Freeze-Dry Ref Aç
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {isNewRef ? (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Yeni Liyofilizasyon RefID</label>
                <input
                  type="text"
                  value={customRefId}
                  onChange={(e) => setCustomRefId(e.target.value)}
                  placeholder="Otomatik (FD-...) veya Özel Kod"
                  className="w-full text-xs font-mono font-bold bg-white border border-sky-300 rounded-lg px-3 py-2 text-sky-900"
                />
              </div>
            ) : (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Mevcut Referans (Seçin veya Yazın)</label>
                <input
                  type="text"
                  list="fd-existing-refs"
                  value={selectedRefId}
                  onChange={(e) => setSelectedRefId(e.target.value)}
                  placeholder="RefID Seçin veya Yazın..."
                  className="w-full text-xs font-mono font-bold bg-white border border-sky-300 rounded-lg px-3 py-2 text-slate-900"
                />
                <datalist id="fd-existing-refs">
                  {existingRefs.map((r) => (
                    <option key={r.refId} value={r.refId}>
                      {r.refId} — {r.product} ({r.quantity} {r.unit}) [{r.status}]
                    </option>
                  ))}
                </datalist>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Liyofilizasyon & Süreç Sorumlusu</label>
              <input
                type="text"
                list="operators-list"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>
          </div>

          {/* Doğrulanmış Saha Testi / Referans Özet Bilgi Kartı */}
          {!isNewRef && (matchedFieldRecord || matchedRef) && (
            <div className="mt-3 p-3 bg-gradient-to-r from-emerald-50/80 via-sky-50/60 to-slate-50 rounded-xl border border-emerald-200/90 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-200/60 pb-2 mb-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-black text-slate-900">
                    Referans Doğrulanmış Saha Test Verileri ({selectedRefId})
                  </span>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Test Onaylı
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-900">
                  <Lock className="w-3 h-3 text-emerald-700" />
                  <span>Veriler forma aktarıldı & kilitlendi (Tekrar girmeye gerek yoktur)</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 text-xs">
                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Ürün & Çeşit</span>
                  <span className="font-extrabold text-slate-900 truncate block">
                    {matchedRef?.product || matchedFieldRecord?.product || product}
                    {matchedFieldRecord?.sortVariety ? ` (${matchedFieldRecord.sortVariety})` : ''}
                  </span>
                </div>

                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Saha Brix Değeri</span>
                  <span className="font-black text-rose-700 block">
                    %{matchedFieldRecord?.avgBrix ? matchedFieldRecord.avgBrix.toFixed(1) : rawBrix} °Bx
                  </span>
                </div>

                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Saha Sertliği</span>
                  <span className="font-extrabold text-blue-700 block">
                    {matchedFieldRecord?.avgHardness ? `${matchedFieldRecord.avgHardness.toFixed(1)} kg/cm²` : '4.2 kg/cm²'}
                  </span>
                </div>

                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Parti Tartımı</span>
                  <span className="font-black text-sky-950 block">
                    {((matchedRef?.quantity || rawWeightKg) ?? 0).toLocaleString()} kg
                  </span>
                </div>

                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Bahçe / Menşei</span>
                  <span className="font-bold text-slate-700 truncate block">
                    {matchedFieldRecord?.orchard || matchedRef?.location || ''}
                  </span>
                </div>

                <div className="bg-white/85 p-2 rounded-lg border border-slate-200/70">
                  <span className="text-[10px] text-slate-500 font-bold block">Nitrat & Karar</span>
                  <span className="font-bold text-emerald-700 block">
                    {matchedFieldRecord?.nitratePass ? '✅ Uygun (Geçti)' : '✅ Kabul Edildi'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Section 1: Hammadde Giriş & Standart Dışı Seçim */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-sky-600" />
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
                1. Hammadde Girişi & Standart Dışı Seçim Testi
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsTestLocked(!isTestLocked)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold border transition shadow-xs ${
                  isTestLocked
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200'
                    : 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                }`}
              >
                {isTestLocked ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Test Verileri Kilitli (Açmak İçin Tıkla)</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-3.5 h-3.5 text-amber-700" />
                    <span>Verileri Kilitle</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Test & Data Locking Notification Banner */}
          <div className={`p-3 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-colors ${
            isTestLocked 
              ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
              : 'bg-amber-50/90 border-amber-300 text-amber-950'
          }`}>
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg shrink-0 ${isTestLocked ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'}`}>
                {isTestLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-xs">
                    {isTestLocked 
                      ? 'Test & Hammadde Bilgileri KİLİTLİ (Koruma Modu)' 
                      : 'Test & Hammadde Bilgileri AÇIK (Serbest Düzenleme)'}
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    isTestLocked ? 'bg-emerald-200/90 text-emerald-900' : 'bg-amber-200/90 text-amber-900'
                  }`}>
                    {isTestLocked ? '✓ Bilgi Değişmediyse Tekrar Doldurulmaz' : '✏️ Düzenlenebilir'}
                  </span>
                </div>
                <p className="text-[11px] opacity-85 mt-0.5">
                  {isTestLocked 
                    ? 'Referans testinden alınan Brix, ürün, çeşit ve ağırlık kilitlenmiştir. Bilgi değişmediyse formu tekrar doldurmanıza gerek yoktur.'
                    : 'Giriş değerlerini değiştirebilirsiniz. Değişiklik bittiğinde "Verileri Kilitle" butonuna tıklayabilirsiniz.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
              <button
                type="button"
                onClick={() => setIsTestLocked(!isTestLocked)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs ${
                  isTestLocked
                    ? 'bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-400'
                    : 'bg-amber-700 hover:bg-amber-800 text-white'
                }`}
              >
                {isTestLocked ? (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Kilidi Aç (Düzenle)</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Verileri Kilitle</span>
                  </>
                )}
              </button>

              {!isNewRef && (
                <button
                  type="button"
                  onClick={handleResetToFieldTest}
                  title="Saha testindeki orijinal değerleri yeniden yükle"
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/90 hover:bg-white text-slate-700 border border-slate-300 text-xs font-semibold"
                >
                  <RotateCcw className="w-3 h-3 text-slate-600" />
                  <span className="hidden sm:inline text-[11px]">Saha Testini Çek</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">İşleme / Kabul Tarihi *</label>
                {isTestLocked && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> Kilitli
                  </span>
                )}
              </div>
              <input
                type="date"
                value={processDate}
                onChange={(e) => setProcessDate(e.target.value)}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900 focus:ring-2 focus:ring-sky-500'
                }`}
               
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">İşlenecek Ürün *</label>
                {isTestLocked && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> Testten Alındı
                  </span>
                )}
              </div>
              <input
                type="text"
                list="products-list"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900 focus:ring-2 focus:ring-sky-500'
                }`}
               
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Çeşit / Varyete</label>
                {isTestLocked && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> Kilitli
                  </span>
                )}
              </div>
              <input
                type="text"
                value={variety}
                onChange={(e) => setVariety(e.target.value)}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
                placeholder="Örn: Extreme 314, Royal Glory"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Giriş Yaş Ağırlığı (kg) *</label>
                {isTestLocked && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> Kilitli
                  </span>
                )}
              </div>
              <input
                type="number"
                min="1"
                step="0.1"
                value={rawWeightKg}
                onChange={(e) => setRawWeightKg(Number(e.target.value))}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-sky-950 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-sky-900 focus:ring-2 focus:ring-sky-500'
                }`}
               
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 pt-1">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Hammadde Kaynağı / Durumu</label>
                {isTestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </div>
              <select
                value={rawMaterialSource}
                onChange={(e) => setRawMaterialSource(e.target.value)}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
              >
                <option value="Saha Standart Dışı Seçim (İhracat Kalibre Altı / Şeker Oranı Yüksek)">🌱 Saha Standart Dışı (Yüksek Brix)</option>
                <option value="Depo / Paketleme Ayıklama Ayrımı (2. Sınıf Tatlı)">🏭 Depo Paketleme Ayrımı</option>
                <option value="Doğrudan Freeze-Dry Sözleşmeli Hasat">📜 Doğrudan Sanayi Sözleşmeli Hasat</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Giriş Şeker Brix (°Bx) *</label>
                {isTestLocked && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> Saha Brix Kilitli
                  </span>
                )}
              </div>
              <input
                type="number"
                step="0.1"
                min="0"
                value={rawBrix}
                onChange={(e) => setRawBrix(Number(e.target.value))}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-rose-900 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-rose-700 focus:ring-2 focus:ring-rose-500'
                }`}
                placeholder="Örn: 14.2"
               
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Başlangıç Su/Nem Oranı (%)</label>
                {isTestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </div>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                value={rawMoisturePercent}
                onChange={(e) => setRawMoisturePercent(Number(e.target.value))}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
                placeholder="Örn: 86.5"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Çekirdek/Kabuk Firesi (kg)</label>
                {isTestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </div>
              <input
                type="number"
                step="0.1"
                min="0"
                value={sortingWasteKg}
                onChange={(e) => setSortingWasteKg(Number(e.target.value))}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-amber-900 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-amber-700'
                }`}
                placeholder="Örn: 110"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Dilim / Küp Kalınlığı (mm)</label>
                {isTestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </div>
              <input
                type="number"
                min="1"
                max="30"
                value={sliceThicknessMm}
                onChange={(e) => setSliceThicknessMm(Number(e.target.value))}
                disabled={isTestLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isTestLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed select-none'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
                placeholder="Örn: 6 mm"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Şok Dondurma (-40°C) & Donuk Depo (-25°C) */}
        <div className="p-4 bg-sky-50/60 rounded-xl border border-sky-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-200 pb-2">
            <div className="flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-sky-700" />
              <h3 className="text-xs font-black uppercase tracking-wider text-sky-950">
                2. -40°C Şok Dondurma & -25°C Donuk Depolama Odası
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsShockLocked(!isShockLocked)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold border transition shadow-xs ${
                isShockLocked
                  ? 'bg-sky-200/90 text-sky-950 border-sky-400 hover:bg-sky-300'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {isShockLocked ? (
                <>
                  <Lock className="w-3.5 h-3.5 text-sky-800" />
                  <span>Şoklama Verileri Kilitli (Açmak İçin Tıkla)</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Şoklamayı Kilitle</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Şoklama Odası / Tünel *</label>
              <input
                type="text"
                value={shockFreezerRoom}
                onChange={(e) => setShockFreezerRoom(e.target.value)}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Şoklama Sıcaklığı (°C) *</label>
              <input
                type="number"
                step="0.1"
                value={shockFreezerTempC}
                onChange={(e) => setShockFreezerTempC(Number(e.target.value))}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-sky-950 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-sky-400 text-sky-900'
                }`}
                placeholder="Hedef: -40°C veya altı"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Meyve Çekirdek Donma (°C)</label>
              <input
                type="number"
                step="0.1"
                value={coreTemperatureC}
                onChange={(e) => setCoreTemperatureC(Number(e.target.value))}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300 text-blue-700'
                }`}
                placeholder="Örn: -38.5"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Şoklama Süresi (Saat)</label>
              <input
                type="number"
                step="0.5"
                min="0.5"
                value={shockDurationHours}
                onChange={(e) => setShockDurationHours(Number(e.target.value))}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
              />
            </div>
          </div>

          {/* -25C Cold Storage Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2 border-t border-sky-200/70">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">-25°C Donuk Depo Odası</label>
              <input
                type="text"
                value={frozenStorageRoom}
                onChange={(e) => setFrozenStorageRoom(e.target.value)}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
                placeholder="Örn: Donuk Depo Hücre FD-3"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Donuk Depo Sıcaklığı (°C)</label>
              <input
                type="number"
                step="0.1"
                value={frozenStorageTempC}
                onChange={(e) => setFrozenStorageTempC(Number(e.target.value))}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-indigo-950 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300 text-indigo-900'
                }`}
                placeholder="Hedef: -25°C"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Donuk Depo Palet No</label>
              <input
                type="text"
                value={frozenStoragePalletNo}
                onChange={(e) => setFrozenStoragePalletNo(e.target.value)}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-mono font-medium transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
                placeholder="Örn: PLT-FD-084"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Donuk Bekleme (Gün)</label>
              <input
                type="number"
                min="0"
                value={frozenStorageDays}
                onChange={(e) => setFrozenStorageDays(Number(e.target.value))}
                disabled={isShockLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-medium transition ${
                  isShockLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
              />
            </div>
          </div>
        </div>

        {/* Section 3: Liyofilizasyon / Freeze-Dry Kurutma Kabini */}
        <div className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-200 pb-2">
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-indigo-700" />
              <h3 className="text-xs font-black uppercase tracking-wider text-indigo-950">
                3. Liyofilizatör Kabini (Vakum & Süblimasyon Kurutma)
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsDryingLocked(!isDryingLocked)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold border transition shadow-xs ${
                isDryingLocked
                  ? 'bg-indigo-200/90 text-indigo-950 border-indigo-400 hover:bg-indigo-300'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {isDryingLocked ? (
                <>
                  <Lock className="w-3.5 h-3.5 text-indigo-800" />
                  <span>Kurutma Verileri Kilitli (Açmak İçin Tıkla)</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Kurutmayı Kilitle</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Liyofilizatör Kabin No *</label>
              <input
                type="text"
                value={dryerChamberNo}
                onChange={(e) => setDryerChamberNo(e.target.value)}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300 text-slate-900'
                }`}
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Tepsi Sayısı (Adet)</label>
              <input
                type="number"
                min="1"
                value={trayCount}
                onChange={(e) => setTrayCount(Number(e.target.value))}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold text-center transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Vakum Basıncı (mBar / Pa) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={vacuumPressureMbar}
                onChange={(e) => setVacuumPressureMbar(Number(e.target.value))}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-indigo-950 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-indigo-300 text-indigo-900'
                }`}
                placeholder="Örn: 0.18 mbar"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Süblimasyon Süresi (Saat) *</label>
              <input
                type="number"
                step="0.5"
                min="1"
                value={sublimationTimeHours}
                onChange={(e) => setSublimationTimeHours(Number(e.target.value))}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
                placeholder="Örn: 20.5 saat"
               
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Çıkan Net Kuru Ürün (kg) *</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={finalDryWeightKg}
                onChange={(e) => setFinalDryWeightKg(Number(e.target.value))}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-black transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-indigo-950 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-indigo-400 text-indigo-950'
                }`}
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Nihai Kuru Nem Oranı (%) *</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="10"
                value={finalMoisturePercent}
                onChange={(e) => setFinalMoisturePercent(Number(e.target.value))}
                disabled={isDryingLocked}
                className={`w-full text-xs border rounded-lg px-3 py-2 font-black transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-slate-700 border-slate-300 cursor-not-allowed'
                    : finalMoisturePercent <= 3.0
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                    : 'bg-rose-50 border-rose-400 text-rose-900'
                }`}
                placeholder="Hedef: < %3.0"
               
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                {finalMoisturePercent <= 3.0 ? '✅ İdeal Çıtır Gevrek Yapı' : '⚠️ Nem yüksek, ek kurutma gerekebilir'}
              </span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Meyve Dokusu & Gevreklik</label>
              <select
                value={crunchinessTexture}
                onChange={(e) => setCrunchinessTexture(e.target.value as any)}
                disabled={isDryingLocked}
                className={`w-full text-xs rounded-lg px-3 py-2 font-bold transition ${
                  isDryingLocked
                    ? 'bg-slate-100 text-slate-700 border border-slate-300 cursor-not-allowed'
                    : 'bg-white border border-slate-300'
                }`}
              >
                <option value="Gevrek / Çıtır">✨ Gevrek / Çıtır (Mükemmel Liyofilizasyon)</option>
                <option value="Yumuşak (Eksik Kuruma)">⚠️ Yumuşak (Eksik Kuruma - Nemli)</option>
                <option value="Kırılgan / Toz">💥 Kırılgan / Tozlaşmış</option>
              </select>
            </div>
          </div>

          {/* Real-time Yield Metric Banner */}
          <div className="bg-white p-3 rounded-xl border border-indigo-200 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">İşlenebilir Net Yaş Dilim:</span>
              <span className="text-xs font-black text-slate-900">{(usableRawWeightKg ?? 0).toLocaleString()} kg</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">Liyofilizasyon Randıman Oranı (%):</span>
              <span className="text-sm font-black text-indigo-700">%{yieldRatioPercent}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">Su Uçurma Oranı:</span>
              <span className="text-xs font-black text-cyan-700">%{Number((100 - yieldRatioPercent).toFixed(2))}</span>
            </div>
          </div>
        </div>

        {/* Section 4: Paketleme & Ambalajlama */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <PackageCheck className="w-4 h-4 text-sky-600" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
              4. Nihai Paketleme, Azot Gazı (MAP) & Lot Bilgileri
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Ambalaj Tipi</label>
              <input
                type="text"
                value={packagingType}
                onChange={(e) => setPackagingType(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                placeholder="Örn: Azot Gazlı Alüminyum Doypack"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Paket Başı Gramaj (g)</label>
              <input
                type="number"
                min="5"
                step="1"
                value={packageGram}
                onChange={(e) => setPackageGram(Number(e.target.value))}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-center"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Üretilen Toplam Paket</label>
              <div className="w-full text-xs bg-slate-100 border border-slate-300 rounded-lg px-3 py-2 font-black text-emerald-800">
                {(calculatedTotalPackages ?? 0).toLocaleString()} Adet Paket
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Azot Gazı (MAP) Koruması</label>
              <button
                type="button"
                onClick={() => setNitrogenFlushed(!nitrogenFlushed)}
                className={`w-full text-xs font-bold rounded-lg px-3 py-2 border flex items-center justify-center gap-1.5 transition ${
                  nitrogenFlushed
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                    : 'bg-white text-slate-700 border-slate-300'
                }`}
              >
                <Wind className="w-3.5 h-3.5" />
                <span>{nitrogenFlushed ? '💨 Azot Gazı Basıldı (O2 <%1)' : 'Hava / Standart'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Üretim Parti / Lot No *</label>
              <input
                type="text"
                value={lotNo}
                onChange={(e) => setLotNo(e.target.value)}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">TETT (Son Tüketim Tarihi)</label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Proses Aşaması Durumu</label>
              <select
                value={processStatus}
                onChange={(e) => setProcessStatus(e.target.value as any)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-900"
              >
                <option value="RAW_ACCEPTED">🟡 Hammadde Kabul & Dilimlendi</option>
                <option value="SHOCKED_40C">❄️ -40°C Şoklamada</option>
                <option value="STORED_25C">🧊 -25°C Donuk Depoda</option>
                <option value="DRYING">⚙️ Liyofilizasyon Kabininde Kurutuluyor</option>
                <option value="COMPLETED">✅ Kurutma & Paketleme Tamamlandı</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Proses & Kalite Notları</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg p-3 font-medium"
              placeholder="Vakum eğrisi, duyusal lezzet testi, çıtırlık değerlendirmesi..."
            />
          </div>
        </div>

        {/* Section 5: Fotoğraf Yükleme */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-700" />
              <label className="text-xs font-black uppercase tracking-wider text-slate-900">
                Freeze-Dry Dilim, Tepsi, -40°C Şok & Paketleme Fotoğrafları
              </label>
            </div>
            <span className="text-[11px] font-bold text-slate-600 bg-white px-2.5 py-0.5 rounded-full border border-slate-200">
              {photos.filter(p => p && p.length > 20).length} Fotoğraf
            </span>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-4 transition text-center flex flex-col sm:flex-row items-center justify-between gap-3 ${
              isDragging
                ? 'border-sky-500 bg-sky-50/70'
                : 'border-slate-300 bg-white hover:border-slate-400'
            }`}
          >
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 border border-sky-200 flex items-center justify-center shrink-0">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">
                  Fotoğrafları buraya sürükleyin veya cihazdan seçin
                </p>
                <p className="text-[11px] text-slate-500">
                  Tepsi dizilimi, -40°C sıcaklık ekranı veya nihai çıtır freeze-dry paket görseli ekleyin.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-sky-300" />
                <span>Fotoğraf Çek</span>
              </button>

              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Galeriden Seç</span>
              </button>

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />

              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-2 flex-wrap text-[11px] pt-1">
            <span className="text-slate-500 font-semibold">Hızlı Fotoğraf Ekle:</span>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1596591606975-97ee5cef3a1e?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-sky-600" />
              <span>🍓 Freeze-Dried Meyve Dilimleri</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-sky-600" />
              <span>📦 Erem™ Doypack Ambalaj</span>
            </button>
          </div>

          {/* Uploaded Grid */}
          {photos.filter(p => p && p.length > 20).length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
              {photos.filter(p => p && p.length > 20).map((p, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shadow-sm aspect-square"
                >
                  <img
                    src={p}
                    alt={`Freeze-Dry Evidence ${idx + 1}`}
                    className="w-full h-full object-cover transition duration-200 group-hover:scale-105"
                  />
                  <div className="absolute top-1 left-1 bg-black/60 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    #{idx + 1}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(idx)}
                    title="Kaldır"
                    className="absolute top-1 right-1 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-md shadow-md opacity-90 group-hover:opacity-100 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition"
          >
            İptal Et
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-gradient-to-r from-sky-900 to-indigo-900 hover:from-sky-800 hover:to-indigo-800 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition`}
          >
            <Save className="w-4 h-4 text-sky-300" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'FREEZE-DRY İŞLEME KAYDINI TAMAMLA'}</span>
          </button>
        </div>
        </fieldset>

      </form>
    </div>
  );
};
