import React from 'react';
import { FlaskConical } from 'lucide-react';

/**
 * Kayıtlardan hesaplanmayan (örnek, simülasyon veya bağlı olmayan) içerikleri işaretler.
 * Kural: platformda kaynağı olmayan her sayı bu rozetle gösterilir.
 */
export default function DemoBadge({ label = 'DEMO', note }: { label?: string; note?: string }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-950/60 dark:text-amber-200 dark:border-amber-700 whitespace-nowrap"
      title={note || 'Bu bölümdeki değerler gerçek kayıtlardan hesaplanmıyor.'}
    >
      <FlaskConical className="w-3 h-3" aria-hidden="true" />
      <span>{label}</span>
      {note && <span className="font-medium opacity-80">· {note}</span>}
    </span>
  );
}
