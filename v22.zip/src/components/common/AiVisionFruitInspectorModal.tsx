import React, { useState, useEffect } from 'react';
import DemoBadge from './DemoBadge';
import {
  X,
  Camera,
  Scan,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Sliders,
  Apple,
  Banana,
  Nut,
  Eye,
  Layers,
  ChevronRight,
  Info,
  Maximize2
} from 'lucide-react';

export interface AiVisionResult {
  fruitType: 'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH';
  averageCalibreMm: number;
  averageColorPercent: number;
  russetingDefectPercent: number;
  detectedCount: number;
  qualityGrade: 'Ekstra Sınıf' | '1. Sınıf' | '2. Sınıf' | 'Sanayi / Fire';
  confidenceScore: number;
  processingTimeMs: number;
  individualItems: Array<{
    id: number;
    calibreMm: number;
    colorPercent: number;
    defectPercent: number;
    box: { x: number; y: number; w: number; h: number }; // percentages
  }>;
}

interface AiVisionFruitInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialFruit?: 'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH';
  onApplyResults?: (results: {
    calibreMm: number;
    colorPercent: number;
    qualityGrade: string;
    russetingPercent?: number;
  }) => void;
}

const PRESET_SAMPLES: Record<'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH', AiVisionResult> = {
  APPLE: {
    fruitType: 'APPLE',
    averageCalibreMm: 74.2,
    averageColorPercent: 82.5,
    russetingDefectPercent: 0.4,
    detectedCount: 6,
    qualityGrade: 'Ekstra Sınıf',
    confidenceScore: 98.4,
    processingTimeMs: 840,
    individualItems: [
      { id: 1, calibreMm: 75.8, colorPercent: 86, defectPercent: 0, box: { x: 18, y: 22, w: 26, h: 26 } },
      { id: 2, calibreMm: 73.4, colorPercent: 81, defectPercent: 0.2, box: { x: 54, y: 20, w: 25, h: 25 } },
      { id: 3, calibreMm: 76.1, colorPercent: 84, defectPercent: 0, box: { x: 14, y: 55, w: 27, h: 27 } },
      { id: 4, calibreMm: 72.9, colorPercent: 79, defectPercent: 0.8, box: { x: 50, y: 56, w: 26, h: 26 } },
      { id: 5, calibreMm: 74.5, colorPercent: 83, defectPercent: 0.3, box: { x: 34, y: 38, w: 25, h: 25 } },
      { id: 6, calibreMm: 72.5, colorPercent: 82, defectPercent: 0.5, box: { x: 76, y: 40, w: 20, h: 20 } }
    ]
  },
  BANANA: {
    fruitType: 'BANANA',
    averageCalibreMm: 41.5, // parmak kalınlığı (grade)
    averageColorPercent: 96.0, // yeşil oran veya renklenme
    russetingDefectPercent: 0.2,
    detectedCount: 8,
    qualityGrade: '1. Sınıf',
    confidenceScore: 97.8,
    processingTimeMs: 760,
    individualItems: [
      { id: 1, calibreMm: 42.0, colorPercent: 98, defectPercent: 0, box: { x: 15, y: 15, w: 22, h: 65 } },
      { id: 2, calibreMm: 41.2, colorPercent: 95, defectPercent: 0, box: { x: 38, y: 18, w: 21, h: 63 } },
      { id: 3, calibreMm: 41.8, colorPercent: 96, defectPercent: 0.4, box: { x: 60, y: 16, w: 23, h: 66 } }
    ]
  },
  ALMOND: {
    fruitType: 'ALMOND',
    averageCalibreMm: 24.8,
    averageColorPercent: 92.0,
    russetingDefectPercent: 1.1,
    detectedCount: 12,
    qualityGrade: 'Ekstra Sınıf',
    confidenceScore: 99.1,
    processingTimeMs: 690,
    individualItems: [
      { id: 1, calibreMm: 25.2, colorPercent: 94, defectPercent: 0, box: { x: 25, y: 30, w: 18, h: 22 } },
      { id: 2, calibreMm: 24.4, colorPercent: 90, defectPercent: 1.2, box: { x: 50, y: 28, w: 17, h: 24 } },
      { id: 3, calibreMm: 24.9, colorPercent: 92, defectPercent: 0.8, box: { x: 38, y: 55, w: 19, h: 23 } }
    ]
  },
  PEACH: {
    fruitType: 'PEACH',
    averageCalibreMm: 72.0,
    averageColorPercent: 88.0,
    russetingDefectPercent: 0.6,
    detectedCount: 5,
    qualityGrade: 'Ekstra Sınıf',
    confidenceScore: 98.2,
    processingTimeMs: 810,
    individualItems: [
      { id: 1, calibreMm: 73.5, colorPercent: 90, defectPercent: 0, box: { x: 20, y: 25, w: 28, h: 28 } },
      { id: 2, calibreMm: 71.2, colorPercent: 86, defectPercent: 0.5, box: { x: 55, y: 26, w: 27, h: 27 } }
    ]
  }
};

export const AiVisionFruitInspectorModal: React.FC<AiVisionFruitInspectorModalProps> = ({
  isOpen,
  onClose,
  initialFruit = 'APPLE',
  onApplyResults
}) => {
  const [selectedFruit, setSelectedFruit] = useState<'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH'>(initialFruit);
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [activeAnalysis, setActiveAnalysis] = useState<AiVisionResult>(PRESET_SAMPLES[initialFruit]);
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [cameraActive, setCameraActive] = useState<boolean>(false);

  useEffect(() => {
    setSelectedFruit(initialFruit);
    runScan(initialFruit);
  }, [initialFruit, isOpen]);

  const runScan = (fruit: 'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH') => {
    setIsScanning(true);
    setTimeout(() => {
      setActiveAnalysis(PRESET_SAMPLES[fruit]);
      setIsScanning(false);
    }, 1000); // 1-second rapid scan
  };

  const handleFruitChange = (fruit: 'APPLE' | 'BANANA' | 'ALMOND' | 'PEACH') => {
    setSelectedFruit(fruit);
    runScan(fruit);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 border border-teal-500/40 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-white">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-teal-950 via-slate-900 to-teal-950 border-b border-teal-500/30 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-500/20 border border-teal-400/40 text-teal-300 shadow-inner">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-teal-500/20 text-teal-300 border border-teal-400/30 font-mono">
                  2026 GAP ÇÖZÜMÜ #3
                </span>
                <span className="text-xs text-teal-400 font-mono font-bold">1 Saniyede Otomatik Kalibre</span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                Mobil Kamera Destekli AI Bilgisayarlı Görü (Computer Vision)
                <DemoBadge note="gerçek görüntü analizi bağlı değil" />
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowGuide(!showGuide)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 transition cursor-pointer"
              title="Bu Modül Nedir ve Nasıl Çalışır?"
            >
              <Info className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition cursor-pointer"
              title="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Info Banner / Explanation */}
          {showGuide && (
            <div className="p-4 rounded-2xl bg-teal-950/60 border border-teal-500/40 text-teal-100 text-xs leading-relaxed space-y-2 animate-in fade-in">
              <div className="font-extrabold text-sm text-teal-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span>Müfettiş Sübjektifliğini Sıfırlayan AI Bilgisayarlı Görü Nedir?</span>
              </div>
              <p>
                Geleneksel kalite kontrolünde farklı vardiyalardaki müfettişlerin kumpas ve renk gözlemleri arasında %10–%15 sübjektif hata payı oluşur. 
                Bu modül, akıllı telefon kamerasından çekilen kasa fotoğrafında meyveleri piksel düzeyinde segmente eder, çapı (mm cinsinden kumpas kalibresi) ve güneşlenme/renklenme yüzdesini <strong>1 saniye içinde</strong> hatasız hesaplar.
              </p>
              <div className="text-[11px] text-teal-300/80 font-mono">
                ✓ Doğruluk Oranı: %98.4 • Çap Hassasiyeti: ±0.3 mm • Renk Ayrımı: RGB/HSV Spektrumu
              </div>
            </div>
          )}

          {/* Fruit Type Selector */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Taranacak Meyve / Numune Türü:
            </span>
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => handleFruitChange('APPLE')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedFruit === 'APPLE' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Apple className="w-3.5 h-3.5" />
                <span>Elma (Gala)</span>
              </button>
              <button
                type="button"
                onClick={() => handleFruitChange('BANANA')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedFruit === 'BANANA' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Banana className="w-3.5 h-3.5" />
                <span>Muz (Cavendish)</span>
              </button>
              <button
                type="button"
                onClick={() => handleFruitChange('ALMOND')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedFruit === 'ALMOND' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Nut className="w-3.5 h-3.5" />
                <span>Badem (Nonpareil)</span>
              </button>
              <button
                type="button"
                onClick={() => handleFruitChange('PEACH')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedFruit === 'PEACH' ? 'bg-orange-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🍑 Şeftali</span>
              </button>
            </div>
          </div>

          {/* Viewfinder Canvas & Visual Segmentation Stage */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            
            {/* Viewfinder simulation (Left 7 cols) */}
            <div className="lg:col-span-7 bg-slate-950 rounded-2xl border-2 border-dashed border-teal-500/50 p-4 relative min-h-[320px] flex flex-col justify-between overflow-hidden shadow-inner">
              
              {/* Camera Crosshairs / Corners */}
              <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-teal-400 pointer-events-none" />
              <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-teal-400 pointer-events-none" />
              <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-teal-400 pointer-events-none" />
              <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-teal-400 pointer-events-none" />

              {/* Viewfinder Top Bar */}
              <div className="flex items-center justify-between text-xs font-mono relative z-10">
                <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/60 text-emerald-400 border border-emerald-500/40 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>AI VISION ACTIVE • 60 FPS</span>
                </span>
                <span className="text-slate-400 bg-black/60 px-2 py-0.5 rounded">
                  {activeAnalysis.confidenceScore}% Güven
                </span>
              </div>

              {/* Laser Scan Line Animation during scanning */}
              {isScanning && (
                <div className="absolute inset-0 pointer-events-none flex flex-col justify-center items-center bg-teal-500/10 z-20">
                  <div className="w-full h-1 bg-gradient-to-r from-transparent via-teal-400 to-transparent shadow-[0_0_15px_#2dd4bf] animate-bounce" />
                  <span className="mt-4 px-3 py-1 rounded-full bg-black/80 text-teal-300 font-mono text-xs font-bold border border-teal-500/40">
                    ⚡ Bilgisayarlı Görü Taraması Yapılıyor (1 sn)...
                  </span>
                </div>
              )}

              {/* Interactive Bounding Boxes Visualization */}
              <div className="relative my-6 min-h-[200px] flex items-center justify-center">
                {/* Synthetic Fruit Crate background */}
                <div className="w-full max-w-[360px] h-[200px] bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 rounded-xl border border-amber-900/40 relative overflow-hidden flex items-center justify-center">
                  
                  {/* Grid of Detected Fruit Bounding Boxes */}
                  {activeAnalysis.individualItems.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        position: 'absolute',
                        left: `${item.box.x}%`,
                        top: `${item.box.y}%`,
                        width: `${item.box.w}%`,
                        height: `${item.box.h}%`
                      }}
                      className="border-2 border-teal-400 rounded-xl bg-teal-500/15 flex flex-col justify-between p-1 transition-all hover:scale-105 hover:bg-teal-500/30 cursor-pointer shadow-[0_0_10px_rgba(45,212,191,0.3)]"
                      title={`#${item.id} Meyve: ${item.calibreMm}mm, Renk %${item.colorPercent}`}
                    >
                      <div className="flex items-center justify-between text-[8px] font-mono font-black text-teal-300 bg-black/70 px-1 rounded">
                        <span>#{item.id}</span>
                        <span>{item.calibreMm}mm</span>
                      </div>
                      <div className="text-[7.5px] font-mono text-white bg-teal-900/80 px-0.5 rounded text-center truncate">
                        %{item.colorPercent} Renk
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Viewfinder Controls */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800 relative z-10">
                <span className="text-[11px] text-slate-400">
                  Tespit Edilen Meyve: <strong className="text-white font-mono">{activeAnalysis.detectedCount} Adet</strong>
                </span>
                <button
                  type="button"
                  onClick={() => runScan(selectedFruit)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold transition cursor-pointer border border-slate-700"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>Yeniden Tara</span>
                </button>
              </div>
            </div>

            {/* Analysis Metrics & Decision Card (Right 5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Özet Analiz Sonuçları
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                    {activeAnalysis.processingTimeMs} ms
                  </span>
                </div>

                {/* Metric 1: Average Calibre (mm) */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Ortalama Kalibre Çapı:</span>
                    <strong className="text-xl font-black text-white font-mono">
                      {activeAnalysis.averageCalibreMm} mm
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-teal-400 font-bold block">Tolerans</span>
                    <span className="text-xs text-slate-300 font-mono">±0.3 mm (Kumpas)</span>
                  </div>
                </div>

                {/* Metric 2: Average Color Percentage */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Kırmızı Üst Renklenme:</span>
                    <strong className="text-xl font-black text-rose-400 font-mono">
                      %{activeAnalysis.averageColorPercent}
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-rose-400 font-bold block">Spektrum</span>
                    <span className="text-xs text-slate-300 font-mono">RGB Blush Yüzeyi</span>
                  </div>
                </div>

                {/* Metric 3: Defect / Russeting */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Kabuk Pası &amp; Kusur:</span>
                    <strong className="text-base font-black text-amber-300 font-mono">
                      %{activeAnalysis.russetingDefectPercent}
                    </strong>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-1 rounded bg-emerald-500/20 text-emerald-300">
                    Kusursuz / Tolerans İçi
                  </span>
                </div>

                {/* Final Verdict Badge */}
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-black text-emerald-300">
                        Otomatik Kalite Sınıfı
                      </div>
                      <div className="text-[11px] text-slate-300">
                        {activeAnalysis.qualityGrade} (İhracata Uygun)
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-1 rounded-lg bg-emerald-500 text-slate-950 font-black text-xs font-mono">
                    PASS
                  </span>
                </div>
              </div>

              {/* Action Button: Form Data Auto-Fill */}
              {onApplyResults && (
                <button
                  type="button"
                  onClick={() => {
                    onApplyResults({
                      calibreMm: activeAnalysis.averageCalibreMm,
                      colorPercent: activeAnalysis.averageColorPercent,
                      qualityGrade: activeAnalysis.qualityGrade,
                      russetingPercent: activeAnalysis.russetingDefectPercent
                    });
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-sm transition shadow-lg shadow-teal-500/20 active:scale-95 cursor-pointer"
                >
                  <CheckCircle2 className="w-5 h-5 text-slate-950" />
                  <span>Değerleri Forma Otomatik Aktar ({activeAnalysis.averageCalibreMm}mm & %{activeAnalysis.averageColorPercent})</span>
                </button>
              )}
            </div>

          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="font-mono text-[11px]">
            AI Modeli: Miwe-Vision Edge v1.4 (WebGL Accelerated)
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition cursor-pointer"
          >
            Pencereyi Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
