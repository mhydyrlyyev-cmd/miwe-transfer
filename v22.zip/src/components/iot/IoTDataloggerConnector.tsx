import React, { useState, useEffect } from 'react';
import DemoBadge from '../common/DemoBadge';

/** v2.2: Bu bağlayıcı şimdilik SİMÜLASYONDUR (Math.random). Simüle değerler forma ve kayda yazılmaz. */
const IS_SIMULATION = true;
import {
  Radio,
  Wifi,
  WifiOff,
  Thermometer,
  Droplets,
  Wind,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  RefreshCw,
  Power,
  ChevronDown,
  ChevronUp,
  Link2,
  Cpu,
  Activity
} from 'lucide-react';

export interface TelemetryData {
  deviceUrl: string;
  deviceName: string;
  deviceType: 'SENSITECH' | 'EMERSON' | 'TIVE' | 'LORAWAN' | 'CUSTOM';
  temperatureC: number;
  humidityPercent: number;
  ethylenePpm: number;
  co2Percent?: number;
  o2Percent?: number;
  batteryPercent: number;
  signalStrength: 'EXCELLENT' | 'GOOD' | 'FAIR';
  lastPingTimestamp: string;
  isBreached: boolean;
  breachReason?: string;
}

interface IoTDataloggerConnectorProps {
  moduleName: string; // 'EXPORT_SAMPLE' | 'AMBAR' | 'LOJISTIK' | 'FIELD'
  defaultDeviceUrl?: string;
  onTelemetryUpdate?: (data: TelemetryData | null) => void;
  targetTempMin?: number;
  targetTempMax?: number;
}

const PRESET_DEVICES = [
  {
    name: 'Emerson GO Real-Time (Frigo Tır 01-AHP)',
    type: 'EMERSON' as const,
    url: 'https://go.emerson.com/track/EM-99214',
    baseTemp: 1.8,
    baseHumidity: 91.5,
    baseEthylene: 0.02
  },
  {
    name: 'Sensitech Cold-Link (İhracat Konteyner MSC-441)',
    type: 'SENSITECH' as const,
    url: 'https://live.sensitech.com/shipment/SN-88219',
    baseTemp: 1.6,
    baseHumidity: 92.0,
    baseEthylene: 0.01
  },
  {
    name: 'Tive Solo 5G (Soğuk Hava Odası #4 CA)',
    type: 'TIVE' as const,
    url: 'https://app.tive.io/track/TV-77102',
    baseTemp: 1.4,
    baseHumidity: 94.2,
    baseEthylene: 0.03
  }
];

export const IoTDataloggerConnector: React.FC<IoTDataloggerConnectorProps> = ({
  moduleName,
  defaultDeviceUrl = '',
  onTelemetryUpdate,
  targetTempMin = 0.5,
  targetTempMax = 2.5
}) => {
  // Option toggle: default is CLOSED if no link entered ("yok ise kapalı durur")
  const [isEnabled, setIsEnabled] = useState<boolean>(Boolean(defaultDeviceUrl));
  const [deviceUrl, setDeviceUrl] = useState<string>(defaultDeviceUrl);
  const [isConnected, setIsConnected] = useState<boolean>(Boolean(defaultDeviceUrl));
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Initialize or connect
  useEffect(() => {
    if (isEnabled && deviceUrl.trim()) {
      handleConnect();
    } else if (!isEnabled) {
      setTelemetry(null);
      setIsConnected(false);
      onTelemetryUpdate?.(null);
    }
  }, [isEnabled]);

  // Live streaming simulation every 4 seconds when connected
  useEffect(() => {
    if (!isConnected || !isEnabled) return;

    const interval = setInterval(() => {
      setTelemetry((prev) => {
        if (!prev) return null;
        const tempDrift = (Math.random() - 0.5) * 0.2;
        const newTemp = Math.round((prev.temperatureC + tempDrift) * 10) / 10;
        const newHum = Math.min(98, Math.max(80, Math.round((prev.humidityPercent + (Math.random() - 0.5) * 0.5) * 10) / 10));
        const isBreached = newTemp < targetTempMin || newTemp > targetTempMax;

        const updated: TelemetryData = {
          ...prev,
          temperatureC: newTemp,
          humidityPercent: newHum,
          lastPingTimestamp: new Date().toLocaleTimeString(),
          isBreached,
          breachReason: isBreached ? `Sıcaklık (${newTemp}°C) hedef bant dışında (${targetTempMin}°C - ${targetTempMax}°C)` : undefined
        };

        if (!IS_SIMULATION) onTelemetryUpdate?.(updated);
        return updated;
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isConnected, isEnabled, targetTempMin, targetTempMax]);

  const handleConnect = () => {
    if (!deviceUrl.trim()) return;
    setIsSyncing(true);

    setTimeout(() => {
      // Find matching preset or default
      const matched = PRESET_DEVICES.find(p => p.url === deviceUrl) || PRESET_DEVICES[0];
      const initialTemp = matched.baseTemp;
      const isBreached = initialTemp < targetTempMin || initialTemp > targetTempMax;

      const initData: TelemetryData = {
        deviceUrl: deviceUrl.trim(),
        deviceName: matched.name,
        deviceType: matched.type,
        temperatureC: initialTemp,
        humidityPercent: matched.baseHumidity,
        ethylenePpm: matched.baseEthylene,
        batteryPercent: 96,
        signalStrength: 'EXCELLENT',
        lastPingTimestamp: new Date().toLocaleTimeString(),
        isBreached,
        breachReason: isBreached ? `Sıcaklık (${initialTemp}°C) hedef bant dışında!` : undefined
      };

      setTelemetry(initData);
      setIsConnected(true);
      setIsSyncing(false);
      if (!IS_SIMULATION) onTelemetryUpdate?.(initData);
    }, 600);
  };

  const handleSelectPreset = (preset: typeof PRESET_DEVICES[0]) => {
    setDeviceUrl(preset.url);
    setIsEnabled(true);
    setIsSyncing(true);

    setTimeout(() => {
      const initData: TelemetryData = {
        deviceUrl: preset.url,
        deviceName: preset.name,
        deviceType: preset.type,
        temperatureC: preset.baseTemp,
        humidityPercent: preset.baseHumidity,
        ethylenePpm: preset.baseEthylene,
        batteryPercent: 95,
        signalStrength: 'EXCELLENT',
        lastPingTimestamp: new Date().toLocaleTimeString(),
        isBreached: preset.baseTemp < targetTempMin || preset.baseTemp > targetTempMax
      };
      setTelemetry(initData);
      setIsConnected(true);
      setIsSyncing(false);
      if (!IS_SIMULATION) onTelemetryUpdate?.(initData);
    }, 500);
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setTelemetry(null);
    onTelemetryUpdate?.(null);
  };

  return (
    <div className="rounded-2xl border border-slate-700 bg-slate-900/90 text-white overflow-hidden shadow-md">
      
      {/* Header bar with option toggle */}
      <div 
        onClick={() => setIsEnabled(!isEnabled)}
        className="p-3 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none bg-slate-850 hover:bg-slate-800 transition"
      >
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded-xl border ${
            isEnabled && isConnected
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              : 'bg-slate-800 text-slate-400 border-slate-700'
          }`}>
            <Radio className={`w-4 h-4 ${isConnected ? 'animate-pulse text-emerald-400' : ''}`} />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-black text-slate-100">
                Gerçek Zamanlı IoT Sensör &amp; Datalogger Bağlantısı
              </span>
              <DemoBadge note="simülasyon, kayda yazılmaz" />
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase font-mono border ${
                isEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {isEnabled ? (isConnected ? (IS_SIMULATION ? 'SİMÜLASYON' : 'CANLI BAĞLI') : 'SEÇENEK AÇIK') : 'KAPALI (İSTEĞE BAĞLI)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isEnabled
                ? 'Sensitech, Emerson, Tive veya LoRaWAN cihaz linkini girerek canlı sıcaklık ve nemi izleyin.'
                : 'Cihaz bilgisi yoksa kapalı kalır. İhtiyaç halinde seçeneği açıp bağlantı linkini yapıştırabilirsiniz.'}
            </p>
          </div>
        </div>

        {/* Toggle Switch */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsEnabled(!isEnabled);
            }}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
              isEnabled ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                isEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Expandable Body */}
      {isEnabled && (
        <div className="p-4 border-t border-slate-800 space-y-4 animate-in fade-in duration-200 bg-slate-950/60">
          
          {/* Connection URL Input */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-300">
              Datalogger Cihaz Bağlantı Linki (URL / API Webhook / Seri No):
            </label>
            <div className="flex items-center gap-2 flex-col sm:flex-row">
              <div className="relative flex-1 w-full">
                <Link2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="https://live.sensitech.com/shipment/... veya https://go.emerson.com/..."
                  value={deviceUrl}
                  onChange={(e) => setDeviceUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-emerald-300 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                {!isConnected ? (
                  <button
                    type="button"
                    onClick={handleConnect}
                    disabled={isSyncing || !deviceUrl.trim()}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl transition cursor-pointer disabled:opacity-50"
                  >
                    <Wifi className="w-3.5 h-3.5" />
                    <span>{isSyncing ? 'Bağlanıyor...' : 'Cihazı Bağla'}</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleDisconnect}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 bg-rose-900/60 hover:bg-rose-800 text-rose-200 font-bold text-xs rounded-xl border border-rose-700 transition cursor-pointer"
                  >
                    <Power className="w-3.5 h-3.5" />
                    <span>Bağlantıyı Kes</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Quick Preset Devices Picker */}
          {!isConnected && (
            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 font-bold block">
                Hızlı Test İçin Örnek Cihaz Seçin:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {PRESET_DEVICES.map((p) => (
                  <button
                    key={p.url}
                    type="button"
                    onClick={() => handleSelectPreset(p)}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-teal-500/50 text-left transition cursor-pointer group"
                  >
                    <div className="text-xs font-bold text-slate-200 group-hover:text-teal-300 flex items-center justify-between">
                      <span className="truncate">{p.name}</span>
                      <ExternalLink className="w-3 h-3 text-slate-500" />
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate">
                      {p.url}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Connected Live Telemetry Card */}
          {isConnected && telemetry && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-black text-white">{telemetry.deviceName}</span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                    4G / LoRaWAN LTE
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  Son Veri: <strong className="text-emerald-300">{telemetry.lastPingTimestamp}</strong> (Sürekli Canlı Akış)
                </div>
              </div>

              {/* 3 Telemetry Sensors */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                {/* Temp */}
                <div className={`p-2.5 rounded-xl border ${
                  telemetry.isBreached
                    ? 'bg-rose-950/60 border-rose-500/60 text-rose-200'
                    : 'bg-slate-950 border-slate-800 text-white'
                }`}>
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Sıcaklık</span>
                    <Thermometer className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <div className="text-lg font-black font-mono mt-0.5">
                    {telemetry.temperatureC > 0 ? `+${telemetry.temperatureC}` : telemetry.temperatureC} °C
                  </div>
                  <div className="text-[9px] text-slate-400 mt-0.5">
                    Hedef: {targetTempMin}°C - {targetTempMax}°C
                  </div>
                </div>

                {/* Humidity */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Bağıl Nem</span>
                    <Droplets className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <div className="text-lg font-black font-mono mt-0.5 text-blue-300">
                    %{telemetry.humidityPercent}
                  </div>
                  <div className="text-[9px] text-slate-400 mt-0.5">
                    Hedef: %90-95 RH
                  </div>
                </div>

                {/* Ethylene */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Etilen (C₂H₄)</span>
                    <Wind className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-lg font-black font-mono mt-0.5 text-emerald-300">
                    {telemetry.ethylenePpm} ppm
                  </div>
                  <div className="text-[9px] text-slate-400 mt-0.5">
                    Kritik Limit: &lt;0.05
                  </div>
                </div>

                {/* Battery & Health */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Batarya / Sinyal</span>
                    <Activity className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-lg font-black font-mono mt-0.5 text-amber-300">
                    %{telemetry.batteryPercent}
                  </div>
                  <div className="text-[9px] text-emerald-400 font-bold mt-0.5">
                    Mükemmel (12 Gün)
                  </div>
                </div>
              </div>

              {/* Breach Warning if any */}
              {telemetry.isBreached && (
                <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{telemetry.breachReason}</span>
                </div>
              )}
            </div>
          )}

        </div>
      )}

    </div>
  );
};
