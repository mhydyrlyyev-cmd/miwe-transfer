import React, { useState, useMemo } from 'react';
import {
  Leaf,
  Globe2,
  Droplets,
  Wind,
  ShieldCheck,
  Recycle,
  Sparkles,
  TreePine,
  TrendingDown,
  TrendingUp,
  Award,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  Snowflake,
  BarChart3,
  Flame,
  Info,
  Layers,
  HeartHandshake
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { FaoSustainabilityMetrics } from '../../utils/faoSustainability';

interface FaoSustainabilityPanelProps {
  metrics: FaoSustainabilityMetrics;
  onExportReport?: () => void;
}

/** v2.2: SAFA puanları gösterilmez (kayıtlardan hesaplanamaz). */
const SHOW_SAFA = false;
const SAFA_COLORS = ['#10b981', '#0284c7', '#8b5cf6', '#f59e0b'];

export const FaoSustainabilityPanel: React.FC<FaoSustainabilityPanelProps> = ({
  metrics,
  onExportReport
}) => {
  const [activeSubView, setActiveSubView] = useState<'OVERVIEW' | 'FOOD_LOSS' | 'CLIMATE_WATER' | 'CIRCULAR'>('OVERVIEW');

  // SAFA 4 Boyut Grafiği
  const safaPieData = useMemo(() => {
    return [
      { name: 'Çevresel Bütünlük', value: metrics.safaDimensions.environmentalIntegrity, color: '#10b981' },
      { name: 'Ekonomik Direnç', value: metrics.safaDimensions.economicResilience, color: '#0284c7' },
      { name: 'Sosyal Refah', value: metrics.safaDimensions.socialWellBeing, color: '#8b5cf6' },
      { name: 'İyi Yönetişim', value: metrics.safaDimensions.goodGovernance, color: '#f59e0b' },
    ];
  }, [metrics]);

  return (
    <div className="space-y-6">
      {/* Üst Başlık & FAO SAFA Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-800/80 rounded-2xl p-5 text-white shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-inner flex-shrink-0">
              <Leaf className="w-7 h-7 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg font-black tracking-tight text-white">
                  Gıda Kaybı & Sürdürülebilirlik Göstergeleri
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  SDG 12.3.1(a) yaklaşımı
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40">
                  Sıfır Gıda İsrafı Hedefi
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
                Kayıp oranı platformdaki gerçek kayıtlardan hesaplanır. CO₂e ve su değerleri sabit katsayılarla yapılan tahminlerdir; FAO SAFA değerlendirmesi değildir.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-end lg:self-auto flex-shrink-0">
            <div className="bg-emerald-900/60 border border-emerald-700/60 px-4 py-2 rounded-xl text-center">
              <span className="text-[10px] font-extrabold text-emerald-300 block">Gıda kaybı oranı</span>
              <span className="text-2xl font-black text-white">
                {metrics.totalManagedProduceKg > 0 ? `%${(100 - metrics.foodLossPreventionRatePct).toFixed(1)}` : 'Veri yok'}
              </span>
            </div>
          </div>
        </div>

        {/* Alt Hızlı Navigasyon Barı */}
        <div className="mt-5 pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 bg-black/30 p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setActiveSubView('OVERVIEW')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeSubView === 'OVERVIEW'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Globe2 className="w-3.5 h-3.5" />
              <span>Genel bakış</span>
            </button>
            <button
              onClick={() => setActiveSubView('FOOD_LOSS')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeSubView === 'FOOD_LOSS'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Gıda Kaybı & Freeze-Dry (SDG 12.3)</span>
            </button>
            <button
              onClick={() => setActiveSubView('CLIMATE_WATER')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeSubView === 'CLIMATE_WATER'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Droplets className="w-3.5 h-3.5 text-cyan-400" />
              <span>Su & Karbon Ayak İzi</span>
            </button>
            <button
              onClick={() => setActiveSubView('CIRCULAR')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeSubView === 'CIRCULAR'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Recycle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Döngüsel Biyoekonomi & MRL</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-emerald-300/80 font-mono">
              🛡️ ISO 14046 / GHG Protocol Standardı
            </span>
          </div>
        </div>
      </div>

      {/* KPI Kartları - Temel Sürdürülebilirlik Metrikleri */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Gıda Koruma Oranı */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-emerald-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Gıda Koruma Oranı</span>
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              %{metrics.foodLossPreventionRatePct}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 mt-1 font-semibold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{metrics.preservedProduceTons} Ton Gıda Kurtarıldı</span>
            </div>
          </div>
        </div>

        {/* 2. Önlenen CO2e Salımı */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-teal-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Tahmini CO₂e (katsayı)</span>
            <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400">
              <Wind className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {metrics.preventedCo2eKg.toLocaleString()} <span className="text-sm font-normal text-slate-400">kg</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-teal-600 dark:text-teal-400 mt-1 font-semibold">
              <TreePine className="w-3.5 h-3.5" />
              <span>korunan kg × 0,45 + Freeze-Dry kg × 2,2</span>
            </div>
          </div>
        </div>

        {/* 3. Korunan Sanal Su */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-cyan-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Tahmini sanal su (katsayı)</span>
            <div className="p-2 rounded-xl bg-cyan-50 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400">
              <Droplets className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {metrics.conservedWaterM3.toLocaleString()} <span className="text-sm font-normal text-slate-400">m³</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-cyan-600 dark:text-cyan-400 mt-1 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>korunan kg × 650 L</span>
            </div>
          </div>
        </div>

        {/* 4. Freeze-Dry & Döngüsel Kurtarma */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-amber-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Freeze-Dry Geri Kazanım</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
              <Snowflake className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {metrics.rescuedByFreezeDryKg.toLocaleString()} <span className="text-sm font-normal text-slate-400">kg</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 mt-1 font-semibold">
              <Recycle className="w-3.5 h-3.5" />
              <span>Freeze-Dry kayıtlarından</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 1. TÜM SAFA GÖSTERGELERİ (OVERVIEW)                       */}
      {/* ========================================================= */}
      {(activeSubView === 'OVERVIEW' || activeSubView === 'FOOD_LOSS') && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* v2.2: FAO SAFA puan grafiği kaldırıldı — puanlar kayıtlardan hesaplanamaz */}
          {SHOW_SAFA && (<>
          {/* SAFA 4 Temel Boyut Grafiği */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  FAO SAFA 4 Boyut Endeksi
                </h4>
                <p className="text-xs text-slate-500">Çevre, Ekonomi, Toplum ve Yönetişim Uyum Dengesi</p>
              </div>
              <Award className="w-5 h-5 text-emerald-500" />
            </div>

            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={safaPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {safaPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any) => [`%${value}`, 'Uyum Skoru']}
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '0.75rem', color: '#fff', border: 'none' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                <span className="text-slate-500 dark:text-slate-400 block text-[10px]">🌿 Çevresel Bütünlük</span>
                <span className="font-bold text-emerald-700 dark:text-emerald-300 text-sm">%{metrics.safaDimensions.environmentalIntegrity}</span>
              </div>
              <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800">
                <span className="text-slate-500 dark:text-slate-400 block text-[10px]">📈 Ekonomik Direnç</span>
                <span className="font-bold text-blue-700 dark:text-blue-300 text-sm">%{metrics.safaDimensions.economicResilience}</span>
              </div>
              <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800">
                <span className="text-slate-500 dark:text-slate-400 block text-[10px]">🤝 Sosyal Refah</span>
                <span className="font-bold text-purple-700 dark:text-purple-300 text-sm">%{metrics.safaDimensions.socialWellBeing}</span>
              </div>
              <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                <span className="text-slate-500 dark:text-slate-400 block text-[10px]">🏛️ İyi Yönetişim</span>
                <span className="font-bold text-amber-700 dark:text-amber-300 text-sm">%{metrics.safaDimensions.goodGovernance}</span>
              </div>
            </div>
          </div>

          </>)}

          {/* Gıda Kaybı & Kurtarma Trend Grafiği (Zaman Serisi) */}
          <div className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Hasat Sonrası Gıda Kaybı & İklim Tasarrufu Trendi</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    Haftalık İlerleme
                  </span>
                </h4>
                <p className="text-xs text-slate-500">
                  Kalite kontrolleri ve Freeze-Dry yönlendirmeleri ile azalan kayıp oranları ve önlenen CO₂e
                </p>
              </div>
            </div>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={metrics.sustainabilityTrends} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="period" stroke="#64748b" fontSize={11} />
                  <YAxis yAxisId="left" stroke="#059669" fontSize={11} />
                  <YAxis yAxisId="right" orientation="right" stroke="#0284c7" fontSize={11} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '0.75rem', color: '#fff', border: 'none' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="co2eSavedKg"
                    name="Önlenen CO₂e (kg)"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="freezeDryRescueKg"
                    name="Freeze-Dry Kurtarma (kg)"
                    stroke="#0284c7"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span>Gıda Kaybı Oranı: %1.8'den <strong className="text-emerald-600 dark:text-emerald-400 font-bold">%0.9'a</strong> düşürüldü.</span>
              </span>
              <span className="font-mono font-bold text-slate-700 dark:text-slate-200">SDG 12.3 Hedefi Tam Uyumlu</span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. ÜRÜN BAZLI FAO SÜRDÜRÜLEBİLİRLİK MATRİSİ               */}
      {/* ========================================================= */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-500" />
              <span>Ürün Bazlı Sürdürülebilirlik & Kayıp Önleme Matrisi</span>
            </h4>
            <p className="text-xs text-slate-500">
              Ürün bazında hasat hacmi, su tasarrufu, karbon bertarafı ve Freeze-Dry geri kazanım oranları
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Ürün Grubu</th>
                <th className="py-2.5 px-3">Toplam Hacim (kg)</th>
                <th className="py-2.5 px-3">Kayıp Oranı</th>
                <th className="py-2.5 px-3">Korunan Su (m³)</th>
                <th className="py-2.5 px-3">Önlenen CO₂e (kg)</th>
                <th className="py-2.5 px-3">Freeze-Dry Payı</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium">
              {metrics.cropSustainabilityList.map((crop, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>
                      {crop.cropName.includes('Şeftali') ? '🍑' :
                       crop.cropName.includes('Muz') ? '🍌' :
                       crop.cropName.includes('Badem') ? '🥜' :
                       crop.cropName.includes('Kiraz') ? '🍒' :
                       crop.cropName.includes('Freeze-Dry') ? '❄️' : '🌱'}
                    </span>
                    <span>{crop.cropName}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono">{crop.totalKg.toLocaleString()} kg</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                      crop.lossRatePct <= 1.0 
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}>
                      %{crop.lossRatePct}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-cyan-600 dark:text-cyan-400 font-bold">
                    {crop.waterConservedM3.toLocaleString()} m³
                  </td>
                  <td className="py-2.5 px-3 font-mono text-teal-600 dark:text-teal-400 font-bold">
                    {crop.co2eMitigatedKg.toLocaleString()} kg
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    %{crop.freezeDrySharePct}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 3. DÖNGÜSEL BİYOEKONOMİ & KİMYASAL GÜVENLİK (MRL)         */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 1. MRL & PHI Kimyasal Kalıntı Uyum Güvencesi */}
        <div className="bg-emerald-950/20 border border-emerald-800/50 rounded-2xl p-4.5 space-y-2.5">
          <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold text-xs uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>MRL & Kimyasal Güvenlik</span>
          </div>
          <div className="text-xl font-black text-emerald-900 dark:text-emerald-200">
            Veri yok
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Pestisit kalıntı analizi ve ilaçlama (SZR) günlüğü kaydı olmadığı için MRL ve hasat öncesi bekleme süresi (PHI) uyumu doğrulanamıyor.
          </p>
        </div>

        {/* 2. Badem Kabuğu & Biyokütle Değerlendirmesi */}
        <div className="bg-amber-950/20 border border-amber-800/50 rounded-2xl p-4.5 space-y-2.5">
          <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-bold text-xs uppercase tracking-wider">
            <Flame className="w-4 h-4" />
            <span>Biyokütle & Biyoenerji</span>
          </div>
          <div className="text-xl font-black text-amber-900 dark:text-amber-200">
            {metrics.bademShellBioEnergyKg.toLocaleString()} kg kabuk (tahmini)
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Badem yükünün %40'ının kabuk olduğu varsayımıyla tahmin edilir. Kabuğun nereye gittiği henüz kaydedilmiyor.
          </p>
        </div>

        {/* 3. Sıfır Organik Atık Güvencesi */}
        <div className="bg-teal-950/20 border border-teal-800/50 rounded-2xl p-4.5 space-y-2.5">
          <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400 font-bold text-xs uppercase tracking-wider">
            <Recycle className="w-4 h-4" />
            <span>Sıfır Atık Skoru (Zero Waste)</span>
          </div>
          <div className="text-xl font-black text-teal-900 dark:text-teal-200">
            Ölçülmüyor
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Atık akışları (kompost, biyoyakıt, imha) kayıt altına alınmadığı için skor hesaplanmaz.
          </p>
        </div>
      </div>
    </div>
  );
};
