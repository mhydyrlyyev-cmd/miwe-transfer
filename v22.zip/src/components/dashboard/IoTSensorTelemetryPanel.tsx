import React, { useState, useEffect, useRef } from 'react';
import DemoBadge from '../common/DemoBadge';
import {
  Radio,
  Wifi,
  WifiOff,
  AlertTriangle,
  CheckCircle2,
  Thermometer,
  Droplets,
  Wind,
  Activity,
  Maximize2,
  Minimize2,
  RefreshCw,
  BellRing,
  Volume2,
  VolumeX,
  Snowflake,
  Flame,
  Truck,
  Warehouse,
  ShieldAlert,
  Sliders,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

export interface TelemetryPoint {
  timestamp: string;
  tempC: number;
  humidityPercent: number;
  co2Ppm?: number;
  o2Percent?: number;
  ethylenePpm?: number;
}

export interface ColdRoomSensor {
  id: string;
  roomName: string;
  roomType: 'APPLE_CA' | 'BANANA_RIPENING' | 'ALMOND_DRY' | 'REEFER_TRUCK';
  product: string;
  targetTempC: number;
  tempToleranceC: number;
  targetHumidityPercent: number;
  humidityTolerancePercent: number;
  currentTempC: number;
  currentHumidityPercent: number;
  currentCo2Ppm?: number;
  currentO2Percent?: number;
  currentEthylenePpm?: number;
  status: 'OPTIMAL' | 'WARNING' | 'CRITICAL';
  sensorBatteryPercent: number;
  lastPacketTime: string;
  history: TelemetryPoint[];
  deviceModel: string;
}

interface IoTSensorTelemetryPanelProps {
  onTriggerAlarm?: (message: string) => void;
  isCompactModeDefault?: boolean;
}

export const IoTSensorTelemetryPanel: React.FC<IoTSensorTelemetryPanelProps> = ({
  onTriggerAlarm,
  isCompactModeDefault = false
}) => {
  const [isWebSocketConnected, setIsWebSocketConnected] = useState<boolean>(true);
  const [pingMs, setPingMs] = useState<number>(24);
  const [packetCount, setPacketCount] = useState<number>(1420);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(!isCompactModeDefault);
  const [selectedSensorId, setSelectedSensorId] = useState<string>('ROOM-CA-01');

  // Initial Sensors definition
  const [sensors, setSensors] = useState<ColdRoomSensor[]>([
    {
      id: 'ROOM-CA-01',
      roomName: 'Ambar Soğuk CA Odası #1 (Elma)',
      roomType: 'APPLE_CA',
      product: 'Gala & Golden Elma',
      targetTempC: 1.5,
      tempToleranceC: 0.5,
      targetHumidityPercent: 92,
      humidityTolerancePercent: 3,
      currentTempC: 1.6,
      currentHumidityPercent: 91.8,
      currentCo2Ppm: 1200,
      currentO2Percent: 1.8,
      currentEthylenePpm: 0.02,
      status: 'OPTIMAL',
      sensorBatteryPercent: 98,
      lastPacketTime: 'Şimdi',
      history: [
        { timestamp: '10:00', tempC: 1.5, humidityPercent: 92 },
        { timestamp: '10:05', tempC: 1.6, humidityPercent: 91.9 },
        { timestamp: '10:10', tempC: 1.5, humidityPercent: 92.1 },
        { timestamp: '10:15', tempC: 1.7, humidityPercent: 91.5 },
        { timestamp: '10:20', tempC: 1.6, humidityPercent: 91.8 }
      ],
      deviceModel: 'Sensitech TempTale Ultra BLE'
    },
    {
      id: 'ROOM-BANANA-03',
      roomName: 'Muz MAP & Olgunlaştırma Odası #3',
      roomType: 'BANANA_RIPENING',
      product: 'Cavendish Yeşil Muz',
      targetTempC: 14.5,
      tempToleranceC: 0.8,
      targetHumidityPercent: 88,
      humidityTolerancePercent: 4,
      currentTempC: 14.7,
      currentHumidityPercent: 87.5,
      currentCo2Ppm: 2450,
      currentEthylenePpm: 1.25,
      status: 'OPTIMAL',
      sensorBatteryPercent: 94,
      lastPacketTime: 'Şimdi',
      history: [
        { timestamp: '10:00', tempC: 14.4, humidityPercent: 88.2 },
        { timestamp: '10:05', tempC: 14.6, humidityPercent: 87.9 },
        { timestamp: '10:10', tempC: 14.5, humidityPercent: 88.0 },
        { timestamp: '10:15', tempC: 14.8, humidityPercent: 87.2 },
        { timestamp: '10:20', tempC: 14.7, humidityPercent: 87.5 }
      ],
      deviceModel: 'Emerson GO Real-Time CA/Ethylene'
    },
    {
      id: 'ROOM-ALMOND-02',
      roomName: 'Badem & Kuru Meyve Deposu #2',
      roomType: 'ALMOND_DRY',
      product: 'Kabuklu Nonpareil Badem',
      targetTempC: 18.0,
      tempToleranceC: 2.0,
      targetHumidityPercent: 52,
      humidityTolerancePercent: 5,
      currentTempC: 18.2,
      currentHumidityPercent: 51.5,
      status: 'OPTIMAL',
      sensorBatteryPercent: 100,
      lastPacketTime: 'Şimdi',
      history: [
        { timestamp: '10:00', tempC: 18.0, humidityPercent: 52.0 },
        { timestamp: '10:05', tempC: 18.1, humidityPercent: 51.8 },
        { timestamp: '10:10', tempC: 18.3, humidityPercent: 51.6 },
        { timestamp: '10:15', tempC: 18.2, humidityPercent: 51.4 },
        { timestamp: '10:20', tempC: 18.2, humidityPercent: 51.5 }
      ],
      deviceModel: 'Tive Solo 5G Wireless Aw'
    },
    {
      id: 'REEFER-TRUCK-74',
      roomName: 'Frigo Tır Transit Dorse (74-AG-210)',
      roomType: 'REEFER_TRUCK',
      product: 'İhracat Elma & Şeftali',
      targetTempC: 3.0,
      tempToleranceC: 1.0,
      targetHumidityPercent: 85,
      humidityTolerancePercent: 5,
      currentTempC: 3.3,
      currentHumidityPercent: 84.8,
      status: 'OPTIMAL',
      sensorBatteryPercent: 91,
      lastPacketTime: 'Şimdi',
      history: [
        { timestamp: '10:00', tempC: 3.1, humidityPercent: 85.0 },
        { timestamp: '10:05', tempC: 3.2, humidityPercent: 84.9 },
        { timestamp: '10:10', tempC: 3.0, humidityPercent: 85.2 },
        { timestamp: '10:15', tempC: 3.4, humidityPercent: 84.6 },
        { timestamp: '10:20', tempC: 3.3, humidityPercent: 84.8 }
      ],
      deviceModel: 'Carrier Transicold DataCOLD 600'
    }
  ]);

  // Live WebSocket Simulation ticker
  useEffect(() => {
    if (!isWebSocketConnected) return;

    const interval = setInterval(() => {
      setPacketCount(p => p + 1);
      setPingMs(Math.floor(20 + Math.random() * 15));

      setSensors(prevSensors =>
        prevSensors.map(sensor => {
          let jitterTemp = (Math.random() - 0.5) * 0.15;
          let jitterHum = (Math.random() - 0.5) * 0.3;

          const newTemp = Number((sensor.currentTempC + jitterTemp).toFixed(2));
          const newHum = Number(
            Math.max(30, Math.min(99, sensor.currentHumidityPercent + jitterHum)).toFixed(1)
          );

          // Quality limits check
          const tempDiff = Math.abs(newTemp - sensor.targetTempC);
          let newStatus: 'OPTIMAL' | 'WARNING' | 'CRITICAL' = 'OPTIMAL';
          if (tempDiff > sensor.tempToleranceC * 2) {
            newStatus = 'CRITICAL';
          } else if (tempDiff > sensor.tempToleranceC) {
            newStatus = 'WARNING';
          }

          const nowTime = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          const newHistory = [
            ...sensor.history.slice(-15),
            { timestamp: nowTime, tempC: newTemp, humidityPercent: newHum }
          ];

          return {
            ...sensor,
            currentTempC: newTemp,
            currentHumidityPercent: newHum,
            status: newStatus,
            lastPacketTime: nowTime,
            history: newHistory
          };
        })
      );
    }, 2500);

    return () => clearInterval(interval);
  }, [isWebSocketConnected, selectedSensorId]);

  const activeSensor = sensors.find(s => s.id === selectedSensorId) || sensors[0];

  const hasAnyCritical = sensors.some(s => s.status === 'CRITICAL');
  const hasAnyWarning = sensors.some(s => s.status === 'WARNING');

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden transition-all text-slate-100">
      
      {/* PANEL HEADER */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-xl flex items-center justify-center transition-colors ${
            hasAnyCritical
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse'
              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
          }`}>
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-black text-white tracking-tight">
                Canlı IoT Sensör &amp; Soğuk Depo Telemetrisi
              </h3>
              <DemoBadge note="simülasyon" />
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono flex items-center gap-1 ${
                isWebSocketConnected
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
              }`}>
                {isWebSocketConnected ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-rose-400" />}
                <span>{isWebSocketConnected ? `WebSocket Canlı (${pingMs}ms)` : 'Bağlantı Kesildi'}</span>
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              SCADA, Sensitech &amp; BLE Datalogger telemetrisi (Sıcaklık, Bağıl Nem, CO₂, O₂, C₂H₄)
            </p>
          </div>
        </div>

        {/* CONTROLS */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsWebSocketConnected(prev => !prev)}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              isWebSocketConnected
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
            title="WebSocket Bağlantısını Aç/Kapat"
          >
            {isWebSocketConnected ? 'Kopart' : 'Yeniden Bağlan'}
          </button>



          <button
            type="button"
            onClick={() => setIsExpanded(prev => !prev)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
            title={isExpanded ? 'Paneli Küçült' : 'Paneli Genişlet'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* QUICK STATUS BAR FOR 4 ROOMS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 p-3 bg-slate-950/60 border-b border-slate-800/80">
        {sensors.map(sensor => {
          const isSelected = sensor.id === selectedSensorId;
          const isCrit = sensor.status === 'CRITICAL';
          const isWarn = sensor.status === 'WARNING';
          return (
            <button
              key={sensor.id}
              type="button"
              onClick={() => setSelectedSensorId(sensor.id)}
              className={`p-2.5 rounded-xl text-left transition cursor-pointer border ${
                isSelected
                  ? 'bg-slate-800/90 border-emerald-500/60 ring-1 ring-emerald-500/40'
                  : 'bg-slate-900/60 hover:bg-slate-850 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                <span className="font-bold truncate max-w-[120px]">{sensor.roomName.split(' ')[0]}</span>
                <span className={`w-2 h-2 rounded-full ${
                  isCrit ? 'bg-rose-500 animate-ping' : isWarn ? 'bg-amber-400' : 'bg-emerald-400'
                }`} />
              </div>
              <div className="flex items-baseline justify-between">
                <div className="text-base sm:text-lg font-black font-mono text-white">
                  {sensor.currentTempC > 0 ? `+${sensor.currentTempC}` : sensor.currentTempC}°C
                </div>
                <div className="text-xs font-mono text-slate-400">
                  %{sensor.currentHumidityPercent} RH
                </div>
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">
                Hedef: {sensor.targetTempC}°C (±{sensor.tempToleranceC})
              </div>
            </button>
          );
        })}
      </div>

      {/* EXPANDED DETAILED INSPECTOR */}
      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4">
          
          {/* Active Sensor Live Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-base font-black text-white">{activeSensor.roomName}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                  {activeSensor.deviceModel}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  activeSensor.status === 'CRITICAL'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : activeSensor.status === 'WARNING'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {activeSensor.status === 'CRITICAL' ? '🚨 KRİTİK REJİM AŞIMI' : activeSensor.status === 'WARNING' ? '⚠️ SINIR DEĞER' : '✅ İDEAL KOŞUL'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Muhafaza Edilen: <strong className="text-slate-200">{activeSensor.product}</strong> • Son Telemetri Paketi: <span className="font-mono text-emerald-400">{activeSensor.lastPacketTime}</span>
              </p>
            </div>

            {/* Live Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <span className="text-[10px] font-bold uppercase text-slate-400 flex items-center justify-center gap-1">
                  <Thermometer className="w-3 h-3 text-rose-400" /> Sıcaklık
                </span>
                <div className="text-lg font-black font-mono text-white mt-0.5">
                  {activeSensor.currentTempC > 0 ? `+${activeSensor.currentTempC}` : activeSensor.currentTempC}°C
                </div>
                <span className="text-[9px] text-slate-500">Hedef: {activeSensor.targetTempC}°C</span>
              </div>

              <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <span className="text-[10px] font-bold uppercase text-slate-400 flex items-center justify-center gap-1">
                  <Droplets className="w-3 h-3 text-cyan-400" /> Bağıl Nem
                </span>
                <div className="text-lg font-black font-mono text-cyan-300 mt-0.5">
                  %{activeSensor.currentHumidityPercent}
                </div>
                <span className="text-[9px] text-slate-500">Hedef: %{activeSensor.targetHumidityPercent}</span>
              </div>

              {activeSensor.currentCo2Ppm !== undefined && (
                <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-bold uppercase text-slate-400 flex items-center justify-center gap-1">
                    <Wind className="w-3 h-3 text-amber-400" /> Karbondioksit
                  </span>
                  <div className="text-lg font-black font-mono text-amber-300 mt-0.5">
                    {activeSensor.currentCo2Ppm} ppm
                  </div>
                  <span className="text-[9px] text-slate-500">Gazlama / Solunum</span>
                </div>
              )}

              {activeSensor.currentEthylenePpm !== undefined && (
                <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-bold uppercase text-slate-400 flex items-center justify-center gap-1">
                    <Flame className="w-3 h-3 text-purple-400" /> Etilen (C₂H₄)
                  </span>
                  <div className="text-lg font-black font-mono text-purple-300 mt-0.5">
                    {activeSensor.currentEthylenePpm} ppm
                  </div>
                  <span className="text-[9px] text-slate-500">MAP Şase Absorber</span>
                </div>
              )}
            </div>
          </div>

          {/* SVG Real-Time Sparkline Chart */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>Canlı Sıcaklık &amp; Nem Trend Eğrisi (Son 15 Okuma)</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Paket Akışı: #{packetCount}
              </span>
            </div>

            {/* Sparkline Canvas rendering */}
            <div className="h-28 w-full relative flex items-end pt-4 pb-2">
              <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 50">
                {/* Safe band rectangle */}
                <rect x="0" y="15" width="100" height="20" fill="rgba(16, 185, 129, 0.08)" />

                {/* Temperature Polyline */}
                <polyline
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={activeSensor.history
                    .map((pt, idx) => {
                      const x = (idx / Math.max(1, activeSensor.history.length - 1)) * 100;
                      // Normalize temp around target
                      const delta = pt.tempC - activeSensor.targetTempC;
                      const y = Math.max(5, Math.min(45, 25 - delta * 10));
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />

                {/* Humidity Polyline */}
                <polyline
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                  strokeDasharray="2,2"
                  points={activeSensor.history
                    .map((pt, idx) => {
                      const x = (idx / Math.max(1, activeSensor.history.length - 1)) * 100;
                      const delta = pt.humidityPercent - activeSensor.targetHumidityPercent;
                      const y = Math.max(5, Math.min(45, 30 - delta * 2));
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />
              </svg>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-2 border-t border-slate-800">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-2.5 h-0.5 bg-emerald-400 inline-block" /> Sıcaklık (°C)
                </span>
                <span className="flex items-center gap-1 text-sky-400">
                  <span className="w-2.5 h-0.5 bg-sky-400 border-dashed inline-block" /> Bağıl Nem (%RH)
                </span>
              </div>
              <span>Sensör Pil: %{activeSensor.sensorBatteryPercent}</span>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
