import React, { useState, useEffect, useRef, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  ExportSampleRecord,
  SalesRecord,
  IncidentRecord,
  FreezeDryRecord,
  CustomFieldDefinition,
  ModuleKey,
  ReferenceStatus,
  SystemStats,
  ActiveFieldContext
} from './types';
import {
  INITIAL_REFERENCES,
  INITIAL_HARVEST_RECORDS,
  INITIAL_FIELD_RECORDS,
  INITIAL_MUZ_RECORDS,
  INITIAL_BADEM_RECORDS,
  INITIAL_LOJISTIK_RECORDS,
  INITIAL_AMBAR_RECORDS,
  INITIAL_EXPORT_SAMPLE_RECORDS,
  INITIAL_SALES_RECORDS,
  INITIAL_INCIDENT_RECORDS,
  INITIAL_FREEZE_DRY_RECORDS,
  INITIAL_FEEDBACKS
} from './data/initialData';
import { savePhoto, deletePhoto, PhotoRecord, safeLocalStorageSetItem, markPhotoSynced } from './utils/db';
import { calculateSystemStats, calculateFieldBreakdown, submitFeedbackToGas, generateFlatSchema } from './utils/calculations';
import { validateConsistency, removeReferenceAndDependents, DataStoreState } from './utils/consistency';
import { addDebugLog } from './utils/debugLogger';
import { FeedbackRecord, FeedbackStatus } from './types';
import { syncCentralAppDataWithServer, saveRecordToCentralServer, deleteReferenceFromCentralServer, recordCentralAuditLog, uploadPhotoToServer, CentralAppData } from './utils/syncService';
import {
  subscribeToAllAppDataOnSnapshot,
  resetAllAppDataInFirestore,
  subscribeToUsersOnSnapshot,
  fetchAllAppDataFromServer,
  fetchUsersFromServer
} from './lib/firestoreService';
import { loadGanttData, saveGanttData, updateParcelHarvestedTonnage, GanttParcelItem } from './data/ganttData';
import { syncQualityOrDelilnamaToHarvestCalendar } from './data/miwe2026Schema';
import { GlobalPlatformProvider } from './context/GlobalPlatformContext';
import { portalEventBus } from './utils/portalEventBus';

// Components
import { Header } from './components/Header';
import { MobileBottomBar } from './components/common/MobileBottomBar';
import { ScrollToTopButton } from './components/common/ScrollToTopButton';
import { DashboardStats } from './components/DashboardStats';
import { ModuleCards } from './components/ModuleCards';
import { DailyHarvestForm } from './components/forms/DailyHarvestForm';
import { FieldForm } from './components/forms/FieldForm';
import { MuzForm } from './components/forms/MuzForm';
import { BademForm } from './components/forms/BademForm';
import { LojistikForm } from './components/forms/LojistikForm';
import { AmbarForm } from './components/forms/AmbarForm';
import { ExportSampleForm } from './components/forms/ExportSampleForm';
import { SalesForm } from './components/forms/SalesForm';
import { IncidentForm } from './components/forms/IncidentForm';
import { FreezeDryForm } from './components/forms/FreezeDryForm';
import { ReferencesView } from './components/views/ReferencesView';
import { GalleryView } from './components/views/GalleryView';
import { PendingOperationsView } from './components/views/PendingOperationsView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { MonthlyQualityReportView } from './components/views/MonthlyQualityReportView';
import SummaryView from './components/views/SummaryView';
import { HarvestPlanningPortal } from './components/portal/HarvestPlanningPortal';
import { QualityRoadmapPortal } from './components/portal/QualityRoadmapPortal';
import { AdminSystemPortal } from './components/portal/AdminSystemPortal';
import { PortalLauncher } from './components/portal/PortalLauncher';
import { PresentationReportWizard } from './components/portal/PresentationReportWizard';
import { ReportingPresentationPortal } from './components/portal/ReportingPresentationPortal';
import { GlobalPlatformFooter } from './components/common/GlobalPlatformFooter';
import { AuditTrailView } from './components/admin/AuditTrailView';
import { PendingSyncCard } from './components/dashboard/PendingSyncCard';
import { QualityInsightCard } from './components/dashboard/QualityInsightCard';
import { SyncModal } from './components/sync/SyncModal';
import { FeedbackView } from './components/views/FeedbackView';
import { SystemDiagnosticsView } from './components/views/SystemDiagnosticsView';
import { TraceabilityModal } from './components/views/TraceabilityModal';
import { TraceabilityLedgerView } from './components/views/TraceabilityLedgerView';
import { VisualStandardsProofModal } from './components/common/VisualStandardsProofModal';
import { MultiPagePdfReportModal } from './components/views/MultiPagePdfReportModal';
import { CustomFieldsModal } from './components/CustomFieldsModal';
import { GasSetupModal } from './components/GasSetupModal';
import { ShareModal } from './components/ShareModal';
import { GuideModal } from './components/GuideModal';
import { GuidePortal } from './components/portal/GuidePortal';
import { AdminPasswordModal } from './components/portal/AdminPasswordModal';
import { AiVisionFruitInspectorModal } from './components/common/AiVisionFruitInspectorModal';
import { AppUser } from './types/auth';
import { getSyncSettings, shouldAllowAutoSync } from './utils/syncSettings';
import { getCurrentUser, logoutUser, logActivity, getUsers, startAutoSync, subscribeToUsersSync, authFetch, restoreUsersFromServer, isAdminAuthenticated, getSessionToken, performSessionAudit, SessionAuditResult, onAuthFailure } from './utils/authService';
import { LoginView } from './components/auth/LoginView';
import { AdminUserManagementModal } from './components/auth/AdminUserManagementModal';
import { UserProfileModal } from './components/auth/UserProfileModal';
import { CreateNotificationModal } from './components/notifications/CreateNotificationModal';
import { addNotification } from './utils/notificationService';
import { AlertTriangle, Leaf, ShieldCheck, Globe, Mail, Phone, MapPin, BookOpen, Trash2, ExternalLink, RefreshCw } from 'lucide-react';
import { useToast } from './context/ToastContext';

/** Mimari v2: Google Sheets tek yönlü rapor aynasıdır (Firestore → Sheets). İstemci tabloya yazmaz. */
const SHEETS_PUSH_ENABLED = false;

export function App() {
  const { showSuccess, showError, showInfo, showWarning } = useToast();
  // Authentication & Role-Based Access State
  // Önbellekteki profil yalnızca hızlı açılış içindir; Firebase oturumu doğrulamazsa onAuthFailure ile düşer
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => getCurrentUser());
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [usersVersion, setUsersVersion] = useState(0);
  const [dismissedPasswordWarning, setDismissedPasswordWarning] = useState(false);
  const [showPasifReaderBanner, setShowPasifReaderBanner] = useState(() => {
    return !sessionStorage.getItem('miwe_pasif_reader_banner_dismissed');
  });

  const isReadOnlyUser = currentUser?.status === 'PASIF_READER' || (currentUser && currentUser.role !== 'ADMIN' && currentUser.permissions?.canEdit === false);

  // Güncel kullanıcıyı ref içinde tutarak re-subscription yarış durumlarını ve stale closure'ları engelle
  const currentUserRef = useRef<AppUser | null>(currentUser);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  // Oturum kapatma işleminin mükerrer veya çakışmalı çalışmasını engelleyen kilit
  const isLoggingOutRef = useRef<boolean>(false);

  // Background server sync setup & user roster restoration on startup
  useEffect(() => {
    // Firebase oturumu kapandığında (başka cihazdan çıkış, hesap silinmesi, token süresi) arayüzü kapat
    const offAuth = onAuthFailure(() => {
      currentUserRef.current = null;
      setCurrentUser(null);
    });
    return offAuth;
  }, []);

  useEffect(() => {
    restoreUsersFromServer().catch(() => {});
    startAutoSync();

    const unsubscribe = subscribeToUsersSync((updatedUsers) => {
      setUsersVersion(v => v + 1);

      const user = currentUserRef.current;
      // Oturum açık ve aktif bir logout işlemi devam etmiyorsa kullanıcı durumunu denetle
      if (user && !isLoggingOutRef.current) {
        const fresh = updatedUsers.find(u => u.id === user.id);
        if (fresh) {
          // Eğer yönetici harici bir kullanıcının durumu PASIF_READER yapıldıysa veya onay durumu kaybedildiyse:
          // Oturumu anında, state güncellemeleriyle çakışmadan ve temiz şekilde kapat
          // PASIF_READER salt-okunur kullanıcıdır; oturumu kapatılmaz, sadece yetkileri güncellenir
          const isApprovalRevoked = fresh.role !== 'ADMIN' && fresh.status !== 'APPROVED' && fresh.status !== 'PASIF_READER';

          if (isApprovalRevoked) {
            isLoggingOutRef.current = true;
            currentUserRef.current = null;
            logoutUser();
            setCurrentUser(null);
            showWarning(
              'Hesabınızın onay veya erişim durumu yönetici tarafından güncellendi (Onay geri alındı veya pasife alındı). Oturumunuz güvenle sonlandırıldı.',
              'Oturum Kapatıldı'
            );
            // Sonraki oturum açma istekleri için kilidi güvenli şekilde sıfırla
            setTimeout(() => {
              isLoggingOutRef.current = false;
            }, 800);
          } else {
            // Kullanıcı halen APPROVED ise sadece gerçek veri değişikliklerinde state'i güncelle (gereksiz render önlenir)
            const hasChanged =
              user.status !== fresh.status ||
              user.role !== fresh.role ||
              JSON.stringify(user.permissions) !== JSON.stringify(fresh.permissions) ||
              JSON.stringify(user.allowedModules) !== JSON.stringify(fresh.allowedModules) ||
              user.fullName !== fresh.fullName ||
              user.company !== fresh.company ||
              user.jobTitle !== fresh.jobTitle;

            if (hasChanged) {
              currentUserRef.current = fresh;
              setCurrentUser(fresh);
            }
          }
        }
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // F5 Yenileme ve Başlangıç Doğrulaması: localStorage 'miwe_admin_auth' ve 'miwe_session_token' durumunu denetle
  const [sessionAudit, setSessionAudit] = useState<SessionAuditResult | null>(() => {
    return typeof window !== 'undefined' ? performSessionAudit() : null;
  });

  const handleRevalidateSession = () => {
    const result = performSessionAudit();
    setSessionAudit(result);
    if (result.status === 'VALID') {
      showSuccess('Oturum tokenı ve localStorage anahtarları başarıyla doğrulandı.', 'Oturum Doğrulandı');
    } else if (result.status === 'ERROR') {
      showError(result.statusMessage, 'Oturum Hatası');
    } else {
      showWarning(result.statusMessage, 'Oturum Durumu');
    }
  };

  useEffect(() => {
    const result = performSessionAudit();
    setSessionAudit(result);
  }, [currentUser]);

  const handleLogout = () => {
    if (currentUser) {
      logActivity(currentUser, 'LOGOUT', 'DASHBOARD', 'Kullanıcı sistemden güvenli çıkış yaptı');
    }
    logoutUser();
    setCurrentUser(null);
    setSessionAudit(performSessionAudit());
  };

  // Versioned clean slate enforcement (KULLANICI VERİLERİ KALICI KORUNUR)
  const CURRENT_APP_VERSION = '2026.10.26.01';
  useEffect(() => {
    const lastVersion = localStorage.getItem('miwe_app_version');
    if (lastVersion !== CURRENT_APP_VERSION) {
      // Yalnızca geçici demo/form verilerini temizle; miwe_platform_users ve kullanıcı oturumları ASLA silinmez!
      [
        'miwe_references',
        'miwe_harvest_records',
        'miwe_field_records',
        'miwe_muz_records',
        'miwe_badem_records',
        'miwe_lojistik_records',
        'miwe_ambar_records',
        'miwe_export_sample_records',
        'miwe_sales_records',
        'miwe_incident_records',
        'miwe_freeze_dry_records',
        'miwe_feedbacks',
        'MIWE_2026_PORTAL_SCHEMA_V3',
        'MIWE_2027_PORTAL_SCHEMA_V3'
      ].forEach(k => localStorage.removeItem(k));
      
      localStorage.setItem('miwe_app_version', CURRENT_APP_VERSION);
      // Sunucudaki kullanıcıları otomatik kurtar
      restoreUsersFromServer().catch(() => {});
    }
  }, []);

  // Cleanup orphaned (ghost) storage records
  const cleanupOrphanedStorage = (currentReferences: ReferenceItem[]) => {
    const activeRefIds = new Set(currentReferences.map(r => r.refId));
    const storageKeys = [
      'miwe_harvest_records', 'miwe_field_records', 'miwe_muz_records',
      'miwe_badem_records', 'miwe_lojistik_records', 'miwe_ambar_records',
      'miwe_export_sample_records', 'miwe_sales_records', 'miwe_incident_records',
      'miwe_freeze_dry_records'
    ];
    storageKeys.forEach(key => {
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const records = JSON.parse(saved);
          if (Array.isArray(records)) {
            const filtered = records.filter((r: any) => activeRefIds.has(r.refId));
            if (filtered.length !== records.length) {
              safeLocalStorageSetItem(key, JSON.stringify(filtered));
            }
          }
        } catch (e) { /* silent */ }
      }
    });
  };

  // 1. Core State Persistence (Clean Slate for Trial Testing)
  const [references, setReferences] = useState<ReferenceItem[]>(() => {
    const saved = localStorage.getItem('miwe_references');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    cleanupOrphanedStorage(references);
  }, [references]);

  // Debug hook to detect and report orphaned records
  useEffect(() => {
    const checkOrphans = () => {
      const activeRefIds = new Set(references.map(r => r.refId));
      const storageKeys = [
        'miwe_harvest_records', 'miwe_field_records', 'miwe_muz_records',
        'miwe_badem_records', 'miwe_lojistik_records', 'miwe_ambar_records',
        'miwe_export_sample_records', 'miwe_sales_records', 'miwe_incident_records',
        'miwe_freeze_dry_records'
      ];
      
      storageKeys.forEach(key => {
        const saved = localStorage.getItem(key);
        if (saved) {
          try {
            const records = JSON.parse(saved);
            if (Array.isArray(records)) {
              const orphans = records.filter((r: any) => !activeRefIds.has(r.refId));
              if (orphans.length > 0) {
                console.warn(`[DebugEffect] Orphaned records found in ${key}:`, orphans);
              }
            }
          } catch (e) {
            console.error(`[DebugEffect] Error parsing ${key}:`, e);
          }
        }
      });
    };
    
    checkOrphans();
  }, [references]);


  const [harvestRecords, setHarvestRecords] = useState<HarvestRecord[]>(() => {
    const saved = localStorage.getItem('miwe_harvest_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [fieldRecords, setFieldRecords] = useState<FieldRecord[]>(() => {
    const saved = localStorage.getItem('miwe_field_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [muzRecords, setMuzRecords] = useState<MuzRecord[]>(() => {
    const saved = localStorage.getItem('miwe_muz_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [bademRecords, setBademRecords] = useState<BademRecord[]>(() => {
    const saved = localStorage.getItem('miwe_badem_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [lojistikRecords, setLojistikRecords] = useState<LojistikRecord[]>(() => {
    const saved = localStorage.getItem('miwe_lojistik_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [ambarRecords, setAmbarRecords] = useState<AmbarRecord[]>(() => {
    const saved = localStorage.getItem('miwe_ambar_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [exportSampleRecords, setExportSampleRecords] = useState<ExportSampleRecord[]>(() => {
    const saved = localStorage.getItem('miwe_export_sample_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [salesRecords, setSalesRecords] = useState<SalesRecord[]>(() => {
    const saved = localStorage.getItem('miwe_sales_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [incidentRecords, setIncidentRecords] = useState<IncidentRecord[]>(() => {
    const saved = localStorage.getItem('miwe_incident_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [freezeDryRecords, setFreezeDryRecords] = useState<FreezeDryRecord[]>(() => {
    const saved = localStorage.getItem('miwe_freeze_dry_records');
    return saved ? JSON.parse(saved) : [];
  });

  const [feedbacks, setFeedbacks] = useState<FeedbackRecord[]>(() => {
    const saved = localStorage.getItem('miwe_feedbacks');
    return saved ? JSON.parse(saved) : [];
  });

  const [customFields, setCustomFields] = useState<CustomFieldDefinition[]>(() => {
    const saved = localStorage.getItem('miwe_custom_fields');
    return saved ? JSON.parse(saved) : [];
  });

  const [ganttParcels, setGanttParcels] = useState<GanttParcelItem[]>(() => loadGanttData());

  // COLD-START & FIRESTORE REALTIME SUBSCRIBER
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);

  const currentUserId = currentUser?.id;
  useEffect(() => {
    // Kurallar oturum ister: dinleyici yalnızca giriş yapılmışken (ve kullanıcı değişince yeniden) kurulur
    if (!currentUserId) return;
    let isMounted = true;
    const loadingFallback = setTimeout(() => { if (isMounted) setIsInitialLoading(false); }, 6000);

    // Direct Real-Time Listener on all operational collections
    const unsubAppData = subscribeToAllAppDataOnSnapshot((data) => {
      if (!isMounted) return;
      if (data.references) setReferences(data.references);
      if (data.harvestRecords) setHarvestRecords(data.harvestRecords);
      if (data.fieldRecords) setFieldRecords(data.fieldRecords);
      if (data.muzRecords) setMuzRecords(data.muzRecords);
      if (data.bademRecords) setBademRecords(data.bademRecords);
      if (data.lojistikRecords) setLojistikRecords(data.lojistikRecords);
      if (data.ambarRecords) setAmbarRecords(data.ambarRecords);
      if (data.exportSampleRecords) setExportSampleRecords(data.exportSampleRecords);
      if (data.salesRecords) setSalesRecords(data.salesRecords);
      if (data.incidentRecords) setIncidentRecords(data.incidentRecords);
      if (data.freezeDryRecords) setFreezeDryRecords(data.freezeDryRecords);
      if (data.feedbacks) setFeedbacks(data.feedbacks);
      if (data.customFields) setCustomFields(data.customFields);
      if (data.ganttParcels && data.ganttParcels.length > 0) setGanttParcels(data.ganttParcels);

      setIsInitialLoading(false);
    }, () => {
      if (isMounted) setIsInitialLoading(false);
    });

    return () => {
      isMounted = false;
      clearTimeout(loadingFallback);
      unsubAppData();
    };
  }, [currentUserId]);

  // 2. Offline / Online Connectivity & Sync Queue
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine ?? true);
  const [offlineQueue, setOfflineQueue] = useState<Array<{ action: string; payload: any; retryCount?: number }>>(() => {
    // v2: bu kuyruk yalnızca Google Sheets (GAS) yazmaları içindi; tablo artık Firestore'dan okuduğu için boşaltılır
    if (!SHEETS_PUSH_ENABLED) {
      try { localStorage.removeItem('miwe_offline_queue'); } catch {}
      return [];
    }
    const saved = localStorage.getItem('miwe_offline_queue');
    return saved ? JSON.parse(saved) : [];
  });

  const [deletedIds, setDeletedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('miwe_deleted_ids');
    return saved ? JSON.parse(saved) : [];
  });

  const markAsDeleted = (idOrRefId: string) => {
    if (!idOrRefId) return;
    setDeletedIds(prev => {
      if (prev.includes(idOrRefId)) return prev;
      const next = [...prev, idOrRefId];
      safeLocalStorageSetItem('miwe_deleted_ids', JSON.stringify(next));
      return next;
    });
  };

  // 3. Google Apps Script Web App URL & Spreadsheet URL
  const [gasUrl, setGasUrl] = useState<string>(() => {
    const envUrl = (typeof import.meta !== 'undefined' && (import.meta as any).env) ? (import.meta as any).env.VITE_GAS_URL : undefined;
    if (envUrl && typeof envUrl === 'string' && envUrl.trim()) return envUrl.trim();
    const saved = localStorage.getItem('miwe_gas_url') || '';
    return saved.trim();
  });
  const [gasToken, setGasToken] = useState<string>(() => {
    const envToken = (typeof import.meta !== 'undefined' && (import.meta as any).env) ? (import.meta as any).env.VITE_GAS_TOKEN : undefined;
    return (envToken && typeof envToken === 'string') ? envToken : (localStorage.getItem('miwe_gas_token') || 'miwe-sec-token-2026');
  });
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string>(() => {
    return localStorage.getItem('miwe_spreadsheet_url') || 'https://docs.google.com/spreadsheets/';
  });

  const handleSaveSpreadsheetUrl = (url: string) => {
    setSpreadsheetUrl(url);
    safeLocalStorageSetItem('miwe_spreadsheet_url', url);
  };

  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<'SUCCESS' | 'PENDING' | 'ERROR' | 'SYNCING'>('SUCCESS');
  const [syncErrorMessage, setSyncErrorMessage] = useState<string | null>(null);

  // Service Worker Update notification state (Task 6)
  const [swUpdateAvailable, setSwUpdateAvailable] = useState<(() => void) | null>(null);

  useEffect(() => {
    const handleSwUpdate = (e: any) => {
      if (e?.detail?.updateSW) {
        setSwUpdateAvailable(() => () => e.detail.updateSW(true));
      }
    };
    window.addEventListener('sw-update-available', handleSwUpdate);
    return () => window.removeEventListener('sw-update-available', handleSwUpdate);
  }, []);

  // Performans & Bellek Optimizasyonu: appStateRef her zaman geçerli varsayılan değerler barındırır
  const appStateRef = useRef<any>({
    references: [],
    harvestRecords: [],
    fieldRecords: [],
    muzRecords: [],
    bademRecords: [],
    lojistikRecords: [],
    ambarRecords: [],
    exportSampleRecords: [],
    salesRecords: [],
    incidentRecords: [],
    freezeDryRecords: [],
    feedbacks: [],
    offlineQueue: [],
    gasUrl: '',
    gasToken: '',
    customFields: [],
    ganttParcels: [],
    deletedIds: []
  });

  // Render aşamasında ref'in en güncel state verilerini tutmasını sağla (senkronize erişim)
  appStateRef.current = {
    references,
    harvestRecords,
    fieldRecords,
    muzRecords,
    bademRecords,
    lojistikRecords,
    ambarRecords,
    exportSampleRecords,
    salesRecords,
    incidentRecords,
    freezeDryRecords,
    feedbacks,
    offlineQueue,
    gasUrl,
    gasToken,
    customFields,
    ganttParcels,
    deletedIds
  };

  const isSyncingCentralRef = useRef(false);
  const [isResetConfirmModalOpen, setIsResetConfirmModalOpen] = useState(false);

  const handleOpenResetModal = () => {
    setIsResetConfirmModalOpen(true);
  };

  const handleConfirmResetAllStocksAndRecords = async () => {
    setIsResetConfirmModalOpen(false);
    
    // 1. Clear React state immediately for instant UI reaction
    setReferences([]);
    setHarvestRecords([]);
    setFieldRecords([]);
    setMuzRecords([]);
    setBademRecords([]);
    setLojistikRecords([]);
    setAmbarRecords([]);
    setExportSampleRecords([]);
    setSalesRecords([]);
    setIncidentRecords([]);
    setFreezeDryRecords([]);
    setFeedbacks([]);
    setDeletedIds([]);

    // 2. Clear record keys from localStorage, while strictly preserving user session and platform settings
    const recordKeys = [
      'miwe_references',
      'miwe_harvest_records',
      'miwe_field_records',
      'miwe_muz_records',
      'miwe_badem_records',
      'miwe_lojistik_records',
      'miwe_ambar_records',
      'miwe_export_sample_records',
      'miwe_sales_records',
      'miwe_incident_records',
      'miwe_freeze_dry_records',
      'miwe_feedbacks',
      'miwe_deleted_ids',
      'miwe_offline_queue'
    ];
    recordKeys.forEach(k => {
      localStorage.removeItem(k);
      safeLocalStorageSetItem(k, JSON.stringify([]));
    });
    
    localStorage.setItem('miwe_is_first_launch', 'false');

    // 3. Merkezi veritabanını (Firestore) sıfırla — yetki firestore.rules tarafından doğrulanır
    const centralOk = await resetAllAppDataInFirestore();
    if (!centralOk) {
      showError('Merkezi veritabanı sıfırlanamadı (yetki veya bağlantı). Yalnızca bu cihazın önbelleği temizlendi.', 'Kısmi Sıfırlama');
      return;
    }

    setLastSyncTime(new Date().toLocaleTimeString('tr-TR'));
    setSyncStatus('SUCCESS');
    showSuccess('Tüm ambar, stok ve referans kayıtları başarıyla sıfırlandı. Oturumunuz korundu.', 'Sıfırlama Başarılı');
  };

  const handleResetAllStocksAndRecords = handleOpenResetModal;

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Auto-sync pending items if back online with up-to-date ref
      triggerOfflineQueueSync();
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // 4. View Navigation & Modals State
  const [activeView, setActiveView] = useState<'DASHBOARD' | 'GALLERY' | 'REFERENCES' | 'PENDING' | 'ANALYTICS' | 'MONTHLY_REPORT' | 'SUMMARY' | 'FEEDBACK' | 'DIAGNOSTICS' | 'HARVEST_PORTAL' | 'QUALITY_ROADMAP' | 'DEPARTMENT_SCORING' | 'REPORTING_PORTAL' | 'GUIDE_PORTAL' | 'AUDIT_TRAIL' | 'TRACEABILITY_LEDGER' | 'PORTAL_LAUNCHER' | ModuleKey>('PORTAL_LAUNCHER');
  const [selectedRefIdForForm, setSelectedRefIdForForm] = useState<string | undefined>(undefined);
  const [editingRecord, setEditingRecord] = useState<{ moduleKey: ModuleKey; record: any } | null>(null);
  
  // Aşama 22: Portal Launcher Breadcrumb & Tab State
  const [activePortalBreadcrumb, setActivePortalBreadcrumb] = useState<{
    portalId: string;
    subId: string;
    portalTitle: string;
    subTitle: string;
  } | null>(null);
  const [initialPortalTab, setInitialPortalTab] = useState<string | null>(null);
  const [showPresentationModal, setShowPresentationModal] = useState(false);

  const handleNavigateFromPortalLauncher = (
    viewId: string,
    tabId?: string,
    portalInfo?: { portalId: string; subId: string; portalTitle: string; subTitle: string }
  ) => {
    setActiveView(viewId as any);
    if (tabId) {
      setInitialPortalTab(tabId);
    } else {
      setInitialPortalTab(null);
    }
    if (portalInfo) {
      setActivePortalBreadcrumb(portalInfo);
    }
  };

  const handleNavigateToDashboard = () => {
    setActiveView('DASHBOARD');
    setActivePortalBreadcrumb(null);
    setInitialPortalTab(null);
  };
  
  // Modals
  const [activeTraceRef, setActiveTraceRef] = useState<ReferenceItem | null>(null);
  const [activePdfRef, setActivePdfRef] = useState<ReferenceItem | null>(null);
  const [activePdfIncident, setActivePdfIncident] = useState<IncidentRecord | null>(null);

  // Handle URL deep link scanning e.g. ?ref=REF-1002 or ?report=REF-1002 or ?refId=REF-1002
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const refParam = urlParams.get('ref') || urlParams.get('report') || urlParams.get('refId');
      if (refParam) {
        const found = references.find(r => r.refId === refParam || r.id === refParam);
        if (found) {
          setActivePdfRef(found);
        }
      }
    } catch (e) {
      console.warn('URL deep link check notice:', e);
    }
  }, [references]);
  const [isGasModalOpen, setIsGasModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isCustomFieldsModalOpen, setIsCustomFieldsModalOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isPwaModalOpen, setIsPwaModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isCreateNotificationModalOpen, setIsCreateNotificationModalOpen] = useState(false);
  const [isVisualStandardsModalOpen, setIsVisualStandardsModalOpen] = useState(false);
  const [isAdminPasswordModalOpen, setIsAdminPasswordModalOpen] = useState(false);
  const [isAiVisionModalOpen, setIsAiVisionOpen] = useState(false);
  const [selectedLedgerRefId, setSelectedLedgerRefId] = useState<string | undefined>(undefined);
  const [activeStatFilter, setActiveStatFilter] = useState<string>('ALL');
  const [dismissedSheetValidationAlert, setDismissedSheetValidationAlert] = useState(false);

  // Active Field/Parcel Context for auto-propagation to sub-forms
  const [activeFieldContext, setActiveFieldContext] = useState<ActiveFieldContext | null>(() => {
    try {
      const saved = localStorage.getItem('miwe_active_field_context');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const handleSelectFieldContext = (ctx: ActiveFieldContext | null) => {
    setActiveFieldContext(ctx);
    if (ctx) {
      localStorage.setItem('miwe_active_field_context', JSON.stringify(ctx));
      showInfo(`Parsel/Sektör "${ctx.parcelCode || ctx.sector || ctx.orchard}" seçildi. Alt formlara otomatik aktarılacak.`, 'Bağlam Seçildi');
    } else {
      localStorage.removeItem('miwe_active_field_context');
    }
  };

  // Automatic Critical Stock Monitor -> Notifies Notification Center
  useEffect(() => {
    try {
      const savedThreshold = localStorage.getItem('miwe_critical_stock_threshold');
      const threshold = savedThreshold ? Number(savedThreshold) : 5000;
      
      const refMap = new Map<string, ReferenceItem>();
      references.forEach(r => refMap.set(r.refId, r));

      const productTotals = new Map<string, { acceptedKg: number; warehouse: string; roomNo: string }>();
      ambarRecords.forEach(a => {
        const parentRef = refMap.get(a.refId);
        const prod = parentRef?.product || 'Meyve';
        const cleanProd = prod.replace(/\(.*\)/, '').trim();
        const existing = productTotals.get(cleanProd) || { 
          acceptedKg: 0, 
          warehouse: a.warehouse || 'Merkez Soğuk Depo', 
          roomNo: a.roomNo || 'Oda 1' 
        };
        existing.acceptedKg += (a.acceptedWeightKg || 0);
        productTotals.set(cleanProd, existing);
      });

      // Deduct sales
      salesRecords.forEach(s => {
        const prod = s.product || '';
        const cleanProd = prod.replace(/\(.*\)/, '').trim();
        if (productTotals.has(cleanProd)) {
          const item = productTotals.get(cleanProd)!;
          item.acceptedKg = Math.max(0, item.acceptedKg - (s.totalQuantityKg || 0));
        }
      });

      // Check against threshold & dispatch
      productTotals.forEach((val, prodName) => {
        if (val.acceptedKg > 0 && val.acceptedKg < threshold) {
          const sessionKey = `miwe_stock_alert_notified_${prodName}_${new Date().toISOString().slice(0, 10)}`;
          if (!sessionStorage.getItem(sessionKey)) {
            const isUrgent = val.acceptedKg < threshold * 0.5;
            addNotification(
              'ALL',
              `${isUrgent ? '🚨 ACİL' : '⚠️'} Kritik Stok: ${prodName} (${val.acceptedKg.toLocaleString()} kg)`,
              `${val.warehouse} (${val.roomNo}) içerisinde ${prodName} stoğu ${val.acceptedKg.toLocaleString()} kg seviyesine gerilemiştir (Güvenlik eşiği: ${threshold.toLocaleString()} kg). Lütfen yeni hasat/tedarik planlayın.`,
              'CRITICAL_ALERT',
              'DASHBOARD'
            );
            sessionStorage.setItem(sessionKey, 'true');
          }
        }
      });
    } catch (e) {
      // Safe guard
    }
  }, [ambarRecords, salesRecords, references]);

  // Persistence to local storage using safeLocalStorageSetItem
  useEffect(() => {
    safeLocalStorageSetItem('miwe_references', JSON.stringify(references));
  }, [references]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_harvest_records', JSON.stringify(harvestRecords));
  }, [harvestRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_field_records', JSON.stringify(fieldRecords));
  }, [fieldRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_muz_records', JSON.stringify(muzRecords));
  }, [muzRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_badem_records', JSON.stringify(bademRecords));
  }, [bademRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_lojistik_records', JSON.stringify(lojistikRecords));
  }, [lojistikRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_ambar_records', JSON.stringify(ambarRecords));
  }, [ambarRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_export_sample_records', JSON.stringify(exportSampleRecords));
  }, [exportSampleRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_sales_records', JSON.stringify(salesRecords));
  }, [salesRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_incident_records', JSON.stringify(incidentRecords));
  }, [incidentRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_freeze_dry_records', JSON.stringify(freezeDryRecords));
  }, [freezeDryRecords]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_feedbacks', JSON.stringify(feedbacks));
  }, [feedbacks]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_custom_fields', JSON.stringify(customFields));
  }, [customFields]);
  useEffect(() => {
    safeLocalStorageSetItem('miwe_offline_queue', JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  // Perform consistency validation on initial load to ensure orphaned records or missing references are healed
  useEffect(() => {
    const initialState: DataStoreState = {
      references: appStateRef.current.references,
      harvestRecords: appStateRef.current.harvestRecords,
      fieldRecords: appStateRef.current.fieldRecords,
      muzRecords: appStateRef.current.muzRecords,
      bademRecords: appStateRef.current.bademRecords,
      lojistikRecords: appStateRef.current.lojistikRecords,
      ambarRecords: appStateRef.current.ambarRecords,
      exportSampleRecords: appStateRef.current.exportSampleRecords,
      salesRecords: appStateRef.current.salesRecords,
      incidentRecords: appStateRef.current.incidentRecords,
      freezeDryRecords: appStateRef.current.freezeDryRecords
    };
    const validated = validateConsistency(initialState);
    if (validated.repairedCount > 0) {
      console.info(`[CentralConsistency] ${validated.repairedCount} referans ilişkisi otomatik doğrulandı ve güncellendi.`);
      setReferences(validated.references);
    }

    // Initial sync with central server backend
    syncCentralAppData();

    // Configurable periodic sync with Data Saver & Custom Interval guards
    let currentIntervalTimer: any = null;

    const setupSyncTimer = () => {
      if (currentIntervalTimer) clearInterval(currentIntervalTimer);
      const settings = getSyncSettings();
      const intervalMs = settings.syncIntervalSeconds > 0 ? settings.syncIntervalSeconds * 1000 : 3600000;

      currentIntervalTimer = setInterval(() => {
        const curSettings = getSyncSettings();
        if (shouldAllowAutoSync(curSettings) && !isSyncingCentralRef.current) {
          syncCentralAppData();
        }
      }, intervalMs);
    };

    setupSyncTimer();

    const handleSyncSettingsUpdated = () => {
      setupSyncTimer();
    };

    window.addEventListener('miwe_sync_settings_updated', handleSyncSettingsUpdated);

    return () => {
      if (currentIntervalTimer) clearInterval(currentIntervalTimer);
      window.removeEventListener('miwe_sync_settings_updated', handleSyncSettingsUpdated);
    };
  }, []);

  // Delta Sync Helper: Filters only records modified since last sync timestamp (Task 2)
  const filterDeltaRecords = <T extends { updatedAt?: string; timestamp?: string; createdAt?: string }>(
    items: T[] | undefined | null,
    lastSyncIso: string | null
  ): T[] => {
    if (!Array.isArray(items)) return [];
    if (!lastSyncIso) return items;
    const lastSyncTimeMs = new Date(lastSyncIso).getTime();
    if (isNaN(lastSyncTimeMs) || lastSyncTimeMs <= 0) return items;
    return items.filter(item => {
      if (!item) return false;
      const itemTime = new Date(item.updatedAt || item.timestamp || item.createdAt || 0).getTime();
      return !isNaN(itemTime) && itemTime > lastSyncTimeMs;
    });
  };

  // Central Server Multi-User Synchronization (with Delta Sync)
  const syncCentralAppData = async (forceFullSync = false) => {
    if (isSyncingCentralRef.current) return;
    isSyncingCentralRef.current = true;
    try {
      const state = appStateRef.current;
      const lastSyncIso = forceFullSync ? null : localStorage.getItem('miwe_last_central_sync_iso');

      const clientData: CentralAppData = {
        references: filterDeltaRecords(state.references, lastSyncIso),
        harvestRecords: filterDeltaRecords(state.harvestRecords, lastSyncIso),
        fieldRecords: filterDeltaRecords(state.fieldRecords, lastSyncIso),
        muzRecords: filterDeltaRecords(state.muzRecords, lastSyncIso),
        bademRecords: filterDeltaRecords(state.bademRecords, lastSyncIso),
        lojistikRecords: filterDeltaRecords(state.lojistikRecords, lastSyncIso),
        ambarRecords: filterDeltaRecords(state.ambarRecords, lastSyncIso),
        salesRecords: filterDeltaRecords(state.salesRecords, lastSyncIso),
        incidentRecords: filterDeltaRecords(state.incidentRecords, lastSyncIso),
        exportSampleRecords: filterDeltaRecords(state.exportSampleRecords, lastSyncIso),
        freezeDryRecords: filterDeltaRecords(state.freezeDryRecords, lastSyncIso),
        feedbacks: filterDeltaRecords(state.feedbacks, lastSyncIso),
        customFields: state.customFields,
        ganttParcels: state.ganttParcels
      };

      const merged = await syncCentralAppDataWithServer(clientData, lastSyncIso || undefined);
      if (merged && merged.data) {
        const data = merged.data;
        const curDeleted = state.deletedIds;
        const isNotDeleted = (id?: string, refId?: string) => {
          if (id && curDeleted.includes(id)) return false;
          if (refId && curDeleted.includes(refId)) return false;
          return true;
        };

        if (Array.isArray(data.references)) {
          setReferences(data.references.filter(r => isNotDeleted(r.refId, r.refId)));
        }
        if (Array.isArray(data.harvestRecords)) {
          setHarvestRecords(data.harvestRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.fieldRecords)) {
          setFieldRecords(data.fieldRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.muzRecords)) {
          setMuzRecords(data.muzRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.bademRecords)) {
          setBademRecords(data.bademRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.lojistikRecords)) {
          setLojistikRecords(data.lojistikRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.ambarRecords)) {
          setAmbarRecords(data.ambarRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.salesRecords)) {
          setSalesRecords(data.salesRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.incidentRecords)) {
          setIncidentRecords(data.incidentRecords.filter(r => isNotDeleted(r.id || r.incidentId, r.refId)));
        }
        if (Array.isArray(data.exportSampleRecords)) {
          setExportSampleRecords(data.exportSampleRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.freezeDryRecords)) {
          setFreezeDryRecords(data.freezeDryRecords.filter(r => isNotDeleted(r.id, r.refId)));
        }
        if (Array.isArray(data.feedbacks)) {
          setFeedbacks(data.feedbacks.filter(r => isNotDeleted(r.id)));
        }
        if (data.customFields) setCustomFields(data.customFields);
        if (data.ganttParcels && data.ganttParcels.length > 0) {
          setGanttParcels(data.ganttParcels);
          saveGanttData(data.ganttParcels);
        }
        const nowIso = new Date().toISOString();
        localStorage.setItem('miwe_last_central_sync_iso', nowIso);
        setLastSyncTime(new Date().toLocaleTimeString('tr-TR'));
      }
    } catch (err: any) {
      console.warn('[SyncNotice] Central server delta sync skipped:', err?.message || err);
    } finally {
      isSyncingCentralRef.current = false;
    }
  };

  // Real-time calculated system stats
  const stats: SystemStats = calculateSystemStats(references, incidentRecords);
  const fieldBreakdown = calculateFieldBreakdown(references, harvestRecords);
  const pendingCount = references.filter(r => r.status === 'CREATED' || r.status === 'SHIPPED' || r.status === 'IN_TRANSIT').length + incidentRecords.filter(i => i.status === 'OPEN').length;

  // Confetti helper
  const triggerSuccessCelebration = () => {
    try {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.8 }
      });
    } catch (e) {
      // ignore in headless
    }
  };

  // Google Apps Script API Sync Helper with dedicated debug log monitoring
  const syncWithGas = async (action: string, payload: any, queueRetryCount = 0) => {
    // Mimari v2: Google Sheets verileri Firestore'dan kendisi okur (google-apps-script/Code.gs).
    // İstemci tabloya YAZMAZ: çift kayıt, kuyruk birikmesi ve açık token sorunu ortadan kalkar.
    if (!SHEETS_PUSH_ENABLED) {
      addDebugLog('GAS_SYNC', 'INFO', `[v2] Tabloya yazma atlandı (${action}); Sheets Firestore'dan otomatik güncellenir.`);
      return;
    }
    const currentGasUrl = appStateRef.current.gasUrl;
    const clientRecordId = payload?.record?.id || payload?.record?.incidentId || payload?.id || payload?.refId || payload?.record?.refId || `cli-${Date.now()}`;
    const safePayload = {
      ...payload,
      clientRecordId
    };

    // 4. PIVOT TABLE / GOOGLE SHEETS VERİ YAPISI UYUMU
    if (safePayload && safePayload.record && safePayload.moduleKey) {
      safePayload.flatData = generateFlatSchema(safePayload.moduleKey, safePayload.record, safePayload.newRefData);
      
      // Portallar Arası Olay Bildirimi (PortalEventBus)
      const eventType = safePayload.isNewRef ? 'RECORD_CREATED' : 'RECORD_UPDATED';
      portalEventBus.emit(eventType, safePayload.record, safePayload.moduleKey, safePayload.record?.refId);
      
      // Save photos to Gallery (IndexedDB) with deterministic IDs and backup to Express Server (Task 9)
      if (safePayload.record.photos && Array.isArray(safePayload.record.photos)) {
        safePayload.record.photos.forEach(async (photoUrl: string, idx: number) => {
          if (photoUrl && photoUrl.startsWith('data:image')) {
            const deterministicId = `${safePayload.record.refId || 'photo'}_${idx}`;
            // Task 9: Backup photo to Express server first
            try {
              await uploadPhotoToServer(deterministicId, photoUrl);
            } catch (err) {
              console.warn('[PhotoBackup] Express sunucusuna fotoğraf yedeklenirken hata:', err);
            }

            try {
              await savePhoto({
                id: deterministicId,
                refId: safePayload.record.refId || (safePayload.newRefData && safePayload.newRefData.refId),
                moduleKey: safePayload.moduleKey,
                location: safePayload.record.location || safePayload.record.orchard || (safePayload.newRefData && safePayload.newRefData.location),
                description: safePayload.record.description || safePayload.record.notes || '',
                timestamp: safePayload.record.timestamp || new Date().toISOString(),
                dataUrl: photoUrl,
                synced: navigator.onLine
              });
            } catch (err) {
              addDebugLog('STORAGE', 'ERROR', 'Fotoğraf galeriye kaydedilirken hata oluştu', err);
            }
          }
        });

        // Retain photos array with base64 so Google Apps Script savePhotoToDrive can decode and upload to Google Drive.
        // Google Sheets cells never store the raw base64 array because generateFlatSchema only outputs 'Mevcut'/'Yok'
        // and getRecordValueForHeader in Apps Script excludes the raw 'photos' array from cells, only saving public Drive URLs into 'PhotoUrl'.
        safePayload.photoCount = safePayload.record.photos.length;
      }
    }

    const payloadStr = JSON.stringify({ action, token: appStateRef.current.gasToken || 'miwe-sec-token-2026', payload: safePayload });
    const payloadSizeBytes = payloadStr.length;
    const startTime = performance.now();

    addDebugLog(
      'GAS_SYNC',
      'INFO',
      `Google Sheets eşitleme isteği hazırlanıyor: [${action}]`,
      {
        action,
        moduleKey: safePayload?.moduleKey,
        refId: safePayload?.refId || safePayload?.record?.refId,
        clientRecordId,
        payloadSizeBytes,
        isOnline: navigator.onLine,
        gasUrlConfigured: Boolean(currentGasUrl)
      }
    );

    // Madde 2: gasUrl boşsa veya offline ise işlem artık offlineQueue'ya EKLENSİN
    if (!navigator.onLine) {
      addDebugLog(
        'GAS_SYNC',
        'WARN',
        `Çevrimdışı durum. İşlem kuyruğa eklendi: [${action}]`,
        { action, clientRecordId }
      );
      showWarning('Cihaz çevrimdışı. İşlem kuyruğa alındı, internet erişimi geldiğinde senkronize edilecektir.', 'Çevrimdışı Kayıt');
      setOfflineQueue(prev => {
        const exists = prev.some(item => item.payload?.clientRecordId === clientRecordId && item.action === action);
        if (exists) return prev;
        return [...prev, { action, payload: safePayload, retryCount: queueRetryCount }];
      });
      return;
    }

    if (!currentGasUrl) {
      addDebugLog(
        'GAS_SYNC',
        'WARN',
        `Google Sheets URL tanımlanmamış. İşlem offlineQueue'ya ekleniyor: [${action}]`,
        { action, clientRecordId }
      );
      setOfflineQueue(prev => {
        const exists = prev.some(item => item.payload?.clientRecordId === clientRecordId && item.action === action);
        if (exists) return prev;
        return [...prev, { action, payload: safePayload, retryCount: queueRetryCount }];
      });
      return;
    }

    setIsSyncing(true);
    try {
      // Madde 2: fetch mode:'cors', headers: {'Content-Type': 'text/plain;charset=utf-8'}
      const res = await fetch(currentGasUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: payloadStr,
        mode: 'cors'
      });

      if (!res.ok) {
        throw new Error(`Google Sheets HTTP ${res.status}`);
      }

      const resJson = await res.json().catch(() => null);
      if (resJson && resJson.success === true) {
        const durationMs = Math.round(performance.now() - startTime);
        setLastSyncTime(new Date().toLocaleTimeString('tr-TR'));
        setSyncStatus('SUCCESS');
        setSyncErrorMessage(null);
        // Kuyruktan sil
        setOfflineQueue(prev => prev.filter(item => item.payload?.clientRecordId !== clientRecordId));
        addDebugLog(
          'GAS_SYNC',
          'INFO',
          `Google Sheets HTTP POST tamamlandı ({success: true}, ${durationMs}ms)`,
          { action, durationMs, payloadSizeBytes }
        );
      } else {
        throw new Error(resJson?.message || 'Google Sheets servisi {success: true} yanıtı dönmedi');
      }
    } catch (err: any) {
      const durationMs = Math.round(performance.now() - startTime);
      addDebugLog(
        'GAS_SYNC',
        'ERROR',
        `Google Sheets HTTP POST hatası (${durationMs}ms). İşlem kuyrukta tutuluyor.`,
        { action, durationMs, error: String(err?.message || err) }
      );
      showWarning(`Google Sheets senkronizasyonunda aksama oldu (${err?.message || 'Bağlantı hatası'}). Kayıt kuyrukta tutuluyor.`, 'Eşitleme Uyarısı');
      setOfflineQueue(prev => {
        const idx = prev.findIndex(item => item.payload?.clientRecordId === clientRecordId && item.action === action);
        if (idx >= 0) {
          return prev.map((item, i) => i === idx ? { ...item, retryCount: (item.retryCount || 0) + 1 } : item);
        }
        return [...prev, { action, payload: safePayload, retryCount: queueRetryCount + 1 }];
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const triggerOfflineQueueSync = async () => {
    const currentQueue = appStateRef.current.offlineQueue;
    const currentGasUrl = appStateRef.current.gasUrl;
    if (!currentQueue || currentQueue.length === 0) {
      showInfo('Senkronize edilecek bekleyen çevrimdışı işlem bulunmuyor.');
      return;
    }
    if (!currentGasUrl) {
      setIsGasModalOpen(true);
      setSyncStatus('ERROR');
      setSyncErrorMessage('Google Sheets Web App URL adresi tanımlı değil');
      showWarning('Çevrimdışı kayıtları eşitlemek için önce Google Sheets Web App URL adresinizi kaydedin.', 'URL Tanımlı Değil');
      return;
    }
    setIsSyncing(true);
    setSyncStatus('SYNCING');
    setSyncErrorMessage(null);

    const successfulIds = new Set<string>();
    const failedErrors = new Map<string, string>();
    let failCount = 0;
    let lastErrorMessage = '';

    try {
      for (const item of currentQueue) {
        const clientRecordId = item.payload?.clientRecordId || item.payload?.record?.id || item.payload?.refId || `cli-${Date.now()}`;
        const payloadToSend = {
          action: item.action,
          token: appStateRef.current.gasToken || 'miwe-sec-token-2026',
          payload: {
            ...item.payload,
            clientRecordId
          }
        };

        try {
          const res = await fetch(currentGasUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: JSON.stringify(payloadToSend),
            mode: 'cors'
          });

          if (res.ok) {
            const data = await res.json().catch(() => null);
            if (data && data.success === true) {
              successfulIds.add(clientRecordId);
            } else {
              failCount++;
              const msg = data?.message || 'Sunucu {success: true} dönmedi';
              lastErrorMessage = msg;
              failedErrors.set(clientRecordId, msg);
            }
          } else {
            failCount++;
            const msg = `HTTP ${res.status}`;
            lastErrorMessage = msg;
            failedErrors.set(clientRecordId, msg);
          }
        } catch (err: any) {
          failCount++;
          const msg = err?.message || 'Ağ erişim hatası';
          lastErrorMessage = msg;
          failedErrors.set(clientRecordId, msg);
        }
      }

      // Yalnızca {success: true} dönenleri kuyruktan sil; başarısız olanların retryCount ve lastError değerlerini güncelle
      setOfflineQueue(prev =>
        prev
          .filter(item => {
            const cid = item.payload?.clientRecordId || item.payload?.record?.id || item.payload?.refId;
            return !successfulIds.has(cid);
          })
          .map(item => {
            const cid = item.payload?.clientRecordId || item.payload?.record?.id || item.payload?.refId;
            const err = failedErrors.get(cid);
            if (err) {
              return {
                ...item,
                retryCount: (item.retryCount || 0) + 1,
                lastError: err
              };
            }
            return item;
          })
      );

      if (successfulIds.size > 0) {
        const timeStr = new Date().toLocaleTimeString('tr-TR');
        setLastSyncTime(timeStr);
        setSyncStatus(failCount === 0 ? 'SUCCESS' : 'PENDING');
        triggerSuccessCelebration();
        addDebugLog('STORAGE', 'INFO', `Bekleyen ${successfulIds.size} adet çevrimdışı işlem Google Sheets'e başarıyla senkronize edildi.`);
        showSuccess(`Bekleyen ${successfulIds.size} adet çevrimdışı işlem başarıyla senkronize edildi!`, 'Senkronizasyon Tamamlandı');
      }

      if (failCount > 0) {
        setSyncStatus('ERROR');
        setSyncErrorMessage(`${failCount} adet işlem eşitlenemedi: ${lastErrorMessage}`);
        showError(`${failCount} adet kayıt eşitlenemedi ve kuyrukta tutulmaya devam ediyor. Hata: ${lastErrorMessage}`, 'Kısmi Senkronizasyon Hatası');
      }
    } catch (e: any) {
      console.warn('Sync queue error:', e);
      setSyncStatus('ERROR');
      setSyncErrorMessage(e?.message || 'Çevrimdışı kuyruk iletiminde ağ hatası');
      addDebugLog('STORAGE', 'ERROR', 'Çevrimdışı işlem kuyruğu senkronizasyon hatası', e);
      showError('Çevrimdışı işlemler eşitlenirken ağ hatası oluştu: ' + (e?.message || String(e)), 'Senkronizasyon Başarısız');
    } finally {
      setIsSyncing(false);
    }
  };

  // 3 kereden fazla başarısız olmuş çevrimdışı kayıtları sıfırlayıp yeniden gönderme fonksiyonu
  const handleRetryFailedQueueItems = async () => {
    const currentQueue = appStateRef.current.offlineQueue;
    const failedItems = currentQueue.filter(item => (item.retryCount || 0) > 3);
    if (failedItems.length === 0) {
      showInfo('3 kereden fazla başarısız olmuş işlem bulunmuyor.');
      return;
    }

    setOfflineQueue(prev =>
      prev.map(item => ((item.retryCount || 0) > 3 ? { ...item, retryCount: 0, lastError: undefined } : item))
    );
    showInfo(`${failedItems.length} adet 3+ kez başarısız olmuş kaydın deneme sayacı sıfırlandı. Senkronizasyon yeniden başlatılıyor...`, 'Yeniden Deneniyor');
    await triggerOfflineQueueSync();
  };

  const handleSyncSingleQueueItem = async (indexOrItem: number | any) => {
    const currentQueue = appStateRef.current.offlineQueue;
    const currentGasUrl = appStateRef.current.gasUrl;
    const index = typeof indexOrItem === 'number'
      ? indexOrItem
      : currentQueue.findIndex(q => q === indexOrItem || JSON.stringify(q) === JSON.stringify(indexOrItem));
    const item = index >= 0 ? currentQueue[index] : (typeof indexOrItem === 'object' ? indexOrItem : null);
    if (!item) return;

    // Always try central server sync first
    if (item.payload?.moduleKey && item.payload?.record) {
      await saveRecordToCentralServer(item.payload.moduleKey, item.payload.record);
    }

    if (!currentGasUrl) {
      showWarning('Google Sheets Web App URL tanımlı değil. Kayıt yerel kuyrukta tutuluyor.', 'URL Gerekli');
      return;
    }

    setIsSyncing(true);
    try {
      const clientRecordId = item.payload?.clientRecordId || item.payload?.record?.id || item.payload?.refId || `cli-${Date.now()}`;
      const payloadToSend = {
        action: item.action,
        token: appStateRef.current.gasToken || 'miwe-sec-token-2026',
        payload: {
          ...item.payload,
          clientRecordId
        }
      };

      const res = await fetch(currentGasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payloadToSend),
        mode: 'cors'
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const resJson = await res.json().catch(() => null);
      if (resJson && resJson.success === true) {
        setOfflineQueue(prev => prev.filter((_, i) => i !== index));
        setLastSyncTime(new Date().toLocaleTimeString('tr-TR'));
        triggerSuccessCelebration();
        showSuccess('Bekleyen işlem başarıyla senkronize edildi.', 'Senkronizasyon Başarılı');
      } else {
        throw new Error(resJson?.message || 'Google Sheets servisi {success: true} dönmedi');
      }
    } catch (e: any) {
      console.warn('Single queue sync error:', e);
      setOfflineQueue(prev => prev.map((q, i) => i === index ? { ...q, retryCount: (q.retryCount || 0) + 1 } : q));
      showError('Senkronizasyon sırasında hata oluştu: ' + (e?.message || String(e)), 'Senkronizasyon Hatası');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleDeleteQueueItem = (index: number) => {
    setOfflineQueue(prev => prev.filter((_, i) => i !== index));
  };

  const handleEditQueueItem = (item: any) => {
    const modKey = item.payload?.moduleKey as ModuleKey;
    const rec = item.payload?.record;
    if (modKey && rec) {
      setEditingRecord({ moduleKey: modKey, record: rec });
      setActiveView(modKey);
    }
  };

  const handleTestGasConnection = async (url: string, token?: string): Promise<boolean> => {
    try {
      const tok = token || appStateRef.current.gasToken || 'miwe-sec-token-2026';
      const res = await fetch(`${url}${url.includes('?') ? '&' : '?'}action=health&token=${encodeURIComponent(tok)}`, { mode: 'cors' });
      const json = await res.json().catch(() => null);
      return json && (json.status === 'ok' || json.success === true);
    } catch (err) {
      return false;
    }
  };

  // Google Sheets Çift Yönlü Okuma (Pull / Read) Fonksiyonu
  const pullFromGoogleSheets = async () => {
    // Mimari v2: tablodan platforma içeri aktarma KAPALI. Tablodaki eski/eksik satırlar
    // silinmiş kayıtları geri getirebiliyordu. Tek kaynak Firestore'dur.
    if (!SHEETS_PUSH_ENABLED) {
      showInfo('Google Sheets tablosu Firestore’dan her 15 dakikada otomatik güncellenir. Platformdaki veriler zaten güncel; tablodan içeri aktarma bu sürümde kapalıdır.', 'Tek Yönlü Rapor');
      return;
    }
    if (!gasUrl || gasUrl.trim() === '') {
      setIsGasModalOpen(true);
      setSyncStatus('ERROR');
      setSyncErrorMessage('Google Sheets Web App URL adresi tanımlı değil');
      showWarning('Google Sheets Web App bağlantısı henüz kurulmamış. Lütfen açılan kurulum penceresinden Web App (/exec) URL\'nizi kaydedin.', 'Bağlantı Gerekli');
      addDebugLog('GAS_SYNC', 'WARN', 'Google Sheets pull isteği başarısız: Web App URL tanımlı değil');
      return;
    }

    if (gasUrl.includes('/dev')) {
      setIsGasModalOpen(true);
      setSyncStatus('ERROR');
      setSyncErrorMessage('Geliştirici test URL\'si (/dev) kullanılamaz');
      showWarning('Kaydedilen URL bir geliştirici test URL\'sidir (/dev). Lütfen "/exec" ile biten canlı Web App URL\'sini kaydedin.', 'Canlı URL Gerekli');
      addDebugLog('GAS_SYNC', 'WARN', 'Google Sheets pull isteği başarısız: /dev URL kullanıldı');
      return;
    }

    setIsSyncing(true);
    setSyncStatus('SYNCING');
    setSyncErrorMessage(null);
    addDebugLog('GAS_SYNC', 'INFO', 'Google Sheets tablosundan veri senkronizasyonu (Pull) başlatıldı...');

    try {
      const targetUrl = `${gasUrl}${gasUrl.includes('?') ? '&' : '?'}action=pullData&token=${encodeURIComponent(appStateRef.current.gasToken || 'miwe-sec-token-2026')}&_t=${Date.now()}`;
      const res = await fetch(targetUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!res.ok) {
        throw new Error(`Google Sheets servisi yanıt vermedi (HTTP ${res.status})`);
      }

      const data = await res.json();
      if (data && (data.records || data.references)) {
        const incoming = (data.records || data.references) as any[];
        if (Array.isArray(incoming) && incoming.length > 0) {
          setReferences(prev => {
            const map = new Map<string, ReferenceItem>();
            prev.forEach(r => map.set(r.refId, r));
            // Madde 9: aynı refId için en yeni satır kazansın, durumu boşsa mevcut durumu koru ve sadece sunucudan gerçekten COMPLETED gelirse kilitle
            incoming.forEach(inc => {
              if (inc.refId) {
                const existing = map.get(inc.refId);
                const isCompleted = inc.status === 'COMPLETED' || existing?.status === 'COMPLETED';
                const isLocked = inc.status === 'COMPLETED' || existing?.isLocked || false;
                const statusToSet = inc.status && inc.status.trim() !== '' ? inc.status : (existing?.status || 'CREATED');

                map.set(inc.refId, {
                  ...existing,
                  refId: inc.refId,
                  moduleKey: inc.moduleKey || existing?.moduleKey || 'HARVEST',
                  product: inc.product || existing?.product || 'Meyve',
                  variety: inc.variety || existing?.variety,
                  location: inc.location || existing?.location || 'Ambar',
                  source: inc.source || existing?.source,
                  destination: inc.destination || existing?.destination,
                  quantity: inc.quantity !== undefined ? inc.quantity : (existing?.quantity || 0),
                  unit: inc.unit || existing?.unit || 'kg',
                  status: isCompleted ? 'COMPLETED' : statusToSet,
                  isLocked: isLocked,
                  createdAt: inc.createdAt || existing?.createdAt || new Date().toISOString(),
                  operator: inc.operator || existing?.operator || '',
                  notes: inc.notes || existing?.notes || '',
                  photoUrl: (() => {
                    const raw = inc.photoUrl || inc.PhotoUrl || existing?.photoUrl || '';
                    const urls = String(raw).split(',').map((u: string) => u.trim()).filter((u: string) => u.startsWith('http') || u.startsWith('data:image'));
                    return urls[0] || (raw.startsWith('http') ? raw : existing?.photoUrl);
                  })(),
                  photos: (() => {
                    const raw = inc.photoUrl || inc.PhotoUrl || existing?.photoUrl || '';
                    const urls = String(raw).split(',').map((u: string) => u.trim()).filter((u: string) => u.startsWith('http') || u.startsWith('data:image'));
                    return urls.length > 0 ? urls : (existing?.photos || []);
                  })()
                });
              }
            });
            return Array.from(map.values());
          });
          const timeStr = new Date().toLocaleTimeString('tr-TR');
          setLastSyncTime(timeStr);
          setSyncStatus('SUCCESS');
          setSyncErrorMessage(null);
          triggerSuccessCelebration();
          addDebugLog('GAS_SYNC', 'INFO', `Google Sheets tablosundan ${incoming.length} adet kayıt başarıyla senkronize edildi.`);
          showSuccess(`Google Sheets tablosundan ${incoming.length} adet kayıt başarıyla senkronize edildi.`, 'Senkronizasyon Başarılı');
        } else {
          setSyncStatus('SUCCESS');
          addDebugLog('GAS_SYNC', 'INFO', 'Google Sheets tablosunda henüz kayıt bulunamadı (boş liste).');
          showInfo('Google Sheets tablosunda henüz senkronize edilecek kayıt bulunamadı.', 'Tablo Boş');
        }
      } else {
        setSyncStatus('ERROR');
        setSyncErrorMessage('Google Sheets yanıtı geçersiz veya boş formatta');
        addDebugLog('GAS_SYNC', 'ERROR', 'Google Sheets yanıtı beklenen JSON formatında değil', data);
        showError('Google Sheets yanıtı beklenen formatta değil. Lütfen Apps Script kodunu kontrol edin.', 'Geçersiz Yanıt');
      }
    } catch (err: any) {
      console.warn('Google Sheets pull notice:', err?.message || err);
      setSyncStatus('ERROR');
      setSyncErrorMessage(err?.message || 'CORS veya ağ erişim engeli');
      addDebugLog('GAS_SYNC', 'ERROR', 'Google Sheets veri çekme (pull) hatası', err);
      showError(
        `Google Sheets tablosundan veri çekilemedi: ${err?.message || 'CORS veya ağ erişim engeli'}. Dağıtımın "Herkes (Anyone)" olarak ayarlandığından emin olun.`,
        'Senkronizasyon Hatası'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  // Quick Ref Search from Header
  const handleSearchRef = (refId: string) => {
    const found = references.find(r => r.refId.toLowerCase().includes(refId.toLowerCase()));
    if (found) {
      setActiveTraceRef(found);
    } else {
      showWarning(`"${refId}" referans kodu bulunamadı. Lütfen kontrol edin.`, 'Referans Bulunamadı');
    }
  };

  // Module Navigation Handlers
  const handleSelectModule = (module: ModuleKey, action: 'NEW' | 'EXISTING') => {
    setEditingRecord(null);
    setSelectedRefIdForForm(action === 'EXISTING' ? references[0]?.refId : undefined);
    setActiveView(module);
  };

  // Direct operations from cards / tables
  const handleDirectDispatch = (refId: string) => {
    setEditingRecord(null);
    setSelectedRefIdForForm(refId);
    setActiveView('LOJISTIK');
  };

  const handleDirectReceive = (refId: string) => {
    setEditingRecord(null);
    setSelectedRefIdForForm(refId);
    setActiveView('AMBAR');
  };

  const handleDirectIncident = (refId: string) => {
    setEditingRecord(null);
    setSelectedRefIdForForm(refId);
    setActiveView('INCIDENT');
  };

  // Düzenleme / Edit Modu (Madde 3 & Status Lifecycle)
  const handleEditReference = (ref: ReferenceItem) => {
    if (currentUser?.role !== 'ADMIN' && !currentUser?.permissions?.canEdit) {
      showError('⛔ Bu kaydı düzenleme yetkiniz bulunmamaktadır. Lütfen Sistem Yöneticisi (Admin) ile iletişime geçin.', 'Yetki Engeli');
      return;
    }
    logActivity(currentUser, 'EDIT', ref.moduleKey, `Referans düzenleme açıldı: ${ref.refId}`);
    setSelectedRefIdForForm(ref.refId);

    // Status kontrolü: COMPLETED ise bilgi ver
    if (ref.status === 'COMPLETED' || ref.isLocked) {
      showInfo(`"${ref.refId}" referanslı kayıt TAMAMLANDI durumundadır. Formu inceleyebilir veya güncelleyebilirsiniz.`, 'Kayıt Düzenleme Modu');
    }

    if (ref.moduleKey === 'FIELD') {
      const match = fieldRecords.find(r => r.refId === ref.refId);
      if (match) {
        setEditingRecord({ moduleKey: 'FIELD', record: match });
      } else {
        setEditingRecord(null);
        showWarning(`"${ref.refId}" partisine ait saha test kaydı bulunamadı. Boş form açıldı.`, 'Kayıt Bulunamadı');
      }
      setActiveView('FIELD');
    } else if (ref.moduleKey === 'HARVEST') {
      const match = harvestRecords.find(r => r.refId === ref.refId);
      if (match) {
        setEditingRecord({ moduleKey: 'HARVEST', record: match });
      } else {
        setEditingRecord(null);
        showWarning(`"${ref.refId}" partisine ait hasat kaydı bulunamadı. Boş form açıldı.`, 'Kayıt Bulunamadı');
      }
      setActiveView('HARVEST');
    } else if (ref.moduleKey === 'LOJISTIK') {
      const match = lojistikRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'LOJISTIK', record: match });
      setActiveView('LOJISTIK');
    } else if (ref.moduleKey === 'AMBAR') {
      const match = ambarRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'AMBAR', record: match });
      setActiveView('AMBAR');
    } else if (ref.moduleKey === 'MUZ') {
      const match = muzRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'MUZ', record: match });
      setActiveView('MUZ');
    } else if (ref.moduleKey === 'BADEM') {
      const match = bademRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'BADEM', record: match });
      setActiveView('BADEM');
    } else if (ref.moduleKey === 'FREEZE_DRY') {
      const match = freezeDryRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'FREEZE_DRY', record: match });
      setActiveView('FREEZE_DRY');
    } else if (ref.moduleKey === 'EXPORT_SAMPLE') {
      const match = exportSampleRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'EXPORT_SAMPLE', record: match });
      setActiveView('EXPORT_SAMPLE');
    } else if (ref.moduleKey === 'SALES') {
      const match = salesRecords.find(r => r.refId === ref.refId);
      if (match) setEditingRecord({ moduleKey: 'SALES', record: match });
      setActiveView('SALES');
    } else {
      setSelectedRefIdForForm(ref.refId);
      setActiveView(ref.moduleKey);
    }
  };

  // --- SAVE HANDLERS FOR THE 7 MODULES ---

  // Birincil Kaynak Kaydı: Express Sunucumuz (Single Source of Truth) & Fotoğraf Yedeği
  const executeUnifiedSave = async (
    moduleKey: string,
    record: any,
    reference?: any,
    _isNewRef?: boolean,
    _newRefData?: any,
    _refId?: string
  ) => {
    // 1. Fotoğrafları GAS'a iletilmeden önce kendi Express sunucumuza yedekle
    if (record && Array.isArray(record.photos)) {
      for (let idx = 0; idx < record.photos.length; idx++) {
        const photoUrl = record.photos[idx];
        if (photoUrl && typeof photoUrl === 'string' && photoUrl.startsWith('data:image')) {
          const deterministicId = `${record.refId || record.id || 'photo'}_${idx}`;
          try {
            await uploadPhotoToServer(deterministicId, photoUrl);
            await savePhoto({
              id: deterministicId,
              refId: record.refId,
              moduleKey,
              location: record.location || record.orchard || '',
              description: record.description || record.notes || '',
              timestamp: record.timestamp || new Date().toISOString(),
              dataUrl: photoUrl,
              synced: true
            });
          } catch (err) {
            console.warn('[PhotoBackup] Express sunucusuna fotoğraf yedeklenirken uyarı:', err);
          }
        }
      }
    }

    // 2. Birincil Kaynak: Express Sunucusu (Race condition engellendi, GAS proxy'leme Express üzerinden yürütülür)
    try {
      await saveRecordToCentralServer(moduleKey, record, reference);
    } catch (err) {
      console.warn(`[UnifiedSave] Express kaydı yerel moda aktarıldı (${moduleKey}):`, err);
    }
  };

  // 0. Harvest Save (🍎 Günlük Saha Hasadı)
  const handleSaveHarvest = (record: HarvestRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    const safeRecord: HarvestRecord = {
      ...record,
      id: record.id?.trim() ? record.id : `harv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
    };

    // Kayıt zaten varsa güncelle, yoksa başa ekle
    setHarvestRecords(prev => {
      const exists = prev.some(r => r.id === safeRecord.id);
      return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
    });

    addDebugLog('FORM_SUBMIT', 'INFO', `Hasat kaydı oluşturuldu: ${safeRecord.refId} (${safeRecord.orchard}, ${safeRecord.dailyTotalKg} kg)`);

    let targetRef: ReferenceItem | undefined = undefined;
    if (isNewRef && newRefData) {
      const newRef: ReferenceItem = {
        refId: safeRecord.refId,
        moduleKey: 'HARVEST',
        product: `${safeRecord.product} (${safeRecord.variety})`,
        orchard: safeRecord.orchard,
        location: safeRecord.destination || 'Ambar 1',
        source: safeRecord.orchard || 'Bahçe',
        destination: newRefData.destination || 'Ambar 1 (Ön Soğutma)',
        finalDestination: newRefData.destination || 'Ambar 1 (Ön Soğutma)',
        quantity: safeRecord.dailyTotalKg,
        unit: 'kg',
        splitLots: safeRecord.splitLots,
        status: 'CREATED',
        createdAt: new Date().toISOString(),
        operator: safeRecord.foreman,
        notes: newRefData.notes
      };
      setReferences(prev => [newRef, ...prev]);
      targetRef = newRef;
    } else {
      // Mevcut referansı güncelle
      const existingRef = references.find(r => r.refId === safeRecord.refId);
      const updatedRef: ReferenceItem | undefined = existingRef ? {
        ...existingRef,
        product: `${safeRecord.product} (${safeRecord.variety})`,
        orchard: safeRecord.orchard,
        quantity: safeRecord.dailyTotalKg,
        splitLots: safeRecord.splitLots
      } : undefined;
      setReferences(prev => prev.map(r => r.refId === safeRecord.refId && updatedRef ? updatedRef : r));
      targetRef = updatedRef;
    }

    // Kalite / Günlük Hasat (Delilnama) kaydını otomatik olarak Hasat Takvimine senkronize et
    if (safeRecord.product && safeRecord.dailyTotalKg > 0 && !safeRecord.product.toLowerCase().includes('muz')) {
      syncQualityOrDelilnamaToHarvestCalendar({
        refId: safeRecord.refId,
        orchard: safeRecord.orchard || 'Garahan',
        product: safeRecord.product,
        variety: safeRecord.variety || safeRecord.product,
        quantityKg: safeRecord.dailyTotalKg,
        recordDate: safeRecord.recordDate || safeRecord.timestamp,
        sourceModule: 'HARVEST',
        isPreHarvestTestOnly: false
      });
    }

    setEditingRecord(null);
    triggerSuccessCelebration();
    showSuccess(`"${safeRecord.refId}" referanslı Günlük Hasat & Delilnama kaydı kaydedildi ve Hasat Takvimine otomatik işlendi.`, 'Hasat & Takvim Senkronize');
    executeUnifiedSave('HARVEST', safeRecord, targetRef, isNewRef, newRefData);
    recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'HARVEST', safeRecord.refId, { orchard: safeRecord.orchard, kg: safeRecord.dailyTotalKg });
    setActiveView('DASHBOARD');
  };

  // 1. Field Save
  const handleSaveField = (record: FieldRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    const safeRecord: FieldRecord = {
      ...record,
      id: record.id?.trim() ? record.id : `field-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
    };

    // Kayıt zaten varsa güncelle, yoksa başa ekle
    setFieldRecords(prev => {
      const exists = prev.some(r => r.id === safeRecord.id);
      return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
    });

    addDebugLog('FORM_SUBMIT', 'INFO', `Saha kalite testi kaydı oluşturuldu: ${safeRecord.refId} (${safeRecord.orchard}, ${safeRecord.product})`);

    let targetRef: ReferenceItem | undefined = undefined;
    if (isNewRef && newRefData) {
      const newRef: ReferenceItem = {
        refId: safeRecord.refId,
        moduleKey: 'FIELD',
        product: newRefData.product || `${safeRecord.product} (${safeRecord.sortVariety})`,
        orchard: safeRecord.orchard,
        location: newRefData.location || safeRecord.location,
        source: newRefData.source || safeRecord.location,
        destination: newRefData.destination || 'Merkez Soğuk Depo',
        finalDestination: newRefData.finalDestination || newRefData.destination || 'Merkez Soğuk Depo',
        quantity: newRefData.quantity || 1000,
        unit: 'kg',
        status: 'CREATED',
        createdAt: new Date().toISOString(),
        operator: safeRecord.operator,
        reroutedToFreezeDry: safeRecord.reroutedToFreezeDry,
        rerouteReason: safeRecord.rejectionReason,
        notes: newRefData.notes
      };
      setReferences(prev => [newRef, ...prev]);
      targetRef = newRef;
    } else {
      // Mevcut referansı güncelle
      const existingRef = references.find(r => r.refId === safeRecord.refId);
      const updatedRef: ReferenceItem | undefined = existingRef ? {
        ...existingRef,
        product: `${safeRecord.product} (${safeRecord.sortVariety})`,
        orchard: safeRecord.orchard,
        reroutedToFreezeDry: safeRecord.reroutedToFreezeDry,
        rerouteReason: safeRecord.rejectionReason
      } : undefined;
      setReferences(prev => prev.map(r => r.refId === safeRecord.refId && updatedRef ? updatedRef : r));
      targetRef = updatedRef;
    }

    // Saha Kalite Testi / Delilnama onayını otomatik olarak Hasat Takvimine ("Test Edildi" / Tonaj) senkronize et
    if (safeRecord.product) {
      const qtyKg = newRefData?.quantity || 0;
      syncQualityOrDelilnamaToHarvestCalendar({
        refId: safeRecord.refId,
        orchard: safeRecord.orchard || safeRecord.location || 'Garahan',
        product: safeRecord.product,
        variety: safeRecord.sortVariety || safeRecord.product,
        quantityKg: qtyKg,
        recordDate: safeRecord.harvestDate || safeRecord.timestamp,
        sourceModule: 'FIELD',
        isPreHarvestTestOnly: true
      });
    }

    setEditingRecord(null);
    triggerSuccessCelebration();
    showSuccess(`"${safeRecord.refId}" referanslı Saha Kalite Testi kaydedildi ve Hasat Takviminde "Test edildi" olarak güncellendi.`, 'Saha Kaydı & Takvim Senkronize');
    executeUnifiedSave('FIELD', safeRecord, targetRef, isNewRef, newRefData);
    recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'FIELD', safeRecord.refId, { orchard: safeRecord.orchard, product: safeRecord.product });
    setActiveView('DASHBOARD');
  };

  // 2. Muz Save
  const handleSaveMuz = (record: MuzRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    try {
      const safeRecord: MuzRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `muz-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setMuzRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'INFO', `Sera Muz hasat kaydı işlendi: ${safeRecord.refId} (${safeRecord.greenhouseNo}, ${safeRecord.netWeightKg} kg)`);

      let syncedRef: ReferenceItem | undefined;
      if (isNewRef && newRefData) {
        const newRef: ReferenceItem = {
          refId: safeRecord.refId,
          moduleKey: 'MUZ',
          product: newRefData.product || safeRecord.product,
          location: safeRecord.greenhouseNo,
          source: safeRecord.greenhouseNo,
          destination: newRefData.destination || 'Ambar 2',
          quantity: safeRecord.netWeightKg,
          unit: 'kg',
          status: 'CREATED',
          createdAt: new Date().toISOString(),
          operator: safeRecord.operator,
          notes: newRefData.notes
        };
        syncedRef = newRef;
        setReferences(prev => [newRef, ...prev]);
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${safeRecord.refId}" referanslı Sera Muz kaydı başarıyla oluşturuldu.`, 'Sera Muz Kaydı Başarılı');
      executeUnifiedSave('MUZ', safeRecord, syncedRef, isNewRef, newRefData);
      recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'MUZ', safeRecord.refId, { greenhouse: safeRecord.greenhouseNo, kg: safeRecord.netWeightKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Muz kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Muz kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // 3. Badem Save
  const handleSaveBadem = (record: BademRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    try {
      const safeRecord: BademRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `badem-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setBademRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'INFO', `Badem işleme kaydı işlendi: ${safeRecord.refId} (${safeRecord.totalLoadKg} kg)`);

      let syncedRef: ReferenceItem | undefined;
      if (isNewRef && newRefData) {
        const newRef: ReferenceItem = {
          refId: safeRecord.refId,
          moduleKey: 'BADEM',
          product: safeRecord.product,
          location: safeRecord.location,
          source: safeRecord.location,
          destination: newRefData.destination || 'Kuru Depo 1',
          quantity: safeRecord.totalLoadKg,
          unit: 'kg',
          status: 'CREATED',
          createdAt: new Date().toISOString(),
          operator: safeRecord.operator,
          notes: newRefData.notes
        };
        syncedRef = newRef;
        setReferences(prev => [newRef, ...prev]);
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${safeRecord.refId}" referanslı Badem İşleme kaydı başarıyla eklendi.`, 'Badem Kaydı Başarılı');
      executeUnifiedSave('BADEM', safeRecord, syncedRef, isNewRef, newRefData);
      recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'BADEM', safeRecord.refId, { location: safeRecord.location, loadKg: safeRecord.totalLoadKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Badem kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Badem kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // 4. Lojistik Save
  const handleSaveLojistik = (record: LojistikRecord, refId: string) => {
    try {
      const safeRecord: LojistikRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `loj-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setLojistikRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      // Update reference status
      setReferences(prev =>
        prev.map(r => (r.refId === refId ? { ...r, status: 'SHIPPED', destination: safeRecord.destination } : r))
      );

      addDebugLog('FORM_SUBMIT', 'INFO', `Frigorifik sevkiyat oluşturuldu: ${refId} (${safeRecord.vehiclePlate}, ${safeRecord.weightKg} kg)`);

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${refId}" referanslı Frigorifik Sevkiyat kaydı oluşturuldu.`, 'Lojistik Sevk Başarılı');
      executeUnifiedSave('LOJISTIK', safeRecord, undefined, false, undefined, refId);
      recordCentralAuditLog(currentUser, 'CREATE', 'LOJISTIK', safeRecord.refId, { driver: safeRecord.driver, plate: safeRecord.vehiclePlate, kg: safeRecord.weightKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Lojistik kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Lojistik kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // 5. Ambar Save
  const handleSaveAmbar = (record: AmbarRecord, refId: string) => {
    try {
      const safeRecord: AmbarRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `amb-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setAmbarRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      // Update reference status
      setReferences(prev =>
        prev.map(r => (r.refId === refId ? { ...r, status: 'RECEIVED', location: `${safeRecord.warehouse} (${safeRecord.roomNo})` } : r))
      );

      addDebugLog('FORM_SUBMIT', 'INFO', `Ambar kabul yapıldı: ${refId} (${safeRecord.warehouse}, ${safeRecord.acceptedWeightKg} kg)`);

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${refId}" referanslı Soğuk Depo & Ambar kabul kaydı kaydedildi.`, 'Ambar Giriş Başarılı');
      executeUnifiedSave('AMBAR', safeRecord, undefined, false, undefined, refId);
      recordCentralAuditLog(currentUser, 'CREATE', 'AMBAR', safeRecord.refId, { warehouse: safeRecord.warehouse, room: safeRecord.roomNo, kg: safeRecord.acceptedWeightKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Ambar kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Ambar kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // helper alias for ambar
  const setAmber = setAmbarRecords;

  // 6. Eksport Numune & Raf Ömrü Testi Save
  const handleSaveExportSample = (record: ExportSampleRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    try {
      const safeRecord: ExportSampleRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `exp-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setExportSampleRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'INFO', `İhracat numune testi kaydedildi: ${safeRecord.refId} (${safeRecord.destinationCountry})`);

      let syncedRef: ReferenceItem | undefined;
      if (isNewRef && newRefData) {
        const newRef: ReferenceItem = {
          refId: safeRecord.refId,
          moduleKey: 'EXPORT_SAMPLE',
          product: safeRecord.product,
          location: newRefData.location || `Eksport (${safeRecord.destinationCountry})`,
          source: 'Datly Miwe Sowuk Depo',
          destination: safeRecord.destinationCountry,
          quantity: newRefData.quantity || 1000,
          unit: 'kg',
          status: 'EXPORT_TESTED',
          createdAt: new Date().toISOString(),
          operator: safeRecord.operator,
          notes: newRefData.notes
        };
        syncedRef = newRef;
        setReferences(prev => [newRef, ...prev]);
      } else {
        // update existing ref status
        const existingRef = references.find(r => r.refId === safeRecord.refId);
        if (existingRef) syncedRef = { ...existingRef, status: 'EXPORT_TESTED' };
        setReferences(prev =>
          prev.map(r => (r.refId === safeRecord.refId ? { ...r, status: 'EXPORT_TESTED' } : r))
        );
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${safeRecord.refId}" referanslı İhracat Numune & Raf Ömrü testi kaydedildi.`, 'Numune Kaydı Başarılı');
      executeUnifiedSave('EXPORT_SAMPLE', safeRecord, syncedRef, isNewRef, newRefData);
      recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'EXPORT_SAMPLE', safeRecord.refId, { destination: safeRecord.destinationCountry });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `İhracat numune kaydı hatası: ${err?.message || err}`);
      showError(`İhracat numune kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // 7. Satış & Sevkiyat Çıkış Kütüğü Save
  const handleSaveSales = (record: SalesRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    try {
      const safeRecord: SalesRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `sale-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setSalesRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'INFO', `Satış ve çıkış kaydı tamamlandı: ${safeRecord.refId} (${safeRecord.customer}, ${safeRecord.totalQuantityKg} kg)`);

      let syncedRef: ReferenceItem | undefined;
      if (isNewRef && newRefData) {
        const newRef: ReferenceItem = {
          refId: safeRecord.refId,
          moduleKey: 'SALES',
          product: safeRecord.product,
          location: newRefData.location || `Satış & Sevkiyat (${safeRecord.salesChannel})`,
          source: 'Datly Miwe Sowuk Depo',
          destination: safeRecord.destination || safeRecord.customer,
          quantity: safeRecord.totalQuantityKg,
          unit: 'kg',
          status: 'SOLD',
          createdAt: new Date().toISOString(),
          operator: safeRecord.operator,
          notes: newRefData.notes
        };
        syncedRef = newRef;
        setReferences(prev => [newRef, ...prev]);
      } else {
        // update existing ref status to SOLD
        const existingRef = references.find(r => r.refId === safeRecord.refId);
        if (existingRef) syncedRef = { ...existingRef, status: 'SOLD', destination: safeRecord.destination || safeRecord.customer };
        setReferences(prev =>
          prev.map(r => (r.refId === safeRecord.refId ? { ...r, status: 'SOLD', destination: safeRecord.destination || safeRecord.customer } : r))
        );
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${safeRecord.refId}" referanslı Satış & Sevkiyat Çıkış Kütüğü kaydedildi.`, 'Satış Kaydı Başarılı');
      executeUnifiedSave('SALES', safeRecord, syncedRef, isNewRef, newRefData);
      recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'SALES', safeRecord.refId, { customer: safeRecord.customer, kg: safeRecord.totalQuantityKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Satış kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Satış kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // 8. Incident Save
  const handleSaveIncident = (record: IncidentRecord, refId: string) => {
    try {
      const safeRecord: IncidentRecord = {
        ...record,
        incidentId: record.incidentId?.trim() ? record.incidentId : `inc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        id: record.id?.trim() ? record.id : `inc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setIncidentRecords(prev => {
        const exists = prev.some(r => r.incidentId === safeRecord.incidentId || r.id === safeRecord.id);
        return exists ? prev.map(r => (r.incidentId === safeRecord.incidentId || r.id === safeRecord.id) ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'WARN', `Barlag akty / olay oluşturuldu: ${refId} (${safeRecord.incidentType}, Derece: ${safeRecord.actDegree || 2})`);

      // Mark reference status as INCIDENT if high/critical
      if (safeRecord.priority === 'CRITICAL' || safeRecord.priority === 'HIGH') {
        setReferences(prev =>
          prev.map(r => (r.refId === refId ? { ...r, status: 'INCIDENT' } : r))
        );
      }

      // 1. Derece / Kritik Olay Kontrolü & Bildirim Merkezine Otomatik İletim
      const isDegree1 = safeRecord.actDegree === 1 || safeRecord.priority === 'CRITICAL';
      if (isDegree1) {
        addNotification(
          'ALL',
          `🚨 [1. DERECE KRİTİK OLAY] ${safeRecord.incidentType || 'Barlag Akty'} (${refId})`,
          `[Akt Protokol: ${safeRecord.actNumber || safeRecord.incidentId || 'AKT'}] - ${safeRecord.affectedQuantityKg ? `${safeRecord.affectedQuantityKg.toLocaleString()} kg ürün etkilendi. ` : ''}${safeRecord.description || 'Kritik kalite sapması'}. Sorumlu: ${safeRecord.responsible || safeRecord.operator || 'Kalite Birimi'}. DÖF başlatıldı.`,
          'CRITICAL_ALERT',
          'INCIDENT',
          {
            incidentId: safeRecord.incidentId,
            refId: safeRecord.refId || refId,
            priority: 'CRITICAL',
            actDegree: 1,
            isResolved: false
          }
        );
        showError(`1. Derece Olay sisteme işlendi ve Bildirim Merkezi'ne acil durum uyarısı olarak gönderildi.`, '1. Derece Kritik Olay');
      } else {
        addNotification(
          'ALL',
          `⚠️ [Barlag Akty: ${safeRecord.actDegree || 2}. Derece] ${safeRecord.incidentType || 'Kalite Sapması'} (${refId})`,
          `${safeRecord.affectedQuantityKg ? `${safeRecord.affectedQuantityKg.toLocaleString()} kg etkilendi. ` : ''}${safeRecord.description || 'Kritik olmayan olay kaydı'}.`,
          'INFO',
          'INCIDENT',
          {
            incidentId: safeRecord.incidentId,
            refId: safeRecord.refId || refId,
            priority: safeRecord.priority || 'MEDIUM',
            actDegree: safeRecord.actDegree || 2,
            isResolved: false
          }
        );
        showSuccess(`"${refId}" referanslı Barlag Akty (Fire & Uygunsuzluk) kaydı açıldı.`, 'Olay Kaydı Başarılı');
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      executeUnifiedSave('INCIDENT', safeRecord, undefined, false, undefined, refId);
      recordCentralAuditLog(currentUser, 'CREATE', 'INCIDENT', safeRecord.refId || refId, { incidentType: safeRecord.incidentType, priority: safeRecord.priority });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Olay kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Olay kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // Quick Resolve Incident from Notification Center (Madde 4 & 7)
  const handleResolveIncidentFromNotification = (incidentId?: string, refId?: string, notifId?: string) => {
    const isMatching = incidentRecords.some(inc => 
      (incidentId && (inc.incidentId === incidentId || inc.id === incidentId)) ||
      (refId && inc.refId === refId && inc.status !== 'RESOLVED' && inc.status !== 'CLOSED')
    );

    setIncidentRecords(prev => prev.map(inc => {
      if (
        (incidentId && (inc.incidentId === incidentId || inc.id === incidentId)) ||
        (refId && inc.refId === refId && inc.status !== 'RESOLVED' && inc.status !== 'CLOSED')
      ) {
        const resolvedInc = {
          ...inc,
          status: 'RESOLVED' as const,
          notes: (inc.notes ? `${inc.notes}\n` : '') + `[${new Date().toLocaleDateString('tr-TR')} ${new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}] Bildirim Merkezi üzerinden çözüldü olarak işaretlendi.`
        };
        saveRecordToCentralServer('INCIDENT', resolvedInc);
        syncWithGas('resolveIncident', { incidentId: inc.incidentId || inc.id, refId: inc.refId, record: resolvedInc });
        return resolvedInc;
      }
      return inc;
    }));

    if (isMatching) {
      showSuccess(`Olay kaydı (${incidentId || refId || ''}) başarıyla "Çözüldü" olarak işaretlendi.`, 'Olay Çözüldü');
    } else {
      showSuccess(`Olay bildirimi başarıyla çözüldü olarak işaretlendi.`, 'Bildirim Çözüldü');
    }
  };

  // 9. Freeze & Dry Save
  const handleSaveFreezeDry = (record: FreezeDryRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => {
    try {
      const safeRecord: FreezeDryRecord = {
        ...record,
        id: record.id?.trim() ? record.id : `fd-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
      };

      setFreezeDryRecords(prev => {
        const exists = prev.some(r => r.id === safeRecord.id);
        return exists ? prev.map(r => r.id === safeRecord.id ? safeRecord : r) : [safeRecord, ...prev];
      });

      addDebugLog('FORM_SUBMIT', 'INFO', `Freeze-dry liyofilizasyon işlemi kaydedildi: ${safeRecord.refId} (${safeRecord.rawWeightKg} kg)`);

      let syncedRef: ReferenceItem | undefined;
      if (isNewRef && newRefData) {
        const newRef: ReferenceItem = {
          refId: safeRecord.refId,
          moduleKey: 'FREEZE_DRY',
          product: safeRecord.product,
          location: 'Freeze-Dry Liyofilizasyon Tesisi',
          source: safeRecord.rawMaterialSource || 'Saha / Soğuk Depo',
          destination: safeRecord.frozenStorageRoom || 'Paketleme & Kuru Depo',
          quantity: safeRecord.rawWeightKg,
          unit: 'kg',
          status: 'IN_FREEZE_DRY',
          createdAt: new Date().toISOString(),
          operator: safeRecord.operator,
          notes: safeRecord.notes
        };
        syncedRef = newRef;
        setReferences(prev => [newRef, ...prev]);
      } else {
        const existingRef = references.find(r => r.refId === safeRecord.refId);
        if (existingRef) syncedRef = { ...existingRef, status: 'IN_FREEZE_DRY', destination: 'Paketleme & Kuru Depo' };
        setReferences(prev =>
          prev.map(r => (r.refId === safeRecord.refId ? { ...r, status: 'IN_FREEZE_DRY', destination: 'Paketleme & Kuru Depo' } : r))
        );
      }

      setEditingRecord(null);
      triggerSuccessCelebration();
      showSuccess(`"${safeRecord.refId}" referanslı Freeze-Dry Liyofilizasyon kaydı oluşturuldu.`, 'Freeze-Dry Kaydı Başarılı');
      executeUnifiedSave('FREEZE_DRY', safeRecord, syncedRef, isNewRef, newRefData);
      recordCentralAuditLog(currentUser, isNewRef ? 'CREATE' : 'UPDATE', 'FREEZE_DRY', safeRecord.refId, { batch: safeRecord.refId, kg: safeRecord.rawWeightKg });
      setActiveView('DASHBOARD');
    } catch (err: any) {
      addDebugLog('MODULE_ERROR', 'ERROR', `Freeze-dry kaydı kaydedilirken hata: ${err?.message || err}`);
      showError(`Freeze-Dry kaydı kaydedilemedi: ${err?.message || err}`, 'Kayıt Hatası');
    }
  };

  // Incident resolution (Madde 4)
  const handleResolveIncident = (inc: IncidentRecord) => {
    const resolvedRecord: IncidentRecord = { ...inc, status: 'RESOLVED' as const };
    const updated = incidentRecords.map(i =>
      i.id === inc.id ? resolvedRecord : i
    );
    setIncidentRecords(updated);
    const hasOtherOpen = updated.some(i => i.refId === inc.refId && i.status !== 'RESOLVED');
    if (!hasOtherOpen) {
      setReferences(prev =>
        prev.map(r => (r.refId === inc.refId ? { ...r, status: 'RECEIVED' } : r))
      );
    }
    saveRecordToCentralServer('INCIDENT', resolvedRecord);
    syncWithGas('resolveIncident', { incidentId: inc.id || inc.incidentId, refId: inc.refId, record: resolvedRecord });
    showSuccess(`"${inc.refId}" referanslı Barlag Akty kaydı başarıyla çözüldü (RESOLVED).`, 'Durum Güncellendi');
  };

  // Delete Reference & associated module records with centralized consistency validation
  const handleDeleteReference = (refId: string) => {
    if (currentUser?.role !== 'ADMIN' && !currentUser?.permissions?.canDelete) {
      showError('⛔ Kayıt silme yetkiniz bulunmamaktadır. Lütfen Sistem Yöneticisi (Admin) ile iletişime geçin.', 'Yetki Engeli');
      return;
    }
    if (!window.confirm(`"${refId}" referans kodlu partiyi ve bağlı tüm verilerini silmek istediğinize emin misiniz?`)) {
      return;
    }
    logActivity(currentUser, 'DELETE', 'REFERENCES', `Referans silindi: ${refId}`);
    markAsDeleted(refId);

    const currentState: DataStoreState = {
      references,
      harvestRecords,
      fieldRecords,
      muzRecords,
      bademRecords,
      lojistikRecords,
      ambarRecords,
      exportSampleRecords,
      salesRecords,
      incidentRecords,
      freezeDryRecords
    };

    const nextState = removeReferenceAndDependents(refId, currentState);

    setReferences(nextState.references);
    setHarvestRecords(nextState.harvestRecords);
    setFieldRecords(nextState.fieldRecords);
    setMuzRecords(nextState.muzRecords);
    setBademRecords(nextState.bademRecords);
    setLojistikRecords(nextState.lojistikRecords);
    setAmbarRecords(nextState.ambarRecords);
    setExportSampleRecords(nextState.exportSampleRecords);
    setSalesRecords(nextState.salesRecords);
    setIncidentRecords(nextState.incidentRecords);
    setFreezeDryRecords(nextState.freezeDryRecords);

    showSuccess(`"${refId}" referans kodlu kayıt ve bağlı tüm veriler başarıyla silindi.`, 'Referans Silindi');
    syncWithGas('deleteReference', { refId });
    deleteReferenceFromCentralServer(refId);
  };

  // Toplu Referans Durumu Güncelleme / Bulk Status Update (Madde 7: localStorage yazımlarını updater'lardan çıkar)
  const handleBulkUpdateReferences = (
    refIds: string[],
    newStatus: ReferenceStatus,
    options: { notes?: string; isLocked?: boolean; operator?: string }
  ) => {
    if (!refIds || refIds.length === 0) return;

    if (currentUser?.role !== 'ADMIN' && !currentUser?.permissions?.canEdit) {
      showError('⛔ Toplu güncelleme yetkiniz bulunmamaktadır. Lütfen Sistem Yöneticisi ile iletişime geçin.', 'Yetki Engeli');
      return;
    }

    const refIdSet = new Set(refIds);

    // 1. Update references (persist useEffect zaten senkronize ediyor)
    setReferences(prev => prev.map(r => {
      if (refIdSet.has(r.refId)) {
        return {
          ...r,
          status: newStatus,
          isLocked: options.isLocked !== undefined ? options.isLocked : r.isLocked,
          notes: options.notes 
            ? (r.notes ? `${r.notes}\n[Toplu Durum: ${options.notes}]` : options.notes)
            : r.notes
        };
      }
      return r;
    }));

    // 2. If newStatus is COMPLETED, update related child testStatus
    if (newStatus === 'COMPLETED') {
      setFieldRecords(prev => prev.map(f => refIdSet.has(f.refId) ? { ...f, testStatus: 'COMPLETED' as const } : f));
      setHarvestRecords(prev => prev.map(h => refIdSet.has(h.refId) ? { ...h, status: 'COMPLETED' as const } : h));
      setMuzRecords(prev => prev.map(m => refIdSet.has(m.refId) ? { ...m, testStatus: 'COMPLETED' as const } : m));
    }

    // 3. Central Sync & Audit Log
    syncWithGas('bulkUpdateReferences', { refIds, status: newStatus, ...options });
    recordCentralAuditLog(currentUser, 'UPDATE', 'REFERENCES', `BULK-${refIds.length}`, {
      refCount: refIds.length,
      refIds,
      newStatus,
      ...options
    });
    logActivity(currentUser, 'UPDATE', 'REFERENCES', `Toplu ${refIds.length} adet referans durumu "${newStatus}" olarak güncellendi.`);

    triggerSuccessCelebration();
    showSuccess(`Seçilen ${refIds.length} adet parti başarıyla "${newStatus}" durumuna güncellendi!`, 'Toplu Güncelleme Başarılı');
  };

  // Hızlı Yönetici Notu Ekleme / Quick Administrative Note (Form açılmadan)
  const handleQuickAddAdminNote = (
    refId: string,
    noteText: string,
    options: {
      category?: string;
      priority?: 'NORMAL' | 'WARNING' | 'CRITICAL';
      operator?: string;
      append?: boolean;
    } = {}
  ) => {
    if (!refId || !noteText) return;

    const dateStamp = new Date().toLocaleString('tr-TR');
    const author = options.operator || currentUser?.fullName || currentUser?.email || 'Yönetici';
    const cat = options.category ? ` [${options.category}]` : '';
    const prio = options.priority && options.priority !== 'NORMAL' ? ` [${options.priority}]` : '';
    const newEntry = `[${dateStamp} - ${author}${cat}${prio}]: ${noteText}`;

    setReferences(prev => prev.map(r => {
      if (r.refId === refId) {
        const existing = r.notes ? r.notes.trim() : '';
        const updatedNotes = options.append !== false && existing ? `${existing}\n${newEntry}` : newEntry;
        return {
          ...r,
          notes: updatedNotes,
          updatedAt: new Date().toISOString()
        };
      }
      return r;
    }));

    syncWithGas('updateReferenceNote', { refId, note: newEntry, ...options });
    recordCentralAuditLog(currentUser, 'UPDATE', 'REFERENCES', refId, {
      action: 'QUICK_ADMIN_NOTE',
      note: noteText,
      ...options
    });
    logActivity(currentUser, 'UPDATE', 'REFERENCES', `Hızlı idari not eklendi: ${refId} (${noteText.slice(0, 40)}...)`);
    triggerSuccessCelebration();
    showSuccess(`"${refId}" referansına idari not başarıyla kaydedildi.`, 'İdari Not Kaydedildi');
  };

  // Delete Incident / Barlag Akty record (Madde 4)
  const handleDeleteIncident = (incidentId: string) => {
    if (currentUser?.role !== 'ADMIN' && !currentUser?.permissions?.canDelete) {
      showError('⛔ Barlag akty silme yetkiniz bulunmamaktadır.', 'Yetki Engeli');
      return;
    }
    logActivity(currentUser, 'DELETE', 'INCIDENT', `Barlag akty silindi: ${incidentId}`);
    markAsDeleted(incidentId);
    setIncidentRecords(prev => prev.filter(i => (i.id !== incidentId && i.incidentId !== incidentId)));
    syncWithGas('deleteIncident', { incidentId, id: incidentId });
    deleteReferenceFromCentralServer(incidentId);
    showSuccess('Barlag akty kaydı başarıyla silindi.', 'Kayıt Silindi');
  };

  // One-click full system database JSON export (Backup)
  const handleDownloadFullBackup = () => {
    try {
      const fullSystemBackup = {
        meta: {
          exportDate: new Date().toISOString(),
          appName: 'Datly Miwe - Gıda & Meyve İzlenebilirlik Sistemi',
          version: '3.5.0',
          exportedBy: currentUser ? { id: currentUser.id, name: currentUser.fullName, email: currentUser.email, role: currentUser.role } : 'Anonim'
        },
        database: {
          references,
          harvestRecords,
          fieldRecords,
          muzRecords,
          bademRecords,
          lojistikRecords,
          ambarRecords,
          exportSampleRecords,
          salesRecords,
          incidentRecords,
          freezeDryRecords,
          customFields
        }
      };

      const jsonString = JSON.stringify(fullSystemBackup, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `datly_miwe_yedek_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      showSuccess('Tüm yerel veritabanı JSON dosyası olarak başarıyla dışa aktarıldı.', 'Yedekleme Başarılı');
      logActivity(currentUser, 'EXPORT', 'SYSTEM', 'Tüm sistem veritabanı JSON yedeği indirildi.');
    } catch (err: any) {
      showError(`Veritabanı yedeği indirilirken hata oluştu: ${err?.message || err}`, 'Yedekleme Hatası');
    }
  };

  // Clear all demo sample data so users can start totally clean with their own real records
  const handleClearAllDemoData = () => {
    if (currentUser?.role !== 'ADMIN' && !currentUser?.permissions?.canClearDemo) {
      showError('⛔ Örnek kayıtları temizleme yetkisi yalnızca Sistem Yöneticisine (Admin) aittir.', 'Yetki Engeli');
      return;
    }
    if (!window.confirm('Tüm örnek kayıtlar silinip sistem tamamen sıfırlanacaktır. Bu işlem geri alınamaz. Devam etmek istiyor musunuz?')) {
      return;
    }
    logActivity(currentUser, 'CLEAR_DEMO', 'DASHBOARD', 'Tüm demo ve örnek veriler temizlendi');
    setReferences([]);
    setHarvestRecords([]);
    setFieldRecords([]);
    setMuzRecords([]);
    setBademRecords([]);
    setLojistikRecords([]);
    setAmbarRecords([]);
    setExportSampleRecords([]);
    setSalesRecords([]);
    setIncidentRecords([]);
    setFreezeDryRecords([]);
    safeLocalStorageSetItem('miwe_references', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_harvest_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_field_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_muz_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_badem_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_lojistik_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_ambar_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_export_sample_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_sales_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_incident_records', JSON.stringify([]));
    safeLocalStorageSetItem('miwe_freeze_dry_records', JSON.stringify([]));
  };

  // Restore demo data
  const handleRestoreDemoData = () => {
    setReferences(INITIAL_REFERENCES);
    setHarvestRecords(INITIAL_HARVEST_RECORDS);
    setFieldRecords(INITIAL_FIELD_RECORDS);
    setMuzRecords(INITIAL_MUZ_RECORDS);
    setBademRecords(INITIAL_BADEM_RECORDS);
    setLojistikRecords(INITIAL_LOJISTIK_RECORDS);
    setAmbarRecords(INITIAL_AMBAR_RECORDS);
    setExportSampleRecords(INITIAL_EXPORT_SAMPLE_RECORDS);
    setSalesRecords(INITIAL_SALES_RECORDS);
    setIncidentRecords(INITIAL_INCIDENT_RECORDS);
    setFreezeDryRecords(INITIAL_FREEZE_DRY_RECORDS);
  };

  // Kalite Sapması / Riskli Parti Freeze & Dry Yönlendirme
  const handleRerouteBatchToFreezeDry = (refId: string, reason: string) => {
    setFieldRecords(prev => prev.map(rec => {
      if (rec.refId === refId) {
        return {
          ...rec,
          finalProductStatus: 'FREEZE_DRY',
          rejectionReason: reason
        };
      }
      return rec;
    }));
    setReferences(prev => prev.map(ref => {
      if (ref.refId === refId) {
        return {
          ...ref,
          kaliteSinifi: 'Freeze & Dry Yönlendirildi'
        };
      }
      return ref;
    }));
    showSuccess(`Parti ${refId} Freeze & Dry (-40°C Şoklama & Liyofilizasyon) hattına yönlendirildi.`, 'Kalite Aksiyonu Tamamlandı');
    addDebugLog('SYSTEM', 'INFO', `Parti ${refId} Freeze & Dry hattına yönlendirildi: ${reason}`);
  };

  // Feedback & Complaint Handlers
  const handleSaveFeedback = async (record: FeedbackRecord) => {
    setFeedbacks(prev => [record, ...prev]);
    triggerSuccessCelebration();
    saveRecordToCentralServer('FEEDBACK', record);

    if (!SHEETS_PUSH_ENABLED) {
      // v2: geri bildirim Firestore'a yazıldı; tablo oradan okur
    } else if (isOnline && gasUrl) {
      try {
        await submitFeedbackToGas(gasUrl, record);
      } catch (err) {
        console.warn('Feedback GAS senkronizasyonu kuyruğa alındı:', err);
        setOfflineQueue(prev => [...prev, { action: 'submitFeedback', payload: record }]);
      }
    } else {
      setOfflineQueue(prev => [...prev, { action: 'submitFeedback', payload: record }]);
    }
  };

  const handleUpdateFeedbackStatus = (id: string, status: FeedbackStatus, note?: string) => {
    setFeedbacks(prev => prev.map(f => {
      if (f.id === id) {
        return {
          ...f,
          status,
          resolutionNote: note ?? f.resolutionNote,
          resolvedAt: status === 'RESOLVED' ? new Date().toISOString() : f.resolvedAt
        };
      }
      return f;
    }));
  };

  const handleDeleteFeedback = (id: string) => {
    markAsDeleted(id);
    setFeedbacks(prev => prev.filter(f => f.id !== id));
    syncWithGas('deleteFeedback', { feedbackId: id, id });
  };

  const handleDeletePhoto = async (photo: PhotoRecord) => {
    try {
      if (photo.id) {
        markAsDeleted(photo.id);
        await deletePhoto(photo.id, photo.dataUrl);
      }
    } catch (err) {
      console.error('Failed to delete photo from IndexedDB:', err);
    }

    syncWithGas('deletePhoto', { photoId: photo.id, refId: photo.refId });

    if (photo.dataUrl) {
      const targetUrl = photo.dataUrl;
      // Madde 7: localStorage yazımlarını updater'lardan çıkar
      setHarvestRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setFieldRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setMuzRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setBademRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setFreezeDryRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setIncidentRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setReferences(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setAmbarRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setLojistikRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setExportSampleRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      setSalesRecords(prev => prev.map(r => ({ ...r, photos: (r.photos || []).filter(p => p !== targetUrl) })));
      showSuccess('Fotoğraf kaydı ve bağlı form ilişkisi silindi.', 'Fotoğraf Silindi');
    }
  };

  // Check Authentication: If not logged in, render the Login / Registration Portal
  if (!currentUser) {
    return (
      <LoginView
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          triggerSuccessCelebration();
        }}
      />
    );
  }

  const pendingApprovalsCount = getUsers().filter(u => u.status === 'PENDING').length;
  const pendingDispatchesCount = references.filter(r => r.status === 'CREATED').length;
  const pendingReceiptsCount = references.filter(r => r.status === 'SHIPPED' || r.status === 'IN_TRANSIT').length;
  const pendingIncidentsCount = incidentRecords.filter(i => i.status === 'OPEN' || i.status === 'IN_PROGRESS').length;
  const pendingOfflineQueueCount = offlineQueue.length;
  const totalPendingToday = pendingApprovalsCount + pendingDispatchesCount + pendingReceiptsCount + pendingIncidentsCount + pendingOfflineQueueCount;

  const handleOpenAdminPortal = () => {
    if (isAdminAuthenticated()) {
      setInitialPortalTab('ADMIN_SYSTEM');
      setActiveView('QUALITY_ROADMAP');
    } else {
      setIsAdminPasswordModalOpen(true);
    }
  };

  if (isInitialLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 font-sans">
        <div className="relative flex items-center justify-center mb-6">
          <div className="w-20 h-20 rounded-full border-4 border-teal-500/20 border-t-teal-400 animate-spin"></div>
          <div className="absolute w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
            <Leaf className="w-6 h-6 animate-pulse" />
          </div>
        </div>
        <h2 className="text-xl font-black tracking-tight text-white mb-2">MIWE HIL Zirai Kalite Platformu</h2>
        <p className="text-xs text-slate-400 font-mono max-w-sm text-center animate-pulse">
          Firestore Bulut Veritabanı ile Gerçek Zamanlı Senkronize Ediliyor...
        </p>
      </div>
    );
  }

  return (
    <GlobalPlatformProvider
      data={{
        references,
        harvestRecords,
        fieldRecords,
        muzRecords,
        bademRecords,
        lojistikRecords,
        ambarRecords,
        salesRecords,
        incidentRecords,
        exportSampleRecords,
        freezeDryRecords,
        feedbacks,
        customFields,
        stats,
        fieldBreakdown
      }}
    >
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-emerald-600 selection:text-white transition-colors duration-200 w-[100dvw] overflow-x-hidden">
      
      {/* Sticky Warning Banner for PASIF_READER (Ziyaretçi Modu) */}
      {currentUser?.status === 'PASIF_READER' && showPasifReaderBanner && (
        <div className="sticky top-0 z-50 bg-amber-500 text-slate-950 font-medium px-4 py-2.5 shadow-md flex items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-slate-950 shrink-0" />
            <span>⚠️ Hesabınız henüz tam yetkili değil. Sistemde sadece gezinebilir ve verileri görüntüleyebilirsiniz. Veri girişi için Sistem Yöneticinizden yetki talep edin.</span>
          </div>
          <button
            type="button"
            onClick={() => {
              sessionStorage.setItem('miwe_pasif_reader_banner_dismissed', 'true');
              setShowPasifReaderBanner(false);
            }}
            className="p-1 rounded-lg hover:bg-amber-600/30 text-slate-950 transition cursor-pointer font-bold shrink-0 text-base leading-none"
            title="Kapat"
          >
            ✕
          </button>
        </div>
      )}

      {/* Top Header */}
      <Header
        onSearchRef={handleSearchRef}
        onOpenAdminPortal={handleOpenAdminPortal}
        onOpenGasModal={() => setIsGasModalOpen(true)}
        onOpenQuickNew={() => handleSelectModule('HARVEST', 'NEW')}
        onSelectModule={handleSelectModule}
        onOpenCustomFields={() => setIsCustomFieldsModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onOpenFeedback={() => setActiveView('FEEDBACK')}
        onOpenDiagnostics={() => setActiveView('DIAGNOSTICS')}
        onOpenGuide={() => setActiveView('GUIDE_PORTAL')}
        onOpenMonthlyReport={() => setActiveView('MONTHLY_REPORT')}
        onOpenSummary={() => setActiveView('SUMMARY')}
        onOpenPwaModal={() => setIsPwaModalOpen(true)}
        onOpenGallery={() => setActiveView('GALLERY')}
        isSyncing={isSyncing}
        isOnline={isOnline}
        offlineQueueCount={offlineQueue.length}
        onSyncOfflineQueue={triggerOfflineQueueSync}
        onOpenSyncModal={() => setIsSyncModalOpen(true)}
        lastSyncTime={lastSyncTime}
        syncStatus={syncStatus}
        lastSyncError={syncErrorMessage}
        totalRefsCount={references.length}
        completedRefsCount={stats.completedCount}
        spreadsheetUrl={spreadsheetUrl}
        onPullFromSheets={pullFromGoogleSheets}
        onNavigateToDashboard={handleNavigateToDashboard}
        currentUser={currentUser}
        onOpenAdminModal={() => setIsAdminModalOpen(true)}
        onLogout={handleLogout}
        pendingApprovalsCount={pendingApprovalsCount}
        pendingTasksCount={totalPendingToday}
        pendingTasksBreakdown={{
          approvals: pendingApprovalsCount,
          dispatches: pendingDispatchesCount,
          receipts: pendingReceiptsCount,
          incidents: pendingIncidentsCount,
          offlineSync: pendingOfflineQueueCount
        }}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenCreateNotification={() => setIsCreateNotificationModalOpen(true)}
        onDownloadBackup={handleDownloadFullBackup}
        onResolveIncident={handleResolveIncidentFromNotification}
        onNavigateToView={(v) => {
          if (v === 'DASHBOARD') {
            handleNavigateToDashboard();
          } else {
            setActiveView(v);
            if (v !== 'HARVEST_PORTAL' && v !== 'QUALITY_ROADMAP' && v !== 'DEPARTMENT_SCORING' && v !== 'REPORTING_PORTAL') {
              setActivePortalBreadcrumb(null);
              setInitialPortalTab(null);
            }
          }
        }}
        activeFieldContext={activeFieldContext}
        onSelectFieldContext={handleSelectFieldContext}
        activeView={activeView}
        activePortalBreadcrumb={activePortalBreadcrumb}
      />

      {/* Main Container */}
      <main 
        style={{
          paddingBottom: 'calc(5.5rem + env(safe-area-inset-bottom, 0px))',
          paddingLeft: 'calc(0.625rem + env(safe-area-inset-left, 0px))',
          paddingRight: 'calc(0.625rem + env(safe-area-inset-right, 0px))'
        }}
        className="flex-1 w-full max-w-full sm:max-w-[1600px] mx-auto py-3 sm:py-6 min-w-0 overflow-x-hidden"
      >
        {activeView === 'PORTAL_LAUNCHER' ? (
          <PortalLauncher
            currentUser={currentUser}
            totalRefsCount={references.length}
            lastSyncTime={lastSyncTime}
            isOnline={isOnline}
            onNavigate={handleNavigateFromPortalLauncher}
            onBackToDashboard={() => setActiveView('DASHBOARD')}
            onOpenPresentationWizard={() => setShowPresentationModal(true)}
          />
        ) : (
          <div className="w-full space-y-4">
            {/* Portallara girildiğinde görünen sol üst dönüş butonu */}
            <div className="p-3 sm:p-4 bg-white border border-slate-200/90 rounded-2xl flex items-center justify-between shadow-xs">
              <button
                type="button"
                onClick={() => setActiveView('PORTAL_LAUNCHER')}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-bold transition cursor-pointer"
              >
                <span>← Ana Portallara Dön</span>
              </button>
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-slate-500 hidden sm:inline">Aktif Görünüm: {activeView}</span>
                <button
                  type="button"
                  onClick={handleResetAllStocksAndRecords}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-xs"
                  title="Tüm stok, ambar ve kayıtları sıfırlayarak temiz başlangıç yap"
                >
                  <span>🗑️ Stokları &amp; Kayıtları Sıfırla</span>
                </button>
              </div>
            </div>

            {/* VIEW 1: DASHBOARD */}
            {activeView === 'DASHBOARD' && (
              <div className="w-full space-y-6">

            {/* Non-Admin Top Card: "Bugünkü İşler" (Bekleyen sevk, kabul, olay, onay ve çevrimdışı kuyruk) */}
            {currentUser?.role !== 'ADMIN' && (
              <div className="bg-white text-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base sm:text-lg text-slate-900">
                        Bugünkü İşler & Operasyonel Görevler
                      </h3>
                      <p className="text-xs text-slate-500">
                        Hoş geldiniz, {currentUser?.fullName} ({currentUser?.jobTitle})
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveView('PENDING')}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer self-start sm:self-center shadow-xs min-h-[44px]"
                  >
                    Tüm Görevleri Yönet →
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-sans">Bekleyen Sevk:</span>
                    <strong className="text-base font-extrabold text-amber-600 tabular-nums">{pendingDispatchesCount}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-sans">Bekleyen Kabul:</span>
                    <strong className="text-base font-extrabold text-emerald-600 tabular-nums">{pendingReceiptsCount}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-sans">Açık İhtilaf / Akt:</span>
                    <strong className="text-base font-extrabold text-rose-600 tabular-nums">{pendingIncidentsCount}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-sans">Bekleyen Onay:</span>
                    <strong className="text-base font-extrabold text-purple-600 tabular-nums">{pendingApprovalsCount}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 col-span-2 sm:col-span-1">
                    <span className="text-slate-500 block text-[11px] font-sans">Çevrimdışı Kuyruk:</span>
                    <strong className="text-base font-extrabold text-teal-600 tabular-nums">{pendingOfflineQueueCount}</strong>
                  </div>
                </div>
              </div>
            )}

            {/* Admin Top Metric Cards */}
            {currentUser?.role === 'ADMIN' && (
              <DashboardStats
                stats={stats}
                fieldBreakdown={fieldBreakdown}
                references={references}
                ambarRecords={ambarRecords}
                onResetStocks={handleResetAllStocksAndRecords}
                lastSyncTime={lastSyncTime}
                offlineQueueCount={offlineQueue.length}
                isSyncing={isSyncing}
                isOnline={isOnline}
                onManualSync={() => syncCentralAppData()}
                onOpenSyncModal={() => setIsSyncModalOpen(true)}
                onSelectModule={handleSelectModule}
                onFilterStatus={(st) => {
                  setActiveStatFilter(st);
                  if (st !== 'ALL') {
                    setActiveView('REFERENCES');
                  }
                }}
                activeFilter={activeStatFilter}
              />
            )}

            <ModuleCards
              onSelectModule={handleSelectModule}
              onOpenSystemView={(v) => setActiveView(v as any)}
              onOpenPwaModal={() => setIsPwaModalOpen(true)}
              onOpenTraceabilityLedger={() => {
                setSelectedLedgerRefId(undefined);
                setActiveView('TRACEABILITY_LEDGER');
              }}
              onOpenProofModal={() => setIsVisualStandardsModalOpen(true)}
              activeView={activeView}
              pendingCount={pendingCount}
              currentUser={currentUser}
              isReadOnlyUser={isReadOnlyUser}
              ambarRecords={ambarRecords}
              lojistikRecords={lojistikRecords}
              salesRecords={salesRecords}
              references={references}
            />

            {/* Non-Admin KPI Cards placed below ModuleCards */}
            {currentUser?.role !== 'ADMIN' && (
              <DashboardStats
                stats={stats}
                fieldBreakdown={fieldBreakdown}
                references={references}
                ambarRecords={ambarRecords}
                onResetStocks={currentUser?.permissions?.canDelete ? handleResetAllStocksAndRecords : undefined}
                lastSyncTime={lastSyncTime}
                offlineQueueCount={offlineQueue.length}
                isSyncing={isSyncing}
                isOnline={isOnline}
                onManualSync={() => syncCentralAppData()}
                onOpenSyncModal={() => setIsSyncModalOpen(true)}
                onFilterStatus={(st) => {
                  setActiveStatFilter(st);
                  if (st !== 'ALL') {
                    setActiveView('REFERENCES');
                  }
                }}
                activeFilter={activeStatFilter}
              />
            )}

            {/* Son Referanslar / Recent Ledger (Filtrelenmiş veya Varsayılan Tüm Parseller) */}
            <div className="pt-2">
              <ReferencesView
                references={references}
                fieldRecords={fieldRecords}
                harvestRecords={harvestRecords}
                muzRecords={muzRecords}
                bademRecords={bademRecords}
                ambarRecords={ambarRecords}
                lojistikRecords={lojistikRecords}
                salesRecords={salesRecords}
                offlineQueue={offlineQueue}
                isReadOnlyUser={isReadOnlyUser}
                onSyncSingleQueueItem={handleSyncSingleQueueItem}
                onOpenTraceability={(r) => setActivePdfRef(r)}
                onDispatch={handleDirectDispatch}
                onReceive={handleDirectReceive}
                onOpenIncident={handleDirectIncident}
                onDeleteReference={handleDeleteReference}
                onEditReference={handleEditReference}
                onAddAdminNote={handleQuickAddAdminNote}
                onBulkUpdateReferences={handleBulkUpdateReferences}
                title="Son Eklenen Kayıtlar (Tüm Parseller)"
                subtitle="Sisteme işlenen en yeni referans partileri"
                isRecentLedger={true}
                onViewAll={() => setActiveView('REFERENCES')}
                totalRefCount={references.length}
                completedRefCount={stats.completedCount}
              />
            </div>

            {/* AŞAMA 21c: YALNIZCA DASHBOARD'DA GÖRÜNEN MEVCUT STOK GRAFİĞİ VE RİSK RADARI */}
            <GlobalPlatformFooter
              activeFieldContext={activeFieldContext}
              onSelectFieldContext={handleSelectFieldContext}
              references={references}
              ambarRecords={ambarRecords}
              fieldRecords={fieldRecords}
              onOpenSystemView={(v) => setActiveView(v)}
              currentView={activeView}
              onSearchRef={handleSearchRef}
              onRerouteToFreezeDry={handleRerouteBatchToFreezeDry}
              onOpenTraceability={(ref) => setActivePdfRef(ref)}
              onOpenFieldTest={(_refId) => {
                handleSelectModule('FIELD', 'EXISTING');
              }}
            />
          </div>
        )}

        {/* VIEW 2: MASTER MODULE FORMS */}
        {activeView === 'HARVEST' && (
          <DailyHarvestForm
            onSave={handleSaveHarvest}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'HARVEST' ? editingRecord.record : undefined}
            customFields={customFields.filter(f => f.moduleKey === 'HARVEST')}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            fieldRecords={fieldRecords}
            activeFieldContext={activeFieldContext}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'FIELD' && (
          <FieldForm
            onSave={handleSaveField}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'FIELD' ? editingRecord.record : undefined}
            activeFieldContext={activeFieldContext}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'MUZ' && (
          <MuzForm
            onSave={handleSaveMuz}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'MUZ' ? editingRecord.record : undefined}
            activeFieldContext={activeFieldContext}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'BADEM' && (
          <BademForm
            onSave={handleSaveBadem}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'BADEM' ? editingRecord.record : undefined}
            bademRecords={bademRecords}
            harvestRecords={harvestRecords}
            activeFieldContext={activeFieldContext}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'LOJISTIK' && (
          <LojistikForm
            onSave={handleSaveLojistik}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'LOJISTIK' ? editingRecord.record : undefined}
            onOpenGallery={() => setActiveView('GALLERY')}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'AMBAR' && (
          <AmbarForm
            onSave={handleSaveAmbar}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'AMBAR' ? editingRecord.record : undefined}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'INCIDENT' && (
          <IncidentForm
            onSave={handleSaveIncident}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'INCIDENT' ? editingRecord.record : undefined}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'EXPORT_SAMPLE' && (
          <ExportSampleForm
            onSave={handleSaveExportSample}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'EXPORT_SAMPLE' ? editingRecord.record : undefined}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'SALES' && (
          <SalesForm
            onSave={handleSaveSales}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'SALES' ? editingRecord.record : undefined}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'FREEZE_DRY' && (
          <FreezeDryForm
            onSave={handleSaveFreezeDry}
            onCancel={() => {
              setEditingRecord(null);
              setActiveView('DASHBOARD');
            }}
            existingRefs={references}
            initialRefId={selectedRefIdForForm}
            initialRecord={editingRecord?.moduleKey === 'FREEZE_DRY' ? editingRecord.record : undefined}
            fieldRecords={fieldRecords}
            harvestRecords={harvestRecords}
            freezeDryRecords={freezeDryRecords}
            bademRecords={bademRecords}
            isReadOnly={isReadOnlyUser}
          />
        )}

        {activeView === 'HARVEST_PORTAL' && (
          <HarvestPlanningPortal
            onBackToMainApp={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToPortals={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToDashboard={handleNavigateToDashboard}
            onSwitchPortal={handleNavigateFromPortalLauncher}
            currentUserId={currentUser?.id}
            muzRecords={muzRecords as any}
            dailyHarvestRecords={harvestRecords as any}
            bademRecords={bademRecords as any}
            freezeDryRecords={freezeDryRecords as any}
            activeFieldContext={activeFieldContext}
            onSelectFieldContext={handleSelectFieldContext}
            initialTab={initialPortalTab as any}
          />
        )}

        {/* QUALITY ROADMAP & INTERNATIONAL KPI PORTAL (GATE 3 - KALİTE & SİSTEM) */}
        {activeView === 'QUALITY_ROADMAP' && (
          <QualityRoadmapPortal
            onBackToMainApp={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToPortals={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToDashboard={handleNavigateToDashboard}
            onSwitchPortal={handleNavigateFromPortalLauncher}
            currentUser={currentUser}
            fieldRecords={fieldRecords}
            ambarRecords={ambarRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            freezeDryRecords={freezeDryRecords}
            harvestRecords={harvestRecords}
            incidentRecords={incidentRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            lojistikRecords={lojistikRecords}
            references={references}
            feedbacks={feedbacks}
            customFields={customFields}
            onForceServerSync={syncCentralAppData}
            onNavigateToView={(v) => setActiveView(v)}
            onSelectModule={handleSelectModule}
            initialTab={initialPortalTab as any}
          />
        )}

        {/* ENTEGRE 3. KAPI SİSTEM YÖNETİMİ YÖNLENDİRMESİ */}
        {activeView === 'DEPARTMENT_SCORING' && (
          <QualityRoadmapPortal
            onBackToMainApp={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToPortals={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToDashboard={handleNavigateToDashboard}
            onSwitchPortal={handleNavigateFromPortalLauncher}
            currentUser={currentUser}
            fieldRecords={fieldRecords}
            ambarRecords={ambarRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            freezeDryRecords={freezeDryRecords}
            harvestRecords={harvestRecords}
            incidentRecords={incidentRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            lojistikRecords={lojistikRecords}
            references={references}
            feedbacks={feedbacks}
            customFields={customFields}
            onForceServerSync={syncCentralAppData}
            onNavigateToView={(v) => setActiveView(v)}
            onSelectModule={handleSelectModule}
            initialTab="ADMIN_SYSTEM"
          />
        )}

        {/* GATE 4: REPORTING, ANALYTICS & PRESENTATION HUB */}
        {activeView === 'REPORTING_PORTAL' && (
          <ReportingPresentationPortal
            references={references}
            stats={stats}
            fieldBreakdown={fieldBreakdown}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            lojistikRecords={lojistikRecords}
            ambarRecords={ambarRecords}
            freezeDryRecords={freezeDryRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            incidentRecords={incidentRecords}
            feedbacks={feedbacks}
            currentUser={currentUser}
            onBackToPortals={() => setActiveView('PORTAL_LAUNCHER')}
            onBackToDashboard={handleNavigateToDashboard}
            onSelectModule={handleSelectModule}
            onSelectReference={handleSearchRef}
            onOpenTraceability={(ref) => setActivePdfRef(ref)}
            initialTab={initialPortalTab as any}
          />
        )}

        {/* SYSTEM VIEWS */}
        {activeView === 'GALLERY' && (
          <GalleryView
            references={references}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
            incidentRecords={incidentRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            freezeDryRecords={freezeDryRecords}
            lojistikRecords={lojistikRecords}
            ambarRecords={ambarRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            onDeletePhoto={handleDeletePhoto}
            onBack={() => setActiveView('DASHBOARD')}
          />
        )}

        {activeView === 'REFERENCES' && (
          <ReferencesView
            references={references}
            fieldRecords={fieldRecords}
            harvestRecords={harvestRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            ambarRecords={ambarRecords}
            lojistikRecords={lojistikRecords}
            salesRecords={salesRecords}
            offlineQueue={offlineQueue}
            onSyncSingleQueueItem={handleSyncSingleQueueItem}
            onOpenTraceability={(r) => setActivePdfRef(r)}
            onDispatch={handleDirectDispatch}
            onReceive={handleDirectReceive}
            onOpenIncident={handleDirectIncident}
            onDeleteReference={handleDeleteReference}
            onEditReference={handleEditReference}
            onAddAdminNote={handleQuickAddAdminNote}
            onBulkUpdateReferences={handleBulkUpdateReferences}
            onRerouteToFreezeDry={handleRerouteBatchToFreezeDry}
            onSelectModule={handleSelectModule}
            onOpenAnalytics={() => setActiveView('ANALYTICS')}
            title="Tüm Kayıtlar & İzlenebilirlik"
            subtitle="Sistemdeki tüm üretim, kalite, lojistik ve ambar partileri"
            isRecentLedger={false}
            onViewAll={() => {}}
            totalRefCount={references.length}
            completedRefCount={stats.completedCount}
            currentUserId={currentUser?.id}
          />
        )}

        {activeView === 'PENDING' && (
          <PendingOperationsView
            references={references}
            lojistikRecords={lojistikRecords}
            incidentRecords={incidentRecords}
            offlineQueue={offlineQueue}
            isSyncing={isSyncing}
            isOnline={isOnline}
            lastSyncTime={lastSyncTime}
            onSyncAllQueue={triggerOfflineQueueSync}
            onSyncSingleQueueItem={handleSyncSingleQueueItem}
            onRetryFailedItems={handleRetryFailedQueueItems}
            onDeleteQueueItem={handleDeleteQueueItem}
            onEditQueueItem={handleEditQueueItem}
            onDispatch={(refId) => {
              setSelectedRefIdForForm(refId);
              setActiveView('LOJISTIK');
            }}
            onReceive={(refId) => {
              setSelectedRefIdForForm(refId);
              setActiveView('AMBAR');
            }}
            onResolveIncident={(inc) => {
              setSelectedRefIdForForm(inc.refId);
              setActiveView('INCIDENT');
            }}
          />
        )}

        {activeView === 'ANALYTICS' && (
          <AnalyticsView
            stats={stats}
            fieldBreakdown={fieldBreakdown}
            references={references}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            lojistikRecords={lojistikRecords}
            ambarRecords={ambarRecords}
            freezeDryRecords={freezeDryRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            incidentRecords={incidentRecords}
            onSelectModule={handleSelectModule}
            onSelectReference={handleSearchRef}
            onRerouteToFreezeDry={handleRerouteBatchToFreezeDry}
            onOpenTraceability={(ref) => setActivePdfRef(ref)}
            onOpenFieldTest={(_refId) => {
              handleSelectModule('FIELD', 'EXISTING');
            }}
            currentUserId={currentUser?.id}
          />
        )}

        {activeView === 'SUMMARY' && (
          <SummaryView
            references={references}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
            ambarRecords={ambarRecords}
            lojistikRecords={lojistikRecords}
            freezeDryRecords={freezeDryRecords}
            salesRecords={salesRecords}
            incidentRecords={incidentRecords}
            onBack={() => setActiveView('DASHBOARD')}
          />
        )}

        {activeView === 'MONTHLY_REPORT' && (
          <MonthlyQualityReportView
            references={references}
            stats={stats}
            fieldBreakdown={fieldBreakdown}
            harvestRecords={harvestRecords}
            fieldRecords={fieldRecords}
            muzRecords={muzRecords}
            bademRecords={bademRecords}
            lojistikRecords={lojistikRecords}
            ambarRecords={ambarRecords}
            freezeDryRecords={freezeDryRecords}
            exportSampleRecords={exportSampleRecords}
            salesRecords={salesRecords}
            incidentRecords={incidentRecords}
            feedbacks={feedbacks}
            onBackToDashboard={() => setActiveView('DASHBOARD')}
            onClose={() => setActiveView('DASHBOARD')}
          />
        )}

        {activeView === 'GUIDE_PORTAL' && (
          <GuidePortal
            onBackToDashboard={() => setActiveView('DASHBOARD')}
          />
        )}

        {activeView === 'FEEDBACK' && (
          <FeedbackView
            feedbacks={feedbacks}
            onSaveFeedback={handleSaveFeedback}
            onUpdateFeedbackStatus={handleUpdateFeedbackStatus}
            onDeleteFeedback={handleDeleteFeedback}
          />
        )}

        {activeView === 'DIAGNOSTICS' && (
          <SystemDiagnosticsView 
            onBack={() => setActiveView('DASHBOARD')}
            dataState={{
              references,
              harvestRecords,
              fieldRecords,
              muzRecords,
              bademRecords,
              lojistikRecords,
              ambarRecords,
              exportSampleRecords,
              salesRecords,
              incidentRecords,
              freezeDryRecords,
              feedbacks,
              customFields
            }}
            currentUser={currentUser}
            onApplyRepairedState={(repairedState) => {
              setReferences(repairedState.references);
              setHarvestRecords(repairedState.harvestRecords);
              setFieldRecords(repairedState.fieldRecords);
              setMuzRecords(repairedState.muzRecords);
              setBademRecords(repairedState.bademRecords);
              setLojistikRecords(repairedState.lojistikRecords);
              setAmbarRecords(repairedState.ambarRecords);
              setExportSampleRecords(repairedState.exportSampleRecords);
              setSalesRecords(repairedState.salesRecords);
              setIncidentRecords(repairedState.incidentRecords);
              setFreezeDryRecords(repairedState.freezeDryRecords);
              if (repairedState.feedbacks) setFeedbacks(repairedState.feedbacks);
              if (repairedState.customFields) setCustomFields(repairedState.customFields);

              localStorage.setItem('miwe_references', JSON.stringify(repairedState.references));
              localStorage.setItem('miwe_harvest_records', JSON.stringify(repairedState.harvestRecords));
              localStorage.setItem('miwe_field_records', JSON.stringify(repairedState.fieldRecords));
              localStorage.setItem('miwe_muz_records', JSON.stringify(repairedState.muzRecords));
              localStorage.setItem('miwe_badem_records', JSON.stringify(repairedState.bademRecords));
              localStorage.setItem('miwe_lojistik_records', JSON.stringify(repairedState.lojistikRecords));
              localStorage.setItem('miwe_ambar_records', JSON.stringify(repairedState.ambarRecords));
              localStorage.setItem('miwe_export_sample_records', JSON.stringify(repairedState.exportSampleRecords));
              localStorage.setItem('miwe_sales_records', JSON.stringify(repairedState.salesRecords));
              localStorage.setItem('miwe_incident_records', JSON.stringify(repairedState.incidentRecords));
              localStorage.setItem('miwe_freeze_dry_records', JSON.stringify(repairedState.freezeDryRecords));
            }}
            onForceServerSync={syncCentralAppData}
            onNavigateToModule={(modKey) => {
              setSelectedRefIdForForm(undefined);
              setActiveView(modKey as any);
            }}
            isSyncing={isSyncing}
            lastSyncTime={lastSyncTime}
          />
        )}

        {activeView === 'AUDIT_TRAIL' && (
          <AuditTrailView
            onBack={() => setActiveView('DASHBOARD')}
            currentUser={currentUser}
            onNavigateToRecord={(refId) => handleSearchRef(refId)}
          />
        )}

        {/* TRACEABILITY LEDGER (SHA-256 HASH CHAIN) */}
        {activeView === 'TRACEABILITY_LEDGER' && (
          <div className="space-y-4">
            <TraceabilityLedgerView
              references={references}
              harvestRecords={harvestRecords}
              fieldRecords={fieldRecords}
              lojistikRecords={lojistikRecords}
              ambarRecords={ambarRecords}
              initialSelectedRefId={selectedLedgerRefId}
              onClose={() => setActiveView('DASHBOARD')}
            />
          </div>
        )}

          </div>
        )}

      </main>

      {showPresentationModal && (
        <PresentationReportWizard
          references={references}
          harvestRecords={harvestRecords}
          fieldRecords={fieldRecords}
          muzRecords={muzRecords}
          bademRecords={bademRecords}
          onClose={() => setShowPresentationModal(false)}
        />
      )}

      <footer className="w-full max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-[10px] text-slate-500 font-mono">
        &copy; {new Date().getFullYear()} MIWE HIL PWA Platformu. Tüm hakları saklıdır.
      </footer>

      {/* MODALS */}
      {isCustomFieldsModalOpen && (
        <CustomFieldsModal
          isOpen={isCustomFieldsModalOpen}
          onClose={() => setIsCustomFieldsModalOpen(false)}
          customFields={customFields}
          onSaveField={(field) => {
            setCustomFields(prev => [...prev.filter(f => f.id !== field.id), field]);
          }}
          onDeleteField={(id) => {
            setCustomFields(prev => prev.filter(f => f.id !== id));
          }}
        />
      )}

      {isShareModalOpen && (
        <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}

      {isGuideOpen && (
        <GuideModal
          isOpen={isGuideOpen}
          onClose={() => setIsGuideOpen(false)}
          isAdmin={currentUser?.role === 'ADMIN'}
          onClearDemoData={handleOpenResetModal}
        />
      )}



      {/* Google Apps Script & Sheets Setup Modal */}
      {isGasModalOpen && (
        <GasSetupModal
          onClose={() => setIsGasModalOpen(false)}
          gasUrl={gasUrl}
          gasToken={gasToken}
          onSaveGasUrl={(url) => {
            setGasUrl(url);
            safeLocalStorageSetItem('miwe_gas_url', url);
            showSuccess('Google Apps Script Web App URL başarıyla kaydedildi.');
          }}
          onSaveGasToken={(tok) => {
            setGasToken(tok);
            safeLocalStorageSetItem('miwe_gas_token', tok);
          }}
          onTestConnection={handleTestGasConnection}
          spreadsheetUrl={spreadsheetUrl}
          onSaveSpreadsheetUrl={handleSaveSpreadsheetUrl}
          onPullFromSheets={pullFromGoogleSheets}
        />
      )}

      {/* Sync Status & Offline Queue Modal */}
      <SyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        offlineQueue={offlineQueue}
        isOnline={isOnline}
        isSyncing={isSyncing}
        onSyncAll={triggerOfflineQueueSync}
        onSyncSingle={handleSyncSingleQueueItem}
        onDeleteItem={handleDeleteQueueItem}
        onEditItem={handleEditQueueItem}
        onPullFromSheets={pullFromGoogleSheets}
      />

      {/* Admin User Management & Activity Audit Modal */}
      {isAdminModalOpen && currentUser?.role === 'ADMIN' && (
        <AdminUserManagementModal
          isOpen={isAdminModalOpen}
          onClose={() => setIsAdminModalOpen(false)}
          currentUser={currentUser}
          onUsersUpdated={() => setUsersVersion(v => v + 1)}
        />
      )}

      {/* User Profile Info Edit Modal */}
      {isProfileModalOpen && currentUser && (
        <UserProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          currentUser={currentUser}
          onUserUpdated={(updatedUser) => {
            setCurrentUser(updatedUser);
            showSuccess('Profil bilgileriniz başarıyla güncellendi.');
          }}
        />
      )}

      {/* Manual Notification & Broadcast Dispatch Modal */}
      {isCreateNotificationModalOpen && (
        <CreateNotificationModal
          isOpen={isCreateNotificationModalOpen}
          onClose={() => setIsCreateNotificationModalOpen(false)}
          currentUser={currentUser}
          onSuccess={(msg) => showSuccess(msg, 'Bildirim Yayınlandı')}
        />
      )}

      {/* Visual Standards, Banana MAP & 4 Languages Proof Modal */}
      {isVisualStandardsModalOpen && (
        <VisualStandardsProofModal
          onClose={() => setIsVisualStandardsModalOpen(false)}
          onOpenLedger={() => {
            setIsVisualStandardsModalOpen(false);
            setActiveView('TRACEABILITY_LEDGER');
          }}
        />
      )}

      {/* 🔒 Miwe Spark Parola Korumalı Yönetici Portalı Doğrulama Modalı */}
      {isAdminPasswordModalOpen && (
        <AdminPasswordModal
          isOpen={isAdminPasswordModalOpen}
          onClose={() => setIsAdminPasswordModalOpen(false)}
          currentUser={currentUser}
          onSuccess={() => {
            setIsAdminPasswordModalOpen(false);
            setInitialPortalTab('ADMIN_SYSTEM');
            setActiveView('QUALITY_ROADMAP');
          }}
        />
      )}

      {/* 📷 Mobil Kamera Destekli AI Bilgisayarlı Görü Modalı (1 Saniye Kalibre & Renk Taraması) */}
      {isAiVisionModalOpen && (
        <AiVisionFruitInspectorModal
          isOpen={isAiVisionModalOpen}
          onClose={() => setIsAiVisionOpen(false)}
          initialFruit="APPLE"
          onApplyResults={(res) => {
            showSuccess(`AI Analizi: Çap ${res.calibreMm}mm, Renk %${res.colorPercent} (${res.qualityGrade})`, 'AI Analiz Tamamlandı');
          }}
        />
      )}

      {/* Standalone Traceability Modal with SHA-256 Link */}
      {activeTraceRef && (
        <TraceabilityModal
          reference={activeTraceRef}
          harvestRecords={harvestRecords}
          fieldRecords={fieldRecords}
          muzRecords={muzRecords}
          bademRecords={bademRecords}
          lojistikRecords={lojistikRecords}
          ambarRecords={ambarRecords}
          freezeDryRecords={freezeDryRecords}
          exportSampleRecords={exportSampleRecords}
          salesRecords={salesRecords}
          incidentRecords={incidentRecords}
          onClose={() => setActiveTraceRef(null)}
          onOpenLedger={(ref) => {
            setSelectedLedgerRefId(ref.refId);
            setActiveTraceRef(null);
            setActiveView('TRACEABILITY_LEDGER');
          }}
        />
      )}

      {/* Multi-Page PDF & Traceability Dashboard */}
      {(activePdfRef || activePdfIncident) && (
        <MultiPagePdfReportModal
          isOpen={true}
          onClose={() => {
            setActivePdfRef(null);
            setActivePdfIncident(null);
          }}
          reference={activePdfRef}
          incident={activePdfIncident}
          companyName="Miwe AGPJ Platformu"
          reportTitle="Resmi Kalite ve İzlenebilirlik Pasaportu"
          allReferences={references}
          harvestRecords={harvestRecords}
          fieldRecords={fieldRecords}
          muzRecords={muzRecords}
          bademRecords={bademRecords}
          lojistikRecords={lojistikRecords}
          ambarRecords={ambarRecords}
          freezeDryRecords={freezeDryRecords}
          exportSampleRecords={exportSampleRecords}
          salesRecords={salesRecords}
          incidentRecords={incidentRecords}
        />
      )}

      {/* Reset Confirmation Modal (Sandboxed iFrame Safe) */}
      {isResetConfirmModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-900">Tüm Verileri ve Stokları Sıfırla</h3>
                <p className="text-xs text-slate-500">
                  Bu işlem tüm test, hasat, ambar, satış, uygunsuzluk kayıtlarını ve stok verilerini kalıcı olarak temizler. Kullanıcı oturumunuz ve ayarlarınız korunur.
                </p>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-800 space-y-1">
              <p className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                Sıfırlanacak Alanlar:
              </p>
              <ul className="list-disc list-inside text-amber-700 text-[11px] space-y-0.5 ml-1">
                <li>Tüm Ambar Giriş & Soğuk Oda Stokları</li>
                <li>Tüm Referanslar ve Kalite Testleri (Field, Muz, Badem...)</li>
                <li>Satış Çıkışları, Sevkiyatlar ve Barlag Uygunsuzlukları</li>
                <li>Merkezi Sunucu ve Yerel Tarayıcı Önbelleği</li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setIsResetConfirmModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200"
              >
                İptal Et
              </button>
              <button
                type="button"
                onClick={handleConfirmResetAllStocksAndRecords}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-xl transition-colors shadow-sm flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Evet, Hepsini Sıfırla
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Non-intrusive Service Worker Update Prompt Banner (Task 6) */}
      {swUpdateAvailable && (
        <div className="fixed bottom-20 sm:bottom-6 right-4 left-4 sm:left-auto sm:max-w-md z-50 p-4 bg-slate-900/95 backdrop-blur-md border-2 border-emerald-500 rounded-2xl shadow-2xl text-white flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-5">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0">
              <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin" />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Yeni Sürüm Hazır</span>
                <span className="text-[10px] px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded font-mono">PWA</span>
              </h4>
              <p className="text-[11px] text-slate-300 truncate">
                Güncelleme hazır. Formunuzu tamamlayınca yenileyebilirsiniz.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setSwUpdateAvailable(null)}
              className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              Daha Sonra
            </button>
            <button
              type="button"
              onClick={() => {
                if (swUpdateAvailable) swUpdateAvailable();
                else window.location.reload();
              }}
              className="px-3 py-1.5 text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition shadow-md flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Yenile</span>
            </button>
          </div>
        </div>
      )}

      {/* Mobile Smart Screen Navigation Bar */}
      <MobileBottomBar
        activeView={activeView}
        onNavigateToDashboard={() => setActiveView('DASHBOARD')}
        onOpenQuickNew={() => handleSelectModule('HARVEST', 'NEW')}
        onOpenSyncModal={() => setIsSyncModalOpen(true)}
        onOpenGallery={() => setActiveView('GALLERY')}
        onOpenSearch={() => {
          const searchInputEl = document.querySelector('input[placeholder*="RefID Ara"]') as HTMLInputElement;
          if (searchInputEl) {
            searchInputEl.focus();
            searchInputEl.scrollIntoView({ behavior: 'smooth' });
          } else {
            setActiveView('REFERENCES');
          }
        }}
        offlineQueueCount={offlineQueue.length}
        isOnline={isOnline}
      />

      {/* Floating Scroll to Top Button (Mobile UX) */}
      <ScrollToTopButton />
      </div>
    </GlobalPlatformProvider>
  );
}

export default App;
