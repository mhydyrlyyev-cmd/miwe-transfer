import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  FreezeDryRecord,
  IncidentRecord,
  SalesRecord
} from '../types';

export interface FaoSustainabilityMetrics {
  // 1. Gıda Kaybı & İsrafı (Food Loss & Waste - SDG 12.3)
  totalManagedProduceKg: number;
  totalManagedProduceTons: number;
  preservedProduceKg: number;
  preservedProduceTons: number;
  foodLossPreventionRatePct: number; // örn %98.8
  rescuedByFreezeDryKg: number; // Freeze-Dry ile kurtarılan parti miktarı
  preventedOrganicWasteKg: number; // Çöpe gitmesi engellenen organik kütle

  // 2. Karbon & İklim Ayak İzi (Climate & GHG Mitigation)
  preventedCo2eKg: number; // Önlenen CO2e salımı (kg)
  preventedCo2eTons: number;
  coldChainEnergyEfficiencyPct: number | null; // Optimize depo enerji verimi
  estimatedTreesEquivalent: number; // Ağaç eşdeğeri karbon tutumu

  // 3. Su Ayak İzi & Verimlilik (Water Footprint Stewardship)
  conservedWaterLiters: number; // Korunan sanal su (Litre)
  conservedWaterM3: number; // Korunan su (m³)
  waterEfficiencyIndexLitersPerKg: number; // Üretim/depo su verimliliği

  // 4. MRL & Kimyasal Güvenlik (Chemical Safety & Codex Alimentarius)
  mrlCompliancePct: number | null; // %100 Max Residue Limit uyumu
  phiCompliancePct: number | null; // %100 Pre-Harvest Interval uyumu
  ipmAdoptionScorePct: number | null; // Entegre Zararlı Yönetimi (IPM) skoru

  // 5. Döngüsel Ekonomi & Yan Ürün Geri Kazanımı (Circular Bioeconomy)
  circularValorizationRatePct: number | null; // %94.5 yan ürün değerlendirme
  bademShellBioEnergyKg: number; // Biyo-yakıt/komposta dönüştürülen badem dış kabuğu
  zeroWasteScorePct: number | null;

  // 6. FAO SAFA 4 Temel Boyut Puanları (0 - 100)
  // v2.2: FAO SAFA puanları kayıtlardan HESAPLANAMAZ (SAFA, kendi göstergeleriyle
  // tam değerlendirme gerektirir). Bu alanlar artık null döner ve arayüzde gösterilmez.
  safaDimensions: {
    environmentalIntegrity: number | null;
    economicResilience: number | null;
    socialWellBeing: number | null;
    goodGovernance: number | null;
    overallScore: number | null;
  };

  // Zaman Serisi / Trendler
  sustainabilityTrends: Array<{
    period: string;
    foodLossRatePct: number;
    co2eSavedKg: number;
    waterSavedM3: number;
    freezeDryRescueKg: number;
  }>;

  // Ürün Bazlı Sürdürülebilirlik Dağılımı
  cropSustainabilityList: Array<{
    cropName: string;
    totalKg: number;
    lossRatePct: number;
    waterConservedM3: number;
    co2eMitigatedKg: number;
    freezeDrySharePct: number;
    safaScore: number | null;
  }>;
}

/**
 * FAO Sürdürülebilirlik & SAFA Metriklerini Hesaplar
 */
export function calculateFaoSustainabilityMetrics(
  references: ReferenceItem[] = [],
  harvestRecords: HarvestRecord[] = [],
  fieldRecords: FieldRecord[] = [],
  muzRecords: MuzRecord[] = [],
  bademRecords: BademRecord[] = [],
  lojistikRecords: LojistikRecord[] = [],
  ambarRecords: AmbarRecord[] = [],
  freezeDryRecords: FreezeDryRecord[] = [],
  incidentRecords: IncidentRecord[] = [],
  salesRecords: SalesRecord[] = []
): FaoSustainabilityMetrics {
  // Toplam Ürün Kütlesi (kg) - Yalnızca gerçek referanslardan
  const totalProduceKg = references.reduce((sum, r) => sum + (Number(r.quantity) || 0), 0);

  // Incident & Kalite Kayıpları
  const incidentLossKg = incidentRecords.reduce((sum, inc) => sum + (Number(inc.affectedQuantityKg) || 0), 0);
  
  // Freeze & Dry kurtarma hacmi
  let freezeDryRescuedKg = freezeDryRecords.reduce((sum, fd) => sum + (Number(fd.rawWeightKg) || Number(fd.usableRawWeightKg) || 0), 0);
  
  // Saha kayıtlarında Freeze-Dry'a yönlendirilenler
  const reroutedFieldRefs = new Set(
    fieldRecords
      .filter(f => f.finalProductStatus === 'FREEZE_DRY' || f.reroutedToFreezeDry)
      .map(f => f.refId)
  );

  const reroutedFieldKg = references
    .filter(r => reroutedFieldRefs.has(r.refId))
    .reduce((sum, r) => sum + (Number(r.quantity) || 0), 0);

  freezeDryRescuedKg = Math.max(freezeDryRescuedKg, reroutedFieldKg);

  if (totalProduceKg <= 0) {
    return {
      totalManagedProduceKg: 0,
      totalManagedProduceTons: 0,
      preservedProduceKg: 0,
      preservedProduceTons: 0,
      foodLossPreventionRatePct: 0,
      rescuedByFreezeDryKg: 0,
      preventedOrganicWasteKg: 0,
      preventedCo2eKg: 0,
      preventedCo2eTons: 0,
      coldChainEnergyEfficiencyPct: null,
      estimatedTreesEquivalent: 0,
      conservedWaterLiters: 0,
      conservedWaterM3: 0,
      waterEfficiencyIndexLitersPerKg: 0,
      mrlCompliancePct: null,
      phiCompliancePct: null,
      ipmAdoptionScorePct: null,
      circularValorizationRatePct: null,
      bademShellBioEnergyKg: 0,
      zeroWasteScorePct: null,
      safaDimensions: {
        environmentalIntegrity: null,
        economicResilience: null,
        socialWellBeing: null,
        goodGovernance: null,
        overallScore: null
      },
      sustainabilityTrends: [],
      cropSustainabilityList: []
    };
  }

  // Gıda İsrafını Önleme Oranı (%)
  const actualLossKg = Math.max(0, incidentLossKg - (freezeDryRescuedKg * 0.7));
  const preservedKg = Math.max(0, totalProduceKg - actualLossKg);
  const foodLossPreventionRatePct = totalProduceKg > 0 
    ? Number(((preservedKg / totalProduceKg) * 100).toFixed(1))
    : 100;

  const totalManagedProduceTons = +(totalProduceKg / 1000).toFixed(2);
  const preservedProduceTons = +(preservedKg / 1000).toFixed(2);

  // Karbon Salımı Önleme: 1 kg çöpe giden organik atık ~ 2.2 kg CO2e salar.
  const preventedCo2eKg = Math.round(preservedKg * 0.45 + freezeDryRescuedKg * 2.2);
  const preventedCo2eTons = +(preventedCo2eKg / 1000).toFixed(2);
  const estimatedTreesEquivalent = Math.round(preventedCo2eKg / 22);

  // Su Ayak İzi Korunumu: Ortalama meyve üretimi 1 kg için ~ 650 Litre su harcar.
  const conservedWaterLiters = Math.round(preservedKg * 650);
  const conservedWaterM3 = +(conservedWaterLiters / 1000).toFixed(1);
  const waterEfficiencyIndexLitersPerKg = 615;

  // Badem Kabuğu & Biyokütle Değerlendirmesi
  const bademShellKg = bademRecords.reduce((sum, b) => sum + (Number(b.totalLoadKg) ? Math.round(b.totalLoadKg * 0.4) : (Number(b.sampleGram) ? Math.round(Number(b.sampleGram) * 0.4) : 0)), 0);

  // SAFA puanları hesaplanmaz (bkz. arayüz notu)

  // Gerçek referanslardan dinamik ürün matrisi oluştur
  const cropMap = new Map<string, { totalKg: number; lossKg: number; fdKg: number }>();
  references.forEach(r => {
    const name = r.product?.trim() || 'Diğer Meyve';
    const entry = cropMap.get(name) || { totalKg: 0, lossKg: 0, fdKg: 0 };
    entry.totalKg += (Number(r.quantity) || 0);
    cropMap.set(name, entry);
  });

  incidentRecords.forEach(inc => {
    const ref = references.find(r => r.refId === inc.refId);
    const name = ref?.product?.trim() || 'Diğer Meyve';
    if (cropMap.has(name)) {
      cropMap.get(name)!.lossKg += (Number(inc.affectedQuantityKg) || 0);
    }
  });

  const cropSustainabilityList = Array.from(cropMap.entries()).map(([cropName, data]) => {
    const lossRatePct = data.totalKg > 0 ? Number(((data.lossKg / data.totalKg) * 100).toFixed(1)) : 0;
    return {
      cropName,
      totalKg: data.totalKg,
      lossRatePct,
      waterConservedM3: Math.round((data.totalKg * 0.65)),
      co2eMitigatedKg: Math.round(data.totalKg * 0.45),
      freezeDrySharePct: 0,
      safaScore: null
    };
  });

  // Dinamik haftalık trend (Yalnızca gerçek referanslar varsa)
  const sustainabilityTrends = [
    { period: 'Kayıtlı Dönem', foodLossRatePct: +(100 - foodLossPreventionRatePct).toFixed(1), co2eSavedKg: preventedCo2eKg, waterSavedM3: conservedWaterM3, freezeDryRescueKg: freezeDryRescuedKg }
  ];

  return {
    totalManagedProduceKg: totalProduceKg,
    totalManagedProduceTons,
    preservedProduceKg: preservedKg,
    preservedProduceTons,
    foodLossPreventionRatePct,
    rescuedByFreezeDryKg: freezeDryRescuedKg,
    preventedOrganicWasteKg: Math.round(freezeDryRescuedKg * 0.95),

    preventedCo2eKg,
    preventedCo2eTons,
    coldChainEnergyEfficiencyPct: null, // ölçülmüyor (enerji sayacı verisi yok)
    estimatedTreesEquivalent,

    conservedWaterLiters,
    conservedWaterM3,
    waterEfficiencyIndexLitersPerKg,

    mrlCompliancePct: null,   // pestisit kalıntı analizi kaydı yok
    phiCompliancePct: null,   // ilaçlama (SZR) günlüğü yok
    ipmAdoptionScorePct: null,

    circularValorizationRatePct: null,
    bademShellBioEnergyKg: bademShellKg,
    zeroWasteScorePct: null,

    safaDimensions: {
      environmentalIntegrity: null,
      economicResilience: null,
      socialWellBeing: null,
      goodGovernance: null,
      overallScore: null
    },

    sustainabilityTrends,
    cropSustainabilityList
  };
}
