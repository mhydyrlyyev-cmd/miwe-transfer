export type ModuleKey = 'HARVEST' | 'FIELD' | 'MUZ' | 'BADEM' | 'LOJISTIK' | 'AMBAR' | 'FREEZE_DRY' | 'EXPORT_SAMPLE' | 'SALES' | 'INCIDENT' | 'FEEDBACK';

export type ReferenceStatus = 'CREATED' | 'SHIPPED' | 'IN_TRANSIT' | 'RECEIVED' | 'PARTIAL' | 'REJECTED' | 'IN_FREEZE_DRY' | 'FREEZE_DRY_COMPLETED' | 'EXPORT_TESTED' | 'SOLD' | 'INCIDENT' | 'CLOSED' | 'COMPLETED';

export type IncidentPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type IncidentStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';

export interface SplitLotItem {
  id?: string;
  subLotId: string;
  subLotCode?: string;
  variety?: string; // Sort / Görnüşi
  kaliteSinifi?: string;
  qualityGrade?: StandardQualityClassKey; // Kalite Sınıfı / Görnüşi
  quantityKg: number;
  caseCount?: number;
  palletCount?: number;
  packageType?: string;
  packageCount?: number;
  destination: string;
  targetMarket?: string;
  temperatureRequirement?: number;
  notes?: string;
  timestamp?: string;
}

export type StandardQualityClassKey =
  | 'EXTRA (V-20)'
  | 'I (V-22) EXC'
  | 'II (V-24) PRM'
  | 'III (V26-28) CLS'
  | 'Mix'
  | 'Standart Däl / Standart Dışı'
  | string;

export interface QualityClassDefinition {
  key: string;
  nameTr: string;
  nameTm: string;
  nameEn: string;
  description: string;
  badgeClass: string;
  isProcessingOrNonStandard?: boolean;
}

export const STANDARD_QUALITY_CLASSES: QualityClassDefinition[] = [
  {
    key: 'EXTRA (V-20)',
    nameTr: 'Ekstra Kalite',
    nameTm: 'Ekstra Hil',
    nameEn: 'Extra Quality (V-20)',
    description: 'En yüksek seçkin ihracat kalitesi, kusursuz görünüm ve kalibre.',
    badgeClass: 'bg-emerald-100 text-emerald-900 border-emerald-300'
  },
  {
    key: 'I (V-22) EXC',
    nameTr: '1. Sınıf Mükemmel / Excellent',
    nameTm: '1-nji Dereje (Ajaýyp)',
    nameEn: 'Class I Excellent (V-22)',
    description: '1. Sınıf mükemmel ticari kalite, üstün tat ve renklenme.',
    badgeClass: 'bg-teal-100 text-teal-900 border-teal-300'
  },
  {
    key: 'II (V-24) PRM',
    nameTr: '2. Sınıf Premium',
    nameTm: '2-nji Dereje (Premium)',
    nameEn: 'Class II Premium (V-24)',
    description: '2. Sınıf premium pazar kalitesi, hafif toleranslı kusur payı.',
    badgeClass: 'bg-blue-100 text-blue-900 border-blue-300'
  },
  {
    key: 'III (V26-28) CLS',
    nameTr: '3. Sınıf Klasik / Standart',
    nameTm: '3-nji Dereje (Standart)',
    nameEn: 'Class III Classic (V26-28)',
    description: '3. Sınıf klasik standart pazar kalitesi.',
    badgeClass: 'bg-amber-100 text-amber-900 border-amber-300'
  },
  {
    key: 'Mix',
    nameTr: 'Karışık / Sanayi & İşleme Sınıfı',
    nameTm: 'Gatyşyk / Senagat',
    nameEn: 'Mix / Industrial Processing',
    description: 'Farklı kalibre karışımı, doğrudan satış veya taze sanayi kullanımına uygun.',
    badgeClass: 'bg-orange-100 text-orange-900 border-orange-300'
  },
  {
    key: 'Standart Däl / Standart Dışı',
    nameTr: 'Standart Değil (Iskarta / Freeze-Dry)',
    nameTm: 'Standart Däl / Gaýtadan Işleme',
    nameEn: 'Non-Standard / Processing & Freeze-Dry',
    description: 'Standart dışı / defektli / şekil bozukluğu olan ürünler. Liyofilizasyon & Freeze-Dry işleme için ideal.',
    badgeClass: 'bg-rose-100 text-rose-900 border-rose-300',
    isProcessingOrNonStandard: true
  }
];

export interface DelilnamaGradeRow {
  gradeKey: StandardQualityClassKey;
  gradeLabelTr?: string;
  yassikliKg?: number; // Ýaşşikli ýygylan (kg)
  hasylNetKg: number;  // Hasyl net (kg)
  satysaBerlenKg?: number; // Satyşa berlen möçberi (kg)
  gapSany?: number;   // Gap sany (san)
}

export interface DelilnamaPassport {
  delilnamaNo: string; // e.g. "0002952"
  sene: string; // Sene (Tarih) e.g. "2026-05-12"
  yeri: string; // Ýeri (e.g. Ýyladyzhana, Bag 4, Parsel 8)
  miwe: string; // Miwe (e.g. Kiraz, Muz, Şetdaly, Badem)
  miweGornusi: string; // Miwe görnüşi (e.g. Lapins, Extreme, Cavendish)
  agacSany?: number; // Agaç sany (e.g. 105)
  gabynGornusi?: string; // Gabyň görnüşi (e.g. Ýaşşik, Karobka)
  grades: DelilnamaGradeRow[];
  jemiNetKg: number; // JEMI Net Hasat Kg
  jemiSatysaKg?: number; // JEMI Satyşa berlen kg
  jemiGapSany?: number; // JEMI Gap sany
  onduriji?: string; // Öndüriji (e.g. Orazow R.)
  hilciHunarmen?: string; // Hilçi hünärmen (e.g. Saparow M.)
  satuwHunarmen?: string; // Satuw hünärmen (e.g. Mämmetgulyýew M.)
  signatureDate?: string;
}

// ----------------------------------------------------
// RESMI BADAM ÇYKYŞ WE GIRIŞ DEPDERÇESI ("MIWE" AGPJ)
// ----------------------------------------------------
export interface BademDepderceItem {
  id: string;
  cykysYeri: string; // Çykyş ýeri (MZ / Sowuk depo / Söwda / Badam zawod)
  girisYeri: string; // Giriş ýeri (MZ / Sowuk depo / Söwda / Sortlamak Gaplama)
  badamSorty: string; // Badamyň sorty (Laurenne, Nonpareil, Ferragnes, Guara vb.)
  meydany: string; // Meýdany / Kalibr (21/22 Premium, 25-27 Premium, 33-35 Classic, 38-40 Mix, Döwük Mix, Pak we heňli)
  arassalananGornusi?: string; // Elde/Tenias H.enjam/Garyşyk maňyz / Şänik/Maňyz
  sortlamaGaplama?: 'I sort' | 'II sort' | 'III sort' | 'Pak we heňli' | string;
  agramyKg: number; // Agramy (kg)
  haltaSany: string; // Halta / Gap sany (Big Bag 1 sany, Halta 1 sany vb.)
  tableType: 'PREMIUM_MANYZ' | 'SORTLAMA_GAPLAMA';
}

export interface BademDelilnamaPassport {
  depderceNo: string; // e.g. "№ 0000417"
  sene: string; // Sene (Tarih)
  ulagBelgisi: string; // Ulagyň belgisi (Araç Plakası)
  bellik: string; // Bellik (Açıklama / Özel Notlar)
  cykysEden: string; // Çykyş eden (ady/familiýasy) e.g. "Badam zawod"
  girisEden: string; // Giriş eden (ady/familiýasy) e.g. "Sowuk depo"
  tassyklan: string; // Tassyklan (ady/familiýasy) e.g. "Hil hünärmen"
  premiumItems: BademDepderceItem[]; // Tablisa 1: Arassalanan Görnüşi & Esasy Maňyz
  sortlamaItems: BademDepderceItem[]; // Tablisa 2: Sortlama & Gaplama
  jemiAgramKg: number; // Jemi agram (kg)
  jemiHaltaSany?: number; // Jemi gap / halta / big bag sany
}

export interface HarvestRecord {
  id: string;
  refId: string;
  timestamp: string;
  recordDate: string;
  operator: string;
  product: string;
  variety: string;
  orchard?: string; // Bahçe / Orchard (Zorunlu / Ana Parametre)
  parcel?: string;
  greenhouse?: string;
  location?: string;
  sector?: string;
  harvestStage: string; // Hasat No / Test Aşama (örn. 1. Hasat, Ana Hasat)
  phenologicalStage?: string; // Fenolojik Aşama No
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı (Extra, I-Exc, II-Prm, III-Cls, Mix, Standart Dışı vb.)
  lotNo: string;
  receiptNo?: string; // Fiş / Kantar No
  dailyTotalKg: number; // Günlük Toplam Kg
  cumulativeTotalKg?: number; // Kümülatif Toplam Kg
  workerCount?: number; // İşçi Sayısı
  foreman?: string; // Foreman / Sorumlu
  nextStep: string; // Sonraki Adım
  destination: string; // Hedef / Nokta
  splitLots?: SplitLotItem[]; // Parçalı Yük (Split Logistics - Sub-lots)
  delilnama?: DelilnamaPassport; // Resmi Delilnama / Kalite Pasaportu
  status: 'ACTIVE' | 'COMPLETED';
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface FieldSample {
  sample: number;
  hardness: number; // kg/cm2 (Penetrometer)
  brix: number;     // % Sugar
  diameterMm: number;
  weightG?: number; // Tekil Meyve Ağırlığı (Gram / g)
  starch?: number;  // Nişasta-İyot Skalası (1 - 10)
  defects: string;
}

export type SpecialCropType =
  | 'NONE'
  | 'APPLE_PEAR'       // Elma / Armut (Nişasta-İyot & Streif SI)
  | 'AVOCADO'          // Avokado (Kuru Madde % & Durofel Yumuşama)
  | 'TOMATO'           // Domates (Likopen / Renk Skalası 1-6 & Titre Edilebilir Asitlik TA)
  | 'GRAPE'            // Üzüm (Brix/Asit Oranı & Tane Tutunma Kuvveti)
  | 'POTATO'           // Patates (Özgül Ağırlık / Kuru Madde & İndirgen Şeker)
  | 'ONION'            // Soğan (Boyun Kuruluğu % & Kuru Madde %)
  | 'MELON_WATERMELON' // Kavun & Karpuz (Sap Çatlağı / Ground Spot & Kabuk Kalınlığı)
  | 'PINEAPPLE'        // Ananas (İç Şeffaflık 1-4 & Kabuk Göz Rengi 0-5)
  | 'MANGO'            // Mango (Kuru Madde % & Yanak Sertliği)
  | 'PISTACHIO'        // Antep Fıstığı (Çıtlaklık % & Boş Tane % & Nem %)
  | 'POMEGRANATE'      // Nar (Aril Renk Yoğunluğu & Tohum Sertliği & Randıman %)
  | 'CORN'             // Mısır (Hasat/Depoluk Nem % & Süt Olumu)
  | 'PERSIMMON'        // Hurma / Trabzon Hurması (Tanen Burukluğu 1-5 & Nem %)
  | 'PEACH_NECTARINE'  // Şeftali / Nektarin (Sertlik 8mm & Çekirdek Çatlağı %)
  | 'PLUM'             // Erik (Mumsu Pus Örtüsü % & Sertlik)
  | 'CARROT';          // Havuç (Brix Şeker %, Kök Çapı/Kalibre & Kırılganlık/Odunlaşma %)

export interface SpecialCropTestResult {
  cropType: SpecialCropType;
  cropNameTr: string;
  metric1Name: string;
  metric1Value: number | string;
  metric1Unit?: string;
  metric2Name?: string;
  metric2Value?: number | string;
  metric2Unit?: string;
  statusBadge: string;
  interpretation: string;
}

export interface FieldRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  product: string;
  sortVariety: string; // e.g. Extreme 314, Royal Glory, Pink Lady
  orchard?: string;    // Bahçe / Orchard
  location: string;    // e.g. Blok A-12, Parsel 4
  testType: string;    // Hasattan Önce, Hasat, Sevkiyattan Önce, 1. Hasat, 2. Test vb.
  sampleCount: number; // 3, 5, 7, ...
  samples: FieldSample[];
  avgHardness: number;
  avgBrix: number;
  avgDiameter: number;

  // Meyve Ağırlık / Gramaj Ölçümleri (Test Ağırlığı & Meyve Gram)
  testSampleWeightKg?: number; // Toplam test numune ağırlığı (kg)
  testSampleWeightG?: number;  // Toplam test numune ağırlığı (gram)
  avgFruitWeightG?: number;    // Ortalama tek meyve ağırlığı (gram/adet)
  fruitCountSampled?: number;  // Tartılan/sayılan toplam meyve adedi

  hasStarchTest?: boolean; // Nişasta & Streif İndeksi (SI) Testi Dahil mi?
  starchIndex?: number;    // Ortalama Nişasta İndeksi (1 - 10)
  streifIndex?: number;    // Streif İndeksi = Sertlik / (Brix * Nişasta)
  streifInterpretation?: string; // Streif İndeksi Yorumu (Optimum Hasat, Depoluk vb.)
  specialCropTest?: SpecialCropTestResult; // Özel Ürün Testleri (Avokado, Domates, Üzüm, vb.)
  qualityStandardOrg?: 'OECD' | 'USDA' | 'UNECE' | 'TESCO' | 'KIPA' | 'GENERAL' | string; // Uygulanan Standart
  qualityStandardVerdict?: 'PASS' | 'FAIL' | 'CONDITIONAL'; // Standart Değerlendirme Sonucu (Geçti/Kaldı/Koşullu)

  // Seçmeli / Opsiyonel Saha Parametreleri
  hasNitrateTest?: boolean;    // Nitrat testi yapıldı mı?
  nitrateMgKg?: number;
  nitrateLimitMgKg?: number;
  nitratePass?: boolean;

  colorationPercent?: number;

  hasHueAngleTest?: boolean;   // Kiraz / Meyve Renk (Hue Angle) Testi (MDPI 2026)
  hueAngle?: number;           // Hue Açısı (°): ≤ 10° tam olgunluk, > 10° warning
  hueAngleVerdict?: 'OPTIMAL' | 'WARNING';
  fertilizationNotes?: string; // Gübreleme & Çatlama Direnci Notları (Horticulturae 2025)

  hasDefectTest?: boolean;     // Kusur analizi yapıldı mı?
  defectPercent?: number;

  hasQualityGrade?: boolean;   // Kalite sınıfı atandı mı?
  qualityGrade?:
    | 'EXTRA (V-20)'
    | 'I (V-22) EXC'
    | 'II (V-24) PRM'
    | 'III (V26-28) CLS'
    | 'Mix'
    | 'Standart Däl / Standart Dışı'
    | 'Ekstra'
    | 'Sınıf 1'
    | 'Sınıf 2'
    | 'Sanayi / Iskarta'
    | string;
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı (Extra, I-Exc, II-Prm, III-Cls, Mix, Standart Dışı)
  harvestDate: string;
  decision: string;    // Hasada Uygun, Tekrar Test Edilecek, 2. Hasat / Seçme, Soğuk Depoya Sevk, vb.
  finalProductStatus?: 'FRESH_SALE' | 'COLD_STORAGE' | 'FREEZE_DRY'; // Ürün Nihai Durumu / Product Final Status
  rejectionReason?: string; // Uygunsuzluk / Kalite Notu (Reason for Rejection)
  reroutedToFreezeDry?: boolean; // Freeze & Dry'a Yönlendirildi mi?
  splitLots?: SplitLotItem[]; // Kalite Sınıflarına & Sortlara Göre Ayrıştırma (Split Lots)
  testStatus: 'ACTIVE' | 'COMPLETED';
  nextStep: string;
  notes: string;
  preHarvestChecklist?: {
    id: string;
    title: string;
    description: string;
    criteria: string;
    checked: boolean;
    autoStatus?: 'PASSED' | 'PENDING' | 'WARNING';
    category?: string;
  }[];
  preHarvestScore?: number;
  photos?: string[];
  photoIds?: string[];
  ambientTempC?: number;
  ambientHumidityPct?: number;
  updatedAt?: string;
}

export interface PreHarvestChecklistItem {
  id: string;
  title: string;
  description: string;
  criteria: string;
  checked: boolean;
  autoStatus?: 'PASSED' | 'PENDING' | 'WARNING';
  category?: string;
}

export interface BananaFruit3PointBrix {
  topPoint: number;    // Sap / Çiçek / Üst Kısım (°Bx)
  middlePoint: number; // Orta Gövde (°Bx)
  bottomPoint: number; // Uç / Alt Kısım (°Bx)
  avg3Point: number;   // 3 Nokta Meyve Ortalaması (°Bx)
}

export interface BananaRipeningStageProgram {
  stageNumber: number; // 1 to 7
  stageNameTr: string; // e.g. 1. Aşama (Ön Isıtma), 2. Aşama (Etilen Gazlama), vb.
  durationHours: number; // Süre (Saat)
  setTempC: number; // Hedef Sıcaklık (°C)
  setEthylenePpm: number; // Hedef Etilen (ppm)
  setCo2Ppm: number; // Hedef CO2 Sınırı (ppm)
  setHumidityPercent: number; // Hedef Nem (%)
}

export interface BananaScadaChamberData {
  chamberId: string; // e.g. "NR1 Ripening Room", "NR2 Ripening Room", ... "NR12 Ripening Room"
  chamberType: 'RIPENING' | 'BANANA_COLD_STORE' | 'ANTE_ROOM' | 'BLAST_FREEZER' | 'COLD_STORE';
  ambientTemp1C: number; // Oda Sıcaklığı 1 (°C)
  ambientTemp2C: number; // Oda Sıcaklığı 2 (°C)
  pulpTemp1C: number; // Meyve İçi / Eti Sıcaklığı 1 (°C - 果肉温度1)
  pulpTemp2C: number; // Meyve İçi / Eti Sıcaklığı 2 (°C - 果肉温度2)
  ethylenePpm: number; // Anlık Etilen Konsantrasyonu (ppm - 乙烯浓度)
  co2Ppm: number; // Anlık CO2 Konsantrasyonu (ppm - CO2浓度)
  humidityPercent: number; // Bağıl Nem (% - 湿度)
  activeStageIndex: number; // 1 - 7
  totalRunTimeHours: number; // Toplam Program Süresi (Hr)
  elapsedTimeHours: number; // Geçen Süre (Hr)
  evaporatorFan1State: boolean; // Evap Fan 1 (Açık/Kapalı)
  evaporatorFan2State: boolean; // Evap Fan 2 (Açık/Kapalı)
  evapFinTempC: number; // Evaporatör Kanatçık Sıcaklığı (°C)
  defrostRemainingMin: number; // Kalan Defrost Süresi (Dk)
  coolingStatusText?: string; // e.g. "Soğutma Aktif", "Standby", "Gazlama Devam Ediyor"
  stagesMatrix?: BananaRipeningStageProgram[];
}

export interface MuzRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  product: string;
  greenhouseNo: string; // e.g. Sera 12, Sera 4 (Sektör C)
  ribbonColor: string;  // e.g. Kırmızı (Hafta 35), Mavi, Sarı, Yeşil, vb.
  bloomWeek?: number;   // Çiçeklenme / Doğum Haftası
  harvestAgeWeeks?: number; // Hasat Yaşı (11-13 Hafta)
  fingerLengthCm: number; // Parmak Uzunluğu (cm)
  calibrationMm: number; // Kalibrasyon / Çap (mm)
  fingerCountPerHand: number; // Tarak/El Başına Parmak Sayısı
  handPosition?: '1. El (Üst)' | '2. El' | 'Orta El' | 'Alt El';
  clusterWeightKg?: number; // Tarak Ağırlığı (kg)
  ripenessScale: number; // 1 to 7 (1=Green, 7=Yellow with brown spots)
  pulpFirmness: number;  // kg/cm2 (Penetrometre)
  pulpTemperatureC?: number; // Meyve İçi Sıcaklığı (°C, Hedef 13.5°C - 14.5°C)
  brix?: number; // Şeker Oranı (°Bx)
  brixSamples?: number[]; // 5 Numune Brix Değerleri (°Bx)
  banana3PointBrix?: BananaFruit3PointBrix; // Muz Meyvesi 3 Nokta Ölçüm (Sap, Orta, Uç)
  avgBrix?: number; // Ortalama Brix (°Bx)
  ppmTestType?: string; // Etilen Gazlama (ppm), Oda CO2 (ppm), Ozon (ppm), Yıkama Havuzu Klor (ppm)
  ppmSamples?: number[]; // 5 Nokta / Numune PPM Değerleri
  avgPpm?: number; // Ortalama PPM
  angularity?: 'Dolu Yuvarlak' | '3/4 Dolu' | 'Köşeli';
  flowerEndDefect: boolean; // Çiçek Ucu / Taç Çürüklüğü
  latexStain: boolean; // Lateks / Süt Lekesi
  mechanicalDamage?: boolean; // Mekanik Çizik / Darbe
  sunburnOrYellow?: boolean; // Güneş Yanığı / Sarı Parmak
  pestDamage?: boolean; // Trips / Kırmızı Örümcek Lekesi
  packaging: string;    // Karton Kutu 18.5kg, Plastik Kasa 20kg
  polybagType?: 'Vakumlu Banavac' | 'Delikli Polietilen' | 'Açık Dökme';
  mapPackaging: boolean; // Modifiye Atmosfer Paketleme (MAP)
  ethyleneAbsorber: boolean; // KMnO4 Etilen Absorber Şase Eklendi
  netWeightKg: number;
  grossWeightKg?: number;
  roomNo: string;
  coolingStatus: 'Uygun' | 'Yetersiz' | 'İşlemde';
  gasStatus: 'Bekliyor' | 'Gazlandı' | 'Gerek Yok' | 'Gazlanmayacak';
  qualityStatus: 'Ekstra / A Kalite' | 'Sınıf 1 / B Kalite' | 'Sınıf 2 / C Kalite' | 'Sanayi / Fire';
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  ripeningScada?: BananaScadaChamberData; // SCADA / HMI Sarartma Odası & Soğuk Zincir İzleme Parametreleri
  decision?: string; // Uygun (Sevkiyata Hazır), Karantina / Gazlama, vb.
  splitLots?: SplitLotItem[];
  testStatus: 'ACTIVE' | 'COMPLETED';
  nextStep: string;
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface BademRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  product: string;
  variety: string;      // Nonpareil, Ferragnes, Ferraduel, Guara, Laurenne, Texas
  location: string;     // Parsel 8, Bahçe 2
  
  // Adım 1: Hasat Öncesi / Hasat Uygunluk Testi
  waterCutOffDate?: string; // Ağacın su kesilme tarihi
  hullSplitPercent?: number; // Ağacın meyve açma / çatlama oranı % (Hedef > %70)
  fruitMoisturePercent?: number; // Meyve nem oranı % (%9-15 ise Hasata Uygun)
  sampleFruitCount?: number; // Kaç meyve (adet)
  sampleFruitWeightGram?: number; // Kaç gram numune
  harvestReadinessStatus?: 'Hasata Uygun' | 'Erken / Beklemeli' | 'Geç';

  // Adım 2: Yerde Kurutma Aşaması
  dryingStage?: string; // Yerde Kurutma 1. Gün, 3. Gün vb.
  kernelMoisturePercent?: number; // Meyve içi kernel nemi % (Hedef %4.5 - %6.0)
  dryingNextStep?: 'Depolama (Kuru Depo Stok Kaydı)' | 'Badem İşleme / Kırma Alanı' | string;

  // Adım 3: Laboratuvar Randıman & Kalite Analizi
  calibre: string;      // 18-20, 20-22, 23-25, 27-30, 30-32, 34-40
  kernelCountPerOz?: number; // Adet/Oz
  shellType?: 'Sert Kabuk' | 'Yarı Sert Kabuk' | 'Yumuşak / Kağıt Kabuk';
  totalLoadKg: number;
  sampleGram: number;   // Laboratuvar Brüt Numune (g, örn. 1000g)
  kernelGram: number;   // Çıkan Net İç Ağırlığı (g, örn. 342g)
  kernelYieldPercent: number; // Randıman % = (kernelGram / sampleGram) * 100
  moisturePercent: number;    // Nem % (Hedef < 6.0%, Kritik Eşik > 6.5%)
  waterActivityAw?: number;   // Su Aktivitesi (aw)
  aflatoxinTest?: 'Negatif (<2 ppb)' | 'İnceleniyor' | 'Pozitif (>4 ppb)';
  phenologicalStage: string;
  testStage: string;    // Hasat Testi, Yerde Kurutma, Laboratuvar Randıman & Kalite
  defWholeGram: number;      // Bütün Sağlam İç (g)
  defDoubleGram: number;     // Çift / İkiz İç (g)
  defMechanicalGram: number; // Mekanik / Kırık (g)
  defForeignGram: number;    // Yabancı Madde / Taş / Kabuk (g)
  defDustGram: number;       // Toz / Kırıntı (g)
  defBrokenGram: number;     // Bölünen / Parçalı (g)
  defSeriousGram: number;    // Ciddi Defekt (Kurt, Küf, Çürük, Acılaşma) (g)
  defUndersizeGram: number;  // Küçük Boy / Cılız / Büzüşük (g)
  defGumGram?: number;       // Gam / Reçine (g)
  defInsectGram?: number;    // Böcek / Kurt Hasarı (g)
  defStainedGram?: number;   // Lekeli / Kararmış İç (g)
  seriousDefectPercent: number;
  totalDefectPercent: number;
  classification: 'Ekstra' | 'Sınıf 1' | 'Sınıf 2' | 'Sanayi / Yağlık';
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  storageRecommendation?: string;
  splitLots?: SplitLotItem[];
  testStatus: 'ACTIVE' | 'COMPLETED';
  nextStep: string;
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface LojistikRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  shipmentDate: string;
  source: string;
  destination: string;
  vehiclePlate: string;
  driver: string;
  driverPhone?: string;
  delilnamaNo: string;
  transportType: string; // Frigorifik Tır, Termo Kamyon, Panelvan
  palletCount: number;
  caseCount: number;
  weightKg: number;
  departureTemperature: number; // °C
  transitTemperature: number;   // °C
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  fruitCategory?: 'MUZ' | 'DIGER' | 'BADEM';
  product?: string;
  variety?: string;
  delilnama?: DelilnamaPassport;
  bademDelilnama?: BademDelilnamaPassport;
  splitLots?: SplitLotItem[];
  status: 'SHIPPED' | 'IN_TRANSIT' | 'DELIVERED';
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface AmbarRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  acceptanceDate: string;
  warehouse: string;
  roomNo: string; // Hangi odaya / hücreye yerleşti
  treatmentApplied: string; // Hangi uygulama yapıldı: Ön Soğutma, Ozonlama, 1-MCP SmartFresh, Etilen Gazlama, vb.
  expectedWeightKg?: number;
  acceptedWeightKg: number;
  weightDiffKg?: number;
  weightDiffPercent?: number;
  productTemperature: number; // Ürün İç Sıcaklığı (°C)
  roomTemperature: number;    // Oda Sıcaklığı (°C)
  humidityPercent: number;    // Oda Bağıl Nem (%)
  co2GasLevelPpm?: number;    // CO2 / Gaz Seviyesi ppm
  packaging: string;
  acceptanceStatus: 'ACCEPTED' | 'PARTIAL' | 'REJECTED';
  hygieneStatus: 'Uygun' | 'Uygun Değil';
  coldChainStatus: 'Uygun' | 'Kritik Sapma' | 'Uygun Değil';
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  splitLots?: SplitLotItem[];
  testStatus: 'ACTIVE' | 'COMPLETED';
  nextStep: string;
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;

  // GOST & Avrasya (EAEU) İthalat Kabul Alanları
  inboundType?: 'DOMESTIC' | 'IMPORT_EURASIA_GOST' | 'IMPORT_OTHER';
  docTemperature?: string;
  coolingUnitTemperature?: string;
  actualTemperature?: string;
  supplier?: string;
  transportType?: string;
  batchNumber?: string;
  brand?: string;
  category?: string;
  palletCount?: number;
  assessmentForQuality?: number;
  tasteBrix?: string;
  caliberDeclared?: string;
  caliberActual?: string;
  caliberPercent?: number;
  sampleBoxCount?: number;
  sampleWeightKg?: number;
  samplePercent?: number;
  wastePercent?: number;
  rotKg?: number;
  rotPercent?: number;
  internalRotNecrosisKg?: number;
  internalRotNecrosisPercent?: number;
  obviousRotTheRotIsObviousKg?: number;
  obviousRotTheRotIsObviousPercent?: number;
  nonStandardKg?: number;
  nonStandardPercent?: number;
  mechanicsKg?: number;
  mechanicsPercent?: number;
  dilutionTopKg?: number;
  dilutionTopPercent?: number;
  easyDeformationKg?: number;
  easyDeformationPercent?: number;
  expertName?: string;
  gostDecision?: 'COMPLIANT' | 'CONDITIONAL_DISCOUNT' | 'REJECTED_INCIDENT';
}

export interface FreezeDryRecord {
  id: string;
  refId: string;
  timestamp: string;
  operator: string;
  processDate: string;
  product: string; // e.g. Şeftali (Extreme 314), Nektarin, Çilek, İncir
  variety: string;
  rawMaterialSource: string; // e.g. Saha Standart Dışı Seçim, Depo Giriş Ayrımı
  rawWeightKg: number; // Giriş Yaş Hammadde Ağırlığı (kg)
  rawQualityGrade?: StandardQualityClassKey; // Giriş Kalite Sınıfı
  kaliteSinifi?: StandardQualityClassKey | string; // Nihai Freeze-Dry Kalite Sınıfı
  splitLots?: SplitLotItem[];
  
  // 1. Hammadde & Giriş Testi
  rawBrix: number; // Brix Şeker (°Bx)
  rawMoisturePercent: number; // Başlangıç Nem Oranı (%)
  sortingWasteKg: number; // Çekirdek/Kabuk/Ayıklama Firesi (kg)
  usableRawWeightKg: number; // İşlenebilir Net Dilim Ağırlığı (kg)
  sliceThicknessMm: number; // Dilim/Küp Kalınlığı (5-7mm vb.)

  // 2. Şok Dondurma (-40°C)
  shockFreezerRoom: string; // Şoklama Odası / Tünel No (örn. Şok Odası 1)
  shockFreezerTempC: number; // Şoklama Sıcaklığı (°C) - Hedef: -40°C
  coreTemperatureC: number; // Çekirdek / Merkez Sıcaklığı (°C)
  shockDurationHours: number; // Şok Dondurma Süresi (saat)
  shockStatus: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';

  // 3. Ara / Hammadde Donuk Depolama (-25°C)
  frozenStorageRoom: string; // Donuk Muhafaza Odası (örn. Donuk Depo -25°C Hücre 3)
  frozenStorageTempC: number; // Donuk Oda Sıcaklığı (°C) - Hedef: -25°C
  frozenStoragePalletNo?: string;
  frozenStorageDays?: number;

  // 4. Liyofilizasyon / Freeze-Dry Kurutma Kabini
  dryerChamberNo: string; // Kabin No (örn. Liyofilizatör FD-02)
  trayCount: number; // Tepsi Sayısı
  vacuumPressureMbar: number; // Vakum Basıncı (mBar / Pa) - Hedef: 0.1-0.5 mbar
  sublimationTimeHours: number; // Süblimasyon & Kurutma Süresi (18-24 saat)
  finalDryWeightKg: number; // Çıkan Kuru Ürün Ağırlığı (kg)
  finalMoisturePercent: number; // Nihai Kuru Ürün Nem Oranı (%) - Hedef: < %2-3
  yieldRatioPercent: number; // Kuruma / Randıman Oranı (%) - Çıkan Kuru / Giren Yaş
  crunchinessTexture: 'Gevrek / Çıtır' | 'Yumuşak (Eksik Kuruma)' | 'Kırılgan / Toz';

  // 5. Paketleme & Ambalajlama
  packagingType: string; // Azot Gazlı Alüminyum Doypack, Vakumlu Torba, Koli
  packageGram: number; // Paket Başı Gramaj (örn. 30g, 50g, 100g)
  totalPackagesProduced: number; // Üretilen Toplam Paket Sayısı
  nitrogenFlushed: boolean; // Azot Gazı Basıldı mı (MAP)
  lotNo: string; // Üretim Parti / Lot No (örn. FD-20260902-L1)
  expiryDate: string; // Tavsiye Edilen Tüketim Tarihi

  processStatus: 'RAW_ACCEPTED' | 'SHOCKED_40C' | 'STORED_25C' | 'DRYING' | 'PACKAGED' | 'COMPLETED';
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface IncidentRecord {
  id: string;
  refId: string;
  incidentId: string; // e.g. INC-20260902-001 / Barlag Akty No
  actNumber?: string; // Resmi Barlag Akty Protokol No
  actDegree?: 1 | 2 | 3; // Akt Dereje: 1, 2, 3
  timestamp: string;
  operator: string;
  assignedTo?: string; // Görevlendirilen Sorumlu Personel
  recordDate?: string;
  incidentDate: string;
  incidentType: string; // Soğuk Zincir Bozulması, Yüksek Fire, Çürüme, Ambalaj Hasarı, vb.
  detectionStage?: string; // Tespit Edildiği Aşama / Modül
  priority: IncidentPriority;
  location?: string;
  lotNo?: string;
  affectedQuantityKg: number;
  affectedCasesCount?: number;
  estimatedLossTmt?: number; // Tahmini Maddi Zarar (TMT)
  description: string;
  rootCauseCategory?: string;
  rootCause?: string;
  immediateAction?: string;
  correctiveAction: string; // DÖF / CAPA (Düzeltici ve Önleyici Faaliyet)
  responsible?: string;
  targetResolutionDate?: string;
  evidence?: string;
  status: IncidentStatus | string;
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface ExportSampleTestItem {
  sampleNo: number;
  hardness: number; // kg/cm2
  brix: number;     // % Sugar
  diameterMm?: number;
  visualScore: number; // 1-5 (5: Kusursuz, 1: Ağır Bozulma)
  defectNotes: string;
}

export interface ExportSampleRecord {
  id: string;
  refId: string;
  timestamp: string;
  testDate: string;
  dispatchDate: string; // Yola çıkış / sevk tarihi
  operator: string;
  product: string;
  variety: string;
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  qualityGrade?: StandardQualityClassKey; // Kalite Sınıfı
  destinationCountry: string; // Rusya, Kazakistan, Özbekistan, BAE vb.
  transitDays: number; // Kaç gün yolda/simülasyonda kaldı
  transitCondition: string; // örn. +2°C Frigo Tır
  initialWeightGr: number; // İlk Ağırlık (gr)
  finalWeightGr: number;   // Son Ağırlık (gr)
  weightLossGr: number;    // Ağırlık Kaybı (gr)
  weightLossPercent: number; // Ağırlık Kaybı (%)
  waterLossPercent: number;  // Su Kaybı / Dehidrasyon (%)
  sampleCount: number;
  samples: ExportSampleTestItem[];
  avgHardness: number;
  avgBrix: number;
  visualAssessment: string; // Görsel Kusur (Buruşma, Kabuk Kararması, Çürüklük)
  shelfLifeDecision: 'EXCELLENT' | 'COMPLIANT' | 'CONDITIONAL' | 'HIGH_RISK';
  decisionNotes: string;
  splitLots?: SplitLotItem[];
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;

  // Russian Sheets Spreadsheet Integration Fields
  docTemperature?: string;
  coolingUnitTemperature?: string;
  actualTemperature?: string;
  supplier?: string;
  transportType?: string;
  batchNumber?: string;
  brand?: string;
  category?: string;
  palletCount?: number;
  assessmentForQuality?: number;
  tasteBrix?: string;
  caliberDeclared?: string;
  caliberActual?: string;
  caliberPercent?: number;
  sampleBoxCount?: number;
  sampleWeightKg?: number;
  samplePercent?: number;
  wastePercent?: number;
  rotKg?: number;
  rotPercent?: number;
  internalRotKg?: number;
  internalRotPercent?: number;
  internalRotNecrosisKg?: number;
  internalRotNecrosisPercent?: number;
  obviousRotKg?: number;
  obviousRotPercent?: number;
  obviousRotTheRotIsObviousKg?: number;
  obviousRotTheRotIsObviousPercent?: number;
  nonStandardKg?: number;
  nonStandardPercent?: number;
  obviousNonStandardKg?: number;
  obviousNonStandardPercent?: number;
  mechanicsKg?: number;
  mechanicsPercent?: number;
  dilutionTopKg?: number;
  dilutionTopPercent?: number;
  easyDeformationKg?: number;
  easyDeformationPercent?: number;
  expertName?: string;
}

export interface SalesVarietyItem {
  variety: string;
  qualityGrade: StandardQualityClassKey;
  caliberSize?: string; // örn: 70-75mm, 18-22cm, 27/30
  caseCount: number;    // Kasa / Koli sayısı
  weightKg: number;     // Net Ağırlık (kg)
  unitPriceTmt?: number; // Birim Fiyat (currency alanındaki para birimiyle, kg başına)
  totalPriceTmt?: number; // Toplam Tutar (currency alanındaki para birimiyle)
  currency?: 'TMT' | 'USD'; // v2.2: para birimi; boşsa eski kayıt = TMT kabul edilir
}

export interface SalesRecord {
  id: string;
  refId: string;
  salesDate: string;
  salesTime?: string;
  timestamp: string;
  operator: string;
  customer: string; // Alıcı Müşteri / Firma
  salesChannel: string; // İhracat (Eksport), Yerel Market Zinciri, Hal Toptancı, Kendi Mağazası
  invoiceNo: string; // Fatura / İrsaliye / Sözleşme No
  product: string;
  items: SalesVarietyItem[];
  totalQuantityKg: number;
  totalCases: number;
  totalPallets?: number;
  overallQualityGrade: string; // Ekstra, Sınıf 1, Sınıf 2
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  vehiclePlate?: string;
  paymentStatus?: 'PAID' | 'PENDING' | 'PARTIAL';
  destination?: string;
  notes: string;
  photos?: string[];
  photoIds?: string[];
  updatedAt?: string;
}

export interface CustomFieldDefinition {
  id: string;
  moduleKey: ModuleKey;
  label: string;
  fieldKey: string;
  fieldType: 'text' | 'number' | 'select' | 'boolean' | 'date';
  options?: string[];
  required?: boolean;
}

export interface ReferenceItem {
  id?: string;
  refId: string;
  moduleKey: ModuleKey;
  product: string;
  variety?: string;
  sortVariety?: string;
  kaliteSinifi?: StandardQualityClassKey | string; // Kalite Sınıfı
  location: string;
  orchard?: string;
  parcel?: string;
  greenhouse?: string;
  source: string;
  destination: string;
  finalDestination?: string;
  quantity: number;
  unit: string;
  status: ReferenceStatus;
  createdAt: string;
  operator: string;
  parentRefId?: string;
  splitLots?: SplitLotItem[];
  isUnsorted?: boolean; // Sortlanmamış / Karma Yük (Henüz sınıflara ayrılmadı)
  isAllocatedFromUnsorted?: boolean; // Referans gösterilerek sınıflara bölündü (Çift sayım engelleme)
  reroutedToFreezeDry?: boolean;
  rerouteReason?: string;
  notes?: string;
  photoUrl?: string;
  photos?: string[];
  photoIds?: string[];
  isLocked?: boolean;
  updatedAt?: string;
}

export interface FullReferenceDetail {
  reference: ReferenceItem;
  harvest?: HarvestRecord[];
  field?: FieldRecord[];
  muz?: MuzRecord[];
  badem?: BademRecord[];
  lojistik?: LojistikRecord[];
  ambar?: AmbarRecord[];
  freezeDry?: FreezeDryRecord[];
  exportSample?: ExportSampleRecord[];
  sales?: SalesRecord[];
  incident?: IncidentRecord[];
}

export interface SystemStats {
  totalReferences: number;
  created: number;
  shipped: number;
  received: number;
  incidents: number;
  completedCount?: number;
  harvestCount: number;
  fieldCount: number;
  muzCount: number;
  bademCount: number;
  freezeDryCount?: number;
  exportSampleCount?: number;
  salesCount?: number;
  totalSalesKg?: number;
}

export interface OfflineQueueItem {
  id: string;
  moduleKey: ModuleKey;
  refId: string;
  record: any;
  createdAt: string;
  synced: boolean;
}

export interface ColdRoomStockItem {
  id: string;
  warehouse: string;
  roomNo: string;
  product: string;
  variety: string;
  refId: string;
  entryDate: string;
  exitDate?: string;
  weightKg: number;
  weightTons: number;
  waitingDays: number;
  status: 'ACTIVE' | 'DISPATCHED';
  treatmentApplied?: string;
  roomTemperature?: number;
  humidityPercent?: number;
}

export interface ColdRoomSummary {
  warehouse: string;
  roomNo: string;
  totalKg: number;
  totalTons: number;
  itemCount: number;
  avgWaitDays: number;
  products: {
    product: string;
    variety?: string;
    kg: number;
    tons: number;
    avgWaitDays: number;
    refCount: number;
  }[];
  longestWaiting?: {
    product: string;
    variety?: string;
    refId: string;
    waitDays: number;
  };
  shortestWaiting?: {
    product: string;
    variety?: string;
    refId: string;
    waitDays: number;
  };
}

export interface ColdRoomMovement {
  refId: string;
  product: string;
  variety?: string;
  warehouse: string;
  roomNo: string;
  weightKg: number;
  entryDate: string;
  exitDate?: string;
  totalWaitDays: number;
  isCompleted: boolean;
}

export type FeedbackType = 'TAVSIYE' | 'SIKAYET' | 'ARIZA' | 'IYILESTIRME' | 'KALITE_IYILESTIRME' | 'SAHA_YETERSIZLIGI' | 'TUTANAK_TAKIBI' | 'DIGER';
export type FeedbackStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
export type FeedbackPriority = 'DUSUK' | 'NORMAL' | 'YUKSEK' | 'ACIL';

export interface FeedbackRecord {
  id: string;
  timestamp: string;
  type: FeedbackType;
  department: string;
  author: string;
  isAnonymous?: boolean;
  contactInfo?: string;
  title: string;
  description: string;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  resolutionNote?: string;
  resolvedAt?: string;
  updatedAt?: string;
}

export interface ActiveFieldContext {
  sector: string;
  orchard: string;
  parcelCode?: string;
  greenhouseNo?: string;
  location?: string;
  product?: string;
  variety?: string;
  ribbonColor?: string;
  harvestCycle?: string;
  source?: 'HEADER' | 'GANTT';
}
