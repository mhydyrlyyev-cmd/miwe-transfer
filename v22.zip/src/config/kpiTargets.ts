/**
 * KPI hedefleri — KALİTE DEPARTMANI tarafından belirlenir.
 * null = hedef tanımlı değil (gösterge hedefsiz gösterilir, uydurma hedef konmaz).
 * Bir hedefi değiştirmek için yalnızca bu dosyayı düzenleyin.
 */
export const KPI_TARGETS = {
  /** Ekstra + I. sınıf payı, kabul edilen kg içinde (%), en az */
  premiumSharePctMin: null as number | null,
  /** Toplam gıda kaybı (%), en fazla — FAO SDG 12.3.1(a) yaklaşımı, müşteri aşaması hariç */
  foodLossPctMax: null as number | null,
  /** Hasattan depo kabulüne süre (gün, medyan), en fazla */
  harvestToCoolingDaysMax: null as number | null,
  /** Nitrat limiti aşan numune payı (%), en fazla */
  nitrateExceedPctMax: 0 as number | null,
  /** Gecikmiş açık DÖF/Barlag Akty sayısı, en fazla */
  overdueCapaMax: 0 as number | null,
  /** Freeze-Dry son nem (%), en fazla — uygulamadaki mevcut eşik */
  freezeDryMoisturePctMax: 6 as number | null,
  /** Nakliyede ürün sıcaklığı üst sınırı (°C) — tanımlanınca soğuk zincir payı hesaplanır */
  transitTempMaxC: null as number | null,
  /** Nakliyede ürün sıcaklığı alt sınırı (°C) */
  transitTempMinC: null as number | null
};
