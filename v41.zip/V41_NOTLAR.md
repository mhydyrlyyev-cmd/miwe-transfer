# v41 — Bekleyen işlemler: çift görünüm düzeltmesi

Uygulama sırası: v40.1'den SONRA. Dosyayı AYNEN (byte-identical) kopyala. Firestore kuralı DEĞİŞMEDİ.

## Sorun
"Bekleyen senkronizasyonlar" sekmesi açıkken kuyruk boşsa Operasyonel görevler de altında çıkıyordu
(aynı listeler iki kez). Altta ayrıca Referanslar sayfasının kopyası olan büyük tablo vardı.

## Düzeltme (src/components/views/PendingOperationsView.tsx)
1. Her sekme yalnız kendi içeriğini gösterir: Senkronizasyon = cihaz kuyruğu; Operasyonel = sevk bekleyen,
   yolda / kabul bekleyen, açık aktlar.
2. Sayfa, kuyruk boşsa doğrudan "Operasyonel görevler" sekmesiyle açılır; kuyrukta kayıt varsa Senkronizasyon ile.
3. "Tüm partiler & süreç takip çizelgesi" yalnız Operasyonel sekmede, kapalı "Tüm partiler tablosu (n)" olarak durur.

## Kabul testleri
1. Kuyruk boşken sayfa Operasyonel görevlerle açılıyor; Senkronizasyon sekmesinde yalnız kuyruk bölümü var.
2. Operasyonel sekmesinde 3 liste bir kez görünüyor; senkronizasyon kartı yok.
3. "Tüm partiler tablosu" kapalı; "Göster" ile açılıyor.
4. TypeScript derleme hatası yok.
