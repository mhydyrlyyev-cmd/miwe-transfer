import React, { useState } from 'react';
import {
  Clock,
  Truck,
  Warehouse,
  AlertOctagon,
  CheckCircle2,
  ChevronRight,
  Package,
  ShieldAlert,
  Search,
  ExternalLink,
  Edit,
  Eye,
  Archive,
  ArrowRight,
  Filter,
  Trash2,
  AlertCircle,
  RefreshCw,
  Camera,
  Layers,
  Sparkles,
  Wifi,
  WifiOff,
  Printer,
  RotateCcw,
  AlertTriangle,
  Activity,
  BarChart2
} from 'lucide-react';
import { ReferenceItem, IncidentRecord, LojistikRecord } from '../../types';

import { isTestReference } from '../../utils/refKind';
export interface PendingQueueItem {
  action?: string;
  payload?: any;
  retryCount?: number;
  lastError?: string;
  timestamp?: number | string;
  [key: string]: any;
}

interface PendingOperationsViewProps {
  references: ReferenceItem[];
  lojistikRecords: LojistikRecord[];
  incidentRecords: IncidentRecord[];
  offlineQueue?: PendingQueueItem[];
  isSyncing?: boolean;
  isOnline?: boolean;
  lastSyncTime?: string | null;
  onSyncSingleQueueItem?: (index: number) => void | Promise<void>;
  onSyncAllQueue?: () => void | Promise<void>;
  onRetryFailedItems?: () => void | Promise<void>;
  onDeleteQueueItem?: (index: number) => void;
  onEditQueueItem?: (item: any) => void;
  onDispatch: (refId: string) => void;
  onReceive: (refId: string) => void;
  onResolveIncident: (incident: IncidentRecord) => void;
  onOpenTraceability?: (item: ReferenceItem) => void;
  onEditReference?: (item: ReferenceItem) => void;
  onToggleStatus?: (refId: string) => void;
  onDeleteReference?: (refId: string) => void;
  onDeleteIncident?: (incidentId: string) => void;
}

export const PendingOperationsView: React.FC<PendingOperationsViewProps> = ({
  references = [],
  lojistikRecords = [],
  incidentRecords = [],
  offlineQueue = [],
  isSyncing = false,
  isOnline = true,
  lastSyncTime = null,
  onSyncSingleQueueItem,
  onSyncAllQueue,
  onRetryFailedItems,
  onDeleteQueueItem,
  onEditQueueItem,
  onDispatch,
  onReceive,
  onResolveIncident,
  onOpenTraceability,
  onEditReference,
  onToggleStatus,
  onDeleteReference,
  onDeleteIncident
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  // v4.1: sekmeler birbirini tekrar etmez; kuyruk boşsa Operasyonel görevlerle açılır
  const [activeTab, setActiveTab] = useState<'OFFLINE' | 'OPERATIONAL'>(() => ((offlineQueue?.length || 0) > 0 ? 'OFFLINE' : 'OPERATIONAL'));
  const [queueFilter, setQueueFilter] = useState<'ALL' | 'READY' | 'RETRYING' | 'CRITICAL_FAILED'>('ALL');
  const [itemToDelete, setItemToDelete] = useState<{ type: 'REFERENCE' | 'INCIDENT'; id: string; title: string } | null>(null);

  // 1. Ready for Dispatch
  const readyForDispatch = references.filter(r => r.status === 'CREATED' && !isTestReference(r));

  // 2. In Transit / Awaiting Warehouse Receipt
  const awaitingReceipt = references.filter(r => r.status === 'SHIPPED' || r.status === 'IN_TRANSIT');

  // 3. Open Incidents
  const openIncidents = incidentRecords.filter(i => i.status === 'OPEN' || i.status === 'IN_PROGRESS');

  // Queue Analytics & Categorization
  const totalQueue = offlineQueue.length;
  
  // Categorize items by retry failure counts
  const indexedQueue = offlineQueue.map((item, originalIndex) => ({
    item,
    originalIndex,
    retries: item.retryCount || 0
  }));

  const criticalFailedItems = indexedQueue.filter(entry => entry.retries > 3);
  const retryingItems = indexedQueue.filter(entry => entry.retries > 0 && entry.retries <= 3);
  const cleanPendingItems = indexedQueue.filter(entry => entry.retries === 0);

  // Visual Progress Bar Metrics
  // When totalQueue === 0, sync is 100% complete.
  // When totalQueue > 0, calculate healthy / pending vs critical failed ratios
  const progressPercent = totalQueue === 0
    ? 100
    : isSyncing
      ? 75
      : Math.max(5, Math.min(100, Math.round(((cleanPendingItems.length * 1.0 + retryingItems.length * 0.4) / totalQueue) * 100)));

  const cleanPercent = totalQueue > 0 ? (cleanPendingItems.length / totalQueue) * 100 : 0;
  const retryingPercent = totalQueue > 0 ? (retryingItems.length / totalQueue) * 100 : 0;
  const criticalPercent = totalQueue > 0 ? (criticalFailedItems.length / totalQueue) * 100 : 0;

  // Filtered queue items based on selected tab/pill
  const displayedQueueItems = indexedQueue.filter(entry => {
    if (queueFilter === 'READY') return entry.retries === 0;
    if (queueFilter === 'RETRYING') return entry.retries > 0 && entry.retries <= 3;
    if (queueFilter === 'CRITICAL_FAILED') return entry.retries > 3;
    return true;
  });

  // Helper for module display label
  const getModuleMeta = (moduleKey?: string) => {
    switch (moduleKey) {
      case 'HARVEST': return { label: 'Günlük Hasat', emoji: '🌿', color: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      case 'FIELD': return { label: 'Meyve Kalite Testi', emoji: '🍎', color: 'bg-rose-100 text-rose-900 border-rose-300' };
      case 'MUZ': return { label: 'Muz Kalite Kontrol', emoji: '🍌', color: 'bg-amber-100 text-amber-900 border-amber-300' };
      case 'BADEM': return { label: 'Badem Testi & Randıman', emoji: '🥜', color: 'bg-orange-100 text-orange-900 border-orange-300' };
      case 'LOJISTIK': return { label: 'Lojistik & Delilnama', emoji: '🚚', color: 'bg-blue-100 text-blue-900 border-blue-300' };
      case 'AMBAR': return { label: 'Ambar Kabul & Depo', emoji: '🏭', color: 'bg-teal-100 text-teal-900 border-teal-300' };
      case 'FREEZE_DRY': return { label: 'Freeze & Dry Kurutma', emoji: '❄️', color: 'bg-cyan-100 text-cyan-900 border-cyan-300' };
      case 'EXPORT_SAMPLE': return { label: 'Eksport Numune', emoji: '🌐', color: 'bg-indigo-100 text-indigo-900 border-indigo-300' };
      case 'SALES': return { label: 'Satış & Sevkiyat', emoji: '🛍️', color: 'bg-purple-100 text-purple-900 border-purple-300' };
      case 'INCIDENT': return { label: 'Barlag Akty & DÖF', emoji: '⚠️', color: 'bg-rose-100 text-rose-900 border-rose-300' };
      default: return { label: moduleKey || 'Yerel Kayıt', emoji: '📋', color: 'bg-slate-100 text-slate-900 border-slate-300' };
    }
  };

  // Helper for photo count
  const getPhotoCount = (payload: any) => {
    if (!payload) return 0;
    const rec = payload.record || {};
    if (Array.isArray(rec.photos)) return rec.photos.length;
    if (rec.photoUrl) return 1;
    return 0;
  };

  // Helper for RefNo / LotNo
  const getRefNo = (payload: any) => {
    if (!payload) return 'KAYIT-LOCAL';
    const rec = payload.record || {};
    const ref = payload.newRefData || {};
    return rec.refId || rec.delilnamaNo || rec.lotNo || ref.refId || 'PAR-LOCAL';
  };

  // Helper for date/time formatting
  const getFormattedDateTime = (payload: any) => {
    if (!payload) return new Date().toLocaleString('tr-TR');
    const rec = payload.record || {};
    const ts = rec.createdAt || rec.timestamp || payload.timestamp;
    if (!ts) return new Date().toLocaleString('tr-TR');
    try {
      return new Date(ts).toLocaleString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (e) {
      return String(ts);
    }
  };

  // Filtered references for master pending table
  const filteredReferences = references.filter(r => {
    const matchesSearch =
      searchTerm === '' ||
      r.refId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.location && r.location.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.destination && r.destination.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'ACTIVE_PENDING' && !isTestReference(r) && (r.status === 'CREATED' || r.status === 'SHIPPED' || r.status === 'IN_TRANSIT')) ||
      r.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleRetryCriticalAll = async () => {
    if (onRetryFailedItems) {
      await onRetryFailedItems();
    } else if (onSyncAllQueue) {
      await onSyncAllQueue();
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner & Top Tabs */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-extrabold flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-400" />
              <span>Bekleyen İşlemler & Senkronizasyon Paneli</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Çevrimdışı yerel (IndexedDB) kuyruğu, senkronizasyon ilerleme durumu ve operasyonel görevlerin şeffaf yönetimi
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* 'Retry All' button for items that failed more than 3 times */}
            {criticalFailedItems.length > 0 && (
              <button
                type="button"
                onClick={handleRetryCriticalAll}
                disabled={isSyncing}
                className="px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-md active:scale-95 cursor-pointer disabled:opacity-50"
                title="3 kereden fazla başarısız olmuş tüm kayıtları yeniden dene"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>3+ Başarısızları Yeniden Dene</span>
                <span className="px-1.5 py-0.5 rounded-full bg-black/40 text-rose-200 font-mono text-[10px] tabular-nums">
                  {criticalFailedItems.length}
                </span>
              </button>
            )}

            {onSyncAllQueue && (
              <button
                type="button"
                onClick={onSyncAllQueue}
                disabled={totalQueue === 0 || isSyncing}
                className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 shadow-md ${
                  totalQueue > 0
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Senkronize Ediliyor...' : 'Tümünü Senkronize Et'}</span>
                <span className="px-2 py-0.5 rounded-full bg-slate-950 text-amber-300 font-mono text-[10px] tabular-nums">
                  {totalQueue}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('OFFLINE')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'OFFLINE'
                ? 'bg-amber-500 text-slate-950 font-black shadow-sm'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <WifiOff className="w-3.5 h-3.5 text-amber-950" />
            <span>Bekleyen Senkronizasyonlar</span>
            <span className={`px-2 py-0.2 rounded-full font-mono text-[10px] tabular-nums ${
              activeTab === 'OFFLINE' ? 'bg-slate-950 text-amber-300' : 'bg-slate-700 text-slate-200'
            }`}>
              {totalQueue}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('OPERATIONAL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'OPERATIONAL'
                ? 'bg-teal-500 text-slate-950 font-black shadow-sm'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Package className="w-3.5 h-3.5 text-teal-950" />
            <span>Operasyonel Görevler</span>
            <span className={`px-2 py-0.2 rounded-full font-mono text-[10px] tabular-nums ${
              activeTab === 'OPERATIONAL' ? 'bg-slate-950 text-teal-300' : 'bg-slate-700 text-slate-200'
            }`}>
              {readyForDispatch.length + awaitingReceipt.length + openIncidents.length}
            </span>
          </button>
        </div>
      </div>

      {/* SECTION 1: BEKLEYEN SENKRONİZASYONLAR & VISUAL PROGRESS BAR */}
      {activeTab === 'OFFLINE' && (
        <div className="space-y-4">
          
          {/* VISUAL PROGRESS BAR & SYNC STATUS CARD */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl font-bold ${
                  totalQueue === 0
                    ? 'bg-emerald-100 text-emerald-800'
                    : isSyncing
                      ? 'bg-sky-100 text-sky-800 animate-spin'
                      : criticalFailedItems.length > 0
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                }`}>
                  {totalQueue === 0 ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : isSyncing ? (
                    <RefreshCw className="w-5 h-5 text-sky-600" />
                  ) : criticalFailedItems.length > 0 ? (
                    <AlertTriangle className="w-5 h-5 text-rose-600" />
                  ) : (
                    <Activity className="w-5 h-5 text-amber-600" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900">
                      Senkronizasyon İlerleme & Kuyruk Durumu
                    </h3>
                    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded font-mono ${
                      totalQueue === 0
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : isSyncing
                          ? 'bg-sky-100 text-sky-800 border border-sky-200 animate-pulse'
                          : criticalFailedItems.length > 0
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}>
                      {totalQueue === 0
                        ? 'TAM SENKRONİZE'
                        : isSyncing
                          ? 'EŞİTLENİYOR...'
                          : criticalFailedItems.length > 0
                            ? 'DİKKAT: 3+ BAŞARISIZ İŞLEM'
                            : 'KUYRUKTA BEKLİYOR'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {totalQueue === 0
                      ? 'Cihazdaki tüm yerel kayıtlar ve görseller bulut veritabanıyla senkronize edilmiştir.'
                      : `${totalQueue} adet yerel kayıt buluta iletilmeyi bekliyor.`}
                  </p>
                </div>
              </div>

              {/* Online / Offline & Last Sync Badge */}
              <div className="flex items-center gap-3 text-xs text-slate-500 self-stretch sm:self-auto justify-between sm:justify-end">
                <span className="flex items-center gap-1 font-medium">
                  {isOnline ? (
                    <>
                      <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Çevrimiçi</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="w-3.5 h-3.5 text-amber-600" />
                      <span className="text-amber-700">Çevrimdışı</span>
                    </>
                  )}
                </span>
                {lastSyncTime && (
                  <span className="font-mono text-[11px] text-slate-400">
                    Son Eşitleme: <strong className="text-slate-700 tabular-nums">{lastSyncTime}</strong>
                  </span>
                )}
              </div>
            </div>

            {/* Visual Progress Bar Component */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span className="flex items-center gap-1.5">
                  <BarChart2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Kuyruk Tamamlanma & Sağlık Oranı</span>
                </span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  %{progressPercent}
                </span>
              </div>

              {/* Segmented Progress Track */}
              <div
                role="progressbar"
                aria-valuenow={progressPercent}
                aria-valuemin={0}
                aria-valuemax={100}
                className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200 flex items-stretch gap-0.5"
              >
                {totalQueue === 0 ? (
                  <div className="h-full w-full bg-emerald-500 rounded-full transition-all duration-500" />
                ) : (
                  <>
                    {/* Clean / Ready segment (Green) */}
                    {cleanPercent > 0 && (
                      <div
                        style={{ width: `${cleanPercent}%` }}
                        className={`h-full bg-emerald-500 rounded-l-full transition-all duration-500 ${isSyncing ? 'animate-pulse' : ''}`}
                        title={`Hazır: ${cleanPendingItems.length} kayıt`}
                      />
                    )}
                    {/* Retrying 1-3x segment (Amber) */}
                    {retryingPercent > 0 && (
                      <div
                        style={{ width: `${retryingPercent}%` }}
                        className={`h-full bg-amber-400 transition-all duration-500 ${isSyncing ? 'animate-pulse' : ''}`}
                        title={`Tekrar Deneniyor (1-3x): ${retryingItems.length} kayıt`}
                      />
                    )}
                    {/* Critical Failed >3x segment (Rose/Red) */}
                    {criticalPercent > 0 && (
                      <div
                        style={{ width: `${criticalPercent}%` }}
                        className="h-full bg-rose-500 rounded-r-full transition-all duration-500"
                        title={`3+ Kez Başarısız: ${criticalFailedItems.length} kayıt`}
                      />
                    )}
                  </>
                )}
              </div>

              {/* Progress Legend & Key Numbers */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                  <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Toplam Kuyruk</div>
                  <div className="font-mono text-base font-extrabold text-slate-900 tabular-nums">{totalQueue}</div>
                  <div className="text-[10px] text-slate-400">İşlem bekliyor</div>
                </div>

                <div className="p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-200/70">
                  <div className="text-[10px] text-emerald-800 font-bold uppercase tracking-wider flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                    <span>Hazır (0 Hata)</span>
                  </div>
                  <div className="font-mono text-base font-extrabold text-emerald-900 tabular-nums">{cleanPendingItems.length}</div>
                  <div className="text-[10px] text-emerald-700">İlk aktarım bekliyor</div>
                </div>

                <div className="p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/70">
                  <div className="text-[10px] text-amber-800 font-bold uppercase tracking-wider flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                    <span>Deneniyor (1-3x)</span>
                  </div>
                  <div className="font-mono text-base font-extrabold text-amber-900 tabular-nums">{retryingItems.length}</div>
                  <div className="text-[10px] text-amber-700">Tekrar kuyruğunda</div>
                </div>

                <div className={`p-2.5 rounded-xl border ${
                  criticalFailedItems.length > 0
                    ? 'bg-rose-50 border-rose-300'
                    : 'bg-slate-50 border-slate-200/70'
                }`}>
                  <div className="text-[10px] text-rose-800 font-bold uppercase tracking-wider flex items-center gap-1">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${criticalFailedItems.length > 0 ? 'bg-rose-600 animate-ping' : 'bg-slate-300'}`} />
                    <span>3+ Başarısız</span>
                  </div>
                  <div className={`font-mono text-base font-extrabold tabular-nums ${criticalFailedItems.length > 0 ? 'text-rose-700' : 'text-slate-400'}`}>
                    {criticalFailedItems.length}
                  </div>
                  <div className="text-[10px] text-rose-700">Müdahale gerekebilir</div>
                </div>
              </div>
            </div>
          </div>

          {/* DEDICATED CALLOUT BANNER FOR ITEMS FAILED > 3 TIMES */}
          {criticalFailedItems.length > 0 && (
            <div className="bg-rose-50 border border-rose-300/80 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-rose-100 text-rose-700 rounded-xl shrink-0 mt-0.5">
                    <AlertTriangle className="w-5 h-5 text-rose-600" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-rose-950 flex items-center gap-2">
                      <span>3+ Kez Başarısız Olan {criticalFailedItems.length} Kayıt Askıda Kaldı</span>
                      <span className="font-mono text-[10px] bg-rose-200 text-rose-900 px-2 py-0.5 rounded font-bold">
                        KRİTİK
                      </span>
                    </h4>
                    <p className="text-[11px] text-rose-800 mt-1 max-w-2xl leading-relaxed">
                      Bu kayıtlar ağ kesintisi veya sunucu zaman aşımı sebebiyle 3 denemeden fazla başarısız oldu.
                      Aşağıdaki <strong>"3+ Başarısızları Yeniden Dene"</strong> butonuna tıklayarak tümünün deneme sayaçlarını sıfırlayabilir ve tek hamlede yeniden buluta gönderebilirsiniz.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleRetryCriticalAll}
                  disabled={isSyncing}
                  className="px-4 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center gap-2 shrink-0 cursor-pointer disabled:opacity-50"
                >
                  <RotateCcw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>3+ Başarısızları Yeniden Dene ({criticalFailedItems.length})</span>
                </button>
              </div>
            </div>
          )}

          {/* MAIN QUEUE LIST CONTAINER */}
          <div className="bg-white rounded-2xl border border-amber-200/80 shadow-sm overflow-hidden">
            <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border-b border-amber-200/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-bold">
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                </div>
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-2">
                    <span>Bekleyen Yerel Senkronizasyonlar (IndexedDB Queue)</span>
                  </h3>
                  <p className="text-[11px] text-amber-800">
                    Cihazınızda çevrimdışı kaydedilmiş veriler. İnternet bağlandığında veya "Senkronize Et" butonuna basıldığında buluta aktarılır.
                  </p>
                </div>
              </div>

              {/* Filter Tabs for Queue */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => setQueueFilter('ALL')}
                  className={`text-xs px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    queueFilter === 'ALL'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white/80 text-slate-700 hover:bg-white border border-slate-200'
                  }`}
                >
                  Tümü ({totalQueue})
                </button>

                <button
                  type="button"
                  onClick={() => setQueueFilter('READY')}
                  className={`text-xs px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    queueFilter === 'READY'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-white/80 text-emerald-800 hover:bg-white border border-emerald-200'
                  }`}
                >
                  Hazır ({cleanPendingItems.length})
                </button>

                {criticalFailedItems.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setQueueFilter('CRITICAL_FAILED')}
                    className={`text-xs px-2.5 py-1.5 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                      queueFilter === 'CRITICAL_FAILED'
                        ? 'bg-rose-700 text-white shadow-xs'
                        : 'bg-white/80 text-rose-800 hover:bg-white border border-rose-200'
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3 text-rose-600" />
                    <span>3+ Başarısız ({criticalFailedItems.length})</span>
                  </button>
                )}
              </div>
            </div>

            <div className="p-4">
              {totalQueue === 0 ? (
                <div className="text-center py-10 bg-slate-50/60 rounded-xl border border-dashed border-slate-200">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
                  <h4 className="text-xs font-bold text-slate-700">Bekleyen Senkronizasyon Bulunmuyor</h4>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Tüm yerel kayıtlar ve fotoğraflar Google Sheets / Bulut sunucusuna başarıyla aktarılmıştır.
                  </p>
                </div>
              ) : displayedQueueItems.length === 0 ? (
                <div className="text-center py-10 bg-slate-50/60 rounded-xl border border-dashed border-slate-200">
                  <Filter className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-700">Seçilen Filtreye Uygun Kayıt Yok</h4>
                  <button
                    type="button"
                    onClick={() => setQueueFilter('ALL')}
                    className="mt-2 text-xs text-amber-700 font-bold underline"
                  >
                    Tümünü Göster
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {displayedQueueItems.map(({ item, originalIndex, retries }) => {
                    const meta = getModuleMeta(item.payload?.moduleKey);
                    const photoCount = getPhotoCount(item.payload);
                    const refNo = getRefNo(item.payload);
                    const dateTime = getFormattedDateTime(item.payload);
                    const isCritical = retries > 3;

                    return (
                      <div
                        key={originalIndex}
                        className={`rounded-xl p-3.5 transition shadow-xs flex flex-col justify-between space-y-3 border ${
                          isCritical
                            ? 'bg-rose-50/40 border-rose-300 hover:border-rose-400'
                            : retries > 0
                              ? 'bg-amber-50/30 border-amber-300 hover:border-amber-400'
                              : 'bg-slate-50/80 hover:bg-white border-slate-200 hover:border-amber-300'
                        }`}
                      >
                        <div className="space-y-2">
                          {/* Top Module & Ref Bar */}
                          <div className="flex items-center justify-between gap-2">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wider border flex items-center gap-1 ${meta.color}`}>
                              <span>{meta.emoji}</span>
                              <span>{meta.label}</span>
                            </span>
                            <span className="font-mono text-xs font-black text-slate-900 bg-slate-200/70 px-2 py-0.5 rounded">
                              {refNo}
                            </span>
                          </div>

                          {/* Failure / Status Transparency Tag */}
                          <div className="flex items-center justify-between gap-2 text-[10px]">
                            <span className="text-slate-500 font-medium">Eşitleme Durumu:</span>
                            {isCritical ? (
                              <span className="font-mono font-bold text-rose-700 bg-rose-100 border border-rose-300 px-1.5 py-0.5 rounded flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 text-rose-600" />
                                <span>⚠️ {retries} Kez Başarısız</span>
                              </span>
                            ) : retries > 0 ? (
                              <span className="font-mono font-bold text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded">
                                Deneme: {retries}/3
                              </span>
                            ) : (
                              <span className="font-mono font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-1.5 py-0.5 rounded">
                                İlk Gönderim Bekliyor
                              </span>
                            )}
                          </div>

                          {/* Last error explanation if present */}
                          {(item.lastError || item.payload?.lastError) && (
                            <div className="text-[10px] text-rose-800 bg-rose-100/70 border border-rose-200 rounded p-1.5 font-mono truncate" title={item.lastError || item.payload?.lastError}>
                              Hata: {item.lastError || item.payload?.lastError}
                            </div>
                          )}

                          {/* Details */}
                          <div className="text-xs text-slate-700 space-y-1 pt-1">
                            <div className="flex items-center justify-between text-[11px] text-slate-500">
                              <span>Kayıt Tarihi:</span>
                              <span className="font-mono font-semibold text-slate-800">{dateTime}</span>
                            </div>

                            <div className="flex items-center justify-between text-[11px]">
                              <span className="text-slate-500">Fotoğraf Sayısı:</span>
                              <span className={`font-bold flex items-center gap-1 ${photoCount > 0 ? 'text-emerald-700 font-mono' : 'text-slate-400'}`}>
                                <Camera className="w-3 h-3 text-emerald-600" />
                                <span>{photoCount > 0 ? `📸 ${photoCount} Görsel` : 'Fotoğraf Yok'}</span>
                              </span>
                            </div>

                            {item.payload?.record?.product && (
                              <div className="text-xs font-semibold text-slate-900 truncate">
                                Ürün: {item.payload.record.product}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* 3 Action Buttons */}
                        <div className="pt-2 border-t border-slate-200/80 flex items-center gap-1.5">
                          {/* 1. Sync / Retry Now */}
                          {onSyncSingleQueueItem && (
                            <button
                              type="button"
                              onClick={() => onSyncSingleQueueItem(originalIndex)}
                              disabled={isSyncing}
                              className={`flex-1 flex items-center justify-center gap-1 py-1.5 px-2 font-extrabold rounded-lg text-xs transition active:scale-95 shadow-xs cursor-pointer disabled:opacity-50 ${
                                isCritical
                                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              }`}
                              title={isCritical ? 'Sayacı sıfırla ve yeniden dene' : 'Sadece bu kaydı ve fotoğraflarını senkronize et'}
                            >
                              <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                              <span>{isCritical ? 'Sıfırla & Şimdi Dene' : 'Şimdi Senkronize Et'}</span>
                            </button>
                          )}

                          {/* 2. Edit */}
                          {onEditQueueItem && (
                            <button
                              type="button"
                              onClick={() => onEditQueueItem(item)}
                              className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-bold transition shadow-xs cursor-pointer"
                              title="Kaydı Düzenle"
                            >
                              <Edit className="w-3.5 h-3.5 text-slate-700" />
                            </button>
                          )}

                          {/* 3. Delete */}
                          {onDeleteQueueItem && (
                            <button
                              type="button"
                              onClick={() => onDeleteQueueItem(originalIndex)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition shadow-xs cursor-pointer"
                              title="Yerel Kaydı Sil"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: OPERASYONEL BEKLEYEN GÖREVLER */}
      {activeTab === 'OPERATIONAL' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Queue 1: Sevkiyat Bekleyenler */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-blue-700" />
                <h3 className="text-xs font-black uppercase tracking-wider text-blue-900">
                  1. Sevkiyat Bekleyen Partiler
                </h3>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-blue-200 text-blue-900 tabular-nums">
                {readyForDispatch.length}
              </span>
            </div>

            <div className="p-3 flex-1 divide-y divide-slate-100 overflow-y-auto max-h-[400px]">
              {readyForDispatch.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-400">
                  Sevkiyat bekleyen parti bulunmuyor.
                </div>
              ) : (
                readyForDispatch.map(item => (
                  <div key={item.refId} className="py-3 px-2 flex flex-col gap-2 hover:bg-slate-50 rounded-lg transition">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono font-bold text-xs text-slate-900 block">
                          {item.refId}
                        </span>
                        <span className="text-xs font-semibold text-slate-700">
                          {item.product}
                        </span>
                      </div>
                      <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 tabular-nums">
                        {item.quantity} {item.unit}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500">
                      Konum: <strong>{item.location}</strong> &rarr; Hedef: <strong>{item.destination || 'Belirtilmedi'}</strong>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <button
                        type="button"
                        onClick={() => onDispatch(item.refId)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Lojistik Sevkiyat Aç &rarr;</span>
                      </button>
                      {onOpenTraceability && (
                        <button
                          type="button"
                          onClick={() => onOpenTraceability(item)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition cursor-pointer"
                          title="Parti PDF Özeti İndir / Yazdır"
                        >
                          <Printer className="w-3.5 h-3.5 text-teal-700" />
                        </button>
                      )}
                      {onDeleteReference && (
                        <button
                          type="button"
                          onClick={() => setItemToDelete({ type: 'REFERENCE', id: item.refId, title: `${item.refId} (${item.product})` })}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-slate-200 transition cursor-pointer"
                          title="Partiyi / Operasyonu Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Queue 2: Ambar Kabul Bekleyenler */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 bg-amber-50 border-b border-amber-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-700" />
                <h3 className="text-xs font-black uppercase tracking-wider text-amber-900">
                  2. Yolda / Kabul Bekleyenler
                </h3>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 tabular-nums">
                {awaitingReceipt.length}
              </span>
            </div>

            <div className="p-3 flex-1 divide-y divide-slate-100 overflow-y-auto max-h-[400px]">
              {awaitingReceipt.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-400">
                  Yolda olan sevkiyat bulunmuyor.
                </div>
              ) : (
                awaitingReceipt.map(item => {
                  const loj = lojistikRecords.find(l => l.refId === item.refId);

                  return (
                    <div key={item.refId} className="py-3 px-2 flex flex-col gap-2 hover:bg-slate-50 rounded-lg transition">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-mono font-bold text-xs text-slate-900 block">
                            {item.refId}
                          </span>
                          <span className="text-xs font-semibold text-slate-700">
                            {item.product}
                          </span>
                        </div>
                        <span className="font-mono text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 tabular-nums">
                          {item.quantity} {item.unit}
                        </span>
                      </div>

                      {loj && (
                        <div className="bg-amber-50/70 p-2 rounded text-[11px] text-amber-950 font-medium">
                          <div>Plaka: <strong>{loj.vehiclePlate}</strong> ({loj.driver})</div>
                          <div>Delilnama: <strong>{loj.delilnamaNo}</strong></div>
                          <div>Çıkış Sıcaklığı: <strong>{loj.departureTemperature}°C</strong></div>
                        </div>
                      )}

                      <div className="flex items-center gap-1.5 mt-1">
                        <button
                          type="button"
                          onClick={() => onReceive(item.refId)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
                        >
                          <Warehouse className="w-3.5 h-3.5" />
                          <span>Ambar Kantar Kabulü Yap &rarr;</span>
                        </button>
                        {onOpenTraceability && (
                          <button
                            type="button"
                            onClick={() => onOpenTraceability(item)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition cursor-pointer"
                            title="Parti PDF Özeti İndir / Yazdır"
                          >
                            <Printer className="w-3.5 h-3.5 text-teal-700" />
                          </button>
                        )}
                        {onDeleteReference && (
                          <button
                            type="button"
                            onClick={() => setItemToDelete({ type: 'REFERENCE', id: item.refId, title: `${item.refId} (${item.product})` })}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-slate-200 transition cursor-pointer"
                            title="Partiyi / Operasyonu Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Queue 3: Açık Incidentler */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 bg-rose-50 border-b border-rose-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-rose-700" />
                <h3 className="text-xs font-black uppercase tracking-wider text-rose-900">
                  3. Açık Barlag Akty & DÖF
                </h3>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-rose-200 text-rose-900 tabular-nums">
                {openIncidents.length}
              </span>
            </div>

            <div className="p-3 flex-1 divide-y divide-slate-100 overflow-y-auto max-h-[400px]">
              {openIncidents.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-400">
                  Açık incident kaydı bulunmuyor.
                </div>
              ) : (
                openIncidents.map(inc => (
                  <div key={inc.id} className="py-3 px-2 flex flex-col gap-2 hover:bg-slate-50 rounded-lg transition">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono font-bold text-xs text-rose-900 block">
                          {inc.incidentId}
                        </span>
                        <span className="text-xs font-semibold text-slate-700">
                          {inc.incidentType}
                        </span>
                      </div>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded border ${
                        inc.priority === 'CRITICAL' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                        inc.priority === 'HIGH' ? 'bg-orange-100 text-orange-800 border-orange-300' :
                        'bg-amber-100 text-amber-800 border-amber-300'
                      }`}>
                        {inc.priority}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2 rounded">
                      "{inc.description}"
                    </p>

                    <div className="text-[11px] text-slate-500">
                      RefID: <strong className="font-mono">{inc.refId}</strong> | Etkilenen: <strong className="tabular-nums">{inc.affectedQuantityKg} kg</strong>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <button
                        type="button"
                        onClick={() => onResolveIncident(inc)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>DÖF İncele & Çözümle &rarr;</span>
                      </button>
                      {onDeleteIncident && (
                        <button
                          type="button"
                          onClick={() => setItemToDelete({ type: 'INCIDENT', id: inc.id, title: `${inc.incidentId} (${inc.incidentType})` })}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-slate-200 transition cursor-pointer"
                          title="Tutanağı Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Comprehensive Master Pending / In-Progress Table — v4.1: yalnız Operasyonel sekmede, kapalı başlar (Referanslar sayfasını tekrar etmesin) */}
      {activeTab === 'OPERATIONAL' && (
      <details className="group bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <summary className="list-none cursor-pointer select-none px-4 py-3 flex items-center justify-between text-sm font-bold text-slate-800 hover:bg-slate-50">
          <span>Tüm partiler tablosu ({filteredReferences.length})</span>
          <span className="text-xs font-semibold text-slate-500 group-open:hidden">Göster</span>
          <span className="text-xs font-semibold text-slate-500 hidden group-open:inline">Gizle</span>
        </summary>
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-teal-600" />
              <span>Tüm Partiler & Süreç Takip Çizelgesi ({filteredReferences.length} Kayıt)</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              RefID bazlı anlık durum, bir sonraki aşama, sorumlu ve detay pasaportu
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <input
                type="text"
                placeholder="RefID, Ürün veya Konum ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-7 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5" />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-white"
            >
              <option value="ALL">Tüm Durumlar</option>
              <option value="ACTIVE_PENDING">Sadece Bekleyenler</option>
              <option value="CREATED">Hazır (Saha / Hasat)</option>
              <option value="SHIPPED">Sevkiyatta (Yolda)</option>
              <option value="RECEIVED">Kabul Edildi (Ambar)</option>
              <option value="IN_FREEZE_DRY">Freeze-Dry Aşamasında</option>
              <option value="SOLD">Satıldı / Sevk Edildi</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 text-slate-600 font-semibold text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-3">RefID</th>
                <th className="py-3 px-3">Ürün & Miktar</th>
                <th className="py-3 px-3">Kaynak &rarr; Gidecek Yer</th>
                <th className="py-3 px-3">Mevcut Durum</th>
                <th className="py-3 px-3">Sorumlu / Operatör</th>
                <th className="py-3 px-3">Tarih</th>
                <th className="py-3 px-3 text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
              {filteredReferences.map((ref) => (
                <tr key={ref.refId} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-3">
                    <span className="font-mono font-bold text-teal-700">{ref.refId}</span>
                    <div className="text-[10px] text-slate-400">{ref.moduleKey}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-900">{ref.product}</div>
                    <span className="text-[11px] font-mono text-slate-500 tabular-nums">
                      {ref.quantity} {ref.unit}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="text-slate-700">{ref.source || ref.location || '-'}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <span>&rarr;</span>
                      <span className="truncate">{ref.destination || 'Belirtilmedi'}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      ref.status === 'CREATED' ? 'bg-blue-100 text-blue-800' :
                      ref.status === 'SHIPPED' ? 'bg-amber-100 text-amber-800' :
                      ref.status === 'RECEIVED' ? 'bg-emerald-100 text-emerald-800' :
                      ref.status === 'IN_FREEZE_DRY' ? 'bg-cyan-100 text-cyan-800' :
                      ref.status === 'SOLD' ? 'bg-purple-100 text-purple-800' :
                      ref.status === 'INCIDENT' ? 'bg-rose-100 text-rose-800' :
                      'bg-slate-100 text-slate-800'
                    }`}>
                      {ref.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 truncate max-w-[120px]">
                    {ref.operator || '-'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-500 font-mono text-[10px] tabular-nums">
                    {ref.createdAt ? ref.createdAt.slice(0, 10) : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {onOpenTraceability && (
                        <button
                          type="button"
                          onClick={() => onOpenTraceability(ref)}
                          title="Parti PDF Özeti & Kalite Pasaportu İndir / Yazdır"
                          className="px-2 py-1 rounded bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold text-[10px] flex items-center gap-1 transition cursor-pointer"
                        >
                          <Printer className="w-3 h-3 text-amber-600" />
                          <span>PDF İndir</span>
                        </button>
                      )}
                      {ref.status === 'CREATED' && (
                        <button
                          type="button"
                          onClick={() => onDispatch(ref.refId)}
                          title="Sevkiyat Başlat"
                          className="px-2 py-1 rounded bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-[10px] flex items-center gap-1 transition cursor-pointer"
                        >
                          <Truck className="w-3 h-3" />
                          <span>Sevk</span>
                        </button>
                      )}
                      {ref.status === 'SHIPPED' && (
                        <button
                          type="button"
                          onClick={() => onReceive(ref.refId)}
                          title="Ambar Kabulü Yap"
                          className="px-2 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center gap-1 transition cursor-pointer"
                        >
                          <Warehouse className="w-3 h-3" />
                          <span>Kabul</span>
                        </button>
                      )}
                      {onDeleteReference && (
                        <button
                          type="button"
                          onClick={() => setItemToDelete({ type: 'REFERENCE', id: ref.refId, title: `${ref.refId} (${ref.product})` })}
                          title="Partiyi ve Bağlı Kayıtları Sil"
                          className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 border border-slate-200 transition cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
      )}

      {/* Operation / Reference Deletion Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  {itemToDelete.type === 'REFERENCE' ? 'Parti / Referansı Sil' : 'Kalite Tutanağını Sil'}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {itemToDelete.type === 'REFERENCE'
                    ? 'Bu işlem seçilen partiyi ve sistemdeki ilişkili tüm operasyon kayıtlarını kalıcı olarak silecektir.'
                    : 'Bu işlem seçilen Barlag Akty / DÖF kalite tutanağını listeden kalıcı olarak silecektir.'}
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800">
              Silinecek Kayıt: <span className="font-mono text-teal-700">{itemToDelete.title}</span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="button"
                onClick={() => {
                  if (itemToDelete.type === 'REFERENCE' && onDeleteReference) {
                    onDeleteReference(itemToDelete.id);
                  } else if (itemToDelete.type === 'INCIDENT' && onDeleteIncident) {
                    onDeleteIncident(itemToDelete.id);
                  }
                  setItemToDelete(null);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Evet, Sil</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
