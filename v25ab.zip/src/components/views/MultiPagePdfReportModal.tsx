import React, { useEffect, useState, useMemo } from 'react';
import QRCode from 'qrcode';
import {
  X,
  Printer,
  ExternalLink,
  ShieldCheck,
  FileCheck,
  Split,
  MapPin,
  Camera,
  Layers,
  AlertTriangle,
  Building,
  Calendar,
  CheckCircle2,
  Truck,
  Warehouse,
  Snowflake,
  Globe2,
  ShoppingBag,
  Copy,
  Check,
  QrCode,
  FileText,
  Sparkles,
  Thermometer,
  Droplets,
  Scale,
  Award,
  Info,
  ArrowRight,
  UserCheck,
  History
} from 'lucide-react';
import {
  ReferenceItem,
  HarvestRecord,
  FieldRecord,
  MuzRecord,
  BademRecord,
  LojistikRecord,
  AmbarRecord,
  IncidentRecord,
  FreezeDryRecord,
  ExportSampleRecord,
  SalesRecord,
  STANDARD_QUALITY_CLASSES,
  DataloggerReading
} from '../../types';
import { getAllPhotos, PhotoRecord } from '../../utils/db';
import { BrandLogo } from '../common/BrandLogo';
import { boxNet, sampleTotals, pieceWeightStats, suggestDecision } from '../../utils/intakeCalc';
import { getProductSpec, LOGGER_CONFLICT_WARN_C } from '../../config/productSpecs';

// Reusable 1D Code128 Barcode Visual Component
const ReportBarcodeSVG: React.FC<{ code: string }> = ({ code }) => {
  const cleanCode = (code || 'TR-REF').replace(/[^a-zA-Z0-9-]/g, '');
  return (
    <div className="flex flex-col items-center bg-white px-2 py-1 rounded-xl border border-slate-300 shadow-2xs">
      <svg className="w-28 sm:w-32 h-7" viewBox="0 0 120 28" fill="currentColor">
        <rect x="0" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="4" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="7" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="13" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="17" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="20" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="25" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="29" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="35" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="38" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="43" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="47" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="50" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="56" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="60" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="65" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="68" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="74" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="78" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="81" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="86" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="90" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="96" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="99" y="0" width="3" height="22" fill="#022c22"/>
        <rect x="104" y="0" width="2" height="22" fill="#022c22"/>
        <rect x="108" y="0" width="1" height="22" fill="#022c22"/>
        <rect x="111" y="0" width="4" height="22" fill="#022c22"/>
        <rect x="117" y="0" width="2" height="22" fill="#022c22"/>
      </svg>
      <span className="text-[9px] font-mono font-black tracking-wider text-slate-900 uppercase">
        *{cleanCode}*
      </span>
    </div>
  );
};

// Reusable SVG Sparkline for Datalogger Series
const ReportLoggerSparklineSVG: React.FC<{
  series?: DataloggerReading[];
  upperLimitC?: number;
  lowerLimitC?: number;
}> = ({ series, upperLimitC, lowerLimitC }) => {
  if (!series || series.length === 0) return null;
  const width = 600;
  const height = 120;
  const paddingX = 24;
  const paddingY = 18;

  const temps = series.map(s => s.c);
  let minT = Math.min(...temps);
  let maxT = Math.max(...temps);
  if (upperLimitC !== undefined) maxT = Math.max(maxT, upperLimitC + 0.5);
  if (lowerLimitC !== undefined) minT = Math.min(minT, lowerLimitC - 0.5);
  if (minT === maxT) { minT -= 1; maxT += 1; }

  const scaleX = (idx: number) => paddingX + (idx / Math.max(1, series.length - 1)) * (width - 2 * paddingX);
  const scaleY = (val: number) => height - paddingY - ((val - minT) / (maxT - minT)) * (height - 2 * paddingY);

  const points = series.map((s, idx) => `${scaleX(idx).toFixed(1)},${scaleY(s.c).toFixed(1)}`).join(' ');

  return (
    <div className="bg-slate-900 rounded-lg p-2.5 text-white">
      <div className="flex items-center justify-between text-[10px] text-slate-300 mb-1 px-1">
        <span>Sıcaklık Seyri ({series.length} Nokta)</span>
        <div className="flex items-center gap-3 font-mono">
          <span>Min: <strong className="text-cyan-400">{Math.min(...temps).toFixed(1)}°C</strong></span>
          <span>Maks: <strong className="text-rose-400">{Math.max(...temps).toFixed(1)}°C</strong></span>
          {upperLimitC !== undefined && <span className="text-rose-300">Eşik Üst: {upperLimitC}°C</span>}
          {lowerLimitC !== undefined && <span className="text-cyan-300">Eşik Alt: {lowerLimitC}°C</span>}
        </div>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-28 overflow-visible">
        {upperLimitC !== undefined && (
          <line
            x1={paddingX}
            y1={scaleY(upperLimitC)}
            x2={width - paddingX}
            y2={scaleY(upperLimitC)}
            stroke="#f43f5e"
            strokeDasharray="4 4"
            strokeWidth="1.5"
          />
        )}
        {lowerLimitC !== undefined && (
          <line
            x1={paddingX}
            y1={scaleY(lowerLimitC)}
            x2={width - paddingX}
            y2={scaleY(lowerLimitC)}
            stroke="#06b6d4"
            strokeDasharray="4 4"
            strokeWidth="1.5"
          />
        )}
        <polyline
          fill="none"
          stroke="#10b981"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />
      </svg>
    </div>
  );
};

interface MultiPagePdfReportModalProps {
  isOpen?: boolean;
  reference?: ReferenceItem | null;
  incident?: IncidentRecord | null;
  companyName?: string;
  reportTitle?: string;
  allReferences?: ReferenceItem[];
  harvestRecords?: HarvestRecord[];
  fieldRecords?: FieldRecord[];
  muzRecords?: MuzRecord[];
  bademRecords?: BademRecord[];
  lojistikRecords?: LojistikRecord[];
  ambarRecords?: AmbarRecord[];
  freezeDryRecords?: FreezeDryRecord[];
  exportSampleRecords?: ExportSampleRecord[];
  salesRecords?: SalesRecord[];
  incidentRecords?: IncidentRecord[];
  onClose: () => void;
}

// Reusable Print Photo Gallery Component
const PdfPhotoGrid: React.FC<{ photos?: string[]; title?: string }> = ({
  photos,
  title = "📸 Saha & İşlem Fotoğrafları:"
}) => {
  const [selectedImg, setSelectedImg] = useState<string | null>(null);

  const validPhotos = (photos || []).filter(
    (p) => typeof p === 'string' && p.trim().length > 15
  );

  if (validPhotos.length === 0) return null;

  return (
    <div className="mt-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl break-inside-avoid print:bg-white print:border-slate-300">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-emerald-700 print:text-slate-900" />
          <span className="text-[11px] font-bold text-slate-700 print:text-slate-900">
            {title}
          </span>
        </div>
        <span className="text-[10px] text-slate-500 font-mono font-bold bg-slate-200/70 print:bg-transparent px-1.5 py-0.5 rounded">
          {validPhotos.length} Fotoğraf / Belge
        </span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
        {validPhotos.map((photoUrl, idx) => (
          <div
            key={idx}
            onClick={() => setSelectedImg(photoUrl)}
            className="group relative rounded-lg overflow-hidden border border-slate-200 bg-slate-100 aspect-4/3 min-h-[105px] print:min-h-[120px] print:h-28 break-inside-avoid shadow-2xs print:shadow-none print:border-slate-300 cursor-pointer"
          >
            <img
              src={photoUrl}
              alt={`Fotoğraf ${idx + 1}`}
              loading="eager"
              crossOrigin="anonymous"
              className="w-full h-full object-cover print:object-contain group-hover:scale-105 transition duration-200"
            />
            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition flex items-center justify-center print:hidden">
              <span className="text-[10px] font-bold text-white bg-black/60 px-2 py-0.5 rounded">Büyüt</span>
            </div>
          </div>
        ))}
      </div>

      {selectedImg && (
        <div
          onClick={() => setSelectedImg(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 print:hidden cursor-zoom-out"
        >
          <div className="max-w-3xl max-h-[85vh] bg-white p-2 rounded-2xl shadow-2xl relative" onClick={e => e.stopPropagation()}>
            <img src={selectedImg} alt="Önizleme" className="max-h-[75vh] w-auto rounded-xl object-contain mx-auto" />
            <button
              onClick={() => setSelectedImg(null)}
              className="mt-2 w-full py-2 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              Kapat
            </button>
          </div>
        </div>
      )}
    </div>
  );
};


/** v2.5: Referans durum kodlarının Türkçe karşılığı (PDF'te İngilizce kod görünmesin) */
const REF_STATUS_TR: Record<string, string> = {
  CREATED: 'Oluşturuldu', SHIPPED: 'Sevk edildi', IN_TRANSIT: 'Yolda', RECEIVED: 'Teslim alındı',
  PARTIAL: 'Kısmi', REJECTED: 'Reddedildi', IN_FREEZE_DRY: "Freeze-Dry'da", FREEZE_DRY_COMPLETED: 'Freeze-Dry tamamlandı',
  EXPORT_TESTED: 'İhracat testi yapıldı', SOLD: 'Satıldı', INCIDENT: 'Uygunsuzluk açık', CLOSED: 'Kapandı', COMPLETED: 'Tamamlandı'
};

type CcpVerdict = 'UYGUN' | 'UYGUN DEĞİL' | 'DEĞERLENDİRİLMEDİ' | 'ÖLÇÜM YOK';
interface CcpRow { code: string; title: string; criterion: string; measured: string; tool: string; verdict: CcpVerdict }

/**
 * v2.5: CCP satırları YALNIZCA kayıttaki ölçüm ve tanımlı kriterden değerlendirilir.
 * Kayıt var diye "UYGUN" yazılmaz; kriter tanımlı değilse "DEĞERLENDİRİLMEDİ".
 */
function buildCcpRows(product: string | undefined, harvest: any[], field: any[], lojistik: any[], ambar: any[]): CcpRow[] {
  const spec = getProductSpec(product);
  const tMin = spec?.transportTempMinC ?? null;
  const tMax = spec?.transportTempMaxC ?? null;
  const pre = harvest[0]?.preCoolingHours;
  const transit = lojistik[0]?.transitTemperature;
  const nitrate = field[0]?.nitrateMgKg;
  const nLimit = field[0]?.nitrateLimitMgKg;
  const o2 = ambar[0]?.o2Level;
  const co2 = ambar[0]?.co2Level;
  const has = (v: any) => v !== undefined && v !== null && v !== '';
  return [
    { code: 'CCP-1', title: 'Hasat sonrası ön soğutma', criterion: 'Kriter tanımlı değil (spesifikasyon)',
      measured: has(pre) ? `${pre} saat` : '— (kayıt yok)', tool: 'Saha zaman kaydı',
      verdict: has(pre) ? 'DEĞERLENDİRİLMEDİ' : 'ÖLÇÜM YOK' },
    { code: 'CCP-2', title: 'Taşıma sıcaklığı',
      criterion: tMin != null || tMax != null ? `${tMin ?? '—'} °C … ${tMax ?? '—'} °C (ürün spesifikasyonu)` : 'Kriter tanımlı değil (spesifikasyon)',
      measured: has(transit) ? `${transit} °C` : '— (kayıt yok)', tool: 'Datalogger / termometre',
      verdict: !has(transit) ? 'ÖLÇÜM YOK' : (tMin == null && tMax == null) ? 'DEĞERLENDİRİLMEDİ'
        : ((tMin == null || Number(transit) >= tMin) && (tMax == null || Number(transit) <= tMax)) ? 'UYGUN' : 'UYGUN DEĞİL' },
    { code: 'CCP-3', title: 'Nitrat', criterion: has(nLimit) ? `< ${nLimit} mg/kg (kayıttaki limit)` : 'Kriter tanımlı değil',
      measured: has(nitrate) ? `${nitrate} mg/kg` : '— (test yapılmadı)', tool: 'Nitrat ölçer',
      verdict: !has(nitrate) ? 'ÖLÇÜM YOK' : !has(nLimit) ? 'DEĞERLENDİRİLMEDİ' : (Number(nitrate) <= Number(nLimit) ? 'UYGUN' : 'UYGUN DEĞİL') },
    { code: 'CCP-4', title: 'Kontrollü atmosfer O₂/CO₂', criterion: 'Kriter tanımlı değil (spesifikasyon)',
      measured: has(o2) ? `O₂ %${o2} / CO₂ %${has(co2) ? co2 : '—'}` : '— (kayıt yok)', tool: 'CA oda ölçümü',
      verdict: has(o2) ? 'DEĞERLENDİRİLMEDİ' : 'ÖLÇÜM YOK' }
  ];
}

export const MultiPagePdfReportModal: React.FC<MultiPagePdfReportModalProps> = ({
  isOpen = true,
  reference,
  incident,
  companyName = 'Datly Miwe AGPJ',
  reportTitle = 'Resmi Kalite ve İzlenebilirlik Pasaportu',
  allReferences = [],
  harvestRecords = [],
  fieldRecords = [],
  muzRecords = [],
  bademRecords = [],
  lojistikRecords = [],
  ambarRecords = [],
  freezeDryRecords = [],
  exportSampleRecords = [],
  salesRecords = [],
  incidentRecords = [],
  onClose
}) => {
  const [dbPhotos, setDbPhotos] = useState<PhotoRecord[]>([]);
  const [copied, setCopied] = useState(false);
  const [selectedRefId, setSelectedRefId] = useState<string>(
    reference?.refId || incident?.refId || ''
  );
  // Şablon Seçimi: İzlenebilirlik Pasaportu (Özet 5 Aşama) vs Detaylı Denetim Raporu (Madde 2)
  const [reportTemplate, setReportTemplate] = useState<'TRACEABILITY_PASSPORT' | 'FULL_AUDIT'>('TRACEABILITY_PASSPORT');

  // Sync selected reference if prop changes
  useEffect(() => {
    if (reference?.refId) {
      setSelectedRefId(reference.refId);
    } else if (incident?.refId) {
      setSelectedRefId(incident.refId);
    }
  }, [reference?.refId, incident?.refId]);

  const activeRef = useMemo(() => {
    if (reference && reference.refId === selectedRefId) return reference;
    return allReferences.find((r) => r.refId === selectedRefId) || reference || null;
  }, [reference, selectedRefId, allReferences]);

  const refId = activeRef?.refId || incident?.refId || selectedRefId || '';
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  // Dynamically generate QR code payload pointing directly to this report
  useEffect(() => {
    if (!refId) return;
    const reportUrl = `${window.location.origin}/?ref=${encodeURIComponent(refId)}`;
    QRCode.toDataURL(reportUrl, {
      width: 180,
      margin: 1,
      color: {
        dark: '#022c22',
        light: '#ffffff'
      },
      errorCorrectionLevel: 'M'
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error('Failed to generate QR code for report:', err));
  }, [refId]);

  useEffect(() => {
    // Add class for print isolation & lock body scroll on screen
    document.body.classList.add('pdf-modal-open');
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    // Ensure container is scrolled to the absolute top so Section 1 header is 100% visible
    setTimeout(() => {
      const container = document.querySelector('.pdf-modal-container');
      if (container) {
        container.scrollTop = 0;
      }
      const card = document.querySelector('.pdf-modal-card');
      if (card) {
        card.scrollTop = 0;
      }
    }, 50);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    // Fetch offline/IndexedDB photos for this refId if any
    getAllPhotos()
      .then((photos) => {
        if (incident) {
          const matched = photos.filter(
            (p) =>
              p.refId === incident.incidentId ||
              p.refId === incident.refId ||
              p.refId === incident.actNumber
          );
          setDbPhotos(matched);
        } else if (refId) {
          const matched = photos.filter((p) => p.refId === refId);
          setDbPhotos(matched);
        }
      })
      .catch((err) => console.error('Failed to load photos for PDF report:', err));

    return () => {
      document.body.classList.remove('pdf-modal-open');
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [refId, incident, onClose]);

  if (isOpen === false) return null;

  // Filter and sort related records for this reference
  const refHarvest = harvestRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  const refField = fieldRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  const refMuz = muzRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  const refBadem = bademRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  const refLojistik = lojistikRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || a.shipmentDate || 0).getTime() - new Date(b.timestamp || b.shipmentDate || 0).getTime());

  const refAmbar = ambarRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || a.acceptanceDate || 0).getTime() - new Date(b.timestamp || b.acceptanceDate || 0).getTime());
  // v2.5: CCP yalnızca ölçüm + tanımlı kriterle değerlendirilir
  const ccpRows = buildCcpRows(activeRef?.product, refHarvest as any[], refField as any[], refLojistik as any[], refAmbar as any[]);

  const refFreezeDry = freezeDryRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || a.processDate || 0).getTime() - new Date(b.timestamp || b.processDate || 0).getTime());

  const refExport = exportSampleRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || a.testDate || 0).getTime() - new Date(b.timestamp || b.testDate || 0).getTime());

  const refSales = salesRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.timestamp || a.salesDate || 0).getTime() - new Date(b.timestamp || b.salesDate || 0).getTime());

  const refIncidents = incidentRecords
    .filter((r) => r.refId === refId || (activeRef?.splitLots && activeRef.splitLots.some(sl => sl.subLotId === r.refId)))
    .sort((a, b) => new Date(a.incidentDate || 0).getTime() - new Date(b.incidentDate || 0).getTime());

  // Freeze Dry yönlendirme kontrolü
  const isReroutedToFreezeDry = Boolean(
    activeRef?.reroutedToFreezeDry ||
    activeRef?.rerouteReason ||
    refField.some((f) => f.decision?.includes('Freeze') || f.rejectionReason) ||
    refFreezeDry.length > 0
  );

  // Hedef Tesis
  const finalDestination =
    activeRef?.finalDestination ||
    activeRef?.destination ||
    (isReroutedToFreezeDry
      ? 'Freeze & Dry Liyofilizasyon Tesisi (-40°C Şoklama)'
      : (activeRef ? 'Merkez Soğuk Hava Deposu' : '—'));

  // Bahçe Bilgisi
  const orchardName =
    activeRef?.orchard ||
    refHarvest[0]?.orchard ||
    refField[0]?.orchard ||
    activeRef?.source ||
    '—';

  // All photos aggregated
  const allReferencePhotos = [
    ...(activeRef?.photos || []),
    ...(activeRef?.photoUrl ? [activeRef.photoUrl] : []),
    ...refHarvest.flatMap((h) => h.photos || []),
    ...refField.flatMap((f) => f.photos || []),
    ...refMuz.flatMap((m) => m.photos || []),
    ...refBadem.flatMap((b) => b.photos || []),
    ...refLojistik.flatMap((l) => l.photos || []),
    ...refAmbar.flatMap((a) => a.photos || []),
    ...refFreezeDry.flatMap((fd) => fd.photos || []),
    ...refExport.flatMap((e) => e.photos || []),
    ...refSales.flatMap((s) => s.photos || []),
    ...refIncidents.flatMap((i) => i.photos || []),
    ...dbPhotos.map((p) => p.dataUrl)
  ].filter(
    (p, idx, self) =>
      typeof p === 'string' && p.trim().length > 15 && self.indexOf(p) === idx
  );

  // Print trigger optimized for mobile (iOS Safari / Chrome Android) and desktop
  const handlePrint = async () => {
    try {
      const printableEl = document.getElementById('printable-pdf-document');
      if (!printableEl) {
        window.print();
        return;
      }

      // Ensure all images are loaded before printing
      const images = Array.from(printableEl.querySelectorAll('img'));
      const pendingImages = images.filter((img) => !img.complete);

      if (pendingImages.length > 0) {
        await Promise.race([
          Promise.all(
            pendingImages.map(
              (img) =>
                new Promise<void>((resolve) => {
                  img.onload = () => resolve();
                  img.onerror = () => resolve();
                })
            )
          ),
          new Promise((res) => setTimeout(res, 800))
        ]);
      }

      // Temporarily release modal overflow lock for mobile Safari & Chrome print engines
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'visible';

      setTimeout(() => {
        try {
          window.print();
        } catch (e) {
          console.warn('Print invocation notice:', e);
        } finally {
          // Restore overflow after print dialog closes
          setTimeout(() => {
            document.body.style.overflow = prevOverflow || 'hidden';
          }, 1200);
        }
      }, 150);
    } catch (err) {
      console.warn('Print handler error:', err);
    }
  };

  // Clean print handler (avoids window.open popup blockers on mobile devices)
  const handlePrintClean = () => {
    handlePrint();
  };
  // Copy Summary text
  const handleCopySummary = () => {
    const summaryLines = [
      `====================================================`,
      `MIWE HIL • KALİTE VE İZLENEBİLİRLİK RAPORU`,
      `Parti / RefID: ${refId}`,
      `Ürün / Çeşit: ${activeRef?.product || '-'} (${activeRef?.variety || activeRef?.sortVariety || '-'})`,
      `Miktar: ${activeRef?.quantity || '-'} ${activeRef?.unit || 'kg'}`,
      `Bahçe / Menşei: ${orchardName}`,
      `Hedef Tesis: ${finalDestination}`,
      `Kayıt Tarihi: ${activeRef?.createdAt ? new Date(activeRef.createdAt).toLocaleDateString('tr-TR') : '-'}`,
      `Operatör: ${activeRef?.operator || '-'}`,
      `----------------------------------------------------`,
      `KALİTE TEST VERİLERİ:`,
      refField.length > 0 ? `• Saha Testi: Ort. Brix: %${refField[0].avgBrix} | Sertlik: ${refField[0].avgHardness} kg/cm² | Nitrat: ${refField[0].nitrateMgKg} mg/kg (${refField[0].decision})` : '• Saha Testi: Kayıtlı test verisi yok',
      refMuz.length > 0 ? `• Muz Testi: Kalibre: ${refMuz[0].calibrationMm}mm | Boy: ${refMuz[0].fingerLengthCm}cm | Olgunluk: ${refMuz[0].ripenessScale}/7 (${refMuz[0].qualityStatus})` : '',
      refBadem.length > 0 ? `• Badem Testi: Randıman: %${refBadem[0].kernelYieldPercent} | Nem: %${refBadem[0].moisturePercent} (${refBadem[0].classification})` : '',
      `----------------------------------------------------`,
      `AMBAR GİRİŞ VE SAKLAMA VERİLERİ:`,
      refAmbar.length > 0 ? `• Depo / Oda: ${refAmbar[0].warehouse} (${refAmbar[0].roomNo})` : '• Ambar Girişi: Kayıtlı ambar verisi yok',
      refAmbar.length > 0 ? `• Kabul Kg: ${refAmbar[0].acceptedWeightKg} kg (Beklenen: ${refAmbar[0].expectedWeightKg || '-'} kg)` : '',
      refAmbar.length > 0 ? `• Fire: %${refAmbar[0].weightDiffPercent || 0} (${refAmbar[0].weightDiffKg || 0} kg)` : '',
      refAmbar.length > 0 ? `• Saklama Koşulları: ${refAmbar[0].roomTemperature}°C / %${refAmbar[0].humidityPercent} RH` : '',
      refAmbar.length > 0 ? `• Soğuk Zincir: ${refAmbar[0].coldChainStatus} | Kabul Durumu: ${refAmbar[0].acceptanceStatus}` : '',
      `----------------------------------------------------`,
      `Tarih: ${new Date().toLocaleDateString('tr-TR')}`,
      `====================================================`
    ].filter(Boolean).join('\n');

    const copySuccess = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    };

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(summaryLines).then(copySuccess).catch(() => {
        // Fallback for iframe restrictions
        try {
          const textarea = document.createElement('textarea');
          textarea.value = summaryLines;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          copySuccess();
        } catch (e) {
          console.warn('Clipboard fallback failed:', e);
        }
      });
    } else {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = summaryLines;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        copySuccess();
      } catch (e) {
        console.warn('Clipboard execCommand failed:', e);
      }
    }
  };

  // ==========================================
  // CASE 1: RESMİ BARLAG AKTY (INCIDENT REPORT)
  // ==========================================
  if (incident) {
    const allIncidentPhotos = [
      ...(incident.photos || []),
      ...dbPhotos.map((p) => p.dataUrl)
    ];

    return (
      <div 
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            onClose();
          }
        }}
        className="pdf-modal-container fixed inset-0 z-50 flex flex-col items-center justify-start sm:justify-center p-0 sm:p-4 bg-slate-900/80 backdrop-blur-sm print:static print:p-0 print:bg-white print:overflow-visible"
      >
        <div className="pdf-modal-card bg-white rounded-none sm:rounded-2xl shadow-2xl border-0 sm:border border-slate-200 max-w-4xl w-full h-full sm:h-[92vh] max-h-screen sm:max-h-[92vh] flex flex-col overflow-hidden print:m-0 print:border-none print:shadow-none print:max-w-none print:w-full print:h-auto print:max-h-none print:overflow-visible relative">
          {/* Action Header - fixed at top of modal box */}
          <div className="shrink-0 bg-slate-900 text-white px-3 sm:px-6 py-2.5 sm:py-4 flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-800 print:hidden shadow-md z-40">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-1.5 sm:p-2 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-400/30 shrink-0">
                <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-xs sm:text-base font-bold text-white font-mono truncate">
                    BARLAG AKTY — {incident.incidentId}
                  </h2>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500 text-white">
                    INCIDENT REPORT
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 hidden sm:block">
                  Resmi Kalite Uygunsuzluk & 5-Why Kök Sebep Raporu (PDF Baskı Formatı / Official Report)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 sm:px-4 py-2 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow-md cursor-pointer min-h-[40px]"
                title="Doğrudan Yazdır veya PDF İndir"
              >
                <Printer className="w-4 h-4" />
                <span className="hidden sm:inline">PDF DIŞA AKTAR / YAZDIR</span>
                <span className="sm:hidden">PDF</span>
              </button>

              <button
                onClick={handlePrintClean}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700 cursor-pointer min-h-[40px]"
                title="Yeni Sekmede A4 Yazdır (Temiz Sayfa)"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Yeni Sekmede Aç</span>
              </button>

              <button
                onClick={onClose}
                className="flex items-center gap-1 px-3 sm:px-3.5 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[40px]"
                title="Raporu Kapat"
                aria-label="Raporu Kapat"
              >
                <X className="w-4 h-4" />
                <span>Kapat</span>
              </button>
            </div>
          </div>

          {/* PRINTABLE OFFICIAL ACT */}
          <div
            id="printable-pdf-document"
            className="grow overflow-y-auto overflow-x-hidden p-3.5 sm:p-8 md:p-12 space-y-6 text-slate-800 bg-white print:overflow-visible print:p-0 w-full max-w-full"
          >
            {/* Document Header with Official Logo */}
            <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl overflow-hidden shadow-xs shrink-0 border border-slate-200 bg-white flex items-center justify-center p-1">
                  <BrandLogo size={52} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black text-slate-900 tracking-tight">
                      MIWE HIL
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-rose-100 text-rose-900 font-bold border border-rose-300">
                      BARLAG AKTY
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    Kalite Uygunsuzluk ve Kök Sebep İnceleme Formu
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                {qrCodeDataUrl && (
                  <div className="flex flex-col items-center bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
                    <img src={qrCodeDataUrl} alt="Barlag Akty QR" className="w-12 h-12 object-contain" />
                    <span className="text-[7px] font-mono font-bold text-rose-900 mt-0.5">📱 QR TARA</span>
                  </div>
                )}
                <ReportBarcodeSVG code={incident.actNumber || incident.incidentId || incident.refId} />
                <div className="text-right font-mono hidden sm:block">
                  <div className="text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-1 rounded inline-block mb-1">
                    RESMİ BARLAG AKTY / INCIDENT ACT
                  </div>
                  <p className="text-xs text-slate-600">
                    Akt No: <strong>{incident.actNumber || incident.incidentId}</strong>
                  </p>
                  <p className="text-xs text-slate-600">
                    Tarih / Date:{' '}
                    <strong>{incident.incidentDate || new Date().toISOString().split('T')[0]}</strong>
                  </p>
                </div>
              </div>
            </div>

            {/* General Info Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  RefID / Parti
                </span>
                <strong className="font-mono text-slate-900 text-sm">
                  {incident.refId}
                </strong>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Sapma Türü / Type
                </span>
                <strong className="text-slate-900 text-sm">
                  {incident.incidentType}
                </strong>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Tespit Aşaması
                </span>
                <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded font-bold inline-block">
                  {incident.detectionStage || '—'}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Etkilenen Miktar
                </span>
                <strong className="font-mono text-rose-700 text-sm">
                  {incident.affectedQuantityKg ? `${incident.affectedQuantityKg} kg` : '—'}
                </strong>
              </div>
            </div>

            {/* Incident Details */}
            <div className="space-y-4 text-xs border border-slate-200 rounded-xl p-4">
              <div>
                <h3 className="font-bold text-slate-900 uppercase mb-1">
                  1. Uygunsuzluk / Kusur Açıklaması:
                </h3>
                <p className="text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-100">
                  {incident.description || '—'}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 uppercase mb-1">
                  2. Kök Sebep Analizi (5-Why Root Cause):
                </h3>
                <p className="text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-100">
                  {incident.rootCause || '—'}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 uppercase mb-1">
                  3. Düzeltici ve Önleyici Faaliyet (DÖF / CAPA):
                </h3>
                <p className="text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-100">
                  {incident.correctiveAction || '—'}
                </p>
              </div>
            </div>

            {/* Photos */}
            {allIncidentPhotos.length > 0 && (
              <PdfPhotoGrid
                photos={allIncidentPhotos}
                title="📸 Barlag Akty Tespit & İnceleme Fotoğrafları:"
              />
            )}

            {/* Official Signatures */}
            <div className="pt-6 border-t-2 border-slate-900 grid grid-cols-2 gap-8 text-xs break-inside-avoid">
              <div className="space-y-8">
                <p className="font-bold text-slate-700">Denetçi / Kalite Uzmanı:</p>
                <div className="border-b border-slate-400 pb-1">
                  <p className="font-bold">{incident.operator || '—'}</p>
                  <p className="text-[10px] text-slate-500">Gol / İmza: ___________</p>
                </div>
              </div>
              <div className="space-y-8">
                <p className="font-bold text-slate-700">Hil & Barlag Müdiri:</p>
                <div className="border-b border-slate-400 pb-1">
                  <p className="font-bold">{incident.responsible || '—'}</p>
                  <p className="text-[10px] text-slate-500">Onay: [ MIWE HIL ]</p>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Modal Actions (Hidden in Print) */}
          <div className="shrink-0 p-3.5 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 print:hidden">
            <div className="text-xs text-slate-500 font-medium">
              Barlag Akty Uygunsuzluk Raporu önizlemesi
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={handlePrint}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
              >
                <Printer className="w-4 h-4" />
                <span>Yazdır / PDF İndir</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
              >
                <X className="w-4 h-4" />
                <span>Raporu Kapat</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Floating Quick Action Bar (Thumb-reachable at screen bottom) */}
        <div className="fixed bottom-4 left-3 right-3 z-50 sm:hidden flex items-center justify-between gap-2 p-2 bg-slate-950/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-700/80 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
          >
            <X className="w-4 h-4" />
            <span>Raporu Kapat</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
          >
            <Printer className="w-4 h-4" />
            <span>PDF / Yazdır</span>
          </button>
        </div>
      </div>
    );
  }

  // ========================================================
  // CASE 2: RESMİ KALİTE PASAPORTU & MULTI-PAGE İZLENEBİLİRLİK
  // ========================================================
  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      className="pdf-modal-container fixed inset-0 z-50 flex flex-col items-center justify-start sm:justify-center p-0 sm:p-4 bg-slate-900/80 backdrop-blur-sm print:static print:p-0 print:bg-white print:overflow-visible"
    >
      <div className="pdf-modal-card bg-white rounded-none sm:rounded-2xl shadow-2xl border-0 sm:border border-slate-200 max-w-5xl w-full h-full sm:h-[92vh] max-h-screen sm:max-h-[92vh] flex flex-col overflow-hidden print:m-0 print:border-none print:shadow-none print:max-w-none print:w-full print:h-auto print:max-h-none print:overflow-visible relative">
        
        {/* ================= MODAL CONTROL TOOLBAR (PRINT:HIDDEN) ================= */}
        <div className="shrink-0 bg-slate-950 text-white px-3 sm:px-6 py-2.5 sm:py-3.5 flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-800 print:hidden shadow-md z-40">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 sm:p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 shrink-0">
              <FileCheck className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xs sm:text-base font-bold text-white font-mono truncate">
                  {refId || 'PARTİ RAPORU'}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500 text-slate-950">
                  KALİTE VE İZLENEBİLİRLİK
                </span>
                {activeRef?.product && (
                  <span className="text-xs text-slate-300 font-medium hidden md:inline">
                    ({activeRef.product})
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                A4 PDF Çıktısı • Hasat, Kalite Testleri, Ambar Girişi ve Depolama Takibi
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {/* Şablon Değiştirici: İzlenebilirlik Pasaportu vs Detaylı Denetim Raporu (Madde 2) */}
            <div className="flex items-center p-1 bg-slate-800/90 rounded-xl border border-slate-700/80 shadow-inner">
              <button
                type="button"
                onClick={() => setReportTemplate('TRACEABILITY_PASSPORT')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  reportTemplate === 'TRACEABILITY_PASSPORT'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="Tüm Yaşam Döngüsünü (Hasat -> Test -> Lojistik -> Ambar -> Satış) Özetleyen Şık İzlenebilirlik Pasaportu"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>İzlenebilirlik Pasaportu</span>
              </button>
              <button
                type="button"
                onClick={() => setReportTemplate('FULL_AUDIT')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  reportTemplate === 'FULL_AUDIT'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="Tüm Sayfaları ve Detaylı Veri Tablolarını Gösteren Denetim Raporu"
              >
                <FileText className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Detaylı Rapor</span>
                <span className="sm:hidden">Detay</span>
              </button>
            </div>

            {/* Quick Reference Selector if multiple references are available */}
            {allReferences.length > 1 && (
              <select
                value={selectedRefId}
                onChange={(e) => setSelectedRefId(e.target.value)}
                className="text-xs bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-2.5 py-2 cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500 max-w-[140px] sm:max-w-[160px] truncate"
                title="Başka Bir Referans / Parti Seç"
              >
                {allReferences.map((r) => (
                  <option key={r.refId} value={r.refId}>
                    {r.refId} - {r.product}
                  </option>
                ))}
              </select>
            )}

            <button
              onClick={handleCopySummary}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700 cursor-pointer shadow-xs min-h-[40px]"
              title="Raporun Metin Özetini Panoya Kopyala"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Kopyalandı!' : 'Özeti Kopyala'}</span>
            </button>

            <a
              href="https://drive.google.com/drive/folders/1lFmN0JEvfsd94Z8WT3oeYGxPRLbv2OPa?usp=drive_link"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 text-xs font-bold rounded-xl transition border border-emerald-700/40 cursor-pointer min-h-[40px]"
              title="Drive Resmi Kalite Klasörünü Aç"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-300" />
              <span>Drive Arşivi</span>
            </a>

            {/* Primary Print / Save as PDF Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-extrabold rounded-xl transition shadow-lg cursor-pointer min-h-[40px]"
              title="Yazdır veya PDF Olarak Kaydet (Print / Save as PDF)"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">PDF DIŞA AKTAR / YAZDIR</span>
              <span className="sm:hidden">PDF</span>
            </button>

            <button
              onClick={handlePrintClean}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700 cursor-pointer min-h-[40px]"
              title="Temiz Pencerede Aç & Yazdır"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Yeni Pencerede</span>
            </button>

            <button
              onClick={onClose}
              className="flex items-center gap-1 px-3 sm:px-3.5 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[40px]"
              title="Raporu Kapat"
              aria-label="Raporu Kapat"
            >
              <X className="w-4 h-4" />
              <span>Kapat</span>
            </button>
          </div>
        </div>

        {/* ================= PRINTABLE OFFICIAL REPORT DOCUMENT ================= */}
        <div
          id="printable-pdf-document"
          className="grow overflow-y-auto overflow-x-hidden p-3.5 sm:p-8 md:p-10 space-y-6 sm:space-y-8 bg-white text-slate-900 print:overflow-visible print:p-0 w-full max-w-full"
        >
          {reportTemplate === 'TRACEABILITY_PASSPORT' ? (
            /* ========================================================================= */
            /* ŞABLON: DİJİTAL TARIMSAL İZLENEBİLİRLİK PASAPORTU (TRACEABILITY PASSPORT)  */
            /* Hasat -> Saha Testi -> Lojistik -> Ambar -> Satış Tam Yaşam Döngüsü        */
            /* ========================================================================= */
            <div className="space-y-6 text-slate-900 print-page">
              {/* 1. RESMİ PASAPORT VE SERTİFİKA BAŞLIĞI */}
              <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white rounded-2xl p-4 sm:p-5 shadow-lg border-2 border-emerald-500/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-md shrink-0 border-2 border-emerald-400/50 bg-white flex items-center justify-center p-1.5">
                    <BrandLogo size={58} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                        MIWE HIL
                      </h1>
                      <span className="text-[11px] font-mono font-black px-2.5 py-0.5 rounded-md bg-emerald-500 text-slate-950 uppercase tracking-wider shadow-xs">
                        İzlenebilirlik Pasaportu
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 font-semibold mt-0.5">
                      Uluslararası Tarımsal Kalite, Soğuk Zincir ve Tam Yaşam Döngüsü Pasaportu (Traceability Passport)
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-emerald-300 font-mono mt-1">
                      <span>Platform kayıtlarından üretilmiştir — sertifika belgesi değildir</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0 justify-end bg-slate-900/90 border border-emerald-500/30 rounded-xl p-2.5 shadow-md">
                  {/* Scannable 2D QR Code */}
                  {qrCodeDataUrl && (
                    <div className="flex flex-col items-center bg-white p-1.5 rounded-xl border border-slate-300 shadow-xs">
                      <img src={qrCodeDataUrl} alt="Rapor QR Kodu" className="w-14 h-14 object-contain" />
                      <span className="text-[8px] font-mono font-black text-slate-900 mt-0.5">
                        📱 QR TARA
                      </span>
                    </div>
                  )}

                  {/* Scannable 1D Code128 Barcode */}
                  <ReportBarcodeSVG code={refId} />

                  <div className="font-mono text-xs space-y-0.5 text-right pl-2 border-l border-slate-700 hidden sm:block text-slate-200">
                    <div className="flex items-center justify-between gap-3 text-slate-400 text-[10px]">
                      <span>PASAPORT NO:</span>
                      <strong className="text-white font-mono">TR-PAS-{refId}</strong>
                    </div>
                    <div className="flex items-center justify-between gap-3 text-slate-400 text-[10px]">
                      <span>PARTİ / REFID:</span>
                      <strong className="text-emerald-400 font-mono">{refId}</strong>
                    </div>
                    <div className="flex items-center justify-between gap-3 text-slate-400 text-[10px]">
                      <span>DÜZENLEME:</span>
                      <span className="text-slate-200">{new Date().toLocaleDateString('tr-TR')}</span>
                    </div>
                    <div className="flex items-center justify-between gap-3 text-slate-400 text-[10px]">
                      <span>GLOBAL GTIN:</span>
                      <span className="text-slate-300 font-mono">86800{refId.replace(/\D/g, '').padEnd(6, '9')}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. PARTİ GENEL KİMLİK & MENŞEİ KARTI (BATCH IDENTITY PROFILE) */}
              <div className="bg-gradient-to-br from-slate-50 via-white to-emerald-50/40 border-2 border-emerald-900/30 rounded-2xl p-4.5 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-800" />
                    <span className="text-xs font-black uppercase text-slate-900 tracking-wider">
                      Parti Kimlik ve Menşei Özeti (Batch Origin & Identity)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-md">
                      {refField[0]?.kaliteSinifi || refField[0]?.qualityGrade || refBadem[0]?.kaliteSinifi || (activeRef ? 'Sınıf 1' : '—')}
                    </span>
                    <span className="text-[11px] font-bold text-slate-700 bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono">
                      {activeRef?.status || '—'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Ürün & Çeşit</span>
                    <strong className="text-slate-900 text-sm block truncate">
                      {activeRef?.product || '—'}
                    </strong>
                    <span className="text-[11px] text-slate-600 block truncate">
                      {activeRef?.variety || activeRef?.sortVariety || '—'}
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Menşei & Parsel</span>
                    <strong className="text-slate-900 text-xs block truncate flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>{orchardName}</span>
                    </strong>
                    <span className="text-[11px] text-slate-600 block truncate font-mono">
                      {activeRef?.location || '—'}
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Kayıtlı Net Miktar</span>
                    <strong className="text-slate-900 text-sm font-mono block">
                      {activeRef?.quantity || refHarvest[0]?.dailyTotalKg ? `${activeRef?.quantity || refHarvest[0]?.dailyTotalKg} ${activeRef?.unit || 'kg'}` : '—'}
                    </strong>
                    <span className="text-[11px] text-emerald-700 font-semibold block">
                      {activeRef?.quantity || refHarvest[0]?.dailyTotalKg ? 'Kayıtlı miktar' : '—'}
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Hedef Tesis / Sevk</span>
                    <strong className="text-slate-900 text-xs block truncate">
                      {finalDestination}
                    </strong>
                    <span className="text-[11px] text-slate-500 block truncate">
                      Sorumlu: {activeRef?.operator || refField[0]?.operator || '—'}
                    </span>
                  </div>
                </div>
              </div>

              {/* 3. 5 AŞAMALI YAŞAM DÖNGÜSÜ AKIŞI (5-STAGE LIFECYCLE PATHWAY) */}
              <div className="space-y-3.5">
                <div className="flex items-center justify-between border-b-2 border-slate-900 pb-1.5">
                  <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <span>🔄 5 AŞAMALI TAM YAŞAM DÖNGÜSÜ İZLENEBİLİRLİK YOL HARİTASI</span>
                  </h2>
                  <span className="text-[11px] font-mono font-bold text-slate-500">
                    Hasat ➔ Saha Testi ➔ Lojistik ➔ Ambar ➔ Satış
                  </span>
                </div>

                <div className="space-y-3">
                  {/* AŞAMA 1: HASAT & SAHA TARTIMI */}
                  <div className="bg-emerald-50/50 border border-emerald-300 rounded-2xl p-4 text-xs space-y-2 break-inside-avoid">
                    <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-emerald-700 text-white font-bold flex items-center justify-center text-xs">
                          1
                        </span>
                        <h3 className="font-black text-emerald-950 text-sm">
                          Hasat & Saha Kantar Tartımı (Harvest & Field Weighing)
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        refHarvest.length > 0 ? 'bg-emerald-200 text-emerald-900 border border-emerald-300' : 'bg-slate-200 text-slate-700 border border-slate-300'
                      }`}>
                        {refHarvest.length > 0 ? '✓ TAMAMLANDI' : '⏳ SAHA HASAT KAYDI BEKLENİYOR'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-emerald-200">
                        <span className="text-[10px] text-slate-500 block">Hasat Tarihi:</span>
                        <strong className="text-slate-900 font-mono">
                          {refHarvest[0]?.timestamp?.split('T')[0] || activeRef?.createdAt?.split('T')[0] || '—'}
                        </strong>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-emerald-200">
                        <span className="text-[10px] text-slate-500 block">Kantar Fiş & Lot:</span>
                        <strong className="text-slate-900 font-mono">
                          {refHarvest[0]?.lotNo ? `${refHarvest[0].lotNo} / ${refHarvest[0]?.receiptNo || '—'}` : '—'}
                        </strong>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-emerald-200">
                        <span className="text-[10px] text-slate-500 block">Hasat Edilen Miktar:</span>
                        <strong className="text-emerald-900 font-mono text-sm">
                          {refHarvest[0]?.dailyTotalKg ? `${refHarvest[0].dailyTotalKg} kg` : (activeRef?.quantity ? `${activeRef.quantity} kg` : '—')}
                        </strong>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-emerald-200">
                        <span className="text-[10px] text-slate-500 block">Kasa / Ambalaj & Ekip:</span>
                        <strong className="text-slate-900 block truncate">
                          {refHarvest[0] ? `${(refHarvest[0] as any)?.crateCount ? `${(refHarvest[0] as any).crateCount} Kasa` : 'Standart Ambalaj'}${refHarvest[0]?.foreman ? ` • ${refHarvest[0].foreman}` : ''}` : '—'}
                        </strong>
                      </div>
                    </div>
                    {refHarvest[0]?.notes && (
                      <p className="text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-emerald-200">
                        <strong>Hasat Notu:</strong> {refHarvest[0].notes}
                      </p>
                    )}
                  </div>

                  {/* AŞAMA 2: SAHA KALİTE & OLGUNLUK TESTİ */}
                  <div className="bg-rose-50/50 border border-rose-300 rounded-2xl p-4 text-xs space-y-2 break-inside-avoid">
                    <div className="flex items-center justify-between border-b border-rose-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-rose-700 text-white font-bold flex items-center justify-center text-xs">
                          2
                        </span>
                        <h3 className="font-black text-rose-950 text-sm">
                          Saha Kalite & Olgunluk Laboratuvarı (Quality & Maturity Testing)
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        refField.length > 0 || refMuz.length > 0 || refBadem.length > 0 ? 'bg-rose-200 text-rose-900 border border-rose-300' : 'bg-slate-200 text-slate-700 border border-slate-300'
                      }`}>
                        {refField.length > 0 || refMuz.length > 0 || refBadem.length > 0 ? '✓ TEST YAPILDI' : '⏳ KALİTE TESTİ BEKLENİYOR'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-rose-200">
                        <span className="text-[10px] text-slate-500 block">Şeker (Brix °Bx):</span>
                        <strong className="text-rose-950 font-mono text-sm">
                          {refField[0]?.avgBrix !== undefined ? `${refField[0].avgBrix} °Bx` : refMuz[0]?.avgBrix !== undefined ? `${refMuz[0].avgBrix} °Bx` : '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block">Refraktometre</span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-rose-200">
                        <span className="text-[10px] text-slate-500 block">Meyve Sertliği:</span>
                        <strong className="text-slate-900 font-mono text-sm">
                          {refField[0]?.avgHardness !== undefined ? `${refField[0].avgHardness} kg/cm²` : refMuz[0]?.pulpFirmness !== undefined ? `${refMuz[0].pulpFirmness} kg/cm²` : '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block">Penetrometre</span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-rose-200">
                        <span className="text-[10px] text-slate-500 block">Streif SI / Nişasta:</span>
                        <strong className="text-slate-900 font-mono block">
                          {refField[0]?.streifIndex !== undefined ? `${refField[0].streifIndex.toFixed(3)} SI` : '—'}
                        </strong>
                        <span className="text-[10px] text-emerald-700 block truncate">
                          {refField[0]?.streifInterpretation || '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-rose-200">
                        <span className="text-[10px] text-slate-500 block">Kusur & Standart Kararı:</span>
                        <strong className="text-slate-900 block truncate">
                          {refField[0]?.defectPercent !== undefined ? `Kusur: %${refField[0].defectPercent}` : '—'} • {refField[0]?.qualityStandardOrg || '—'}
                        </strong>
                        <span className="text-[10px] text-emerald-800 font-bold block truncate">
                          {refField[0]?.decision || (refField.length > 0 || refMuz.length > 0 || refBadem.length > 0 ? 'Uygun' : 'Test Yapılmadı')}
                        </span>
                      </div>
                    </div>

                    {/* Muz veya Badem Özel Metrikleri */}
                    {refMuz.length > 0 && (
                      <div className="p-2 bg-white rounded-lg border border-rose-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <span>🍌 <strong>Muz MAP Metrikleri:</strong> Parmak Kalibresi: <strong>{refMuz[0].calibrationMm} mm</strong> · Boy: <strong>{refMuz[0].fingerLengthCm} cm</strong> · Lateks: <strong>{(refMuz[0] as any).latexScore || (refMuz[0].latexStain ? 'Lekeli' : 'Temiz')}</strong></span>
                        <span className="font-bold text-emerald-800">Karar: {refMuz[0].decision || 'Uygun'}</span>
                      </div>
                    )}

                    {refBadem.length > 0 && (
                      <div className="p-2 bg-white rounded-lg border border-rose-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <span>🥜 <strong>Badem Metrikleri:</strong> İç Randıman: <strong>%{refBadem[0].kernelYieldPercent}</strong> · Nem: <strong>%{refBadem[0].moisturePercent}</strong></span>
                        <span className="font-bold text-emerald-800">Sınıf: {refBadem[0].kaliteSinifi || refBadem[0].classification}</span>
                      </div>
                    )}
                  </div>

                  {/* AŞAMA 3: LOJİSTİK & FRİGO SOĞUK ZİNCİR */}
                  <div className="bg-blue-50/50 border border-blue-300 rounded-2xl p-4 text-xs space-y-2 break-inside-avoid">
                    <div className="flex items-center justify-between border-b border-blue-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-blue-700 text-white font-bold flex items-center justify-center text-xs">
                          3
                        </span>
                        <h3 className="font-black text-blue-950 text-sm">
                          Lojistik & Frigofirik Soğuk Zincir (Cold-Chain Logistics)
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        refLojistik.length > 0 ? 'bg-blue-200 text-blue-900 border border-blue-300' : 'bg-slate-200 text-slate-700 border border-slate-300'
                      }`}>
                        {refLojistik.length > 0 ? '✓ SEVKİYAT TAMAMLANDI' : '⏳ LOJİSTİK SEVKİYAT BEKLENİYOR'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-blue-200">
                        <span className="text-[10px] text-slate-500 block">Araç Plaka & Türü:</span>
                        <strong className="text-slate-900 font-mono">
                          {refLojistik[0]?.vehiclePlate || '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block">
                          {refLojistik[0]?.transportType || '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-blue-200">
                        <span className="text-[10px] text-slate-500 block">Şoför & İletişim:</span>
                        <strong className="text-slate-900 block truncate">
                          {refLojistik[0]?.driver || '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 font-mono block">
                          {refLojistik[0]?.driverPhone || '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-blue-200">
                        <span className="text-[10px] text-slate-500 block">Sıcaklık Takibi (°C):</span>
                        <strong className="text-blue-950 font-mono text-sm block">
                          {refLojistik[0] ? `${refLojistik[0].departureTemperature ?? '—'}°C ➔ ${refLojistik[0].transitTemperature ?? '—'}°C` : '—'}
                        </strong>
                        <span className="text-[10px] text-emerald-700 font-bold block">
                          {refLojistik[0] ? 'Kesintisiz Soğuk Zincir' : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-blue-200">
                        <span className="text-[10px] text-slate-500 block">İrsaliye / Delilnama No:</span>
                        <strong className="text-slate-900 font-mono block">
                          {refLojistik[0]?.delilnamaNo || '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block truncate">
                          {refLojistik[0]?.destination || '—'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* AŞAMA 4: AMBAR KABUL & CA/ULO SOĞUK DEPO */}
                  <div className="bg-teal-50/50 border border-teal-300 rounded-2xl p-4 text-xs space-y-2 break-inside-avoid">
                    <div className="flex items-center justify-between border-b border-teal-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-teal-700 text-white font-bold flex items-center justify-center text-xs">
                          4
                        </span>
                        <h3 className="font-black text-teal-950 text-sm">
                          Ambar Kabul & CA/ULO Depolama (Warehouse & CA Cold Storage)
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        refAmbar.length > 0 ? 'bg-teal-200 text-teal-900 border border-teal-300' : 'bg-slate-200 text-slate-700 border border-slate-300'
                      }`}>
                        {refAmbar.length > 0 ? '✓ DEPOYA KABUL EDİLDİ' : '⏳ AMBAR KABUL BEKLENİYOR'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-teal-200">
                        <span className="text-[10px] text-slate-500 block">Depo Tesisi & Oda:</span>
                        <strong className="text-slate-900 block truncate">
                          {refAmbar[0]?.warehouse || '—'}
                        </strong>
                        <span className="text-[10px] font-mono text-teal-800 font-bold block">
                          {refAmbar[0]?.roomNo ? `Oda No: ${refAmbar[0].roomNo}` : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-teal-200">
                        <span className="text-[10px] text-slate-500 block">Kabul Net Ağırlık:</span>
                        <strong className="text-teal-950 font-mono text-sm block">
                          {refAmbar[0]?.acceptedWeightKg ? `${refAmbar[0].acceptedWeightKg} kg` : '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block">
                          {refAmbar[0] ? ((refAmbar[0] as any)?.crateCount ? `${(refAmbar[0] as any).crateCount} Kasa` : (refAmbar[0]?.packaging || 'Kabul Edildi')) : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-teal-200">
                        <span className="text-[10px] text-slate-500 block">Oda İklimlendirme:</span>
                        <strong className="text-slate-900 font-mono text-sm block">
                          {refAmbar[0] ? `${refAmbar[0].roomTemperature ?? '—'}°C • %${refAmbar[0].humidityPercent ?? '—'} Nem` : '—'}
                        </strong>
                        <span className="text-[10px] text-emerald-700 font-semibold block">
                          {refAmbar[0] ? 'Kontrollü Atmosfer (CA)' : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-teal-200">
                        <span className="text-[10px] text-slate-500 block">Tahmini Depo Ömrü:</span>
                        <strong className="text-slate-900 font-mono text-sm block">
                          {(refAmbar[0] as any)?.storagePotentialDays ? `${(refAmbar[0] as any).storagePotentialDays} Gün` : '—'}
                        </strong>
                        <span className="text-[10px] text-teal-800 font-bold block truncate">
                          {(refAmbar[0] as any)?.shelfLifeVerdict || '—'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* AŞAMA 5: TİCARİ SATIŞ VE SEVKİYAT */}
                  <div className="bg-indigo-50/50 border border-indigo-300 rounded-2xl p-4 text-xs space-y-2 break-inside-avoid">
                    <div className="flex items-center justify-between border-b border-indigo-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-indigo-700 text-white font-bold flex items-center justify-center text-xs">
                          5
                        </span>
                        <h3 className="font-black text-indigo-950 text-sm">
                          Ticari Satış & Müşteri Sevkiyatı (Commercial Sales & Customer Dispatch)
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        refSales.length > 0 ? 'bg-indigo-200 text-indigo-900 border border-indigo-300' : 'bg-slate-200 text-slate-700 border border-slate-300'
                      }`}>
                        {refSales.length > 0 ? '✓ SEVKİYAT TAMAMLANDI' : '⏳ MÜŞTERİ SATIŞI BEKLENİYOR'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-indigo-200">
                        <span className="text-[10px] text-slate-500 block">Alıcı Firma / Müşteri:</span>
                        <strong className="text-slate-900 block truncate">
                          {refSales[0]?.customer || '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 block">
                          {(refSales[0] as any)?.deliveryLocation || refSales[0]?.salesChannel || '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-indigo-200">
                        <span className="text-[10px] text-slate-500 block">Fatura / Çıkış Fiş No:</span>
                        <strong className="text-slate-900 font-mono block">
                          {refSales[0]?.invoiceNo || '—'}
                        </strong>
                        <span className="text-[10px] text-slate-500 font-mono block">
                          {refSales[0]?.salesDate ? `Tarih: ${refSales[0].salesDate}` : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-indigo-200">
                        <span className="text-[10px] text-slate-500 block">Sevk Edilen Miktar:</span>
                        <strong className="text-indigo-950 font-mono text-sm block">
                          {refSales[0]?.totalQuantityKg ? `${refSales[0].totalQuantityKg} kg` : '—'}
                        </strong>
                        <span className="text-[10px] text-emerald-700 font-semibold block">
                          {refSales[0] ? 'Tam Parti Çıkışı' : '—'}
                        </span>
                      </div>

                      <div className="p-2 bg-white rounded-lg border border-indigo-200">
                        <span className="text-[10px] text-slate-500 block">Durum & Doğrulama:</span>
                        <strong className="text-slate-900 block">
                          {(refSales[0] as any)?.status || (refSales.length > 0 ? 'SEVKİYAT TAMAMLANDI' : 'Çıkış Yapılmadı')}
                        </strong>
                        <span className="text-[10px] text-emerald-800 font-bold block">
                          {refSales.length > 0 ? '✓ Müşteri Teslim Tesellüm Tamam' : '—'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. KRİTİK KONTROL NOKTALARI (CCP) & SOĞUK ZİNCİR DENETİM GÜNLÜĞÜ */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs space-y-2.5 break-inside-avoid">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                  <h3 className="font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>Kritik Kontrol Noktaları (CCP) & Soğuk Zincir Doğrulama Matrisi</span>
                  </h3>
                  <span className="text-[10px] font-mono text-emerald-800 font-bold bg-emerald-100 px-2 py-0.5 rounded-md">
                    Kayıtlardan · kriter yoksa değerlendirilmez
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-[11px] border-collapse bg-white rounded-xl overflow-hidden shadow-2xs">
                    <thead>
                      <tr className="bg-slate-800 text-white text-[10px] uppercase font-bold text-left">
                        <th className="p-2">Kritik Kontrol Noktası</th>
                        <th className="p-2">Hedef Standart Eşik</th>
                        <th className="p-2">Gerçekleşen Ölçüm</th>
                        <th className="p-2">Denetim Aracı</th>
                        <th className="p-2 text-right">Doğrulama</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {ccpRows.map(row => (
                        <tr key={row.code}>
                          <td className="p-2 font-bold text-slate-900">{row.code}: {row.title}</td>
                          <td className="p-2 text-slate-600">{row.criterion}</td>
                          <td className="p-2 font-mono font-bold text-slate-900">{row.measured}</td>
                          <td className="p-2 text-slate-500">{row.tool}</td>
                          <td className={`p-2 text-right font-bold ${row.verdict === 'UYGUN' ? 'text-emerald-700' : row.verdict === 'UYGUN DEĞİL' ? 'text-rose-700' : 'text-slate-500'}`}>
                            {row.verdict === 'UYGUN' ? '✓ UYGUN' : row.verdict === 'UYGUN DEĞİL' ? '⚠️ UYGUN DEĞİL' : row.verdict}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 5. RESMİ DİJİTAL İMZA, ONAY VE AKREDİTASYON MÜHRÜ */}
              <div className="pt-4 border-t-2 border-slate-900 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs break-inside-avoid">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <UserCheck className="w-4 h-4 text-emerald-700" />
                    <span>Saha Denetim Sorumlusu</span>
                  </div>
                  <div className="border-b-2 border-slate-400 pb-1">
                    <p className="font-bold text-slate-900">{refHarvest[0]?.foreman || refField[0]?.operator || activeRef?.operator || '—'}</p>
                    <p className="text-[10px] text-slate-500">Dijital İmzalandı</p>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono block">Hasat & Saha Testi Onayı</span>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <Warehouse className="w-4 h-4 text-teal-700" />
                    <span>Lojistik & Depo Sorumlusu</span>
                  </div>
                  <div className="border-b-2 border-slate-400 pb-1">
                    <p className="font-bold text-slate-900">{refAmbar[0]?.operator || refLojistik[0]?.driver || '—'}</p>
                    <p className="text-[10px] text-slate-500">Dijital İmzalandı</p>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono block">Soğuk Zincir & Ambar Onayı</span>
                </div>

                <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-300 space-y-4">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-950">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>Kalite Güvence Onayı</span>
                  </div>
                  <div className="border-b-2 border-emerald-400 pb-1">
                    <p className="font-bold text-slate-900">Onay bekliyor</p>
                    <p className="text-[10px] text-slate-500 font-bold">İmza: ___________________</p>
                  </div>
                  <div className="flex items-center justify-between text-[9px] font-mono font-black text-amber-800">
                    <span>[ TASLAK — ONAYLANMADI ]</span>
                    <span>QR: TR-{refId}</span>
                  </div>
                </div>
              </div>

              {/* Bilgilendirme Dipnotu */}
              <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200 text-[10px] text-slate-600 flex flex-wrap items-center justify-between gap-2 font-mono">
                <span>İzlenebilirlik Pasaportu No: TR-PAS-{refId}</span>
                <span>Miwe Hil Tarımsal Kalite ve Soğuk Zincir Yönetim Sistemi tarafından üretilmiştir.</span>
              </div>
            </div>
          ) : (
            /* ========================================================================= */
            /* ŞABLON: DETAYLI DENETİM RAPORU (FULL AUDIT REPORT - ORIGINAL PAGES)         */
            /* ========================================================================= */
            <>
          {/* ========================================================================= */}
          {/* SAYFA 1: ŞİRKET LOGOLU BAŞLIK, PARTİ KİMLİĞİ, ZAMAN ÇİZELGESİ & KALİTE TESTLERİ */}
          {/* ========================================================================= */}
          <div className="space-y-6 pb-6 border-b-2 border-slate-900 print-page">
            
            {/* CORPORATE HEADER */}
            <div className="flex items-start justify-between border-b-2 border-emerald-900 pb-4 gap-4">
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden shadow-xs shrink-0 border border-slate-200 bg-white flex items-center justify-center p-1.5">
                  <BrandLogo size={58} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                      MIWE HIL
                    </span>
                    <span className="text-[10px] sm:text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300 uppercase">
                      Kalite ve İzlenebilirlik Raporu
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    Hasat, Kalite Analizleri, Ambar Girişi ve Depolama Takibi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                {qrCodeDataUrl && (
                  <div className="flex flex-col items-center bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
                    <img src={qrCodeDataUrl} alt="Rapor QR" className="w-12 h-12 object-contain" />
                    <span className="text-[7px] font-mono font-bold text-emerald-900 mt-0.5">📱 QR TARA</span>
                  </div>
                )}
                <ReportBarcodeSVG code={refId} />
                <div className="text-right font-mono shrink-0 hidden sm:block">
                  <span className="px-2.5 py-1 rounded bg-slate-100 text-slate-900 text-xs font-bold block mb-1 border border-slate-200">
                    Parti / RefID: {refId || 'N/A'}
                  </span>
                  <span className="text-[11px] text-slate-600 block">
                    Tarih: <strong>{new Date().toLocaleDateString('tr-TR')}</strong>
                  </span>
                </div>
              </div>
            </div>

            {/* PARTİ GENEL KİMLİK KARTI (REFERENCE PASSPORT SUMMARY) */}
            <div className="bg-slate-50 border-2 border-slate-200 rounded-xl p-4 text-xs shadow-2xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-emerald-700" />
                  <span>1. Parti Kimlik ve Menşei Bilgileri (Batch Identity & Origin)</span>
                </span>
                <span className="font-mono text-xs font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                  RefID: <strong>{refId}</strong>
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">
                    Ürün & Çeşit / Product
                  </span>
                  <strong className="text-slate-900 text-sm block truncate">
                    {activeRef?.product || '—'}
                  </strong>
                  <span className="text-[10px] text-slate-500">
                    {activeRef?.variety || activeRef?.sortVariety || '—'}
                  </span>
                </div>

                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">
                    Kayıtlı Miktar / Qty
                  </span>
                  <strong className="text-slate-900 text-sm font-mono block">
                    {activeRef?.quantity ? `${activeRef.quantity} ${activeRef.unit || 'kg'}` : '—'}
                  </strong>
                  <span className="text-[10px] text-emerald-700 font-semibold">
                    Durum: {REF_STATUS_TR[String(activeRef?.status || '')] || activeRef?.status || '—'}
                  </span>
                </div>

                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">
                    Bahçe / Menşei (Orchard)
                  </span>
                  <strong className="text-slate-900 text-xs flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{orchardName}</span>
                  </strong>
                  <span className="text-[10px] text-slate-500">
                    Lokasyon: {activeRef?.location || '—'}
                  </span>
                </div>

                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">
                    Gideceği Yer (Destination)
                  </span>
                  <strong className="text-slate-900 text-xs block truncate mt-0.5">
                    {finalDestination}
                  </strong>
                  <span className="text-[10px] text-slate-500">
                    Sorumlu: {activeRef?.operator || '—'}
                  </span>
                </div>
              </div>

              {/* Parçalı Sevkiyat Dağılımı (Sub-lots) */}
              {activeRef?.splitLots && activeRef.splitLots.length > 0 && (
                <div className="bg-emerald-50/70 border border-emerald-300 rounded-lg p-3 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                      <Split className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Parçalı Sevkiyat Dağılımı / Split Logistics (Sub-Lots):</span>
                    </span>
                    <span className="text-[10px] font-mono text-emerald-800 font-bold bg-white px-1.5 py-0.5 rounded border border-emerald-200">
                      {activeRef.splitLots.length} Alt Parti
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {activeRef.splitLots.map((sl, idx) => (
                      <div
                        key={idx}
                        className="bg-white p-2 rounded-lg border border-emerald-200 text-[11px] flex items-center justify-between"
                      >
                        <div>
                          <strong className="font-mono text-emerald-900 block">{sl.subLotId}</strong>
                          <span className="text-slate-600 text-[10px] block truncate max-w-[140px]">{sl.destination}</span>
                        </div>
                        <span className="font-mono font-bold text-slate-900 bg-slate-50 px-2 py-0.5 rounded border">
                          {sl.quantityKg} kg
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* KRONOLOJİK YAŞAM DÖNGÜSÜ AKIŞI (LIFECYCLE MILESTONE TIMELINE) */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl break-inside-avoid">
              <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider block mb-2">
                ⏱️ PARTİ İŞLEM VE İZLENEBİLİRLİK ZAMAN ÇİZELGESİ (CHRONOLOGICAL LIFECYCLE)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div className={`p-2 rounded-lg border ${refHarvest.length > 0 ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-white border-slate-200 text-slate-400'}`}>
                  <div className="font-bold flex items-center gap-1">
                    <span>1. Hasat & Tartım</span>
                    {refHarvest.length > 0 && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                  </div>
                  <span className="text-[10px] block font-mono">
                    {refHarvest.length > 0 ? `${refHarvest[0].dailyTotalKg} kg` : 'Beklemede'}
                  </span>
                </div>

                <div className={`p-2 rounded-lg border ${refField.length > 0 || refMuz.length > 0 || refBadem.length > 0 ? 'bg-rose-50 border-rose-300 text-rose-950' : 'bg-white border-slate-200 text-slate-400'}`}>
                  <div className="font-bold flex items-center gap-1">
                    <span>2. Kalite & Test</span>
                    {(refField.length > 0 || refMuz.length > 0 || refBadem.length > 0) && <CheckCircle2 className="w-3 h-3 text-rose-600" />}
                  </div>
                  <span className="text-[10px] block">
                    {refField.length > 0 ? `%${refField[0].avgBrix} Bx` : refMuz.length > 0 ? `${refMuz[0].calibrationMm}mm` : refBadem.length > 0 ? `%${refBadem[0].kernelYieldPercent} Rand.` : 'Beklemede'}
                  </span>
                </div>

                <div className={`p-2 rounded-lg border ${refLojistik.length > 0 ? 'bg-blue-50 border-blue-300 text-blue-950' : 'bg-white border-slate-200 text-slate-400'}`}>
                  <div className="font-bold flex items-center gap-1">
                    <span>3. Lojistik & Frigo</span>
                    {refLojistik.length > 0 && <CheckCircle2 className="w-3 h-3 text-blue-600" />}
                  </div>
                  <span className="text-[10px] block font-mono truncate">
                    {refLojistik.length > 0 ? `${refLojistik[0].vehiclePlate}` : 'Beklemede'}
                  </span>
                </div>

                <div className={`p-2 rounded-lg border ${refAmbar.length > 0 ? 'bg-teal-50 border-teal-300 text-teal-950' : 'bg-white border-slate-200 text-slate-400'}`}>
                  <div className="font-bold flex items-center gap-1">
                    <span>4. Ambar & Soğuk Oda</span>
                    {refAmbar.length > 0 && <CheckCircle2 className="w-3 h-3 text-teal-600" />}
                  </div>
                  <span className="text-[10px] block font-mono truncate">
                    {refAmbar.length > 0 ? `${refAmbar[0].warehouse} (${refAmbar[0].roomNo})` : 'Beklemede'}
                  </span>
                </div>
              </div>
            </div>

            {/* 1. KRONOLOJİK ADIM: HASAT VERİLERİ (DAILY HARVEST) */}
            {refHarvest.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-emerald-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <span>🌿 1. AŞAMA: GÜNLÜK HASAT & TARTIM VERİLERİ (DAILY HARVEST)</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">
                    {refHarvest.length} Kayıt Bulundu
                  </span>
                </h3>

                {refHarvest.map((h) => {
                  // İlgili Saha / Meyve Testini Keşfet (RefId, PreHarvestRef, Notlar veya Bahçe/Ürün Eşleşmesi)
                  const linkedFieldTest = fieldRecords.find(
                    (f) =>
                      f.refId === h.refId ||
                      (h.notes && h.notes.includes(f.refId)) ||
                      (f.orchard && h.orchard && f.orchard === h.orchard && f.product === h.product)
                  );

                  return (
                    <div
                      key={h.id}
                      className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-2.5 break-inside-avoid"
                    >
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Bahçe / Sektör:</span>
                          <strong className="text-slate-900">
                            {h.orchard || (orchardName !== '—' ? orchardName : '—')}{h.sector ? ` (${h.sector})` : ''}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Lot & Kantar Fiş No:</span>
                          <strong className="font-mono text-slate-900">
                            {h.lotNo} / {h.receiptNo || '-'}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Günlük Hasat Miktarı:</span>
                          <strong className="font-mono text-emerald-800 text-sm">
                            {h.dailyTotalKg} kg
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">İşçi & Çavuş / Foreman:</span>
                          <strong className="text-slate-900">
                            {h.workerCount ? `${h.workerCount} Kişi` : '-'} {h.foreman ? `(${h.foreman})` : ''}
                          </strong>
                        </div>
                      </div>

                      {/* BAĞLI MEYVE TESTİ BİLGİ KARTI (Hasat Öncesi / Sevkiyat Öncesi Test Sonuçları) */}
                      {linkedFieldTest && (
                        <div className="mt-2 bg-gradient-to-r from-amber-50/90 via-emerald-50/70 to-teal-50/90 border border-amber-300 rounded-xl p-3 text-xs space-y-2 break-inside-avoid shadow-2xs">
                          <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-amber-200/80 pb-1.5">
                            <span className="font-extrabold text-amber-950 flex items-center gap-1.5 text-[11px]">
                              <span>🍎 Bağlı Meyve Testi / Fruit Test:</span>
                              <span className="font-mono px-2 py-0.5 rounded bg-amber-200/80 text-amber-900 text-[10px]">
                                {linkedFieldTest.refId}
                              </span>
                              <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                {linkedFieldTest.testType || 'Hasattan Önce'}
                              </span>
                            </span>
                            <span className="text-[10px] text-slate-600 font-mono">
                              Tarih: {linkedFieldTest.timestamp ? linkedFieldTest.timestamp.split('T')[0] : linkedFieldTest.harvestDate}
                            </span>
                          </div>

                          {/* Ağırlık, Gramaj, Brix ve Sertlik */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                            <div className="bg-white/90 p-1.5 rounded-lg border border-amber-200">
                              <span className="text-slate-500 text-[10px] block">Ort. Meyve Gramajı:</span>
                              <strong className="font-mono text-amber-950 text-xs">
                                {linkedFieldTest.avgFruitWeightG ? `${linkedFieldTest.avgFruitWeightG} g/meyve` : '-'}
                              </strong>
                              {linkedFieldTest.testSampleWeightKg && (
                                <span className="text-[9px] text-slate-500 block font-mono">
                                  Test: {linkedFieldTest.testSampleWeightKg} kg ({linkedFieldTest.fruitCountSampled || linkedFieldTest.sampleCount || 5} adet)
                                </span>
                              )}
                            </div>

                            <div className="bg-white/90 p-1.5 rounded-lg border border-amber-200">
                              <span className="text-slate-500 text-[10px] block">Şeker / Brix & Sertlik:</span>
                              <strong className="font-mono text-emerald-800 text-xs">
                                %{linkedFieldTest.avgBrix?.toFixed(1)}°Bx | {linkedFieldTest.avgHardness?.toFixed(2)} kg/cm²
                              </strong>
                            </div>

                            <div className="bg-white/90 p-1.5 rounded-lg border border-amber-200">
                              <span className="text-slate-500 text-[10px] block">Nitrat & Kusur:</span>
                              <strong className="text-xs font-mono">
                                {linkedFieldTest.hasNitrateTest && linkedFieldTest.nitrateMgKg !== undefined
                                  ? `${linkedFieldTest.nitrateMgKg} mg/kg (${linkedFieldTest.nitratePass ? 'Uygun ✓' : 'Aşım ✗'})`
                                  : 'Nitrat: Ölçülmedi (Opsiyonel)'}
                              </strong>
                              {linkedFieldTest.hasDefectTest && linkedFieldTest.defectPercent !== undefined && (
                                <span className="text-[9px] text-slate-600 block">
                                  Kusur: %{linkedFieldTest.defectPercent}
                                </span>
                              )}
                            </div>

                            <div className="bg-white/90 p-1.5 rounded-lg border border-amber-200">
                              <span className="text-slate-500 text-[10px] block">Kalite Sınıfı & Karar:</span>
                              <strong className="text-xs text-slate-900 block truncate">
                                {linkedFieldTest.kaliteSinifi || linkedFieldTest.qualityGrade || 'Standart Sınıf'}
                              </strong>
                              <span className="text-[10px] font-semibold text-emerald-800 truncate block">
                                {linkedFieldTest.decision || 'Hasada Uygun'}
                              </span>
                            </div>
                          </div>

                          {/* Streif İndeksi veya Özel Ürün Testi */}
                          {(linkedFieldTest.streifIndex !== undefined || linkedFieldTest.specialCropTest) && (
                            <div className="bg-white/90 p-2 rounded-lg border border-amber-200 text-[10px] flex flex-wrap items-center justify-between gap-2">
                              {linkedFieldTest.streifIndex !== undefined && (
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-indigo-950">🧪 Streif Olgunluk İndeksi:</span>
                                  <span className="px-1.5 py-0.5 bg-indigo-700 text-white rounded font-mono font-bold">
                                    SI: {linkedFieldTest.streifIndex.toFixed(3)}
                                  </span>
                                  {linkedFieldTest.streifInterpretation && (
                                    <span className="text-slate-700 font-medium">({linkedFieldTest.streifInterpretation})</span>
                                  )}
                                </div>
                              )}
                              {linkedFieldTest.specialCropTest && (
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-teal-950">🌾 {linkedFieldTest.specialCropTest.cropNameTr}:</span>
                                  <span className="text-slate-800 font-mono">
                                    {linkedFieldTest.specialCropTest.metric1Name}: {linkedFieldTest.specialCropTest.metric1Value}{linkedFieldTest.specialCropTest.metric1Unit || ''}
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-teal-100 text-teal-900 font-bold text-[9px]">
                                    {linkedFieldTest.specialCropTest.interpretation}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {h.notes && (
                        <p className="text-[11px] text-slate-600 bg-white p-2 rounded border border-slate-200">
                          <strong>Hasat Notu:</strong> {h.notes}
                        </p>
                      )}

                      {/* Varsa Delilnama Koçanı */}
                      {h.delilnama && (
                        <div className="mt-2 bg-white border border-slate-300 rounded-lg p-3 text-xs break-inside-avoid">
                          <div className="flex items-center justify-between border-b pb-1.5 mb-2 font-mono">
                            <span className="font-bold text-slate-900">
                              DELILNAMA №: <strong className="text-rose-700">{h.delilnama.delilnamaNo}</strong>
                            </span>
                            <span className="text-slate-500 text-[11px]">Sene: {h.delilnama.sene}</span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] mb-2">
                            <div><span className="text-slate-500">Ýeri:</span> <strong>{h.delilnama.yeri}</strong></div>
                            <div><span className="text-slate-500">Miwe:</span> <strong>{h.delilnama.miwe}</strong></div>
                            <div><span className="text-slate-500">Miwe görnüşi:</span> <strong>{h.delilnama.miweGornusi}</strong></div>
                            <div><span className="text-slate-500">Jemi Hasyl Net:</span> <strong className="font-mono text-emerald-800">{h.delilnama.jemiNetKg} kg</strong></div>
                          </div>
                        </div>
                      )}

                      <PdfPhotoGrid photos={h.photos} title="📸 Hasat & Saha Tartım Fotoğrafları:" />
                    </div>
                  );
                })}
              </div>
            )}

            {/* 2. KRONOLOJİK ADIM: KALİTE VE LABORATUVAR TEST SONUÇLARI */}
            <div className="space-y-3 break-inside-avoid">
              <h3 className="text-xs font-black uppercase tracking-wider text-rose-900 flex items-center justify-between border-b pb-1">
                <span className="flex items-center gap-1.5">
                  <span>🔬 2. AŞAMA: KALİTE VE LABORATUVAR TEST SONUÇLARI (QUALITY TEST RESULTS)</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">
                  Saha ve laboratuvar ölçümleri
                </span>
              </h3>

              {/* SAHA MEYVE TESTLERİ */}
              {refField.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    🍎 Saha Meyve Kalite Analizi (Brix, Sertlik, Ağırlık/Gramaj & Kimyasal Analiz):
                  </span>
                  {refField.map((f) => (
                    <div
                      key={f.id}
                      className="bg-rose-50/40 border border-rose-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                    >
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Test Türü & Aşaması:</span>
                          <strong className="text-rose-950 font-bold">{f.testType || 'Hasattan Önce'}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Ortalama Şeker / Brix:</span>
                          <strong className="font-mono text-amber-800 text-sm">
                            %{f.avgBrix?.toFixed(1)} °Bx
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Ortalama Sertlik:</span>
                          <strong className="font-mono text-slate-900 text-sm">
                            {f.avgHardness?.toFixed(2)} kg/cm²
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Tek Meyve Gramajı & Test Kg:</span>
                          <strong className="font-mono text-amber-950 text-sm">
                            {f.avgFruitWeightG ? `${f.avgFruitWeightG} g` : '-'}
                          </strong>
                          {f.testSampleWeightKg && (
                            <span className="text-[9px] text-slate-500 block font-mono">
                              Numune Toplamı: {f.testSampleWeightKg} kg ({(f.testSampleWeightKg * 1000).toFixed(0)}g)
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-rose-100 text-[11px]">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Ort. Meyve Çapı:</span>
                          <strong className="font-mono">{f.avgDiameter?.toFixed(1)} mm</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Nitrat Analizi:</span>
                          <strong className={`font-mono ${f.hasNitrateTest ? (f.nitratePass ? 'text-emerald-700' : 'text-rose-700') : 'text-slate-600'}`}>
                            {f.hasNitrateTest && f.nitrateMgKg !== undefined
                              ? `${f.nitrateMgKg} mg/kg (${f.nitratePass ? 'UYGUN' : 'LİMİT ÜSTÜ'})`
                              : 'Sahada Ölçülmedi (Opsiyonel)'}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Kusur % & Kalite Sınıfı:</span>
                          <strong className="text-emerald-800">
                            {f.hasDefectTest && f.defectPercent !== undefined ? `Kusur: %${f.defectPercent} | ` : ''}
                            {f.hasQualityGrade && (f.kaliteSinifi || f.qualityGrade) ? (f.kaliteSinifi || f.qualityGrade) : 'Belirlenmedi'}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Karar & Sonraki Adım:</span>
                          <strong className="text-slate-900">{f.decision || 'Hasada Uygun'}</strong>
                        </div>
                      </div>

                      {/* Nişasta & Streif İndeksi (SI) Hasat Değerlendirmesi */}
                      {(f.starchIndex !== undefined || f.streifIndex !== undefined) && (
                        <div className="bg-indigo-50/70 border border-indigo-200 rounded-lg p-2 text-[11px] flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-indigo-950">🧪 Streif Olgunluk İndeksi (SI):</span>
                            {f.streifIndex !== undefined && (
                              <span className="px-2 py-0.5 bg-indigo-700 text-white rounded font-mono font-bold">
                                SI: {f.streifIndex.toFixed(3)}
                              </span>
                            )}
                            {f.starchIndex !== undefined && (
                              <span className="px-2 py-0.5 bg-white border border-indigo-200 text-indigo-900 rounded font-mono font-bold">
                                Nişasta: {f.starchIndex.toFixed(1)} / 10
                              </span>
                            )}
                          </div>
                          {f.streifInterpretation && (
                            <span className="text-[10px] font-semibold text-indigo-900">
                              {f.streifInterpretation}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Özel Pomolojik Ürün Testi */}
                      {f.specialCropTest && (
                        <div className="bg-teal-50/70 border border-teal-200 rounded-lg p-2 text-[11px] flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-teal-950">🌾 {f.specialCropTest.cropNameTr} Özel Testi:</span>
                            <span className="px-2 py-0.5 bg-white border border-teal-300 text-teal-950 rounded font-mono font-bold">
                              {f.specialCropTest.metric1Name}: {f.specialCropTest.metric1Value}{f.specialCropTest.metric1Unit || ''}
                            </span>
                            {f.specialCropTest.metric2Name && (
                              <span className="px-2 py-0.5 bg-white border border-teal-300 text-teal-950 rounded font-mono font-bold">
                                {f.specialCropTest.metric2Name}: {f.specialCropTest.metric2Value}{f.specialCropTest.metric2Unit || ''}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-bold text-teal-900">
                            {f.specialCropTest.interpretation}
                          </span>
                        </div>
                      )}

                      {/* Laboratuvar Numune Ölçümleri */}
                      {f.samples && f.samples.length > 0 && (
                        <div className="bg-white p-2 rounded-lg border border-rose-200 overflow-x-auto">
                          <span className="text-[10px] font-bold text-slate-600 block mb-1">
                            Ölçülen {f.samples.length} Numune Detayı:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {f.samples.map((s, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-0.5 bg-rose-50/70 border border-rose-200 rounded text-[10px] font-mono"
                              >
                                #{s.sample}: {s.hardness} kg/cm² | {s.brix}°Bx | {s.diameterMm}mm{s.weightG ? ` | ${s.weightG}g` : ''}{s.starch !== undefined ? ` | Nişasta: ${s.starch}` : ''}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      <PdfPhotoGrid photos={f.photos} title="📸 Saha Meyve Kalite ve Laboratuvar Test Fotoğrafları:" />
                    </div>
                  ))}
                </div>
              )}

              {/* MUZ KALİTE TESTLERİ (BANANA QUALITY) */}
              {refMuz.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    🍌 Muz Kalite Standartları Testi:
                  </span>
                  {refMuz.map((m) => (
                    <div
                      key={m.id}
                      className="bg-amber-50/50 border border-amber-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                    >
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Hasat Kurdelesi & Yaş:</span>
                          <strong>{m.ribbonColor} ({m.harvestAgeWeeks || m.bloomWeek || '-'} Hafta)</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Kalibrasyon / Çap:</span>
                          <strong className="font-mono text-amber-900">{m.calibrationMm} mm</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Parmak Boyu:</span>
                          <strong className="font-mono">{m.fingerLengthCm} cm</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Olgunluk Skalası (1-7):</span>
                          <strong className="text-emerald-700 font-mono">{m.ripenessScale} / 7 ({m.qualityStatus})</strong>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-amber-100 text-[11px]">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Tarak Başı Parmak:</span>
                          <strong className="font-mono">{m.fingerCountPerHand} Adet</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Meyve Sıcaklığı:</span>
                          <strong className="font-mono">{m.pulpTemperatureC ? `${m.pulpTemperatureC}°C` : '-'}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Şeker Oranı (Brix):</span>
                          <strong className="font-mono">{m.brix || m.avgBrix ? `%${m.brix || m.avgBrix}` : '-'}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">MAP & Gazlama:</span>
                          <strong>{m.mapPackaging ? 'MAP Vakum' : 'Standart'} ({m.gasStatus})</strong>
                        </div>
                      </div>

                      <PdfPhotoGrid photos={m.photos} title="📸 Muz Kalite ve Parmak Boyu Fotoğrafları:" />
                    </div>
                  ))}
                </div>
              )}

              {/* BADEM KALİTE TESTLERİ (ALMOND QUALITY) */}
              {refBadem.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    🥜 Badem Kalite, Nem & İç Randıman Testi:
                  </span>
                  {refBadem.map((b) => (
                    <div
                      key={b.id}
                      className="bg-orange-50/50 border border-orange-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                    >
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Çeşit & Lokasyon:</span>
                          <strong>{b.variety} ({b.location})</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">İç Randıman (Kernel Yield):</span>
                          <strong className="font-mono text-orange-900 text-sm">%{b.kernelYieldPercent}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Tane Nemi %:</span>
                          <strong className="font-mono text-slate-900">%{b.moisturePercent}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Aflatoksin Analizi:</span>
                          <strong className="text-emerald-700">{b.aflatoxinTest || 'Negatif (<2 ppb)'}</strong>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-orange-100 text-[11px]">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Ağaç Açılma %:</span>
                          <strong className="font-mono">%{b.hullSplitPercent || '-'}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Numune / İç Gramajı:</span>
                          <strong className="font-mono">{b.sampleGram}g &rarr; {b.kernelGram}g İç</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Toplam Kusur %:</span>
                          <strong className="font-mono text-rose-700">%{b.totalDefectPercent}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Kalite Sınıfı:</span>
                          <strong className="text-emerald-800">{b.classification}</strong>
                        </div>
                      </div>

                      <PdfPhotoGrid photos={b.photos} title="📸 Badem Randıman ve Kusur Fotoğrafları:" />
                    </div>
                  ))}
                </div>
              )}

              {refField.length === 0 && refMuz.length === 0 && refBadem.length === 0 && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs italic">
                  Bu parti için henüz saha veya laboratuvar kalite testi kaydı girilmemiştir.
                </div>
              )}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* SAYFA 2: AMBAR GİRİŞİ, SOĞUK DEPO VE FRİGORİFİK LOJİSTİK AKIŞI */}
          {/* ========================================================================= */}
          <div className="space-y-6 pb-6 border-b-2 border-slate-900 print-page">
            
            {/* Running Header for Page 2 */}
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <BrandLogo size={24} />
                <h2 className="text-sm font-black uppercase tracking-tight text-emerald-950">
                  SAYFA 2: AMBAR GİRİŞ VERİLERİ, SOĞUK HAVA DEPOSU & LOJİSTİK AKIŞI
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">RefID: <strong>{refId}</strong></span>
            </div>

            {/* ========================================================================= */}
            {/* 4. AŞAMA: AMBAR VE SOĞUK DEPO GİRİŞ VERİLERİ (ÖZEL VURGULANMIŞ BÖLÜM) */}
            {/* ========================================================================= */}
            <div className="space-y-3 break-inside-avoid">
              <div className="flex items-center justify-between border-b-2 border-teal-800 pb-1.5">
                <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-teal-950 flex items-center gap-2">
                  <Warehouse className="w-4 h-4 sm:w-5 sm:h-5 text-teal-700" />
                  <span>🏭 AMBAR VE SOĞUK DEPO GİRİŞ VERİLERİ (WAREHOUSE INBOUND & STORAGE)</span>
                </h3>
                <span className="text-[10px] font-bold bg-teal-100 text-teal-900 px-2 py-0.5 rounded border border-teal-300">
                  Kantar & Soğuk Oda Kaydı
                </span>
              </div>

              {refAmbar.length > 0 ? (
                refAmbar.map((a) => (
                  <div
                    key={a.id}
                    className="bg-teal-50/40 border-2 border-teal-200 rounded-xl p-4 text-xs space-y-3.5 break-inside-avoid shadow-2xs"
                  >
                    {/* Ambar Kabul Başlık Parametreleri */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3 rounded-lg border border-teal-100">
                      <div>
                        <span className="text-slate-500 text-[10px] font-bold block uppercase">
                          Kabul Eden Ambar / Tesis:
                        </span>
                        <strong className="text-slate-900 text-sm flex items-center gap-1 mt-0.5">
                          <Building className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                          <span>{a.warehouse}</span>
                        </strong>
                        <span className="text-[10px] text-slate-500 block">
                          Hücre / Oda: <strong>{a.roomNo}</strong>
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] font-bold block uppercase">
                          Kabul Tarihi & Saati:
                        </span>
                        <strong className="font-mono text-slate-900 text-sm block mt-0.5">
                          {a.acceptanceDate ? new Date(a.acceptanceDate).toLocaleDateString('tr-TR') : new Date().toLocaleDateString('tr-TR')}
                        </strong>
                        <span className="text-[10px] text-slate-500">
                          Sorumlu: {a.operator || '-'}
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] font-bold block uppercase">
                          Kantar Kabul Ağırlığı:
                        </span>
                        <strong className="font-mono text-teal-900 text-sm block mt-0.5">
                          {a.acceptedWeightKg} kg Net
                        </strong>
                        <span className="text-[10px] text-slate-500">
                          Gelen / Beklenen: {a.expectedWeightKg ? `${a.expectedWeightKg} kg` : '-'}
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] font-bold block uppercase">
                          Fire / Çekme Analizi:
                        </span>
                        <strong className="font-mono text-amber-800 text-sm block mt-0.5">
                          %{a.weightDiffPercent || 0} ({a.weightDiffKg || 0} kg)
                        </strong>
                        <span className="text-[10px] text-slate-500">
                          Kabul Durumu: <strong className="text-emerald-700">{a.acceptanceStatus}</strong>
                        </span>
                      </div>
                    </div>

                    {/* İklimlendirme ve Soğuk Saklama Şartları */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-teal-100/40 p-3 rounded-lg border border-teal-200 text-[11px]">
                      <div>
                        <span className="text-slate-600 text-[10px] font-bold flex items-center gap-1">
                          <Thermometer className="w-3 h-3 text-blue-600" />
                          <span>Oda Sıcaklığı:</span>
                        </span>
                        <strong className="font-mono text-slate-900 text-xs">
                          {a.roomTemperature}°C
                        </strong>
                      </div>

                      <div>
                        <span className="text-slate-600 text-[10px] font-bold flex items-center gap-1">
                          <Droplets className="w-3 h-3 text-cyan-600" />
                          <span>Bağıl Nem (% RH):</span>
                        </span>
                        <strong className="font-mono text-slate-900 text-xs">
                          %{a.humidityPercent} RH
                        </strong>
                      </div>

                      <div>
                        <span className="text-slate-600 text-[10px] font-bold flex items-center gap-1">
                          <Thermometer className="w-3 h-3 text-amber-600" />
                          <span>Ürün İç Sıcaklığı:</span>
                        </span>
                        <strong className="font-mono text-slate-900 text-xs">
                          {a.productTemperature}°C
                        </strong>
                      </div>

                      <div>
                        <span className="text-slate-600 text-[10px] font-bold flex items-center gap-1">
                          <Layers className="w-3 h-3 text-teal-600" />
                          <span>CO2 / Gaz Seviyesi:</span>
                        </span>
                        <strong className="font-mono text-slate-900 text-xs">
                          {a.co2GasLevelPpm ? `${a.co2GasLevelPpm} ppm` : 'Optimal'}
                        </strong>
                      </div>
                    </div>

                    {/* Koruma & Uygulama Bilgileri */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-white p-2.5 rounded-lg border border-teal-100 text-[11px]">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Uygulanan Koruma / Muhafaza:</span>
                        <strong className="text-teal-950">{a.treatmentApplied || 'Standart Ön Soğutma'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Soğuk Zincir Durumu:</span>
                        <strong className={`font-bold ${a.coldChainStatus === 'Uygun' ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {a.coldChainStatus}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Depo Hijyen / Sanitize:</span>
                        <strong className="text-emerald-700">{a.hygieneStatus}</strong>
                      </div>
                    </div>

                    {a.notes && (
                      <p className="text-[11px] text-slate-700 bg-white p-2.5 rounded border border-teal-100">
                        <strong>Ambar Kabul Notu:</strong> {a.notes}
                      </p>
                    )}

                    {/* Ambar Kabul Fotoğrafları */}
                    <PdfPhotoGrid
                      photos={a.photos}
                      title="📸 Ambar Kabul, Kantar Fişi & Soğuk Oda Fotoğrafları:"
                    />
                  </div>
                ))
              ) : (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs text-center">
                  Bu referans için henüz kaydedilmiş ambar kabul veya soğuk depo kaydı bulunmamaktadır.
                </div>
              )}
            </div>

            {/* ========================================================================= */}
            {/* 5. AŞAMA: KABUL MUTABAKATI & KANTAR TARTIMI (INTAKE RECONCILIATION) */}
            {/* ========================================================================= */}
            {refAmbar.some(a => a.countryOfOrigin || a.declaredPallets !== undefined || a.weighbridgeNetKg !== undefined) && (
              <div className="space-y-2 break-inside-avoid print-page-break">
                <div className="flex items-center justify-between border-b-2 border-emerald-800 pb-1.5">
                  <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-emerald-950 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-700" />
                    <span>5. KABUL MUTABAKATI & KANTAR TARTIMI (INTAKE RECONCILIATION)</span>
                  </h3>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded border border-emerald-300">
                    Resmi Giriş Mutabakatı
                  </span>
                </div>

                {refAmbar.map((a) => (
                  <div key={`recon-${a.id}`} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-white p-2.5 rounded-lg border border-slate-200">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Kabul Rapor No:</span>
                        <strong className="text-emerald-800 font-mono text-xs">{a.intakeReportNo || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Menşei / Marka:</span>
                        <strong className="text-slate-900 text-xs">
                          {a.countryOfOrigin || 'Türkiye'}{a.brand ? ` • ${a.brand}` : ''}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Palet Sayımı (Beyan / Fiili):</span>
                        <strong className="font-mono text-slate-900 text-xs">
                          {a.declaredPallets ?? '—'} / {a.receivedPallets ?? '—'}
                        </strong>
                        {a.declaredPallets !== undefined && a.receivedPallets !== undefined && a.declaredPallets !== a.receivedPallets && (
                          <span className="text-[10px] text-rose-600 font-bold block">
                            Fark: {a.receivedPallets - a.declaredPallets} palet
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Kutu Sayımı (Beyan / Fiili):</span>
                        <strong className="font-mono text-slate-900 text-xs">
                          {a.declaredBoxes ?? '—'} / {a.receivedBoxes ?? '—'}
                        </strong>
                        {a.declaredBoxes !== undefined && a.receivedBoxes !== undefined && a.declaredBoxes !== a.receivedBoxes && (
                          <span className="text-[10px] text-rose-600 font-bold block">
                            Fark: {a.receivedBoxes - a.declaredBoxes} kutu
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Hasarlı Sayım (Palet / Kutu):</span>
                        <strong className="font-mono text-rose-700 text-xs">
                          {a.damagedPallets ?? 0} Palet / {a.damagedBoxes ?? 0} Kutu
                        </strong>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-2.5 rounded-lg border border-slate-200">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Kantar Tartımı (Brüt / Dara / Net):</span>
                        <div className="flex items-center gap-3 font-mono text-xs mt-0.5">
                          <span>Brüt: <strong>{a.weighbridgeGrossKg ? `${a.weighbridgeGrossKg} kg` : '—'}</strong></span>
                          <span>Dara: <strong>{a.weighbridgeTareKg ? `${a.weighbridgeTareKg} kg` : '—'}</strong></span>
                          <span className="text-emerald-800 font-bold">Net: <strong>{a.weighbridgeNetKg ? `${a.weighbridgeNetKg} kg` : '—'}</strong></span>
                        </div>
                        {a.expectedWeightKg && a.weighbridgeNetKg && (
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            Beyan - Fiili Net Fark: {(a.weighbridgeNetKg - a.expectedWeightKg).toFixed(1)} kg
                          </span>
                        )}
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold">Ambalaj Listesi / İrsaliye Uygunluğu:</span>
                        <span className={`inline-block font-bold px-2 py-0.5 rounded text-[11px] mt-0.5 ${
                          a.packingListCompliant ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {a.packingListCompliant ? '✅ Tam Uygun' : '❌ Uygun Değil'}
                        </span>
                        {a.packingListNote && (
                          <p className="text-[11px] text-rose-700 mt-1 italic">Not: {a.packingListNote}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ========================================================================= */}
            {/* 6. AŞAMA: DATALOGGER SICAKLIK & SOĞUK ZİNCİR KAYITLARI */}
            {/* ========================================================================= */}
            {refLojistik.some(l => l.dataloggers && l.dataloggers.length > 0) && (
              <div className="space-y-3 break-inside-avoid print-page-break">
                <div className="flex items-center justify-between border-b-2 border-cyan-800 pb-1.5">
                  <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-cyan-950 flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-cyan-700" />
                    <span>6. DATALOGGER SICAKLIK & SOĞUK ZİNCİR KAYITLARI</span>
                  </h3>
                  <span className="text-[10px] font-bold bg-cyan-100 text-cyan-900 px-2 py-0.5 rounded border border-cyan-300">
                    Dijital Sensör Analizi
                  </span>
                </div>

                {refLojistik.map(l => (l.dataloggers || []).map((dl, dIdx) => {
                  const stats = dl.fullStats || dl.tripStats;
                  return (
                    <div key={dl.id} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-800">Cihaz #{dIdx + 1}: {dl.brand || 'Datalogger'} ({dl.deviceId})</span>
                          <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px] font-bold">
                            Konum: {dl.placement || 'PALET_ICI'}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[10px]">
                            TZ: {dl.sourceTimezone}
                          </span>
                          {dl.editedAfterImport && (
                            <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                              İthalat Sonrası Düzenlendi
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">Kaynak: {dl.source} {dl.fileName ? `(${dl.fileName})` : ''}</span>
                      </div>

                      {/* İstatistik Tablosu */}
                      {stats && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 bg-white p-2.5 rounded-lg border border-slate-200 font-mono text-[11px] text-center">
                          <div>
                            <span className="text-slate-500 text-[9px] block">Min °C</span>
                            <strong className="text-cyan-700">{stats.minC !== undefined ? `${stats.minC}°C` : '—'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">Maks °C</span>
                            <strong className="text-rose-700">{stats.maxC !== undefined ? `${stats.maxC}°C` : '—'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">Ort °C</span>
                            <strong className="text-slate-800">{stats.avgC !== undefined ? `${stats.avgC}°C` : '—'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">MKT °C</span>
                            <strong className="text-indigo-700">{stats.mktC !== undefined ? `${stats.mktC}°C` : '—'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">Aralık (dk)</span>
                            <span>{stats.intervalMin ? `${stats.intervalMin} dk` : '—'}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">Üst Limit Aşımı</span>
                            <strong className="text-rose-600">{stats.minutesAboveUpper ? `${stats.minutesAboveUpper} dk` : '0 dk'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">Alt Limit Aşımı</span>
                            <strong className="text-cyan-600">{stats.minutesBelowLower ? `${stats.minutesBelowLower} dk` : '0 dk'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[9px] block">İhlal Sayısı</span>
                            <strong className={stats.violationCount ? 'text-rose-600' : 'text-emerald-700'}>
                              {stats.violationCount || 0}
                            </strong>
                          </div>
                        </div>
                      )}

                      {/* SVG Sparkline Grafiği */}
                      {dl.series && dl.series.length > 0 && (
                        <ReportLoggerSparklineSVG
                          series={dl.series}
                          upperLimitC={dl.upperLimitC}
                          lowerLimitC={dl.lowerLimitC}
                        />
                      )}
                    </div>
                  );
                }))}

                {/* Çatışma Uyarısı (2°C veya daha fazla fark) */}
                {(() => {
                  const allDls = refLojistik.flatMap(l => l.dataloggers || []).filter(d => d.fullStats?.avgC !== undefined);
                  if (allDls.length >= 2) {
                    const diff = Math.abs(allDls[0].fullStats!.avgC! - allDls[1].fullStats!.avgC!);
                    if (diff >= LOGGER_CONFLICT_WARN_C) {
                      return (
                        <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 text-xs flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>
                            <strong>Datalogger Çatışma Uyarısı:</strong> {allDls[0].deviceId} ile {allDls[1].deviceId} arasındaki ortalama sıcaklık farkı {diff.toFixed(1)}°C'dir (Eşik: &ge; {LOGGER_CONFLICT_WARN_C}°C).
                          </span>
                        </div>
                      );
                    }
                  }
                  return null;
                })()}
              </div>
            )}

            {/* ========================================================================= */}
            {/* 7. AŞAMA: NUMUNE KUTULARI (SAMPLE BOXES) */}
            {/* ========================================================================= */}
            {refAmbar.some(a => a.sampleBoxes && a.sampleBoxes.length > 0) && (
              <div className="space-y-3 break-inside-avoid print-page-break">
                <div className="flex items-center justify-between border-b-2 border-emerald-800 pb-1.5">
                  <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-emerald-950 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>7. NUMUNE KUTULARI (SAMPLE BOXES)</span>
                  </h3>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded border border-emerald-300">
                    Kasa Bazlı Kalite & Kusur Matrisi
                  </span>
                </div>

                {refAmbar.map((a) => {
                  if (!a.sampleBoxes || a.sampleBoxes.length === 0) return null;
                  const totals = sampleTotals(a.sampleBoxes);
                  return (
                    <div key={`sample-table-${a.id}`} className="space-y-2">
                      {totals.mismatchBoxNos.length > 0 && (
                        <div className="p-2 bg-amber-50 border border-amber-300 rounded text-amber-900 text-[11px] font-bold">
                          ⚠️ Uyumsuz Kutu: #{totals.mismatchBoxNos.join(', #')} için kusur adetleri toplamı adet/boy (count size) ile uyuşmuyor.
                        </div>
                      )}

                      <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-100 text-slate-700 border-b border-slate-300 font-bold text-[10px]">
                              <th className="p-1.5 text-center">Kutu</th>
                              <th className="p-1.5 text-center">Boy</th>
                              <th className="p-1.5 text-center">Brüt(g)</th>
                              <th className="p-1.5 text-center">Dara(g)</th>
                              <th className="p-1.5 text-center">Net(g)</th>
                              <th className="p-1.5 text-center bg-emerald-50 text-emerald-900">Sınıf 1</th>
                              <th className="p-1.5 text-center">Mekanik</th>
                              <th className="p-1.5 text-center bg-rose-50 text-rose-900">Çürük</th>
                              <th className="p-1.5 text-center">Yumuşak</th>
                              <th className="p-1.5 text-center">İç Boz.</th>
                              <th className="p-1.5 text-center">Küf</th>
                              <th className="p-1.5 text-center">Soğuk</th>
                              <th className="p-1.5 text-center">Antrak.</th>
                              <th className="p-1.5 text-center">Sertlik</th>
                              <th className="p-1.5">Tane Ağırlık İstatistiği (n, min, ort, maks, CV)</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 text-[11px]">
                            {a.sampleBoxes.map((b) => {
                              const stats = pieceWeightStats(b.pieceWeightsG || []);
                              const isMismatch = totals.mismatchBoxNos.includes(b.boxNo);
                              const bTotal = b.countSize || 0;
                              const pct = (val: number) => (bTotal > 0 ? `%${((val / bTotal) * 100).toFixed(1)}` : '—');

                              return (
                                <React.Fragment key={b.boxNo}>
                                  <tr className={isMismatch ? 'bg-amber-50/50' : 'hover:bg-slate-50'}>
                                    <td className="p-1.5 text-center font-mono font-bold">#{b.boxNo}</td>
                                    <td className="p-1.5 text-center font-mono">{b.countSize}</td>
                                    <td className="p-1.5 text-center font-mono">{b.grossG !== null ? `${b.grossG}g` : '—'}</td>
                                    <td className="p-1.5 text-center font-mono">{b.tareG !== null ? `${b.tareG}g` : '—'}</td>
                                    <td className="p-1.5 text-center font-mono font-bold text-emerald-800">{b.netG !== null ? `${b.netG}g` : '—'}</td>
                                    <td className="p-1.5 text-center font-mono font-bold text-emerald-700 bg-emerald-50/40">{b.class1}</td>
                                    <td className="p-1.5 text-center font-mono">{b.mechanical}</td>
                                    <td className="p-1.5 text-center font-mono font-bold text-rose-700 bg-rose-50/40">{b.rotten}</td>
                                    <td className="p-1.5 text-center font-mono">{b.soft}</td>
                                    <td className="p-1.5 text-center font-mono">{b.internal}</td>
                                    <td className="p-1.5 text-center font-mono">{b.mold}</td>
                                    <td className="p-1.5 text-center font-mono">{b.coldDamage}</td>
                                    <td className="p-1.5 text-center font-mono">{b.anthracnose}</td>
                                    <td className="p-1.5 text-center font-mono">{b.firmness !== null ? b.firmness : '—'}</td>
                                    <td className="p-1.5 text-[10px] font-mono text-slate-700">
                                      {stats.n > 0 ? (
                                        <span>
                                          n:{stats.n} | Min:{stats.min}g | Ort:{stats.mean.toFixed(1)}g | Maks:{stats.max}g | <strong className="text-emerald-700">CV:%{stats.cvPct.toFixed(1)}</strong>
                                        </span>
                                      ) : (
                                        '—'
                                      )}
                                    </td>
                                  </tr>
                                  {/* Her Kutu Satırının Altına O Kutunun Kategori Yüzdeleri (kategori adedi / kutu adedi × 100) */}
                                  <tr className="bg-slate-50/80 text-[10px] text-slate-500 border-b border-slate-200">
                                    <td colSpan={5} className="p-1 text-right font-semibold text-slate-400 italic pr-2">
                                      Kutu #{b.boxNo} Yüzdeleri (%):
                                    </td>
                                    <td className="p-1 text-center font-mono font-bold text-emerald-700 bg-emerald-50/20">{pct(b.class1)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.mechanical)}</td>
                                    <td className="p-1 text-center font-mono font-bold text-rose-700 bg-rose-50/20">{pct(b.rotten)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.soft)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.internal)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.mold)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.coldDamage)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.anthracnose)}</td>
                                    <td className="p-1 text-center font-mono text-slate-400">—</td>
                                    <td className="p-1 text-[9px] text-slate-400 italic">Kategori / {bTotal} adet</td>
                                  </tr>
                                </React.Fragment>
                              );
                            })}
                          </tbody>
                          <tfoot>
                            <tr className="bg-slate-100 font-bold border-t-2 border-slate-300 text-[10px] text-slate-900">
                              <td className="p-1.5 text-center font-mono">TOPLAM</td>
                              <td className="p-1.5 text-center font-mono">{totals.totalFruits} adet</td>
                              <td className="p-1.5 text-center font-mono">{totals.avgGross !== null ? `${totals.avgGross.toFixed(0)}g` : '—'}</td>
                              <td className="p-1.5 text-center font-mono">{totals.avgTare !== null ? `${totals.avgTare.toFixed(0)}g` : '—'}</td>
                              <td className="p-1.5 text-center font-mono text-emerald-800">{totals.avgNet !== null ? `${totals.avgNet.toFixed(1)}g` : '—'}</td>
                              <td className="p-1.5 text-center font-mono text-emerald-700 bg-emerald-100/60">%{totals.class1Pct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.mechanicalPct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono text-rose-700 bg-rose-100/60">%{totals.rottenPct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.softPct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.internalPct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.moldPct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.coldDamagePct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">%{totals.anthracnosePct.toFixed(1)}</td>
                              <td className="p-1.5 text-center font-mono">{totals.avgFirmness !== null ? `${totals.avgFirmness.toFixed(1)}` : '—'}</td>
                              <td className="p-1.5 text-slate-600">Örneklem: {a.sampleBoxes.length} kutu, {totals.totalFruits} meyve</td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* ========================================================================= */}
            {/* 8. AŞAMA: GÖRSEL DENETİM & KUTU BAZLI KUSUR FOTOĞRAF KANITI */}
            {/* ========================================================================= */}
            {refAmbar.some(a => (a.photos && a.photos.length > 0) || (a.sampleBoxes && a.sampleBoxes.length > 0)) && (
              <div className="space-y-4 break-inside-avoid print-page-break">
                <div className="flex items-center justify-between border-b-2 border-slate-800 pb-1.5">
                  <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <Camera className="w-4 h-4 text-slate-700" />
                    <span>8. GÖRSEL DENETİM &amp; KUTU BAZLI KUSUR FOTOĞRAF KANITI</span>
                  </h3>
                  <span className="text-[10px] font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-300">
                    Kutu Bazlı Muayene ve Fotoğraflar
                  </span>
                </div>

                {refAmbar.map((a) => {
                  const photos = a.photos || [];
                  const metas = a.photoMeta || [];
                  const BOX_PHOTO_ORDER = ['KANTAR', 'SINIF1', 'MEKANIK', 'CURUK', 'YUMUSAK', 'KESIT', 'SERTLIK'];
                  const CATEGORY_TITLES: Record<string, string> = {
                    KANTAR: 'Kantar / Ağırlık',
                    SINIF1: 'Sınıf 1 (Class 1)',
                    MEKANIK: 'Mekanik Hasar',
                    CURUK: 'Çürük (Rotten)',
                    YUMUSAK: 'Yumuşak (Soft)',
                    KESIT: 'Meyve Kesit',
                    SERTLIK: 'Sertlik / Penetrometre',
                    ARAC: 'Araç / Konteyner',
                    MUHUR: 'Mühür (Seal)',
                    DATALOGGER: 'Datalogger Cihazı',
                    DIGER: 'Diğer Kanıt'
                  };

                  const allPhotoItems = photos.map((url, idx) => {
                    const m = metas.find(meta => meta.index === idx);
                    return { url, idx, meta: m };
                  });

                  // Kutu numarası olmayan fotoğraflar (araç, mühür, kantar fişi, datalogger)
                  const generalPhotos = allPhotoItems.filter(p => !p.meta || p.meta.boxNo === undefined || p.meta.boxNo === null);
                  const sampleBoxes = a.sampleBoxes || [];

                  return (
                    <div key={`box-inspection-${a.id}`} className="space-y-4">
                      {/* Genel Bloğu (araç, mühür, kantar fişi, datalogger) */}
                      {generalPhotos.length > 0 && (
                        <div className="border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2 break-inside-avoid shadow-2xs">
                          <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <Truck className="w-3.5 h-3.5 text-slate-600" />
                              <span>Genel / Sevkiyat, Araç, Mühür &amp; Datalogger Fotoğrafları ({generalPhotos.length})</span>
                            </span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                            {generalPhotos.map(p => {
                              const catLabel = p.meta ? (CATEGORY_TITLES[p.meta.category] || p.meta.category) : `Fotoğraf #${p.idx + 1}`;
                              return (
                                <div key={p.idx} className="border border-slate-200 rounded-lg p-1 bg-white shadow-2xs">
                                  <img src={p.url} alt={catLabel} className="w-full h-28 object-cover rounded" />
                                  <div className="text-[10px] font-bold text-slate-700 text-center mt-1 truncate">
                                    {catLabel}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Her Kutu İçin: "Kutu N" başlığı, tablo satırı ve yüzdeleri, tane ağırlıkları (2 sütun), sıralı fotoğraflar */}
                      {sampleBoxes.map((b) => {
                        const bTotal = b.countSize || 0;
                        const pct = (val: number) => (bTotal > 0 ? `%${((val / bTotal) * 100).toFixed(1)}` : '—');
                        const stats = pieceWeightStats(b.pieceWeightsG || []);

                        // Fotoğrafları şu sırayla: KANTAR, SINIF1, MEKANIK, CURUK, YUMUSAK, KESIT, SERTLIK
                        const boxPhotos = allPhotoItems
                          .filter(p => p.meta && p.meta.boxNo === b.boxNo)
                          .sort((p1, p2) => {
                            const c1 = p1.meta?.category || '';
                            const c2 = p2.meta?.category || '';
                            const r1 = BOX_PHOTO_ORDER.indexOf(c1);
                            const r2 = BOX_PHOTO_ORDER.indexOf(c2);
                            const rank1 = r1 >= 0 ? r1 : 999;
                            const rank2 = r2 >= 0 ? r2 : 999;
                            return rank1 - rank2;
                          });

                        return (
                          <div key={b.boxNo} className="border border-slate-200 rounded-xl p-3 bg-white space-y-3 break-inside-avoid shadow-2xs">
                            {/* Kutu N Başlığı */}
                            <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                              <div className="flex items-center gap-2">
                                <h4 className="text-xs sm:text-sm font-black uppercase text-emerald-950 flex items-center gap-1.5">
                                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                                  <span>Kutu {b.boxNo}</span>
                                </h4>
                                <span className="text-[10px] font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded border border-emerald-200 font-mono">
                                  Boy: {b.countSize} adet | Net: {b.netG !== null ? `${b.netG}g` : '—'}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-500 font-semibold">
                                {boxPhotos.length} Fotoğraf Kanıtı
                              </span>
                            </div>

                            {/* O Kutunun Tablo Satırı ve Yüzdeleri */}
                            <div className="overflow-x-auto border border-slate-200 rounded-lg">
                              <table className="w-full text-left border-collapse text-xs">
                                <thead>
                                  <tr className="bg-slate-100 text-slate-700 font-bold text-[10px] border-b border-slate-200">
                                    <th className="p-1 text-center">Kutu</th>
                                    <th className="p-1 text-center">Boy</th>
                                    <th className="p-1 text-center">Brüt(g)</th>
                                    <th className="p-1 text-center">Dara(g)</th>
                                    <th className="p-1 text-center font-bold text-emerald-800">Net(g)</th>
                                    <th className="p-1 text-center bg-emerald-50 text-emerald-900 font-bold">Sınıf 1</th>
                                    <th className="p-1 text-center">Mekanik</th>
                                    <th className="p-1 text-center bg-rose-50 text-rose-900 font-bold">Çürük</th>
                                    <th className="p-1 text-center">Yumuşak</th>
                                    <th className="p-1 text-center">İç Boz.</th>
                                    <th className="p-1 text-center">Küf</th>
                                    <th className="p-1 text-center">Soğuk</th>
                                    <th className="p-1 text-center">Antrak.</th>
                                    <th className="p-1 text-center">Sertlik</th>
                                  </tr>
                                </thead>
                                <tbody className="text-[11px] divide-y divide-slate-200">
                                  <tr>
                                    <td className="p-1 text-center font-mono font-bold">#{b.boxNo}</td>
                                    <td className="p-1 text-center font-mono">{b.countSize}</td>
                                    <td className="p-1 text-center font-mono">{b.grossG !== null ? `${b.grossG}g` : '—'}</td>
                                    <td className="p-1 text-center font-mono">{b.tareG !== null ? `${b.tareG}g` : '—'}</td>
                                    <td className="p-1 text-center font-mono font-bold text-emerald-800">{b.netG !== null ? `${b.netG}g` : '—'}</td>
                                    <td className="p-1 text-center font-mono font-bold text-emerald-700 bg-emerald-50/40">{b.class1}</td>
                                    <td className="p-1 text-center font-mono">{b.mechanical}</td>
                                    <td className="p-1 text-center font-mono font-bold text-rose-700 bg-rose-50/40">{b.rotten}</td>
                                    <td className="p-1 text-center font-mono">{b.soft}</td>
                                    <td className="p-1 text-center font-mono">{b.internal}</td>
                                    <td className="p-1 text-center font-mono">{b.mold}</td>
                                    <td className="p-1 text-center font-mono">{b.coldDamage}</td>
                                    <td className="p-1 text-center font-mono">{b.anthracnose}</td>
                                    <td className="p-1 text-center font-mono">{b.firmness !== null ? b.firmness : '—'}</td>
                                  </tr>
                                  <tr className="bg-slate-50/80 text-[10px] text-slate-600 font-medium border-t border-slate-200">
                                    <td colSpan={5} className="p-1 text-right italic font-semibold text-slate-500 pr-2">
                                      Kutu #{b.boxNo} Yüzdeleri (%):
                                    </td>
                                    <td className="p-1 text-center font-mono font-bold text-emerald-700 bg-emerald-50/30">{pct(b.class1)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.mechanical)}</td>
                                    <td className="p-1 text-center font-mono font-bold text-rose-700 bg-rose-50/30">{pct(b.rotten)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.soft)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.internal)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.mold)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.coldDamage)}</td>
                                    <td className="p-1 text-center font-mono">{pct(b.anthracnose)}</td>
                                    <td className="p-1 text-center font-mono text-slate-400">—</td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>

                            {/* Tane Ağırlıkları (2 Sütun) */}
                            {b.pieceWeightsG && b.pieceWeightsG.length > 0 && (
                              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                                <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 mb-1.5 flex-wrap gap-2">
                                  <span>Tane Ağırlıkları ({b.pieceWeightsG.length} Meyve - 2 Sütun):</span>
                                  {stats.n > 0 && (
                                    <span className="font-mono text-[10px] text-slate-600">
                                      n:{stats.n} | Min: <strong>{stats.min}g</strong> | Ort: <strong>{stats.mean.toFixed(1)}g</strong> | Maks: <strong>{stats.max}g</strong> | CV: <strong className="text-emerald-700">%{stats.cvPct.toFixed(1)}</strong>
                                    </span>
                                  )}
                                </div>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 font-mono text-[10px] text-slate-700">
                                  {b.pieceWeightsG.map((w, wIdx) => (
                                    <div key={wIdx} className="flex items-center justify-between border-b border-slate-200/60 py-0.5 px-1 bg-white/60 rounded">
                                      <span className="text-slate-500">Meyve #{wIdx + 1}:</span>
                                      <span className="font-bold text-slate-900">{w} g</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Fotoğrafları Şu Sırayla: KANTAR, SINIF1, MEKANIK, CURUK, YUMUSAK, KESIT, SERTLIK */}
                            {boxPhotos.length > 0 ? (
                              <div className="space-y-1.5 pt-1">
                                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
                                  Kutu #{b.boxNo} Fotoğraf Kanıtları (Sıralı: Kantar &rarr; Sınıf 1 &rarr; Mekanik &rarr; Çürük &rarr; Yumuşak &rarr; Kesit &rarr; Sertlik):
                                </span>
                                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2">
                                  {boxPhotos.map(p => {
                                    const catName = p.meta ? (CATEGORY_TITLES[p.meta.category] || p.meta.category) : `Fotoğraf #${p.idx + 1}`;
                                    return (
                                      <div key={p.idx} className="border border-slate-200 rounded-lg p-1 bg-slate-50 text-center shadow-2xs">
                                        <img src={p.url} alt={catName} className="w-full h-24 object-cover rounded" />
                                        <div className="text-[9px] font-bold text-slate-800 mt-1 truncate" title={catName}>
                                          {catName}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            ) : (
                              <div className="text-[10px] text-slate-400 italic p-1">
                                Bu kutu için yüklenmiş fotoğraf kanıtı bulunmamaktadır.
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            )}

            {/* ========================================================================= */}
            {/* 9. AŞAMA: KABUL KARARI, SPESİFİKASYON DEĞERLENDİRMESİ & TALEP */}
            {/* ========================================================================= */}
            {refAmbar.some(a => a.intakeDecision || a.gostDecision) && (
              <div className="space-y-3 break-inside-avoid print-page-break">
                <div className="flex items-center justify-between border-b-2 border-emerald-900 pb-1.5">
                  <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-emerald-950 flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-700" />
                    <span>9. KABUL KARARI, SPESİFİKASYON DEĞERLENDİRMESİ & TALEP</span>
                  </h3>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded border border-emerald-300">
                    Nihai Onay Kararı
                  </span>
                </div>

                {refAmbar.map((a) => {
                  const spec = getProductSpec(reference?.product || 'Avokado');
                  const totals = a.sampleBoxes && a.sampleBoxes.length > 0 ? sampleTotals(a.sampleBoxes) : null;
                  const suggestion = totals ? suggestDecision(totals, spec) : null;
                  const linkedIncident = refIncidents.find(i => i.refId === a.refId);

                  return (
                    <div key={`dec-${a.id}`} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-3">
                      {suggestion && (
                        <div className={`p-2.5 rounded-lg border text-xs ${
                          suggestion.decision === 'KABUL'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                            : 'bg-rose-50 border-rose-300 text-rose-900'
                        }`}>
                          <div className="font-bold flex items-center gap-1.5">
                            <span>Spesifikasyon Analiz Sonucu: <strong>{suggestion.decision}</strong></span>
                          </div>
                          {suggestion.reasons.length > 0 && (
                            <ul className="list-disc pl-5 mt-1 space-y-0.5 text-[11px]">
                              {suggestion.reasons.map((r, ri) => (
                                <li key={ri}>{r}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-3 rounded-lg border border-slate-200">
                        <div>
                          <span className="text-slate-500 text-[10px] block font-bold">Nihai Kabul Kararı:</span>
                          <strong className={`text-sm ${
                            (a.intakeDecision || a.acceptanceStatus) === 'KABUL' || (a.intakeDecision || a.acceptanceStatus) === 'ACCEPTED'
                              ? 'text-emerald-700'
                              : 'text-rose-700'
                          }`}>
                            {a.intakeDecision || a.acceptanceStatus || 'BELİRTİLMEDİ'}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block font-bold">Muayeneyi Yapan Uzman:</span>
                          <strong className="text-slate-900 text-xs">{a.operator || 'Depo Kabul Uzmanı'}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block font-bold">Bağlı DÖF / Tutanak No:</span>
                          <strong className="font-mono text-rose-700 text-xs">
                            {linkedIncident ? (linkedIncident.actNumber || linkedIncident.incidentId) : 'Yok'}
                          </strong>
                        </div>
                      </div>

                      {a.intakeDecisionNote && (
                        <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-[11px] text-slate-700">
                          <strong>Karar Notu / Açıklaması:</strong> {a.intakeDecisionNote}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* 3. AŞAMA: FRİGORİFİK LOJİSTİK VE SOĞUK ZİNCİR SEVKİYAT VERİLERİ */}
            {refLojistik.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-blue-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-blue-700" />
                    <span>🚚 3. AŞAMA: FRİGORİFİK LOJİSTİK VE SOĞUK ZİNCİR SEVKİYATI</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">
                    Sıcaklık Kayıt Takibi
                  </span>
                </h3>

                {refLojistik.map((l) => (
                  <div
                    key={l.id}
                    className="bg-blue-50/50 border border-blue-200 rounded-xl p-3.5 text-xs space-y-2.5 break-inside-avoid"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Araç Plaka & Şoför:</span>
                        <strong>{l.vehiclePlate} ({l.driver})</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Delilnama No:</span>
                        <strong className="font-mono text-rose-700">{l.delilnamaNo}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Çıkış / Yol Sıcaklığı:</span>
                        <strong className="font-mono text-blue-900">
                          {l.departureTemperature}°C / {l.transitTemperature}°C
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Yüklenen Miktar:</span>
                        <strong className="font-mono text-slate-900">
                          {l.weightKg} kg ({l.palletCount} Palet / {l.caseCount} Kasa)
                        </strong>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 border-t border-blue-100 text-[11px]">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Çıkış & Varış Noktası:</span>
                        <span>{l.source} &rarr; <strong>{l.destination}</strong></span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Taşıma Tipi:</span>
                        <span>{l.transportType || 'Frigorifik Tır'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Sevkiyat Durumu:</span>
                        <strong className="text-emerald-700">{l.status}</strong>
                      </div>
                    </div>

                    <PdfPhotoGrid
                      photos={l.photos}
                      title="📸 Frigorifik Araç, Yükleme & Delilnama Fotoğrafları:"
                    />
                  </div>
                ))}
              </div>
            )}

            {/* 5. AŞAMA: FREEZE-DRY LİYOFİLİZASYON İŞLEME (VARSA) */}
            {refFreezeDry.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-purple-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <Snowflake className="w-4 h-4 text-purple-700" />
                    <span>❄️ 5. AŞAMA: FREEZE-DRY LİYOFİLİZASYON İŞLEME (-40°C ŞOKLAMA)</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Liyofilizasyon</span>
                </h3>

                {refFreezeDry.map((fd) => (
                  <div
                    key={fd.id}
                    className="bg-purple-50/50 border border-purple-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Giren / Çıkan Ağırlık:</span>
                        <strong className="font-mono text-purple-950">
                          {fd.rawWeightKg} kg &rarr; {fd.finalDryWeightKg} kg Kuru
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Şoklama / Donuk Oda:</span>
                        <strong className="font-mono">
                          {fd.shockFreezerTempC}°C (Şok) / {fd.frozenStorageTempC}°C
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Kuru Ürün Nemi & Verim:</span>
                        <strong className="font-mono text-purple-900">
                          %{fd.finalMoisturePercent} Nem (%{fd.yieldRatioPercent} Verim)
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Üretilen Paket:</span>
                        <strong>{fd.totalPackagesProduced} Paket ({fd.packagingType})</strong>
                      </div>
                    </div>

                    <PdfPhotoGrid
                      photos={fd.photos}
                      title="📸 Freeze-Dry Şoklama ve Vakum Paketleme Fotoğrafları:"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ========================================================================= */}
          {/* SAYFA 3: EKSPORT, SATIŞ, KALİTE SAPMALARI, FOTOĞRAFLAR VE RESMİ İMZALAR */}
          {/* ========================================================================= */}
          <div className="space-y-6 pb-6 border-b-2 border-slate-900 print-page">
            
            {/* Running Header for Page 3 */}
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <BrandLogo size={24} />
                <h2 className="text-sm font-black uppercase tracking-tight text-emerald-950">
                  SAYFA 3: EKSPORT, TİCARİ SATIŞ, BELGE ARŞİVİ & RESMİ ONAY MÜHRÜ
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">RefID: <strong>{refId}</strong></span>
            </div>

            {/* 6. AŞAMA: EKSPORT ŞAHİT NUMUNE & VARIŞ TESTİ */}
            {refExport.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-cyan-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <Globe2 className="w-4 h-4 text-cyan-700" />
                    <span>✈️ 6. AŞAMA: EKSPORT TRANSİT ŞAHİT NUMUNE & VARIŞ TESTİ</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Varış Kalitesi</span>
                </h3>

                {refExport.map((exp) => (
                  <div
                    key={exp.id}
                    className="bg-cyan-50/50 border border-cyan-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Hedef Ülke & Gün:</span>
                        <strong>{exp.destinationCountry} ({exp.transitDays} Gün Yol)</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Ağırlık & Su Kaybı:</span>
                        <strong className="font-mono text-cyan-900">
                          Ağ: %{exp.weightLossPercent} | Su: %{exp.waterLossPercent}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Varış Brix & Sertlik:</span>
                        <strong className="font-mono">
                          %{exp.avgBrix} °Bx / {exp.avgHardness} kg/cm²
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Raf Ömrü Kararı:</span>
                        <strong className="text-emerald-800">{exp.shelfLifeDecision}</strong>
                      </div>
                    </div>

                    <PdfPhotoGrid
                      photos={exp.photos}
                      title="📸 Transit Şahit Numune & Varış Testi Fotoğrafları:"
                    />
                  </div>
                ))}
              </div>
            )}

            {/* 7. AŞAMA: TİCARİ SATIŞ VE SEVKİYAT */}
            {refSales.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-indigo-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <ShoppingBag className="w-4 h-4 text-indigo-700" />
                    <span>🛍️ 7. AŞAMA: TİCARİ SATIŞ VE SEVKİYAT DAĞILIMI</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Müşteri Çıkışı</span>
                </h3>

                {refSales.map((s) => (
                  <div
                    key={s.id}
                    className="bg-indigo-50/50 border border-indigo-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Alıcı Müşteri / Firma:</span>
                        <strong>{s.customer}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Toplam Satış Çıkışı:</span>
                        <strong className="font-mono text-indigo-900">
                          {s.totalQuantityKg} kg ({s.totalCases} Kasa)
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Fatura / İrsaliye No:</span>
                        <strong className="font-mono">{s.invoiceNo}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">Kalite Sınıfı:</span>
                        <strong className="text-emerald-800">{s.overallQualityGrade}</strong>
                      </div>
                    </div>

                    <PdfPhotoGrid
                      photos={s.photos}
                      title="📸 Satış, Paletleme & Sevk Fotoğrafları:"
                    />
                  </div>
                ))}
              </div>
            )}

            {/* 8. AŞAMA: KALİTE UYGUNSUZLUK / BARLAG AKTY (VARSA) */}
            {refIncidents.length > 0 && (
              <div className="space-y-2 break-inside-avoid">
                <h3 className="text-xs font-black uppercase tracking-wider text-rose-900 flex items-center justify-between border-b pb-1">
                  <span className="flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-700" />
                    <span>⚠️ 8. AŞAMA: İLGİLİ KALİTE UYGUNSUZLUK / BARLAG AKTI KAYITLARI</span>
                  </span>
                  <span className="text-[10px] font-mono text-rose-700 font-bold">
                    {refIncidents.length} Uygunsuzluk
                  </span>
                </h3>

                {refIncidents.map((inc) => (
                  <div
                    key={inc.id}
                    className="bg-rose-50/50 border border-rose-200 rounded-xl p-3.5 text-xs space-y-2 break-inside-avoid"
                  >
                    <div className="flex items-center justify-between">
                      <strong className="text-rose-900 font-mono">
                        Akt No: {inc.actNumber || inc.incidentId}
                      </strong>
                      <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded font-bold text-[10px]">
                        {inc.detectionStage}
                      </span>
                    </div>
                    <p className="text-slate-700">{inc.description}</p>
                    <p className="text-slate-600">
                      <strong>5-Why Kök Sebep:</strong> {inc.rootCause}
                    </p>
                    <PdfPhotoGrid photos={inc.photos} title="📸 Kalite Sapması Tespit Fotoğrafları:" />
                  </div>
                ))}
              </div>
            )}

            {/* 9. AŞAMA: TOPLU BELGE VE FOTOĞRAF KÜTÜĞÜ */}
            {allReferencePhotos.length > 0 && (
              <div className="space-y-3 break-inside-avoid">
                <div className="flex items-center justify-between border-b pb-1">
                  <h3 className="text-xs font-black uppercase tracking-wider text-teal-950 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-teal-700" />
                    <span>📸 9. AŞAMA: PARTİ SAHA VE KALİTE BELGE KÜTÜĞÜ</span>
                  </h3>
                  <span className="text-[10px] font-mono text-slate-500 font-bold">
                    Toplam {allReferencePhotos.length} Belge & Fotoğraf
                  </span>
                </div>
                <PdfPhotoGrid
                  photos={allReferencePhotos}
                  title="📸 Partiye Ait Tüm Denetim, Hasat, Kalite ve Ambar Belgeleri:"
                />
              </div>
            )}

            {/* RESMİ ONAY, İMZA VE MÜHÜR ALANI */}
            <div className="pt-6 border-t-2 border-slate-900 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs break-inside-avoid">
              <div className="space-y-6 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span>Saha Kalite Operatörü:</span>
                </div>
                <div className="border-b-2 border-slate-400 pb-1">
                  <p className="font-bold text-slate-900">{activeRef?.operator || refHarvest[0]?.operator || refField[0]?.operator || '—'}</p>
                  <p className="text-[10px] text-slate-500">Gol / İmza: ___________________</p>
                </div>
                <span className="text-[9px] text-slate-400 block font-mono">Saha & Hasat Kontrolü</span>
              </div>

              <div className="space-y-6 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold">
                  <Warehouse className="w-4 h-4 text-teal-600" />
                  <span>Ambar & Soğuk Depo Sorumlusu:</span>
                </div>
                <div className="border-b-2 border-slate-400 pb-1">
                  <p className="font-bold text-slate-900">{refAmbar[0]?.operator || '—'}</p>
                  <p className="text-[10px] text-slate-500">Gol / İmza: ___________________</p>
                </div>
                <span className="text-[9px] text-slate-400 block font-mono">Depo Kabul & İklimlendirme</span>
              </div>

              <div className="space-y-6 bg-emerald-50/60 p-3 rounded-xl border border-emerald-200">
                <div className="flex items-center gap-1.5 text-emerald-950 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Hil & Barlag Müdiri:</span>
                </div>
                <div className="border-b-2 border-emerald-400 pb-1">
                  <p className="font-bold text-slate-900">Onay bekliyor</p>
                  <p className="text-[10px] text-slate-500 font-semibold">Gol / İmza: ___________________</p>
                </div>
                <div className="text-[9px] text-emerald-900 font-mono font-bold">
                  <span className="text-amber-800">[ TASLAK — ONAYLANMADI ]</span>
                </div>
              </div>
            </div>

            {/* Bilgilendirme Dipnotu */}
            <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200 text-[10px] text-slate-500 flex flex-wrap items-center justify-between gap-2 font-mono">
              <span>Parti / RefID: {refId}</span>
              <span>Bu rapor Miwe Hil Kalite Yönetim Sistemi tarafından üretilmiştir.</span>
            </div>
          </div>
        </>
      )}
    </div>

          {/* Bottom Modal Actions (Hidden in Print) */}
          <div className="shrink-0 p-3.5 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 print:hidden">
            <div className="text-xs text-slate-500 font-medium">
              3 Sayfalı Çoklu Kalite & İzlenebilirlik Pasaportu önizlemesi
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={handlePrint}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
              >
                <Printer className="w-4 h-4" />
                <span>Yazdır / PDF Olarak Kaydet</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
              >
                <X className="w-4 h-4" />
                <span>Raporu Kapat</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Floating Quick Action Bar (Thumb-reachable at screen bottom) */}
        <div className="fixed bottom-4 left-3 right-3 z-50 sm:hidden flex items-center justify-between gap-2 p-2 bg-slate-950/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-700/80 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
          >
            <X className="w-4 h-4" />
            <span>Raporu Kapat</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
          >
            <Printer className="w-4 h-4" />
            <span>PDF / Yazdır</span>
          </button>
        </div>
      </div>
  );
};
