import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  CheckCircle2,
  Shield,
  Building,
  Award,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  Check
} from 'lucide-react';
import { AppUser } from '../../types/auth';
import { updateUserProfile, changeUserPassword as updateUserPassword, performSessionAudit, SessionAuditResult } from '../../utils/authService';
import { SessionValidationIndicator } from './SessionValidationIndicator';
import { evaluatePasswordStrength } from '../../utils/security';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AppUser;
  onUserUpdated: (user: AppUser) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'PROFILE' | 'PASSWORD'>('PROFILE');
  const [fullName, setFullName] = useState(currentUser.fullName);
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordConfirm, setNewPasswordConfirm] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showNewPasswordConfirm, setShowNewPasswordConfirm] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  const newPasswordStrength = evaluatePasswordStrength(newPassword);

  const [sessionAudit, setSessionAudit] = useState<SessionAuditResult | null>(null);
  const handleRevalidateSession = () => {
    setSessionAudit(performSessionAudit());
  };

  useEffect(() => {
    if (isOpen) {
      setSessionAudit(performSessionAudit());
      setFullName(currentUser.fullName);
      setPhone(currentUser.phone || '');
      setIsSuccess(false);
      setError('');
      setCurrentPassword('');
      setNewPassword('');
      setNewPasswordConfirm('');
      setPasswordSuccess(false);
      setPasswordError('');
      // If user requires password change, default to PASSWORD tab
      if (currentUser.requiresPasswordChange) {
        setActiveTab('PASSWORD');
      } else {
        setActiveTab('PROFILE');
      }
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSuccess(false);

    const nameVal = fullName.trim();
    const phoneVal = phone.trim();

    if (!nameVal) {
      setError('İsim soyisim alanı boş bırakılamaz.');
      return;
    }

    if (nameVal.length < 3) {
      setError('İsim soyisim en az 3 karakterden oluşmalıdır.');
      return;
    }

    const nameRegex = /^[a-zA-Z\s\.\-'\u00C0-\u017F\u0180-\u024F\u1E00-\u1EFF]+$/;
    if (!nameRegex.test(nameVal)) {
      setError('İsim soyisim alanı sadece harf, nokta ve boşluk içerebilir.');
      return;
    }

    if (!phoneVal) {
      setError('Telefon numarası alanı boş bırakılamaz.');
      return;
    }

    const phoneRegex = /^\+?[0-9\s\-()]{7,18}$/;
    if (!phoneRegex.test(phoneVal)) {
      setError('Lütfen geçerli bir telefon numarası giriniz (en az 7 hane, örn: +90 555 123 4567).');
      return;
    }

    const updated = await updateUserProfile(currentUser.id, nameVal, phoneVal);
    if (updated) {
      onUserUpdated(updated);
      setIsSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1200);
    } else {
      setError('Profil güncellenirken bir hata oluştu.');
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess(false);

    if (!currentPassword) {
      setPasswordError('Lütfen mevcut parolanızı girin.');
      return;
    }

    if (!newPassword || newPassword.length < 3) {
      setPasswordError('Yeni parola en az 3 karakterden oluşmalıdır.');
      return;
    }

    if (newPassword !== newPasswordConfirm) {
      setPasswordError('Yeni parolalar eşleşmiyor.');
      return;
    }

    const res = await updateUserPassword(currentPassword, newPassword);
    if (res.success) {
      setPasswordSuccess(true);
      onUserUpdated({ ...currentUser, requiresPasswordChange: false });
      setTimeout(() => {
        onClose();
      }, 1500);
    } else {
      setPasswordError(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-md w-full overflow-hidden transition-all duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-teal-500/10 text-teal-600 dark:text-teal-400 rounded-lg">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">Hesap & Profil Ayarları</h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Kişisel bilgilerinizi ve güvenlik tercihlerinizi yönetin</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 p-1">
          <button
            type="button"
            onClick={() => setActiveTab('PROFILE')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'PROFILE'
                ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profil Bilgileri</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('PASSWORD')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'PASSWORD'
                ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Şifre Değiştir</span>
            {currentUser.requiresPasswordChange && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            )}
          </button>
        </div>

        {/* Tab 1: Profile Form */}
        {activeTab === 'PROFILE' && (
          <form onSubmit={handleProfileSubmit} className="p-5 space-y-4">
            {/* v2.5: oturum/token teşhis bilgisi yalnızca yöneticiye görünür */}
            {currentUser.role === 'ADMIN' && (
              <SessionValidationIndicator
                audit={sessionAudit}
                onRevalidate={handleRevalidateSession}
                className="mb-1"
              />
            )}

            {/* Readonly Info Badges */}
            <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800/60 text-[11px] text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-1.5 truncate">
                <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate font-semibold">{currentUser.company}</span>
              </div>
              <div className="flex items-center gap-1.5 truncate">
                <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate font-semibold">{currentUser.jobTitle}</span>
              </div>
              <div className="col-span-2 mt-1.5 pt-1.5 border-t border-slate-100 dark:border-slate-800/40 flex items-center justify-between text-slate-500">
                <div className="flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 shrink-0 text-teal-500" />
                  <span>Rol: <strong className="text-teal-600 dark:text-teal-400 font-bold">{currentUser.role}</strong></span>
                </div>
                <span className="text-[10px] text-slate-400">{currentUser.email}</span>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-2.5 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 text-rose-800 dark:text-rose-200 text-xs rounded-xl font-medium animate-shake">
                {error}
              </div>
            )}

            {/* Success Message */}
            {isSuccess && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl font-medium flex items-center gap-2 animate-pulse">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Profil bilgileriniz başarıyla güncellendi!</span>
              </div>
            )}

            {/* Inputs */}
            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  İsim Soyisim
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition"
                    placeholder="örn: Ahmet Yılmaz"
                  />
                  <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Telefon Numarası
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition"
                    placeholder="örn: +993 61 234567"
                  />
                  <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 dark:bg-teal-500 dark:hover:bg-teal-400 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
              >
                <span>Değişiklikleri Kaydet</span>
              </button>
            </div>
          </form>
        )}

        {/* Tab 2: Password Change Form */}
        {activeTab === 'PASSWORD' && (
          <form onSubmit={handlePasswordSubmit} className="p-5 space-y-3.5">
            {currentUser.requiresPasswordChange && (
              <div className="p-2.5 bg-amber-500/15 border border-amber-500/30 text-amber-800 dark:text-amber-200 text-xs rounded-xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>Güvenliğiniz için ilk girişinizde lütfen yeni bir şifre belirleyin.</span>
              </div>
            )}

            {passwordError && (
              <div className="p-2.5 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 text-rose-800 dark:text-rose-200 text-xs rounded-xl font-medium">
                {passwordError}
              </div>
            )}

            {passwordSuccess && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Parolanız güvenli şekilde güncellendi!</span>
              </div>
            )}

            {/* Current Password */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Mevcut Parola *
              </label>
              <div className="relative">
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full pl-8 pr-9 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition"
                  placeholder="Mevcut parolanızı girin"
                  required
                />
                <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                >
                  {showCurrentPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* New Password & Confirm */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Yeni Parola *
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full pl-8 pr-9 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition"
                  placeholder="Yeni parolanız"
                  required
                />
                <KeyRound className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                >
                  {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Yeni Parola Onayı *
              </label>
              <div className="relative">
                <input
                  type={showNewPasswordConfirm ? 'text' : 'password'}
                  value={newPasswordConfirm}
                  onChange={(e) => setNewPasswordConfirm(e.target.value)}
                  className="w-full pl-8 pr-9 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition"
                  placeholder="Yeni parolanızı tekrar girin"
                  required
                />
                <KeyRound className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowNewPasswordConfirm(!showNewPasswordConfirm)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                >
                  {showNewPasswordConfirm ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Password Strength Meter */}
            {newPassword.length > 0 && (
              <div className="space-y-1.5 p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-500 dark:text-slate-400 font-bold">Yeni Şifre Gücü:</span>
                  <span className="font-bold text-teal-600 dark:text-teal-400">{newPasswordStrength.label}</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden flex gap-1">
                  {[1, 2, 3, 4].map((level) => (
                    <div
                      key={level}
                      className={`h-full flex-1 transition-all duration-300 rounded-full ${
                        level <= newPasswordStrength.score ? newPasswordStrength.color : 'bg-slate-200 dark:bg-slate-800'
                      }`}
                    />
                  ))}
                </div>
                {newPasswordConfirm && (
                  <div className="text-[10px] flex items-center gap-1 font-semibold">
                    {newPassword === newPasswordConfirm ? (
                      <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Parolalar eşleşiyor
                      </span>
                    ) : (
                      <span className="text-rose-500 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Parolalar eşleşmiyor
                      </span>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 dark:bg-teal-500 dark:hover:bg-teal-400 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
              >
                <span>Şifreyi Güncelle</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
