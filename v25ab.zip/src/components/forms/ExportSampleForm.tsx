import React, { useState, useEffect, useRef } from 'react';
import {
  Globe2,
  ArrowLeft,
  Save,
  Camera,
  Image as ImageIcon,
  Scale,
  Droplets,
  Activity,
  Sparkles,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Trash2,
  Plus,
  Calendar,
  Layers,
  ThermometerSnowflake,
  ShieldCheck,
  TrendingDown,
  Info,
  Lock
} from 'lucide-react';
import { ExportSampleRecord, ExportSampleTestItem, ReferenceItem } from '../../types';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { getCurrentUser } from '../../utils/authService';
import { generateRefId } from '../../utils/calculations';
import { SmartCreatableSelect } from '../common/SmartField';
import { GostDefectInput, GostSpreadsheetMetadata } from '../../utils/gostQualityCalculators';
import { IoTDataloggerConnector } from '../iot/IoTDataloggerConnector';
import { GostDefectMatrixWidget } from '../common/GostDefectMatrixWidget';

interface ExportSampleFormProps {
  onSave: (record: ExportSampleRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: ExportSampleRecord;
  isReadOnly?: boolean;
}

export const ExportSampleForm: React.FC<ExportSampleFormProps> = ({
  onSave,
  onCancel,
  existingRefs = [],
  initialRefId,
  initialRecord,
  isReadOnly = false
}) => {
  const [isNewRef, setIsNewRef] = useState<boolean>(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState<string>(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId ?? 'EXP-REF-01'));
  
  // Custom new Ref fields
  const [customRefId, setCustomRefId] = useState<string>(() => {
    if (initialRecord?.refId) return initialRecord.refId;
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    return `EXP-${today}-${rand}`;
  });

  // Basic Form State
  const [operator, setOperator] = useState(initialRecord?.operator || getCurrentUser()?.fullName || '');
  const [testDate, setTestDate] = useState(initialRecord?.testDate || new Date().toISOString().slice(0, 10));
  const [dispatchDate, setDispatchDate] = useState(() => {
    if (initialRecord?.dispatchDate) return initialRecord.dispatchDate;
    const d = new Date();
    d.setDate(d.getDate() - 4);
    return d.toISOString().slice(0, 10);
  });
  const [product, setProduct] = useState(initialRecord?.product || '');
  const [variety, setVariety] = useState(initialRecord?.variety || '');
  const [destinationCountry, setDestinationCountry] = useState(initialRecord?.destinationCountry || '');
  const [transitDays, setTransitDays] = useState<number | null>(initialRecord?.transitDays ?? null);
  const [transitCondition, setTransitCondition] = useState(initialRecord?.transitCondition || 'CPT - Frigorifik Tır');

  // Weight & Water Loss State
  const [initialWeightGr, setInitialWeightGr] = useState<number | null>(initialRecord?.initialWeightGr ?? null);
  const [finalWeightGr, setFinalWeightGr] = useState<number | null>(initialRecord?.finalWeightGr ?? null);
  const [waterLossPercent, setWaterLossPercent] = useState<number | null>(initialRecord?.waterLossPercent ?? null);

  // Dynamic Sample Testing Matrix
  const [sampleCount, setSampleCount] = useState<number>(initialRecord?.sampleCount ?? 5);
  const [samples, setSamples] = useState<ExportSampleTestItem[]>(
    initialRecord?.samples && initialRecord.samples.length > 0
      ? initialRecord.samples
      : [1, 2, 3, 4, 5].map(n => ({ sampleNo: n, hardness: 0, brix: 0, diameterMm: 0, visualScore: 0, defectNotes: '' })) // v2.5: boş satırlar (0 = ölçülmedi)
  );

  // Assessment & Decision
  const [visualAssessment, setVisualAssessment] = useState(initialRecord?.visualAssessment || '');
  const [shelfLifeDecision, setShelfLifeDecision] = useState<'EXCELLENT' | 'COMPLIANT' | 'CONDITIONAL' | 'HIGH_RISK'>(initialRecord?.shelfLifeDecision || ('' as any));
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(initialRecord?.kaliteSinifi || '');
  const [decisionNotes, setDecisionNotes] = useState(initialRecord?.decisionNotes || '');

  // Photo Upload State (Cold-Start: no sample photos)
  const [photos, setPhotos] = useState<string[]>(
    initialRecord?.photos && initialRecord.photos.length > 0
      ? initialRecord.photos
      : []
  );
  const [isDragging, setIsDragging] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // --- Spreadsheet Integration States (Bilingual Russian/Turkish/English) ---
  const [docTemperature, setDocTemperature] = useState('');
  const [coolingUnitTemperature, setCoolingUnitTemperature] = useState('');
  const [actualTemperature, setActualTemperature] = useState('');
  const [supplier, setSupplier] = useState('');
  const [transportType, setTransportType] = useState('');
  const [batchNumber, setBatchNumber] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState('');
  const [palletCount, setPalletCount] = useState<number | ''>('');
  const [assessmentForQuality, setAssessmentForQuality] = useState<number | ''>('');
  const [tasteBrix, setTasteBrix] = useState('');
  const [caliberDeclared, setCaliberDeclared] = useState('');
  const [caliberActual, setCaliberActual] = useState('');
  const [caliberPercent, setCaliberPercent] = useState<number | ''>('');
  
  // Weights (kg)
  const [sampleBoxCount, setSampleBoxCount] = useState<number | ''>('');
  const [sampleWeightKg, setSampleWeightKg] = useState<number | ''>('');
  const [samplePercent, setSamplePercent] = useState<number | ''>('');
  
  // Defect Weights (kg)
  const [internalRotNecrosisKg, setInternalRotNecrosisKg] = useState<number>(0);
  const [obviousRotTheRotIsObviousKg, setObviousRotTheRotIsObviousKg] = useState<number>(0);
  const [mechanicsKg, setMechanicsKg] = useState<number>(0);
  const [dilutionTopKg, setDilutionTopKg] = useState<number>(0);
  const [easyDeformationKg, setEasyDeformationKg] = useState<number>(0);

  // Expert Full Name
  const [expertName, setExpertName] = useState('');

  // --- Computed Defect Metrics (Auto-calculated like Excel formulas) ---
  const totalSampleWeight = Number(sampleWeightKg) || 0;

  // Rot
  const rotKg = internalRotNecrosisKg + obviousRotTheRotIsObviousKg;
  const rotPercent = totalSampleWeight > 0 ? Number(((rotKg / totalSampleWeight) * 100).toFixed(2)) : 0;
  const internalRotNecrosisPercent = totalSampleWeight > 0 ? Number(((internalRotNecrosisKg / totalSampleWeight) * 100).toFixed(2)) : 0;
  const obviousRotTheRotIsObviousPercent = totalSampleWeight > 0 ? Number(((obviousRotTheRotIsObviousKg / totalSampleWeight) * 100).toFixed(2)) : 0;

  // Non-standard
  const obviousNonStandardKg = mechanicsKg + dilutionTopKg;
  const obviousNonStandardPercent = totalSampleWeight > 0 ? Number(((obviousNonStandardKg / totalSampleWeight) * 100).toFixed(2)) : 0;
  
  const nonStandardKg = obviousNonStandardKg;
  const nonStandardPercent = totalSampleWeight > 0 ? Number(((nonStandardKg / totalSampleWeight) * 100).toFixed(2)) : 0;

  const mechanicsPercent = totalSampleWeight > 0 ? Number(((mechanicsKg / totalSampleWeight) * 100).toFixed(2)) : 0;
  const dilutionTopPercent = totalSampleWeight > 0 ? Number(((dilutionTopKg / totalSampleWeight) * 100).toFixed(2)) : 0;

  // Easy
  const easyDeformationPercent = totalSampleWeight > 0 ? Number(((easyDeformationKg / totalSampleWeight) * 100).toFixed(2)) : 0;

  // Waste (Total)
  const wasteKg = rotKg + nonStandardKg + easyDeformationKg;
  const wastePercent = totalSampleWeight > 0 ? Number(((wasteKg / totalSampleWeight) * 100).toFixed(2)) : 0;

  // --- Preset Loader for Peach Spreadsheet (06.08.2026) ---
  const loadScreenshotPreset = () => {
    setTestDate('2026-08-06');
    setDispatchDate('2026-08-02');
    setTransitDays(4);
    setProduct('Персики свежие (Şeftali Sınıf 1)');
    setVariety('Персики свежие');
    setDestinationCountry('Туркменистан');
    setTransitCondition('CPT - Frigorifik Tır');
    setOperator('Ковалевский Олег Владимирович');
    
    // Header Info
    setDocTemperature('t°C 1/,09');
    setCoolingUnitTemperature('t°C 1/,09');
    setActualTemperature('0,7');
    setSupplier('Гок булут');
    setTransportType('CPT');
    setBatchNumber('86813');
    setBrand('');
    setCategory('1');
    setPalletCount(1);
    setAssessmentForQuality(3);
    setTasteBrix('вкус сладкий.');
    
    setCaliberDeclared('60+');
    setCaliberActual('60+');
    setCaliberPercent(100);
    
    setVisualAssessment('окрас красный, бордовый с желтым, 3 паллета окрас салатово желтый с красным фоном. основная масса плодов упругие, в верхних рядах плоды с незначительной потерей упругости.');
    setShelfLifeDecision('COMPLIANT');
    setDecisionNotes('4 günlük transit sonrası Rusya/Eurasia standardı taze şeftali kontrol sonuçları.');

    // Sample Box and Weights
    setSampleBoxCount(16);
    setSampleWeightKg(58.28);
    setSamplePercent(100);

    // Defect weights from sheets screenshot
    setInternalRotNecrosisKg(0);
    setObviousRotTheRotIsObviousKg(0);
    setMechanicsKg(1.055);
    setDilutionTopKg(1.18);
    setEasyDeformationKg(0);

    setExpertName('Ковалевский Олег Владимирович');

    // Also populate samples matrix
    setSampleCount(5);
    setSamples([
      { sampleNo: 1, hardness: 4.8, brix: 12.5, diameterMm: 62, visualScore: 3, defectNotes: 'Упругий, окрас красный' },
      { sampleNo: 2, hardness: 4.5, brix: 13.0, diameterMm: 64, visualScore: 3, defectNotes: 'Упругий, бордовый' },
      { sampleNo: 3, hardness: 4.6, brix: 12.2, diameterMm: 61, visualScore: 3, defectNotes: 'Салатово-желтый' },
      { sampleNo: 4, hardness: 4.2, brix: 12.8, diameterMm: 63, visualScore: 3, defectNotes: 'Верхний ряд, легкое размягчение' },
      { sampleNo: 5, hardness: 4.1, brix: 13.1, diameterMm: 62, visualScore: 3, defectNotes: 'Незначительная потеря упругости' }
    ]);
  };

  // Sync with selected existing reference
  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      const found = existingRefs.find(r => r.refId === selectedRefId);
      if (found) {
        setProduct(found.product || '');
      }
    }
  }, [isNewRef, selectedRefId, existingRefs]);

  // Auto calculate transit days if dates change
  useEffect(() => {
    if (dispatchDate && testDate) {
      const d1 = new Date(dispatchDate);
      const d2 = new Date(testDate);
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (!isNaN(diffDays) && diffDays > 0) {
        setTransitDays(diffDays);
      }
    }
  }, [dispatchDate, testDate]);

  // Adjust sample count
  const handleSampleCountChange = (count: number) => {
    setSampleCount(count);
    setSamples(prev => {
      if (count > prev.length) {
        const added: ExportSampleTestItem[] = [];
        for (let i = prev.length + 1; i <= count; i++) {
          added.push({
            sampleNo: i,
            hardness: 0,
            brix: 0,
            diameterMm: 0,
            visualScore: 0,
            defectNotes: ''
          });
        }
        return [...prev, ...added];
      } else {
        return prev.slice(0, count);
      }
    });
  };

  const updateSampleField = (index: number, field: keyof ExportSampleTestItem, value: any) => {
    setSamples(prev => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  // Calculations
  const weightLossGr = initialWeightGr != null && finalWeightGr != null ? Math.max(0, initialWeightGr - finalWeightGr) : null;
  const weightLossPercent = weightLossGr != null && initialWeightGr ? Number(((weightLossGr / initialWeightGr) * 100).toFixed(2)) : null;

  const validSamples = samples.slice(0, sampleCount);
  const measuredHard = validSamples.map(s => Number(s.hardness) || 0).filter(v => v > 0);
  const avgHardness = measuredHard.length > 0 ? Number((measuredHard.reduce((a, b) => a + b, 0) / measuredHard.length).toFixed(2)) : null;

  const measuredBrix = validSamples.map(s => Number(s.brix) || 0).filter(v => v > 0);
  const avgBrix = measuredBrix.length > 0 ? Number((measuredBrix.reduce((a, b) => a + b, 0) / measuredBrix.length).toFixed(2)) : null;

  // File Upload Handlers
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
      e.target.value = '';
    }
  };

  const processFiles = (files: File[]) => {
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const addPresetPhoto = (url: string) => {
    setPhotos(prev => [...prev, url]);
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // v2.5: ölçülmemiş değerle kayıt yok
    const missing: string[] = [];
    if (!product.trim()) missing.push('Ürün');
    if (!destinationCountry.trim()) missing.push('Hedef ülke');
    if (transitDays == null) missing.push('Yolda geçen gün');
    if (initialWeightGr == null) missing.push('İlk ağırlık (g)');
    if (finalWeightGr == null) missing.push('Son ağırlık (g)');
    if (avgHardness == null && avgBrix == null) missing.push('En az bir numunede sertlik veya Brix');
    if (!shelfLifeDecision) missing.push('Raf ömrü kararı');
    if (!kaliteSinifi) missing.push('Kalite sınıfı');
    if (missing.length) {
      window.alert('Kaydetmeden önce şunları girin:\n• ' + missing.join('\n• '));
      return;
    }
    let effectiveRefId = isNewRef ? customRefId.trim() : (selectedRefId.trim() || initialRecord?.refId || '');
    if (!effectiveRefId) {
      effectiveRefId = generateRefId('EXPORT_SAMPLE', existingRefs.map(r => r.refId));
    }

    const finalOperator = operator.trim() || getCurrentUser()?.fullName || 'Belirtilmedi';
    const finalProduct = product.trim();
    const finalDest = destinationCountry.trim();

    const record: ExportSampleRecord = {
      id: initialRecord?.id || `exp-${Date.now()}`,
      refId: effectiveRefId,
      timestamp: new Date().toISOString(),
      testDate,
      dispatchDate,
      operator: finalOperator,
      product: finalProduct,
      variety: variety.trim(),
      destinationCountry: finalDest,
      transitDays: transitDays ?? (undefined as any),
      transitCondition: transitCondition.trim() || 'CPT - Frigorifik Tır',
      initialWeightGr: initialWeightGr ?? (undefined as any),
      finalWeightGr: finalWeightGr ?? (undefined as any),
      weightLossGr: weightLossGr ?? (undefined as any),
      weightLossPercent: weightLossPercent ?? (undefined as any),
      waterLossPercent: waterLossPercent ?? (undefined as any),
      sampleCount,
      samples: validSamples,
      avgHardness: avgHardness ?? (undefined as any),
      avgBrix: avgBrix ?? (undefined as any),
      visualAssessment,
      shelfLifeDecision,
      kaliteSinifi,
      decisionNotes,
      photos,

      // Spreadsheet Integration Fields
      docTemperature,
      coolingUnitTemperature,
      actualTemperature,
      supplier,
      transportType,
      batchNumber,
      brand,
      category,
      palletCount: Number(palletCount) || undefined,
      assessmentForQuality: Number(assessmentForQuality) || undefined,
      tasteBrix,
      caliberDeclared,
      caliberActual,
      caliberPercent: Number(caliberPercent) || undefined,
      sampleBoxCount: Number(sampleBoxCount) || undefined,
      sampleWeightKg: Number(sampleWeightKg) || undefined,
      samplePercent: Number(samplePercent) || undefined,
      wastePercent,
      rotKg,
      rotPercent,
      internalRotKg: internalRotNecrosisKg,
      internalRotPercent: internalRotNecrosisPercent,
      internalRotNecrosisKg,
      internalRotNecrosisPercent,
      obviousRotKg: obviousRotTheRotIsObviousKg,
      obviousRotPercent: obviousRotTheRotIsObviousPercent,
      obviousRotTheRotIsObviousKg,
      obviousRotTheRotIsObviousPercent,
      nonStandardKg,
      nonStandardPercent,
      obviousNonStandardKg,
      obviousNonStandardPercent,
      mechanicsKg,
      mechanicsPercent,
      dilutionTopKg,
      dilutionTopPercent,
      easyDeformationKg,
      easyDeformationPercent,
      expertName
    };

    onSave(record, isNewRef, isNewRef ? {
      product,
      location: `Eksport Numune Kontrol Laboratuvarı (${destinationCountry})`,
      destination: destinationCountry,
      quantity: 0,
      unit: 'kg',
      notes: `Eksport Yol Dayanım Testi: ${transitDays ?? '—'} gün sonra %${weightLossPercent ?? '—'} ağırlık kaybı, Brix: ${avgBrix ?? '—'}%, Sertlik: ${avgHardness ?? '—'} kg/cm².`
    } : undefined);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      
      {/* Header */}
      <div className="bg-slate-900 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-teal-500/20 border border-teal-400/30 text-teal-300 shrink-0">
            <Globe2 className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-extrabold tracking-wide text-white">
                EKSPORT NUMUNE & RAF ÖMRÜ (YOL DAYANIM) TESTİ
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-black uppercase bg-teal-400 text-slate-950">
                Eksport Lab • Erem™
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 line-clamp-2 sm:line-clamp-none">
              İhracata çıkan şahit numunelerin yol simülasyonu / dönüş sonrası sertlik, brix, dehidrasyon ve ağırlık kaybı analizi
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onCancel}
          className="self-end sm:self-center shrink-0 flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Geri Dön</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Reference Selector */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
            <label className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-teal-600" />
              <span>İzlenebilirlik Referansı (RefID)</span>
            </label>
            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => setIsNewRef(false)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  !isNewRef
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                Mevcut Ref'e Bağla
              </button>
              <button
                type="button"
                onClick={() => setIsNewRef(true)}
                className={`px-3 py-1 rounded-lg font-bold transition ${
                  isNewRef
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                + Yeni Eksport Ref Aç
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {isNewRef ? (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Yeni Eksport RefID (Yazılabilir veya Otomatik)</label>
                <input
                  type="text"
                  value={customRefId}
                  onChange={(e) => setCustomRefId(e.target.value)}
                  placeholder="örn: EXPORT-20260907-001"
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-teal-700"
                />
              </div>
            ) : (
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Referans Seç veya Serbestçe Yaz (RefID)</label>
                <input
                  type="text"
                  list="export-existing-refs-list"
                  value={selectedRefId}
                  onChange={(e) => setSelectedRefId(e.target.value)}
                  placeholder="Listeden seçin veya RefID yazın..."
                  className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:ring-1 focus:ring-teal-500"
                />
                <datalist id="export-existing-refs-list">
                  {existingRefs.map((r) => (
                    <option key={r.refId} value={r.refId}>
                      {r.product} ({r.quantity} {r.unit}) [{r.status}]
                    </option>
                  ))}
                </datalist>
              </div>
            )}

            {/* TAMAMLANMIŞ TİCARİ HASAT MİKTARI (SALT OKUNUR) */}
            {!isNewRef && selectedRefId && (
              <div className="sm:col-span-2 bg-slate-900 text-white border border-emerald-500/50 rounded-2xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-sm">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                    <Lock className="w-3.5 h-3.5" />
                  </span>
                  <div>
                    <span className="text-[10px] font-black uppercase text-emerald-300 tracking-wider block">
                      Tamamlanmış Hasat Miktarı (Salt Okunur)
                    </span>
                    <span className="text-[10px] text-slate-300 block">
                      Referans onaylı ticari stok miktarıdır. Eksport test numunesi ağırılığından tamamen izoledir.
                    </span>
                  </div>
                </div>
                <div className="font-mono text-right shrink-0">
                  <span className="text-sm font-black text-emerald-400 block">
                    {existingRefs.find(r => r.refId === selectedRefId)?.quantity ? `${Number(existingRefs.find(r => r.refId === selectedRefId)?.quantity).toLocaleString('tr-TR')} kg` : '0 kg'}
                  </span>
                  <span className="text-[9px] font-bold text-slate-400 block">
                    ({existingRefs.find(r => r.refId === selectedRefId)?.quantity ? (Number(existingRefs.find(r => r.refId === selectedRefId)?.quantity) / 1000).toFixed(2) : '0.00'} Ton)
                  </span>
                </div>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Testi Yapan Kalite Mühendisi</label>
              <input
                type="text"
                list="operators-list"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
              <datalist id="operators-list">
                {AUTOCOMPLETE_LISTS.operators.map((op) => (
                  <option key={op} value={op} />
                ))}
              </datalist>
            </div>
          </div>
        </div>

        {/* Section 1: Sevkiyat, Hedef Ülke & Yol Koşulları */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <Globe2 className="w-4 h-4 text-teal-600" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
              1. Sevkiyat, Hedef Ülke & Yol Simülasyon Koşulları
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <SmartCreatableSelect
                label="Hedef Ülke / Pazar"
                categoryKey="exportDestinations"
                options={AUTOCOMPLETE_LISTS.destinations}
                value={destinationCountry}
                onChange={setDestinationCountry}
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Meyve & Çeşit</label>
              <input
                type="text"
                list="products-list"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Yola Çıkış Tarihi</label>
              <input
                type="date"
                value={dispatchDate}
                onChange={(e) => setDispatchDate(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Dönüş / Test Tarihi</label>
              <input
                type="date"
                value={testDate}
                onChange={(e) => setTestDate(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
               
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Yol / Simülasyon Süresi (Gün)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="45"
                  value={transitDays ?? ''}
                  onChange={(e) => setTransitDays(e.target.value === '' ? null : Number(e.target.value))}
                  className="w-28 text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 text-center text-teal-800"
                />
                <span className="text-xs text-slate-500 font-medium">gün boyunca soğuk zincirde kaldı</span>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Taşıma Şekli & Sıcaklık Koşulu
              </label>
              <input
                type="text"
                value={transitCondition}
                onChange={(e) => setTransitCondition(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                placeholder="Örn: +2.5°C Frigorifik Tır (Termoking)"
              />
            </div>
          </div>

          {/* Gerçek Zamanlı IoT Sensör & Datalogger Bağlantısı (İsteğe Bağlı) */}
          <div className="pt-2">
            <IoTDataloggerConnector
              moduleName="EXPORT_SAMPLE"
              targetTempMin={0.5}
              targetTempMax={2.5}
              onTelemetryUpdate={(data) => {
                if (data) {
                  setActualTemperature(String(data.temperatureC));
                  setTransitCondition(`${data.deviceName}: ${data.temperatureC}°C, %${data.humidityPercent} RH, ${data.ethylenePpm} ppm C₂H₄`);
                }
              }}
            />
          </div>
        </div>

        {/* Section 1.2: Rusya / Avrasya Excel Şablonu Bilgileri */}
        <div className="p-4 bg-amber-50/20 rounded-xl border border-amber-200/50 space-y-4">
          <div className="flex items-center gap-2 border-b border-amber-200 pb-2">
            <FileSpreadsheet className="w-4 h-4 text-amber-700" />
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
              <span>1.2. Avrasya Kalite Standartları Excel Şablonu Üst Bilgileri (Header Info)</span>
              <span className="px-1.5 py-0.2 bg-amber-200 text-amber-900 rounded text-[9px] font-black">Спецификация</span>
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Поставщик / Tedarikçi (Supplier)</label>
              <input
                type="text"
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
                placeholder="Örn: Gok bulut"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Вид перевозки / Taşıma Tipi</label>
              <input
                type="text"
                value={transportType}
                onChange={(e) => setTransportType(e.target.value)}
                placeholder="Örn: CPT"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">№ партии / Parti Numarası (Batch #)</label>
              <input
                type="text"
                value={batchNumber}
                onChange={(e) => setBatchNumber(e.target.value)}
                placeholder="Örn: 86813"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Бренд / Marka (Brand)</label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="Örn: Erem"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-1">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Категория / Kategori (Category)</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Örn: 1"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Паллет / Palet Adedi (Pallet Count)</label>
              <input
                type="number"
                value={palletCount}
                onChange={(e) => setPalletCount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Örn: 1"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Оценка / Kalite Skoru (1 - 5)</label>
              <input
                type="number"
                min="1"
                max="5"
                value={assessmentForQuality}
                onChange={(e) => setAssessmentForQuality(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Örn: 3"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-teal-700"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Вкусовые качества / Tat & Lezzet</label>
              <input
                type="text"
                value={tasteBrix}
                onChange={(e) => setTasteBrix(e.target.value)}
                placeholder="Örn: вкус сладкий (tatlı lezzet)"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
              />
            </div>
          </div>

          <div className="border-t border-dashed border-amber-200/70 pt-3">
            <h4 className="text-[11px] font-black uppercase text-slate-700 mb-2 flex items-center gap-1">
              <ThermometerSnowflake className="w-3.5 h-3.5 text-blue-500" />
              <span>Sıcaklık Değerleri / Температурный режим (t°C)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">t°C по документам / Dokümandaki t°C</label>
                <input
                  type="text"
                  value={docTemperature}
                  onChange={(e) => setDocTemperature(e.target.value)}
                  placeholder="Örn: t°C 1/,09"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono text-blue-700 font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">t°C на холод. уст. / Cihaz t°C (Cooler)</label>
                <input
                  type="text"
                  value={coolingUnitTemperature}
                  onChange={(e) => setCoolingUnitTemperature(e.target.value)}
                  placeholder="Örn: t°C 1/,09"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono text-blue-700 font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">t°C фактическая / Fiili/Ölçülen t°C</label>
                <input
                  type="text"
                  value={actualTemperature}
                  onChange={(e) => setActualTemperature(e.target.value)}
                  placeholder="Örn: 0,7"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono text-rose-700 font-bold"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-dashed border-amber-200/70 pt-3">
            <h4 className="text-[11px] font-black uppercase text-slate-700 mb-2 flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span>Калибр / Kalibrasyon (Declared & Actual Caliber)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">заявленный / Beyan Edilen Kalibre</label>
                <input
                  type="text"
                  value={caliberDeclared}
                  onChange={(e) => setCaliberDeclared(e.target.value)}
                  placeholder="Örn: 60+"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">фактический / Fiili Kalibre</label>
                <input
                  type="text"
                  value={caliberActual}
                  onChange={(e) => setCaliberActual(e.target.value)}
                  placeholder="Örn: 60+"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-medium"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">Kalibre Uygunluk Oranı (%)</label>
                <input
                  type="number"
                  value={caliberPercent}
                  onChange={(e) => setCaliberPercent(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Örn: 100"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-800"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Ağırlık & Su Kaybı (Dehidrasyon) */}
        <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-200 space-y-4">
          <div className="flex items-center justify-between border-b border-teal-200 pb-2">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-teal-700" />
              <h3 className="text-xs font-black uppercase tracking-wider text-teal-900">
                2. Numune Ağırlık & Su Kaybı (Dehidrasyon) Analizi
              </h3>
            </div>
            <span className="text-[11px] font-bold text-teal-800 bg-teal-100 px-2.5 py-0.5 rounded-full border border-teal-300">
              Otomatik Fire & Nem Kaybı Matrisi
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                İlk Numune Ağırlığı (gr) *
              </label>
              <input
                type="number"
                step="1"
                min="10"
                value={initialWeightGr ?? ''}
                onChange={(e) => setInitialWeightGr(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
               
              />
              <span className="text-[10px] text-slate-500">Yola çıkış anındaki şahit ağırlığı</span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Son Numune Ağırlığı (gr) *
              </label>
              <input
                type="number"
                step="1"
                min="10"
                value={finalWeightGr ?? ''}
                onChange={(e) => setFinalWeightGr(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
               
              />
              <span className="text-[10px] text-slate-500">Yoldan dönüş / simülasyon sonrası</span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Hesaplanan Ağırlık Kaybı (gr & %)
              </label>
              <div className="w-full text-xs font-black bg-white border border-teal-300 rounded-lg px-3 py-2 text-teal-800 flex items-center justify-between shadow-inner">
                <span>{weightLossGr ?? '—'} gr</span>
                <span className="px-2 py-0.5 rounded bg-teal-100 text-teal-900 border border-teal-300">
                  %{weightLossPercent ?? '—'}
                </span>
              </div>
              <span className="text-[10px] text-slate-500">Hedef: %3.0 altı ideal</span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Tahmini Su Kaybı / Dehidrasyon (%)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="30"
                  value={waterLossPercent ?? ''}
                  onChange={(e) => setWaterLossPercent(e.target.value === '' ? null : Number(e.target.value))}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2"
                />
                <Droplets className="w-5 h-5 text-teal-600 shrink-0" />
              </div>
              <span className="text-[10px] text-slate-500">Hücre suyu çekilme oranı</span>
            </div>
          </div>
        </div>

        {/* Section 3: Sertlik & Brix Şeker Numune Matrisi */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
                3. Dönüş Sonrası Sertlik (kg/cm²) & Brix Şeker (°Bx) Test Matrisi
              </h3>
            </div>
            
            {/* Sample count toggle */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600">Numune Adedi:</span>
              {[3, 5, 7].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleSampleCountChange(num)}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition ${
                    sampleCount === num
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {num} Numune
                </button>
              ))}
            </div>
          </div>

          {/* Desktop Table View */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-200/80 text-slate-700 font-extrabold uppercase text-[10px]">
                  <th className="py-2 px-3 rounded-l-lg">No</th>
                  <th className="py-2 px-3">Penetrometr Sertlik (kg/cm²)</th>
                  <th className="py-2 px-3">Refraktometre Brix (% Şeker)</th>
                  <th className="py-2 px-3">Kalibre / Çap (mm)</th>
                  <th className="py-2 px-3">Görsel Skor (1-5)</th>
                  <th className="py-2 px-3 rounded-r-lg">Kusur / Numune Notu</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-medium">
                {validSamples.map((s, idx) => (
                  <tr key={idx} className="hover:bg-white/60">
                    <td className="py-2 px-3 font-mono font-bold text-slate-600">
                      #{s.sampleNo}
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        max="20"
                        value={s.hardness || ''}
                        onChange={(e) => updateSampleField(idx, 'hardness', Number(e.target.value))}
                        className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold text-slate-900 min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        max="35"
                        value={s.brix || ''}
                        onChange={(e) => updateSampleField(idx, 'brix', Number(e.target.value))}
                        className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold text-teal-800 min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        step="1"
                        min="10"
                        max="120"
                        value={s.diameterMm || 70}
                        onChange={(e) => updateSampleField(idx, 'diameterMm', Number(e.target.value))}
                        className="w-20 bg-white border border-slate-300 rounded px-2 py-1 text-xs min-h-[40px]"
                      />
                    </td>
                    <td className="py-2 px-3">
                      <select
                        value={s.visualScore}
                        onChange={(e) => updateSampleField(idx, 'visualScore', Number(e.target.value))}
                        className="bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold min-h-[40px]"
                      >
                        <option value="5">5 (Kusursuz / Parlak)</option>
                        <option value="4">4 (Çok İyi / Hafif Leke)</option>
                        <option value="3">3 (Kabul Edilebilir)</option>
                        <option value="2">2 (Buruşma / Kararma)</option>
                        <option value="1">1 (Ağır Bozulma / Çürük)</option>
                      </select>
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={s.defectNotes}
                        onChange={(e) => updateSampleField(idx, 'defectNotes', e.target.value)}
                        placeholder="Örn: Kusursuz, kabuk gergin"
                        className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs min-h-[40px]"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Card List View (sm:hidden) */}
          <div className="block sm:hidden space-y-3">
            {validSamples.map((s, idx) => (
              <div key={idx} className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                  <span className="font-mono font-bold text-xs text-teal-800">Numune #{s.sampleNo}</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-bold text-slate-500">Skor:</span>
                    <select
                      value={s.visualScore}
                      onChange={(e) => updateSampleField(idx, 'visualScore', Number(e.target.value))}
                      className="bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 text-xs font-bold text-slate-800"
                    >
                      <option value="5">5 (Kusursuz)</option>
                      <option value="4">4 (Çok İyi)</option>
                      <option value="3">3 (Kabul)</option>
                      <option value="2">2 (Buruşma)</option>
                      <option value="1">1 (Bozuk)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Sertlik (kg/cm²)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={s.hardness || ''}
                      onChange={(e) => updateSampleField(idx, 'hardness', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Brix (% Şeker)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={s.brix || ''}
                      onChange={(e) => updateSampleField(idx, 'brix', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-xs font-bold text-teal-800"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Çap (mm)</label>
                    <input
                      type="number"
                      value={s.diameterMm || 70}
                      onChange={(e) => updateSampleField(idx, 'diameterMm', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 text-xs text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">Kusur / Numune Açıklaması</label>
                  <input
                    type="text"
                    value={s.defectNotes}
                    onChange={(e) => updateSampleField(idx, 'defectNotes', e.target.value)}
                    placeholder="Örn: Kusursuz, kabuk gergin"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Quick Stats Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Ortalama Sertlik:</span>
              <span className="text-sm font-black text-slate-900">{avgHardness ?? '—'} kg/cm²</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Ortalama Brix Şekeri:</span>
              <span className="text-sm font-black text-teal-700">{avgBrix ?? '—'}° Bx</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between shadow-sm">
              <span className="text-xs font-bold text-slate-600">Ağırlık Kayıp Oranı:</span>
              <span className="text-sm font-black text-amber-700">%{weightLossPercent ?? '—'}</span>
            </div>
          </div>
        </div>

        {/* Section 3.5: Avrasya / Rusya Kalite Standartları Kusur & Fire Hesaplama Tablosu */}
        <div className="p-4 bg-amber-50/20 dark:bg-slate-900/40 rounded-xl border border-amber-200/70 dark:border-amber-900/40 space-y-4">
          <GostDefectMatrixWidget
            defects={{
              sampleBoxCount: Number(sampleBoxCount) || 0,
              sampleWeightKg: Number(sampleWeightKg) || 0,
              internalRotNecrosisKg: internalRotNecrosisKg || 0,
              obviousRotTheRotIsObviousKg: obviousRotTheRotIsObviousKg || 0,
              mechanicsKg: mechanicsKg || 0,
              dilutionTopKg: dilutionTopKg || 0,
              easyDeformationKg: easyDeformationKg || 0,
              productName: product
            }}
            onChangeDefects={(upd) => {
              setSampleBoxCount(upd.sampleBoxCount || '');
              setSampleWeightKg(upd.sampleWeightKg || '');
              setInternalRotNecrosisKg(upd.internalRotNecrosisKg || 0);
              setObviousRotTheRotIsObviousKg(upd.obviousRotTheRotIsObviousKg || 0);
              setMechanicsKg(upd.mechanicsKg || 0);
              setDilutionTopKg(upd.dilutionTopKg || 0);
              setEasyDeformationKg(upd.easyDeformationKg || 0);
            }}
            metadata={{
              docTemperature,
              coolingUnitTemperature,
              actualTemperature,
              supplier,
              transportType,
              batchNumber,
              brand,
              category,
              palletCount,
              assessmentForQuality,
              tasteBrix,
              caliberDeclared,
              caliberActual,
              caliberPercent,
              expertName,
              testDate,
              dispatchDate,
              transitDays,
              destinationCountry
            }}
            onChangeMetadata={(upd) => {
              if (upd.docTemperature !== undefined) setDocTemperature(upd.docTemperature);
              if (upd.coolingUnitTemperature !== undefined) setCoolingUnitTemperature(upd.coolingUnitTemperature);
              if (upd.actualTemperature !== undefined) setActualTemperature(upd.actualTemperature);
              if (upd.supplier !== undefined) setSupplier(upd.supplier);
              if (upd.transportType !== undefined) setTransportType(upd.transportType);
              if (upd.batchNumber !== undefined) setBatchNumber(upd.batchNumber);
              if (upd.category !== undefined) setCategory(upd.category);
              if (upd.palletCount !== undefined) setPalletCount(typeof upd.palletCount === 'number' ? upd.palletCount : Number(upd.palletCount) || '');
              if (upd.tasteBrix !== undefined) setTasteBrix(upd.tasteBrix);
              if (upd.caliberDeclared !== undefined) setCaliberDeclared(upd.caliberDeclared);
              if (upd.caliberActual !== undefined) setCaliberActual(upd.caliberActual);
              if (upd.expertName !== undefined) setExpertName(upd.expertName);
            }}
            productName={product}
          />

          {/* Expert Signature */}
          <div className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="w-full">
              <label className="text-xs font-black uppercase text-slate-800 dark:text-slate-200 block mb-1">
                Ф.И.О. эксперта / Kalite Kontrol Eksperti (Expert Full Name) *
              </label>
              <input
                type="text"
                value={expertName}
                onChange={(e) => setExpertName(e.target.value)}
                placeholder="Örn: Ковалевский Олег Владимирович"
                className="w-full text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 font-bold text-slate-900 dark:text-slate-100 shadow-sm"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Görsel Değerlendirme & Raf Ömrü / Yol Dayanım Kararı */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
              4. Görsel Analiz & Raf Ömrü / Sevkiyat Kabul Kararı
            </h3>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Görsel Durum, Kabuk Direnci & Kusur Değerlendirmesi
            </label>
            <textarea
              rows={2}
              value={visualAssessment}
              onChange={(e) => setVisualAssessment(e.target.value)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg p-3 font-medium focus:ring-1 focus:ring-teal-500"
              placeholder="Kabuk lekeleri, buruşma, renklenme kaybı veya çürüklük durumu..."
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Nihai Raf Ömrü & Yol Dayanım Kararı *
              </label>
              <select
                value={shelfLifeDecision}
                onChange={(e) => setShelfLifeDecision(e.target.value as any)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2.5 font-bold text-slate-900 focus:ring-1 focus:ring-teal-500"
              >
                <option value="">— Karar seçin —</option>
                <option value="EXCELLENT">🟢 MÜKEMMEL (Yol Dayanımı Yüksek - Raf Ömrü 10+ Gün)</option>
                <option value="COMPLIANT">🔵 UYGUN (Standart İhracat Kalitesi Korundu - Satışa Hazır)</option>
                <option value="CONDITIONAL">🟡 ŞARTLI KABUL (Hızlı Tüketim & Yakın Sevk Önerilir)</option>
                <option value="HIGH_RISK">🔴 YÜKSEK RİSK / RET (Aşırı Yumuşama veya Çürüme - İade Riski)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Karar / Kalite Açıklaması
              </label>
              <input
                type="text"
                value={decisionNotes}
                onChange={(e) => setDecisionNotes(e.target.value)}
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-3 py-2.5 font-medium"
                placeholder="Örn: 4 günlük transit sonrası değerler tam uygundur."
              />
            </div>
          </div>
        </div>

        {/* Section 5: Fotoğraf & Numune Delil Belgeleri */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-700" />
              <label className="text-xs font-black uppercase tracking-wider text-slate-900">
                Eksport Numune & Kesit Fotoğrafları
              </label>
            </div>
            <span className="text-[11px] font-bold text-slate-600 bg-white px-2.5 py-0.5 rounded-full border border-slate-200">
              {photos.filter(p => p && p.length > 20).length} Fotoğraf
            </span>
          </div>

          {/* Drag & Drop / Upload Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-4 transition text-center flex flex-col sm:flex-row items-center justify-between gap-3 ${
              isDragging
                ? 'border-teal-500 bg-teal-50/70'
                : 'border-slate-300 bg-white hover:border-slate-400'
            }`}
          >
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 border border-teal-200 flex items-center justify-center shrink-0">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">
                  Fotoğrafları buraya sürükleyin veya cihazdan seçin
                </p>
                <p className="text-[11px] text-slate-500">
                  Numune meyve kesiti, refraktometre ekranı ve kantar tartım görseli yükleyebilirsiniz.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-teal-300" />
                <span>Fotoğraf Çek</span>
              </button>

              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Galeriden Seç</span>
              </button>

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />

              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>

          {/* Quick Preset Samples for Testing */}
          <div className="flex items-center gap-2 flex-wrap text-[11px] pt-1">
            <span className="text-slate-500 font-semibold">Hızlı Numune Fotoğrafı Ekle:</span>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-teal-600" />
              <span>🍑 Şeftali / Nektarin Şahit Numune</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-teal-600" />
              <span>🍎 Elma İhracat Kesiti</span>
            </button>
            <button
              type="button"
              onClick={() => addPresetPhoto('https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=400&q=80')}
              className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold transition flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-teal-600" />
              <span>🍌 Muz Kalite & Parmak Boyu</span>
            </button>
          </div>

          {/* Uploaded Photos Grid */}
          {photos.filter(p => p && p.length > 20).length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
              {photos.filter(p => p && p.length > 20).map((p, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shadow-sm aspect-square"
                >
                  <img
                    src={p}
                    alt={`Export Evidence ${idx + 1}`}
                    className="w-full h-full object-cover transition duration-200 group-hover:scale-105"
                  />
                  <div className="absolute top-1 left-1 bg-black/60 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    #{idx + 1}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(idx)}
                    title="Kaldır"
                    className="absolute top-1 right-1 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-md shadow-md opacity-90 group-hover:opacity-100 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bilgi Amaçlı Modül Sonu Rehberi: Eksport Yol Dayanım & Raf Ömrü Rehberi (Kritik Standartlar) */}
        <div className="bg-cyan-50/90 border border-cyan-200/80 rounded-2xl p-4 text-xs text-cyan-950 space-y-2.5 shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-cyan-900">
            <Info className="w-4.5 h-4.5 text-cyan-700 shrink-0" />
            <span className="text-xs uppercase tracking-wider font-extrabold">💡 Eksport Yol Dayanım & Raf Ömrü Rehberi (Kritik Standartlar)</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-[11px] text-cyan-900/90 leading-relaxed">
            <div className="bg-white/90 p-2.5 rounded-xl border border-cyan-200/60 shadow-2xs">
              <strong className="block text-cyan-950 mb-0.5">Ağırlık & Su Kaybı:</strong> Transit sonrası %5 altındaki su/ağırlık kaybı "Kusursuz (A Kalite)" kabul edilir. %10 üstü fire kritik risk oluşturur.
            </div>
            <div className="bg-white/90 p-2.5 rounded-xl border border-cyan-200/60 shadow-2xs">
              <strong className="block text-cyan-950 mb-0.5">Sertlik & Şeker Eşiği:</strong> Şeftali/Nektarin için minimum 4.0 kg/cm² sertlik ve 11+ °Bx şeker gereklidir.
            </div>
            <div className="bg-white/90 p-2.5 rounded-xl border border-cyan-200/60 shadow-2xs">
              <strong className="block text-cyan-950 mb-0.5">Şahit Numune Kuralı:</strong> Her ihracat partisinden en az 5 şahit numune alınarak varış ülkesi sıcaklık simülasyonuna tabi tutulur.
            </div>
          </div>
        </div>

        {/* Action Buttons (Top & Bottom Geri Dön options for maximum ergonomic comfort) */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-slate-200 flex-wrap">
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center justify-center gap-1.5 px-5 py-3 min-h-[44px] rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 active:scale-95 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-slate-500" />
            <span>← Geri Dön / İptal</span>
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800 active:scale-95 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition cursor-pointer`}
          >
            <Save className="w-4 h-4 text-teal-300" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'EKSPORT NUMUNE TESTİNİ KAYDET'}</span>
          </button>
        </div>
        </fieldset>

      </form>
    </div>
  );
};
