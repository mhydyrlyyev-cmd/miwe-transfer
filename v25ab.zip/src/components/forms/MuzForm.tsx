import React, { useState, useMemo, useRef } from 'react';
import { Banana, ArrowLeft, Camera, Image as ImageIcon, Save, Info, AlertTriangle, CheckCircle2, Thermometer, Sparkles, Scale, Layers, Box, Wind, Zap, Activity, Flame, Droplets, Sliders, Calendar, BookOpen } from 'lucide-react';
import { MuzRecord, ReferenceItem, SplitLotItem, STANDARD_QUALITY_CLASSES, BananaScadaChamberData, ActiveFieldContext } from '../../types';
import { BANANA_RIPENESS_STAGES, generateRefId, evaluateBananaQuality } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { getCurrentUser } from '../../utils/authService';
import { SmartCreatableSelect } from '../common/SmartField';
import { compressImageFiles } from '../../utils/imageCompressor';
import { BananaRipeningScadaModal } from './BananaRipeningScadaModal';
import { MuzKurdeleView } from '../portal/MuzKurdeleView';
import { InteractiveBananaQualityTraceabilityWidget } from './InteractiveBananaQualityTraceabilityWidget';

interface MuzFormProps {
  onSave: (record: MuzRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: MuzRecord;
  activeFieldContext?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

export const MuzForm: React.FC<MuzFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  activeFieldContext,
  isReadOnly = false
}) => {
  const isEditing = Boolean(initialRecord);
  const [activeMuzSubTab, setActiveMuzSubTab] = useState<'QUALITY_FORM' | 'KURDELE_VIEW'>('QUALITY_FORM');
  const [isNewRef, setIsNewRef] = useState(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || '');
  const [customRefInput, setCustomRefInput] = useState(initialRecord?.refId || '');

  // Operator & Origin (Auto-populated from activeFieldContext if selected in Gantt or Header)
  const [operator, setOperator] = useState(initialRecord?.operator || getCurrentUser()?.fullName || '');
  const [product, setProduct] = useState(initialRecord?.product || activeFieldContext?.product || 'Muz (Cavendish)');
  const [greenhouseNo, setGreenhouseNo] = useState(
    initialRecord?.greenhouseNo || activeFieldContext?.greenhouseNo || activeFieldContext?.parcelCode || ''
  );
  const [ribbonColor, setRibbonColor] = useState(
    initialRecord?.ribbonColor || activeFieldContext?.ribbonColor || ''
  );
  const [bloomWeek, setBloomWeek] = useState<number | null>(initialRecord?.bloomWeek ?? null);
  const [harvestAgeWeeks, setHarvestAgeWeeks] = useState<number | null>(initialRecord?.harvestAgeWeeks ?? null);
  const [destination, setDestination] = useState('');
  
  // Physical measurements & Morphometry
  const [fingerLengthCm, setFingerLengthCm] = useState<number | null>(initialRecord?.fingerLengthCm ?? null);
  const [calibrationMm, setCalibrationMm] = useState<number | null>(initialRecord?.calibrationMm ?? null);
  const [fingerCountPerHand, setFingerCountPerHand] = useState<number | null>(initialRecord?.fingerCountPerHand ?? null);
  const [handPosition, setHandPosition] = useState<'1. El (Üst)' | '2. El' | 'Orta El' | 'Alt El'>(initialRecord?.handPosition || '1. El (Üst)');
  const [clusterWeightKg, setClusterWeightKg] = useState<number | null>(initialRecord?.clusterWeightKg ?? null);
  const [angularity, setAngularity] = useState<'Dolu Yuvarlak' | '3/4 Dolu' | 'Köşeli'>(initialRecord?.angularity || 'Dolu Yuvarlak');

  // Physiology & Ripeness Tests
  const [ripenessScale, setRipenessScale] = useState<number | null>(initialRecord?.ripenessScale ?? null); // 1 = Green harvest
  const [pulpFirmness, setPulpFirmness] = useState<number | null>(initialRecord?.pulpFirmness ?? null);
  const [pulpTemperatureC, setPulpTemperatureC] = useState<number | null>(initialRecord?.pulpTemperatureC ?? null);
  
  // Brix Multi-Sample Testing & Average (Seçmeli - Madde 10)
  const [hasBrixTest, setHasBrixTest] = useState<boolean>(() => {
    return Boolean(initialRecord?.brix !== undefined && initialRecord.brix > 0);
  });
  const [hasPpmTest, setHasPpmTest] = useState<boolean>(() => {
    return Boolean(initialRecord?.avgPpm !== undefined && initialRecord.avgPpm > 0);
  });

  // Muz Özel 3-Nokta Meyve Ölçümü (Sap/Üst, Orta, Uç/Alt)
  const [banana3PointTop, setBanana3PointTop] = useState<number | null>(null);
  const [banana3PointMiddle, setBanana3PointMiddle] = useState<number | null>(null);
  const [banana3PointBottom, setBanana3PointBottom] = useState<number | null>(null);

  const [brix1, setBrix1] = useState<number | null>(null);
  const [brix2, setBrix2] = useState<number | null>(null);
  const [brix3, setBrix3] = useState<number | null>(null);
  const [brix4, setBrix4] = useState<number | null>(null);
  const [brix5, setBrix5] = useState<number | null>(null);

  // PPM Multi-Point Testing & Average
  const [ppmTestType, setPpmTestType] = useState<string>('Etilen Gazlama Seviyesi (ppm)');
  const [ppm1, setPpm1] = useState<number | null>(null);
  const [ppm2, setPpm2] = useState<number | null>(null);
  const [ppm3, setPpm3] = useState<number | null>(null);
  const [ppm4, setPpm4] = useState<number | null>(null);
  const [ppm5, setPpm5] = useState<number | null>(null);

  // Calculated Averages
  const banana3PointAvg = useMemo(() => {
    const top = Number(banana3PointTop) || 0;
    const mid = Number(banana3PointMiddle) || 0;
    const bot = Number(banana3PointBottom) || 0;
    const list = [top, mid, bot].filter(v => v > 0);
    if (!list.length) return null; // v2.5: ölçüm yoksa uydurma 4.5 yok
    return parseFloat((list.reduce((a, b) => a + b, 0) / list.length).toFixed(1));
  }, [banana3PointTop, banana3PointMiddle, banana3PointBottom]);

  const avgBrix = useMemo(() => {
    const list = [brix1, brix2, brix3, brix4, brix5].filter((v): v is number => typeof v === 'number' && v > 0);
    if (!list.length) return banana3PointAvg;
    return parseFloat((list.reduce((a, b) => a + b, 0) / list.length).toFixed(1));
  }, [brix1, brix2, brix3, brix4, brix5, banana3PointAvg]);

  const avgPpm = useMemo(() => {
    const list = [ppm1, ppm2, ppm3, ppm4, ppm5].filter((v): v is number => typeof v === 'number' && v > 0);
    if (!list.length) return null; // v2.5: ölçüm yoksa uydurma 100 ppm yok
    return Math.round(list.reduce((a, b) => a + b, 0) / list.length);
  }, [ppm1, ppm2, ppm3, ppm4, ppm5]);

  // Defects Check
  const [flowerEndDefect, setFlowerEndDefect] = useState<boolean>(false);
  const [latexStain, setLatexStain] = useState<boolean>(false);
  const [mechanicalDamage, setMechanicalDamage] = useState<boolean>(false);
  const [sunburnOrYellow, setSunburnOrYellow] = useState<boolean>(false);
  const [pestDamage, setPestDamage] = useState<boolean>(false);

  // Packaging & Storage details
  const [packaging, setPackaging] = useState('');
  const [polybagType, setPolybagType] = useState<'Vakumlu Banavac' | 'Delikli Polietilen' | 'Açık Dökme'>('Vakumlu Banavac');
  const [mapPackaging, setMapPackaging] = useState<boolean>(true); // Modifiye Atmosfer Paketleme
  const [ethyleneAbsorber, setEthyleneAbsorber] = useState<boolean>(true); // KMnO4 Etilen Emici Absorber Şase
  const [netWeightKg, setNetWeightKg] = useState<number | null>(initialRecord?.netWeightKg ?? null); // v2.5: uydurma 3200 kg yok
  const [grossWeightKg, setGrossWeightKg] = useState<number | null>(initialRecord?.grossWeightKg ?? null); // v2.5: uydurma 3380 kg yok
  const [roomNo, setRoomNo] = useState('');
  const [coolingStatus, setCoolingStatus] = useState<'Uygun' | 'Yetersiz' | 'İşlemde'>('Uygun');
  const [gasStatus, setGasStatus] = useState<'Bekliyor' | 'Gazlandı' | 'Gerek Yok' | 'Gazlanmayacak'>('Bekliyor');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>('EXTRA (V-20)');
  const [qualityStatus, setQualityStatus] = useState<'Ekstra / A Kalite' | 'Sınıf 1 / B Kalite' | 'Sınıf 2 / C Kalite' | 'Sanayi / Fire'>('Ekstra / A Kalite');
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>([]);
  
  // SCADA / PLC Banana Ripening Parameters (Kendall / Siemens)
  const [isScadaModalOpen, setIsScadaModalOpen] = useState<boolean>(false);
  const [ripeningScada, setRipeningScada] = useState<BananaScadaChamberData | undefined>({
    chamberId: 'NR1 Ripening Room',
    chamberType: 'RIPENING',
    ambientTemp1C: 19.1,
    ambientTemp2C: 19.0,
    pulpTemp1C: 17.6,
    pulpTemp2C: 17.6,
    ethylenePpm: 1.3,
    co2Ppm: 2553.1,
    humidityPercent: 82.0,
    activeStageIndex: 1,
    totalRunTimeHours: 151,
    elapsedTimeHours: 42,
    evaporatorFan1State: true,
    evaporatorFan2State: true,
    evapFinTempC: 2.5,
    defrostRemainingMin: 25,
    coolingStatusText: 'Kademeli Sarartma & Gazlama Devam Ediyor'
  });

  // Decision, Status & Next Step
  const [decision, setDecision] = useState('');
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>('COMPLETED');
  const [nextStep, setNextStep] = useState('');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);

  const currentStageInfo = BANANA_RIPENESS_STAGES.find(s => s.stage === ripenessScale) || BANANA_RIPENESS_STAGES[0];

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      try {
        const compressedUrls = await compressImageFiles(files, 1200, 0.78);
        setPhotos(prev => [...prev, ...compressedUrls.filter(Boolean)]);
      } catch (err) {
        console.error('Error compressing images:', err);
        files.forEach(file => {
          const reader = new FileReader();
          reader.onload = (event) => {
            if (event.target?.result) {
              setPhotos(prev => [...prev, event.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        });
      }
      e.target.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // v2.5: ölçülmemiş değerle kayıt yok — eksik alanlar listelenir
    const missing: string[] = [];
    if (!greenhouseNo.trim()) missing.push('Sera / Parsel');
    if (!ribbonColor) missing.push('Kurdele rengi');
    if (harvestAgeWeeks === null) missing.push('Hasat yaşı (hafta)');
    if (calibrationMm === null) missing.push('Kalibrasyon (mm)');
    if (fingerLengthCm === null) missing.push('Parmak boyu (cm)');
    if (pulpFirmness === null) missing.push('Meyve sertliği');
    if (pulpTemperatureC === null) missing.push('Meyve iç sıcaklığı');
    if (ripenessScale === null) missing.push('Olgunluk skalası');
    if (hasBrixTest && avgBrix === null) missing.push('En az bir Brix ölçümü');
    if (hasPpmTest && avgPpm === null) missing.push('En az bir PPM ölçümü');
    if (missing.length) {
      window.alert('Kaydetmeden önce şu ölçümleri girin:\n• ' + missing.join('\n• '));
      return;
    }
    const finalOperator = operator.trim() || getCurrentUser()?.fullName || 'Belirtilmedi';
    const finalProduct = product.trim() || 'Muz (Cavendish)';
    const finalGreenhouse = greenhouseNo.trim();

    let finalRefId = '';
    if (isEditing && initialRecord) {
      finalRefId = initialRecord.refId;
    } else if (isNewRef) {
      finalRefId = customRefInput.trim()
        ? customRefInput.trim()
        : generateRefId('MUZ', existingRefs.map(r => r.refId));
    } else {
      finalRefId = selectedRefId.trim() || customRefInput.trim() || generateRefId('MUZ', existingRefs.map(r => r.refId));
    }

    if (!finalRefId) {
      finalRefId = generateRefId('MUZ', []);
    }

    const muzRecord: MuzRecord = {
      id: (isEditing && initialRecord?.id) ? initialRecord.id : `m-${Date.now()}`,
      refId: finalRefId,
      timestamp: initialRecord?.timestamp || new Date().toISOString(),
      operator: finalOperator,
      product: finalProduct,
      greenhouseNo: finalGreenhouse,
      ribbonColor,
      bloomWeek: bloomWeek ?? undefined,
      harvestAgeWeeks: harvestAgeWeeks ?? undefined,
      fingerLengthCm: fingerLengthCm as number,
      calibrationMm: calibrationMm as number,
      fingerCountPerHand: fingerCountPerHand ?? (undefined as any),
      handPosition,
      clusterWeightKg: clusterWeightKg ?? undefined,
      ripenessScale: ripenessScale as number,
      pulpFirmness: pulpFirmness as number,
      pulpTemperatureC: pulpTemperatureC as number,
      brix: hasBrixTest ? (avgBrix ?? undefined) : undefined,
      brixSamples: hasBrixTest ? [brix1, brix2, brix3, brix4, brix5].filter((v): v is number => typeof v === 'number') : undefined,
      banana3PointBrix: hasBrixTest ? {
        topPoint: Number(banana3PointTop) || 0,
        middlePoint: Number(banana3PointMiddle) || 0,
        bottomPoint: Number(banana3PointBottom) || 0,
        avg3Point: banana3PointAvg
      } : undefined,
      avgBrix: hasBrixTest ? (avgBrix ?? undefined) : undefined,
      ppmTestType: hasPpmTest ? ppmTestType : undefined,
      ppmSamples: hasPpmTest ? [ppm1, ppm2, ppm3, ppm4, ppm5].filter((v): v is number => typeof v === 'number') : undefined,
      avgPpm: hasPpmTest ? (avgPpm ?? undefined) : undefined,
      angularity,
      flowerEndDefect,
      latexStain,
      mechanicalDamage,
      sunburnOrYellow,
      pestDamage,
      packaging,
      polybagType,
      mapPackaging,
      ethyleneAbsorber,
      netWeightKg: netWeightKg ?? (undefined as any),
      grossWeightKg: grossWeightKg ?? (undefined as any),
      roomNo,
      coolingStatus,
      gasStatus,
      qualityStatus,
      kaliteSinifi,
      ripeningScada,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      decision: decision || 'Kabul & Gazlama Odasına Sevk',
      testStatus,
      nextStep: nextStep || 'Olgunlaştırma & Paketleme',
      notes,
      photos
    };

    const newRefData: Partial<ReferenceItem> | undefined = (isNewRef && !isEditing)
      ? {
          refId: finalRefId,
          moduleKey: 'MUZ',
          product: finalProduct,
          location: finalGreenhouse,
          source: finalGreenhouse,
          destination: destination || '',
          quantity: netWeightKg ?? 0, // tartılmadıysa stok oluşmaz
          unit: 'kg',
          status: testStatus === 'COMPLETED' ? 'CREATED' : 'CREATED',
          createdAt: new Date().toISOString(),
          operator: finalOperator,
          notes: `Muz Kalite Kontrolü. Şerit: ${ribbonColor || '—'}, Kalibre: ${calibrationMm ?? '—'}mm, MAP: ${mapPackaging ? 'Var' : 'Yok'}, Etilen Absorber: ${ethyleneAbsorber ? 'Var' : 'Yok'}`
        }
      : undefined;

    onSave(muzRecord, isNewRef && !isEditing, newRefData);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      {/* Modern Header */}
      <div className="bg-slate-900 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-teal-500/20 border border-teal-400/30 text-teal-300 shrink-0">
            <Banana className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                🍌 Muz Kalite, Brix, PPM & Gazlama Test Modülü
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-extrabold uppercase bg-teal-950 text-teal-300 border border-teal-800">
                Hemsaýa • Erem™
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 line-clamp-2 sm:line-clamp-none">
              Brix şeker & PPM testleri, kalibrasyon, MAP & Etilen Absorber ve test ortalamaları takibi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">

        {/* Reference Selection & Mode */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 sm:gap-4 w-full max-w-full min-w-0">
          <div className="w-full md:w-auto min-w-0">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1.5">
              Referans ID (Mevcut partiye bağlayın veya yeni parti kodu yazın)
            </span>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
              <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${isNewRef ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                <input
                  type="radio"
                  checked={isNewRef}
                  onChange={() => setIsNewRef(true)}
                  className="text-amber-700 focus:ring-amber-500 shrink-0"
                />
                <span>Yeni Referans Oluştur</span>
              </label>

              <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${!isNewRef ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                <input
                  type="radio"
                  checked={!isNewRef}
                  onChange={() => setIsNewRef(false)}
                  className="text-amber-700 focus:ring-amber-500 shrink-0"
                />
                <span>Mevcut Referansa Bağla / Seç</span>
              </label>
            </div>
          </div>

          <div className="w-full md:w-auto min-w-0">
            {isNewRef ? (
              <input
                type="text"
                value={customRefInput}
                onChange={(e) => setCustomRefInput(e.target.value)}
                placeholder="Otomatik (MUZ-...) veya Özel Kod Yazın"
                className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-amber-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-amber-500 max-w-full"
              />
            ) : (
              <div className="space-y-1 w-full min-w-0">
                <input
                  type="text"
                  list="existing-refs-list"
                  value={selectedRefId}
                  onChange={(e) => setSelectedRefId(e.target.value)}
                  placeholder="RefID Seçin veya Klavyeden Yazın"
                  className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-amber-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-amber-500 max-w-full truncate"
                />
                <datalist id="existing-refs-list">
                  {existingRefs.map(r => (
                    <option key={r.refId} value={r.refId}>
                      {r.refId} — {r.product} [{r.quantity} {r.unit}]
                    </option>
                  ))}
                </datalist>
              </div>
            )}
          </div>
        </div>

        {/* General Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Operatör Adı *
            </label>
            <input
              type="text"
              list="operators-list"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
              placeholder="Adınızı giriniz"
             
              className="w-full text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
            <datalist id="operators-list">
              {AUTOCOMPLETE_LISTS.operators.map(op => (
                <option key={op} value={op} />
              ))}
            </datalist>
          </div>

          <div>
            <SmartCreatableSelect
              label="Sera No / Sektör"
              categoryKey="greenhouses"
              options={[]}
              value={greenhouseNo}
              onChange={setGreenhouseNo}
              placeholder="Sera seçin veya yeni ekleyin..."
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Şerit Rengi (Ribbon / Hafta)
            </label>
            <input
              type="text"
              list="ribbons-list"
              value={ribbonColor}
              onChange={(e) => setRibbonColor(e.target.value)}
              placeholder="Şerit rengi seçin veya girin"
              className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
            <datalist id="ribbons-list">
              {AUTOCOMPLETE_LISTS.ribbons.map(r => (
                <option key={r} value={r} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Hasat Yaşı (Hafta)
            </label>
            <input
              type="number"
              value={harvestAgeWeeks ?? ''}
              onChange={(e) => setHarvestAgeWeeks(e.target.value === '' ? null : Number(e.target.value))}
              className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <div>
            <SmartCreatableSelect
              label="Hedef Tesis / Destination (Opsiyonel)"
              categoryKey="destinations"
              options={[]}
              value={destination}
              onChange={setDestination}
              placeholder="Hedef tesis seçin veya yeni ekleyin..."
            />
          </div>
        </div>

        {/* Morfolojik Ölçümler & Olgunluk Skalası */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 space-y-4">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-700" />
            <span>Fiziksel Kalibrasyon & Olgunluk Testi</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Parmak Kalibrasyonu (mm) [Hedef: 39-44 mm]
              </label>
              <input
                type="number"
                step="0.1"
                value={calibrationMm ?? ''}
                onChange={(e) => setCalibrationMm(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Parmak Uzunluğu (cm) [Hedef: &gt;20 cm]
              </label>
              <input
                type="number"
                step="0.1"
                value={fingerLengthCm ?? ''}
                onChange={(e) => setFingerLengthCm(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Meyve Eti Sertliği (kg/cm²)
              </label>
              <input
                type="number"
                step="0.1"
                value={pulpFirmness ?? ''}
                onChange={(e) => setPulpFirmness(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Meyve İçi Sıcaklığı (°C) [Hedef: 13.5-14.5°C]
              </label>
              <input
                type="number"
                step="0.1"
                value={pulpTemperatureC ?? ''}
                onChange={(e) => setPulpTemperatureC(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Olgunluk Skalası Seçici */}
          <div className="pt-2">
            <label className="block text-[11px] font-bold text-slate-700 mb-2">
              Muz Olgunluk Skalası (1: Sert Yeşil Hasat - 7: Sarı Benekli):
            </label>
            <div className="grid grid-cols-7 gap-1.5">
              {BANANA_RIPENESS_STAGES.map((s) => (
                <button
                  key={s.stage}
                  type="button"
                  onClick={() => setRipenessScale(s.stage)}
                  className={`p-2 rounded-lg text-center border transition ${
                    ripenessScale === s.stage
                      ? 'border-amber-600 bg-amber-50 ring-2 ring-amber-500 shadow-sm'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div
                    className="w-full h-3 rounded mb-1"
                    style={{ backgroundColor: s.colorHex }}
                  />
                  <div className="text-[11px] font-bold text-slate-800">{s.stage}</div>
                  <div className="text-[9px] text-slate-500 truncate">{s.nameTr.split(' ')[0]}</div>
                </button>
              ))}
            </div>
            <div className="mt-2 text-xs font-bold text-emerald-800 bg-emerald-50/80 px-3 py-1.5 rounded-lg border border-emerald-200">
              {ripenessScale === null ? 'Olgunluk aşaması seçilmedi' : <>Seçilen Aşama {currentStageInfo.stage}: <strong>{currentStageInfo.nameTr}</strong> — {currentStageInfo.description}</>}
            </div>
          </div>
        </div>

        {/* ===================== BRIX & PPM TESTLERİ VE TEST ORTALAMALARI (SEÇMELİ) ===================== */}
        <div className="border border-teal-200 bg-teal-50/40 rounded-xl p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-teal-200/80 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-teal-600 text-white shadow-sm">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-teal-950">
                  🔬 Muz Brix (°Bx) Şeker & PPM Gaz/Kimyasal Testleri
                </h3>
                <p className="text-[11px] text-teal-800/80">
                  İhtiyaca göre seçmeli: Refraktometre şeker analizi ve gazlama/oda ortamı PPM ölçümleri (Her partiye yapılmayabilir)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center bg-white border border-teal-300 rounded-xl p-0.5 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setHasBrixTest(true)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer ${
                    hasBrixTest
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ✓ Brix Yapıldı
                </button>
                <button
                  type="button"
                  onClick={() => setHasBrixTest(false)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                    !hasBrixTest
                      ? 'bg-slate-200 text-slate-800'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  ○ Yapılmadı
                </button>
              </div>

              <div className="flex items-center bg-white border border-cyan-300 rounded-xl p-0.5 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setHasPpmTest(true)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer ${
                    hasPpmTest
                      ? 'bg-cyan-700 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ✓ PPM Yapıldı
                </button>
                <button
                  type="button"
                  onClick={() => setHasPpmTest(false)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                    !hasPpmTest
                      ? 'bg-slate-200 text-slate-800'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  ○ Yapılmadı
                </button>
              </div>

              {hasBrixTest && (
                <span className="px-2.5 py-1 rounded-md text-[11px] font-extrabold bg-teal-100 text-teal-900 border border-teal-300">
                  Ort. Brix: <strong className="font-mono text-teal-950">{avgBrix ?? '—'} °Bx</strong>
                </span>
              )}
              {hasPpmTest && (
                <span className="px-2.5 py-1 rounded-md text-[11px] font-extrabold bg-cyan-100 text-cyan-900 border border-cyan-300">
                  Ort. PPM: <strong className="font-mono text-cyan-950">{avgPpm ?? '—'} ppm</strong>
                </span>
              )}
            </div>
          </div>

          {!hasBrixTest && !hasPpmTest && (
            <div className="py-6 px-4 text-center bg-white/70 rounded-xl border border-dashed border-teal-200">
              <p className="text-xs font-bold text-teal-900">
                Bu muz partisinde Brix ve PPM ölçümleri pasif durumda (İsteğe bağlı test).
              </p>
              <p className="text-[11px] text-teal-700 mt-1">
                Refraktometre veya gaz/kimyasal ölçümü yapıldığında yukarıdaki butonlardan ilgili testi aktif edebilirsiniz.
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* 1. BRIX TESTİ (MUZ MEYVESİ 3 NOKTA + 5 NUMUNE TARAMASI) */}
            {hasBrixTest && (
            <div className="bg-white border border-teal-200/80 rounded-xl p-4 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                  🍌 Muz Meyvesi 3 Nokta Brix Ölçümü (Sap, Gövde, Uç)
                </span>
                <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                  Muz Standardı: 3 Bölge Ölçümü
                </span>
              </div>

              {/* 3-Zone Banana Visual Card */}
              <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3 space-y-2">
                <p className="text-[11px] font-bold text-amber-900 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                  <span>Tek Muz Meyvesinde 3 Noktadan Refraktometre Şeker Analizi:</span>
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  {/* Point 1: Sap / Üst */}
                  <div className="bg-white p-2.5 rounded-lg border border-amber-300 shadow-2xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-extrabold text-amber-900 uppercase">1. Sap / Üst Kısım</span>
                      <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">Proximal</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="0.1"
                        value={banana3PointTop ?? ''}
                        onChange={(e) => setBanana3PointTop(e.target.value === '' ? null : Number(e.target.value))}
                        className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded py-1 focus:bg-white focus:ring-2 focus:ring-teal-500"
                      />
                      <span className="text-[10px] font-bold text-slate-500">°Bx</span>
                    </div>
                  </div>

                  {/* Point 2: Orta Gövde */}
                  <div className="bg-white p-2.5 rounded-lg border border-amber-300 shadow-2xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-extrabold text-amber-900 uppercase">2. Orta Gövde</span>
                      <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">Middle</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="0.1"
                        value={banana3PointMiddle ?? ''}
                        onChange={(e) => setBanana3PointMiddle(e.target.value === '' ? null : Number(e.target.value))}
                        className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded py-1 focus:bg-white focus:ring-2 focus:ring-teal-500"
                      />
                      <span className="text-[10px] font-bold text-slate-500">°Bx</span>
                    </div>
                  </div>

                  {/* Point 3: Alt / Uç */}
                  <div className="bg-white p-2.5 rounded-lg border border-amber-300 shadow-2xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-extrabold text-amber-900 uppercase">3. Uç / Alt Kısım</span>
                      <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">Distal</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="0.1"
                        value={banana3PointBottom ?? ''}
                        onChange={(e) => setBanana3PointBottom(e.target.value === '' ? null : Number(e.target.value))}
                        className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded py-1 focus:bg-white focus:ring-2 focus:ring-teal-500"
                      />
                      <span className="text-[10px] font-bold text-slate-500">°Bx</span>
                    </div>
                  </div>
                </div>

                <div className="bg-emerald-100/90 border border-emerald-300 rounded-lg p-2 flex items-center justify-between text-xs mt-1">
                  <span className="text-emerald-950 font-extrabold text-[11px]">Tek Meyve 3 Nokta Brix Ortalaması:</span>
                  <span className="font-mono font-black text-emerald-900 text-sm">
                    {banana3PointAvg} °Bx
                  </span>
                </div>
              </div>

              {/* 5 Numune Meyve Taraması */}
              <div className="space-y-2 pt-1 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700">5 Numune Parti Refraktometre Taraması:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setBrix1(banana3PointAvg);
                    }}
                    className="text-[10px] font-bold text-teal-700 hover:text-teal-900 underline"
                  >
                    3 Nokta Ortalamasını Numune 1'e Aktar
                  </button>
                </div>

                <div className="grid grid-cols-5 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Numune 1</label>
                    <input
                      type="number"
                      step="0.1"
                      value={brix1 ?? ''}
                      onChange={(e) => setBrix1(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Numune 2</label>
                    <input
                      type="number"
                      step="0.1"
                      value={brix2 ?? ''}
                      onChange={(e) => setBrix2(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Numune 3</label>
                    <input
                      type="number"
                      step="0.1"
                      value={brix3 ?? ''}
                      onChange={(e) => setBrix3(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Numune 4</label>
                    <input
                      type="number"
                      step="0.1"
                      value={brix4 ?? ''}
                      onChange={(e) => setBrix4(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Numune 5</label>
                    <input
                      type="number"
                      step="0.1"
                      value={brix5 ?? ''}
                      onChange={(e) => setBrix5(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex items-center justify-between text-xs">
                <span className="text-slate-600 font-semibold">Genel Parti Ortalama Brix:</span>
                <span className="font-mono font-black text-teal-800 text-sm">
                  {avgBrix ?? '—'} °Bx
                </span>
              </div>
            </div>
            )}

            {/* 2. PPM TESTİ (5 NOKTA/NUMUNE) */}
            {hasPpmTest && (
            <div className="bg-white border border-teal-200/80 rounded-xl p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-500"></span>
                  PPM Gaz / Kimyasal Testi — 5 Nokta
                </span>
                <select
                  value={ppmTestType}
                  onChange={(e) => setPpmTestType(e.target.value)}
                  className="text-[11px] font-bold text-teal-900 bg-teal-50 border border-teal-300 rounded-md px-2 py-0.5"
                >
                  <option value="Etilen Gazlama Seviyesi (ppm)">Etilen Gazlama (ppm)</option>
                  <option value="Oda CO2 / Gaz Seviyesi (ppm)">Oda CO2 Seviyesi (ppm)</option>
                  <option value="Ozon Dezenfeksiyonu (ppm)">Ozon / Gazlama (ppm)</option>
                  <option value="Yıkama Havuzu Klor (ppm)">Yıkama Havuzu Klor (ppm)</option>
                </select>
              </div>

              <div className="grid grid-cols-5 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Nokta 1</label>
                  <input
                    type="number"
                    value={ppm1 ?? ''}
                    onChange={(e) => setPpm1(e.target.value === '' ? null : Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Nokta 2</label>
                  <input
                    type="number"
                    value={ppm2 ?? ''}
                    onChange={(e) => setPpm2(e.target.value === '' ? null : Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Nokta 3</label>
                  <input
                    type="number"
                    value={ppm3 ?? ''}
                    onChange={(e) => setPpm3(e.target.value === '' ? null : Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Nokta 4</label>
                  <input
                    type="number"
                    value={ppm4 ?? ''}
                    onChange={(e) => setPpm4(e.target.value === '' ? null : Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 text-center">Nokta 5</label>
                  <input
                    type="number"
                    value={ppm5 ?? ''}
                    onChange={(e) => setPpm5(e.target.value === '' ? null : Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold text-center bg-slate-50 border border-slate-300 rounded-lg py-1.5 focus:bg-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex items-center justify-between text-xs">
                <span className="text-slate-600 font-semibold truncate">Ortalama PPM Değeri:</span>
                <span className="font-mono font-black text-cyan-800 text-sm">
                  {avgPpm ?? '—'} ppm
                </span>
              </div>
            </div>
            )}
          </div>

          {/* TEST ORTALAMALARI VE ANALİZ ÖZET KARTI */}
          <div className="bg-gradient-to-r from-slate-900 to-teal-950 rounded-xl p-4 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-300 block mb-0.5">
                📊 Test Ortalamaları & Kalite Analiz Özeti
              </span>
              <div className="flex items-center gap-3 text-xs text-slate-200">
                <span>Parti: <strong>{isNewRef ? (customRefInput || '') : selectedRefId}</strong></span>
                <span>•</span>
                <span>Sıcaklık: <strong className="text-amber-300 font-mono">{pulpTemperatureC ?? '—'}°C</strong></span>
                <span>•</span>
                <span>Sertlik: <strong className="text-emerald-300 font-mono">{pulpFirmness ?? '—'} kg/cm²</strong></span>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="bg-white/10 border border-white/15 px-3 py-1.5 rounded-lg text-center">
                <span className="text-[9px] uppercase tracking-wider text-teal-200 block">Ort. Brix</span>
                <span className="text-xs font-mono font-bold text-teal-300">{avgBrix ?? '—'} °Bx</span>
              </div>
              <div className="bg-white/10 border border-white/15 px-3 py-1.5 rounded-lg text-center">
                <span className="text-[9px] uppercase tracking-wider text-cyan-200 block">Ort. PPM</span>
                <span className="text-xs font-mono font-bold text-cyan-300">{avgPpm ?? '—'} ppm</span>
              </div>
              <div className="bg-white/10 border border-white/15 px-3 py-1.5 rounded-lg text-center">
                <span className="text-[9px] uppercase tracking-wider text-amber-200 block">Kalibrasyon</span>
                <span className="text-xs font-mono font-bold text-amber-300">{calibrationMm ?? '—'} mm</span>
              </div>
            </div>
          </div>
        </div>

        {/* ===================== SIEMENS & KENDALL SCADA SARARTMA ODASI & SOĞUK ZİNCİR ENTEGRASYONU ===================== */}
        <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-amber-500/40 shadow-md space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xs sm:text-sm font-black text-amber-300 tracking-wide flex items-center gap-1.5">
                    Siemens & Kendall SCADA • Sarartma Odası & Soğuk Hava Telemetrisi
                  </h3>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-700">
                    PLC LIVE
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Sarartma odası meyve eti sıcaklığı, C2H4 etilen dozajı, CO2 seviyesi ve 7-Aşama eğrisi
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsScadaModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs transition shadow-sm cursor-pointer shrink-0"
            >
              <Sliders className="w-4 h-4 text-slate-950" />
              <span>SCADA Parametrelerini Aç & Düzenle</span>
            </button>
          </div>

          {ripeningScada && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 font-mono text-xs">
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">Oda & Modül</div>
                <div className="font-bold text-amber-400 truncate mt-0.5">{ripeningScada.chamberId}</div>
              </div>
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">Meyve Eti (Pulp)</div>
                <div className="font-bold text-teal-300 mt-0.5">{ripeningScada.pulpTemp1C} °C</div>
              </div>
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">Oda Sıcaklığı</div>
                <div className="font-bold text-blue-300 mt-0.5">{ripeningScada.ambientTemp1C} °C</div>
              </div>
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">Etilen C2H4</div>
                <div className="font-bold text-amber-300 mt-0.5">{ripeningScada.ethylenePpm} ppm</div>
              </div>
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">CO2 & Nem</div>
                <div className="font-bold text-emerald-300 mt-0.5">{ripeningScada.humidityPercent}% • {ripeningScada.co2Ppm}ppm</div>
              </div>
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-400 font-sans">Aşama Programı</div>
                <div className="font-bold text-purple-300 mt-0.5">{ripeningScada.activeStageIndex}. Aşama / {ripeningScada.totalRunTimeHours}h</div>
              </div>
            </div>
          )}
        </div>

        {/* ===================== PAKETLEME, MAP & ETİLEN ABSORBER DETAYLARI ===================== */}
        <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4 space-y-4">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
            <Box className="w-4 h-4 text-emerald-700" />
            <span>Paketleme, MAP & Etilen Absorber Standartları</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Ambalaj Tipi
              </label>
              <input
                type="text"
                value={packaging}
                onChange={(e) => setPackaging(e.target.value)}
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Poşet / Torba Tipi
              </label>
              <select
                value={polybagType}
                onChange={(e) => setPolybagType(e.target.value as any)}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Vakumlu Banavac">Vakumlu Banavac (Tavsiye Edilen)</option>
                <option value="Delikli Polietilen">Delikli Polietilen</option>
                <option value="Açık Dökme">Açık Dökme / Poşetsiz</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Net Ağırlık (kg)
              </label>
              <input
                type="number"
                value={netWeightKg ?? ''}
                placeholder="tartılmadı"
                onChange={(e) => setNetWeightKg(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Hedef Oda / Ön Soğutma
              </label>
              <input
                type="text"
                value={roomNo}
                onChange={(e) => setRoomNo(e.target.value)}
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* MAP ve Etilen Absorber Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <label className="flex items-center gap-3 p-3 rounded-xl bg-white border border-emerald-200 cursor-pointer shadow-sm hover:bg-emerald-50/50 transition">
              <input
                type="checkbox"
                checked={mapPackaging}
                onChange={(e) => setMapPackaging(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
              />
              <div>
                <span className="text-xs font-bold text-emerald-950 block flex items-center gap-1.5">
                  <Wind className="w-3.5 h-3.5 text-emerald-600" />
                  MAP (Modifiye Atmosfer Paketleme) Uygulandı
                </span>
                <span className="text-[10px] text-slate-500">
                  Oksijen düşürme ve CO2 dengeleme ile yeşil kalma süresini uzatır
                </span>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 rounded-xl bg-white border border-emerald-200 cursor-pointer shadow-sm hover:bg-emerald-50/50 transition">
              <input
                type="checkbox"
                checked={ethyleneAbsorber}
                onChange={(e) => setEthyleneAbsorber(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
              />
              <div>
                <span className="text-xs font-bold text-emerald-950 block flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  KMnO4 Etilen Absorber Şase Eklendi
                </span>
                <span className="text-[10px] text-slate-500">
                  Kutu içi serbest etilen gazını emerek erken sararmayı önler
                </span>
              </div>
            </label>
          </div>
        </div>

        {/* Karar, Sonraki Adım & Durum */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Kalite Değerlendirme Kararı
              </label>
              <input
                type="text"
                list="muz-decisions"
                value={decision}
                onChange={(e) => setDecision(e.target.value)}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
              <datalist id="muz-decisions">
                <option value="Uygun (Sevkiyata Hazır)" />
                <option value="Ön Soğutmaya Sevk" />
                <option value="Gazlama Odasına Alınacak" />
                <option value="Şartlı Kabul (İç Piyasa)" />
                <option value="Karantina / İnceleme" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Sonraki Adım (Seçiniz veya yazınız)
              </label>
              <input
                type="text"
                list="muz-next-steps"
                value={nextStep}
                onChange={(e) => setNextStep(e.target.value)}
                placeholder="Seçiniz veya yazınız"
               
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
              <datalist id="muz-next-steps">
                <option value="Ön Soğutma & Frigorifik Lojistik Sevk" />
                <option value="Gazlama Odasına Transfer (Etilen Uygulama)" />
                <option value="Soğuk Depoda Dinlendirme (13.5°C)" />
                <option value="İç Piyasa Hızlı Sevk" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Referans İşlem Durumu
              </label>
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setTestStatus('ACTIVE')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'ACTIVE'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Aktif (İşlemde)
                </button>
                <button
                  type="button"
                  onClick={() => setTestStatus('COMPLETED')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'COMPLETED'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Tamamlandı
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Notlar */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Notlar & Gözlemler
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Sera içi nemi, lateks temizliği, taç kesim kalitesi..."
            className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-3 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
          />
        </div>

        {/* İnteraktif Kalite Standartları, Kasa Tipi & Hedef Pazar (Export / Yerel) İzlenebilirlik Eşleştirmesi (Alt Bölüme Alındı) */}
        <div className="pt-2">
          {harvestAgeWeeks === null || calibrationMm === null || fingerLengthCm === null || ripenessScale === null || pulpTemperatureC === null ? (
            <p className="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-xl p-3">
              Karar önerisi için hasat yaşı, kalibrasyon, parmak boyu, olgunluk ve meyve sıcaklığını girin.
            </p>
          ) : (
          <InteractiveBananaQualityTraceabilityWidget
            greenhouseNo={greenhouseNo}
            ribbonColor={ribbonColor}
            harvestAgeWeeks={harvestAgeWeeks}
            calibrationMm={calibrationMm}
            fingerLengthCm={fingerLengthCm}
            ripenessScale={ripenessScale}
            pulpTemperatureC={pulpTemperatureC}
            mapPackaging={mapPackaging}
            ethyleneAbsorber={ethyleneAbsorber}
            netWeightKg={netWeightKg ?? 0}
            packaging={packaging}
            kaliteSinifi={kaliteSinifi}
            onApplyDecisionToForm={(dec) => {
              setPackaging(dec.crateType);
              setKaliteSinifi(dec.kaliteSinifi);
              setQualityStatus(dec.qualityStatus);
              setMapPackaging(dec.mapPackaging);
              setEthyleneAbsorber(dec.ethyleneAbsorber);
              setPolybagType(dec.polybagType);
              setDestination(dec.destination);
              if (dec.calibrationMm !== undefined) setCalibrationMm(dec.calibrationMm);
              if (dec.fingerLengthCm !== undefined) setFingerLengthCm(dec.fingerLengthCm);
              if (dec.harvestAgeWeeks !== undefined) setHarvestAgeWeeks(dec.harvestAgeWeeks);
            }}
          />
          )}
        </div>

        {/* Fotoğraf Ekle */}
        <div className="border-t border-slate-200 pt-4">
          <label className="block text-xs font-bold text-slate-700 mb-2">
            Fotoğraf / Numune Dosyası Ekle
          </label>
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* 1. Kamera Butonu */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer transition shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Fotoğraf Çek</span>
            </button>

            {/* 2. Galeri Butonu */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition shadow-2xs"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>Galeriden Seç</span>
            </button>

            {/* Gizli Kamera Girişi */}
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleAddPhoto}
              className="hidden"
            />

            {/* Gizli Galeri Girişi (multiple destekli) */}
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleAddPhoto}
              className="hidden"
            />

            {photos.filter(p => p && p.length > 20).map((p, idx) => (
              <div key={idx} className="relative w-14 h-14 rounded-lg overflow-hidden border border-slate-300 shadow-sm group">
                <img src={p} alt="Muz Foto" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setPhotos(prev => prev.filter((_, i) => i !== idx))}
                  className="absolute inset-0 bg-red-900/70 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center text-[10px] font-bold transition"
                >
                  Sil
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-[#5c1d24] hover:bg-[#43141a] text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition`}
          >
            <Save className="w-4 h-4" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'KAYDET VE İLERLET'}</span>
          </button>
        </div>
        </fieldset>

      </form>

      {/* Siemens & Kendall SCADA Ripening Modal */}
      <BananaRipeningScadaModal
        isOpen={isScadaModalOpen}
        onClose={() => setIsScadaModalOpen(false)}
        initialData={ripeningScada}
        onApplyScadaData={(data) => {
          setRipeningScada(data);
          if (data.pulpTemp1C) setPulpTemperatureC(data.pulpTemp1C);
          if (data.chamberId) setRoomNo(data.chamberId);
        }}
      />
    </div>
  );
};
