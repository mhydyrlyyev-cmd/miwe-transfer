import React, { useState, useEffect, useRef } from 'react';
import {
  Nut,
  ArrowLeft,
  Camera,
  Image as ImageIcon,
  Save,
  Calculator,
  Percent,
  ShieldAlert,
  CheckCircle,
  Droplets,
  Sparkles,
  Scale,
  AlertTriangle,
  Layers,
  Calendar,
  SunMedium,
  Info,
  Lock,
  Unlock,
  RotateCcw
} from 'lucide-react';
import { BademRecord, ReferenceItem, HarvestRecord, SplitLotItem, STANDARD_QUALITY_CLASSES, ActiveFieldContext } from '../../types';
import { calculateAlmondYield, calculateAlmondDefects, generateRefId } from '../../utils/calculations';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';

interface BademFormProps {
  onSave: (record: BademRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: BademRecord;
  bademRecords?: BademRecord[];
  harvestRecords?: HarvestRecord[];
  activeFieldContext?: ActiveFieldContext | null;
  isReadOnly?: boolean;
}

export const BademForm: React.FC<BademFormProps> = ({
  onSave,
  onCancel,
  existingRefs = [],
  initialRefId,
  initialRecord,
  bademRecords = [],
  harvestRecords = [],
  activeFieldContext,
  isReadOnly = false
}) => {
  const isEditing = Boolean(initialRecord);
  const [isNewRef, setIsNewRef] = useState(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || (existingRefs[0]?.refId ?? ''));
  const [customRefInput, setCustomRefInput] = useState(initialRecord?.refId || '');

  // Section Lock / Unlock States (prevents re-entering completed/tested data)
  const [isGeneralLocked, setIsGeneralLocked] = useState<boolean>(false);
  const [isHarvestLocked, setIsHarvestLocked] = useState<boolean>(false);
  const [isDryingLocked, setIsDryingLocked] = useState<boolean>(false);
  const [isLabLocked, setIsLabLocked] = useState<boolean>(false);

  // Operator & Origin (Auto-populated from activeFieldContext if selected in Gantt or Header)
  const [operator, setOperator] = useState(initialRecord?.operator || AUTOCOMPLETE_LISTS.operators[0] || '');
  const [product, setProduct] = useState(initialRecord?.product || 'Badem');
  const [variety, setVariety] = useState(initialRecord?.variety || activeFieldContext?.variety || 'Nonpareil');
  const [location, setLocation] = useState(
    initialRecord?.location || activeFieldContext?.location || activeFieldContext?.parcelCode || 'Miweli Atyz Badem Plantasyonu (Kaka)'
  );
  const [testStage, setTestStage] = useState<'Hasat Öncesi / Hasat Testi' | 'Yerde Kurutma Aşaması' | 'Laboratuvar Randıman & Kalite'>('Hasat Öncesi / Hasat Testi');
  
  // ===================== ADIM 1: HASAT TESTİ BİLGİLERİ =====================
  const [waterCutOffDate, setWaterCutOffDate] = useState("");
  const [hullSplitPercent, setHullSplitPercent] = useState<number | null>((initialRecord as any)?.hullSplitPercent ?? null); // Ağacın meyve açma oranı % (hedef >%70)
  const [fruitMoisturePercent, setFruitMoisturePercent] = useState<number | null>((initialRecord as any)?.fruitMoisturePercent ?? null); // Meyvenin nem oranı % (9-15% hasata uygun)
  const [sampleFruitCount, setSampleFruitCount] = useState<number | null>((initialRecord as any)?.sampleFruitCount ?? null); // Kaç meyve
  const [sampleFruitWeightGram, setSampleFruitWeightGram] = useState<number | null>((initialRecord as any)?.sampleFruitWeightGram ?? null); // Kaç gram

  // Otomatik Hasat Uygunluk Hesabı
  const isHarvestReady = hullSplitPercent != null && fruitMoisturePercent != null && hullSplitPercent >= 70 && fruitMoisturePercent >= 9 && fruitMoisturePercent <= 15;
  const harvestReadinessStatus: 'Hasata Uygun' | 'Erken / Beklemeli' | 'Geç' = isHarvestReady 
    ? 'Hasata Uygun' 
    : (hullSplitPercent == null || fruitMoisturePercent == null || hullSplitPercent < 70 || fruitMoisturePercent > 15 ? 'Erken / Beklemeli' : 'Geç');

  // ===================== ADIM 2: YERDE KURUTMA BİLGİLERİ =====================
  const [dryingStage, setDryingStage] = useState('');
  const [kernelMoisturePercent, setKernelMoisturePercent] = useState<number | null>((initialRecord as any)?.kernelMoisturePercent ?? null); // İç Kernel Nemi (%4.5 - %6.0 hedef)
  const [dryingNextStep, setDryingNextStep] = useState<'Depolama (Kuru Depo Stok Kaydı)' | 'Badem İşleme / Kırma Alanı' | string>('Depolama (Kuru Depo Stok Kaydı)');

  const isDryingComplete = kernelMoisturePercent != null && kernelMoisturePercent >= 4.5 && kernelMoisturePercent <= 6.0;

  // ===================== ADIM 3: LAB RANDIMAN & KALİTE BİLGİLERİ =====================
  const [calibre, setCalibre] = useState('');
  const [kernelCountPerOz, setKernelCountPerOz] = useState<number | null>((initialRecord as any)?.kernelCountPerOz ?? null);
  const [destination, setDestination] = useState('');
  const [totalLoadKg, setTotalLoadKg] = useState<number | null>((initialRecord as any)?.totalLoadKg ?? null);

  // Lab Weights & Chemistry
  const [sampleGram, setSampleGram] = useState<number | null>((initialRecord as any)?.sampleGram ?? null);
  const [kernelGram, setKernelGram] = useState<number | null>((initialRecord as any)?.kernelGram ?? null);
  const [moisturePercent, setMoisturePercent] = useState<number | null>((initialRecord as any)?.moisturePercent ?? null);
  const [waterActivityAw, setWaterActivityAw] = useState<number | null>((initialRecord as any)?.waterActivityAw ?? null);
  // v2.5: gıda güvenliği sonucu ASLA önceden 'Negatif' gelmez; test sonucu seçilmelidir
  const [aflatoxinTest, setAflatoxinTest] = useState<'' | 'Negatif (<2 ppb)' | 'İnceleniyor' | 'Pozitif (>4 ppb)'>(((initialRecord as any)?.aflatoxinTest as any) || '');
  const [phenologicalStage, setPhenologicalStage] = useState('');

  // Defect Breakdown (Grams)
  const [defWholeGram, setDefWholeGram] = useState<number>(312);
  const [defDoubleGram, setDefDoubleGram] = useState<number>(12);
  const [defMechanicalGram, setDefMechanicalGram] = useState<number>(8);
  const [defForeignGram, setDefForeignGram] = useState<number>(1);
  const [defDustGram, setDustGram] = useState<number>(2);
  const [defBrokenGram, setDefBrokenGram] = useState<number>(4);
  const [defSeriousGram, setDefSeriousGram] = useState<number>(1); // Serious defects (mold, insect, rot)
  const [defUndersizeGram, setDefUndersizeGram] = useState<number>(2);
  const [defGumGram, setDefGumGram] = useState<number>(1); // Gam/Reçine
  const [defInsectGram, setDefInsectGram] = useState<number>(1); // Kurt/Zararlı

  const [classification, setClassification] = useState<'Ekstra' | 'Sınıf 1' | 'Sınıf 2' | 'Sanayi / Yağlık'>('Ekstra');
  const [kaliteSinifi, setKaliteSinifi] = useState<string>('EXTRA (V-20)');
  const [storageRecommendation, setStorageRecommendation] = useState('');
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>('COMPLETED');
  const [nextStep, setNextStep] = useState("");
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>([]);
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);

  // Live Calculations
  const kernelYieldPercent = sampleGram && kernelGram != null ? calculateAlmondYield(sampleGram, kernelGram) : 0;
  const totalDefectsGram = defDoubleGram + defMechanicalGram + defForeignGram + defDustGram + defBrokenGram + defSeriousGram + defUndersizeGram + defGumGram + defInsectGram;
  const { seriousPercent, totalPercent } = calculateAlmondDefects(sampleGram || 1, defSeriousGram + defInsectGram, totalDefectsGram);

  // Auto-fill and lock when selecting an existing reference
  const populateFromSelectedRef = (refId: string) => {
    if (!refId) return;
    const bRec = bademRecords.find(b => b.refId === refId);
    const hRec = harvestRecords.find(h => h.refId === refId);
    const rItem = existingRefs.find(r => r.refId === refId);

    if (bRec) {
      if (bRec.operator) setOperator(bRec.operator);
      if (bRec.variety) setVariety(bRec.variety);
      if (bRec.location) setLocation(bRec.location);
      if (bRec.totalLoadKg) setTotalLoadKg(bRec.totalLoadKg);
      if (bRec.testStage) setTestStage(bRec.testStage as any);

      // Step 1: Hasat Testi
      if (bRec.waterCutOffDate) setWaterCutOffDate(bRec.waterCutOffDate);
      if (bRec.hullSplitPercent !== undefined) setHullSplitPercent(bRec.hullSplitPercent);
      if (bRec.fruitMoisturePercent !== undefined) setFruitMoisturePercent(bRec.fruitMoisturePercent);
      if (bRec.sampleFruitCount !== undefined) setSampleFruitCount(bRec.sampleFruitCount);
      if (bRec.sampleFruitWeightGram !== undefined) setSampleFruitWeightGram(bRec.sampleFruitWeightGram);

      // Step 2: Yerde Kurutma
      if (bRec.dryingStage) setDryingStage(bRec.dryingStage);
      if (bRec.kernelMoisturePercent !== undefined) setKernelMoisturePercent(bRec.kernelMoisturePercent);
      if (bRec.dryingNextStep) setDryingNextStep(bRec.dryingNextStep);

      // Step 3: Lab Randıman
      if (bRec.calibre) setCalibre(bRec.calibre);
      if (bRec.kernelCountPerOz !== undefined) setKernelCountPerOz(bRec.kernelCountPerOz);
      if (bRec.sampleGram !== undefined) setSampleGram(bRec.sampleGram);
      if (bRec.kernelGram !== undefined) setKernelGram(bRec.kernelGram);
      if (bRec.moisturePercent !== undefined) setMoisturePercent(bRec.moisturePercent);
      if (bRec.waterActivityAw !== undefined) setWaterActivityAw(bRec.waterActivityAw);
      if (bRec.aflatoxinTest) setAflatoxinTest(bRec.aflatoxinTest as any);
      if (bRec.phenologicalStage) setPhenologicalStage(bRec.phenologicalStage);

      // Defects
      if (bRec.defWholeGram !== undefined) setDefWholeGram(bRec.defWholeGram);
      if (bRec.defDoubleGram !== undefined) setDefDoubleGram(bRec.defDoubleGram);
      if (bRec.defMechanicalGram !== undefined) setDefMechanicalGram(bRec.defMechanicalGram);
      if (bRec.defForeignGram !== undefined) setDefForeignGram(bRec.defForeignGram);
      if (bRec.defDustGram !== undefined) setDustGram(bRec.defDustGram);
      if (bRec.defBrokenGram !== undefined) setDefBrokenGram(bRec.defBrokenGram);
      if (bRec.defSeriousGram !== undefined) setDefSeriousGram(bRec.defSeriousGram);
      if (bRec.defUndersizeGram !== undefined) setDefUndersizeGram(bRec.defUndersizeGram);
      if (bRec.defGumGram !== undefined) setDefGumGram(bRec.defGumGram);
      if (bRec.defInsectGram !== undefined) setDefInsectGram(bRec.defInsectGram);

      if (bRec.classification) setClassification(bRec.classification as any);
      if (bRec.storageRecommendation) setStorageRecommendation(bRec.storageRecommendation);
      if (bRec.testStatus) setTestStatus(bRec.testStatus);
      if (bRec.nextStep) setNextStep(bRec.nextStep);
      if (bRec.notes) setNotes(bRec.notes);
      if (bRec.photos && bRec.photos.length > 0) setPhotos(bRec.photos);

      // Lock tested stages so operator does not need to re-enter
      setIsGeneralLocked(true);
      setIsHarvestLocked(true);
      setIsDryingLocked(bRec.kernelMoisturePercent !== undefined && bRec.kernelMoisturePercent > 0);
      setIsLabLocked(bRec.kernelGram !== undefined && bRec.kernelGram > 0);
    } else if (hRec || rItem) {
      if (rItem?.quantity) setTotalLoadKg(rItem.quantity);
      else if (hRec?.dailyTotalKg) setTotalLoadKg(hRec.dailyTotalKg);

      if (hRec?.variety) setVariety(hRec.variety);
      if (hRec?.orchard) setLocation(hRec.orchard);
      if (hRec?.operator) setOperator(hRec.operator);

      if (hRec?.photos && hRec.photos.length > 0) {
        setPhotos(prev => Array.from(new Set([...hRec.photos!, ...prev])).slice(0, 8));
      }

      setIsGeneralLocked(true);
      setIsHarvestLocked(true);
    }
  };

  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      populateFromSelectedRef(selectedRefId);
    }
  }, [isNewRef, selectedRefId]);

  const handleResetToPreviousTest = () => {
    if (selectedRefId) {
      populateFromSelectedRef(selectedRefId);
    }
  };

  const allSectionsLocked = isHarvestLocked && isDryingLocked && isLabLocked;
  const toggleAllLocks = () => {
    const nextState = !allSectionsLocked;
    setIsGeneralLocked(nextState);
    setIsHarvestLocked(nextState);
    setIsDryingLocked(nextState);
    setIsLabLocked(nextState);
  };

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setPhotos(prev => [...prev, event.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
      e.target.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // v2.5: seçili aşamanın ölçümleri girilmeden kayıt yok (önceden dolu değer kullanılmaz)
    const missing: string[] = [];
    if (testStage === 'Hasat Öncesi / Hasat Testi') {
      if (hullSplitPercent == null) missing.push('Meyve açma oranı (%)');
      if (fruitMoisturePercent == null) missing.push('Meyve nemi (%)');
    } else if (testStage === 'Yerde Kurutma Aşaması') {
      if (kernelMoisturePercent == null) missing.push('İç (kernel) nemi (%)');
    } else {
      if (!sampleGram) missing.push('Numune ağırlığı (g)');
      if (kernelGram == null) missing.push('Net iç ağırlığı (g)');
      if (!aflatoxinTest) missing.push('Aflatoksin test sonucu');
    }
    if (missing.length) {
      window.alert('Bu aşamanın ölçümlerini girin:\n• ' + missing.join('\n• '));
      return;
    }
    const finalOperator = operator.trim() || AUTOCOMPLETE_LISTS.operators[0] || 'Badem Lab Uzmanı';
    const finalVariety = variety.trim() || 'Nonpareil';
    const finalLocation = location.trim() || 'Miweli Atyz Badem Plantasyonu (Kaka)';

    let finalRefId = '';
    if (isEditing && initialRecord) {
      finalRefId = initialRecord.refId;
    } else if (isNewRef) {
      finalRefId = customRefInput.trim()
        ? customRefInput.trim()
        : generateRefId('BADEM', existingRefs.map(r => r.refId));
    } else {
      finalRefId = selectedRefId.trim() || customRefInput.trim() || generateRefId('BADEM', existingRefs.map(r => r.refId));
    }

    if (!finalRefId) {
      finalRefId = generateRefId('BADEM', []);
    }

    const bademRecord: BademRecord = {
      id: (isEditing && initialRecord?.id) ? initialRecord.id : `b-${Date.now()}`,
      refId: finalRefId,
      timestamp: initialRecord?.timestamp || new Date().toISOString(),
      operator: finalOperator,
      product: `Badem (${finalVariety})`,
      variety: finalVariety,
      location: finalLocation,
      
      // Adım 1
      waterCutOffDate,
      hullSplitPercent: hullSplitPercent ?? undefined,
      fruitMoisturePercent: fruitMoisturePercent ?? undefined,
      sampleFruitCount: sampleFruitCount ?? undefined,
      sampleFruitWeightGram: sampleFruitWeightGram ?? undefined,
      harvestReadinessStatus,

      // Adım 2
      dryingStage,
      kernelMoisturePercent: kernelMoisturePercent ?? undefined,
      dryingNextStep,

      // Adım 3
      calibre,
      kernelCountPerOz: kernelCountPerOz ?? undefined,
      totalLoadKg: totalLoadKg ?? 0,
      sampleGram: sampleGram ?? 0,
      kernelGram: kernelGram ?? 0,
      kernelYieldPercent,
      moisturePercent: (moisturePercent ?? kernelMoisturePercent ?? undefined) as any,
      waterActivityAw: waterActivityAw ?? undefined,
      aflatoxinTest: aflatoxinTest || undefined,
      phenologicalStage,
      testStage,
      defWholeGram,
      defDoubleGram,
      defMechanicalGram,
      defForeignGram,
      defDustGram,
      defBrokenGram,
      defSeriousGram: defSeriousGram + defInsectGram,
      defUndersizeGram,
      defGumGram,
      defInsectGram,
      seriousDefectPercent: seriousPercent,
      totalDefectPercent: totalPercent,
      classification,
      kaliteSinifi,
      storageRecommendation,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      testStatus,
      nextStep,
      notes,
      photos
    };

    const newRefData: Partial<ReferenceItem> | undefined = (isNewRef && !isEditing)
      ? {
          refId: finalRefId,
          moduleKey: 'BADEM',
          product: `Badem (${finalVariety})`,
          location: finalLocation,
          source: finalLocation,
          destination: destination || 'Miweli Atyz Kuru Depo & İşleme',
          quantity: totalLoadKg ?? 0,
          unit: 'kg',
          status: testStatus === 'COMPLETED' ? 'CREATED' : 'CREATED',
          createdAt: new Date().toISOString(),
          operator: finalOperator,
          notes: `Badem [${testStage}]. Randıman: %${kernelYieldPercent.toFixed(1)}, Nem: %${kernelMoisturePercent ?? moisturePercent ?? '—'}, Sınıf: ${classification}`
        }
      : undefined;

    onSave(bademRecord, isNewRef && !isEditing, newRefData);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden w-full max-w-full min-w-0">
      {/* Modern Header */}
      <div className="bg-slate-900 text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shrink-0">
            <Nut className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                🌰 Badem Kalite, Hasat Testi & Randıman Modülü
              </h2>
              <span className="px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-extrabold uppercase bg-amber-950 text-amber-300 border border-amber-800">
                Miweli Atyz Kalite Standartları
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 line-clamp-2 sm:line-clamp-none">
              Su kesimi takibi, %70+ meyve açılma testi, %4.5-6.0 kurutma nemi ve randıman analizi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          {/* Master Lock / Unlock Toggle Button */}
          <button
            type="button"
            onClick={toggleAllLocks}
            className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 sm:px-3 py-1.5 rounded-lg border transition ${
              allSectionsLocked 
                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700 hover:bg-emerald-900' 
                : 'bg-amber-950/80 text-amber-300 border-amber-700 hover:bg-amber-900'
            }`}
            title="Tüm test aşamalarının kilitlerini aç veya kilitle"
          >
            {allSectionsLocked ? (
              <>
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden xs:inline">Testler Kilitli</span>
              </>
            ) : (
              <>
                <Unlock className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden xs:inline">Düzenleme Modu</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        <fieldset disabled={isReadOnly} className="contents border-0 p-0 m-0">
        {/* Test & Data Locking Notification Banner */}
        <div
          className={`border rounded-2xl p-4 transition duration-300 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
            allSectionsLocked
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-amber-50 border-amber-300 text-amber-900'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-lg shrink-0 ${allSectionsLocked ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'}`}>
              {allSectionsLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2 font-bold text-xs">
                <span>
                  {allSectionsLocked
                    ? '🔒 Test Verileri Kilitlendi (Tekrarlayan Giriş Engellendi)'
                    : '✏️ Test Verileri Düzenleme Modunda'}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                  allSectionsLocked ? 'bg-emerald-200/90 text-emerald-900' : 'bg-amber-200/90 text-amber-900'
                }`}>
                  {allSectionsLocked ? '✓ Bilgi Değişmediyse Tekrar Doldurulmaz' : '✏️ Değerler Değiştirilebilir'}
                </span>
              </div>
              <p className="text-[11px] mt-0.5 text-slate-700 leading-snug">
                {allSectionsLocked
                  ? 'Miweli Atyz bahçe ve kurutma test sonuçları korunmaktadır. Aynı bilgileri tekrar yazmanıza gerek yoktur.'
                  : 'Yeni laboratuvar randıman ölçümü veya düzeltme yapmak için kilitli alanları düzenleyebilirsiniz.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-center shrink-0">
            {!isNewRef && selectedRefId && (
              <button
                type="button"
                onClick={handleResetToPreviousTest}
                className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition shadow-sm"
                title="Kayıtlı test verilerini sıfırla ve yeniden yükle"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span>Testi Yeniden Yükle</span>
              </button>
            )}

            <button
              type="button"
              onClick={toggleAllLocks}
              className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm transition ${
                allSectionsLocked
                  ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                  : 'bg-amber-700 hover:bg-amber-800 text-white'
              }`}
            >
              {allSectionsLocked ? (
                <>
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Tüm Kilitleri Aç</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Tümünü Kilitle</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Reference Selection & Mode */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 sm:gap-4 w-full max-w-full min-w-0">
          <div className="w-full md:w-auto min-w-0">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1.5">
              Referans ID (Mevcut partiye bağlayın veya yeni parti kodu yazın)
            </span>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
              <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${isNewRef ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                <input
                  type="radio"
                  checked={isNewRef}
                  onChange={() => setIsNewRef(true)}
                  className="text-amber-700 focus:ring-amber-500 shrink-0"
                />
                <span>Yeni Referans Oluştur</span>
              </label>

              <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${!isNewRef ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                <input
                  type="radio"
                  checked={!isNewRef}
                  onChange={() => setIsNewRef(false)}
                  className="text-amber-700 focus:ring-amber-500 shrink-0"
                />
                <span>Mevcut Referansa Bağla / Test Getir</span>
              </label>
            </div>
          </div>

          <div className="w-full md:w-auto min-w-0">
            {isNewRef ? (
              <input
                type="text"
                value={customRefInput}
                onChange={(e) => setCustomRefInput(e.target.value)}
                placeholder="Otomatik (BADEM-...) veya Özel Kod Yazın"
                className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-amber-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-amber-500 max-w-full"
              />
            ) : (
              <div className="space-y-1 w-full min-w-0">
                <input
                  type="text"
                  list="existing-badem-refs"
                  value={selectedRefId}
                  onChange={(e) => setSelectedRefId(e.target.value)}
                  placeholder="RefID Seçin veya Klavyeden Yazın"
                  className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-amber-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-amber-500 max-w-full truncate"
                />
                <datalist id="existing-badem-refs">
                  {existingRefs.map(r => (
                    <option key={r.refId} value={r.refId}>
                      {r.refId} — {r.product} [{r.quantity} {r.unit}]
                    </option>
                  ))}
                </datalist>
              </div>
            )}
          </div>
        </div>

        {/* Test Aşaması Seçici */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
          <label className="block text-[11px] font-extrabold uppercase text-slate-600 mb-2">
            İşlem / Test Aşaması Seçimi:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {[
              { id: 'Hasat Öncesi / Hasat Testi', label: '1. Hasat Testi & Su Kesimi', desc: 'Açılma >%70, Nem %9-15' },
              { id: 'Yerde Kurutma Aşaması', label: '2. Yerde Kurutma & Rota', desc: 'Kernel Nem %4.5-6.0 -> Depo/İşleme' },
              { id: 'Laboratuvar Randıman & Kalite', label: '3. Randıman & Kalite', desc: 'Net iç %, Kalibre & Kusur' }
            ].map((step) => (
              <button
                key={step.id}
                type="button"
                onClick={() => setTestStage(step.id as any)}
                className={`p-3 rounded-xl text-left border transition ${
                  testStage === step.id
                    ? 'bg-[#5c1d24] text-white border-rose-950 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="font-bold text-xs">{step.label}</div>
                <div className={`text-[10px] mt-0.5 ${testStage === step.id ? 'text-amber-200' : 'text-slate-400'}`}>
                  {step.desc}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* General Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>Operatör Adı *</span>
              {isGeneralLocked && <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5"><Lock className="w-2.5 h-2.5" /> Kilitli</span>}
            </label>
            <input
              type="text"
              list="operators-list"
              value={operator}
              onChange={(e) => setOperator(e.target.value)}
              disabled={isGeneralLocked}
              placeholder="Adınızı giriniz"
             
              className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition focus:outline-none ${
                isGeneralLocked 
                  ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                  : 'bg-slate-50 border border-slate-300 focus:bg-white focus:ring-2 focus:ring-amber-500'
              }`}
            />
            <datalist id="operators-list">
              {AUTOCOMPLETE_LISTS.operators.map(op => (
                <option key={op} value={op} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>Badem Çeşidi</span>
              {isGeneralLocked && <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5"><Lock className="w-2.5 h-2.5" /> Kilitli</span>}
            </label>
            <input
              type="text"
              list="badem-varieties"
              value={variety}
              onChange={(e) => setVariety(e.target.value)}
              disabled={isGeneralLocked}
              className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition focus:outline-none ${
                isGeneralLocked 
                  ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                  : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
              }`}
            />
            <datalist id="badem-varieties">
              <option value="Nonpareil (Erem™)" />
              <option value="Ferragnes" />
              <option value="Ferraduel" />
              <option value="Guara" />
              <option value="Laurenne" />
              <option value="Texas" />
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>Lokasyon / Parsel</span>
              {isGeneralLocked && <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5"><Lock className="w-2.5 h-2.5" /> Kilitli</span>}
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              disabled={isGeneralLocked}
              className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition focus:outline-none ${
                isGeneralLocked 
                  ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                  : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>Toplam Parti Yükü (kg)</span>
              {isGeneralLocked && <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5"><Lock className="w-2.5 h-2.5" /> Kilitli</span>}
            </label>
            <input
              type="number"
              value={totalLoadKg ?? ''}
              onChange={(e) => setTotalLoadKg(e.target.value === '' ? null : parseFloat(e.target.value))}
              disabled={isGeneralLocked}
              className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition focus:outline-none ${
                isGeneralLocked 
                  ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                  : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
              }`}
            />
          </div>
        </div>

        {/* ======================= DETAY 1: HASAT TESTİ ALANI ======================= */}
        <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-4 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-950 flex items-center gap-2">
                <SunMedium className="w-4 h-4 text-amber-700" />
                <span>1. Aşama: Hasat Testi, Su Kesimi & Meyve Açılma Oranı</span>
              </h3>
              {isHarvestLocked && (
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" /> Kilitli
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold ${
                isHarvestReady ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {harvestReadinessStatus}
              </span>

              <button
                type="button"
                onClick={() => setIsHarvestLocked(!isHarvestLocked)}
                className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition ${
                  isHarvestLocked
                    ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                {isHarvestLocked ? (
                  <>
                    <Unlock className="w-3 h-3 text-amber-800" />
                    <span>Kilidi Aç</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3 h-3 text-slate-600" />
                    <span>Kilitle</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Ağacın Su Kesilme Tarihi</span>
                {isHarvestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <input
                type="date"
                value={waterCutOffDate}
                onChange={(e) => setWaterCutOffDate(e.target.value)}
                disabled={isHarvestLocked}
                className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition ${
                  isHarvestLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Meyve Açılma Oranı (%)</span>
                {isHarvestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={hullSplitPercent ?? ''}
                  onChange={(e) => setHullSplitPercent(e.target.value === '' ? null : parseFloat(e.target.value))}
                  disabled={isHarvestLocked}
                  className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition ${
                    isHarvestLocked 
                      ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                      : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                  }`}
                />
                <span className="absolute right-3 top-2 text-xs font-bold text-slate-400">%</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Meyve Nem Oranı (%)</span>
                {isHarvestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={fruitMoisturePercent ?? ''}
                  onChange={(e) => setFruitMoisturePercent(e.target.value === '' ? null : parseFloat(e.target.value))}
                  disabled={isHarvestLocked}
                  className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition ${
                    isHarvestLocked 
                      ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                      : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                  }`}
                />
                <span className="absolute right-3 top-2 text-xs font-bold text-slate-400">%</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Kaç Meyve (Numune Adet)</span>
                {isHarvestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <input
                type="number"
                value={sampleFruitCount ?? ''}
                onChange={(e) => setSampleFruitCount(e.target.value === '' ? null : parseInt(e.target.value))}
                disabled={isHarvestLocked}
                className={`w-full text-xs font-mono font-semibold rounded-lg px-3 py-2 transition ${
                  isHarvestLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Numune Ağırlığı (Gram)</span>
                {isHarvestLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <input
                type="number"
                value={sampleFruitWeightGram ?? ''}
                onChange={(e) => setSampleFruitWeightGram(e.target.value === '' ? null : parseFloat(e.target.value))}
                disabled={isHarvestLocked}
                className={`w-full text-xs font-mono font-semibold rounded-lg px-3 py-2 transition ${
                  isHarvestLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
            </div>
          </div>
        </div>

        {/* ======================= DETAY 2: YERDE KURUTMA & ROTA ======================= */}
        <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
                <Droplets className="w-4 h-4 text-emerald-700" />
                <span>2. Aşama: Yerde Kurutma & Rota Kararı (Hedef: %4.5 - %6.0 Nem)</span>
              </h3>
              {isDryingLocked && (
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" /> Kilitli
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold ${
                isDryingComplete ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {isDryingComplete ? 'Kurutma Tamamlandı ✓' : 'Kurutma Devam Ediyor (%4.5-6.0 Bekleniyor)'}
              </span>

              <button
                type="button"
                onClick={() => setIsDryingLocked(!isDryingLocked)}
                className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition ${
                  isDryingLocked
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                {isDryingLocked ? (
                  <>
                    <Unlock className="w-3 h-3 text-emerald-800" />
                    <span>Kilidi Aç</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3 h-3 text-slate-600" />
                    <span>Kilitle</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Kurutma Aşaması / Gün</span>
                {isDryingLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <input
                type="text"
                value={dryingStage}
                onChange={(e) => setDryingStage(e.target.value)}
                disabled={isDryingLocked}
                placeholder="Örn. Yerde Kurutma 3. Gün"
                className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition ${
                  isDryingLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-emerald-500'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Meyve İçi Kernel Nemi (%)</span>
                {isDryingLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  value={kernelMoisturePercent ?? ''}
                  onChange={(e) => setKernelMoisturePercent(e.target.value === '' ? null : parseFloat(e.target.value))}
                  disabled={isDryingLocked}
                  className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition ${
                    isDryingLocked 
                      ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                      : 'bg-white border border-slate-300 focus:ring-2 focus:ring-emerald-500'
                  }`}
                />
                <span className="absolute right-3 top-2 text-xs font-bold text-slate-400">%</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Kurutma Sonrası Rota / Sevk Kararı</span>
                {isDryingLocked && <Lock className="w-2.5 h-2.5 text-emerald-700" />}
              </label>
              <select
                value={dryingNextStep}
                onChange={(e) => {
                  setDryingNextStep(e.target.value);
                  setNextStep(e.target.value);
                }}
                disabled={isDryingLocked}
                className={`w-full text-xs font-bold rounded-lg px-3 py-2 transition ${
                  isDryingLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-emerald-500'
                }`}
              >
                <option value="Depolama (Kuru Depo Stok Kaydı)">1. Depolama (Kuru Depo Stok Kaydı)</option>
                <option value="Badem İşleme / Kırma Alanı">2. Badem İşleme / Kırma Alanı</option>
                <option value="Yerde Kurutmaya Devam (Nem Yüksek)">3. Yerde Kurutmaya Devam (Nem Yüksek)</option>
              </select>
            </div>
          </div>
        </div>

        {/* ======================= DETAY 3: LAB RANDIMAN & KALİTE ANALİZİ ======================= */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-rose-700" />
                <span>3. Aşama: Laboratuvar Randıman & Kalite Analizi</span>
              </h3>
              {isLabLocked && (
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" /> Kilitli
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-600">
                Hesaplanan Randıman: <strong className="font-mono text-rose-900 text-sm">%{kernelYieldPercent.toFixed(2)}</strong>
              </span>

              <button
                type="button"
                onClick={() => setIsLabLocked(!isLabLocked)}
                className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition ${
                  isLabLocked
                    ? 'bg-rose-100 text-rose-900 border-rose-300 hover:bg-rose-200'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                {isLabLocked ? (
                  <>
                    <Unlock className="w-3 h-3 text-rose-800" />
                    <span>Kilidi Aç</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3 h-3 text-slate-600" />
                    <span>Kilitle</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Brüt Numune Ağırlığı (g)</span>
                {isLabLocked && <Lock className="w-2.5 h-2.5 text-rose-700" />}
              </label>
              <input
                type="number"
                value={sampleGram ?? ''}
                onChange={(e) => setSampleGram(e.target.value === '' ? null : parseFloat(e.target.value))}
                disabled={isLabLocked}
                className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition ${
                  isLabLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Çıkan Net İç Badem (g)</span>
                {isLabLocked && <Lock className="w-2.5 h-2.5 text-rose-700" />}
              </label>
              <input
                type="number"
                value={kernelGram ?? ''}
                onChange={(e) => setKernelGram(e.target.value === '' ? null : parseFloat(e.target.value))}
                disabled={isLabLocked}
                className={`w-full text-xs font-mono font-bold rounded-lg px-3 py-2 transition ${
                  isLabLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Kalibre (Adet/Oz)</span>
                {isLabLocked && <Lock className="w-2.5 h-2.5 text-rose-700" />}
              </label>
              <input
                type="text"
                list="calibres-list"
                value={calibre}
                onChange={(e) => setCalibre(e.target.value)}
                disabled={isLabLocked}
                className={`w-full text-xs font-semibold rounded-lg px-3 py-2 transition ${
                  isLabLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              />
              <datalist id="calibres-list">
                <option value="18-20 (Çok İri)" />
                <option value="20-22 (İri)" />
                <option value="23-25 (Standart Erem)" />
                <option value="27-30 (Orta)" />
                <option value="30-32 (Küçük)" />
                <option value="34-40 (Cılız)" />
              </datalist>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Aflatoksin Testi</span>
                {isLabLocked && <Lock className="w-2.5 h-2.5 text-rose-700" />}
              </label>
              <select
                value={aflatoxinTest}
                onChange={(e) => setAflatoxinTest(e.target.value as any)}
                disabled={isLabLocked}
                className={`w-full text-xs font-bold rounded-lg px-3 py-2 transition ${
                  isLabLocked 
                    ? 'bg-slate-100 text-slate-800 border border-slate-200 cursor-not-allowed' 
                    : 'bg-white border border-slate-300 focus:ring-2 focus:ring-amber-500'
                }`}
              >
                <option value="">— Test sonucu seçin —</option>
                <option value="Negatif (<2 ppb)">Negatif (&lt;2 ppb) ✓ Uygun</option>
                <option value="İnceleniyor">İnceleniyor / Beklemede</option>
                <option value="Pozitif (>4 ppb)">Pozitif (&gt;4 ppb) ✗ Karantina</option>
              </select>
            </div>
          </div>

          {/* Kusur Dağılımı Gramaj Tablosu */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-[11px] font-bold text-slate-700">
                Kusur Dağılımı (Gramaj Olarak):
              </label>
              <div className="text-[11px] font-semibold text-slate-600">
                Toplam Kusur: <strong className="text-amber-800">%{totalPercent.toFixed(1)}</strong> | Ciddi Kusur: <strong className="text-rose-800">%{seriousPercent.toFixed(1)}</strong>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Bütün Sağlam (g)</span>
                <input
                  type="number"
                  value={defWholeGram}
                  onChange={(e) => setDefWholeGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-bold text-emerald-700 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Çift / İkiz (g)</span>
                <input
                  type="number"
                  value={defDoubleGram}
                  onChange={(e) => setDefDoubleGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-slate-800 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Kırık / Mekanik (g)</span>
                <input
                  type="number"
                  value={defMechanicalGram}
                  onChange={(e) => setDefMechanicalGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-slate-800 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Gam / Reçine (g)</span>
                <input
                  type="number"
                  value={defGumGram}
                  onChange={(e) => setDefGumGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-slate-800 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Kurt / Zararlı (g)</span>
                <input
                  type="number"
                  value={defInsectGram}
                  onChange={(e) => setDefInsectGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-rose-700 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Ciddi Küf/Çürük (g)</span>
                <input
                  type="number"
                  value={defSeriousGram}
                  onChange={(e) => setDefSeriousGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-rose-700 mt-1 bg-transparent focus:outline-none"
                />
              </div>

              <div className={`p-2 rounded-lg border transition ${isLabLocked ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] text-slate-500 block">Küçük / Büzüşük (g)</span>
                <input
                  type="number"
                  value={defUndersizeGram}
                  onChange={(e) => setDefUndersizeGram(parseFloat(e.target.value) || 0)}
                  disabled={isLabLocked}
                  className="w-full font-mono font-semibold text-slate-800 mt-1 bg-transparent focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Karar, Sonraki Adım & Durum */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Kalite Sınıfı (Seçmeli)
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { key: 'Ekstra', label: 'Ekstra', hint: '1. Sınıf İhracat' },
                  { key: 'Sınıf 1', label: 'Sınıf 1', hint: 'Standart Pazar' },
                  { key: 'Sınıf 2', label: 'Sınıf 2', hint: 'İkinci Kalite' },
                  { key: 'Sanayi / Yağlık', label: 'Sanayi', hint: 'Kırma / Yağlık' }
                ].map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setClassification(item.key as any)}
                    className={`p-2 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      classification === item.key
                        ? 'bg-amber-100 text-amber-950 border-amber-400 ring-2 ring-amber-400 font-extrabold shadow-xs'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xs">{item.label}</span>
                    <span className="text-[9px] text-slate-500 font-normal">{item.hint}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Sonraki Adım (Seçiniz veya yazınız)
              </label>
              <input
                type="text"
                list="badem-next-steps"
                value={nextStep}
                onChange={(e) => setNextStep(e.target.value)}
                placeholder="Seçiniz veya yazınız"
               
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
              <datalist id="badem-next-steps">
                <option value="Ağaç Sarsma / Hasada Başla" />
                <option value="Yerde Kurutmaya Sevk" />
                <option value="Depolama (Kuru Depo Stok Kaydı)" />
                <option value="Badem İşleme / Kırma Alanı" />
                <option value="Vakumlu Nitrojen Paketleme & Kuru Depo" />
                <option value="Miweli Atyz Kırma & Kalibrasyon Ünitesi" />
                <option value="Fümigasyon & İklimlendirme" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Referans İşlem Durumu
              </label>
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setTestStatus('ACTIVE')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'ACTIVE'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Aktif (İşlemde)
                </button>
                <button
                  type="button"
                  onClick={() => setTestStatus('COMPLETED')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${
                    testStatus === 'COMPLETED'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Tamamlandı
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Notlar */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Notlar & Açıklamalar
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Ağaç yükü, su kesim sonrası yaprak dökümü, hava koşulları ve analiz notları..."
            className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-3 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
          />
        </div>

        {/* Fotoğraf Ekle */}
        <div className="border-t border-slate-200 pt-4">
          <label className="block text-xs font-bold text-slate-700 mb-2">
            Fotoğraf / Numune Dosyası Ekle
          </label>
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* 1. Kamera Butonu */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold cursor-pointer transition shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Fotoğraf Çek</span>
            </button>

            {/* 2. Galeri Butonu */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition shadow-2xs"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>Galeriden Seç</span>
            </button>

            {/* Gizli Kamera Girişi */}
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleAddPhoto}
              className="hidden"
            />

            {/* Gizli Galeri Girişi (multiple destekli) */}
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleAddPhoto}
              className="hidden"
            />

            {photos.filter(p => p && p.length > 20).map((p, idx) => (
              <div key={idx} className="relative w-14 h-14 rounded-lg overflow-hidden border border-slate-300 shadow-sm group">
                <img src={p} alt="Badem Foto" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setPhotos(prev => prev.filter((_, i) => i !== idx))}
                  className="absolute inset-0 bg-red-900/70 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center text-[10px] font-bold transition"
                >
                  Sil
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* 💡 Badem Kalite, Randıman & Nem Rehberi (Miweli Atyz Standartları) - Formun En Altında */}
        <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 text-xs text-amber-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-amber-900">
            <Info className="w-4 h-4 text-amber-700 shrink-0" />
            <span>💡 Badem Kalite, Randıman & Nem Rehberi (Miweli Atyz Standartları):</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] text-amber-900/90 leading-relaxed">
            <div className="bg-white/70 p-2.5 rounded-lg border border-amber-200/60">
              <strong>Hasat Olgunluğu & Sulama:</strong> Ağaçta meyve dış kabuk açılması en az %70 olmalıdır. Hasattan 10-14 gün önce sulama kesilir.
            </div>
            <div className="bg-white/70 p-2.5 rounded-lg border border-amber-200/60">
              <strong>Kurutma Nemi (Kritik):</strong> İç tane (kernel) nemi %4.5 - %6.0 arasında olmalıdır. %6.0 üzeri küflenme ve toksin riski yaratır.
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition"
          >
            İptal
          </button>

          <button
            type="submit"
            disabled={isReadOnly}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${isReadOnly ? 'bg-slate-400 text-slate-200 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800 text-white shadow-md hover:shadow-lg'} text-xs font-extrabold transition`}
          >
            <Save className="w-4 h-4 text-amber-300" />
            <span>{isReadOnly ? 'Salt Okunur (Ziyaretçi Modu)' : 'KAYDET VE İLERLET'}</span>
          </button>
        </div>
        </fieldset>

      </form>
    </div>
  );
};
