import React, { useState, useEffect, useMemo, useRef } from 'react';
import { getCurrentUser } from '../../utils/authService';
import { Apple, ArrowLeft, Camera, Save, CheckCircle, AlertTriangle, Layers, Calendar, Sparkles, Info, Plus, Trash2, Lock, Unlock, Snowflake, AlertOctagon, Loader2, Eye, X, FileCheck, FlaskConical, Gauge, Scale, ShieldCheck, CheckCircle2, XCircle, AlertCircle, Filter, Zap, SlidersHorizontal, ChevronDown, ChevronUp, Building, BookOpen, ExternalLink, HelpCircle, ClipboardCheck, CheckSquare, Square, RefreshCw } from 'lucide-react';
import { FieldRecord, FieldSample, ReferenceItem, STANDARD_QUALITY_CLASSES, SplitLotItem, SpecialCropType, SpecialCropTestResult, ActiveFieldContext } from '../../types';
import { calculateFieldAverages, calculateStreifIndex, generateRefId } from '../../utils/calculations';
import { detectSpecialCropType, CROP_PRESETS, CropPresetDefinition } from '../../utils/specialCropTests';
import { QualityStandardOrg, QUALITY_STANDARDS_ORGS, CROP_QUALITY_SPECS, evaluateCropQuality, resolveStandardSpecForOrg, evaluateSampleAcrossAllStandards, TURKMENISTAN_CROP_VARIETIES_GUIDE, CropQualitySpec, getCropParameterConfig, CropParameterConfig } from '../../utils/qualityStandards';
import { AUTOCOMPLETE_LISTS } from '../../data/initialData';
import { SmartInput, SmartCreatableSelect } from '../common/SmartField';
import { compressImage, cachePhoto } from '../../utils/photoStorage';
import { AdminOptionsStandardsModal } from '../admin/AdminOptionsStandardsModal';
import { AiVisionFruitInspectorModal } from '../common/AiVisionFruitInspectorModal';
import { IoTDataloggerConnector } from '../iot/IoTDataloggerConnector';
import { ModuleEvidenceSection, EvidenceRecord } from '../common/ModuleEvidenceSection';
import { PhotoLightboxModal } from '../common/PhotoLightboxModal';
import { PublicationModal, MDPI_ARTICLES, PublicationData } from '../common/PublicationModal';

interface FieldFormProps {
  onSave: (record: FieldRecord, isNewRef: boolean, newRefData?: Partial<ReferenceItem>) => void;
  onCancel: () => void;
  existingRefs: ReferenceItem[];
  initialRefId?: string;
  initialRecord?: FieldRecord | null; // Düzenleme (Edit) desteği
  activeFieldContext?: ActiveFieldContext | null;
  currentUser?: { fullName?: string; role?: string };
  isReadOnly?: boolean;
}

// Hızlı Seçim İçin Özel Meyve & Sebze Şablonları Listesi
const FEATURED_CROP_TEMPLATES: {
  type: SpecialCropType;
  name: string;
  icon: string;
  presetProduct: string;
  defaultVariety: string;
  badge: string;
  hint: string;
}[] = [
  {
    type: 'MANGO',
    name: 'Mango',
    icon: '🥭',
    presetProduct: 'Mango',
    defaultVariety: 'Kent / Keitt',
    badge: 'Kuru Madde % & Sertlik',
    hint: 'OECD / TESCO Min 13.0°Bx • Kuru Madde min %15 • 4.5-8.0 kg/cm²'
  },
  {
    type: 'PINEAPPLE',
    name: 'Ananas',
    icon: '🍍',
    presetProduct: 'Ananas',
    defaultVariety: 'MD2 Extra Sweet',
    badge: 'Camsılaşma & Kabuk Gözü',
    hint: 'OECD Min 12.0°Bx • Translucency 1-3 • Çift taçsız'
  },
  {
    type: 'AVOCADO',
    name: 'Avokado',
    icon: '🥑',
    presetProduct: 'Avokado',
    defaultVariety: 'Hass',
    badge: 'Kuru Madde % & Durofel',
    hint: 'OECD / TESCO Hass min %21-23 Kuru Madde • Basınca dayanıklı'
  },
  {
    type: 'POMEGRANATE',
    name: 'Nar',
    icon: '🔴',
    presetProduct: 'Nar',
    defaultVariety: 'Hicaz',
    badge: 'Meyve Suyu & Aril Rengi',
    hint: 'OECD Min 14.0°Bx • Meyve Suyu Randımanı min %40 • Koyu Yakut Aril'
  },
  {
    type: 'PLUM',
    name: 'Erik',
    icon: '🟣',
    presetProduct: 'Erik',
    defaultVariety: 'Black Amber / Stanley',
    badge: 'Mumsu Pus & Sertlik',
    hint: 'OECD Min 12.0°Bx • Doğal Pus Örtüsü >%80 • 3.5-6.0 kg/cm²'
  },
  {
    type: 'PISTACHIO',
    name: 'Antep Fıstığı',
    icon: '🥜',
    presetProduct: 'Antep Fıstığı',
    defaultVariety: 'Siirt / Uzun',
    badge: 'Doğal Çıtlaklık & Nem %',
    hint: 'UNECE DDP-09 min %85 Doğal Çıtlak • Depo Nemi <%7.0 (Kritik Aflatoksin Sınırı)'
  },
  {
    type: 'APPLE_PEAR',
    name: 'Elma / Armut',
    icon: '🍎',
    presetProduct: 'Elma',
    defaultVariety: 'Gala / Pink Lady',
    badge: 'Nişasta & Streif (SI)',
    hint: 'OECD FFV-01 min 12°Bx • Streif SI 0.08-0.18 CA/ULO Depoluk'
  },
  {
    type: 'TOMATO',
    name: 'Domates',
    icon: '🍅',
    presetProduct: 'Domates',
    defaultVariety: 'Beef / Salkım',
    badge: 'USDA Renk & TA Asit',
    hint: 'OECD FFV-36 min 4.5°Bx • USDA 2-4 İhracat Alaca Dönüm'
  },
  {
    type: 'GRAPE',
    name: 'Üzüm',
    icon: '🍇',
    presetProduct: 'Üzüm',
    defaultVariety: 'Sultani / Crimson',
    badge: 'Brix/Asit & Tutunma',
    hint: 'OECD FFV-19 min 16°Bx • Brix/Asit min 18:1 • Sağlam Salkım'
  },
  {
    type: 'PEACH_NECTARINE',
    name: 'Şeftali / Nektarin',
    icon: '🍑',
    presetProduct: 'Şeftali',
    defaultVariety: 'Royal Glory / Extreme',
    badge: 'Sertlik & Çekirdek Çatlağı',
    hint: 'OECD FFV-26 4.5-6.5 kg/cm² Sertlik • Çekirdek Çatlağı <%5'
  },
  {
    type: 'MELON_WATERMELON',
    name: 'Kavun / Karpuz',
    icon: '🍉',
    presetProduct: 'Kavun',
    defaultVariety: 'Kırkağaç / Ananas',
    badge: 'Sap Çatlağı & Kabuk',
    hint: 'OECD Min 10.5-12°Bx • Full Slip Sap Ayrılması'
  },
  {
    type: 'ONION',
    name: 'Soğan (Kuru/Taze)',
    icon: '🧅',
    presetProduct: 'Soğan',
    defaultVariety: 'Daytona / Valenciana / Kırmızı',
    badge: 'Boyun Kuruluğu % & Kuru Madde',
    hint: 'OECD FFV-25 Boyun Kuruluğu ≥%90-95 • Kuru Madde ≥%13 • Sıkı Katman'
  },
  {
    type: 'CARROT',
    name: 'Havuç (Käşir)',
    icon: '🥕',
    presetProduct: 'Havuç',
    defaultVariety: 'Nantes / Maestro / Bolero',
    badge: 'Gevreklik, Brix & Odunlaşma %',
    hint: 'UNECE FFV-10 Min 8.5°Bx • Çap 20-40mm • Odunlaşma/Çatlak <%5'
  },
  {
    type: 'POTATO',
    name: 'Patates (Kartoşka)',
    icon: '🥔',
    presetProduct: 'Patates',
    defaultVariety: 'Agria / Gala / Hermes',
    badge: 'Özgül Ağırlık (SG) & Şeker',
    hint: 'UNECE FFV-52 SG 1.075-1.095 • Yeşillenme <%2 • Kabuk Bağlamış'
  }
];

export const FieldForm: React.FC<FieldFormProps> = ({
  onSave,
  onCancel,
  existingRefs,
  initialRefId,
  initialRecord,
  activeFieldContext,
  currentUser,
  isReadOnly: isReadOnlyProp = false
}) => {
  const isEditing = Boolean(initialRecord);
  const isCompletedRecord = initialRecord?.testStatus === 'COMPLETED';
  const [isReadOnly, setIsReadOnly] = useState<boolean>(isReadOnlyProp || isCompletedRecord);

  const [isNewRef, setIsNewRef] = useState(!initialRefId && !initialRecord);
  const [selectedRefId, setSelectedRefId] = useState(initialRecord?.refId || initialRefId || '');
  const [customRefInput, setCustomRefInput] = useState('');

  const selectedRefObj = useMemo(() => existingRefs.find(r => r.refId === selectedRefId), [existingRefs, selectedRefId]);

  // Admin Options & Standards Modal State (Madde 4)
  const [isAdminOptionsModalOpen, setIsAdminOptionsModalOpen] = useState(false);
  const [isSfacGuideOpen, setIsSfacGuideOpen] = useState(false);
  
  // Kilit State'leri (Referans seçildiğinde otomatik kilitlenir)
  const [isProductLocked, setIsProductLocked] = useState(Boolean(!isNewRef && selectedRefId));
  const [isVarietyLocked, setIsVarietyLocked] = useState(Boolean(!isNewRef && selectedRefId));
  const [isLocationLocked, setIsLocationLocked] = useState(Boolean(!isNewRef && selectedRefId));

  // Temel Bilgiler / Basic Info (Auto-populated from activeFieldContext if selected in Gantt or Header)
  const [operator, setOperator] = useState(initialRecord?.operator || getCurrentUser()?.fullName || '');
  const [product, setProduct] = useState(initialRecord?.product || activeFieldContext?.product || '');
  const [sortVariety, setSortVariety] = useState(initialRecord?.sortVariety || activeFieldContext?.variety || '');
  const [orchard, setOrchard] = useState(initialRecord?.orchard || activeFieldContext?.orchard || '');
  
  // Çoklu Lokasyon / Parsel / Blok State (Madde 8)
  const [selectedParcels, setSelectedParcels] = useState<string[]>(() => {
    const raw = initialRecord?.location || activeFieldContext?.location || activeFieldContext?.parcelCode || '';
    if (!raw) return [];
    return raw.split(',').map(s => s.trim()).filter(Boolean);
  });
  const [newParcelInput, setNewParcelInput] = useState('');
  const [location, setLocation] = useState(
    initialRecord?.location || activeFieldContext?.location || activeFieldContext?.parcelCode || ''
  );

  const [testType, setTestType] = useState(initialRecord?.testType || activeFieldContext?.harvestCycle || '');
  const [harvestDate, setHarvestDate] = useState(initialRecord?.harvestDate || new Date().toISOString().split('T')[0]);

  // Hedef Tesis / Destination (Opsiyonel & Varsayılan Kapalı - Madde 5)
  const [showDestination, setShowDestination] = useState<boolean>(Boolean((initialRecord as any)?.destination));
  const [destination, setDestination] = useState((initialRecord as any)?.destination || '');

  // Kalite Standartları Organizasyonu (OECD, USDA, UNECE, TESCO, KIPA, GENERAL)
  const [selectedStandard, setSelectedStandard] = useState<QualityStandardOrg>(() => {
    if (initialRecord?.qualityStandardOrg && (initialRecord.qualityStandardOrg as QualityStandardOrg) in QUALITY_STANDARDS_ORGS) {
      return initialRecord.qualityStandardOrg as QualityStandardOrg;
    }
    const detected = detectSpecialCropType(initialRecord?.product || product);
    return CROP_QUALITY_SPECS[detected]?.defaultStandard || 'OECD';
  });
  
  // Nişasta & Streif İndeksi (SI) Testi
  const [hasStarchTest, setHasStarchTest] = useState<boolean>(
    Boolean(initialRecord?.hasStarchTest || (initialRecord?.starchIndex && initialRecord.starchIndex > 0))
  );

  // Özel Ürün Kalite & Olgunluk Testleri (Mango, Ananas, Avokado, Nar, Erik, Antep Fıstığı vb.)
  const [specialCropType, setSpecialCropType] = useState<SpecialCropType>(() => {
    if (initialRecord?.specialCropTest?.cropType) return initialRecord.specialCropTest.cropType;
    return detectSpecialCropType(initialRecord?.product || product);
  });
  const [hasSpecialCropTest, setHasSpecialCropTest] = useState<boolean>(
    Boolean(initialRecord?.specialCropTest && initialRecord.specialCropTest.cropType !== 'NONE') ||
    specialCropType !== 'NONE'
  );
  
  // Modüler Kanıtlar (Aşama 15)
  const [evidences, setEvidences] = useState<EvidenceRecord[]>([]);

  const [specialMetric1, setSpecialMetric1] = useState<number>(() => {
    if (initialRecord?.specialCropTest?.metric1Value !== undefined) {
      return Number(initialRecord.specialCropTest.metric1Value) || 0;
    }
    const detected = detectSpecialCropType(initialRecord?.product || product);
    return CROP_PRESETS[detected]?.metric1Default ?? 0;
  });
  const [specialMetric2, setSpecialMetric2] = useState<number>(() => {
    if (initialRecord?.specialCropTest?.metric2Value !== undefined) {
      return Number(initialRecord.specialCropTest.metric2Value) || 0;
    }
    const detected = detectSpecialCropType(initialRecord?.product || product);
    return CROP_PRESETS[detected]?.metric2Default ?? 0;
  });

  // Dinamik Numuneler / Dynamic Samples
  const [samples, setSamples] = useState<FieldSample[]>(() => {
    if (initialRecord?.samples && initialRecord.samples.length > 0) {
      return initialRecord.samples;
    }
    return [
      { sample: 1, hardness: 5.5, brix: 12.5, diameterMm: 70, weightG: 180, starch: 5, defects: 'Yok' },
      { sample: 2, hardness: 5.4, brix: 12.8, diameterMm: 72, weightG: 195, starch: 5, defects: 'Yok' },
      { sample: 3, hardness: 5.6, brix: 12.4, diameterMm: 69, weightG: 175, starch: 6, defects: 'Yok' },
      { sample: 4, hardness: 5.3, brix: 13.0, diameterMm: 73, weightG: 205, starch: 5, defects: 'Yok' },
      { sample: 5, hardness: 5.5, brix: 12.6, diameterMm: 71, weightG: 190, starch: 6, defects: 'Yok' }
    ];
  });

  // Test Ağırlığı ve Meyve Gramajı (Test Weight & Fruit Gram - Madde 1)
  const [fruitCountSampled, setFruitCountSampled] = useState<number>(
    initialRecord?.fruitCountSampled ?? (initialRecord?.samples?.length || 5)
  );
  const [testSampleWeightKg, setTestSampleWeightKg] = useState<number>(
    initialRecord?.testSampleWeightKg ?? (initialRecord?.testSampleWeightG ? Number((initialRecord.testSampleWeightG / 1000).toFixed(3)) : 0.945)
  );

  // Seçmeli / Opsiyonel Saha Parametreleri (Konjonktür gereği sahada her zaman ölçülmeyebilir - Madde 2)
  const [hasNitrateTest, setHasNitrateTest] = useState<boolean>(
    initialRecord?.hasNitrateTest !== undefined
      ? initialRecord.hasNitrateTest
      : Boolean(initialRecord?.nitrateMgKg && initialRecord.nitrateMgKg > 0)
  );
  const [hasColorationTest, setHasColorationTest] = useState<boolean>(
    initialRecord?.colorationPercent != null ? true : false
  );
  const [hasProductFinalStatus, setHasProductFinalStatus] = useState<boolean>(
    initialRecord?.finalProductStatus !== undefined ? true : false
  );
  const [hasDefectTest, setHasDefectTest] = useState<boolean>(
    initialRecord?.hasDefectTest !== undefined ? initialRecord.hasDefectTest : false
  );
  const [hasQualityGrade, setHasQualityGrade] = useState<boolean>(
    initialRecord?.hasQualityGrade !== undefined ? initialRecord.hasQualityGrade : true
  );

  // MDPI Scientific Publication States & Selected Parameters
  const [activePublicationModal, setActivePublicationModal] = useState<PublicationData | null>(null);
  const [hasHueAngleTest, setHasHueAngleTest] = useState<boolean>(
    initialRecord?.hasHueAngleTest !== undefined ? initialRecord.hasHueAngleTest : false
  );
  const [hueAngle, setHueAngle] = useState<number | null>(initialRecord?.hueAngle ?? null);
  const [hasFertilizationNotes, setHasFertilizationNotes] = useState<boolean>(
    Boolean(initialRecord?.fertilizationNotes)
  );
  const [fertilizationNotes, setFertilizationNotes] = useState<string>(
    initialRecord?.fertilizationNotes || ''
  );

  // Kalite Metrikleri / Quality Metrics
  const [nitrateMgKg, setNitrateMgKg] = useState<number | null>(initialRecord?.nitrateMgKg ?? null);
  const [nitrateLimitMgKg, setNitrateLimitMgKg] = useState<number | null>(initialRecord?.nitrateLimitMgKg ?? null);
  const [colorationPercent, setColorationPercent] = useState<number | null>(initialRecord?.colorationPercent ?? null);
  const [defectPercent, setDefectPercent] = useState<number | null>(initialRecord?.defectPercent ?? null);
  const [kaliteSinifi, setKaliteSinifi] = useState<string>(
    initialRecord?.kaliteSinifi || initialRecord?.qualityGrade || 'I (V-22) EXC'
  );
  const [qualityGrade, setQualityGrade] = useState<any>(
    initialRecord?.qualityGrade || 'I (V-22) EXC'
  );

  // Freeze & Dry ve Nihai Ürün Durumu / Product Final Status
  const [finalProductStatus, setFinalProductStatus] = useState<'FRESH_SALE' | 'COLD_STORAGE' | 'FREEZE_DRY'>(
    initialRecord?.finalProductStatus || 'FRESH_SALE'
  );
  const [rejectionReason, setRejectionReason] = useState(initialRecord?.rejectionReason || '');

  // Dinamik Parametre Yapılandırması (Seçilen Meyve/Sebzeye göre otomatik filtreleme)
  const [showAllParamsManual, setShowAllParamsManual] = useState<boolean>(false);
  const [showTemplatesExpanded, setShowTemplatesExpanded] = useState<boolean>(false); // Mobil görünümde şablonları katlanabilir yapma
  const cropParamConfig: CropParameterConfig = useMemo(() => {
    return getCropParameterConfig(specialCropType, product);
  }, [specialCropType, product]);

  // Karar & Durum
  const [splitLots, setSplitLots] = useState<SplitLotItem[]>(initialRecord?.splitLots || []);
  const [testStatus, setTestStatus] = useState<'ACTIVE' | 'COMPLETED'>(initialRecord?.testStatus || 'COMPLETED');
  const [decision, setDecision] = useState(initialRecord?.decision || '');
  const [nextStep, setNextStep] = useState(initialRecord?.nextStep || '');
  const [notes, setNotes] = useState(initialRecord?.notes || '');
  const [photos, setPhotos] = useState<string[]>(initialRecord?.photos || []);
  const [fieldTempC, setFieldTempC] = useState<number | undefined>((initialRecord as any)?.fieldTempC ?? (initialRecord as any)?.ambientTempC);
  const [fieldHumidityPct, setFieldHumidityPct] = useState<number | undefined>((initialRecord as any)?.fieldHumidityPct ?? (initialRecord as any)?.ambientHumidityPct);

  // Hasat Öncesi Kontrol Listesi State (Pre-Harvest Readiness Checklist - Madde 1)
  const [checkedListIds, setCheckedListIds] = useState<Record<string, boolean>>(() => {
    if (initialRecord?.preHarvestChecklist && initialRecord.preHarvestChecklist.length > 0) {
      const map: Record<string, boolean> = {};
      initialRecord.preHarvestChecklist.forEach((item) => {
        map[item.id] = item.checked;
      });
      return map;
    }
    return {};
  });
  const [isChecklistExpanded, setIsChecklistExpanded] = useState<boolean>(true);
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [isAiVisionOpen, setIsAiVisionOpen] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Otomatik Ürün Tespiti (Elma/Armut için Nişasta, Diğer meyve/sebzeler için özel testler)
  useEffect(() => {
    const p = (product || '').toLowerCase();
    const isPome = p.includes('alma') || p.includes('elma') || p.includes('apple') || p.includes('armut') || p.includes('pear') || p.includes('fuji') || p.includes('gala') || p.includes('golden') || p.includes('granny') || p.includes('red chief') || p.includes('scarlet');
    if (isPome) {
      if (!hasStarchTest) {
        setHasStarchTest(true);
      }
      if (specialCropType !== 'APPLE_PEAR') {
        setSpecialCropType('APPLE_PEAR');
        setHasSpecialCropTest(true);
      }
    }

    const detected = detectSpecialCropType(product);
    if (detected !== 'NONE' && !initialRecord) {
      setSpecialCropType(detected);
      setHasSpecialCropTest(true);
      const preset = CROP_PRESETS[detected];
      if (preset) {
        setSpecialMetric1(preset.metric1Default);
        if (preset.metric2Default !== undefined) setSpecialMetric2(preset.metric2Default);
      }
      const cropSpec = CROP_QUALITY_SPECS[detected];
      if (cropSpec && cropSpec.defaultStandard) {
        setSelectedStandard(cropSpec.defaultStandard);
      }
    }
  }, [product, hasStarchTest, initialRecord, specialCropType]);

  // Şablon Seçildiğinde Ürünü, Parametreleri ve Standartları Yükleme Fonksiyonu
  const handleApplyCropTemplate = (tpl: typeof FEATURED_CROP_TEMPLATES[0]) => {
    setSpecialCropType(tpl.type);
    setHasSpecialCropTest(true);
    if (!product || product === 'Standart' || !isProductLocked) {
      setProduct(tpl.presetProduct);
    }
    if (!sortVariety || !isVarietyLocked) {
      setSortVariety(tpl.defaultVariety);
    }

    // Preset metriklerini yükle
    const preset = CROP_PRESETS[tpl.type];
    if (preset) {
      setSpecialMetric1(preset.metric1Default);
      if (preset.metric2Default !== undefined) {
        setSpecialMetric2(preset.metric2Default);
      }
    }

    // Ürünün varsayılan standardını ayarla
    const cropSpec = CROP_QUALITY_SPECS[tpl.type];
    if (cropSpec) {
      const std = cropSpec.defaultStandard || 'OECD';
      setSelectedStandard(std);
      const stdLimits = cropSpec.standards[std] || cropSpec.standards.OECD || cropSpec.standards.UNECE;
      if (stdLimits) {
        setNitrateLimitMgKg(stdLimits.maxNitrateMgKg ?? null); // v2.5: standartta limit yoksa uydurma 60 yok
      }
    }

    // Elma/Armut ise nişastayı aç, diğerlerinde opsiyonel tut
    if (tpl.type === 'APPLE_PEAR') {
      setHasStarchTest(true);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsCompressingPhoto(true);
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const compressedBase64 = await compressImage(file, 1280, 1280, 0.82);
        const photoKey = `photo_field_${Date.now()}_${i}`;
        await cachePhoto(photoKey, compressedBase64);
        setPhotos(prev => [...prev, compressedBase64]);
      }
    } catch (err) {
      console.error('Fotoğraf işleme hatası:', err);
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (re) => {
        if (re.target?.result) setPhotos(prev => [...prev, re.target!.result as string]);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsCompressingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // Referans seçildiğinde otomatik doldurma ve kilitleme
  useEffect(() => {
    if (!isNewRef && selectedRefId) {
      const match = existingRefs.find(r => r.refId === selectedRefId);
      if (match) {
        if (match.product) {
          setProduct(match.product.replace(/\(.*\)/, '').trim());
          setIsProductLocked(true);
        }
        if (match.location) {
          setLocation(match.location);
          setIsLocationLocked(true);
        }
        if (match.orchard) {
          setOrchard(match.orchard);
        }
      }
    }
  }, [selectedRefId, isNewRef, existingRefs]);

  // Dinamik Numune Ekle / Sil
  const handleAddSample = () => {
    const nextIndex = samples.length + 1;
    const last = samples[samples.length - 1];
    setSamples([
      ...samples,
      {
        sample: nextIndex,
        hardness: last ? last.hardness : 5.5,
        brix: last ? last.brix : 12.5,
        diameterMm: last ? last.diameterMm : 70,
        starch: last ? (last.starch ?? 5) : 5,
        defects: 'Yok'
      }
    ]);
  };

  const handleRemoveSample = (indexToRemove: number) => {
    if (samples.length <= 1) {
      alert('En az 1 numune bulunmalıdır.');
      return;
    }
    const updated = samples
      .filter((_, idx) => idx !== indexToRemove)
      .map((s, newIdx) => ({ ...s, sample: newIdx + 1 }));
    setSamples(updated);
  };

  const handleSampleChange = (index: number, field: keyof FieldSample, value: any) => {
    const updated = [...samples];
    updated[index] = { ...updated[index], [field]: value };
    setSamples(updated);
  };

  // Dinamik Aritmetik Ortalamalar
  const { avgHardness, avgBrix, avgDiameter, avgStarch, avgWeightG, totalWeightG } = useMemo(() => {
    return calculateFieldAverages(samples);
  }, [samples]);

  // Efektif Tek Meyve Gramı ve Test Toplam Gramı
  const effectiveAvgFruitWeightG = useMemo(() => {
    if (avgWeightG > 0) return avgWeightG;
    if (testSampleWeightKg > 0 && fruitCountSampled > 0) {
      return Number(((testSampleWeightKg * 1000) / fruitCountSampled).toFixed(1));
    }
    return 0;
  }, [avgWeightG, testSampleWeightKg, fruitCountSampled]);

  const effectiveTotalWeightG = useMemo(() => {
    if (totalWeightG > 0) return totalWeightG;
    if (testSampleWeightKg > 0) return Number((testSampleWeightKg * 1000).toFixed(1));
    return 0;
  }, [totalWeightG, testSampleWeightKg]);

  // Streif İndeksi Hesaplaması (SI = Sertlik / [Brix * Nişasta])
  const streifResult = useMemo(() => {
    return calculateStreifIndex(avgHardness, avgBrix, avgStarch, sortVariety);
  }, [avgHardness, avgBrix, avgStarch, sortVariety]);

  const nitratePass = !hasNitrateTest || (nitrateMgKg != null && nitrateLimitMgKg != null && nitrateMgKg <= nitrateLimitMgKg);

  // Aktif Standart ve Ürün Limitlerine Göre OTOMATİK KALİTE DEĞERLENDİRMESİ (Geçti / Kaldı / Koşullu)
  const evaluationResult = useMemo(() => {
    return evaluateCropQuality({
      cropType: specialCropType,
      standardOrg: selectedStandard,
      avgBrix,
      avgHardness,
      defectPercent: hasDefectTest ? (defectPercent ?? undefined) : 0,
      colorationPercent: hasColorationTest ? (colorationPercent ?? undefined) : undefined,
      nitrateMgKg: hasNitrateTest ? (nitrateMgKg ?? undefined) : undefined,
      nitrateLimitMgKg: hasNitrateTest ? (nitrateLimitMgKg ?? undefined) : undefined,
      specialMetric1: hasSpecialCropTest ? specialMetric1 : undefined,
      specialMetric2: hasSpecialCropTest ? specialMetric2 : undefined
    });
  }, [specialCropType, selectedStandard, avgBrix, avgHardness, hasDefectTest, defectPercent, colorationPercent, hasNitrateTest, nitrateMgKg, nitrateLimitMgKg, hasSpecialCropTest, specialMetric1, specialMetric2]);

  // Aktif ürünün spesifikasyon bilgileri
  const activeCropSpec = CROP_QUALITY_SPECS[specialCropType] || CROP_QUALITY_SPECS.NONE;
  const activeStandardSpec = resolveStandardSpecForOrg(specialCropType, selectedStandard);
  const activeOrgInfo = QUALITY_STANDARDS_ORGS[selectedStandard] || QUALITY_STANDARDS_ORGS.GENERAL;

  // Numune Testine Göre Tüm Standartlara Uygunluk Matrisi (OECD, UNECE, Pazar, Freeze&Dry, Konsantre/Meyve Suyu, TM Oba Hojalyk)
  const multiStandardMatrix = useMemo(() => {
    return evaluateSampleAcrossAllStandards({
      cropType: specialCropType,
      avgBrix,
      avgHardness,
      defectPercent,
      colorationPercent,
      nitrateMgKg,
      nitrateLimitMgKg,
      specialMetric1: hasSpecialCropTest ? specialMetric1 : undefined,
      specialMetric2: hasSpecialCropTest ? specialMetric2 : undefined
    });
  }, [specialCropType, avgBrix, avgHardness, defectPercent, colorationPercent, nitrateMgKg, nitrateLimitMgKg, hasSpecialCropTest, specialMetric1, specialMetric2]);
  const [showTmGuide, setShowTmGuide] = useState(false);

  // 1. Ürüne Özel Hasat Öncesi Kontrol Listesi & Parsel Olgunluk Hesaplayıcısı (Madde 1)
  const checklistCropCategory = useMemo<'APPLE' | 'BANANA' | 'ALMOND' | 'OTHER'>(() => {
    const norm = `${product} ${sortVariety}`.toLowerCase();
    if (norm.includes('elma') || norm.includes('alma') || norm.includes('apple') || specialCropType === 'APPLE_PEAR') {
      return 'APPLE';
    }
    if (norm.includes('muz') || norm.includes('banana')) {
      return 'BANANA';
    }
    if (norm.includes('badem') || norm.includes('almond') || norm.includes('badam')) {
      return 'ALMOND';
    }
    return 'OTHER';
  }, [product, sortVariety, specialCropType]);

  const preHarvestChecklistData = useMemo(() => {
    const parcelText = selectedParcels.length > 0
      ? selectedParcels.join(', ')
      : (location || 'Tanımsız Parsel');

    interface ChecklistDef {
      id: string;
      title: string;
      description: string;
      criteria: string;
      category: string;
      autoStatus: 'PASSED' | 'WARNING' | 'PENDING';
      statusMessage: string;
    }

    let items: ChecklistDef[] = [];
    let readinessVerdict = '';
    let maturityStageLabel = '';

    if (checklistCropCategory === 'APPLE') {
      // Elma Hasat Öncesi Olgunluk Listesi (WSU & Streif İndeksi Odaklı)
      const isStreifIdeal = streifResult.streifIndex >= 0.08 && streifResult.streifIndex <= 0.20;
      const isStreifEarly = streifResult.streifIndex > 0.20;
      const isStreifLate = streifResult.streifIndex > 0 && streifResult.streifIndex < 0.08;

      const streifAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' = 
        hasStarchTest && streifResult.streifIndex > 0
          ? (isStreifIdeal || isStreifLate ? 'PASSED' : 'WARNING')
          : 'PENDING';

      const starchAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        hasStarchTest && avgStarch > 0
          ? (avgStarch >= 2.5 && avgStarch <= 6.5 ? 'PASSED' : 'WARNING')
          : 'PENDING';

      const brixAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        avgBrix > 0 ? (avgBrix >= 12.0 ? 'PASSED' : 'WARNING') : 'PENDING';

      const hardnessAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        avgHardness > 0 ? (avgHardness >= 6.2 ? 'PASSED' : 'WARNING') : 'PENDING';

      const colorAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        colorationPercent != null ? (colorationPercent >= 50 ? 'PASSED' : 'WARNING') : 'PENDING';

      const defectAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        defectPercent != null ? (defectPercent <= 3.0 ? 'PASSED' : 'WARNING') : 'PENDING';

      items = [
        {
          id: 'apple_streif',
          title: 'Streif Olgunluk İndeksi (SI = Sertlik / [Brix × Nişasta])',
          description: 'CA / ULO uzun dönem soğuk depo veya taze pazar sevk penceresi doğrulaması.',
          criteria: 'Depoluk: 0.08 - 0.18 SI • Taze Pazar: 0.04 - 0.08 SI',
          category: 'Olgunluk İndeksi',
          autoStatus: streifAutoStatus,
          statusMessage: hasStarchTest && streifResult.streifIndex > 0
            ? (isStreifIdeal 
                ? `✓ Mükemmel Depoluk Pencere (SI: ${streifResult.streifIndex.toFixed(3)})` 
                : isStreifEarly 
                ? `⚠️ Ham / Erken Hasat (SI: ${streifResult.streifIndex.toFixed(3)} > 0.20)` 
                : `✓ Taze Tüketim Olgunluğu (SI: ${streifResult.streifIndex.toFixed(3)})`)
            : 'Nişasta testi yapıldığında otomatik hesaplanır'
        },
        {
          id: 'apple_starch',
          title: 'WSU Nişasta-İyot Dönüşüm Skalası (1-10 Skoru)',
          description: 'Meyve etindeki nişastanın şekere dönüşüm derecesi (Washington State University standardı).',
          criteria: 'CA Depo: 2.5 - 4.5 • Taze Tüketim: 5.0 - 6.5',
          category: 'Biyokimyasal Olgunluk',
          autoStatus: starchAutoStatus,
          statusMessage: avgStarch > 0
            ? (avgStarch >= 2.5 && avgStarch <= 5.5
                ? `✓ İdeal Depoluk Nişasta: ${avgStarch.toFixed(1)} / 10`
                : avgStarch > 5.5
                ? `✓ Taze Pazar / İleri Dönüşüm: ${avgStarch.toFixed(1)} / 10`
                : `⚠️ Yüksek Nişasta / Ham: ${avgStarch.toFixed(1)} / 10`)
            : 'Numunelerden ortalama nişasta bekleniyor'
        },
        {
          id: 'apple_firmness',
          title: 'Penetrometre Eti Sertliği (11mm Uç ile)',
          description: 'Hasat, taşıma ve uzun süre depolama sırasında yumuşama direnci.',
          criteria: 'Asgari ≥ 6.2 - 7.5 kg/cm² (Gala, Granny Smith, Red Chief)',
          category: 'Fiziksel Kalibrasyon',
          autoStatus: hardnessAutoStatus,
          statusMessage: avgHardness > 0
            ? (avgHardness >= 6.2
                ? `✓ Sertlik Yeterli: ${avgHardness.toFixed(1)} kg/cm²`
                : `⚠️ Düşük Sertlik: ${avgHardness.toFixed(1)} kg/cm² (Hızlı Tüketim)`)
            : 'Numunelerden ortalama sertlik bekleniyor'
        },
        {
          id: 'apple_brix',
          title: 'Refraktometre Şeker Seviyesi (Brix °Bx)',
          description: 'Tüketici lezzet profili ve asgari depolama şekeri standardı.',
          criteria: 'Asgari ≥ 12.0 °Bx (OECD FFV-01 ve SFAC PHM-SOP)',
          category: 'Duyusal & Şeker',
          autoStatus: brixAutoStatus,
          statusMessage: avgBrix > 0
            ? (avgBrix >= 12.0
                ? `✓ Şeker Seviyesi Uygun: ${avgBrix.toFixed(1)} °Bx`
                : `⚠️ Yetersiz Şeker: ${avgBrix.toFixed(1)} °Bx (Hedef ≥ 12.0)`)
            : 'Numunelerden ortalama Brix bekleniyor'
        },
        {
          id: 'apple_color',
          title: 'Zemin Rengi Açılması & Üst Renklenme (%)',
          description: 'Zemin renginin koyu yeşilden sarımsı-yeşile dönmesi; çeşit tipik renklenmesi.',
          criteria: 'Renklenme ≥ %50 (Kırmızı elmalar için OECD Sınıf 1)',
          category: 'Görsel Olgunluk',
          autoStatus: colorAutoStatus,
          statusMessage: colorationPercent != null
            ? (colorationPercent >= 50
                ? `✓ Renklenme Yeterli: %${colorationPercent}`
                : `⚠️ Renklenme Gelişimi Devam Ediyor: %${colorationPercent}`)
            : 'Renklenme testi seçildiğinde güncellenir'
        },
        {
          id: 'apple_seed_defects',
          title: 'Acı Benek (Bitter Pit), Çil & Güneş Yanığı Taraması',
          description: 'Kalsiyum noksanlığı lekeleri ve kabuk bozukluklarının parsel genelinde kontrolü.',
          criteria: 'Toplam kusur & fizyolojik leke < %3.0',
          category: 'Kusur & Tolerans',
          autoStatus: defectAutoStatus,
          statusMessage: defectPercent != null
            ? (defectPercent <= 3.0
                ? `✓ Kusur Toleransı Dahilinde: %${defectPercent}`
                : `⚠️ Parselde Kusur Yüksek: %${defectPercent} (> %3.0)`)
            : 'Kusur analizi tamamlandığında güncellenir'
        }
      ];

      if (hasStarchTest && streifResult.streifIndex > 0) {
        if (isStreifIdeal) {
          maturityStageLabel = 'Optimum CA/ULO Depolama Penceresi';
          readinessVerdict = `Parsel ${parcelText}: Elma olgunluk göstergeleri uzun dönem depolama için idealdir. Hasada başlanabilir.`;
        } else if (isStreifEarly) {
          maturityStageLabel = 'Ham / Erken Hasat Dönemi';
          readinessVerdict = `Parsel ${parcelText}: Nişasta henüz şekere dönüşmemiş (Streif SI: ${streifResult.streifIndex.toFixed(3)}). Parsel 3-5 gün sonra tekrar test edilmelidir.`;
        } else {
          maturityStageLabel = 'İleri Olgunluk / Taze Pazar';
          readinessVerdict = `Parsel ${parcelText}: Meyve tüketim olgunluğuna ulaşmış. Uzun dönem depo yerine taze sevk veya market zincirine yönlendirilmeli.`;
        }
      } else {
        maturityStageLabel = 'Ölçüm Bekleniyor';
        readinessVerdict = `Parsel ${parcelText}: Numune değerleri girildikçe olgunluk endeksleri otomatik güncellenecektir.`;
      }

    } else if (checklistCropCategory === 'BANANA') {
      // Muz Kalite Kontrol & MAP Öncesi Kesim Listesi
      const caliper = specialMetric1 || avgDiameter;
      const caliperAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        caliper > 0
          ? (caliper >= 38 && caliper <= 44 ? 'PASSED' : 'WARNING')
          : 'PENDING';

      const brixAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        avgBrix > 0
          ? (avgBrix >= 3.5 && avgBrix <= 5.8 ? 'PASSED' : 'WARNING')
          : 'PENDING';

      items = [
        {
          id: 'banana_caliper',
          title: 'Parmak Kalibre Çapı & Grade (38 - 44 mm)',
          description: 'Muz salkımındaki parmakların orta kısımdan kumpas ile kesim kalibrasyonu kontrolü.',
          criteria: 'Standart Kesim: 38 - 44 mm (Grade 39-44)',
          category: 'Kalibrasyon',
          autoStatus: caliperAutoStatus,
          statusMessage: caliper > 0
            ? (caliper >= 38 && caliper <= 44
                ? `✓ Kesim Kalibresi Uygun: ${caliper.toFixed(1)} mm`
                : caliper > 44
                ? `⚠️ İri Parmak (>44 mm): Hızlı sararma riski`
                : `⚠️ İnce Parmak (<38 mm): Dolum beklenmeli`)
            : 'Kumpas ölçümü girildiğinde doğrulanır'
        },
        {
          id: 'banana_shape',
          title: 'Köşeli Yapıdan Silindirik Yuvarlaklığa Geçiş (Açı Kaybı)',
          description: 'Boyuna keskin köşelerin kaybolması ve meyvenin dolgun 3/4 round formuna ulaşması.',
          criteria: 'Full 3/4 veya Full Round (SFAC PHM-SOP Madde 4.2)',
          category: 'Morfolojik Olgunluk',
          autoStatus: caliper >= 38 ? 'PASSED' : 'PENDING',
          statusMessage: caliper >= 38 ? '✓ Parmak dolgunluğu ve köşe yuvarlaklığı yeterli' : 'Köşe dolumu kontrol edilmeli'
        },
        {
          id: 'banana_brix',
          title: 'Yeşil Muz Nişasta Stabilitesi & 3-Nokta Brix',
          description: 'Hasat anında erken şekerlenme başlamamış olmalı (kararlı yeşil dönem).',
          criteria: 'Stabil Yeşil Dönem: 3.5 - 5.5 °Bx',
          category: 'Biyokimyasal Stabilite',
          autoStatus: brixAutoStatus,
          statusMessage: avgBrix > 0
            ? (avgBrix >= 3.5 && avgBrix <= 5.8
                ? `✓ Kararlı Yeşil Dönem: ${avgBrix.toFixed(1)} °Bx`
                : `⚠️ Erken Şekerlenme: ${avgBrix.toFixed(1)} °Bx (>5.8)`)
            : 'Brix ölçümü bekleniyor'
        },
        {
          id: 'banana_latex',
          title: 'Lateks / Koçan Sütü Akış Debisi & Şeffaflığı',
          description: 'Kesim kesitinden bol ve berrak süt akışı; su stresi ve kuraklık yokluğu.',
          criteria: 'Berrak ve kesintisiz lateks salgısı',
          category: 'Bitki Sağlığı',
          autoStatus: 'PASSED',
          statusMessage: '✓ Koçan süt akışı normal'
        },
        {
          id: 'banana_flower_rot',
          title: 'Çiçek Burnu Temizliği & Uç Çürüklüğü (Cigar End Rot) Yokluğu',
          description: 'Kurumuş çiçek kalıntılarının temizlenmesi ve mantari uç enfeksiyonu taraması.',
          criteria: 'Enfeksiyonsuz, temiz piston uçları',
          category: 'Fitopatoloji',
          autoStatus: 'PASSED',
          statusMessage: '✓ Uç çürüklüğü gözlenmedi'
        },
        {
          id: 'banana_map_prep',
          title: 'MAP Modifiye Atmosfer Torbaları & Sünger Dolgular',
          description: 'Hasat sonrası sürtünme önleyici köpük yastıklar ve MAP torbalarının hazır oluşu.',
          criteria: 'MAP torbalama donanımı hazır',
          category: 'Hasat Sonrası Koruma',
          autoStatus: 'PASSED',
          statusMessage: '✓ MAP koruma kiti hazır'
        }
      ];

      maturityStageLabel = caliper >= 38 && caliper <= 44 ? 'Muz Kesim Standardında' : 'Gelişim Devam Ediyor';
      readinessVerdict = `Sera / Parsel ${parcelText}: Muz partisi ${caliper > 0 ? `${caliper.toFixed(1)} mm kalibre ile ` : ''}kesim ve MAP torbalama için değerlendirilmektedir.`;

    } else if (checklistCropCategory === 'ALMOND') {
      // Badem Silkme & Randıman Listesi
      const splitPercent = specialMetric1 || 95;
      const moisture = specialMetric2 || 6.5;

      const splitAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        splitPercent >= 90 ? 'PASSED' : (splitPercent > 0 ? 'WARNING' : 'PENDING');

      const moistureAutoStatus: 'PASSED' | 'WARNING' | 'PENDING' =
        moisture > 0 ? (moisture <= 7.0 ? 'PASSED' : 'WARNING') : 'PENDING';

      items = [
        {
          id: 'almond_hull_split',
          title: 'Dış Yeşil Kabuk Çatlama Oranı (Hull Split ≥ %95)',
          description: 'Ağacın tepe ve iç kısımlarındaki bademlerin yeşil kabuğunun tamamen yarılması.',
          criteria: 'Asgari ≥ %95 çatlama (Ağaç üstü silkme standardı)',
          category: 'Hasat Olgunluğu',
          autoStatus: splitAutoStatus,
          statusMessage: splitPercent >= 90
            ? `✓ Yeşil Kabuk Çatlaması Yeterli: %${splitPercent}`
            : `⚠️ Çatlama Devam Ediyor: %${splitPercent} (Beklenmeli)`
        },
        {
          id: 'almond_abscission',
          title: 'Sap Ayırma Katmanı (Abscission) Kuruması',
          description: 'Meyve sapı ile dal arasındaki iletim demetinin kuruması; silkelemede gövde kabuğunun korunması.',
          criteria: 'Gövde kabuğu sıyrılmadan tam ayrılma',
          category: 'Mekanik Silkme Güvenliği',
          autoStatus: splitPercent >= 90 ? 'PASSED' : 'PENDING',
          statusMessage: splitPercent >= 90 ? '✓ Abscission katmanı kurumuş, silkme güvenli' : 'Dal bağlantısı kontrol edilmeli'
        },
        {
          id: 'almond_moisture',
          title: 'İç Badem Nem Oranı (Kritik Aflatoksin Eşiği)',
          description: 'Aflatoksin ve küf riskine karşı güvenli depolama nem sınırının yakalanması.',
          criteria: 'İç Tane Nemi ≤ %6.0 - 7.0 (Kritik sınır)',
          category: 'Depolama Güvenliği',
          autoStatus: moistureAutoStatus,
          statusMessage: moisture > 0
            ? (moisture <= 7.0
                ? `✓ Nem Güvenli Sınırda: %${moisture}`
                : `⚠️ Yüksek Nem: %${moisture} (Kurutma Gerekli)`)
            : 'Nem tayin cihazı ölçümü bekleniyor'
        },
        {
          id: 'almond_yield',
          title: 'İç Randıman ve Çift/İkiz Dane Oranı',
          description: 'Kabuklu ağırlığa oranla iç badem randımanı ve ikiz tane toleransı.',
          criteria: 'Randıman ≥ %30-36 • İkiz Dane < %5',
          category: 'Randıman & Kalite',
          autoStatus: 'PASSED',
          statusMessage: '✓ Randıman parametreleri uygun'
        },
        {
          id: 'almond_pest',
          title: 'Göbek Kurdu (Navel Orangeworm) & Sakızlanma Yokluğu',
          description: 'Kurt yeniği, delik, küf ve sakızlı tane varlığının elenmesi.',
          criteria: 'Kusurlu dane < %1.5 tolerans',
          category: 'Kusur & Sağlık',
          autoStatus: 'PASSED',
          statusMessage: '✓ Zararlı hasarı tolerans içi'
        },
        {
          id: 'almond_ground_prep',
          title: 'Yer Brandası & Silkeleme Makinesi Kauçuk Ped Hijyeni',
          description: 'Meyvelerin doğrudan toprakla temas etmemesi için brandaların açılması.',
          criteria: 'Temiz zemin brandaları serili',
          category: 'Saha Hijyeni',
          autoStatus: 'PASSED',
          statusMessage: '✓ Branda ve silkeleyici hazır'
        }
      ];

      maturityStageLabel = splitPercent >= 90 && moisture <= 7.0 ? 'Silkme ve Hasada Hazır' : 'Olgunlaşma İzleniyor';
      readinessVerdict = `Parsel ${parcelText}: Badem parseli yeşil kabuk çatlama (%${splitPercent}) ve nem (%${moisture}) kriterlerine göre değerlendirildi.`;

    } else {
      // Genel Meyve & Sebze Hasat Öncesi Kontrol Listesi
      items = [
        {
          id: 'gen_brix',
          title: 'Refraktometre Çözünür Kuru Madde (Brix °Bx)',
          description: 'Meyve şekeri ve tat olgunluğunun hedef standartla uyumu.',
          criteria: 'Hedef standart asgari Brix değeri',
          category: 'Şeker',
          autoStatus: avgBrix > 0 ? (avgBrix >= 10.0 ? 'PASSED' : 'WARNING') : 'PENDING',
          statusMessage: avgBrix > 0 ? `Ortalama: ${avgBrix.toFixed(1)} °Bx` : 'Ölçüm bekleniyor'
        },
        {
          id: 'gen_firmness',
          title: 'Meyve Eti Sertliği ve Basınç Direnci',
          description: 'Taşıma ve raf ömrü için gereken asgari meyve sertliği.',
          criteria: 'Uluslararası kabul edilebilir sertlik aralığı',
          category: 'Sertlik',
          autoStatus: avgHardness > 0 ? (avgHardness >= 4.0 ? 'PASSED' : 'WARNING') : 'PENDING',
          statusMessage: avgHardness > 0 ? `Ortalama: ${avgHardness.toFixed(1)} kg/cm²` : 'Ölçüm bekleniyor'
        },
        {
          id: 'gen_color',
          title: 'Renklenme & Zemin Rengi Dönüşümü (%)',
          description: 'Çeşide özgü hasat rengi ve zemin klorofil kaybı.',
          criteria: 'Asgari %50-70 renk gelişimi',
          category: 'Renk',
          autoStatus: colorationPercent != null && colorationPercent >= 50 ? 'PASSED' : 'PENDING',
          statusMessage: colorationPercent != null ? `%${colorationPercent} renklenme` : 'İsteğe bağlı test'
        },
        {
          id: 'gen_defects',
          title: 'Güneş Yanığı, Yara & Haşere Kusur Taraması',
          description: 'Parsel genelindeki toplam ıskarta ve leke oranı.',
          criteria: 'Toplam kusur < %5.0',
          category: 'Kusur',
          autoStatus: defectPercent != null && defectPercent <= 5.0 ? 'PASSED' : 'WARNING',
          statusMessage: defectPercent != null ? `%${defectPercent} kusur oranı` : 'Ölçüm bekleniyor'
        },
        {
          id: 'gen_prep',
          title: 'Hasat Kasası Hijyeni & Gölge Sevk Alanı',
          description: 'Güneş altında bekletmeden hızlı gölge alana ve frigo araçlara sevk planı.',
          criteria: 'SFAC PHM-SOP Soğuk Zincir Direktifleri',
          category: 'Lojistik Hazırlık',
          autoStatus: 'PASSED',
          statusMessage: '✓ Hasat kasaları ve lojistik hazır'
        }
      ];

      maturityStageLabel = avgBrix >= 10 && avgHardness >= 4.0 ? 'Hasat Olgunluğunda' : 'Gelişim Devam Ediyor';
      readinessVerdict = `Parsel ${parcelText}: Saha numune testleri doğrultusunda parsel hasat olgunluğu izlenmektedir.`;
    }

    // Dynamic readiness score calculation (%):
    const totalItems = items.length;
    const passedCount = items.filter(it => {
      if (checkedListIds[it.id] !== undefined) {
        return checkedListIds[it.id];
      }
      return it.autoStatus === 'PASSED';
    }).length;

    const readinessScore = totalItems > 0 ? Math.round((passedCount / totalItems) * 100) : 0;

    return {
      category: checklistCropCategory,
      items,
      totalItems,
      passedCount,
      readinessScore,
      maturityStageLabel,
      readinessVerdict,
      parcelText
    };
  }, [
    checklistCropCategory,
    product,
    sortVariety,
    selectedParcels,
    location,
    avgBrix,
    avgHardness,
    avgStarch,
    streifResult,
    hasStarchTest,
    colorationPercent,
    defectPercent,
    specialMetric1,
    specialMetric2,
    avgDiameter,
    checkedListIds
  ]);

  // Kalite Sapma ve Freeze & Dry Kontrolü
  const isQualityDeviated = useMemo(() => {
    const isNonStandardGrade = 
      qualityGrade === 'Standart Däl / Standart Dışı' || 
      qualityGrade === 'Sanayi / Iskarta' ||
      qualityGrade === 'Mix';
    const isStreifOverripe = hasStarchTest && streifResult.status === 'IMMEDIATE_CONSUMPTION' && finalProductStatus === 'COLD_STORAGE';
    return (
      evaluationResult.overallStatus === 'FAIL' ||
      avgHardness < 3.8 ||
      defectPercent > 10 ||
      isStreifOverripe ||
      isNonStandardGrade ||
      !nitratePass ||
      finalProductStatus === 'FREEZE_DRY'
    );
  }, [evaluationResult, avgHardness, defectPercent, qualityGrade, nitratePass, finalProductStatus, hasStarchTest, streifResult]);

  // Otomatik Kalite Değerlendirmesi Sonuçlarını Forma Uygulama Fonksiyonu
  const handleApplyEvaluationToForm = () => {
    setKaliteSinifi(evaluationResult.recommendedGrade);
    setQualityGrade(evaluationResult.recommendedGrade);
    setDecision(evaluationResult.recommendedDecision);
    setNextStep(evaluationResult.recommendedNextStep);

    if (evaluationResult.shouldRerouteToFreezeDry) {
      setFinalProductStatus('FREEZE_DRY');
      setRejectionReason(evaluationResult.summaryText);
    } else if (finalProductStatus === 'FREEZE_DRY' && evaluationResult.overallStatus === 'PASS') {
      setFinalProductStatus('FRESH_SALE');
      setRejectionReason('');
    }
  };

  const handleSubmit = (e?: React.FormEvent, forceStatus?: 'ACTIVE' | 'COMPLETED') => {
    if (e) e.preventDefault();

    const effectiveStatus = forceStatus || testStatus;
    // v2.5: açık testin ölçümü girilmeden kayıt yok
    const missing: string[] = [];
    if (hasNitrateTest && nitrateMgKg == null) missing.push('Nitrat (mg/kg)');
    if (hasNitrateTest && nitrateLimitMgKg == null) missing.push('Nitrat limiti (mg/kg)');
    if (hasHueAngleTest && hueAngle == null) missing.push('Hue açısı');
    if (hasColorationTest && colorationPercent == null) missing.push('Renklenme (%)');
    if (hasDefectTest && defectPercent == null) missing.push('Kusur oranı (%)');
    if (missing.length) {
      window.alert('Açık testlerin ölçümünü girin ya da testi kapatın:\n• ' + missing.join('\n• '));
      return;
    }
    const finalOperator = operator.trim() || getCurrentUser()?.fullName || 'Belirtilmedi';
    const finalProduct = product.trim() || 'Meyve / Saha Numunesi';
    const finalOrchard = orchard.trim() || 'Saha / Bahçe (Genel)';

    let finalRefId = '';
    if (isEditing && initialRecord) {
      finalRefId = initialRecord.refId;
    } else if (isNewRef) {
      finalRefId = customRefInput.trim()
        ? customRefInput.trim()
        : generateRefId('FIELD', existingRefs.map(r => r.refId));
    } else {
      finalRefId = selectedRefId.trim() || customRefInput.trim() || generateRefId('FIELD', existingRefs.map(r => r.refId));
    }

    if (!finalRefId) {
      finalRefId = generateRefId('FIELD', []);
    }

    const rerouted = finalProductStatus === 'FREEZE_DRY' || isQualityDeviated;

    const currentPreset = CROP_PRESETS[specialCropType];
    let specialCropTest: SpecialCropTestResult | undefined = undefined;
    if (hasSpecialCropTest && specialCropType !== 'NONE' && currentPreset) {
      const calcResult = currentPreset.calculate(specialMetric1, specialMetric2);
      specialCropTest = {
        cropType: specialCropType,
        cropNameTr: currentPreset.cropNameTr,
        metric1Name: currentPreset.metric1Label,
        metric1Value: specialMetric1,
        metric1Unit: currentPreset.metric1Unit,
        metric2Name: currentPreset.metric2Label,
        metric2Value: specialMetric2,
        metric2Unit: currentPreset.metric2Unit,
        statusBadge: calcResult.statusBadge,
        interpretation: calcResult.interpretation
      };
    }

    const fieldRecord: FieldRecord = {
      id: (isEditing && initialRecord?.id) 
        ? initialRecord.id 
        : `field-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      refId: finalRefId,
      timestamp: initialRecord?.timestamp || new Date().toISOString(),
      operator: finalOperator,
      product: finalProduct,
      sortVariety,
      orchard: finalOrchard,
      location,
      testType: testType || 'Hasattan Önce (Ön Hasat Olgunluk Testi)',
      sampleCount: samples.length,
      samples,
      avgHardness,
      avgBrix,
      avgDiameter,

      // Test Ağırlığı ve Meyve Gramajı (Kg / Gram / Meyve Gram)
      testSampleWeightKg: testSampleWeightKg > 0 ? testSampleWeightKg : undefined,
      testSampleWeightG: effectiveTotalWeightG > 0 ? effectiveTotalWeightG : undefined,
      avgFruitWeightG: effectiveAvgFruitWeightG > 0 ? effectiveAvgFruitWeightG : undefined,
      fruitCountSampled: fruitCountSampled > 0 ? fruitCountSampled : samples.length,

      hasStarchTest,
      starchIndex: hasStarchTest ? avgStarch : undefined,
      streifIndex: hasStarchTest && streifResult.streifIndex > 0 ? streifResult.streifIndex : undefined,
      streifInterpretation: hasStarchTest && streifResult.streifIndex > 0 ? streifResult.interpretation : undefined,
      specialCropTest,
      qualityStandardOrg: selectedStandard,
      qualityStandardVerdict: evaluationResult.overallStatus,

      // Seçmeli / Opsiyonel Parametreler
      hasNitrateTest,
      nitrateMgKg: hasNitrateTest ? (nitrateMgKg ?? undefined) : undefined,
      nitrateLimitMgKg: hasNitrateTest ? (nitrateLimitMgKg ?? undefined) : undefined,
      nitratePass: hasNitrateTest ? nitratePass : undefined,

      hasHueAngleTest,
      hueAngle: hasHueAngleTest ? (hueAngle ?? undefined) : undefined,
      hueAngleVerdict: hasHueAngleTest && hueAngle != null ? (hueAngle <= 10 ? 'OPTIMAL' : 'WARNING') : undefined,
      fertilizationNotes: hasFertilizationNotes ? fertilizationNotes : undefined,

      colorationPercent: hasColorationTest ? (colorationPercent ?? undefined) : undefined,

      hasDefectTest,
      defectPercent: hasDefectTest ? (defectPercent ?? undefined) : undefined,

      hasQualityGrade,
      kaliteSinifi: hasQualityGrade ? kaliteSinifi : undefined,
      qualityGrade: hasQualityGrade ? kaliteSinifi : undefined,

      harvestDate,
      decision: decision || evaluationResult.recommendedDecision,
      finalProductStatus,
      rejectionReason: rerouted ? (rejectionReason || evaluationResult.summaryText) : undefined,
      reroutedToFreezeDry: rerouted,
      splitLots: splitLots.length > 0 ? splitLots : undefined,
      testStatus: effectiveStatus,
      nextStep: nextStep || evaluationResult.recommendedNextStep,
      notes,
      preHarvestScore: preHarvestChecklistData.readinessScore,
      preHarvestChecklist: preHarvestChecklistData.items.map((it) => ({
        id: it.id,
        title: it.title,
        description: it.description,
        criteria: it.criteria,
        category: it.category,
        checked: checkedListIds[it.id] !== undefined ? checkedListIds[it.id] : it.autoStatus === 'PASSED',
        autoStatus: it.autoStatus
      })),
      ambientTempC: fieldTempC,
      ambientHumidityPct: fieldHumidityPct,
      photos
    };

    const newRefData: Partial<ReferenceItem> | undefined = (isNewRef && !isEditing)
      ? {
          refId: finalRefId,
          moduleKey: 'FIELD',
          product: `${finalProduct}${sortVariety ? ` (${sortVariety})` : ''}`,
          orchard: finalOrchard,
          location,
          source: finalOrchard || location,
          destination: rerouted ? 'Freeze & Dry İşleme Tesisi' : (destination || 'Zirai Kalite Laboratuvarı / Numune Arşivi'),
          finalDestination: rerouted ? 'Freeze & Dry İşleme Tesisi' : (destination || 'Zirai Kalite Laboratuvarı / Numune Arşivi'),
          quantity: 0,
          unit: 'kg',
          status: effectiveStatus === 'COMPLETED' ? 'COMPLETED' : 'CREATED',
          createdAt: new Date().toISOString(),
          operator: finalOperator,
          reroutedToFreezeDry: rerouted,
          rerouteReason: rejectionReason || evaluationResult.summaryText,
          notes: `Meyve Testi / Fruit Test [${testType || 'Hasattan Önce'}]. Hasat Hazırlık Skoru: %${preHarvestChecklistData.readinessScore} [${preHarvestChecklistData.maturityStageLabel}]. Standart: ${selectedStandard} [${evaluationResult.overallStatus}]. Karar: ${decision || evaluationResult.recommendedDecision}. Ort Brix: ${avgBrix}%, Ort Sertlik: ${avgHardness} kg/cm², Ort Meyve: ${effectiveAvgFruitWeightG}g (Test: ${testSampleWeightKg} kg / ${fruitCountSampled} adet)`
        }
      : undefined;

    onSave(fieldRecord, isNewRef && !isEditing, newRefData);
  };

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-depth overflow-hidden w-full max-w-full min-w-0">
      {/* Header */}
      <div className="bg-[#0f4a33] text-white px-3.5 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-emerald-950">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 shrink-0 shadow-inner-subtle">
            <Apple className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                🍎 Meyve &amp; Sebze Kalite Testi
              </h2>
              <span className="px-2 py-0.5 rounded-md text-[9px] sm:text-[10px] font-mono font-bold uppercase bg-emerald-900/80 text-emerald-200 border border-emerald-700/80">
                OECD • UNECE • PAZAR • FREEZE &amp; DRY • KONSANTRE • TM OBA HOJALYK
              </span>
              {isEditing && (
                <span className="px-2 py-0.5 rounded-md text-[9px] sm:text-[10px] font-bold uppercase bg-amber-500 text-slate-950 shadow-xs">
                  Düzenleme Modu
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-emerald-200/80 truncate sm:whitespace-normal mt-0.5">
              Seçilen meyveye göre otomatik filtrelenen kalite limitleri, Brix, penetrometre sertlik, nitrat ve Geçti/Kaldı motoru
            </p>
          </div>
        </div>

        {/* Freeze & Dry Rozeti */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          {(finalProductStatus === 'FREEZE_DRY' || isQualityDeviated) && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-purple-900 text-purple-200 border border-purple-400 rounded-xl text-[11px] sm:text-xs font-black animate-pulse shadow-md">
              <Snowflake className="w-3.5 h-3.5 text-purple-300 shrink-0" />
              <span>Freeze &amp; Dry</span>
            </div>
          )}

          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1.5 text-xs font-semibold text-emerald-100 hover:text-white bg-emerald-900/70 hover:bg-emerald-900 px-3 py-1.5 rounded-xl border border-emerald-700/80 transition-all btn-tactile cursor-pointer shadow-xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Geri Dön / Back</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-3 sm:p-6 space-y-5 sm:space-y-6 w-full max-w-full min-w-0">
        
        {/* COMPLETED / READ-ONLY BANNER */}
        {isCompletedRecord && (
          <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-start sm:items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                <FileCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-xs font-black uppercase tracking-wide text-emerald-400">
                    Kayıt Durumu: Tamamlandı / Status: Completed
                  </h4>
                  <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-950 text-emerald-300 border border-emerald-600">
                    {isReadOnly ? 'Salt Okunur (Read-Only)' : 'Düzenleme Açık (Unlocked)'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  {isReadOnly 
                    ? 'Bu saha meyve testi tamamlanmış ve arşivlenmiştir. Veri güvenliği gereği form alanları salt okunurdur.'
                    : 'Kilit açıldı. Yapılan değişiklikler kaydedildiğinde mevcut referans ve test verileri güncellenecektir.'}
                </p>
              </div>
            </div>

            {isReadOnlyProp ? (
              <span className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-amber-950 bg-amber-400 border border-amber-300 flex items-center gap-1.5 shadow-xs">
                <Lock className="w-3.5 h-3.5" />
                <span>Ziyaretçi Modu (Salt Okunur)</span>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => setIsReadOnly(prev => !prev)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-1.5 shadow-sm cursor-pointer ${
                  isReadOnly
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                {isReadOnly ? (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Kilidi Aç ve Düzenle / Unlock & Edit</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Tekrar Kilitle / Lock</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}

        <fieldset disabled={isReadOnly} className="space-y-5 sm:space-y-6 w-full max-w-full min-w-0 block border-0 p-0 m-0">

        {/* 1. REFERANS SEÇİMİ / MODU */}
        {!isEditing && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 sm:gap-4 w-full max-w-full min-w-0">
            <div className="w-full md:w-auto min-w-0">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-800 block mb-1.5">
                Referans ID / Reference Mode
              </span>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
                <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${isNewRef ? 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-1 ring-emerald-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                  <input
                    type="radio"
                    checked={isNewRef}
                    onChange={() => {
                      setIsNewRef(true);
                      setIsProductLocked(false);
                      setIsVarietyLocked(false);
                      setIsLocationLocked(false);
                    }}
                    className="text-emerald-600 focus:ring-emerald-500 shrink-0"
                  />
                  <span className="leading-tight">Yeni Referans Oluştur <span className="text-slate-400 text-[10px] font-normal">/ New</span></span>
                </label>

                <label className={`flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg border cursor-pointer transition ${!isNewRef ? 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-1 ring-emerald-400' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`}>
                  <input
                    type="radio"
                    checked={!isNewRef}
                    onChange={() => setIsNewRef(false)}
                    className="text-emerald-600 focus:ring-emerald-500 shrink-0"
                  />
                  <span className="leading-tight">Mevcut Referansa Bağla <span className="text-slate-400 text-[10px] font-normal">/ Existing</span></span>
                </label>
              </div>
            </div>

            <div className="w-full md:w-auto min-w-0">
              {isNewRef ? (
                <input
                  type="text"
                  value={customRefInput}
                  onChange={(e) => setCustomRefInput(e.target.value)}
                  placeholder="Otomatik (FIELD-...) veya Özel Kod"
                  className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-emerald-300 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 max-w-full"
                />
              ) : (
                <div className="space-y-1 w-full min-w-0">
                  <select
                    value={selectedRefId}
                    onChange={(e) => setSelectedRefId(e.target.value)}
                    className="w-full md:w-80 text-xs font-mono font-bold bg-white border border-emerald-400 text-slate-900 rounded-lg px-3 py-2 shadow-sm focus:ring-2 focus:ring-emerald-500 max-w-full truncate"
                  >
                    <option value="">-- Referans Seçiniz / Select Ref --</option>
                    {existingRefs.map(r => (
                      <option key={r.refId} value={r.refId}>
                        {r.refId} — {r.product} [{r.quantity} {r.unit}]
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAMAMLANMIŞ TİCARİ HASAT MİKTARI (SALT OKUNUR) */}
        {!isNewRef && selectedRefId && (
          <div className="bg-slate-900 text-white border border-emerald-500/50 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                <Lock className="w-4 h-4" />
              </span>
              <div>
                <span className="text-xs font-black uppercase text-emerald-300 tracking-wider flex items-center gap-1.5">
                  <span>Tamamlanmış Ticari Hasat Miktarı (Salt Okunur / Read-Only)</span>
                  <span className="text-[9px] font-mono font-bold text-slate-400 bg-slate-800 border border-slate-700 px-1.5 py-0.5 rounded">
                    🔒 Kilitli Stok
                  </span>
                </span>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Bu referansa ait onaylı ticari stok miktarıdır. Aşağıdaki test numunesi ağırılığı ({testSampleWeightKg} kg) ile 100% ayrıştırılmıştır.
                </p>
              </div>
            </div>
            <div className="font-mono text-right shrink-0 self-end sm:self-auto bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <span className="text-base font-black text-emerald-400 block">
                {selectedRefObj?.quantity ? `${Number(selectedRefObj.quantity).toLocaleString('tr-TR')} kg` : '0 kg'}
              </span>
              <span className="text-[10px] font-bold text-slate-400 block">
                ({selectedRefObj?.quantity ? (Number(selectedRefObj.quantity) / 1000).toFixed(2) : '0.00'} Ton Ticari Stok)
              </span>
            </div>
          </div>
        )}

        {/* 2. DOLDURULMASI GEREKEN TEMEL BİLGİLER (Mobil Öncelikli Üst Alan) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>1. Temel Saha & Bahçe Bilgileri (Doldurulacak Alanlar)</span>
            </h3>
            <span className="text-[10px] text-slate-500 font-medium">Zorunlu / Ana Parametreler</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            <SmartCreatableSelect
              label="Operatör / Operator *"
              categoryKey="operators"
              options={AUTOCOMPLETE_LISTS.operators}
              value={operator}
              onChange={setOperator}
              placeholder="Operatör seçin veya yazın..."
            />

            <SmartCreatableSelect
              label="Test Türü / Aşaması *"
              categoryKey="field_test_types"
              options={[
                'Hasattan Önce (Ön Hasat Olgunluk Testi)',
                'Hasat Testi (Ana Hasat Kontrolü)',
                'Sevkiyattan Önce (Soğuk Depo / Çıkış Kalite Testi)',
                '1. Hasat Testi',
                '2. Test (Seçme Hasat)',
                'Özel / Şüpheli Kontrol Testi'
              ]}
              value={testType}
              onChange={setTestType}
            />

            <SmartInput
              label="Hasat / Test Tarihi *"
              type="date"
              value={harvestDate}
              onChange={(e) => setHarvestDate(e.target.value)}
            />

            <SmartCreatableSelect
              label="Ürün (Meyve/Sebze) *"
              categoryKey="products"
              options={AUTOCOMPLETE_LISTS.products}
              value={product}
              onChange={(val) => {
                setProduct(val);
                const norm = (val || '').toLowerCase();
                if (norm.includes('elma') || norm.includes('alma') || norm.includes('apple')) {
                  setHasStarchTest(true);
                  setSpecialCropType('APPLE_PEAR');
                }
              }}
              isLocked={isProductLocked}
              onToggleLock={() => setIsProductLocked(!isProductLocked)}
            />

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700">
                  Çeşit (Sort / Variety) *
                </label>
                <button
                  type="button"
                  onClick={() => setIsAdminOptionsModalOpen(true)}
                  className="text-[10px] font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-50 border border-indigo-200 px-1.5 py-0.5 rounded transition flex items-center gap-1 cursor-pointer"
                  title="Admin Çeşit & Standart Yönetim Portalı"
                >
                  <ShieldCheck className="w-3 h-3 text-indigo-600" />
                  <span>Standart & Çeşit Portalı</span>
                </button>
              </div>
              <SmartCreatableSelect
                label=""
                categoryKey="varieties"
                productContext={product}
                options={[]}
                value={sortVariety}
                onChange={setSortVariety}
                isLocked={isVarietyLocked}
                onToggleLock={() => setIsVarietyLocked(!isVarietyLocked)}
                placeholder="Çeşit seçin veya yeni ekleyin (örn: Scarlet Spur, Granny Smith)..."
              />
            </div>

            <SmartCreatableSelect
              label="Bahçe / Orchard *"
              categoryKey="orchards"
              options={[]}
              value={orchard}
              onChange={setOrchard}
              placeholder="Bahçe seçin veya yeni ekleyin..."
            />

            {/* ÇOKLU PARSEL & LOKASYON SEÇİCİ (Madde 8) */}
            <div className="space-y-1 sm:col-span-2 bg-slate-50/80 p-3 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700">
                  Lokasyon / Parsel / Blok (Çoklu Seçilebilir) *
                </label>
                <span className="text-[10px] text-slate-500 font-semibold">
                  Örn: B-Z, B-2 gibi birden fazla parsel aynı teste eklenebilir
                </span>
              </div>

              {/* Seçilen Parsel Etiketleri */}
              <div className="flex flex-wrap items-center gap-1.5 min-h-[38px] p-2 bg-white border border-slate-300 rounded-xl">
                {selectedParcels.map((parcel, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-black shadow-xs"
                  >
                    <span>{parcel}</span>
                    <button
                      type="button"
                      onClick={() => {
                        const next = selectedParcels.filter((_, i) => i !== idx);
                        setSelectedParcels(next);
                        setLocation(next.join(', '));
                      }}
                      className="text-emerald-700 hover:text-rose-600 font-bold ml-0.5 p-0.5 cursor-pointer"
                      title="Parseli kaldır"
                    >
                      ×
                    </button>
                  </span>
                ))}

                {/* Yeni Parsel Ekleme Kutusu */}
                <div className="flex items-center gap-1.5 flex-1 min-w-[180px]">
                  <input
                    type="text"
                    value={newParcelInput}
                    onChange={(e) => setNewParcelInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        const trimmed = newParcelInput.trim();
                        if (trimmed && !selectedParcels.includes(trimmed)) {
                          const next = [...selectedParcels, trimmed];
                          setSelectedParcels(next);
                          setLocation(next.join(', '));
                          setNewParcelInput('');
                        }
                      }
                    }}
                    placeholder="Parsel kodu yazıp Enter'a basın (örn: B-Z, B-2)..."
                    className="flex-1 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 outline-none focus:bg-white focus:ring-1 focus:ring-emerald-500 font-bold"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const trimmed = newParcelInput.trim();
                      if (trimmed && !selectedParcels.includes(trimmed)) {
                        const next = [...selectedParcels, trimmed];
                        setSelectedParcels(next);
                        setLocation(next.join(', '));
                        setNewParcelInput('');
                      }
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg cursor-pointer transition shadow-xs"
                  >
                    + Ekle
                  </button>
                </div>
              </div>

              {/* Popüler Parsel Kısayol Butonları */}
              <div className="flex items-center gap-1 overflow-x-auto pt-1 text-[10px]">
                <span className="text-slate-400 font-bold shrink-0">Hızlı Ekle:</span>
                {['B-Z', 'B-2', 'Parsel 1.1', 'Parsel 2.1', 'Parsel 3.1', 'Badem P-8', 'GB-5-6', 'GB-7-8', 'Hem-5'].map(p => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => {
                      if (!selectedParcels.includes(p)) {
                        const next = [...selectedParcels, p];
                        setSelectedParcels(next);
                        setLocation(next.join(', '));
                      }
                    }}
                    className={`px-2 py-0.5 rounded-md border font-semibold shrink-0 cursor-pointer transition ${
                      selectedParcels.includes(p)
                        ? 'bg-emerald-500 text-white border-emerald-600 font-bold'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {selectedParcels.includes(p) ? `✓ ${p}` : `+ ${p}`}
                  </button>
                ))}
              </div>
            </div>

            {/* HEDEF TESİS (Opsiyonel & Varsayılan Kapalı - Madde 5) */}
            <div className="sm:col-span-2">
              {!showDestination ? (
                <button
                  type="button"
                  onClick={() => setShowDestination(true)}
                  className="text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl px-3 py-2 flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Building className="w-3.5 h-3.5 text-slate-600" />
                  <span>+ Hedef Tesis / Sevk Noktası Belirt (Opsiyonel - Varsayılan Kapalı)</span>
                </button>
              ) : (
                <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">Hedef Tesis / Sevk Noktası (Opsiyonel)</span>
                    <button
                      type="button"
                      onClick={() => {
                        setShowDestination(false);
                        setDestination('');
                      }}
                      className="text-[11px] text-slate-500 hover:text-rose-600 font-semibold cursor-pointer"
                    >
                      Kapat / Temizle
                    </button>
                  </div>
                  <SmartCreatableSelect
                    label=""
                    categoryKey="destinations"
                    options={[]}
                    value={destination}
                    onChange={setDestination}
                    placeholder="Hedef tesis seçin veya yeni ekleyin..."
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* HASAT ÖNCESİ KONTROL LİSTESİ & PARSEL OLGUNLUK DENETİMİ (MADDE 1)           */}
        {/* ========================================================================= */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden transition-all duration-200">
          {/* Header Bar */}
          <div className="px-4 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800 border border-emerald-200 shrink-0">
                <ClipboardCheck className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-black text-slate-900 tracking-tight">
                    Hasat Öncesi Kontrol Listesi & Parsel Olgunluk Denetimi
                  </h3>
                  <span className="text-[11px] font-bold text-slate-600 bg-white border border-slate-200 px-2 py-0.5 rounded-md">
                    {checklistCropCategory === 'APPLE' && '🍏 Elma Test Suite (WSU & Streif)'}
                    {checklistCropCategory === 'BANANA' && '🍌 Muz Kesim & MAP Öncesi'}
                    {checklistCropCategory === 'ALMOND' && '🥜 Badem Silkme & Nem'}
                    {checklistCropCategory === 'OTHER' && `🌾 ${product || 'Genel'} Olgunluk Standartları`}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 font-medium">
                  Seçili parsel ({preHarvestChecklistData.parcelText}) ve laboratuvar parametrelerine göre otomatik güncellenen hazırlık paneli
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Live Readiness Score */}
              <div className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-xl shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Parsel Hazırlık:
                </span>
                <span
                  className={`text-xs font-black font-mono ${
                    preHarvestChecklistData.readinessScore >= 80
                      ? 'text-emerald-700'
                      : preHarvestChecklistData.readinessScore >= 50
                      ? 'text-amber-700'
                      : 'text-rose-700'
                  }`}
                >
                  %{preHarvestChecklistData.readinessScore} ({preHarvestChecklistData.passedCount}/{preHarvestChecklistData.totalItems})
                </span>
              </div>

              {/* Auto Sync Button */}
              <button
                type="button"
                onClick={() => {
                  const synced: Record<string, boolean> = {};
                  preHarvestChecklistData.items.forEach((it) => {
                    synced[it.id] = it.autoStatus === 'PASSED';
                  });
                  setCheckedListIds(synced);
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 active:scale-95 border border-emerald-300 rounded-xl transition cursor-pointer"
                title="Tüm parametreleri güncel saha test sonuçlarına göre otomatik eşitle"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Otomatik Eşitle</span>
              </button>

              {/* Collapse / Expand Toggle */}
              <button
                type="button"
                onClick={() => setIsChecklistExpanded(!isChecklistExpanded)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition cursor-pointer"
                title={isChecklistExpanded ? 'Paneli Daralt' : 'Paneli Genişlet'}
              >
                {isChecklistExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {isChecklistExpanded && (
            <div className="p-4 sm:p-5 space-y-4">
              {/* Dynamic Parcel Maturity Status Banner */}
              <div
                className={`p-3.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                  preHarvestChecklistData.readinessScore >= 80
                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                    : preHarvestChecklistData.readinessScore >= 50
                    ? 'bg-amber-50/80 border-amber-200 text-amber-950'
                    : 'bg-rose-50/70 border-rose-200 text-rose-950'
                }`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap text-xs font-bold">
                    <span>📍 Parsel: {preHarvestChecklistData.parcelText}</span>
                    <span aria-hidden="true">·</span>
                    <span>Durum: {preHarvestChecklistData.maturityStageLabel}</span>
                  </div>
                  <p className="text-xs font-medium opacity-90">
                    {preHarvestChecklistData.readinessVerdict}
                  </p>
                </div>

                <div className="w-full sm:w-48 shrink-0 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold font-mono">
                    <span>Olgunluk İlerlemesi</span>
                    <span>%{preHarvestChecklistData.readinessScore}</span>
                  </div>
                  <div className="h-2 w-full bg-black/10 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 rounded-full ${
                        preHarvestChecklistData.readinessScore >= 80
                          ? 'bg-emerald-600'
                          : preHarvestChecklistData.readinessScore >= 50
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(5, preHarvestChecklistData.readinessScore))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Checklist Items Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {preHarvestChecklistData.items.map((item) => {
                  const isChecked = checkedListIds[item.id] !== undefined
                    ? checkedListIds[item.id]
                    : item.autoStatus === 'PASSED';

                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        setCheckedListIds((prev) => ({
                          ...prev,
                          [item.id]: !isChecked
                        }));
                      }}
                      className={`p-3 rounded-xl border transition-all cursor-pointer select-none space-y-2 ${
                        isChecked
                          ? 'bg-emerald-50/40 border-emerald-300 hover:border-emerald-400'
                          : item.autoStatus === 'WARNING'
                          ? 'bg-amber-50/30 border-amber-200 hover:border-amber-300'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <button
                            type="button"
                            className="mt-0.5 text-emerald-600 focus:outline-none shrink-0"
                            aria-label={`Toggle ${item.title}`}
                          >
                            {isChecked ? (
                              <CheckSquare className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400" />
                            )}
                          </button>
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                              {item.category}
                            </span>
                            <h4
                              className={`text-xs font-bold leading-snug ${
                                isChecked ? 'text-slate-900' : 'text-slate-800'
                              }`}
                            >
                              {item.title}
                            </h4>
                          </div>
                        </div>

                        {/* Status Tag */}
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded shrink-0 ${
                            item.autoStatus === 'PASSED'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : item.autoStatus === 'WARNING'
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {item.autoStatus === 'PASSED' && '✓ UYGUN'}
                          {item.autoStatus === 'WARNING' && '⚠️ DİKKAT'}
                          {item.autoStatus === 'PENDING' && '⏳ BEKLENİYOR'}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed pl-6">
                        {item.description}
                      </p>

                      <div className="pl-6 pt-1 border-t border-slate-100 flex flex-wrap items-center justify-between gap-1 text-[10px]">
                        <span className="text-slate-500 font-mono">
                          Hedef: <strong>{item.criteria}</strong>
                        </span>
                        <span
                          className={`font-semibold ${
                            item.autoStatus === 'PASSED'
                              ? 'text-emerald-700'
                              : item.autoStatus === 'WARNING'
                              ? 'text-amber-700'
                              : 'text-slate-500'
                          }`}
                        >
                          {item.statusMessage}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom Quick Control Bar */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <span className="text-[11px]">
                  💡 <strong>İpucu:</strong> Form üzerindeki Brix, Sertlik veya Nişasta ölçümlerini değiştirdikçe kriterler otomatik olarak güncellenir.
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const allChecked: Record<string, boolean> = {};
                      preHarvestChecklistData.items.forEach((it) => {
                        allChecked[it.id] = true;
                      });
                      setCheckedListIds(allChecked);
                    }}
                    className="text-[11px] font-bold text-slate-700 hover:text-emerald-700 transition cursor-pointer"
                  >
                    Tümünü Onayla
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={() => setCheckedListIds({})}
                    className="text-[11px] font-bold text-slate-500 hover:text-rose-600 transition cursor-pointer"
                  >
                    Seçimleri Sıfırla
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 3. KOMPAKT & KATLANABİLİR ULUSLARARASI STANDARTLAR VE TEST ŞABLONLARI BÖLÜMÜ */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-3.5 sm:p-4 border border-slate-700 shadow-md space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2 min-w-0">
              <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300 border border-amber-400/30 shrink-0">
                <Scale className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-white">
                    🌾 Şablon & Standart:
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                    {activeOrgInfo.shortName}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-400/30">
                    {cropParamConfig.cropName}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 truncate">
                  Min Brix: ≥{activeStandardSpec?.minBrix || 10}°Bx • Tolerans: ≤%{activeStandardSpec?.maxDefectPercent || 10}
                </p>
              </div>
            </div>

            {/* Şablonları Aç / Kapat Butonu (Mobil görünümde yer tasarrufu sağlar) */}
            <button
              type="button"
              onClick={() => setShowTemplatesExpanded(!showTemplatesExpanded)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-sm ${
                showTemplatesExpanded
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
            >
              <span>{showTemplatesExpanded ? '▲ Şablonları Kapat' : '▼ Şablonları & Standartları Değiştir'}</span>
              {showTemplatesExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Hızlı Şablon Kısayolları (Her Zaman Tek Satırda Hızlı Seçim) */}
          {!showTemplatesExpanded && (
            <div className="flex items-center gap-1.5 overflow-x-auto pt-1 pb-0.5 text-xs no-scrollbar border-t border-slate-700/60">
              <span className="text-[10px] font-bold uppercase text-amber-300 shrink-0">Hızlı Preset:</span>
              {FEATURED_CROP_TEMPLATES.slice(0, 8).map((tpl) => {
                const isActive = specialCropType === tpl.type;
                return (
                  <button
                    key={tpl.type}
                    type="button"
                    onClick={() => handleApplyCropTemplate(tpl)}
                    className={`px-2 py-0.5 rounded-lg text-[11px] font-bold whitespace-nowrap border transition cursor-pointer flex items-center gap-1 ${
                      isActive
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-black'
                        : 'bg-slate-800/60 text-slate-200 border-slate-700 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    <span>{tpl.icon}</span>
                    <span>{tpl.name}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Açıldığında Görünen Tam Standart ve Şablon Listesi */}
          {showTemplatesExpanded && (
            <div className="pt-3 border-t border-slate-700/80 space-y-3.5 animate-in fade-in duration-200">
              {/* Standart Seçici Butonları */}
              <div>
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block mb-1.5">
                  1. Uluslararası Kalite Standardı Seçimi:
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {(Object.keys(QUALITY_STANDARDS_ORGS) as QualityStandardOrg[]).map((orgKey) => {
                    const org = QUALITY_STANDARDS_ORGS[orgKey];
                    const isSelected = selectedStandard === orgKey;
                    return (
                      <button
                        key={orgKey}
                        type="button"
                        onClick={() => {
                          setSelectedStandard(orgKey);
                          const stdObj = resolveStandardSpecForOrg(specialCropType, orgKey);
                          if (stdObj?.maxNitrateMgKg) {
                            setNitrateLimitMgKg(stdObj.maxNitrateMgKg);
                          }
                        }}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 border shadow-xs ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-400/50 shadow-md'
                            : 'bg-slate-800/80 text-slate-200 border-slate-700 hover:bg-slate-700 hover:text-white'
                        }`}
                        title={org.description}
                      >
                        <ShieldCheck className={`w-3.5 h-3.5 ${isSelected ? 'text-slate-950' : 'text-emerald-400'}`} />
                        <span>{org.shortName}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Türkmenistan Çeşit Rehberi */}
              <div className="bg-slate-950/70 border border-emerald-500/30 rounded-xl p-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-emerald-300">
                    🇹🇲 Türkmenistan Oba Hojalyk Zirai Çeşit Standartları
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowTmGuide(!showTmGuide)}
                    className="px-2 py-0.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 text-[10px] font-bold border border-emerald-500/40 cursor-pointer"
                  >
                    {showTmGuide ? 'Rehberi Gizle' : 'Çeşitleri Gör'}
                  </button>
                </div>
                {showTmGuide && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 mt-2.5 pt-2 border-t border-slate-800 text-xs">
                    {TURKMENISTAN_CROP_VARIETIES_GUIDE.map(item => (
                      <div key={item.cropTr} className="bg-slate-900 border border-slate-800 rounded-xl p-2 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-300">{item.cropTr} ({item.cropTm})</span>
                          <span className="text-[10px] text-emerald-400 font-mono">{item.orchards}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 pt-0.5">
                          {item.varieties.map(v => (
                            <button
                              key={v}
                              type="button"
                              onClick={() => {
                                setProduct(item.cropTm.split('/')[0].trim());
                                setSortVariety(v);
                                setSelectedStandard('TM_OBA_HOJALYK');
                              }}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-[10px] font-semibold transition cursor-pointer"
                              title="Tıkla ve forma çeşit olarak uygula"
                            >
                              {v}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Özel Kalite Test Şablonları Kartları */}
              <div>
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block mb-1.5">
                  2. Özel Ürün Test Şablonları (Mango, Ananas, Avokado, Nar, vb.):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                  {FEATURED_CROP_TEMPLATES.map((tpl) => {
                    const isActive = specialCropType === tpl.type;
                    return (
                      <button
                        key={tpl.type}
                        type="button"
                        onClick={() => handleApplyCropTemplate(tpl)}
                        className={`p-2 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between gap-1 shadow-xs ${
                          isActive
                            ? 'bg-emerald-600/40 border-emerald-400 ring-2 ring-emerald-400 text-white shadow-md'
                            : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800 hover:border-slate-500 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-base">{tpl.icon}</span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            isActive ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-slate-700 text-slate-300'
                          }`}>
                            {isActive ? 'Aktif' : 'Seç'}
                          </span>
                        </div>
                        <div>
                          <div className="text-xs font-black text-white">{tpl.name}</div>
                          <div className="text-[10px] text-emerald-300 truncate font-semibold">{tpl.badge}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* YENİ: AĞIRLIK (KG/GRAM) & MEYVE GRAMAJI ÖLÇÜM KARTI (Madde 1) */}
        <div className="bg-gradient-to-r from-amber-50 via-emerald-50 to-teal-50 border-2 border-amber-300 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/80 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-600 text-white shadow-xs">
                <Scale className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-extrabold text-amber-950 flex items-center gap-2">
                  <span>⚖️ Test Numune Ağırlığı & Meyve Gramajı (Weight & Gram)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 border border-amber-300">
                    Ölçüm & Kalibre
                  </span>
                </h3>
                <p className="text-[11px] text-amber-800 font-medium">
                  Test edilen partinin toplam numune ağırlığı (kg/g) ile ortalama tek meyve gramajı hesaplaması
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-600 font-semibold">Ortalama Tek Meyve:</span>
              <div className="px-3 py-1 bg-white border-2 border-amber-400 rounded-xl font-mono text-sm font-black text-amber-950 shadow-xs flex items-center gap-1">
                <span>{effectiveAvgFruitWeightG > 0 ? effectiveAvgFruitWeightG : '-'}</span>
                <span className="text-[11px] font-bold text-amber-700">g/adet</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {/* 1. Test Ağırlığı (Kg) */}
            <div className="bg-white/95 p-3 rounded-xl border border-amber-200 shadow-2xs space-y-1">
              <label className="text-xs font-bold text-slate-800 flex items-center justify-between">
                <span>Toplam Test Ağırlığı (Kg)</span>
                <span className="text-[10px] text-amber-700 font-mono">Kantar / Terazi</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.005"
                  min="0.01"
                  value={testSampleWeightKg}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 0;
                    setTestSampleWeightKg(val);
                  }}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg font-bold text-amber-950 text-sm focus:ring-2 focus:ring-amber-500 font-mono outline-none"
                  placeholder="Örn: 0.950 kg"
                />
                <span className="font-bold text-slate-600 text-xs shrink-0">kg</span>
              </div>
              <span className="text-[10px] text-slate-500 block font-mono">
                = {(testSampleWeightKg * 1000).toFixed(0)} Gram (Test Toplamı)
              </span>
            </div>

            {/* 2. Tartılan Meyve Adedi */}
            <div className="bg-white/95 p-3 rounded-xl border border-amber-200 shadow-2xs space-y-1">
              <label className="text-xs font-bold text-slate-800 flex items-center justify-between">
                <span>Tartılan Meyve Adedi</span>
                <span className="text-[10px] text-slate-500 font-mono">Numune Sayısı</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={fruitCountSampled}
                  onChange={(e) => setFruitCountSampled(parseInt(e.target.value, 10) || 1)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg font-bold text-slate-900 text-sm focus:ring-2 focus:ring-amber-500 font-mono outline-none"
                  placeholder="Örn: 5 adet"
                />
                <span className="font-bold text-slate-600 text-xs shrink-0">adet</span>
              </div>
              <span className="text-[10px] text-slate-500 block">
                Tabloda {samples.length} adet numune satırı var
              </span>
            </div>

            {/* 3. Hesaplanan Tek Meyve Gramı */}
            <div className="bg-white/95 p-3 rounded-xl border border-amber-200 shadow-2xs space-y-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider block">
                  Hesaplanan Tek Meyve Gramajı
                </span>
                <div className="text-lg font-black text-amber-950 font-mono mt-0.5 flex items-baseline gap-1">
                  <span>{effectiveAvgFruitWeightG}</span>
                  <span className="text-xs font-bold text-slate-600">gram / meyve</span>
                </div>
              </div>
              <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-100 font-mono">
                Hesaplama: {testSampleWeightKg > 0 ? `${(testSampleWeightKg * 1000).toFixed(0)}g / ${fruitCountSampled} adet` : 'Ölçüm bekliyor'}
              </div>
            </div>
          </div>
        </div>

        {/* DİNAMİK NUMUNE YÖNETİMİ (EKLE / SİL & AKILLI FİLTRELEME) */}
        <div className="border border-slate-200 rounded-2xl p-3 sm:p-4 bg-slate-50/80 shadow-xs space-y-3 w-full max-w-full min-w-0 overflow-hidden">
          {/* Akıllı Parametre Profili Bilgi & Geçiş Çubuğu */}
          <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 text-white p-3 rounded-xl border border-emerald-800/60 flex flex-wrap items-center justify-between gap-2.5 shadow-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Sparkles className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-emerald-300">
                    🌾 Dinamik Test Şablonu: {cropParamConfig.cropName}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-slate-200 border border-white/10">
                    Standart: {selectedStandard}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap mt-1">
                  <span className="text-[10px] text-slate-400">Aktif Parametreler:</span>
                  {(showAllParamsManual || cropParamConfig.showBrix) && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-900/80 text-emerald-200 border border-emerald-700">
                      ✓ {cropParamConfig.brixLabel}
                    </span>
                  )}
                  {(showAllParamsManual || cropParamConfig.showHardness) && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-900/80 text-blue-200 border border-blue-700">
                      ✓ {cropParamConfig.hardnessLabel}
                    </span>
                  )}
                  {(hasStarchTest || showAllParamsManual || cropParamConfig.showStarch) && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-900/80 text-indigo-200 border border-indigo-700">
                      ✓ {cropParamConfig.starchLabel}
                    </span>
                  )}
                  {(showAllParamsManual || cropParamConfig.showDiameter) && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-900/80 text-purple-200 border border-purple-700">
                      ✓ {cropParamConfig.diameterLabel}
                    </span>
                  )}
                  {cropParamConfig.hasSpecialCropTest && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-teal-900/80 text-teal-200 border border-teal-700">
                      ✓ {cropParamConfig.specialMetricTitle || 'Özel Parametreler'}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowAllParamsManual(!showAllParamsManual)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer active:scale-95 ${
                showAllParamsManual
                  ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-black shadow-sm'
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
              title={showAllParamsManual ? 'Ürüne özel parametrelere geri dön' : 'Tüm test sütunlarını manuel aç'}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{showAllParamsManual ? '🎯 Akıllı Filtreye Dön' : '⚙️ Tüm Parametreleri Göster'}</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2.5 sm:gap-3 pt-1">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-800">
                  Numune Ölçüm Tablosu ({cropParamConfig.cropName})
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                  {samples.length} Numune
                </span>
                {hasStarchTest && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-100 text-indigo-800 border border-indigo-300 flex items-center gap-1">
                    <FlaskConical className="w-3 h-3 text-indigo-600" />
                    <span>Nişasta & SI Aktif</span>
                  </span>
                )}
                {activeStandardSpec?.minBrix !== undefined && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    Hedef: ≥ {activeStandardSpec.minBrix}°Bx
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500">
                Seçilen ürüne göre yalnızca ilgili pomolojik test parametreleri gösterilir ve limitlerle canlı denetlenir.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Nişasta & Streif Testi Aç / Kapat Butonu */}
              <button
                type="button"
                onClick={() => setHasStarchTest(!hasStarchTest)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs active:scale-95 shrink-0 cursor-pointer ${
                  hasStarchTest
                    ? 'bg-indigo-700 text-white border border-indigo-600 hover:bg-indigo-800'
                    : 'bg-white text-indigo-900 border border-indigo-300 hover:bg-indigo-50'
                }`}
              >
                <FlaskConical className="w-3.5 h-3.5 text-indigo-300" />
                <span>{hasStarchTest ? '✓ Nişasta & SI Aktif' : '+ Nişasta & SI Testi'}</span>
              </button>

              {/* Özel Ürün Testi Aç / Kapat Butonu */}
              <button
                type="button"
                onClick={() => setHasSpecialCropTest(!hasSpecialCropTest)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs active:scale-95 shrink-0 cursor-pointer ${
                  hasSpecialCropTest
                    ? 'bg-teal-700 text-white border border-teal-600 hover:bg-teal-800'
                    : 'bg-white text-teal-900 border border-teal-300 hover:bg-teal-50'
                }`}
              >
                <Gauge className="w-3.5 h-3.5 text-teal-400" />
                <span>{hasSpecialCropTest ? '✓ Özel Test Aktif' : '+ Özel Ürün Testi'}</span>
              </button>

              {/* Dinamik Numune Ekle Butonu */}
              <button
                type="button"
                onClick={handleAddSample}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0f4a33] hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs active:scale-95 shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-300" />
                <span>+ Numune Ekle</span>
              </button>

              {/* 📷 Mobil AI Kamera ile Kalibre & Renk Analizi Butonu */}
              <button
                type="button"
                onClick={() => setIsAiVisionOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-teal-600 via-teal-700 to-emerald-700 hover:from-teal-500 hover:to-emerald-600 text-white rounded-xl text-xs font-black transition shadow-md active:scale-95 shrink-0 cursor-pointer border border-teal-400/50"
                title="Akıllı telefon kamerasından kasa fotoğrafı çekerek meyve kalibre çapını ve renklenme yüzdesini 1 saniyede otomatik hesapla"
              >
                <Camera className="w-4 h-4 text-amber-300" />
                <span>📷 AI Kamera: Kalibre &amp; Renk Tara (1 sn)</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto w-full max-w-full min-w-0 -mx-1 px-1 sm:mx-0 sm:px-0">
            <table className="w-full min-w-[580px] text-left text-xs bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 w-24">Numune #</th>

                  <th className="py-2.5 px-3 bg-amber-50/70 text-amber-950">
                    Ağırlık / Weight (g)
                    <span className="block text-[9px] font-normal text-amber-800">
                      Tekil Meyve Gramı
                    </span>
                  </th>
                  
                  {(showAllParamsManual || cropParamConfig.showHardness) && (
                    <th className="py-2.5 px-3">
                      {cropParamConfig.hardnessLabel} ({cropParamConfig.hardnessUnit})
                      {activeStandardSpec?.minHardnessKgCm2 && (
                        <span className="block text-[9px] font-normal text-slate-500">
                          Hedef: {activeStandardSpec.minHardnessKgCm2}-{activeStandardSpec.maxHardnessKgCm2}
                        </span>
                      )}
                    </th>
                  )}

                  {(showAllParamsManual || cropParamConfig.showBrix) && (
                    <th className="py-2.5 px-3">
                      {cropParamConfig.brixLabel} ({cropParamConfig.brixUnit})
                      {activeStandardSpec?.minBrix && (
                        <span className="block text-[9px] font-normal text-emerald-600 font-mono">
                          Hedef: ≥ {activeStandardSpec.minBrix}°Bx
                        </span>
                      )}
                    </th>
                  )}

                  {(hasStarchTest || showAllParamsManual || cropParamConfig.showStarch) && (
                    <th className="py-2.5 px-3 text-indigo-900 bg-indigo-50/70">
                      {cropParamConfig.starchLabel} (1-10)
                    </th>
                  )}

                  {(showAllParamsManual || cropParamConfig.showDiameter) && (
                    <th className="py-2.5 px-3">
                      {cropParamConfig.diameterLabel} ({cropParamConfig.diameterUnit})
                    </th>
                  )}

                  <th className="py-2.5 px-3">Kusur & Not / Defects</th>
                  <th className="py-2.5 px-3 text-center w-16">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {samples.map((s, idx) => {
                  const brixLow = activeStandardSpec?.minBrix ? s.brix < activeStandardSpec.minBrix : s.brix < 11;
                  const hardnessOut = activeStandardSpec?.minHardnessKgCm2
                    ? (s.hardness < activeStandardSpec.minHardnessKgCm2 || (activeStandardSpec.maxHardnessKgCm2 && s.hardness > activeStandardSpec.maxHardnessKgCm2))
                    : s.hardness < 4.0;

                  return (
                    <tr key={idx} className="hover:bg-emerald-50/30 transition">
                      <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                        Numune {s.sample}
                      </td>

                      {/* Meyve Gramajı (g) */}
                      <td className="py-2 px-3 bg-amber-50/30">
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            step="1"
                            min="1"
                            value={s.weightG ?? ''}
                            placeholder="g"
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              handleSampleChange(idx, 'weightG', val);
                            }}
                            className="w-24 px-2.5 py-1 border border-amber-300 rounded-lg font-bold text-amber-950 bg-white outline-none focus:ring-2 focus:ring-amber-500"
                          />
                          <span className="text-[10px] text-slate-500 font-sans">g</span>
                        </div>
                      </td>

                      {(showAllParamsManual || cropParamConfig.showHardness) && (
                        <td className="py-2 px-3">
                          <input
                            type="number"
                            step="0.1"
                            value={s.hardness}
                            onChange={(e) => handleSampleChange(idx, 'hardness', parseFloat(e.target.value) || 0)}
                            className={`w-28 px-2.5 py-1 border rounded-lg font-bold outline-none text-slate-900 transition ${
                              hardnessOut ? 'border-amber-400 bg-amber-50 text-amber-900' : 'border-slate-300 bg-white'
                            }`}
                          />
                        </td>
                      )}

                      {(showAllParamsManual || cropParamConfig.showBrix) && (
                        <td className="py-2 px-3">
                          <input
                            type="number"
                            step="0.1"
                            value={s.brix}
                            onChange={(e) => handleSampleChange(idx, 'brix', parseFloat(e.target.value) || 0)}
                            className={`w-28 px-2.5 py-1 border rounded-lg font-bold outline-none ${
                              brixLow ? 'border-rose-400 bg-rose-50 text-rose-900' : 'border-slate-300 bg-white text-emerald-800'
                            }`}
                          />
                        </td>
                      )}

                      {(hasStarchTest || showAllParamsManual || cropParamConfig.showStarch) && (
                        <td className="py-2 px-3 bg-indigo-50/30">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min="1"
                              max="10"
                              step="0.5"
                              value={s.starch ?? 5}
                              onChange={(e) => handleSampleChange(idx, 'starch', parseFloat(e.target.value) || 1)}
                              className="w-20 px-2.5 py-1 border border-indigo-300 rounded-lg font-bold text-indigo-950 bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                            <span className="text-[10px] text-slate-500 font-sans">/ 10</span>
                          </div>
                        </td>
                      )}

                      {(showAllParamsManual || cropParamConfig.showDiameter) && (
                        <td className="py-2 px-3">
                          <input
                            type="number"
                            step="1"
                            value={s.diameterMm}
                            onChange={(e) => handleSampleChange(idx, 'diameterMm', parseFloat(e.target.value) || 0)}
                            className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg text-slate-700 bg-white outline-none"
                          />
                        </td>
                      )}

                      <td className="py-2 px-3 font-sans">
                        <input
                          type="text"
                          value={s.defects}
                          onChange={(e) => handleSampleChange(idx, 'defects', e.target.value)}
                          placeholder="Yok / Leke / Çizik"
                          className="w-full px-2.5 py-1 border border-slate-300 rounded-lg text-xs text-slate-700 bg-white outline-none"
                        />
                      </td>

                      <td className="py-2 px-3 text-center font-sans">
                        <button
                          type="button"
                          onClick={() => handleRemoveSample(idx)}
                          disabled={samples.length <= 1}
                          title={samples.length <= 1 ? 'En az 1 numune kalmalıdır' : 'Numuneyi Sil / Delete Sample'}
                          className={`p-1.5 rounded-lg transition cursor-pointer ${
                            samples.length <= 1
                              ? 'text-slate-300 cursor-not-allowed'
                              : 'text-rose-600 hover:bg-rose-50 hover:text-rose-800'
                          }`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-emerald-50/90 font-bold border-t border-emerald-300 text-emerald-950 font-mono">
                <tr>
                  <td className="py-2.5 px-3 font-sans text-xs">DİNAMİK ORTALAMA:</td>

                  <td className="py-2.5 px-3 text-sm text-amber-950 bg-amber-100/60 font-mono">
                    <div>{effectiveAvgFruitWeightG > 0 ? `${effectiveAvgFruitWeightG} g` : '-'}</div>
                    <div className="text-[10px] text-amber-800 font-sans font-normal">
                      Toplam: {(effectiveTotalWeightG / 1000).toFixed(3)} kg
                    </div>
                  </td>
                  
                  {(showAllParamsManual || cropParamConfig.showHardness) && (
                    <td className="py-2.5 px-3 text-sm">{avgHardness.toFixed(2)} {cropParamConfig.hardnessUnit}</td>
                  )}

                  {(showAllParamsManual || cropParamConfig.showBrix) && (
                    <td className="py-2.5 px-3 text-sm">{avgBrix.toFixed(2)} {cropParamConfig.brixUnit}</td>
                  )}

                  {(hasStarchTest || showAllParamsManual || cropParamConfig.showStarch) && (
                    <td className="py-2.5 px-3 text-sm text-indigo-950 bg-indigo-100/60 font-mono">
                      <div>{avgStarch.toFixed(1)} / 10</div>
                      {streifResult.streifIndex > 0 && (
                        <div className="text-[10px] text-indigo-700 font-sans">SI: {streifResult.streifIndex}</div>
                      )}
                    </td>
                  )}

                  {(showAllParamsManual || cropParamConfig.showDiameter) && (
                    <td className="py-2.5 px-3 text-sm">{avgDiameter.toFixed(1)} {cropParamConfig.diameterUnit}</td>
                  )}

                  <td colSpan={2} className="py-2.5 px-3 font-sans text-[11px] text-emerald-800">
                    {samples.length} numune meyve analiz edildi
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Nişasta & Streif İndeksi (SI) Hasat / Depoluk Analiz Paneli */}
          {hasStarchTest && (
            <div className="bg-gradient-to-r from-indigo-50 via-slate-50 to-blue-50 border border-indigo-200 rounded-2xl p-3.5 sm:p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-indigo-100 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-xs">
                    <FlaskConical className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-indigo-950 flex items-center gap-1.5">
                      🧪 Nişasta-İyot Testi & Streif Hasat / Depolama İndeksi (SI)
                    </h4>
                    <p className="text-[11px] text-indigo-700">
                      Elma ve armutlarda optimum hasat penceresi ve soğuk hava depolama ömrünü belirleyen pomolojik indeks
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-500 font-semibold">Streif İndeksi (SI):</span>
                  <div className="px-3 py-1 bg-white border border-indigo-300 rounded-xl font-mono text-base font-black text-indigo-950 shadow-xs">
                    {streifResult.streifIndex > 0 ? streifResult.streifIndex : '-'}
                  </div>
                </div>
              </div>

              {/* Formül ve Canlı Değer Dağılımı */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
                <div className="bg-white/90 p-2.5 rounded-xl border border-indigo-100">
                  <span className="text-[10px] text-slate-500 block">Hesaplama Formülü</span>
                  <div className="font-mono text-xs font-bold text-slate-800 mt-0.5">
                    SI = Sertlik / (Brix × Nişasta)
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-1">
                    {avgHardness.toFixed(2)} / ({avgBrix.toFixed(2)} × {avgStarch.toFixed(1)})
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-indigo-100">
                  <span className="text-[10px] text-slate-500 block">Nişasta-İyot Dönüşüm Durumu</span>
                  <div className="font-semibold text-xs text-indigo-900 mt-0.5">
                    {streifResult.starchStageText}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    Ortalama: <strong className="font-mono text-indigo-950">{avgStarch.toFixed(1)}</strong> / 10
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-indigo-100">
                  <span className="text-[10px] text-slate-500 block">Hasat & Depolama Önerisi</span>
                  <div className={`mt-1 px-2.5 py-1 rounded-lg border text-[11px] font-extrabold ${streifResult.badgeClass}`}>
                    {streifResult.interpretation}
                  </div>
                </div>
              </div>

              {/* WSU 1-6 Nişasta-İyot Test Skalası Görsel Rehberi & Açıklama Kutusu */}
              <div className="pt-2 border-t border-indigo-100/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                    🍏 WSU (Washington State University) 1-6 Nişasta-İyot Test Skalası &amp; Görsel Rehber:
                  </span>
                  <span className="text-[10px] bg-indigo-200 text-indigo-900 px-2 py-0.5 rounded-full font-bold">
                    Elma &amp; Armut Standart Skalası
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-1.5 text-[10px]">
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 1 })))}
                    className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-100 rounded-xl border border-slate-700 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group"
                    title="Tıkla: Tüm numuneleri Skala 1 (1.0) olarak ata"
                  >
                    <strong className="block text-slate-200 group-hover:text-teal-300 font-black text-xs">Skala 1 (1.0)</strong>
                    <span className="text-[9px] text-slate-300 block mt-0.5">Tamamen Siyah / Mor (Ham)</span>
                  </div>
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 2 })))}
                    className="p-2 bg-indigo-950 hover:bg-indigo-900 text-indigo-200 rounded-xl border border-indigo-800 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group"
                    title="Tıkla: Tüm numuneleri Skala 2 (2.0) olarak ata"
                  >
                    <strong className="block text-indigo-300 group-hover:text-teal-300 font-black text-xs">Skala 2 (2.0)</strong>
                    <span className="text-[9px] text-indigo-300 block mt-0.5">Çekirdek Lekeli (Erken CA)</span>
                  </div>
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 3 })))}
                    className="p-2 bg-cyan-950 hover:bg-cyan-900 text-cyan-200 rounded-xl border border-cyan-800 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group ring-1 ring-cyan-500/40"
                    title="Tıkla: Tüm numuneleri Skala 3 (3.0) olarak ata (İdeal CA Depo)"
                  >
                    <strong className="block text-cyan-300 group-hover:text-teal-300 font-black text-xs">Skala 3 (3.0) ★</strong>
                    <span className="text-[9px] text-cyan-300 block mt-0.5">Yarı Boyalı (Optimum CA)</span>
                  </div>
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 4 })))}
                    className="p-2 bg-emerald-950 hover:bg-emerald-900 text-emerald-200 rounded-xl border border-emerald-800 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group"
                    title="Tıkla: Tüm numuneleri Skala 4 (4.0) olarak ata"
                  >
                    <strong className="block text-emerald-300 group-hover:text-teal-300 font-black text-xs">Skala 4 (4.0)</strong>
                    <span className="text-[9px] text-emerald-300 block mt-0.5">Yarıdan Fazla Temiz (Soğuk Depo)</span>
                  </div>
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 5 })))}
                    className="p-2 bg-amber-950 hover:bg-amber-900 text-amber-200 rounded-xl border border-amber-800 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group"
                    title="Tıkla: Tüm numuneleri Skala 5 (5.0) olarak ata"
                  >
                    <strong className="block text-amber-300 group-hover:text-teal-300 font-black text-xs">Skala 5 (5.0)</strong>
                    <span className="text-[9px] text-amber-300 block mt-0.5">Az Lekeli (Taze Pazar Sevk)</span>
                  </div>
                  <div 
                    onClick={() => setSamples(prev => prev.map(s => ({ ...s, starch: 6 })))}
                    className="p-2 bg-rose-950 hover:bg-rose-900 text-rose-200 rounded-xl border border-rose-800 text-center cursor-pointer transition active:scale-95 hover:border-teal-400 group"
                    title="Tıkla: Tüm numuneleri Skala 6 (6.0) olarak ata"
                  >
                    <strong className="block text-rose-300 group-hover:text-teal-300 font-black text-xs">Skala 6 (6.0)</strong>
                    <span className="text-[9px] text-rose-300 block mt-0.5">Tam Beyaz (Aşırı Olgun)</span>
                  </div>
                </div>

                {/* Saha / Laboratuvar Dijital Cihaz & IoT Bağlantısı (İsteğe Bağlı) */}
                <div className="pt-2">
                  <IoTDataloggerConnector
                    moduleName="FIELD"
                    targetTempMin={1.0}
                    targetTempMax={4.0}
                    onTelemetryUpdate={(data) => {
                      if (data) {
                        setFieldTempC(data.temperatureC);
                        setFieldHumidityPct(data.humidityPercent);
                      }
                    }}
                  />
                </div>
              </div>

              {/* WSU Çeşit Odaklı Hasat & Olgunluk Kriterleri (Madde 9 & SFAC SOP Madde 6) */}
              <div className="pt-3 border-t border-indigo-200 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <Apple className="w-4 h-4 text-indigo-700 shrink-0" />
                    <span className="text-xs font-black text-indigo-950">
                      🏛️ WSU &amp; SFAC SOP Çeşit Odaklı Olgunluk Standartları:
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsSfacGuideOpen(!isSfacGuideOpen)}
                      className="px-2.5 py-1 bg-teal-100 hover:bg-teal-200 text-teal-900 border border-teal-300 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition shadow-xs"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-teal-700" />
                      <span>{isSfacGuideOpen ? 'SOP Kılavuzunu Kapat' : 'SFAC PHM-SOP Rehberini Aç'}</span>
                    </button>
                    <span className="text-[10px] text-indigo-800 font-bold bg-indigo-100 px-2 py-0.5 rounded-full">
                      Seçili Çeşit: {sortVariety || 'Genel Elma'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[11px]">
                  {/* Granny Smith */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('granny')
                      ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-emerald-950">
                      <span>🍏 Granny Smith</span>
                      <span className="text-[10px] text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded font-mono">CA: 9-12 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>7.0 - 8.5 kg/cm²</strong> • Brix: <strong>11.5 - 13.5°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>2.5 - 3.5</strong> • SI: <strong>≥ 0.16 - 0.22</strong></div>
                      <div className="text-[10px] text-emerald-800 font-medium mt-1">
                        Asitlik yüksek, erken hasatta nişasta hidrolizi yavaş izlenmelidir.
                      </div>
                    </div>
                  </div>

                  {/* Golden Delicious */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('golden')
                      ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-amber-950">
                      <span>🟡 Golden Delicious</span>
                      <span className="text-[10px] text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded font-mono">Depo: 4-7 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>6.0 - 7.5 kg/cm²</strong> • Brix: <strong>12.5 - 15.0°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>4.0 - 5.5</strong> • SI: <strong>0.10 - 0.16</strong></div>
                      <div className="text-[10px] text-amber-800 font-medium mt-1">
                        Zemin rengi yeşilden sarıya dönerken toplanır, erken sararma riski.
                      </div>
                    </div>
                  </div>

                  {/* Red Chief / Scarlet Spur */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('red chief') || (sortVariety || '').toLowerCase().includes('scarlet')
                      ? 'bg-rose-50 border-rose-400 ring-2 ring-rose-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-rose-950">
                      <span>🍎 Red Chief / Scarlet Spur</span>
                      <span className="text-[10px] text-rose-800 bg-rose-100 px-1.5 py-0.2 rounded font-mono">Depo: 6-9 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>6.5 - 7.8 kg/cm²</strong> • Brix: <strong>12.0 - 14.5°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>3.5 - 4.5</strong> • SI: <strong>0.11 - 0.17</strong></div>
                      <div className="text-[10px] text-rose-800 font-medium mt-1">
                        ⚠️ <strong>Renk aldanması riski!</strong> Dış renk erkenden kızarır, nişasta teyit edilmelidir.
                      </div>
                    </div>
                  </div>

                  {/* Gala */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('gala')
                      ? 'bg-orange-50 border-orange-400 ring-2 ring-orange-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-orange-950">
                      <span>🍑 Gala</span>
                      <span className="text-[10px] text-orange-800 bg-orange-100 px-1.5 py-0.2 rounded font-mono">Depo: 3-5 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>7.0 - 8.5 kg/cm²</strong> • Brix: <strong>12.0 - 14.0°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>4.5 - 6.0</strong> • SI: <strong>0.12 - 0.18</strong></div>
                      <div className="text-[10px] text-orange-800 font-medium mt-1">
                        Hızlı olgunlaşır, hasat penceresi dar (7-10 gün). Çatlama riski.
                      </div>
                    </div>
                  </div>

                  {/* Fuji */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('fuji')
                      ? 'bg-purple-50 border-purple-400 ring-2 ring-purple-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-purple-950">
                      <span>🔴 Fuji</span>
                      <span className="text-[10px] text-purple-800 bg-purple-100 px-1.5 py-0.2 rounded font-mono">Depo: 8-11 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>6.8 - 8.0 kg/cm²</strong> • Brix: <strong>13.5 - 16.5°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>5.0 - 6.5</strong> • SI: <strong>0.09 - 0.15</strong></div>
                      <div className="text-[10px] text-purple-800 font-medium mt-1">
                        Geç hasat. Yüksek Brix. Aşırı olgunlukta su kalbi (watercore) riski.
                      </div>
                    </div>
                  </div>

                  {/* Pink Lady */}
                  <div className={`p-2.5 rounded-xl border transition ${
                    (sortVariety || '').toLowerCase().includes('pink')
                      ? 'bg-pink-50 border-pink-400 ring-2 ring-pink-400/40 font-bold shadow-xs'
                      : 'bg-white/90 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between text-xs font-black text-pink-950">
                      <span>🌸 Pink Lady</span>
                      <span className="text-[10px] text-pink-800 bg-pink-100 px-1.5 py-0.2 rounded font-mono">Depo: 7-10 Ay</span>
                    </div>
                    <div className="mt-1 space-y-0.5 text-slate-700">
                      <div>Sertlik: <strong>7.2 - 8.5 kg/cm²</strong> • Brix: <strong>13.0 - 15.5°Bx</strong></div>
                      <div>Nişasta (WSU): <strong>3.5 - 5.0</strong> • SI: <strong>0.13 - 0.19</strong></div>
                      <div className="text-[10px] text-pink-800 font-medium mt-1">
                        Geç hasat penceresi, dengeli asit-şeker oranı ve yüksek sertlik.
                      </div>
                    </div>
                  </div>
                </div>

                {/* SFAC PHM-SOP Açılır Paneli (Madde 6) */}
                {isSfacGuideOpen && (
                  <div className="mt-3 p-3.5 bg-teal-50 border-2 border-teal-300 rounded-2xl space-y-2.5 text-xs text-teal-950 shadow-sm animate-fadeIn">
                    <div className="flex items-center justify-between border-b border-teal-200 pb-2">
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-teal-700" />
                        <strong className="text-teal-900 font-black">
                          SFAC INDIA PHM-SOP (Mayıs 2022) Hasat Sonrası &amp; Depolama Kılavuzu
                        </strong>
                      </div>
                      <a
                        href="https://sfacindia.com/UploadFile/Statistics/Draft-PHM-SOP-Fruits-and-Vegetables-24-May-2022.pdf"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-teal-800 underline hover:text-teal-950 flex items-center gap-1"
                      >
                        <span>Orijinal Belgeyi Aç</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] leading-relaxed">
                      <div className="bg-white/80 p-2.5 rounded-xl border border-teal-200">
                        <strong className="block text-teal-950 mb-1">🌡️ Optimum Sıcaklık &amp; Bağıl Nem:</strong>
                        <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                          <li><strong>Elma:</strong> 0.0°C - 1.0°C, %90-95 RH, 3-8 ay saklama.</li>
                          <li><strong>Şeftali/Nektarin:</strong> -0.5°C - 0.0°C, %90-95 RH, 2-4 hafta. (2-8°C arası üşüme/unlaşma hasarı!).</li>
                          <li><strong>Muz (Yeşil):</strong> 13.0°C - 14.0°C, %85-95 RH. (&lt;12.8°C gri kabuk üşüme hasarı!).</li>
                          <li><strong>Badem:</strong> 0-10°C, &lt;%65 RH, tane nemi &lt;%6.0.</li>
                        </ul>
                      </div>

                      <div className="bg-white/80 p-2.5 rounded-xl border border-teal-200">
                        <strong className="block text-teal-950 mb-1">⚠️ Başlıca Kusur Nedenleri &amp; Önlemler:</strong>
                        <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                          <li><strong>Acı Benek (Bitter Pit):</strong> Kalsiyum eksikliği ve aşırı azot. Hasat öncesi kalsiyum klorür uygulaması.</li>
                          <li><strong>Su Kalbi (Watercore):</strong> Fuji elmalarda geç hasat ve yüksek şeker birikimi.</li>
                          <li><strong>Yüzeysel Yanıklık (Scald):</strong> Erken hasat ve zayıf havalandırma. DPA / 1-MCP koruması.</li>
                          <li><strong>Mekanik Ezilme:</strong> Kasa aşırı doldurma ve nakliye sarsıntısı.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ÖZEL ÜRÜN KALİTE & OLGUNLUK TESTLERİ (Mango, Ananas, Avokado, Nar, Erik, Antep Fıstığı vb.) */}
          {hasSpecialCropTest && (
            <div className="bg-gradient-to-r from-teal-50 via-emerald-50 to-slate-50 border-2 border-teal-300 rounded-2xl p-3.5 sm:p-4 space-y-3.5 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-teal-100 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-teal-700 text-white shadow-xs">
                    <Gauge className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-teal-950 flex items-center gap-2">
                      <span>🌾 Ürüne Özel Kalite & Olgunluk Test Suite</span>
                      {specialCropType !== 'NONE' && (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-teal-200 text-teal-900">
                          {CROP_PRESETS[specialCropType]?.badge}
                        </span>
                      )}
                    </h4>
                    <p className="text-[11px] text-teal-800">
                      Uluslararası standartlara uygun pomolojik test presetleri (Kuru madde, titre edilebilir asitlik, özgül ağırlık, boyun kuruluğu, çıtlaklık vb.)
                    </p>
                  </div>
                </div>

                {/* Ürün Tipi Seçici / Switcher */}
                <div className="flex items-center gap-2">
                  <label className="text-[11px] font-bold text-slate-600 shrink-0">Test Şablonu:</label>
                  <select
                    value={specialCropType}
                    onChange={(e) => {
                      const newType = e.target.value as SpecialCropType;
                      setSpecialCropType(newType);
                      const preset = CROP_PRESETS[newType];
                      if (preset) {
                        setSpecialMetric1(preset.metric1Default);
                        if (preset.metric2Default !== undefined) setSpecialMetric2(preset.metric2Default);
                      }
                      const spec = CROP_QUALITY_SPECS[newType];
                      if (spec && spec.defaultStandard) {
                        setSelectedStandard(spec.defaultStandard);
                      }
                    }}
                    className="text-xs font-bold bg-white border border-teal-300 rounded-xl px-2.5 py-1.5 text-teal-950 focus:ring-2 focus:ring-teal-500 shadow-xs outline-none"
                  >
                    <option value="MANGO">🥭 Mango (Kuru Madde % & Yanak Sertliği)</option>
                    <option value="PINEAPPLE">🍍 Ananas (Camsılaşma 1-4 & Kabuk Gözü 0-5)</option>
                    <option value="AVOCADO">🥑 Avokado (Kuru Madde % & Durofel)</option>
                    <option value="POMEGRANATE">🔴 Nar (Meyve Suyu Randımanı % & Aril Rengi)</option>
                    <option value="PLUM">🟣 Erik (Mumsu Pus Örtüsü % & Sertlik)</option>
                    <option value="PISTACHIO">🥜 Antep Fıstığı (Doğal Çıtlaklık % & Depo Nemi %)</option>
                    <option value="APPLE_PEAR">🍎 Elma / Armut (Nişasta & Streif SI)</option>
                    <option value="TOMATO">🍅 Domates (Likopen Skalası 1-6 & TA Asitlik)</option>
                    <option value="GRAPE">🍇 Üzüm (Brix/Asit & Sap Tutunma Kuvveti)</option>
                    <option value="POTATO">🥔 Patates (Özgül Ağırlık / Cips Nişasta & Glukoz)</option>
                    <option value="ONION">🧅 Soğan (Boyun Kuruluğu % & Kuru Madde %)</option>
                    <option value="MELON_WATERMELON">🍉 Kavun & Karpuz (Sap Çatlağı & Kabuk Kalınlığı)</option>
                    <option value="CORN">🌽 Mısır (Hasat/Silo Nemi % & Süt Olumu)</option>
                    <option value="PERSIMMON">🟠 Hurma / Trabzon Hurması (Tanen Burukluğu 1-4 & Nem %)</option>
                    <option value="PEACH_NECTARINE">🍑 Şeftali / Nektarin (Sertlik 8mm & Çekirdek Çatlağı %)</option>
                  </select>
                </div>
              </div>

              {specialCropType !== 'NONE' && CROP_PRESETS[specialCropType] && (() => {
                const preset = CROP_PRESETS[specialCropType]!;
                const calcResult = preset.calculate(specialMetric1, specialMetric2);

                const handleAddEvidence = (record: EvidenceRecord) => {
    setEvidences([...evidences, record]);
  };
  const handleUpdateEvidenceStatus = (id: string, status: 'APPROVED' | 'REJECTED', note?: string) => {
    setEvidences(evidences.map(e => e.id === id ? { ...e, status, adminNote: note } : e));
  };
  const handleDeleteEvidence = (id: string) => {
    setEvidences(evidences.filter(e => e.id !== id));
  };

  return (
                  <div className="space-y-3">
                    {/* Açıklama */}
                    <div className="text-[11px] text-slate-600 bg-white/80 p-2.5 rounded-xl border border-teal-100 flex items-start gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                      <span>{preset.description}</span>
                    </div>

                    {/* Metrik Girdileri ve Canlı Hesaplama */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                      {/* Metrik 1 */}
                      <div className="bg-white p-3 rounded-xl border border-teal-200 shadow-xs">
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          {preset.metric1Label}
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            step={preset.metric1Step}
                            min={preset.metric1Min}
                            max={preset.metric1Max}
                            value={specialMetric1}
                            onChange={(e) => setSpecialMetric1(parseFloat(e.target.value) || 0)}
                            className="w-full px-3 py-1.5 border border-teal-300 rounded-lg font-bold text-teal-950 text-sm focus:ring-2 focus:ring-teal-500 outline-none"
                          />
                          <span className="text-xs font-bold text-slate-500 shrink-0">{preset.metric1Unit}</span>
                        </div>
                      </div>

                      {/* Metrik 2 */}
                      {preset.metric2Label && (
                        <div className="bg-white p-3 rounded-xl border border-teal-200 shadow-xs">
                          <label className="block text-xs font-bold text-slate-800 mb-1">
                            {preset.metric2Label}
                          </label>
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step={preset.metric2Step || 0.1}
                              min={preset.metric2Min || 0}
                              max={preset.metric2Max || 100}
                              value={specialMetric2}
                              onChange={(e) => setSpecialMetric2(parseFloat(e.target.value) || 0)}
                              className="w-full px-3 py-1.5 border border-teal-300 rounded-lg font-bold text-teal-950 text-sm focus:ring-2 focus:ring-teal-500 outline-none"
                            />
                            <span className="text-xs font-bold text-slate-500 shrink-0">{preset.metric2Unit}</span>
                          </div>
                        </div>
                      )}

                      {/* Canlı Değerlendirme & Yorum */}
                      <div className="bg-white p-3 rounded-xl border border-teal-200 shadow-xs flex flex-col justify-between">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                          Pomolojik / Kalite Sonucu
                        </span>
                        <div className={`mt-1.5 px-3 py-1.5 rounded-lg border text-xs font-extrabold ${calcResult.statusBadge}`}>
                          {calcResult.interpretation}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>

        {/* Kimyasal & Kalite Metrikleri (Seçmeli / Opsiyonel Saha Parametreleri) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Saha Kalite & Kimyasal Analiz Parametreleri (Seçmeli / Opsiyonel)</span>
            </h3>
            <span className="text-[10px] text-slate-500 font-medium">
              Saha konjonktürüne göre ölçülmeyen parametreler kapatılabilir
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {/* KİRAZ RENK (HUE ANGLE) - MDPI 2026 (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasHueAngleTest ? 'bg-white border-teal-300 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5 gap-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <label className="text-xs font-bold text-slate-800">
                    Kiraz Renk (Hue Angle °)
                  </label>
                  <button
                    type="button"
                    onClick={() => setActivePublicationModal(MDPI_ARTICLES.CHERRY_HUE)}
                    className="px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-800 dark:text-teal-300 hover:bg-teal-500/30 text-[10px] font-mono font-bold border border-teal-500/40 transition cursor-pointer flex items-center gap-1"
                    title="MDPI Horticulturae (Ağustos 2026) Makale Atıfını Aç"
                  >
                    <BookOpen className="w-3 h-3 text-teal-600 shrink-0" />
                    <span>[MDPI 2026]</span>
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setHasHueAngleTest(!hasHueAngleTest)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition shrink-0 ${
                    hasHueAngleTest
                      ? 'bg-teal-100 text-teal-900 border border-teal-300 hover:bg-teal-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasHueAngleTest ? '✓ Aktif' : '○ Ölçülmedi'}
                </button>
              </div>

              {hasHueAngleTest ? (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="180"
                      value={hueAngle ?? ''}
                      onChange={(e) => setHueAngle(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold bg-white border border-teal-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-teal-500 outline-none"
                      placeholder="Örn: 8.5°"
                    />
                    <span className="text-[11px] font-bold text-slate-500 shrink-0">° Hue</span>
                  </div>

                  {hueAngle == null ? (
                    <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200">Ölçülmedi</span>
                  ) : hueAngle <= 10 ? (
                    <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-700 shrink-0" />
                      <span>Tam Olgunluk &amp; Antioksidan: Optimal (≤ 10°)</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-amber-700 shrink-0" />
                      <span>Olgunlaşma Yetersiz / Yüksek Hue Açısı (&gt; 10°)</span>
                    </span>
                  )}
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Hue Angle spektrofotometrik renk testi pasif.
                </div>
              )}
            </div>

            {/* GÜBRELEME & ÇATLAMA DİRENCİ - HORTICULTURAE 2025 (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasFertilizationNotes ? 'bg-white border-amber-300 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5 gap-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <label className="text-xs font-bold text-slate-800">
                    Gübreleme &amp; Çatlama Direnci
                  </label>
                  <button
                    type="button"
                    onClick={() => setActivePublicationModal(MDPI_ARTICLES.FERTILIZATION)}
                    className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-900 dark:text-amber-300 hover:bg-amber-500/30 text-[10px] font-mono font-bold border border-amber-500/40 transition cursor-pointer flex items-center gap-1"
                    title="Horticulturae (2025) Makale Atıfını Aç"
                  >
                    <BookOpen className="w-3 h-3 text-amber-700 shrink-0" />
                    <span>[Horticulturae 2025]</span>
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setHasFertilizationNotes(!hasFertilizationNotes)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition shrink-0 ${
                    hasFertilizationNotes
                      ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasFertilizationNotes ? '✓ Kayıtlı' : '○ Yok'}
                </button>
              </div>

              {hasFertilizationNotes ? (
                <div className="space-y-1">
                  <input
                    type="text"
                    value={fertilizationNotes}
                    onChange={(e) => setFertilizationNotes(e.target.value)}
                    className="w-full text-xs font-semibold bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="Örn: Yapraktan Ca/K gübrelemesi uygulandı"
                  />
                  <span className="text-[10px] text-amber-800 block">
                    Kalsiyum &amp; Potasyum yaprak uygulaması çatlama direncini artırır.
                  </span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Özel yaprak gübreleme notu girilmedi.
                </div>
              )}
            </div>

            {/* 1. NİTRAT DEĞERİ (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasNitrateTest ? 'bg-white border-emerald-300 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <span>Nitrat (mg/kg)</span>
                </label>
                <button
                  type="button"
                  onClick={() => setHasNitrateTest(!hasNitrateTest)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                    hasNitrateTest
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasNitrateTest ? '✓ Aktif' : '○ Ölçülmedi'}
                </button>
              </div>

              {hasNitrateTest ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      value={nitrateMgKg ?? ''}
                      onChange={(e) => setNitrateMgKg(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-emerald-500 outline-none"
                      placeholder="mg/kg"
                    />
                    <span className="text-[11px] font-bold text-slate-500 shrink-0">mg/kg</span>
                  </div>
                  <span className={`text-[10px] font-bold block ${nitrateMgKg == null || nitrateLimitMgKg == null ? 'text-slate-500' : nitratePass ? 'text-emerald-600' : 'text-rose-600'}`}>
                    Limit: ≤ {nitrateLimitMgKg ?? '—'} mg/kg ({nitrateMgKg == null || nitrateLimitMgKg == null ? 'ölçüm ve limit girin' : nitratePass ? 'Uygun ✓' : 'Aşım ✗'})
                  </span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Sahada nitrat ölçümü yapılmadı (Laboratuvara sevk edilebilir).
                </div>
              )}
            </div>

            {/* 2. RENKLENME ORANI (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasColorationTest ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-800">
                  Renklenme / Coloration (%)
                </label>
                <button
                  type="button"
                  onClick={() => setHasColorationTest(!hasColorationTest)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                    hasColorationTest
                      ? 'bg-rose-100 text-rose-900 border border-rose-300 hover:bg-rose-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasColorationTest ? '✓ Aktif' : '○ Belirlenmedi'}
                </button>
              </div>

              {hasColorationTest ? (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="1"
                      value={colorationPercent ?? ''}
                      onChange={(e) => setColorationPercent(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                    <span className="text-[11px] font-bold text-slate-500 shrink-0">%</span>
                  </div>

                  {/* Seçmeli Hızlı Skala Butonları (Madde 7) */}
                  <div className="flex items-center gap-1 flex-wrap pt-0.5">
                    {[
                      { label: '< %25 (Zayıf)', val: 20 },
                      { label: '%25-50 (Kısmi)', val: 40 },
                      { label: '%50-75 (Norm)', val: 65 },
                      { label: '≥ %75 (Tam)', val: 85 }
                    ].map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setColorationPercent(p.val)}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold border transition cursor-pointer ${
                          colorationPercent != null && Math.abs(colorationPercent - p.val) <= 10
                            ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                            : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  <span className="text-[10px] text-slate-500 block">
                    Yüzey renk tutumu ve homojenlik (Seçmeli test)
                  </span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Renklenme ölçümü pasif (Her meyve için zorunlu değil).
                </div>
              )}
            </div>

            {/* 3. KUSUR / DEFEKT ORANI (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasDefectTest ? 'bg-white border-amber-300 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-800">
                  Kusur / Defekt (%)
                </label>
                <button
                  type="button"
                  onClick={() => setHasDefectTest(!hasDefectTest)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                    hasDefectTest
                      ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasDefectTest ? '✓ Aktif' : '○ Belirlenmedi'}
                </button>
              </div>

              {hasDefectTest ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={defectPercent ?? ''}
                      onChange={(e) => setDefectPercent(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                    <span className="text-[11px] font-bold text-slate-500 shrink-0">%</span>
                  </div>
                  <span className={`text-[10px] font-bold block ${defectPercent <= 5 ? 'text-emerald-600' : defectPercent <= 10 ? 'text-amber-600' : 'text-rose-600'}`}>
                    {defectPercent <= 5 ? 'Kusursuz / Düşük' : defectPercent <= 10 ? 'Orta Kusur' : 'Yüksek Kusur (Iskarta/F-Dry)'}
                  </span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Kusur sayımı yapılmadı / genel parti temiz kabul edildi.
                </div>
              )}
            </div>

            {/* 4. KALİTE SINIFI (SEÇMELİ) */}
            <div className={`p-3 rounded-xl border transition-all ${
              hasQualityGrade ? 'bg-white border-indigo-300 shadow-xs' : 'bg-slate-50/80 border-slate-200 opacity-80'
            }`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-800">
                  Kalite Sınıfı
                </label>
                <button
                  type="button"
                  onClick={() => setHasQualityGrade(!hasQualityGrade)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                    hasQualityGrade
                      ? 'bg-indigo-100 text-indigo-900 border border-indigo-300 hover:bg-indigo-200'
                      : 'bg-slate-200 text-slate-600 border border-slate-300 hover:bg-slate-300'
                  }`}
                >
                  {hasQualityGrade ? '✓ Seçildi' : '○ Belli Değil'}
                </button>
              </div>

              {hasQualityGrade ? (
                <select
                  value={kaliteSinifi}
                  onChange={(e) => {
                    setKaliteSinifi(e.target.value);
                    setQualityGrade(e.target.value);
                  }}
                  className="w-full text-xs font-bold bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {STANDARD_QUALITY_CLASSES.map(cls => (
                    <option key={cls.key} value={cls.key}>
                      {cls.key} — {cls.nameTr}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-2">
                  Sınıf ayrımı sahada yapılmadı (Depo/Sortlama aşamasında belirlenecek).
                </div>
              )}
            </div>
          </div>
        </div>

        {/* NİHAİ ÜRÜN DURUMU & FREEZE & DRY YÖNLENDİRME (SEÇMELİ) */}
        <div className={`border rounded-2xl p-4 space-y-3 transition-all ${
          hasProductFinalStatus ? 'bg-purple-50/60 border-purple-200' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-purple-950 flex items-center gap-2">
              <Snowflake className="w-4 h-4 text-purple-600" />
              <span>Ürün Nihai Durumu & Sevk Yönlendirmesi / Product Final Status</span>
            </h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setHasProductFinalStatus(!hasProductFinalStatus)}
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                  hasProductFinalStatus
                    ? 'bg-purple-200 text-purple-900 border border-purple-300'
                    : 'bg-slate-200 text-slate-600 border border-slate-300'
                }`}
              >
                {hasProductFinalStatus ? '✓ Seçim Aktif' : '+ Durum Belirle (Opsiyonel)'}
              </button>
              <span className="text-[10px] font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                İzlenebilirlik Kontrolü
              </span>
            </div>
          </div>

          {hasProductFinalStatus ? (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-2">
                  Nihai Durum Seçimi (Tıklayarak Seçiniz):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    {
                      id: 'FRESH_SALE',
                      title: '🛒 Taze Satış (Fresh Sale)',
                      desc: 'Doğrudan İhracat & Taze İç Pazar Sevk',
                      accent: 'bg-emerald-50 text-emerald-950 border-emerald-400'
                    },
                    {
                      id: 'COLD_STORAGE',
                      title: '❄️ Soğuk Depo (CA Storage)',
                      desc: 'Datly Miwe 1000T Kontrollü Atmosfer',
                      accent: 'bg-blue-50 text-blue-950 border-blue-400'
                    },
                    {
                      id: 'FREEZE_DRY',
                      title: '🍓 Freeze & Dry / İşleme',
                      desc: 'Sapma / İkinci Kalite Liyofilizasyon',
                      accent: 'bg-purple-50 text-purple-950 border-purple-400'
                    }
                  ].map(item => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setFinalProductStatus(item.id as any)}
                      className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                        finalProductStatus === item.id
                          ? `${item.accent} ring-2 ring-purple-500 shadow-sm font-bold`
                          : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs font-black">
                        <span>{item.title}</span>
                        {finalProductStatus === item.id && (
                          <span className="text-[10px] bg-purple-200 text-purple-900 px-1.5 py-0.2 rounded font-mono">
                            ✓ Seçili
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-1">
                        {item.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {finalProductStatus === 'FREEZE_DRY' && (
                <div className="pt-2 border-t border-purple-200">
                  <label className="block text-xs font-bold text-rose-800 mb-1">
                    Uygunsuzluk / Kalite Sapma Notu (Opsiyonel)
                  </label>
                  <input
                    type="text"
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="Örn: Penetrometre sertlik düşük veya Brix standart altı -> Freeze-Dry"
                    className="w-full text-xs font-semibold bg-rose-50 border-2 border-rose-400 text-rose-950 rounded-xl px-3 py-2 focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              )}
            </div>
          ) : (
            <div className="text-[11px] text-slate-500 italic py-1">
              Ürün nihai sevk durumu belirlenmedi (Varsayılan taze pazar akışında işlem görecektir).
            </div>
          )}
        </div>

        {/* Karar & Sonraki Adım */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <SmartCreatableSelect
              label="Muayene Kararı / Decision"
              categoryKey="field_decisions"
              options={[
                'Hasada Uygun (Hasada Başla)',
                'Freeze-Dry İşleme Tesisine Yönlendir (-40°C Şoklama)',
                'Tekrar Test Edilecek (Bekleme)',
                '2. Hasat / Seçme Hasat',
                'Şartlı Kabul (Hızlı Sevk)',
                'Hasat Ertelendi (Olgunlaşma Yetersiz)'
              ]}
              value={decision}
              onChange={setDecision}
            />

            <SmartCreatableSelect
              label="Sonraki Adım / Next Step"
              categoryKey="field_next_steps"
              options={[
                'Hasat & Soğuk Depoya Sevk',
                'Freeze & Dry İşleme Hattına Sevk',
                '2 Gün Sonra Tekrar Numune Alımı',
                'Lojistik Doğrudan Dağıtım',
                'Sanayi Tesisine Sevk'
              ]}
              value={nextStep}
              onChange={setNextStep}
            />

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                İşlem Durumu / Status
              </label>
              <select
                value={testStatus}
                onChange={(e) => setTestStatus(e.target.value as any)}
                className="w-full text-xs font-bold bg-white border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="COMPLETED">Tamamlandı / Completed</option>
                <option value="ACTIVE">Devam Ediyor / In Progress</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Kalite Kontrol Notları / Quality Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Parsel durumu, meyve kabuk yapısı, tat profili ve ek açıklamalar..."
              className="w-full text-xs bg-white border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Fotoğraf Hızlı Yükleme & Önizleme */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-xs font-bold text-slate-800">
                  Meyve Test Fotoğrafları / Photos (Otomatik Sıkıştırma & Çevrimdışı Önbellek)
                </label>
                <span className="text-[11px] text-slate-500">
                  Fotoğraflar otomatik olarak optimize edilir (WebP/JPEG) ve çevrimdışı önbelleğe kaydedilir.
                </span>
              </div>
              
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Kamera ile Çek</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isCompressingPhoto}
                  className="px-3.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-emerald-300 shadow-2xs cursor-pointer"
                >
                  {isCompressingPhoto ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>İşleniyor...</span>
                    </>
                  ) : (
                    <>
                      <span>+ Galeriden Seç</span>
                    </>
                  )}
                </button>
              </div>

              {/* Gizli Kamera Girişi */}
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoUpload}
                className="hidden"
              />

              {/* Gizli Galeri Girişi */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>

            {photos.filter(p => p && p.length > 20).length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-1">
                {photos.filter(p => p && p.length > 20).map((photoUrl, idx) => (
                  <div
                    key={idx}
                    onClick={() => setLightboxIndex(idx)}
                    className="relative group rounded-xl overflow-hidden border border-slate-200 aspect-square bg-slate-100 shadow-2xs cursor-pointer hover:border-emerald-400 transition"
                    title="Fotoğrafı tam ekran önizlemek veya silmek için dokunun"
                  >
                    <img
                      src={photoUrl}
                      alt={`Test Fotoğrafı ${idx + 1}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLightboxIndex(idx);
                        }}
                        className="p-1.5 bg-white text-slate-800 rounded-lg hover:bg-slate-100 transition shadow-sm cursor-pointer"
                        title="Büyüt / Önizle"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemovePhoto(idx);
                        }}
                        className="p-1.5 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition shadow-sm cursor-pointer"
                        title="Kaldır / Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        </fieldset>

        {/* Submit Buttons */}
        <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200 w-full">
          <button
            type="button"
            onClick={onCancel}
            className="w-full sm:w-auto px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition text-center cursor-pointer"
          >
            İptal / Cancel
          </button>

          {!isReadOnly && (
            <button
              type="button"
              onClick={() => handleSubmit(undefined, 'ACTIVE')}
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition shadow-xs cursor-pointer"
            >
              <Save className="w-3.5 h-3.5 text-amber-700" />
              <span>Taslak Olarak Kaydet (İşlemde)</span>
            </button>
          )}

          <button
            type="button"
            disabled={isReadOnly}
            onClick={() => handleSubmit(undefined, 'COMPLETED')}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold shadow-md transition active:scale-95 cursor-pointer ${
              isReadOnly
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed border border-slate-300 shadow-none'
                : 'bg-[#0f4a33] hover:bg-emerald-800 text-white hover:shadow-lg'
            }`}
          >
            <Save className={`w-4 h-4 ${isReadOnly ? 'text-slate-400' : 'text-emerald-300'} shrink-0`} />
            <span className="truncate">
              {isReadOnly
                ? 'Salt Okunur (Düzenlemek İçin Kilidi Açın)'
                : isEditing
                ? 'Değişiklikleri Güncelle & Kaydet'
                : 'Saha Testini Tamamla & Kaydet'}
            </span>
          </button>
        </div>

      </form>

      {/* Full-Screen Photo Lightbox Modal */}
      <PhotoLightboxModal
        isOpen={lightboxIndex !== null}
        photoUrl={lightboxIndex !== null ? photos[lightboxIndex] : null}
        photoIndex={lightboxIndex ?? 0}
        totalPhotos={photos.length}
        title={`Meyve Kalite Testi Fotoğrafı #${(lightboxIndex ?? 0) + 1}`}
        onClose={() => setLightboxIndex(null)}
        onDelete={(idx) => {
          handleRemovePhoto(idx);
          if (photos.length <= 1) {
            setLightboxIndex(null);
          } else if (idx >= photos.length - 1) {
            setLightboxIndex(Math.max(0, photos.length - 2));
          }
        }}
        onPrev={lightboxIndex !== null && lightboxIndex > 0 ? () => setLightboxIndex(prev => (prev !== null ? prev - 1 : 0)) : undefined}
        onNext={lightboxIndex !== null && lightboxIndex < photos.length - 1 ? () => setLightboxIndex(prev => (prev !== null ? prev + 1 : 0)) : undefined}
      />


      {/* Admin Options & Standards Modal */}
      <AdminOptionsStandardsModal
        isOpen={isAdminOptionsModalOpen}
        onClose={() => setIsAdminOptionsModalOpen(false)}
        currentUser={currentUser}
      />

      {/* 📷 Mobil AI Kamera Destekli Bilgisayarlı Görü Modalı */}
      {isAiVisionOpen && (
        <AiVisionFruitInspectorModal
          isOpen={isAiVisionOpen}
          onClose={() => setIsAiVisionOpen(false)}
          initialFruit={
            (product || '').toLowerCase().includes('muz') ? 'BANANA' :
            (product || '').toLowerCase().includes('badem') ? 'ALMOND' :
            (product || '').toLowerCase().includes('şeftali') || (product || '').toLowerCase().includes('nektarin') ? 'PEACH' : 'APPLE'
          }
          onApplyResults={() => {
            // v2.5: Görüntü analizi henüz SİMÜLASYON — sonuçlar forma ve kayda yazılmaz
            window.alert('DEMO: Gerçek görüntü analizi bağlı değil; sonuçlar forma yazılmadı.');
          }}
        />
      )}

      {/* MDPI Makale Referans Modalı */}
      {activePublicationModal && (
        <PublicationModal
          publication={activePublicationModal}
          onClose={() => setActivePublicationModal(null)}
        />
      )}
    </div>
  );
};
