import React, { useState, useMemo } from 'react';
import {
  Home,
  Search,
  CalendarDays,
  ShieldCheck,
  FileBarChart,
  ChevronRight,
  ExternalLink,
  LayoutGrid,
  Apple,
  Banana,
  Activity,
  Layers,
  Wrench,
  Globe2,
  BarChart3,
  Archive,
  Clock,
  Target,
  GitMerge,
  CheckCircle2,
  Database,
  Sparkles,
  ArrowRight,
  BookOpen,
  Zap,
  FileText,
  FileSpreadsheet
} from 'lucide-react';
import { AppUser } from '../../types/auth';

export interface PortalLauncherProps {
  currentUser?: AppUser | null;
  totalRefsCount?: number;
  lastSyncTime?: string | null;
  isOnline?: boolean;
  onNavigate: (
    viewId: string,
    tabId?: string,
    portalInfo?: { portalId: string; subId: string; portalTitle: string; subTitle: string }
  ) => void;
  onBackToDashboard?: () => void;
  onOpenPresentationWizard?: () => void;
}

interface PortalSubItem {
  label: string;
  viewId?: string;
  tabId?: string;
  badge?: string;
  isPdf?: boolean;
}

interface PortalTileConfig {
  id: string;
  gateNumber: string;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  badge: string;
  badgeColor: string;
  cardStyle: string;
  iconBg: string;
  viewId: string;
  tabId?: string;
  statusText: string;
  subItems: PortalSubItem[];
}

export const PortalLauncher: React.FC<PortalLauncherProps> = ({
  currentUser,
  totalRefsCount = 0,
  lastSyncTime,
  isOnline = true,
  onNavigate,
  onBackToDashboard,
  onOpenPresentationWizard
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const launchpadTiles: PortalTileConfig[] = [
    {
      id: 'dashboard-portal',
      gateNumber: '01',
      title: 'Ana Platform & Saha Operasyonları',
      subtitle: 'Günlük İşler, 10 Operasyonel Modül, Parti Kabul & Sevkiyat',
      icon: LayoutGrid,
      badge: 'Birincil Çalışma Alanı (Canlı)',
      badgeColor: 'bg-teal-50 text-teal-700 border-teal-200',
      cardStyle: 'bg-white/90 border-teal-200 hover:border-teal-400 shadow-xs hover:shadow-md backdrop-blur-xs',
      iconBg: 'bg-teal-50 text-teal-700 border border-teal-200',
      viewId: 'DASHBOARD',
      statusText: 'Merkezi Operasyonel Saha Modülü (Veri Giriş & Kayıt)',
      subItems: [
        { label: 'Günlük Pano & İşler', viewId: 'DASHBOARD' },
        { label: '10 Operasyon Modülü', viewId: 'DASHBOARD' },
        { label: 'Parti & Referanslar', viewId: 'REFERENCES' },
        { label: 'Bekleyen Görevler', viewId: 'PENDING' }
      ]
    },
    {
      id: 'reporting-portal',
      gateNumber: '04',
      title: 'Raporlama & Sunum Merkezi',
      subtitle: 'Aylık Yönetim Brifingi, R-01-R-05 Zirai Raporlar ve İzlenebilirlik',
      icon: FileBarChart,
      badge: 'Raporlama & Analiz (Pasif İzleyici)',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      cardStyle: 'bg-white/90 border-indigo-200 hover:border-indigo-400 shadow-xs hover:shadow-md backdrop-blur-xs',
      iconBg: 'bg-indigo-50 text-indigo-700 border border-indigo-200',
      viewId: 'REPORTING_PORTAL',
      tabId: 'MONTHLY_REPORT',
      statusText: 'Ana Platform Verilerini Analiz Eden ve Sunan Merkez',
      subItems: [
        { label: 'Aylık Yönetim Özeti & Brifing', tabId: 'MONTHLY_REPORT', badge: 'PDF', isPdf: true },
        { label: 'İstatistiksel Analiz & FAO', tabId: 'ANALYTICS' },
        { label: 'İzlenebilirlik Defteri (Pasaport)', tabId: 'TRACEABILITY' },
        { label: 'Görsel Standartlar & Kalite Kılavuzu', tabId: 'STANDARDS_4LANG' }
      ]
    }
  ];

  const filteredTiles = useMemo(() => {
    if (!searchQuery.trim()) return launchpadTiles;
    const q = searchQuery.toLowerCase();
    return launchpadTiles.filter(
      t =>
        t.title.toLowerCase().includes(q) ||
        t.subtitle.toLowerCase().includes(q) ||
        t.subItems.some(sub => sub.label.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  const handleOpenTile = (tile: PortalTileConfig, specificTabId?: string, specificViewId?: string) => {
    const targetView = specificViewId || tile.viewId;
    const targetTab = specificTabId !== undefined ? specificTabId : tile.tabId;
    onNavigate(targetView, targetTab, {
      portalId: tile.id,
      subId: targetTab || 'overview',
      portalTitle: tile.title,
      subTitle: tile.subtitle
    });
  };

  return (
    <div className="min-h-full bg-slate-50 text-slate-900 p-4 sm:p-8 lg:p-12 space-y-8 animate-in fade-in duration-200 font-sans">
      {/* BAŞLIK & ARAMA ŞERİDİ */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200 text-[11px] font-mono font-bold tracking-wider uppercase">
              MIWE HIL
            </span>
            <span className="text-xs text-slate-500 font-mono">Ana Platform &amp; Raporlama Merkezi</span>
            {totalRefsCount > 0 && (
              <span className="text-[10px] bg-slate-100 text-teal-800 border border-slate-200 px-2 py-0.5 rounded-full font-mono font-bold">
                {totalRefsCount} Kayıtlı Parti
              </span>
            )}
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              isOnline ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-800 border border-amber-200'
            }`}>
              {isOnline ? '● Canlı Ağ Bağlantısı' : '○ Çevrimdışı Mod'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Portal Komut Merkezi
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
            Ana Platform günlük kayıtların girildiği çalışma alanıdır; Raporlama Merkezi bu kayıtlardan raporları hazırlar.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {onBackToDashboard && (
            <button
              type="button"
              onClick={onBackToDashboard}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-bold transition shadow-2xs cursor-pointer active:scale-95"
            >
              <Home className="w-4 h-4 text-teal-600" />
              <span>Ana Pano (Dashboard)</span>
            </button>
          )}

          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Portal veya alt modül ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 text-slate-900 text-xs rounded-xl pl-8 pr-3 py-2.5 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 font-mono placeholder-slate-400 shadow-2xs"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
          </div>
        </div>
      </div>

      {/* 4 TEMEL PORTAL GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6 lg:gap-8 max-w-7xl mx-auto">
        {filteredTiles.map((tile) => {
          const Icon = tile.icon;
          const isPrimary = tile.gateNumber === '01';
          return (
            <div
              key={tile.id}
              className={`group relative text-left rounded-3xl p-6 sm:p-7 border transition-all duration-300 shadow-xs ${tile.cardStyle} ${
                isPrimary ? 'ring-1 ring-teal-500/40 shadow-teal-500/5' : ''
              } flex flex-col justify-between overflow-hidden`}
            >
              <div className="space-y-4 relative z-10">
                {/* Header Row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-13 h-13 rounded-2xl flex items-center justify-center ${tile.iconBg} shadow-2xs group-hover:scale-105 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xl font-black font-mono text-slate-300 group-hover:text-slate-500 transition-colors">
                      {tile.gateNumber}
                    </span>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider border shadow-2xs ${tile.badgeColor}`}>
                    {tile.badge}
                  </span>
                </div>

                {/* Title & Subtitle */}
                <div className="space-y-1">
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {tile.title}
                  </h2>
                  <h3 className="text-xs font-bold text-teal-700 font-mono tracking-wide">
                    {tile.subtitle}
                  </h3>
                  <div className="text-[11px] text-slate-600 pt-1 font-mono flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-amber-600 shrink-0" />
                    <span>{tile.statusText}</span>
                  </div>
                </div>

                {/* Alt Kapılar & Modüller (Tıklanabilir Kısayollar) */}
                <div className="pt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                    İçerik &amp; Alt Modüller:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {tile.subItems.map((sub, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenTile(tile, sub.tabId, sub.viewId);
                        }}
                        className="flex items-center justify-between gap-1.5 px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-semibold transition text-left cursor-pointer group/sub"
                      >
                        <span className="truncate group-hover/sub:text-teal-700 transition-colors flex items-center gap-1.5">
                          {sub.isPdf && <FileText className="w-3.5 h-3.5 text-rose-500 shrink-0" />}
                          {sub.label}
                        </span>
                        {sub.badge ? (
                          <span className="text-[10px] px-1.5 py-0.2 bg-rose-50 text-rose-700 border border-rose-200 rounded font-mono font-bold shrink-0 flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            {sub.badge}
                          </span>
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover/sub:text-teal-600 shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Action */}
              <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenTile(tile)}
                  className={`w-full flex items-center justify-between py-2.5 px-4 rounded-xl ${
                    isPrimary
                      ? 'bg-teal-600 text-white hover:bg-teal-500 font-black shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800 hover:text-teal-700 font-bold border border-slate-200'
                  } text-xs transition cursor-pointer`}
                >
                  <span className="flex items-center gap-1.5">
                    <span>{isPrimary ? 'Ana Operasyon Çalışma Alanına Git' : 'Portala Giriş Yap'}</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                  </span>
                  <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
