# V68 NOTLAR — Türkmençe saha düzeltmeleri (v67 dahil)

Taban: v66 (225) veya v67 (228). Sonuç: 228 dosya. v67 uygulanmadıysa bu paket onu da içerir (aynı 5 dosya; yalnız dict.ts farklı). Silinecek yok. Firestore kuralı değişmedi.

## Dosyalar (SHA-256)
6fe9904a39c5b127c914e53fc5f0965706e86d97b2d5f2d96e00d5764d41e249  src/i18n/lang.ts
474a7058b3461f35c01c079ce4dca28d412ab089f93395fa9a1327e0e700c7bd  src/i18n/domTranslate.ts
6f03af05fa3c629f38fab5fb85ad2be026cca186ed59c3f4e510747d620807c9  src/i18n/dict.ts
5b6d144943f8a2caf08946463e40359dae78b355caf1925e89196cdd6b1cefbf  src/App.tsx
312a085c7d108a6222beefdce2c93f1b2bd09c0d69c0b2b5e44c11c943a3a0c0  src/components/portal/HomeMenu.tsx

Yeni (v67 uygulanmadıysa): src/i18n/lang.ts, src/i18n/domTranslate.ts, src/i18n/dict.ts

## Ne değişti
- Sözlük tablosundaki Türkmençe düzeltmeler sözlüğe işlendi (52 terim): Test merkezi, Barlaglar, Meýdan test, Ýeralma, Bölek (karta), Görnüşi, Agro howa maglumaty, Dolandyryş otagy, Ýekelemek, teste basyň …
- Küçük yazım düzeltmeleri: ș → ş (goşmaça, görnüşi), "maglumayy" → "maglumaty", "işleyişi" → "işleýişi", "meyilnama" → "meýilnama", "test ü/nbasyň" → "Teste basyň", fazla boşluk.
- v67'nin her şeyi: TR · TK · EN düğmesi, profile göre varsayılan dil.
