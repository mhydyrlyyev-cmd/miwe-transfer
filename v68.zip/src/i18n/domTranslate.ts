/**
 * v67 — ekran çevirmeni. Dosyalardaki Türkçe yazılara dokunmadan, ekrandaki metni sözlüğe göre çevirir.
 * · Tam eşleşme → sözlük; olmazsa " · " ile bölünen parçalar tek tek; sayılar "#" ile kalıba çevrilir (ör. "# parti depoda").
 * · Ay / gün adları kelime kelime.
 * · Yazı alanları (input, textarea), kod, [data-no-i18n] ve contenteditable çevrilmez; kullanıcının yazdığı veri sözlükte yoksa aynen kalır.
 * · TR'ye dönünce özgün metin geri yazılır.
 * React metni güncellediğinde (characterData) yeniden çevrilir; yalnız metin değeri değişir, düğüm eklenip silinmez.
 */
import { DICT, WORDS } from './dict';
import type { Lang } from './lang';

const ATTRS = ['placeholder', 'title', 'aria-label'];
const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'CODE', 'PRE', 'NOSCRIPT']);
const NUM = /[−+-]?\d[\d.,]*/g;
const EDGE = /^([\s·›‹→←—:+•▾]*)(.*?)([\s·›‹→←—:•▾.]*)$/s;

let lang: Lang = 'tr';
let obs: MutationObserver | null = null;
const origText = new Map<Text, string>();
const origAttr = new Map<Element, Record<string, string>>();
let applying = false;

function idx(l: Lang) { return l === 'tk' ? 0 : 1; }
function one(seg: string): string | null {
  const m = seg.match(EDGE); if (!m) return null;
  const [, pre, core0, post0] = m;
  if (!core0) return null;
  // sondaki nokta / üç nokta sözlük anahtarının parçası olabilir: önce onunla dene
  const tries: [string, string][] = [];
  const dot = post0.match(/^([.…]+)(.*)$/s);
  if (dot) tries.push([core0 + dot[1], dot[2]]);
  tries.push([core0, post0]);
  for (const [core, post] of tries) {
    const d = DICT[core];
    if (d) return pre + d[idx(lang)] + post;
    const nums = core.match(NUM);
    if (nums) {
      const k = core.replace(NUM, '#');
      const p = DICT[k];
      if (p) { let i = 0; return pre + p[idx(lang)].replace(/#/g, () => nums[i++] ?? '#') + post; }
    }
  }
  const core = core0, post = post0;
  // kelime kelime: yalnız sayı + ay / gün adlarından oluşuyorsa
  const words = core.split(/(\s+|\/)/);
  if (words.every(w => !w.trim() || w === '/' || /^[−+-]?\d[\d.,]*$/.test(w) || WORDS[w])) {
    if (words.some(w => WORDS[w])) return pre + words.map(w => (WORDS[w] ? WORDS[w][idx(lang)] : w)).join('') + post;
  }
  return null;
}
export function translateString(s: string, l: Lang = lang): string {
  if (l === 'tr' || !s || !/[A-Za-zÇĞİÖŞÜçğıöşü]/.test(s)) return s;
  const prev = lang; lang = l;
  try {
    const whole = one(s); if (whole !== null) return whole;
    if (s.includes(' · ')) {
      let changed = false;
      const out = s.split(' · ').map(p => { const t = one(p); if (t !== null) { changed = true; return t; } return p; }).join(' · ');
      if (changed) return out;
    }
    return s;
  } finally { lang = prev; }
}
function skipped(el: Element | null): boolean {
  for (let e = el; e; e = e.parentElement) {
    if (SKIP.has(e.tagName) || e.hasAttribute('data-no-i18n') || (e as HTMLElement).isContentEditable) return true;
  }
  return false;
}
function doText(n: Text) {
  if (skipped(n.parentElement)) return;
  const cur = n.nodeValue || '';
  const base = origText.has(n) && translateString(origText.get(n)!) === cur ? origText.get(n)! : cur;
  const t = translateString(base);
  if (t !== cur) { origText.set(n, base); n.nodeValue = t; }
}
function doAttrs(el: Element) {
  // input/textarea'nın değeri çevrilmez ama placeholder/title çevrilir
  if (el.hasAttribute('data-no-i18n') || skipped(el.parentElement)) return;
  for (const a of ATTRS) {
    const v = el.getAttribute(a); if (!v) continue;
    const o = origAttr.get(el) || {};
    const base = o[a] && translateString(o[a]) === v ? o[a] : v;
    const t = translateString(base);
    if (t !== v) { o[a] = base; origAttr.set(el, o); el.setAttribute(a, t); }
  }
}
function walk(root: Node) {
  if (root.nodeType === 3) { doText(root as Text); return; }
  if (root.nodeType !== 1) return;
  const el = root as Element;
  if (SKIP.has(el.tagName) && el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA') return;
  doAttrs(el);
  const tw = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  for (let n = tw.nextNode(); n; n = tw.nextNode()) { if (n.nodeType === 3) doText(n as Text); else doAttrs(n as Element); }
}
function restore() {
  applying = true;
  origText.forEach((o, n) => { if (n.isConnected) n.nodeValue = o; });
  origAttr.forEach((o, el) => { if (el.isConnected) for (const [a, v] of Object.entries(o)) el.setAttribute(a, v); });
  origText.clear(); origAttr.clear();
  applying = false;
}
function prune() {
  if (origText.size > 4000) origText.forEach((_, n) => { if (!n.isConnected) origText.delete(n); });
  if (origAttr.size > 2000) origAttr.forEach((_, el) => { if (!el.isConnected) origAttr.delete(el); });
}

export function applyLanguage(l: Lang) {
  if (typeof document === 'undefined') return;
  if (l === lang && (l === 'tr' || obs)) return;
  if (obs) { obs.disconnect(); obs = null; }
  restore();
  lang = l;
  if (l === 'tr') return;
  applying = true; walk(document.body); applying = false;
  obs = new MutationObserver(ms => {
    if (applying) return;
    applying = true;
    try {
      for (const m of ms) {
        if (m.type === 'characterData') doText(m.target as Text);
        else if (m.type === 'attributes') doAttrs(m.target as Element);
        else m.addedNodes.forEach(walk);
      }
      prune();
    } finally { applying = false; }
  });
  obs.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
}
