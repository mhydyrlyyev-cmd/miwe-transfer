/**
 * v67 — dil seçimi (TR / TK / EN). Cihazda kullanıcı başına saklanır.
 * Varsayılan profile göre: Saha / Sera / Depo / Lojistik → Türkmençe; Ofis / Yönetim / yönetici → Türkçe; Dış → İngilizce.
 */
import { useEffect, useState } from 'react';
import type { AppUser } from '../types/auth';
import { profileOf } from '../config/publishProfiles';

export type Lang = 'tr' | 'tk' | 'en';
export const LANG_LABEL: Record<Lang, string> = { tr: 'Türkçe', tk: 'Türkmençe', en: 'English' };
const KEY = 'miwe_lang_v1';
let current: Lang = 'tr';
const ls = new Set<(l: Lang) => void>();

export function defaultLang(u?: AppUser | null): Lang {
  const p = profileOf(u);
  if (!p) return 'tr';
  if (p.key === 'DIS') return 'en';
  if (p.key === 'OFIS' || p.key === 'YONETIM') return 'tr';
  return 'tk';
}
const keyFor = (u?: AppUser | null) => `${KEY}:${u?.id || u?.email || 'anon'}`;
export function loadLang(u?: AppUser | null): Lang {
  try { const v = localStorage.getItem(keyFor(u)) as Lang | null; if (v === 'tr' || v === 'tk' || v === 'en') return v; } catch { /* yoksay */ }
  return defaultLang(u);
}
export function getLang(): Lang { return current; }
export function setLang(l: Lang, u?: AppUser | null) {
  current = l;
  try { if (u !== undefined) localStorage.setItem(keyFor(u), l); document.documentElement.lang = l === 'tk' ? 'tk' : l; } catch { /* yoksay */ }
  ls.forEach(f => f(l));
}
export function useLang(): Lang {
  const [l, set] = useState(current);
  useEffect(() => { const f = (x: Lang) => set(x); ls.add(f); return () => { ls.delete(f); }; }, []);
  return l;
}
