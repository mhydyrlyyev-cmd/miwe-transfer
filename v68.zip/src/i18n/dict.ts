/**
 * v67/v68 — arayüz sözlüğü (v68: Türkmençe saha düzeltmeleri): Türkçe (kaynak) | Türkmençe | İngilizce.
 * "#" = sayı yeri (ör. "# parti depoda"). Satır biçimi: tr|tk|en. Boş satır ve // yorum atlanır.
 * Türkmençe terimler saha ekibinin gözden geçirmesi içindir (bkz. terim tablosu); düzeltme = bu dosyada bir satırı değiştirmek.
 * Veriler (bahçe, çeşit, kişi adı, not) çevrilmez.
 */
const RAW = `
// --- gezinme ve menü
Ana|Baş sahypa|Home
Menü|Menu|Menu
Bahçeler|Baglar|Orchards
Depolar|Ammarlar|Stores
Seralar|Ýyladyşhanalar|Greenhouses
Açık tarla|Açyk meýdan|Open field
C proje|C haryt (taslama)|C project
Kayıt|Hasaba alyş|Records
Testler|Barlaglar|Tests
Raporlar|Hasabatlar|Reports
Ayarlar|Sazlamalar|Settings
Yönetim|Dolandyryş|Management
Geri|Yza|Back
Alt menü|Aşaky menu|Bottom menu
RefID, bahçe veya ürün ara…|RefID, bag ýa-da önüm gözle…|Search RefID, orchard or product…
Günlük hasat|Gündelik hasyl|Daily harvest
Ön soğutma fişi|Öňünden sowatmak kagyzy|Pre-cooling slip
Ön soğutma|Öňünden sowatmak|Pre-cooling
Ön soğ.|Öň. sow.|Pre-cool
Sortlama ve paketleme|Sortlamak we gaplamak|Sorting and packing
Sortlama|Sortlamak|Sorting
Depo kabul|Ammara kabul|Store intake
Depoya giriş|Ammara giriş|Store entry
Sevk kaydı|Ugratma ýazgysy|Dispatch record
Sevk|Ugratma|Dispatch
Satış|Satuw|Sales
Satış / sevk|Satuw / ugratma|Sales / dispatch
Akt / olay|Akt / waka|Act / incident
Toplu QR tarama|Köpçülikleýin QR okamak|Batch QR scan
Test merkezi|Test merkezi|Test centre
geçmiş|geçmiş|history
bahçe ve sera|bag we ýyladyşhana|orchard and greenhouse
standartlar|standartlar|standards
Saha testi (meyve|Meýdan barlagy (miwe|Field test (fruit
soğan|sogan|onion
patates)|ýeralma)|potato)
Saha testi|Meýdan test|Field test
Saha testleri|Meýdan testler|Field tests
Muz|Banan|Banana
Badem|Badam|Almond
Badem testi|Badam test|Almond test
Muz testi|Banan test|Banana test
akış|akym|flow
İhracat numunesi|Eksport nusgasy|Export sample
Freeze-dry|Doňdurylyp guradylan|Freeze-dry
Rapor merkezi|Hasabat merkezi|Report centre
kalite|hil|quality
aylık PDF|aýlyk PDF|monthly PDF
izlenebilirlik|yzygiderlilik|traceability
# arşivi|# arhiwi|# archive
Yönetici özeti|Dolandyryş maglumaty|Manager summary
Uyarılar|Duýduryşlar|Alerts
QR etiket sayfası (A#)|QR bellik sahypasy (A#)|QR label sheet (A#)
Profiller (bahçe|Profiller (bag|Profiles (orchard
sera|ýyladyşhana|greenhouse
depo|ammar|store
oda|otag|room
cihaz)|enjam)|device)
Standartlar|Standartlar|Standards
görsel|wizual|visual
Senkron|Sinhron|Sync
bekleyen|garaşýan|pending
Rehber ve sorular|Gollanma we soraglar|Guide and FAQ
Geri bildirim|Pikir bildirmek|Feedback
Yönetici masası|Dolandyryş otagy|Admin desk
bahçe ve sera ayrıntısı|bag we ýyladyşhana goşmaça maglumaty|orchard and greenhouse detail
kurulum|gurnama|setup
veri sağlığı|maglumat işleýişi|data health
analiz|seljerme|analysis
denetim izi|barlag yzygiderlilik|audit trail
Kullanıcılar ve onaylar|Ulanyjylar we tassyklamalar|Users and approvals
# parti depoda|# partiýa ammarda|# lots in store
# bekliyor|# garaşýar|# pending
Yeni kayıt|Täze ýazgy|New record
// --- profiller
Profil|Profil|Profile
Saha (bahçe)|Meýdan (bag)|Field (orchard)
Sera (muz)|Ýyladyşhana (banan)|Greenhouse (banana)
Depo|Ammar|Store
Lojistik|Logistika|Logistics
Ofis / kalite|Ofis / hil|Office / quality
Dış / müşteri|Daşky / müşderi|External / customer
// --- ana sayfa
İyi akşamlar|Agşamyňyz haýyrly|Good evening
Günaydın|Ertiriňiz haýyrly|Good morning
İyi günler|Günüňiz haýyrly|Good afternoon
Partiler|Partiýalar|Lots
Bugün bakılacaklar|Şu gün seretmeli|Today's checks
Tümü|Hemmesi|All
Tümü #|Hemmesi #|All #
Bahçe #|Bag #|Orchard #
Depo #|Ammar #|Store #
Uyarı #|Duýduryş #|Alert #
Odaya git|Otaga git|Go to room
Gir|Gir|Open
# daha|ýene #|# more
Zirai hava|Agro howa maglumaty|Farm weather
Zirai hava · # gün|Agro howa maglumaty · # gün|Farm weather · # days
İklim|Howa - Klimat|Climate
# gün içinde bahçelerde zirai risk yok.|# günüň içinde baglarda howa howpy ýok.|No farm weather risk in orchards for # days.
Kış dinlenmesi: don uyarısı gösterilmez.|Gyşky dynç: doňak duýduryşy görkezilmeýär.|Winter dormancy: frost alerts hidden.
Hava bilgisi yükleniyor…|Howa maglumaty ýüklenýär…|Loading weather…
Akış|Akym|Flow
şu an|häzir|now
Hasat|Hasyl|Harvest
Depolar ·|Ammarlar ·|Stores ·
boş|boş|empty
Bu hafta|Şu hepde|This week
Bu hafta hasat|Şu hepde hasyl|Harvest this week
Bu hafta sevk|Şu hepde ugratma|Dispatch this week
Kalite testi|Hil synagy|Quality test
Açık akt|Açyk akt|Open acts
Bahçeler · # sezonu|Baglar · # möwsümi|Orchards · # season
Hasat takvimi|Hasyl senenamasy|Harvest calendar
Plan|Meýilnama|Plan
# gerçekleşen|# ýerine ýetirilen|# actual
Meyve türüne göre gidişat|Miwe görnüşi boýunça ýagdaý|Progress by fruit
# plan|# meýilnama|# plan
hasat edilen|ýygylan|harvested
Yaklaşan hasat|Golaýdaky hasyl|Upcoming harvest
Yaklaşan hasat · # gün|Golaýdaky hasyl · # gün|Upcoming harvest · # days
# gün içinde ilk hasat yok|# günüň içinde ilkinji hasyl ýok|No first harvest within # days
Bahçeler · # bahçe|Baglar · # bag|Orchards · # orchards
Parti bilgisi|Partiýa maglumaty|Lot information
Kasa veya palet etiketindeki QR kodu telefonun kamerasıyla okutun: ürün, çeşit, hasat tarihi, sınıf ve o partinin kalite özeti açılır.|Gutudaky ýa-da paletdäki QR kody telefonuň kamerasy bilen okadyň: önüm, sort, hasyl senesi, synp we şol partiýanyň hil gysgaça maglumaty açylýar.|Scan the QR code on the crate or pallet label with your phone camera: product, variety, harvest date, class and the lot's quality summary will open.
Bu hesapta iç kayıtlar, tonajlar, aktlar ve kişi adları görünmez.|Bu hasapda ýazgylar, tonnažlar, aktlar we adamlaryň atlary görünmeýär.|Internal records, tonnages, acts and personal names are not shown on this account.
Kış dinlenmesinde don uyarısı gösterilmez (ağaca zarar vermez); çiçek döneminde tekrar uyarılır.|Gyşky dynçda doňak duýduryşy görkezilmeýär (agaja zyýan bermeýär); gülleýiş döwründe ýene duýdurylýar.|Frost alerts are hidden in winter dormancy (no harm to trees); they return at bloom.
// --- bahçe kartları
Özet|Gysgaça|Summary
Takvim|Senenama|Calendar
Tüm takvim|Doly senenama|Full calendar
Takvim · testler · iklim · profil — hepsi bahçenin içinde|Senenama · test · howa · profil — hemmesi bagyň içinde|Calendar · tests · climate · profile — all inside the orchard
Ağaç · alan|Agaç · meýdan|Trees · area
parsel bilgisi yok|bölek (karta) maglumaty ýok|no plot data
Çeşit|Görnüşi|Variety
# çeşit hasat takviminde|# görnüşi hasyl senenamasynda|# varieties in harvest calendar
2026 gerçekleşen|2026 ýerine ýetirilen|2026 actual
2027 plan|2027 meýilnama|2027 plan
#% #'ya göre|#% (#'a görä)|#% vs #
Gantt (satylan)|Gantt (satylan)|Gantt (sold)
hasat fişleri + Gantt|hasyl hasap + Gantt|harvest slips + Gantt
# hasat sırası|# hasyl tertibi|# harvest order
Hasat pencereleri #|Hasyl penjireleri #|Harvest windows #
# penceresi|# penjiresi|# window
# gerçek hasat|# hakyky hasyl|# actual harvest
# tahmini|# çaklama|# forecast
# çiçek|# gül|# bloom
# tahmini pencere|# çaklama penjire|# forecast window
Sezon sonucu #|Möwsüm netijesi #|Season result #
tahmin ile gerçek başlangıç farkı ort.|çaklama bilen hakyky başlangyç tapawudy ort.|avg. forecast vs actual start difference
Ağaçlar|Agaçlar|Trees
# ağaç|# agaç|# trees
bütçe|býujet|budget
kayıp|ýitgi|loss
yeni|täze|new
net|arassa|net
+ Kayıp / yeni dikim / sayım|+ Ýitgi / täze ekiş / sanaw|+ Loss / new planting / count
Bahçe bilgisi|Bag maglumaty|Orchard info
Profili düzenle|Profili üýtget|Edit profile
Konum|Ýerleşýän ýeri|Location
Denizden yükseklik|Deňiz derejesinden beýiklik|Altitude
Sorumlu|Jogapkär|Responsible
# çiçeklenme|# gülleýiş|# bloom
Kaynaklar ▾|Çeşmeler ▾|Sources ▾
Kaynaklar|Çeşmeler|Sources
Son test|Soňky test|Last test
test yok|synag ýok|no tests
arşiv #|arhiw #|archive #
Hasat rasatları (saha testleri)|Hasyl gözegçilikleri (meýdan testler)|Harvest observations (field tests)
Rasat ekle|Gözegçilik goş|Add observation
Bu çeşit için saha testi yok.|Bu sort üçin meýdan testi ýok.|No field tests for this variety.
Toplam|Jemi|Total
# test|# synag|# tests
# meyve|# miwe|# fruits
teste dokunun|teste basyň|tap a test
Teste dokunun: bütün bilgisi ve geçmişi.|Teste basyň: ähli maglumaty we geçmişi.|Tap a test: all details and history.
BBCH adımları|BBCH tapgyrlary|BBCH stages
Aşama|Tapgyr|Stage
Kaydet|Ýatda sakla|Save
Seyreltme|Ýekelemek|Thinning
Meyve sayımı → tonaj rasadı|Miwe sanawy → tonnaž gözegçiligi|Fruit count → tonnage estimate
Tarih|Sene|Date
Ağaç|Agaç|Tree
Tahmin|Çaklama|Estimate
Dikimler|Ekişler|Plantings
Dikim|Ekiş|Planting
Parsel|Bölek (karta)|Plot
Tüm parseller (#)|Ähli bölekler (#)|All plots (#)
// --- testler, formlar
Yeni test|Täze synag|New test
Meyve · sebze|Miwe · gök önüm|Fruit · vegetable
Bu hafta|Şu hepde|This week
# gün|# gün|# days
Bu yıl|Şu ýyl|This year
Hepsi|Hemmesi|All
Tüm yerler|Ähli ýerler|All places
Tüm ürünler|Ähli önümler|All products
Test|Test|Test
Ölçülen meyve|Ölçelen miwe|Fruits measured
Dikkat / uygun değil|Üns beriň / laýyk däl|Attention / not OK
Son testler|Soňky testler|Recent tests
Son testler · teste dokunun|Soňky testler · teste basyň|Recent tests · tap a test
Saha|Meýdan|Field
İhracat|Eksport|Export
dikkat|üns beriň|attention
Kalite raporu|Hil hasabaty|Quality report
Partiler ve testler (RefID)|Partiýalar we testler (RefID)|Lots and tests (RefID)
Standartlar (OECD|Standartlar (OECD|Standards (OECD
iç hedef)|içki meýilnama)|internal target)
# arşivi · çeşit çeşit analiz|# arhiwi · görnüş boýunça seljerme|# archive · analysis by variety
Ürün|Önüm|Product
Bahçe|Bag|Orchard
Bahçe / parsel|Bag / bölek|Orchard / plot
Parsel / sıra|Uçastok / hatar|Plot / row
Numune|Nusga|Sample
Numune sayısı (meyve / baş / yumru)|Nusga sany (miwe / baş / düwünek)|Sample count (fruit / head / tuber)
Sertlik|Gatylyk|Firmness
sertlik|gatylyk|firmness
sertlik #|gatylyk #|firmness #
Brix|Brix|Brix
Brix Şeker|Brix şeker|Brix sugar
Ağırlık|Agram|Weight
Kalibre / Çap|Kalibr / Diametr|Calibre / Diameter
çap #|diametr #|diameter #
Nişasta (#–#)|Krahmal (#–#)|Starch (#–#)
Renk / hue|Reňk / hue|Colour / hue
Kızarma / Zemin Renk Oranı|Gyzaryş / esasy reňk paýy|Blush / ground colour ratio
Kusur / Leke Oranı|Kemçilik / tegmil paýy|Defect / blemish ratio
Nitrat|Nitrat|Nitrate
Sonuç|Netije|Result
Fotoğraf ekle|Surat goş|Add photo
Fotoğraf ve not|Surat we bellik|Photo and note
Not (gözlem, kusur, hava…)|Bellik (gözegçilik, kemçilik, howa…)|Note (observation, defect, weather…)
Not (hava, kalite, sorun…)|Bellik (howa, hil, mesele…)|Note (weather, quality, issue…)
Ağaçtaki aşama (BBCH)|Agaçdaky tapgyr (BBCH)|Stage on the tree (BBCH)
isteğe bağlı|islege görä|optional
Ölçüm girilmedi|Ölçeg girizilmedi|No measurement entered
Hasat öncesi|Hasyldan öň|Pre-harvest
Hasattan Önce|Hasyldan öň|Pre-harvest
Hasat Testi|Hasyl test|Harvest test
eşik yok|çäk ýok|no threshold
uygun|laýyk|OK
Nereden|Nireden|From where
Ne kadar|Näçe|How much
Nereye gidiyor|Nirä barýar|Where it goes
Kasa|Gap|Crate
Palet # kutu|Palet # guty|Pallet # boxes
Kantar brüt|Terezi brutto|Scale gross
Dara|Tara|Tare
Net kg girin|Arassa kg giriziň|Enter net kg
Kendi partimiz|Öz partiýamyz|Our own lot
Dışarıdan (yeni parti)|Daşardan (täze partiýa)|From outside (new lot)
Depo ve oda seçin|Ammar we otag saýlaň|Select store and room
Yurtiçi|Içerki|Domestic
seçin / yazın|saýlaň / ýazyň|select / type
Fotoğraf, standart karşılaştırma, özel ürün testi → ayrıntılı form|Surat, standart deňeşdirme, ýörite önüm testi → giňişleýin forma|Photo, standard comparison, special product test → detailed form
Lot / fiş no, hasat aşaması, parçalı yük → ayrıntılı form|Lot / kagyz no, hasyl tapgyry, bölekleýin ýük → giňişleýin forma|Lot / slip no, harvest stage, split load → detailed form
Fotoğraf, depolama önerisi, parçalı yük → ayrıntılı form|Surat, saklamak teklibi, bölekleýin ýük → giňişleýin forma|Photo, storage advice, split load → detailed form
Palet, ambalaj listesi, kutu kutu sınıf ve fotoğraf → ayrıntılı form|Palet, gaplama sanawy, guty boýunça synp we surat → giňişleýin forma|Pallet, packing list, class per box and photo → detailed form
// --- ürünler
Elma|Alma|Apple
Armut|Armyt|Pear
Nashi|Aziýa armydy|Nashi pear
Kiraz|Çereşnýa|Cherry
Şeftali|Şetdaly|Peach
Nektarin|Nektarin|Nectarine
Erik|Garaly|Plum
Kayısı|Erik|Apricot
Hurma|Hurma|Persimmon
Soğan|Sogan|Onion
Patates|Ýeralma|Potato
Havuç|Käşir|Carrot
Domates|Pomidor|Tomato
Karpuz|Garpyz|Watermelon
Kavun|Gawun|Melon
Üzüm|Üzüm|Grape
Mısır|Mekgejöwen|Maize
Meyve|Miwe|Fruit
sebze|gök önüm|vegetable
// --- BBCH
Tam çiçeklenme|Doly gülleýiş|Full bloom
Çiçeklenme başı|Gülleýşiň başy|Beginning of bloom
Çiçeklenme sonu|Gülleýşiň soňy|End of bloom
Meyve tutumu|Miwe tutyjylygy|Fruit set
Fındık iriliği|Hoz ululygy|Hazelnut size
T evresi|T tapgyry|T stage
Meyve büyümesi|Miwe ösüşi|Fruit growth
Olgunlaşma başı|Ýetişmegiň başy|Beginning of ripening
İleri olgunluk|Aşa bişen|Advanced ripeness
Hasat, tam yeme olgunluğu|Hasyl, doly iýmäge bişen|Harvest, full eating ripeness
Renklenme başı|Reňklenmegiň başy|Beginning of colouring
İleri renklenme|Ýokary reňklenme|Advanced colouring
Hasat, yeme olgunluğu|Hasyl, bişen (iýmäge ýetişen)|Harvest, eating ripeness
// --- yönetim
Yönetim analizi|Dolandyryş seljermesi|Management analysis
Denetim izi|Barlag yzygiderlilik|Audit trail
Kurulum ve uyarlama|Gurnama we uýgunlaşdyrma|Setup and adaptation
Veri sağlığı|Maglumat işleýişi|Data health
Bahçeler ve seralar|Baglar we ýyladyşhanalar|Orchards and greenhouses
Bahçeler ve seralar · ayrıntı|Baglar we ýyladyşhanalar · goşmaça|Orchards and greenhouses · detail
ayrıntı|goşmaça|detail
# kalite kaydı|# hil ýazgysy|# quality records
#: # hasat günü|#: # hasyl güni|#: # harvest days
#: # akt|#: # akt|#: # acts
son hasat #|soňky hasyl #|last harvest #
son test #|soňky synag #|last test #
Onay bekleyen kullanıcı|Tassyklama garaşýan ulanyjy|User awaiting approval
Onayla|Tassykla|Approve
Yönetici|Ýolbaşçy|Administrator
Müdür|Müdir|Manager
Operatör|Operator|Operator
Kalite kontrolcü|Hil barlagçy|Quality inspector
Kişiler ve roller|Adamlar we wezipeler|People and roles
İndir|Göçürip al|Download
Yedek|Ätiýaçlyk|Backup
// --- ortak
# sezonu|# möwsümi|# season
# bahçe|# bag|# orchards
hasatta|hasylda|in harvest
toplanan # / # t|ýygnalan # / # t|collected # / # t
Muz seraları|Banan ýyladyşhanalary|Banana greenhouses
Bugün # salkım|Şu gün # salkym|Today # bunches
# çiçeklenme girildi|# gülleýiş girizildi|# bloom entered
çeşit — tahmini hasat tarihleri buna göre çıkar.|sort — çak edilýän hasyl seneleri şuňa görä çykýar.|varieties — forecast harvest dates follow from this.
sıradaki|indiki|next
Dokun → gir. Boş bırakılan ölçüm sonuca girmez. Ürünün kendi test seti ve eşikleri|Bas → giriz. Boş galdyrylan ölçeg netijä girmeýär. Önümiň öz synag toplumy we çäkleri|Tap → enter. Empty measurements are not counted. Product's own test set and thresholds
ürün seçince gelir|önüm saýlananda gelýär|appears when product is chosen
Not (gözlem, kusur, hava…)|Bellik (syn, kemçilik, howa…)|Note (observation, defect, weather…)
# çeşit daha — Takvim sekmesinde|ýene # sort — Senenama bölüminde|# more varieties — in Calendar tab
ölç|ölçe|measure
çeşit daha — Takvim sekmesinde|sort ýene — Senenama bölüminde|more varieties — in Calendar tab
meyve|miwe|fruit
# kayıp|# ýitgi|# lost
# yeni|# täze|# new
Hasat günü|Hasyl güni|Harvest day
Şahit numune|Şaýat nusga|Reference sample
yeni RefID|täze RefID|new RefID
Sertlik ·|Gatylyk ·|Firmness ·
bugün|şu gün|today
# gün önce|# gün öň|# days ago
Son # gün|Soňky # gün|Last # days
saat|sagat|hour
hazır|taýýar|ready
otomatik|awtomatik|automatic
hiç|hiç|never
Kaydediliyor…|Ýatda saklanýar…|Saving…
Vazgeç|Ýatyr|Cancel
Sil|Poz|Delete
Düzenle|Üýtget|Edit
Kapat|Ýap|Close
Tamam|Bolýar|OK
Evet|Hawa|Yes
Hayır|Ýok|No
`;

export const DICT: Record<string, [string, string]> = {};
for (const line of RAW.split('\n')) {
  const t = line.trim();
  if (!t || t.startsWith('//')) continue;
  const [tr, tk, en] = t.split('|');
  if (tr && tk && en) DICT[tr] = [tk, en];
}

/** Ay ve gün adları (tarih yazıları kelime kelime) */
export const WORDS: Record<string, [string, string]> = {
  Ocak: ['Ýanwar', 'January'], Şubat: ['Fewral', 'February'], Mart: ['Mart', 'March'], Nisan: ['Aprel', 'April'], Mayıs: ['Maý', 'May'], Haziran: ['Iýun', 'June'],
  Temmuz: ['Iýul', 'July'], Ağustos: ['Awgust', 'August'], Eylül: ['Sentýabr', 'September'], Ekim: ['Oktýabr', 'October'], Kasım: ['Noýabr', 'November'], Aralık: ['Dekabr', 'December'],
  Oca: ['Ýan', 'Jan'], Şub: ['Few', 'Feb'], Mar: ['Mar', 'Mar'], Nis: ['Apr', 'Apr'], May: ['Maý', 'May'], Haz: ['Iýn', 'Jun'], Tem: ['Iýl', 'Jul'], Ağu: ['Awg', 'Aug'], Eyl: ['Sen', 'Sep'], Eki: ['Okt', 'Oct'], Kas: ['Noý', 'Nov'], Ara: ['Dek', 'Dec'],
  Pazartesi: ['Duşenbe', 'Monday'], Salı: ['Sişenbe', 'Tuesday'], Çarşamba: ['Çarşenbe', 'Wednesday'], Perşembe: ['Penşenbe', 'Thursday'], Cuma: ['Anna', 'Friday'], Cumartesi: ['Şenbe', 'Saturday'], Pazar: ['Ýekşenbe', 'Sunday'],
  Pzt: ['Duş', 'Mon'], Sal: ['Siş', 'Tue'], Çar: ['Çar', 'Wed'], Per: ['Pen', 'Thu'], Cum: ['Ann', 'Fri'], Cmt: ['Şen', 'Sat'], Paz: ['Ýek', 'Sun'],
};
